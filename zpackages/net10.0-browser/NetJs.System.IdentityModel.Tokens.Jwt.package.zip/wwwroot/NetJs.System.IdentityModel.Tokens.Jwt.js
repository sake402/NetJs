
//--TRIMMABLE-BOUNDARY-START(121)
(function ($global, $, $$, $mia, $sc, $sm, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sri, $sl, $mwp, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sci, $sim, $srm, $sds, $srn, $sfa, $sscr, $snsc, $stc, $snq, $srij, $snh, $mil, $scm, $so, $sre, $srei, $srel, $srp, $sle, $mxdi, $med, $mexla, $mep, $scp, $scs, $sdp, $srw, $srl, $srsf, $str, $sdts, $spx, $spxl, $sxxd, $sct, $sca, $meo, $mexl, $sipl, $stew, $stj, $mit, $mij) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.IdentityModel.Tokens.Jwt", 
    {
  "h": 121,
  "f": "System.IdentityModel.Tokens.Jwt",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 107282433,
      "c": 12992184321,
      "a": [
        {
          "v": "Serviceable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 54263809,
      "c": 8644198401,
      "a": [
        {
          "v": true,
          "t": 262145
        }
      ]
    },
    {
      "t": 140050433,
      "c": 8729985025,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 129695745,
      "c": 13014597633,
      "a": [
        {
          "v": "System.IdentityModel.Tokens.Jwt.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107282433,
      "c": 12992184321,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107282433,
      "c": 12992184321,
      "a": [
        {
          "v": "IsAotCompatible",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "Microsoft Corporation.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106627073,
      "c": 8696561665,
      "a": [
        {
          "v": "\u00A9 Microsoft Corporation. All rights reserved.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106889217,
      "c": 8696823809,
      "a": [
        {
          "v": "Includes types that provide support for creating, serializing and validating JSON Web Tokens. As of IdentityModel 7x, this is a legacy tool that should be replaced with Microsoft.IdentityModel.JsonWebTokens.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "9.0.0.26264",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "Microsoft IdentityModel",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.IdentityModel.Tokens.Jwt",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107282433,
      "c": 12992184321,
      "a": [
        {
          "v": "RepositoryUrl",
          "t": 1310721
        },
        {
          "v": "https://github.com/AzureAD/azure-activedirectory-identitymodel-extensions-for-dotnet",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(131193)
        $asm.$cls("$sitj.System.IdentityModel.Tokens.Jwt.JwtConstants", ($self) => class JwtConstants
        {
            //--TRIMMABLE-BOUNDARY-START(8590065785)
            /*string*/ static HeaderType = null;
            //--TRIMMABLE-BOUNDARY-END(8590065785)
            
            //--TRIMMABLE-BOUNDARY-START(12885033081)
            /*string*/ static HeaderTypeAlt = null;
            //--TRIMMABLE-BOUNDARY-END(12885033081)
            
            //--TRIMMABLE-BOUNDARY-START(38654836857)
            /*string*/ static TokenType = null;
            //--TRIMMABLE-BOUNDARY-END(38654836857)
            
            //--TRIMMABLE-BOUNDARY-START(42949804153)
            /*string*/ static TokenTypeAlt = null;
            //--TRIMMABLE-BOUNDARY-END(42949804153)
            
            //--TRIMMABLE-BOUNDARY-START(17180000377)
            /*string*/ static JsonCompactSerializationRegex = null;
            //--TRIMMABLE-BOUNDARY-END(17180000377)
            
            //--TRIMMABLE-BOUNDARY-START(21474967673)
            /*string*/ static JweCompactSerializationRegex = null;
            //--TRIMMABLE-BOUNDARY-END(21474967673)
            
            //--TRIMMABLE-BOUNDARY-START(25769934969)
            /*int*/ static JweSegmentCount = 5;
            //--TRIMMABLE-BOUNDARY-END(25769934969)
            
            //--TRIMMABLE-BOUNDARY-START(30064902265)
            /*int*/ static JwsSegmentCount = 3;
            //--TRIMMABLE-BOUNDARY-END(30064902265)
            
            //--TRIMMABLE-BOUNDARY-START(34359869561)
            /*int*/ static MaxJwtSegmentCount = 5;
            //--TRIMMABLE-BOUNDARY-END(34359869561)
            
            //--TRIMMABLE-BOUNDARY-START(4295098489)
            /*string*/ static DirectKeyUseAlg = null;
            //--TRIMMABLE-BOUNDARY-END(4295098489)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590065785)
                    this.HeaderType = "JWT";
                    //--TRIMMABLE-BOUNDARY-END(8590065785)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885033081)
                    this.HeaderTypeAlt = "http://openid.net/specs/jwt/1.0";
                    //--TRIMMABLE-BOUNDARY-END(12885033081)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654836857)
                    this.TokenType = "JWT";
                    //--TRIMMABLE-BOUNDARY-END(38654836857)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949804153)
                    this.TokenTypeAlt = "urn:ietf:params:oauth:token-type:jwt";
                    //--TRIMMABLE-BOUNDARY-END(42949804153)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180000377)
                    this.JsonCompactSerializationRegex = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*$";
                    //--TRIMMABLE-BOUNDARY-END(17180000377)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474967673)
                    this.JweCompactSerializationRegex = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+$";
                    //--TRIMMABLE-BOUNDARY-END(21474967673)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295098489)
                    this.DirectKeyUseAlg = "dir";
                    //--TRIMMABLE-BOUNDARY-END(4295098489)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 131193;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590065785),
    {
      "t": 1310721,
      "n": "HeaderType",
      "d": 131193,
      "h": 8590065785,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590065785),
//--TRIMMABLE-BOUNDARY-START(12885033081),
    {
      "t": 1310721,
      "n": "HeaderTypeAlt",
      "d": 131193,
      "h": 12885033081,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885033081),
//--TRIMMABLE-BOUNDARY-START(38654836857),
    {
      "t": 1310721,
      "n": "TokenType",
      "d": 131193,
      "h": 38654836857,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38654836857),
//--TRIMMABLE-BOUNDARY-START(42949804153),
    {
      "t": 1310721,
      "n": "TokenTypeAlt",
      "d": 131193,
      "h": 42949804153,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42949804153),
//--TRIMMABLE-BOUNDARY-START(17180000377),
    {
      "t": 1310721,
      "n": "JsonCompactSerializationRegex",
      "d": 131193,
      "h": 17180000377,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180000377),
//--TRIMMABLE-BOUNDARY-START(21474967673),
    {
      "t": 1310721,
      "n": "JweCompactSerializationRegex",
      "d": 131193,
      "h": 21474967673,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21474967673),
//--TRIMMABLE-BOUNDARY-START(25769934969),
    {
      "t": 655361,
      "n": "JweSegmentCount",
      "d": 131193,
      "h": 25769934969,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25769934969),
//--TRIMMABLE-BOUNDARY-START(30064902265),
    {
      "t": 655361,
      "n": "JwsSegmentCount",
      "d": 131193,
      "h": 30064902265,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30064902265),
//--TRIMMABLE-BOUNDARY-START(34359869561),
    {
      "t": 655361,
      "n": "MaxJwtSegmentCount",
      "d": 131193,
      "h": 34359869561,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34359869561),
//--TRIMMABLE-BOUNDARY-START(4295098489),
    {
      "t": 1310721,
      "n": "DirectKeyUseAlg",
      "d": 131193,
      "h": 4295098489,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295098489)
  ],
  "h": 131193
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtConstants`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131193)
        
        
        //--TRIMMABLE-BOUNDARY-START(65657)
        $asm.$cls("$sitj.System.IdentityModel.Tokens.Jwt.JsonClaimValueTypes", ($self) => class JsonClaimValueTypes
        {
            //--TRIMMABLE-BOUNDARY-START(4295032953)
            /*string*/ static Json = null;
            //--TRIMMABLE-BOUNDARY-END(4295032953)
            
            //--TRIMMABLE-BOUNDARY-START(8590000249)
            /*string*/ static JsonArray = null;
            //--TRIMMABLE-BOUNDARY-END(8590000249)
            
            //--TRIMMABLE-BOUNDARY-START(12884967545)
            /*string*/ static JsonNull = null;
            //--TRIMMABLE-BOUNDARY-END(12884967545)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295032953)
                    this.Json = "JSON";
                    //--TRIMMABLE-BOUNDARY-END(4295032953)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590000249)
                    this.JsonArray = "JSON_ARRAY";
                    //--TRIMMABLE-BOUNDARY-END(8590000249)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12884967545)
                    this.JsonNull = "JSON_NULL";
                    //--TRIMMABLE-BOUNDARY-END(12884967545)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 65657;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295032953),
    {
      "t": 1310721,
      "n": "Json",
      "d": 65657,
      "h": 4295032953,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295032953),
//--TRIMMABLE-BOUNDARY-START(8590000249),
    {
      "t": 1310721,
      "n": "JsonArray",
      "d": 65657,
      "h": 8590000249,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590000249),
//--TRIMMABLE-BOUNDARY-START(12884967545),
    {
      "t": 1310721,
      "n": "JsonNull",
      "d": 65657,
      "h": 12884967545,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12884967545)
  ],
  "h": 65657
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JsonClaimValueTypes`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65657)
        
        
        //--TRIMMABLE-BOUNDARY-START(721017)
        $asm.$cls("$sitj.System.IdentityModel.Tokens.Jwt.LogMessages", ($self) => class LogMessages
        {
            //--TRIMMABLE-BOUNDARY-START(4295688313)
            /*string*/ static IDX12401 = null;
            //--TRIMMABLE-BOUNDARY-END(4295688313)
            
            //--TRIMMABLE-BOUNDARY-START(8590655609)
            /*string*/ static IDX12706 = null;
            //--TRIMMABLE-BOUNDARY-END(8590655609)
            
            //--TRIMMABLE-BOUNDARY-START(12885622905)
            /*string*/ static IDX12709 = null;
            //--TRIMMABLE-BOUNDARY-END(12885622905)
            
            //--TRIMMABLE-BOUNDARY-START(17180590201)
            /*string*/ static IDX12710 = null;
            //--TRIMMABLE-BOUNDARY-END(17180590201)
            
            //--TRIMMABLE-BOUNDARY-START(21475557497)
            /*string*/ static IDX12711 = null;
            //--TRIMMABLE-BOUNDARY-END(21475557497)
            
            //--TRIMMABLE-BOUNDARY-START(25770524793)
            /*string*/ static IDX12712 = null;
            //--TRIMMABLE-BOUNDARY-END(25770524793)
            
            //--TRIMMABLE-BOUNDARY-START(30065492089)
            /*string*/ static IDX12713 = null;
            //--TRIMMABLE-BOUNDARY-END(30065492089)
            
            //--TRIMMABLE-BOUNDARY-START(34360459385)
            /*string*/ static IDX12714 = null;
            //--TRIMMABLE-BOUNDARY-END(34360459385)
            
            //--TRIMMABLE-BOUNDARY-START(38655426681)
            /*string*/ static IDX12715 = null;
            //--TRIMMABLE-BOUNDARY-END(38655426681)
            
            //--TRIMMABLE-BOUNDARY-START(42950393977)
            /*string*/ static IDX12720 = null;
            //--TRIMMABLE-BOUNDARY-END(42950393977)
            
            //--TRIMMABLE-BOUNDARY-START(47245361273)
            /*string*/ static IDX12721 = null;
            //--TRIMMABLE-BOUNDARY-END(47245361273)
            
            //--TRIMMABLE-BOUNDARY-START(51540328569)
            /*string*/ static IDX12722 = null;
            //--TRIMMABLE-BOUNDARY-END(51540328569)
            
            //--TRIMMABLE-BOUNDARY-START(55835295865)
            /*string*/ static IDX12723 = null;
            //--TRIMMABLE-BOUNDARY-END(55835295865)
            
            //--TRIMMABLE-BOUNDARY-START(60130263161)
            /*string*/ static IDX12729 = null;
            //--TRIMMABLE-BOUNDARY-END(60130263161)
            
            //--TRIMMABLE-BOUNDARY-START(64425230457)
            /*string*/ static IDX12730 = null;
            //--TRIMMABLE-BOUNDARY-END(64425230457)
            
            //--TRIMMABLE-BOUNDARY-START(68720197753)
            /*string*/ static IDX12735 = null;
            //--TRIMMABLE-BOUNDARY-END(68720197753)
            
            //--TRIMMABLE-BOUNDARY-START(73015165049)
            /*string*/ static IDX12736 = null;
            //--TRIMMABLE-BOUNDARY-END(73015165049)
            
            //--TRIMMABLE-BOUNDARY-START(77310132345)
            /*string*/ static IDX12737 = null;
            //--TRIMMABLE-BOUNDARY-END(77310132345)
            
            //--TRIMMABLE-BOUNDARY-START(81605099641)
            /*string*/ static IDX12738 = null;
            //--TRIMMABLE-BOUNDARY-END(81605099641)
            
            //--TRIMMABLE-BOUNDARY-START(85900066937)
            /*string*/ static IDX12739 = null;
            //--TRIMMABLE-BOUNDARY-END(85900066937)
            
            //--TRIMMABLE-BOUNDARY-START(90195034233)
            /*string*/ static IDX12740 = null;
            //--TRIMMABLE-BOUNDARY-END(90195034233)
            
            //--TRIMMABLE-BOUNDARY-START(94490001529)
            /*string*/ static IDX12741 = null;
            //--TRIMMABLE-BOUNDARY-END(94490001529)
            
            //--TRIMMABLE-BOUNDARY-START(98784968825)
            /*string*/ static IDX12742 = null;
            //--TRIMMABLE-BOUNDARY-END(98784968825)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295688313)
                    this.IDX12401 = "IDX12401: Expires: '{0}' must be after NotBefore: '{1}'.";
                    //--TRIMMABLE-BOUNDARY-END(4295688313)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590655609)
                    this.IDX12706 = "IDX12706: '{0}' can only write SecurityTokens of type: '{1}', 'token' type is: '{2}'.";
                    //--TRIMMABLE-BOUNDARY-END(8590655609)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885622905)
                    this.IDX12709 = "IDX12709: CanReadToken() returned false. JWT is not well formed.\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'.";
                    //--TRIMMABLE-BOUNDARY-END(12885622905)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180590201)
                    this.IDX12710 = "IDX12710: Only a single 'Actor' is supported. Found second claim of type: '{0}', value: '{1}'";
                    //--TRIMMABLE-BOUNDARY-END(17180590201)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475557497)
                    this.IDX12711 = "IDX12711: actor.BootstrapContext is not a string AND actor.BootstrapContext is not a JWT";
                    //--TRIMMABLE-BOUNDARY-END(21475557497)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770524793)
                    this.IDX12712 = "IDX12712: actor.BootstrapContext is null. Creating the token using actor.Claims.";
                    //--TRIMMABLE-BOUNDARY-END(25770524793)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065492089)
                    this.IDX12713 = "IDX12713: Creating actor value using actor.BootstrapContext(as string)";
                    //--TRIMMABLE-BOUNDARY-END(30065492089)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360459385)
                    this.IDX12714 = "IDX12714: Creating actor value using actor.BootstrapContext.rawData";
                    //--TRIMMABLE-BOUNDARY-END(34360459385)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655426681)
                    this.IDX12715 = "IDX12715: Creating actor value by writing the JwtSecurityToken created from actor.BootstrapContext";
                    //--TRIMMABLE-BOUNDARY-END(38655426681)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950393977)
                    this.IDX12720 = "IDX12720: Token string does not match the token formats: JWE (header.encryptedKey.iv.ciphertext.tag) or JWS (header.payload.signature)";
                    //--TRIMMABLE-BOUNDARY-END(42950393977)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245361273)
                    this.IDX12721 = "IDX12721: Creating JwtSecurityToken: Issuer: '{0}', Audience: '{1}'";
                    //--TRIMMABLE-BOUNDARY-END(47245361273)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540328569)
                    this.IDX12722 = "IDX12722: Creating security token from the header: '{0}', payload: '{1}'.";
                    //--TRIMMABLE-BOUNDARY-END(51540328569)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835295865)
                    this.IDX12723 = "IDX12723: Unable to decode the payload '{0}' as Base64Url encoded string.";
                    //--TRIMMABLE-BOUNDARY-END(55835295865)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130263161)
                    this.IDX12729 = "IDX12729: Unable to decode the header '{0}' as Base64Url encoded string.";
                    //--TRIMMABLE-BOUNDARY-END(60130263161)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425230457)
                    this.IDX12730 = "IDX12730: Failed to create the token encryption provider.";
                    //--TRIMMABLE-BOUNDARY-END(64425230457)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720197753)
                    this.IDX12735 = "IDX12735: If JwtSecurityToken.InnerToken != null, then JwtSecurityToken.Header.EncryptingCredentials must be set.";
                    //--TRIMMABLE-BOUNDARY-END(68720197753)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015165049)
                    this.IDX12736 = "IDX12736: JwtSecurityToken.SigningCredentials is not supported when JwtSecurityToken.InnerToken is set.";
                    //--TRIMMABLE-BOUNDARY-END(73015165049)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310132345)
                    this.IDX12737 = "IDX12737: EncryptingCredentials set on JwtSecurityToken.InnerToken is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(77310132345)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81605099641)
                    this.IDX12738 = "IDX12738: Header.Cty != null, assuming JWS. Cty: '{0}'.";
                    //--TRIMMABLE-BOUNDARY-END(81605099641)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85900066937)
                    this.IDX12739 = "IDX12739: JWT has three segments but is not in proper JWS format.";
                    //--TRIMMABLE-BOUNDARY-END(85900066937)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90195034233)
                    this.IDX12740 = "IDX12740: JWT has five segments but is not in proper JWE format.";
                    //--TRIMMABLE-BOUNDARY-END(90195034233)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94490001529)
                    this.IDX12741 = "IDX12741: JWT must have three segments (JWS) or five segments (JWE).";
                    //--TRIMMABLE-BOUNDARY-END(94490001529)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784968825)
                    this.IDX12742 = "IDX12742: ''{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation.";
                    //--TRIMMABLE-BOUNDARY-END(98784968825)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 721017;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688313),
    {
      "t": 1310721,
      "n": "IDX12401",
      "d": 721017,
      "h": 4295688313,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295688313),
//--TRIMMABLE-BOUNDARY-START(8590655609),
    {
      "t": 1310721,
      "n": "IDX12706",
      "d": 721017,
      "h": 8590655609,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590655609),
//--TRIMMABLE-BOUNDARY-START(12885622905),
    {
      "t": 1310721,
      "n": "IDX12709",
      "d": 721017,
      "h": 12885622905,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885622905),
//--TRIMMABLE-BOUNDARY-START(17180590201),
    {
      "t": 1310721,
      "n": "IDX12710",
      "d": 721017,
      "h": 17180590201,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180590201),
//--TRIMMABLE-BOUNDARY-START(21475557497),
    {
      "t": 1310721,
      "n": "IDX12711",
      "d": 721017,
      "h": 21475557497,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475557497),
//--TRIMMABLE-BOUNDARY-START(25770524793),
    {
      "t": 1310721,
      "n": "IDX12712",
      "d": 721017,
      "h": 25770524793,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25770524793),
//--TRIMMABLE-BOUNDARY-START(30065492089),
    {
      "t": 1310721,
      "n": "IDX12713",
      "d": 721017,
      "h": 30065492089,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065492089),
//--TRIMMABLE-BOUNDARY-START(34360459385),
    {
      "t": 1310721,
      "n": "IDX12714",
      "d": 721017,
      "h": 34360459385,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34360459385),
//--TRIMMABLE-BOUNDARY-START(38655426681),
    {
      "t": 1310721,
      "n": "IDX12715",
      "d": 721017,
      "h": 38655426681,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38655426681),
//--TRIMMABLE-BOUNDARY-START(42950393977),
    {
      "t": 1310721,
      "n": "IDX12720",
      "d": 721017,
      "h": 42950393977,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42950393977),
//--TRIMMABLE-BOUNDARY-START(47245361273),
    {
      "t": 1310721,
      "n": "IDX12721",
      "d": 721017,
      "h": 47245361273,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47245361273),
//--TRIMMABLE-BOUNDARY-START(51540328569),
    {
      "t": 1310721,
      "n": "IDX12722",
      "d": 721017,
      "h": 51540328569,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51540328569),
//--TRIMMABLE-BOUNDARY-START(55835295865),
    {
      "t": 1310721,
      "n": "IDX12723",
      "d": 721017,
      "h": 55835295865,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55835295865),
//--TRIMMABLE-BOUNDARY-START(60130263161),
    {
      "t": 1310721,
      "n": "IDX12729",
      "d": 721017,
      "h": 60130263161,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60130263161),
//--TRIMMABLE-BOUNDARY-START(64425230457),
    {
      "t": 1310721,
      "n": "IDX12730",
      "d": 721017,
      "h": 64425230457,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64425230457),
//--TRIMMABLE-BOUNDARY-START(68720197753),
    {
      "t": 1310721,
      "n": "IDX12735",
      "d": 721017,
      "h": 68720197753,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68720197753),
//--TRIMMABLE-BOUNDARY-START(73015165049),
    {
      "t": 1310721,
      "n": "IDX12736",
      "d": 721017,
      "h": 73015165049,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73015165049),
//--TRIMMABLE-BOUNDARY-START(77310132345),
    {
      "t": 1310721,
      "n": "IDX12737",
      "d": 721017,
      "h": 77310132345,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77310132345),
//--TRIMMABLE-BOUNDARY-START(81605099641),
    {
      "t": 1310721,
      "n": "IDX12738",
      "d": 721017,
      "h": 81605099641,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81605099641),
//--TRIMMABLE-BOUNDARY-START(85900066937),
    {
      "t": 1310721,
      "n": "IDX12739",
      "d": 721017,
      "h": 85900066937,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85900066937),
//--TRIMMABLE-BOUNDARY-START(90195034233),
    {
      "t": 1310721,
      "n": "IDX12740",
      "d": 721017,
      "h": 90195034233,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90195034233),
//--TRIMMABLE-BOUNDARY-START(94490001529),
    {
      "t": 1310721,
      "n": "IDX12741",
      "d": 721017,
      "h": 94490001529,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94490001529),
//--TRIMMABLE-BOUNDARY-START(98784968825),
    {
      "t": 1310721,
      "n": "IDX12742",
      "d": 721017,
      "h": 98784968825,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98784968825)
  ],
  "h": 721017
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.LogMessages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721017)
        
        
        //--TRIMMABLE-BOUNDARY-START(524409)
        $asm.$cls("$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenConverter", ($self) => class JwtSecurityTokenConverter
        {
            //--TRIMMABLE-BOUNDARY-START(4295491705)
            static /*JwtSecurityToken */ Convert(/*JsonWebToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (token === null)
                {
                    throw new $.$$.System.ArgumentNullException().$ctor$19("token");
                }
                if (token.InnerToken !== null)
                {
                    /*var*/ let jwtSecurityToken = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$3(token.EncodedToken);
                    jwtSecurityToken.InnerToken = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$3(token.InnerToken.EncodedToken);
                    return jwtSecurityToken;
                }
                else if (!$.$$.System.String.IsNullOrEmpty(token.EncodedToken))
                {
                    return new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$3(token.EncodedToken);
                }
                throw new $.$$.System.ArgumentException().$ctor$14("token.EncodedToken must be set");
            }
            //--TRIMMABLE-BOUNDARY-END(4295491705)
            
            static $h = 524409;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295491705),
    {
      "r": 458873,
      "p": [
        {
          "n": "token",
          "p": 262264
        }
      ],
      "n": "Convert",
      "d": 524409,
      "h": 4295491705,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295491705)
  ],
  "h": 524409
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtSecurityTokenConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524409)
        
        
        //--TRIMMABLE-BOUNDARY-START(262265)
        $asm.$str("$sitj.System.IdentityModel.Tokens.Jwt.JwtHeaderParameterNames", ($self) => class JwtHeaderParameterNames extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8590196857)
            /*string*/ static Alg = null;
            //--TRIMMABLE-BOUNDARY-END(8590196857)
            
            //--TRIMMABLE-BOUNDARY-START(21475098745)
            /*string*/ static Cty = null;
            //--TRIMMABLE-BOUNDARY-END(21475098745)
            
            //--TRIMMABLE-BOUNDARY-START(25770066041)
            /*string*/ static Enc = null;
            //--TRIMMABLE-BOUNDARY-END(25770066041)
            
            //--TRIMMABLE-BOUNDARY-START(34360000633)
            /*string*/ static IV = null;
            //--TRIMMABLE-BOUNDARY-END(34360000633)
            
            //--TRIMMABLE-BOUNDARY-START(38654967929)
            /*string*/ static Jku = null;
            //--TRIMMABLE-BOUNDARY-END(38654967929)
            
            //--TRIMMABLE-BOUNDARY-START(42949935225)
            /*string*/ static Jwk = null;
            //--TRIMMABLE-BOUNDARY-END(42949935225)
            
            //--TRIMMABLE-BOUNDARY-START(47244902521)
            /*string*/ static Kid = null;
            //--TRIMMABLE-BOUNDARY-END(47244902521)
            
            //--TRIMMABLE-BOUNDARY-START(51539869817)
            /*string*/ static Typ = null;
            //--TRIMMABLE-BOUNDARY-END(51539869817)
            
            //--TRIMMABLE-BOUNDARY-START(55834837113)
            /*string*/ static X5c = null;
            //--TRIMMABLE-BOUNDARY-END(55834837113)
            
            //--TRIMMABLE-BOUNDARY-START(60129804409)
            /*string*/ static X5t = null;
            //--TRIMMABLE-BOUNDARY-END(60129804409)
            
            //--TRIMMABLE-BOUNDARY-START(64424771705)
            /*string*/ static X5u = null;
            //--TRIMMABLE-BOUNDARY-END(64424771705)
            
            //--TRIMMABLE-BOUNDARY-START(68719739001)
            /*string*/ static Zip = null;
            //--TRIMMABLE-BOUNDARY-END(68719739001)
            
            //--TRIMMABLE-BOUNDARY-START(30065033337)
            /*string*/ static Epk = null;
            //--TRIMMABLE-BOUNDARY-END(30065033337)
            
            //--TRIMMABLE-BOUNDARY-START(12885164153)
            /*string*/ static Apu = null;
            //--TRIMMABLE-BOUNDARY-END(12885164153)
            
            //--TRIMMABLE-BOUNDARY-START(17180131449)
            /*string*/ static Apv = null;
            //--TRIMMABLE-BOUNDARY-END(17180131449)
            
            //--TRIMMABLE-BOUNDARY-START(4295229561)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229561)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590196857)
                    this.Alg = "alg";
                    //--TRIMMABLE-BOUNDARY-END(8590196857)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475098745)
                    this.Cty = "cty";
                    //--TRIMMABLE-BOUNDARY-END(21475098745)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770066041)
                    this.Enc = "enc";
                    //--TRIMMABLE-BOUNDARY-END(25770066041)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360000633)
                    this.IV = "iv";
                    //--TRIMMABLE-BOUNDARY-END(34360000633)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654967929)
                    this.Jku = "jku";
                    //--TRIMMABLE-BOUNDARY-END(38654967929)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949935225)
                    this.Jwk = "jwk";
                    //--TRIMMABLE-BOUNDARY-END(42949935225)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244902521)
                    this.Kid = "kid";
                    //--TRIMMABLE-BOUNDARY-END(47244902521)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51539869817)
                    this.Typ = "typ";
                    //--TRIMMABLE-BOUNDARY-END(51539869817)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834837113)
                    this.X5c = "x5c";
                    //--TRIMMABLE-BOUNDARY-END(55834837113)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60129804409)
                    this.X5t = "x5t";
                    //--TRIMMABLE-BOUNDARY-END(60129804409)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424771705)
                    this.X5u = "x5u";
                    //--TRIMMABLE-BOUNDARY-END(64424771705)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68719739001)
                    this.Zip = "zip";
                    //--TRIMMABLE-BOUNDARY-END(68719739001)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065033337)
                    this.Epk = "epk";
                    //--TRIMMABLE-BOUNDARY-END(30065033337)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885164153)
                    this.Apu = "apu";
                    //--TRIMMABLE-BOUNDARY-END(12885164153)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180131449)
                    this.Apv = "apv";
                    //--TRIMMABLE-BOUNDARY-END(17180131449)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 262265;
            static $z = 0;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590196857),
    {
      "t": 1310721,
      "n": "Alg",
      "d": 262265,
      "h": 8590196857,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590196857),
//--TRIMMABLE-BOUNDARY-START(21475098745),
    {
      "t": 1310721,
      "n": "Cty",
      "d": 262265,
      "h": 21475098745,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475098745),
//--TRIMMABLE-BOUNDARY-START(25770066041),
    {
      "t": 1310721,
      "n": "Enc",
      "d": 262265,
      "h": 25770066041,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770066041),
//--TRIMMABLE-BOUNDARY-START(34360000633),
    {
      "t": 1310721,
      "n": "IV",
      "d": 262265,
      "h": 34360000633,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360000633),
//--TRIMMABLE-BOUNDARY-START(38654967929),
    {
      "t": 1310721,
      "n": "Jku",
      "d": 262265,
      "h": 38654967929,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38654967929),
//--TRIMMABLE-BOUNDARY-START(42949935225),
    {
      "t": 1310721,
      "n": "Jwk",
      "d": 262265,
      "h": 42949935225,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42949935225),
//--TRIMMABLE-BOUNDARY-START(47244902521),
    {
      "t": 1310721,
      "n": "Kid",
      "d": 262265,
      "h": 47244902521,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47244902521),
//--TRIMMABLE-BOUNDARY-START(51539869817),
    {
      "t": 1310721,
      "n": "Typ",
      "d": 262265,
      "h": 51539869817,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51539869817),
//--TRIMMABLE-BOUNDARY-START(55834837113),
    {
      "t": 1310721,
      "n": "X5c",
      "d": 262265,
      "h": 55834837113,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834837113),
//--TRIMMABLE-BOUNDARY-START(60129804409),
    {
      "t": 1310721,
      "n": "X5t",
      "d": 262265,
      "h": 60129804409,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60129804409),
//--TRIMMABLE-BOUNDARY-START(64424771705),
    {
      "t": 1310721,
      "n": "X5u",
      "d": 262265,
      "h": 64424771705,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64424771705),
//--TRIMMABLE-BOUNDARY-START(68719739001),
    {
      "t": 1310721,
      "n": "Zip",
      "d": 262265,
      "h": 68719739001,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68719739001),
//--TRIMMABLE-BOUNDARY-START(30065033337),
    {
      "t": 1310721,
      "n": "Epk",
      "d": 262265,
      "h": 30065033337,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065033337),
//--TRIMMABLE-BOUNDARY-START(12885164153),
    {
      "t": 1310721,
      "n": "Apu",
      "d": 262265,
      "h": 12885164153,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885164153),
//--TRIMMABLE-BOUNDARY-START(17180131449),
    {
      "t": 1310721,
      "n": "Apv",
      "d": 262265,
      "h": 17180131449,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180131449)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229561),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262265,
      "h": 4295229561,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229561)
  ],
  "h": 262265
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtHeaderParameterNames`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262265)
        
        
        //--TRIMMABLE-BOUNDARY-START(393337)
        $asm.$str("$sitj.System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames", ($self) => class JwtRegisteredClaimNames extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12885295225)
            /*string*/ static Act = null;
            //--TRIMMABLE-BOUNDARY-END(12885295225)
            
            //--TRIMMABLE-BOUNDARY-START(17180262521)
            /*string*/ static Actort = null;
            //--TRIMMABLE-BOUNDARY-END(17180262521)
            
            //--TRIMMABLE-BOUNDARY-START(8590327929)
            /*string*/ static Acr = null;
            //--TRIMMABLE-BOUNDARY-END(8590327929)
            
            //--TRIMMABLE-BOUNDARY-START(25770197113)
            /*string*/ static Alg = null;
            //--TRIMMABLE-BOUNDARY-END(25770197113)
            
            //--TRIMMABLE-BOUNDARY-START(30065164409)
            /*string*/ static Amr = null;
            //--TRIMMABLE-BOUNDARY-END(30065164409)
            
            //--TRIMMABLE-BOUNDARY-START(21475229817)
            /*string*/ static Address = null;
            //--TRIMMABLE-BOUNDARY-END(21475229817)
            
            //--TRIMMABLE-BOUNDARY-START(34360131705)
            /*string*/ static AtHash = null;
            //--TRIMMABLE-BOUNDARY-END(34360131705)
            
            //--TRIMMABLE-BOUNDARY-START(38655099001)
            /*string*/ static Aud = null;
            //--TRIMMABLE-BOUNDARY-END(38655099001)
            
            //--TRIMMABLE-BOUNDARY-START(42950066297)
            /*string*/ static AuthTime = null;
            //--TRIMMABLE-BOUNDARY-END(42950066297)
            
            //--TRIMMABLE-BOUNDARY-START(47245033593)
            /*string*/ static Azp = null;
            //--TRIMMABLE-BOUNDARY-END(47245033593)
            
            //--TRIMMABLE-BOUNDARY-START(51540000889)
            /*string*/ static Birthdate = null;
            //--TRIMMABLE-BOUNDARY-END(51540000889)
            
            //--TRIMMABLE-BOUNDARY-START(55834968185)
            /*string*/ static CHash = null;
            //--TRIMMABLE-BOUNDARY-END(55834968185)
            
            //--TRIMMABLE-BOUNDARY-START(60129935481)
            /*string*/ static Email = null;
            //--TRIMMABLE-BOUNDARY-END(60129935481)
            
            //--TRIMMABLE-BOUNDARY-START(64424902777)
            /*string*/ static EmailVerified = null;
            //--TRIMMABLE-BOUNDARY-END(64424902777)
            
            //--TRIMMABLE-BOUNDARY-START(68719870073)
            /*string*/ static Exp = null;
            //--TRIMMABLE-BOUNDARY-END(68719870073)
            
            //--TRIMMABLE-BOUNDARY-START(77309804665)
            /*string*/ static Gender = null;
            //--TRIMMABLE-BOUNDARY-END(77309804665)
            
            //--TRIMMABLE-BOUNDARY-START(73014837369)
            /*string*/ static FamilyName = null;
            //--TRIMMABLE-BOUNDARY-END(73014837369)
            
            //--TRIMMABLE-BOUNDARY-START(81604771961)
            /*string*/ static GivenName = null;
            //--TRIMMABLE-BOUNDARY-END(81604771961)
            
            //--TRIMMABLE-BOUNDARY-START(85899739257)
            /*string*/ static Iat = null;
            //--TRIMMABLE-BOUNDARY-END(85899739257)
            
            //--TRIMMABLE-BOUNDARY-START(90194706553)
            /*string*/ static Iss = null;
            //--TRIMMABLE-BOUNDARY-END(90194706553)
            
            //--TRIMMABLE-BOUNDARY-START(94489673849)
            /*string*/ static Jti = null;
            //--TRIMMABLE-BOUNDARY-END(94489673849)
            
            //--TRIMMABLE-BOUNDARY-START(98784641145)
            /*string*/ static Locale = null;
            //--TRIMMABLE-BOUNDARY-END(98784641145)
            
            //--TRIMMABLE-BOUNDARY-START(103079608441)
            /*string*/ static MiddleName = null;
            //--TRIMMABLE-BOUNDARY-END(103079608441)
            
            //--TRIMMABLE-BOUNDARY-START(107374575737)
            /*string*/ static Name = null;
            //--TRIMMABLE-BOUNDARY-END(107374575737)
            
            //--TRIMMABLE-BOUNDARY-START(111669543033)
            /*string*/ static NameId = null;
            //--TRIMMABLE-BOUNDARY-END(111669543033)
            
            //--TRIMMABLE-BOUNDARY-START(120259477625)
            /*string*/ static Nickname = null;
            //--TRIMMABLE-BOUNDARY-END(120259477625)
            
            //--TRIMMABLE-BOUNDARY-START(124554444921)
            /*string*/ static Nonce = null;
            //--TRIMMABLE-BOUNDARY-END(124554444921)
            
            //--TRIMMABLE-BOUNDARY-START(115964510329)
            /*string*/ static Nbf = null;
            //--TRIMMABLE-BOUNDARY-END(115964510329)
            
            //--TRIMMABLE-BOUNDARY-START(128849412217)
            /*string*/ static PhoneNumber = null;
            //--TRIMMABLE-BOUNDARY-END(128849412217)
            
            //--TRIMMABLE-BOUNDARY-START(133144379513)
            /*string*/ static PhoneNumberVerified = null;
            //--TRIMMABLE-BOUNDARY-END(133144379513)
            
            //--TRIMMABLE-BOUNDARY-START(137439346809)
            /*string*/ static Picture = null;
            //--TRIMMABLE-BOUNDARY-END(137439346809)
            
            //--TRIMMABLE-BOUNDARY-START(146029281401)
            /*string*/ static Prn = null;
            //--TRIMMABLE-BOUNDARY-END(146029281401)
            
            //--TRIMMABLE-BOUNDARY-START(141734314105)
            /*string*/ static PreferredUsername = null;
            //--TRIMMABLE-BOUNDARY-END(141734314105)
            
            //--TRIMMABLE-BOUNDARY-START(150324248697)
            /*string*/ static Profile = null;
            //--TRIMMABLE-BOUNDARY-END(150324248697)
            
            //--TRIMMABLE-BOUNDARY-START(154619215993)
            /*string*/ static Sid = null;
            //--TRIMMABLE-BOUNDARY-END(154619215993)
            
            //--TRIMMABLE-BOUNDARY-START(158914183289)
            /*string*/ static Sub = null;
            //--TRIMMABLE-BOUNDARY-END(158914183289)
            
            //--TRIMMABLE-BOUNDARY-START(163209150585)
            /*string*/ static Typ = null;
            //--TRIMMABLE-BOUNDARY-END(163209150585)
            
            //--TRIMMABLE-BOUNDARY-START(167504117881)
            /*string*/ static UniqueName = null;
            //--TRIMMABLE-BOUNDARY-END(167504117881)
            
            //--TRIMMABLE-BOUNDARY-START(171799085177)
            /*string*/ static UpdatedAt = null;
            //--TRIMMABLE-BOUNDARY-END(171799085177)
            
            //--TRIMMABLE-BOUNDARY-START(176094052473)
            /*string*/ static Website = null;
            //--TRIMMABLE-BOUNDARY-END(176094052473)
            
            //--TRIMMABLE-BOUNDARY-START(180389019769)
            /*string*/ static ZoneInfo = null;
            //--TRIMMABLE-BOUNDARY-END(180389019769)
            
            //--TRIMMABLE-BOUNDARY-START(4295360633)
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360633)
            
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885295225)
                    this.Act = "act";
                    //--TRIMMABLE-BOUNDARY-END(12885295225)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180262521)
                    this.Actort = "actort";
                    //--TRIMMABLE-BOUNDARY-END(17180262521)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590327929)
                    this.Acr = "acr";
                    //--TRIMMABLE-BOUNDARY-END(8590327929)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770197113)
                    this.Alg = "alg";
                    //--TRIMMABLE-BOUNDARY-END(25770197113)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065164409)
                    this.Amr = "amr";
                    //--TRIMMABLE-BOUNDARY-END(30065164409)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475229817)
                    this.Address = "address";
                    //--TRIMMABLE-BOUNDARY-END(21475229817)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360131705)
                    this.AtHash = "at_hash";
                    //--TRIMMABLE-BOUNDARY-END(34360131705)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655099001)
                    this.Aud = "aud";
                    //--TRIMMABLE-BOUNDARY-END(38655099001)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950066297)
                    this.AuthTime = "auth_time";
                    //--TRIMMABLE-BOUNDARY-END(42950066297)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245033593)
                    this.Azp = "azp";
                    //--TRIMMABLE-BOUNDARY-END(47245033593)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540000889)
                    this.Birthdate = "birthdate";
                    //--TRIMMABLE-BOUNDARY-END(51540000889)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834968185)
                    this.CHash = "c_hash";
                    //--TRIMMABLE-BOUNDARY-END(55834968185)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60129935481)
                    this.Email = "email";
                    //--TRIMMABLE-BOUNDARY-END(60129935481)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424902777)
                    this.EmailVerified = "email_verified";
                    //--TRIMMABLE-BOUNDARY-END(64424902777)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68719870073)
                    this.Exp = "exp";
                    //--TRIMMABLE-BOUNDARY-END(68719870073)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77309804665)
                    this.Gender = "gender";
                    //--TRIMMABLE-BOUNDARY-END(77309804665)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73014837369)
                    this.FamilyName = "family_name";
                    //--TRIMMABLE-BOUNDARY-END(73014837369)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81604771961)
                    this.GivenName = "given_name";
                    //--TRIMMABLE-BOUNDARY-END(81604771961)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899739257)
                    this.Iat = "iat";
                    //--TRIMMABLE-BOUNDARY-END(85899739257)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90194706553)
                    this.Iss = "iss";
                    //--TRIMMABLE-BOUNDARY-END(90194706553)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94489673849)
                    this.Jti = "jti";
                    //--TRIMMABLE-BOUNDARY-END(94489673849)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784641145)
                    this.Locale = "locale";
                    //--TRIMMABLE-BOUNDARY-END(98784641145)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079608441)
                    this.MiddleName = "middle_name";
                    //--TRIMMABLE-BOUNDARY-END(103079608441)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374575737)
                    this.Name = "name";
                    //--TRIMMABLE-BOUNDARY-END(107374575737)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669543033)
                    this.NameId = "nameid";
                    //--TRIMMABLE-BOUNDARY-END(111669543033)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259477625)
                    this.Nickname = "nickname";
                    //--TRIMMABLE-BOUNDARY-END(120259477625)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554444921)
                    this.Nonce = "nonce";
                    //--TRIMMABLE-BOUNDARY-END(124554444921)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964510329)
                    this.Nbf = "nbf";
                    //--TRIMMABLE-BOUNDARY-END(115964510329)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849412217)
                    this.PhoneNumber = "phone_number";
                    //--TRIMMABLE-BOUNDARY-END(128849412217)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144379513)
                    this.PhoneNumberVerified = "phone_number_verified";
                    //--TRIMMABLE-BOUNDARY-END(133144379513)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439346809)
                    this.Picture = "picture";
                    //--TRIMMABLE-BOUNDARY-END(137439346809)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029281401)
                    this.Prn = "prn";
                    //--TRIMMABLE-BOUNDARY-END(146029281401)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734314105)
                    this.PreferredUsername = "preferred_username";
                    //--TRIMMABLE-BOUNDARY-END(141734314105)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324248697)
                    this.Profile = "profile";
                    //--TRIMMABLE-BOUNDARY-END(150324248697)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154619215993)
                    this.Sid = "sid";
                    //--TRIMMABLE-BOUNDARY-END(154619215993)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158914183289)
                    this.Sub = "sub";
                    //--TRIMMABLE-BOUNDARY-END(158914183289)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163209150585)
                    this.Typ = "typ";
                    //--TRIMMABLE-BOUNDARY-END(163209150585)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167504117881)
                    this.UniqueName = "unique_name";
                    //--TRIMMABLE-BOUNDARY-END(167504117881)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171799085177)
                    this.UpdatedAt = "updated_at";
                    //--TRIMMABLE-BOUNDARY-END(171799085177)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176094052473)
                    this.Website = "website";
                    //--TRIMMABLE-BOUNDARY-END(176094052473)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180389019769)
                    this.ZoneInfo = "zoneinfo";
                    //--TRIMMABLE-BOUNDARY-END(180389019769)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 393337;
            static $z = 0;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885295225),
    {
      "t": 1310721,
      "n": "Act",
      "d": 393337,
      "h": 12885295225,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885295225),
//--TRIMMABLE-BOUNDARY-START(17180262521),
    {
      "t": 1310721,
      "n": "Actort",
      "d": 393337,
      "h": 17180262521,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180262521),
//--TRIMMABLE-BOUNDARY-START(8590327929),
    {
      "t": 1310721,
      "n": "Acr",
      "d": 393337,
      "h": 8590327929,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590327929),
//--TRIMMABLE-BOUNDARY-START(25770197113),
    {
      "t": 1310721,
      "n": "Alg",
      "d": 393337,
      "h": 25770197113,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770197113),
//--TRIMMABLE-BOUNDARY-START(30065164409),
    {
      "t": 1310721,
      "n": "Amr",
      "d": 393337,
      "h": 30065164409,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065164409),
//--TRIMMABLE-BOUNDARY-START(21475229817),
    {
      "t": 1310721,
      "n": "Address",
      "d": 393337,
      "h": 21475229817,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475229817),
//--TRIMMABLE-BOUNDARY-START(34360131705),
    {
      "t": 1310721,
      "n": "AtHash",
      "d": 393337,
      "h": 34360131705,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360131705),
//--TRIMMABLE-BOUNDARY-START(38655099001),
    {
      "t": 1310721,
      "n": "Aud",
      "d": 393337,
      "h": 38655099001,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655099001),
//--TRIMMABLE-BOUNDARY-START(42950066297),
    {
      "t": 1310721,
      "n": "AuthTime",
      "d": 393337,
      "h": 42950066297,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950066297),
//--TRIMMABLE-BOUNDARY-START(47245033593),
    {
      "t": 1310721,
      "n": "Azp",
      "d": 393337,
      "h": 47245033593,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245033593),
//--TRIMMABLE-BOUNDARY-START(51540000889),
    {
      "t": 1310721,
      "n": "Birthdate",
      "d": 393337,
      "h": 51540000889,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540000889),
//--TRIMMABLE-BOUNDARY-START(55834968185),
    {
      "t": 1310721,
      "n": "CHash",
      "d": 393337,
      "h": 55834968185,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834968185),
//--TRIMMABLE-BOUNDARY-START(60129935481),
    {
      "t": 1310721,
      "n": "Email",
      "d": 393337,
      "h": 60129935481,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60129935481),
//--TRIMMABLE-BOUNDARY-START(64424902777),
    {
      "t": 1310721,
      "n": "EmailVerified",
      "d": 393337,
      "h": 64424902777,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64424902777),
//--TRIMMABLE-BOUNDARY-START(68719870073),
    {
      "t": 1310721,
      "n": "Exp",
      "d": 393337,
      "h": 68719870073,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68719870073),
//--TRIMMABLE-BOUNDARY-START(77309804665),
    {
      "t": 1310721,
      "n": "Gender",
      "d": 393337,
      "h": 77309804665,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77309804665),
//--TRIMMABLE-BOUNDARY-START(73014837369),
    {
      "t": 1310721,
      "n": "FamilyName",
      "d": 393337,
      "h": 73014837369,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73014837369),
//--TRIMMABLE-BOUNDARY-START(81604771961),
    {
      "t": 1310721,
      "n": "GivenName",
      "d": 393337,
      "h": 81604771961,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81604771961),
//--TRIMMABLE-BOUNDARY-START(85899739257),
    {
      "t": 1310721,
      "n": "Iat",
      "d": 393337,
      "h": 85899739257,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899739257),
//--TRIMMABLE-BOUNDARY-START(90194706553),
    {
      "t": 1310721,
      "n": "Iss",
      "d": 393337,
      "h": 90194706553,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90194706553),
//--TRIMMABLE-BOUNDARY-START(94489673849),
    {
      "t": 1310721,
      "n": "Jti",
      "d": 393337,
      "h": 94489673849,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94489673849),
//--TRIMMABLE-BOUNDARY-START(98784641145),
    {
      "t": 1310721,
      "n": "Locale",
      "d": 393337,
      "h": 98784641145,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784641145),
//--TRIMMABLE-BOUNDARY-START(103079608441),
    {
      "t": 1310721,
      "n": "MiddleName",
      "d": 393337,
      "h": 103079608441,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103079608441),
//--TRIMMABLE-BOUNDARY-START(107374575737),
    {
      "t": 1310721,
      "n": "Name",
      "d": 393337,
      "h": 107374575737,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374575737),
//--TRIMMABLE-BOUNDARY-START(111669543033),
    {
      "t": 1310721,
      "n": "NameId",
      "d": 393337,
      "h": 111669543033,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669543033),
//--TRIMMABLE-BOUNDARY-START(120259477625),
    {
      "t": 1310721,
      "n": "Nickname",
      "d": 393337,
      "h": 120259477625,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259477625),
//--TRIMMABLE-BOUNDARY-START(124554444921),
    {
      "t": 1310721,
      "n": "Nonce",
      "d": 393337,
      "h": 124554444921,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554444921),
//--TRIMMABLE-BOUNDARY-START(115964510329),
    {
      "t": 1310721,
      "n": "Nbf",
      "d": 393337,
      "h": 115964510329,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964510329),
//--TRIMMABLE-BOUNDARY-START(128849412217),
    {
      "t": 1310721,
      "n": "PhoneNumber",
      "d": 393337,
      "h": 128849412217,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849412217),
//--TRIMMABLE-BOUNDARY-START(133144379513),
    {
      "t": 1310721,
      "n": "PhoneNumberVerified",
      "d": 393337,
      "h": 133144379513,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144379513),
//--TRIMMABLE-BOUNDARY-START(137439346809),
    {
      "t": 1310721,
      "n": "Picture",
      "d": 393337,
      "h": 137439346809,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439346809),
//--TRIMMABLE-BOUNDARY-START(146029281401),
    {
      "t": 1310721,
      "n": "Prn",
      "d": 393337,
      "h": 146029281401,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029281401),
//--TRIMMABLE-BOUNDARY-START(141734314105),
    {
      "t": 1310721,
      "n": "PreferredUsername",
      "d": 393337,
      "h": 141734314105,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734314105),
//--TRIMMABLE-BOUNDARY-START(150324248697),
    {
      "t": 1310721,
      "n": "Profile",
      "d": 393337,
      "h": 150324248697,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324248697),
//--TRIMMABLE-BOUNDARY-START(154619215993),
    {
      "t": 1310721,
      "n": "Sid",
      "d": 393337,
      "h": 154619215993,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619215993),
//--TRIMMABLE-BOUNDARY-START(158914183289),
    {
      "t": 1310721,
      "n": "Sub",
      "d": 393337,
      "h": 158914183289,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158914183289),
//--TRIMMABLE-BOUNDARY-START(163209150585),
    {
      "t": 1310721,
      "n": "Typ",
      "d": 393337,
      "h": 163209150585,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163209150585),
//--TRIMMABLE-BOUNDARY-START(167504117881),
    {
      "t": 1310721,
      "n": "UniqueName",
      "d": 393337,
      "h": 167504117881,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167504117881),
//--TRIMMABLE-BOUNDARY-START(171799085177),
    {
      "t": 1310721,
      "n": "UpdatedAt",
      "d": 393337,
      "h": 171799085177,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171799085177),
//--TRIMMABLE-BOUNDARY-START(176094052473),
    {
      "t": 1310721,
      "n": "Website",
      "d": 393337,
      "h": 176094052473,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176094052473),
//--TRIMMABLE-BOUNDARY-START(180389019769),
    {
      "t": 1310721,
      "n": "ZoneInfo",
      "d": 393337,
      "h": 180389019769,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180389019769)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360633),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393337,
      "h": 4295360633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360633)
  ],
  "h": 393337
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393337)
        
        
        //--TRIMMABLE-BOUNDARY-START(458873)
        $asm.$cls("$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken", ($self) => class JwtSecurityToken extends $.$mit.Microsoft.IdentityModel.Tokens.SecurityToken
        {
            //--TRIMMABLE-BOUNDARY-START(4295426169)
            /*JwtPayload*/ _payload = null;
            //--TRIMMABLE-BOUNDARY-END(4295426169)
            
            //--TRIMMABLE-BOUNDARY-START(60130001017)
            $ctor$3(/*string*/ jwtEncodedString)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130001017);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.System.String.IsNullOrWhiteSpace(jwtEncodedString))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtEncodedString");
                    }
                    /*string[]*/ let tokenParts = $.$$.System.String.Split$3.call(jwtEncodedString, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/*.*/ 46], [-1], null), ((5/*JwtConstants.MaxJwtSegmentCount*/ + 1) | 0));
                    if (tokenParts.length === 3/*JwtConstants.JwsSegmentCount*/)
                    {
                        if (!$.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.RegexJws.IsMatch$9(jwtEncodedString))
                        {
                            throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX12739: JWT has three segments but is not in proper JWS format."/*LogMessages.IDX12739*/));
                        }
                    }
                    else if (tokenParts.length === 5/*JwtConstants.JweSegmentCount*/)
                    {
                        if (!$.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.RegexJwe.IsMatch$9(jwtEncodedString))
                        {
                            throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX12740: JWT has five segments but is not in proper JWE format."/*LogMessages.IDX12740*/));
                        }
                    }
                    else 
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX12741: JWT must have three segments (JWS) or five segments (JWE)."/*LogMessages.IDX12741*/));
                    }
                    this.Decode(tokenParts, jwtEncodedString);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60130001017)
            
            //--TRIMMABLE-BOUNDARY-START(64424968313)
            $ctor$4(/*JwtHeader*/ header, /*JwtPayload*/ payload, /*string*/ rawHeader, /*string*/ rawPayload, /*string*/ rawSignature)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424968313);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (header === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("header");
                    }
                    if (payload === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload");
                    }
                    if ($.$$.System.String.IsNullOrWhiteSpace(rawHeader))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("rawHeader");
                    }
                    if ($.$$.System.String.IsNullOrWhiteSpace(rawPayload))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("rawPayload");
                    }
                    if ($.$$.System.String.op_Equality(rawSignature, null))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("rawSignature");
                    }
                    this.Header = header;
                    this.Payload = payload;
                    this.RawData = $.$$.System.String.Concat$10($.$$.System.ReadOnlySpan$$($.$$.System.String).op_Implicit$1([ rawHeader, ".", rawPayload, ".", rawSignature ]));
                    this.RawHeader = rawHeader;
                    this.RawPayload = rawPayload;
                    this.RawSignature = rawSignature;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64424968313)
            
            //--TRIMMABLE-BOUNDARY-START(73014902905)
            $ctor$6(/*JwtHeader*/ header, /*JwtSecurityToken*/ innerToken, /*string*/ rawHeader, /*string*/ rawEncryptedKey, /*string*/ rawInitializationVector, /*string*/ rawCiphertext, /*string*/ rawAuthenticationTag)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014902905);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (header === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("header");
                    }
                    if (innerToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("innerToken");
                    }
                    if ($.$$.System.String.op_Equality(rawEncryptedKey, null))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("rawEncryptedKey");
                    }
                    if ($.$$.System.String.IsNullOrEmpty(rawInitializationVector))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("rawInitializationVector");
                    }
                    if ($.$$.System.String.IsNullOrEmpty(rawCiphertext))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("rawCiphertext");
                    }
                    if ($.$$.System.String.IsNullOrEmpty(rawAuthenticationTag))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("rawAuthenticationTag");
                    }
                    this.Header = header;
                    this.InnerToken = innerToken;
                    this.RawData = $.$$.System.String.Join$8(".", $.$$.System.ReadOnlySpan$$($.$$.System.String).op_Implicit$1([ rawHeader, rawEncryptedKey, rawInitializationVector, rawCiphertext, rawAuthenticationTag ]));
                    this.RawHeader = rawHeader;
                    this.RawEncryptedKey = rawEncryptedKey;
                    this.RawInitializationVector = rawInitializationVector;
                    this.RawCiphertext = rawCiphertext;
                    this.RawAuthenticationTag = rawAuthenticationTag;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73014902905)
            
            //--TRIMMABLE-BOUNDARY-START(68719935609)
            $ctor$5(/*JwtHeader*/ header, /*JwtPayload*/ payload)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719935609);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (header === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("header");
                    }
                    if (payload === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("payload");
                    }
                    this.Header = header;
                    this.Payload = payload;
                    this.RawSignature = $.$$.System.String.Empty;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68719935609)
            
            //--TRIMMABLE-BOUNDARY-START(55835033721)
            $ctor$2(/*string*/ issuer, /*string*/ audience, /*IEnumerable<Claim>*/ claims, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*SigningCredentials*/ signingCredentials)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835033721);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(expires) && $.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(notBefore))
                    {
                        if (notBefore >= expires)
                        {
                            throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12401: Expires: '{0}' must be after NotBefore: '{1}'."/*LogMessages.IDX12401*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(expires)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(notBefore)) ], null, null))));
                        }
                    }
                    this.Payload = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload().$ctor$15(issuer, audience, claims, notBefore?.Clone() ?? null, expires?.Clone() ?? null);
                    this.Header = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader().$ctor$21(signingCredentials);
                    this.RawSignature = $.$$.System.String.Empty;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835033721)
            
            //--TRIMMABLE-BOUNDARY-START(77309870201)
            /*string */ get Actor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259543161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.Actort;
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(77309870201)
            
            //--TRIMMABLE-BOUNDARY-START(81604837497)
            /*IEnumerable<string> */ get Audiences()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849477753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.Aud;
                }
                return new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(81604837497)
            
            //--TRIMMABLE-BOUNDARY-START(85899804793)
            /*IEnumerable<Claim> */ get Claims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439412345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.Claims;
                }
                return new ($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim))().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(85899804793)
            
            //--TRIMMABLE-BOUNDARY-START(103079673977)
            /*string */ get EncodedHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029346937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Header.Base64UrlEncode();
            }
            //--TRIMMABLE-BOUNDARY-END(103079673977)
            
            //--TRIMMABLE-BOUNDARY-START(107374641273)
            /*string */ get EncodedPayload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619281529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.Base64UrlEncode();
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(107374641273)
            
            //--TRIMMABLE-BOUNDARY-START(347892809849)
            /*JwtHeader*/ Header = null;
            //--TRIMMABLE-BOUNDARY-END(347892809849)
            
            //--TRIMMABLE-BOUNDARY-START(352187777145)
            /*string */ get Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389085305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.Jti;
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(352187777145)
            
            //--TRIMMABLE-BOUNDARY-START(365072679033)
            /*string */ get Issuer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158889081);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.Iss;
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(365072679033)
            
            //--TRIMMABLE-BOUNDARY-START(369367646329)
            /*JwtPayload */ get Payload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748823673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.InnerToken !== null)
                {
                    return this.InnerToken.Payload;
                }
                return this._payload;
            }
            /*JwtPayload */ set Payload(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433792155769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._payload = value;
            }
            //--TRIMMABLE-BOUNDARY-END(369367646329)
            
            //--TRIMMABLE-BOUNDARY-START(356482744441)
            /*JwtSecurityToken*/ InnerToken = null;
            //--TRIMMABLE-BOUNDARY-END(356482744441)
            
            //--TRIMMABLE-BOUNDARY-START(373662613625)
            /*string*/ RawAuthenticationTag = null;
            //--TRIMMABLE-BOUNDARY-END(373662613625)
            
            //--TRIMMABLE-BOUNDARY-START(377957580921)
            /*string*/ RawCiphertext = null;
            //--TRIMMABLE-BOUNDARY-END(377957580921)
            
            //--TRIMMABLE-BOUNDARY-START(382252548217)
            /*string*/ RawData = null;
            //--TRIMMABLE-BOUNDARY-END(382252548217)
            
            //--TRIMMABLE-BOUNDARY-START(386547515513)
            /*string*/ RawEncryptedKey = null;
            //--TRIMMABLE-BOUNDARY-END(386547515513)
            
            //--TRIMMABLE-BOUNDARY-START(395137450105)
            /*string*/ RawInitializationVector = null;
            //--TRIMMABLE-BOUNDARY-END(395137450105)
            
            //--TRIMMABLE-BOUNDARY-START(390842482809)
            /*string*/ RawHeader = null;
            //--TRIMMABLE-BOUNDARY-END(390842482809)
            
            //--TRIMMABLE-BOUNDARY-START(399432417401)
            /*string*/ RawPayload = null;
            //--TRIMMABLE-BOUNDARY-END(399432417401)
            
            //--TRIMMABLE-BOUNDARY-START(403727384697)
            /*string*/ RawSignature = null;
            //--TRIMMABLE-BOUNDARY-END(403727384697)
            
            //--TRIMMABLE-BOUNDARY-START(408022351993)
            /*SecurityKey */ get SecurityKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058235001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(408022351993)
            
            //--TRIMMABLE-BOUNDARY-START(515396534393)
            /*string */ get SignatureAlgorithm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648169593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Header.Alg;
            }
            //--TRIMMABLE-BOUNDARY-END(515396534393)
            
            //--TRIMMABLE-BOUNDARY-START(519691501689)
            /*SigningCredentials */ get SigningCredentials()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238104185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Header.SigningCredentials;
            }
            //--TRIMMABLE-BOUNDARY-END(519691501689)
            
            //--TRIMMABLE-BOUNDARY-START(111669608569)
            /*EncryptingCredentials */ get EncryptingCredentials()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209216121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Header.EncryptingCredentials;
            }
            //--TRIMMABLE-BOUNDARY-END(111669608569)
            
            //--TRIMMABLE-BOUNDARY-START(523986468985)
            /*SecurityKey*/ SigningKey = null;
            //--TRIMMABLE-BOUNDARY-END(523986468985)
            
            //--TRIMMABLE-BOUNDARY-START(528281436281)
            /*string */ get Subject()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326417973369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.Sub;
                }
                return $.$$.System.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(528281436281)
            
            //--TRIMMABLE-BOUNDARY-START(541166338169)
            /*DateTime */ get ValidFrom()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335007907961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.ValidFrom;
                }
                return $.$$.System.DateTime.MinValue;
            }
            //--TRIMMABLE-BOUNDARY-END(541166338169)
            
            //--TRIMMABLE-BOUNDARY-START(545461305465)
            /*DateTime */ get ValidTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597842553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.ValidTo;
                }
                return $.$$.System.DateTime.MinValue;
            }
            //--TRIMMABLE-BOUNDARY-END(545461305465)
            
            //--TRIMMABLE-BOUNDARY-START(360777711737)
            /*DateTime */ get IssuedAt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568954489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.IssuedAt;
                }
                return $.$$.System.DateTime.MinValue;
            }
            //--TRIMMABLE-BOUNDARY-END(360777711737)
            
            //--TRIMMABLE-BOUNDARY-START(532576403577)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532576403577);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Header.SerializeToJson() + "." + this.Payload.SerializeToJson();
                }
                else 
                {
                    return this.Header.SerializeToJson() + ".";
                }
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(532576403577)
            
            //--TRIMMABLE-BOUNDARY-START(536871370873)
            /*string */ UnsafeToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(536871370873);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.RawData;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(536871370873)
            
            //--TRIMMABLE-BOUNDARY-START(90194772089)
            /*void */ Decode(/*string[]*/ tokenParts, /*string*/ rawData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194772089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    this.Header = $.$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader.Base64UrlDeserialize($.$$.System.Array.$ReadT1.call(tokenParts, 0));
                }
                catch(ex)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$11($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12729: Unable to decode the header '{0}' as Base64Url encoded string."/*LogMessages.IDX12729*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$$.System.Array.$ReadT1.call(tokenParts, 0) ], null, null)), ex));
                }
                if (tokenParts.length === 5/*JwtConstants.JweSegmentCount*/)
                {
                    this.DecodeJwe(tokenParts);
                }
                else 
                {
                    this.DecodeJws($.$$.System.Array.$ReadT1.call(tokenParts, 1));
                    this.RawHeader = $.$$.System.Array.$ReadT1.call(tokenParts, 0);
                    this.RawPayload = $.$$.System.Array.$ReadT1.call(tokenParts, 1);
                    this.RawSignature = $.$$.System.Array.$ReadT1.call(tokenParts, 2);
                }
                this.RawData = rawData;
            }
            //--TRIMMABLE-BOUNDARY-END(90194772089)
            
            //--TRIMMABLE-BOUNDARY-START(98784706681)
            /*void */ DecodeJws(/*string*/ payload)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784706681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.op_Inequality(this.Header.Cty, null) && $.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12738: Header.Cty != null, assuming JWS. Cty: '{0}'."/*LogMessages.IDX12738*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ this.Header.Cty ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                }
                try
                {
                    this.Payload = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoding.Decode$5($.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload, payload, 0, payload.length, new ($.$$.System.Func$$$$($.$typeArray($.$$.System.Byte), $.$$.System.Int32, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload))().$ctor($.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.CreatePayload));
                }
                catch(ex)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$11($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12723: Unable to decode the payload '{0}' as Base64Url encoded string."/*LogMessages.IDX12723*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ payload ], null, null)), ex));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784706681)
            
            //--TRIMMABLE-BOUNDARY-START(94489739385)
            /*void */ DecodeJwe(/*string[]*/ tokenParts)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.RawHeader = $.$$.System.Array.$ReadT1.call(tokenParts, 0);
                this.RawEncryptedKey = $.$$.System.Array.$ReadT1.call(tokenParts, 1);
                this.RawInitializationVector = $.$$.System.Array.$ReadT1.call(tokenParts, 2);
                this.RawCiphertext = $.$$.System.Array.$ReadT1.call(tokenParts, 3);
                this.RawAuthenticationTag = $.$$.System.Array.$ReadT1.call(tokenParts, 4);
            }
            //--TRIMMABLE-BOUNDARY-END(94489739385)
            
            static $h = 458873;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 13762679,
  "p": [
//--TRIMMABLE-BOUNDARY-START(77309870201),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259543161,
        "f": 50331649
      },
      "n": "Actor",
      "d": 458873,
      "h": 77309870201,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309870201),
//--TRIMMABLE-BOUNDARY-START(81604837497),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849477753,
        "f": 50331649
      },
      "n": "Audiences",
      "d": 458873,
      "h": 81604837497,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604837497),
//--TRIMMABLE-BOUNDARY-START(85899804793),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439412345,
        "f": 50331649
      },
      "n": "Claims",
      "d": 458873,
      "h": 85899804793,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899804793),
//--TRIMMABLE-BOUNDARY-START(103079673977),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029346937,
        "f": 50331777
      },
      "n": "EncodedHeader",
      "d": 458873,
      "h": 103079673977,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(103079673977),
//--TRIMMABLE-BOUNDARY-START(107374641273),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619281529,
        "f": 50331777
      },
      "n": "EncodedPayload",
      "d": 458873,
      "h": 107374641273,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(107374641273),
//--TRIMMABLE-BOUNDARY-START(347892809849),
    {
      "p": 196729,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799150713,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 416612286585,
        "f": 83886088
      },
      "n": "Header",
      "d": 458873,
      "h": 347892809849,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(347892809849),
//--TRIMMABLE-BOUNDARY-START(352187777145),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389085305,
        "f": 50364417
      },
      "n": "Id",
      "d": 458873,
      "h": 352187777145,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(352187777145),
//--TRIMMABLE-BOUNDARY-START(365072679033),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206158889081,
        "f": 50364417
      },
      "n": "Issuer",
      "d": 458873,
      "h": 365072679033,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(365072679033),
//--TRIMMABLE-BOUNDARY-START(369367646329),
    {
      "p": 327801,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214748823673,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 433792155769,
        "f": 83886088
      },
      "n": "Payload",
      "d": 458873,
      "h": 369367646329,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(369367646329),
//--TRIMMABLE-BOUNDARY-START(356482744441),
    {
      "p": 458873,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979019897,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 425202221177,
        "f": 83886088
      },
      "n": "InnerToken",
      "d": 458873,
      "h": 356482744441,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(356482744441),
//--TRIMMABLE-BOUNDARY-START(373662613625),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223338758265,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 442382090361,
        "f": 83886082
      },
      "n": "RawAuthenticationTag",
      "d": 458873,
      "h": 373662613625,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(373662613625),
//--TRIMMABLE-BOUNDARY-START(377957580921),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231928692857,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 450972024953,
        "f": 83886082
      },
      "n": "RawCiphertext",
      "d": 458873,
      "h": 377957580921,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(377957580921),
//--TRIMMABLE-BOUNDARY-START(382252548217),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240518627449,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 459561959545,
        "f": 83886082
      },
      "n": "RawData",
      "d": 458873,
      "h": 382252548217,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(382252548217),
//--TRIMMABLE-BOUNDARY-START(386547515513),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249108562041,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 468151894137,
        "f": 83886082
      },
      "n": "RawEncryptedKey",
      "d": 458873,
      "h": 386547515513,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(386547515513),
//--TRIMMABLE-BOUNDARY-START(395137450105),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266288431225,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 485331763321,
        "f": 83886082
      },
      "n": "RawInitializationVector",
      "d": 458873,
      "h": 395137450105,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(395137450105),
//--TRIMMABLE-BOUNDARY-START(390842482809),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257698496633,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 476741828729,
        "f": 83886088
      },
      "n": "RawHeader",
      "d": 458873,
      "h": 390842482809,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(390842482809),
//--TRIMMABLE-BOUNDARY-START(399432417401),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274878365817,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 493921697913,
        "f": 83886088
      },
      "n": "RawPayload",
      "d": 458873,
      "h": 399432417401,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(399432417401),
//--TRIMMABLE-BOUNDARY-START(403727384697),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283468300409,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 502511632505,
        "f": 83886088
      },
      "n": "RawSignature",
      "d": 458873,
      "h": 403727384697,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(403727384697),
//--TRIMMABLE-BOUNDARY-START(408022351993),
    {
      "p": 13631607,
      "g": {
        "r": 0,
        "d": 0,
        "h": 292058235001,
        "f": 50364417
      },
      "n": "SecurityKey",
      "d": 458873,
      "h": 408022351993,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(408022351993),
//--TRIMMABLE-BOUNDARY-START(515396534393),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 300648169593,
        "f": 50331649
      },
      "n": "SignatureAlgorithm",
      "d": 458873,
      "h": 515396534393,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(515396534393),
//--TRIMMABLE-BOUNDARY-START(519691501689),
    {
      "p": 15925367,
      "g": {
        "r": 0,
        "d": 0,
        "h": 309238104185,
        "f": 50331649
      },
      "n": "SigningCredentials",
      "d": 458873,
      "h": 519691501689,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(519691501689),
//--TRIMMABLE-BOUNDARY-START(111669608569),
    {
      "p": 3932279,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209216121,
        "f": 50331649
      },
      "n": "EncryptingCredentials",
      "d": 458873,
      "h": 111669608569,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669608569),
//--TRIMMABLE-BOUNDARY-START(523986468985),
    {
      "p": 13631607,
      "g": {
        "r": 0,
        "d": 0,
        "h": 317828038777,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 511101567097,
        "f": 83918849
      },
      "n": "SigningKey",
      "d": 458873,
      "h": 523986468985,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(523986468985),
//--TRIMMABLE-BOUNDARY-START(528281436281),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 326417973369,
        "f": 50331649
      },
      "n": "Subject",
      "d": 458873,
      "h": 528281436281,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(528281436281),
//--TRIMMABLE-BOUNDARY-START(541166338169),
    {
      "p": 65273857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 335007907961,
        "f": 50364417
      },
      "n": "ValidFrom",
      "d": 458873,
      "h": 541166338169,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(541166338169),
//--TRIMMABLE-BOUNDARY-START(545461305465),
    {
      "p": 65273857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 343597842553,
        "f": 50364417
      },
      "n": "ValidTo",
      "d": 458873,
      "h": 545461305465,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(545461305465),
//--TRIMMABLE-BOUNDARY-START(360777711737),
    {
      "p": 65273857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197568954489,
        "f": 50331777
      },
      "n": "IssuedAt",
      "d": 458873,
      "h": 360777711737,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(360777711737)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(532576403577),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 458873,
      "h": 532576403577,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(532576403577),
//--TRIMMABLE-BOUNDARY-START(536871370873),
    {
      "r": 1310721,
      "n": "UnsafeToString",
      "d": 458873,
      "h": 536871370873,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(536871370873),
//--TRIMMABLE-BOUNDARY-START(90194772089),
    {
      "r": 65537,
      "p": [
        {
          "n": "tokenParts",
          "p": $.$typeArray($.$$.System.String).$h
        },
        {
          "n": "rawData",
          "p": 1310721
        }
      ],
      "n": "Decode",
      "d": 458873,
      "h": 90194772089,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(90194772089),
//--TRIMMABLE-BOUNDARY-START(98784706681),
    {
      "r": 65537,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        }
      ],
      "n": "DecodeJws",
      "d": 458873,
      "h": 98784706681,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98784706681),
//--TRIMMABLE-BOUNDARY-START(94489739385),
    {
      "r": 65537,
      "p": [
        {
          "n": "tokenParts",
          "p": $.$typeArray($.$$.System.String).$h
        }
      ],
      "n": "DecodeJwe",
      "d": 458873,
      "h": 94489739385,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94489739385)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295426169),
    {
      "t": 327801,
      "n": "_payload",
      "d": 458873,
      "h": 4295426169,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426169)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(60130001017),
    {
      "p": [
        {
          "n": "jwtEncodedString",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458873,
      "h": 60130001017,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130001017),
//--TRIMMABLE-BOUNDARY-START(64424968313),
    {
      "p": [
        {
          "n": "header",
          "p": 196729
        },
        {
          "n": "payload",
          "p": 327801
        },
        {
          "n": "rawHeader",
          "p": 1310721
        },
        {
          "n": "rawPayload",
          "p": 1310721
        },
        {
          "n": "rawSignature",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 458873,
      "h": 64424968313,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424968313),
//--TRIMMABLE-BOUNDARY-START(73014902905),
    {
      "p": [
        {
          "n": "header",
          "p": 196729
        },
        {
          "n": "innerToken",
          "p": 458873
        },
        {
          "n": "rawHeader",
          "p": 1310721
        },
        {
          "n": "rawEncryptedKey",
          "p": 1310721
        },
        {
          "n": "rawInitializationVector",
          "p": 1310721
        },
        {
          "n": "rawCiphertext",
          "p": 1310721
        },
        {
          "n": "rawAuthenticationTag",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 458873,
      "h": 73014902905,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014902905),
//--TRIMMABLE-BOUNDARY-START(68719935609),
    {
      "p": [
        {
          "n": "header",
          "p": 196729
        },
        {
          "n": "payload",
          "p": 327801
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 458873,
      "h": 68719935609,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719935609),
//--TRIMMABLE-BOUNDARY-START(55835033721),
    {
      "p": [
        {
          "n": "issuer",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "audience",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,
          "f": 65
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.System.DateTime).$h,
          "f": 65
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.System.DateTime).$h,
          "f": 65
        },
        {
          "n": "signingCredentials",
          "p": 15925367,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458873,
      "h": 55835033721,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835033721)
  ],
  "i": [196726
  ],
  "h": 458873
}; }
            static get $b() { return $.$mit.Microsoft.IdentityModel.Tokens.SecurityToken; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mil.Microsoft.IdentityModel.Logging.ISafeLogSecurityArtifact ]; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtSecurityToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458873)
        
        
        //--TRIMMABLE-BOUNDARY-START(589945)
        $asm.$cls("$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler", ($self) => class JwtSecurityTokenHandler extends $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenHandler
        {
            //--TRIMMABLE-BOUNDARY-START(655481)
            static $_CertMatcher;
            static get CertMatcher()
            {
                let $cls = $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler;
                return $cls.$_CertMatcher ??= $asm.$ncls("$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.CertMatcher", ($self) => class CertMatcher extends $.$$.System.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*bool*/ Invoke(/**/ cert)
                    {
                        return this.$nativeFunction.call(this.$target, cert);
                    }
                    static $h = 655481;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 98959361,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180524665),
    {
      "r": 262145,
      "p": [
        {
          "n": "cert",
          "p": 28180510
        }
      ],
      "n": "Invoke",
      "d": 655481,
      "h": 17180524665,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180524665),
//--TRIMMABLE-BOUNDARY-START(8590590073),
    {
      "r": 89784321,
      "p": [
        {
          "n": "cert",
          "p": 28180510
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 655481,
      "h": 8590590073,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590590073),
//--TRIMMABLE-BOUNDARY-START(12885557369),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": 89784321
        }
      ],
      "n": "EndInvoke",
      "d": 655481,
      "h": 12885557369,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885557369)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622777),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 655481,
      "h": 4295622777,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622777)
  ],
  "i": [89980929,157483009
  ],
  "d": 589945,
  "h": 655481
}; }
                    static get $b() { return $.$$.System.MulticastDelegate; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
                    static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.CertMatcher`; }
                }, $cls, ($v) => $cls.$_CertMatcher = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655481)
            
            //--TRIMMABLE-BOUNDARY-START(8590524537)
            /*ISet<string>*/ _inboundClaimFilter = null;
            //--TRIMMABLE-BOUNDARY-END(8590524537)
            
            //--TRIMMABLE-BOUNDARY-START(12885491833)
            /*IDictionary<string, string>*/ _inboundClaimTypeMap = null;
            //--TRIMMABLE-BOUNDARY-END(12885491833)
            
            //--TRIMMABLE-BOUNDARY-START(17180459129)
            /*string*/ static _jsonClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(17180459129)
            
            //--TRIMMABLE-BOUNDARY-START(25770393721)
            /*string*/ static _namespace = null;
            //--TRIMMABLE-BOUNDARY-END(25770393721)
            
            //--TRIMMABLE-BOUNDARY-START(4295557241)
            /*string*/ static _className = null;
            //--TRIMMABLE-BOUNDARY-END(4295557241)
            
            //--TRIMMABLE-BOUNDARY-START(34360328313)
            /*IDictionary<string, string>*/ _outboundClaimTypeMap = null;
            //--TRIMMABLE-BOUNDARY-END(34360328313)
            
            //--TRIMMABLE-BOUNDARY-START(30065361017)
            /*Dictionary<string, string>*/ _outboundAlgorithmMap = null;
            //--TRIMMABLE-BOUNDARY-END(30065361017)
            
            //--TRIMMABLE-BOUNDARY-START(38655295609)
            /*string*/ static _shortClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(38655295609)
            
            //--TRIMMABLE-BOUNDARY-START(21475426425)
            /*bool*/ _mapInboundClaims = false;
            //--TRIMMABLE-BOUNDARY-END(21475426425)
            
            //--TRIMMABLE-BOUNDARY-START(386547646585)
            /*Microsoft.IdentityModel.Telemetry.ITelemetryClient*/ TelemetryClient = null;
            //--TRIMMABLE-BOUNDARY-END(386547646585)
            
            //--TRIMMABLE-BOUNDARY-START(146029478009)
            /*IDictionary<string, string>*/ static DefaultInboundClaimTypeMap = null;
            //--TRIMMABLE-BOUNDARY-END(146029478009)
            
            //--TRIMMABLE-BOUNDARY-START(150324445305)
            /*bool*/ static DefaultMapInboundClaims = true;
            //--TRIMMABLE-BOUNDARY-END(150324445305)
            
            //--TRIMMABLE-BOUNDARY-START(158914379897)
            /*IDictionary<string, string>*/ static DefaultOutboundClaimTypeMap = null;
            //--TRIMMABLE-BOUNDARY-END(158914379897)
            
            //--TRIMMABLE-BOUNDARY-START(141734510713)
            /*ISet<string>*/ static DefaultInboundClaimFilter = null;
            //--TRIMMABLE-BOUNDARY-END(141734510713)
            
            //--TRIMMABLE-BOUNDARY-START(154619412601)
            /*IDictionary<string, string>*/ static DefaultOutboundAlgorithmMap = null;
            //--TRIMMABLE-BOUNDARY-END(154619412601)
            
            //--TRIMMABLE-BOUNDARY-START(47245230201)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245230201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47245230201)
            
            //--TRIMMABLE-BOUNDARY-START(51540197497)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51540197497);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._mapInboundClaims)
                    {
                        this._inboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.DefaultInboundClaimTypeMap);
                    }
                    else 
                    {
                        this._inboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$1();
                    }
                    this._outboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.DefaultOutboundClaimTypeMap);
                    this._inboundClaimFilter = new ($.$$.System.Collections.Generic.HashSet$$($.$$.System.String))().$ctor$3($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.DefaultInboundClaimFilter);
                    this._outboundAlgorithmMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.DefaultOutboundAlgorithmMap);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51540197497)
            
            //--TRIMMABLE-BOUNDARY-START(283468431481)
            /*bool */ get MapInboundClaims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748954745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._mapInboundClaims;
            }
            /*bool */ set MapInboundClaims(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777842809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._mapInboundClaims && value && this._inboundClaimTypeMap.System$Collections$Generic$ICollection$$$Count === 0)
                {
                    this._inboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.DefaultInboundClaimTypeMap);
                }
                this._mapInboundClaims = value;
            }
            //--TRIMMABLE-BOUNDARY-END(283468431481)
            
            //--TRIMMABLE-BOUNDARY-START(274878496889)
            /*IDictionary<string, string> */ get InboundClaimTypeMap()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569085561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inboundClaimTypeMap;
            }
            /*IDictionary<string, string> */ set InboundClaimTypeMap(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597973625);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._inboundClaimTypeMap = $.$firstOf(value, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value") });
            }
            //--TRIMMABLE-BOUNDARY-END(274878496889)
            
            //--TRIMMABLE-BOUNDARY-START(292058366073)
            /*IDictionary<string, string> */ get OutboundClaimTypeMap()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928823929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._outboundClaimTypeMap;
            }
            /*IDictionary<string, string> */ set OutboundClaimTypeMap(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367777401);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value");
                }
                this._outboundClaimTypeMap = value;
            }
            //--TRIMMABLE-BOUNDARY-END(292058366073)
            
            //--TRIMMABLE-BOUNDARY-START(287763398777)
            /*IDictionary<string, string> */ get OutboundAlgorithmMap()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338889337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._outboundAlgorithmMap;
            }
            //--TRIMMABLE-BOUNDARY-END(287763398777)
            
            //--TRIMMABLE-BOUNDARY-START(270583529593)
            /*ISet<string> */ get InboundClaimFilter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979150969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inboundClaimFilter;
            }
            /*ISet<string> */ set InboundClaimFilter(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335008039033);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value");
                }
                this._inboundClaimFilter = value;
            }
            //--TRIMMABLE-BOUNDARY-END(270583529593)
            
            //--TRIMMABLE-BOUNDARY-START(382252679289)
            static /*string */ get ShortClaimTypeProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518758521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler._shortClaimType;
            }
            static /*string */ set ShortClaimTypeProperty(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377957711993);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrWhiteSpace(value))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value");
                }
                $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler._shortClaimType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(382252679289)
            
            //--TRIMMABLE-BOUNDARY-START(279173464185)
            static /*string */ get JsonClaimTypeProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159020153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler._jsonClaimType;
            }
            static /*string */ set JsonClaimTypeProperty(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187908217);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrWhiteSpace(value))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("value");
                }
                $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler._jsonClaimType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(279173464185)
            
            //--TRIMMABLE-BOUNDARY-START(60130132089)
            /*bool */ get CanValidateToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799281785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(60130132089)
            
            //--TRIMMABLE-BOUNDARY-START(64425099385)
            /*bool */ get CanWriteToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389216377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(64425099385)
            
            //--TRIMMABLE-BOUNDARY-START(390842613881)
            /*Type */ get TokenType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108693113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(390842613881)
            
            //--TRIMMABLE-BOUNDARY-START(55835164793)
            /*bool */ CanReadToken(/*string*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835164793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrWhiteSpace(token))
                {
                    return false;
                }
                if (token.length > this.MaximumTokenSizeInBytes)
                {
                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.System.Int32)) ], null, null));
                    }
                    return false;
                }
                /*int*/ let tokenPartCount = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CountJwtTokenPart(token, ((5/*JwtConstants.MaxJwtSegmentCount*/ + 1) | 0));
                if (tokenPartCount === 3/*JwtConstants.JwsSegmentCount*/)
                {
                    return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.RegexJws.IsMatch$9(token);
                }
                else if (tokenPartCount === 5/*JwtConstants.JweSegmentCount*/)
                {
                    return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.RegexJwe.IsMatch$9(token);
                }
                $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX12720: Token string does not match the token formats: JWE (header.encryptedKey.iv.ciphertext.tag) or JWS (header.payload.signature)"/*LogMessages.IDX12720*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(55835164793)
            
            //--TRIMMABLE-BOUNDARY-START(103079805049)
            /*string */ CreateEncodedJwt$3(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079805049);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (tokenDescriptor === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("tokenDescriptor");
                }
                return this.CreateJwtSecurityToken$3(tokenDescriptor).RawData;
            }
            //--TRIMMABLE-BOUNDARY-END(103079805049)
            
            //--TRIMMABLE-BOUNDARY-START(98784837753)
            /*string */ CreateEncodedJwt$2(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784837753);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CreateJwtSecurityTokenPrivate((() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                        const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Issuer = issuer;
                        $i1.Audience = audience;
                        $i1.Subject = subject;
                        $i1.NotBefore = notBefore?.Clone() ?? null;
                        $i1.Expires = expires?.Clone() ?? null;
                        $i1.IssuedAt = issuedAt?.Clone() ?? null;
                        $i1.SigningCredentials = signingCredentials;
                        return $i1;
                    })()).RawData;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784837753)
            
            //--TRIMMABLE-BOUNDARY-START(94489870457)
            /*string */ CreateEncodedJwt$1(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94489870457);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CreateJwtSecurityTokenPrivate((() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                        const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Issuer = issuer;
                        $i1.Audience = audience;
                        $i1.Subject = subject;
                        $i1.NotBefore = notBefore?.Clone() ?? null;
                        $i1.Expires = expires?.Clone() ?? null;
                        $i1.IssuedAt = issuedAt?.Clone() ?? null;
                        $i1.SigningCredentials = signingCredentials;
                        $i1.EncryptingCredentials = encryptingCredentials;
                        return $i1;
                    })()).RawData;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489870457)
            
            //--TRIMMABLE-BOUNDARY-START(90194903161)
            /*string */ CreateEncodedJwt(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ claimCollection)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194903161);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CreateJwtSecurityTokenPrivate((() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                        const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Issuer = issuer;
                        $i1.Audience = audience;
                        $i1.Subject = subject;
                        $i1.NotBefore = notBefore?.Clone() ?? null;
                        $i1.Expires = expires?.Clone() ?? null;
                        $i1.IssuedAt = issuedAt?.Clone() ?? null;
                        $i1.SigningCredentials = signingCredentials;
                        $i1.EncryptingCredentials = encryptingCredentials;
                        $i1.Claims = claimCollection;
                        return $i1;
                    })()).RawData;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194903161)
            
            //--TRIMMABLE-BOUNDARY-START(120259674233)
            /*JwtSecurityToken */ CreateJwtSecurityToken$3(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259674233);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (tokenDescriptor === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("tokenDescriptor");
                }
                return this.CreateJwtSecurityTokenPrivate(tokenDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(120259674233)
            
            //--TRIMMABLE-BOUNDARY-START(111669739641)
            /*JwtSecurityToken */ CreateJwtSecurityToken$1(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111669739641);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CreateJwtSecurityTokenPrivate((() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                        const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Issuer = issuer;
                        $i1.Audience = audience;
                        $i1.Subject = subject;
                        $i1.NotBefore = notBefore?.Clone() ?? null;
                        $i1.Expires = expires?.Clone() ?? null;
                        $i1.IssuedAt = issuedAt?.Clone() ?? null;
                        $i1.SigningCredentials = signingCredentials;
                        $i1.EncryptingCredentials = encryptingCredentials;
                        return $i1;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669739641)
            
            //--TRIMMABLE-BOUNDARY-START(107374772345)
            /*JwtSecurityToken */ CreateJwtSecurityToken(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ claimCollection)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374772345);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CreateJwtSecurityTokenPrivate((() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                        const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Issuer = issuer;
                        $i1.Audience = audience;
                        $i1.Subject = subject;
                        $i1.NotBefore = notBefore?.Clone() ?? null;
                        $i1.Expires = expires?.Clone() ?? null;
                        $i1.IssuedAt = issuedAt?.Clone() ?? null;
                        $i1.SigningCredentials = signingCredentials;
                        $i1.EncryptingCredentials = encryptingCredentials;
                        $i1.Claims = claimCollection;
                        return $i1;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374772345)
            
            //--TRIMMABLE-BOUNDARY-START(115964706937)
            /*JwtSecurityToken */ CreateJwtSecurityToken$2(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964706937);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CreateJwtSecurityTokenPrivate((() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor()
                        const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Issuer = issuer;
                        $i1.Audience = audience;
                        $i1.Subject = subject;
                        $i1.NotBefore = notBefore?.Clone() ?? null;
                        $i1.Expires = expires?.Clone() ?? null;
                        $i1.IssuedAt = issuedAt?.Clone() ?? null;
                        $i1.SigningCredentials = signingCredentials;
                        return $i1;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964706937)
            
            //--TRIMMABLE-BOUNDARY-START(133144576121)
            /*SecurityToken */ CreateToken(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144576121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (tokenDescriptor === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("tokenDescriptor");
                }
                return this.CreateJwtSecurityTokenPrivate(tokenDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(133144576121)
            
            //--TRIMMABLE-BOUNDARY-START(124554641529)
            /*JwtSecurityToken */ CreateJwtSecurityTokenPrivate(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554641529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*DateTime?*/ let expires = tokenDescriptor.Expires;
                /*DateTime?*/ let issuedAt = tokenDescriptor.IssuedAt;
                /*DateTime?*/ let notBefore = tokenDescriptor.NotBefore;
                if (this.SetDefaultTimesOnTokenCreation && (!$.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(expires) || !$.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(issuedAt) || !$.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(notBefore)))
                {
                    /*DateTime*/ let now = $.$$.System.DateTime.UtcNow;
                    if (!$.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(expires))
                    {
                        expires = $.$$.System.DateTime.op_Addition(now, $.$$.System.TimeSpan.FromMinutes$2(BigInt(this.TokenLifetimeInMinutes)));
                    }
                    if (!$.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(issuedAt))
                    {
                        issuedAt = now;
                    }
                    if (!$.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(notBefore))
                    {
                        notBefore = now;
                    }
                }
                /*string*/ let issuer = tokenDescriptor.Issuer;
                /*ClaimsIdentity*/ let subject = tokenDescriptor.Subject;
                /*IDictionary<string, object>*/ let claimCollection = tokenDescriptor.Claims;
                /*JwtPayload*/ let payload = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload().$ctor$16(issuer, tokenDescriptor.Audience, tokenDescriptor.Audiences, (subject === null ? null : this.OutboundClaimTypeTransform$1(subject.Claims)), (claimCollection === null ? null : this.OutboundClaimTypeTransform(claimCollection)), notBefore?.Clone() ?? null, expires?.Clone() ?? null, issuedAt?.Clone() ?? null);
                /*SigningCredentials*/ let signingCredentials = tokenDescriptor.SigningCredentials;
                /*string*/ let tokenType = tokenDescriptor.TokenType;
                /*JwtHeader*/ let header = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader().$ctor$17(signingCredentials, this.OutboundAlgorithmMap, tokenType, tokenDescriptor.AdditionalInnerHeaderClaims, tokenDescriptor.IncludeKeyIdInHeader);
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX12721: Creating JwtSecurityToken: Issuer: '{0}', Audience: '{1}'"/*LogMessages.IDX12721*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(issuer ?? "null"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Object.ToString.call(payload.Aud) ?? "null") ], null, null));
                }
                if ((subject?.Actor ?? null) !== null)
                {
                    payload.AddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$8("actort"/*JwtRegisteredClaimNames.Actort*/, this.CreateActorValue(subject.Actor)));
                }
                /*string*/ let rawHeader = header.Base64UrlEncode();
                /*string*/ let rawPayload = payload.Base64UrlEncode();
                /*string*/ let rawSignature = $.$$.System.String.Empty;
                if (signingCredentials !== null)
                {
                    /*string*/ let message = $.$$.System.String.Concat$12(rawHeader, ".", rawPayload);
                    rawSignature = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CreateEncodedSignature$2(message, signingCredentials);
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX12722: Creating security token from the header: '{0}', payload: '{1}'."/*LogMessages.IDX12722*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ rawHeader, rawPayload ], null, null));
                }
                /*EncryptingCredentials*/ let encryptingCredentials = tokenDescriptor.EncryptingCredentials;
                if (encryptingCredentials !== null)
                {
                    return this.EncryptToken(new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$4(header, payload, rawHeader, rawPayload, rawSignature), encryptingCredentials, tokenType, tokenDescriptor.AdditionalHeaderClaims);
                }
                return new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$4(header, payload, rawHeader, rawPayload, rawSignature);
            }
            //--TRIMMABLE-BOUNDARY-END(124554641529)
            
            //--TRIMMABLE-BOUNDARY-START(163209347193)
            /*JwtSecurityToken */ EncryptToken(/*JwtSecurityToken*/ innerJwt, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ tokenType, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209347193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (encryptingCredentials === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials");
                }
                /*var*/ let cryptoProviderFactory = encryptingCredentials.CryptoProviderFactory ?? encryptingCredentials.Key.CryptoProviderFactory;
                if (cryptoProviderFactory === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14("IDX10620: Unable to obtain a CryptoProviderFactory, both EncryptingCredentials.CryptoProviderFactory and EncryptingCredentials.Key.CryptoProviderFactory are null."/*TokenLogMessages.IDX10620*/));
                }
                /*byte[]*/ let wrappedKey;
                /*SecurityKey*/ let securityKey = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetSecurityKey(encryptingCredentials, cryptoProviderFactory, additionalHeaderClaims, $.$ref(() => wrappedKey, ($v) => wrappedKey = $v, $.$typeArray($.$$.System.Byte)));
                let encryptionProvider = null;
                try
                {
                    encryptionProvider = cryptoProviderFactory.CreateAuthenticatedEncryptionProvider(securityKey, encryptingCredentials.Enc);
                    if (encryptionProvider === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14("IDX12730: Failed to create the token encryption provider."/*LogMessages.IDX12730*/));
                    }
                    try
                    {
                        /*var*/ let header = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader().$ctor$13(encryptingCredentials, this.OutboundAlgorithmMap, tokenType, additionalHeaderClaims);
                        /*var*/ let encodedHeader = header.Base64UrlEncode();
                        /*AuthenticatedEncryptionResult*/ let encryptionResult = encryptionProvider.Encrypt$1($.$$.System.Text.Encoding.UTF8.GetBytes$8(innerJwt.RawData), $.$$.System.Text.Encoding.ASCII.GetBytes$8(encodedHeader));
                        return $.$$.System.String.Equals$5.call("dir"/*JwtConstants.DirectKeyUseAlg*/, encryptingCredentials.Alg) ? new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$6(header, innerJwt, encodedHeader, $.$$.System.String.Empty, $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.IV), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.Ciphertext), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.AuthenticationTag)) : new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$6(header, innerJwt, encodedHeader, $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(wrappedKey), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.IV), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.Ciphertext), $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(encryptionResult.AuthenticationTag));
                    }
                    catch(ex)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$13($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10616: Encryption failed. EncryptionProvider failed for: Algorithm: '{0}', SecurityKey: '{1}'. See inner exception."/*TokenLogMessages.IDX10616*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Enc), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(encryptingCredentials.Key.KeyId) ], null, null)), ex));
                    }
                }
                finally
                {
                    encryptionProvider?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209347193)
            
            //--TRIMMABLE-BOUNDARY-START(300648300665)
            /*IEnumerable<Claim> */ OutboundClaimTypeTransform$1(/*IEnumerable<Claim>*/ claims)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    var $en3 = claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var claim = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            /*string*/ let type = null;
                            if (this._outboundClaimTypeMap.System$Collections$Generic$IDictionary$$$$TryGetValue(claim.Type, $.$ref(() => type, ($v) => type = $v, $.$$.System.String), [$.$$.System.String, $.$$.System.String]))
                            {
                                yield new $.$ssc.System.Security.Claims.Claim().$ctor$4(type, claim.Value, claim.ValueType, claim.Issuer, claim.OriginalIssuer, claim.Subject);
                            }
                            else 
                            {
                                yield claim;
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(300648300665)
            
            //--TRIMMABLE-BOUNDARY-START(296353333369)
            /*Dictionary<string, object> */ OutboundClaimTypeTransform(/*IDictionary<string, object>*/ claimCollection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353333369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let claims = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object))().$ctor$1();
                var $en2 = claimCollection.System$Collections$Generic$IDictionary$$$$Keys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claimType = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*string*/ let type;
                        if (this._outboundClaimTypeMap.System$Collections$Generic$IDictionary$$$$TryGetValue(claimType, $.$ref(() => type, ($v) => type = $v, $.$$.System.String), [$.$$.System.String, $.$$.System.String]))
                        {
                            claims.set_Item(type, claimCollection.System$Collections$Generic$IDictionary$$$$get_Item(claimType, [$.$$.System.String, $.$$.System.Object]));
                        }
                        else 
                        {
                            claims.set_Item(claimType, claimCollection.System$Collections$Generic$IDictionary$$$$get_Item(claimType, [$.$$.System.String, $.$$.System.Object]));
                        }
                    }
                }
                return claims;
            }
            //--TRIMMABLE-BOUNDARY-END(296353333369)
            
            //--TRIMMABLE-BOUNDARY-START(304943267961)
            /*JwtSecurityToken */ ReadJwtToken(/*string*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943267961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrEmpty(token))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("token");
                }
                if (token.length > this.MaximumTokenSizeInBytes)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.System.Int32)) ], null, null))));
                }
                if (!this.CanReadToken(token))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX12709: CanReadToken() returned false. JWT is not well formed.\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX12709*/));
                }
                /*var*/ let jwtToken = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$2(null, null, null, null, null, null);
                jwtToken.Decode($.$$.System.String.Split$1.call(token, /*.*/ 46, 0), token);
                return jwtToken;
            }
            //--TRIMMABLE-BOUNDARY-END(304943267961)
            
            //--TRIMMABLE-BOUNDARY-START(309238235257)
            /*SecurityToken */ ReadToken(/*string*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238235257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadJwtToken(token);
            }
            //--TRIMMABLE-BOUNDARY-END(309238235257)
            
            //--TRIMMABLE-BOUNDARY-START(313533202553)
            /*SecurityToken */ ReadToken$1(/*XmlReader*/ reader, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533202553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(313533202553)
            
            //--TRIMMABLE-BOUNDARY-START(442382221433)
            /*ClaimsPrincipal */ ValidateToken(/*string*/ token, /*TokenValidationParameters*/ validationParameters, /*out SecurityToken*/ validatedToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442382221433);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.String.IsNullOrWhiteSpace(token))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("token");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                if (token.length > this.MaximumTokenSizeInBytes)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.System.Int32)) ], null, null))));
                }
                /*int*/ let tokenPartCount = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CountJwtTokenPart(token, ((5/*JwtConstants.MaxJwtSegmentCount*/ + 1) | 0));
                if (tokenPartCount !== 3/*JwtConstants.JwsSegmentCount*/ && tokenPartCount !== 5/*JwtConstants.JweSegmentCount*/)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenMalformedException().$ctor$22("IDX12741: JWT must have three segments (JWS) or five segments (JWE)."/*LogMessages.IDX12741*/));
                }
                if (tokenPartCount === 5/*JwtConstants.JweSegmentCount*/)
                {
                    /*var*/ let jwtToken = this.ReadJwtToken(token);
                    /*var*/ let decryptedJwt = this.DecryptToken(jwtToken, validationParameters);
                    return this.ValidateToken$2(decryptedJwt, jwtToken, validationParameters, validatedToken);
                }
                else 
                {
                    return this.ValidateToken$2(token, null, validationParameters, validatedToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(442382221433)
            
            //--TRIMMABLE-BOUNDARY-START(446677188729)
            /*ClaimsPrincipal */ ValidateToken$2(/*string*/ token, /*JwtSecurityToken*/ outerToken, /*TokenValidationParameters*/ validationParameters, /*out SecurityToken*/ signatureValidatedToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446677188729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*BaseConfiguration*/ let currentConfiguration = null;
                if (validationParameters.ConfigurationManager !== null)
                {
                    try
                    {
                        currentConfiguration = validationParameters.ConfigurationManager.GetBaseConfigurationAsync($.$$.System.Threading.CancellationToken.None).ConfigureAwait$2(false).GetAwaiter().GetResult();
                    }
                    catch(ex)
                    {
                        if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                        {
                            $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogWarning($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10261: Unable to retrieve configuration from authority: '{0}'. \nProceeding with token validation in case the relevant properties have been set manually on the TokenValidationParameters. Exception caught: \n {1}. See https://aka.ms/validate-using-configuration-manager for additional information."/*TokenLogMessages.IDX10261*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(validationParameters.ConfigurationManager.MetadataAddress), $.$$.System.Exception.ToString.call(ex) ], null, null)), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                        }
                    }
                }
                /*ExceptionDispatchInfo*/ let exceptionThrown;
                /*ClaimsPrincipal*/ let claimsPrincipal = outerToken !== null ? this.ValidateJWE(token, outerToken, validationParameters, currentConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo)) : this.ValidateJWS(token, validationParameters, currentConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo));
                if (validationParameters.ConfigurationManager !== null)
                {
                    if (claimsPrincipal !== null)
                    {
                        if (currentConfiguration !== null)
                        {
                            validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                        }
                        return claimsPrincipal;
                    }
                    else if ($.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.IsRecoverableException(exceptionThrown.SourceException, (currentConfiguration !== null && currentConfiguration.TokenDecryptionKeys.System$Collections$Generic$ICollection$$$Count > 0)))
                    {
                        if (currentConfiguration !== null)
                        {
                            this.TelemetryClient.Microsoft$IdentityModel$Telemetry$ITelemetryClient$IncrementConfigurationRefreshRequestCounter$2(validationParameters.ConfigurationManager.MetadataAddress, "LastKnownGood"/*TelemetryConstants.Protocols.Lkg*/, "Unknown"/*TelemetryConstants.Protocols.ConfigurationSourceUnknown*/);
                            validationParameters.ConfigurationManager.RequestRefresh();
                            validationParameters.RefreshBeforeValidation = true;
                            /*var*/ let lastConfig = currentConfiguration;
                            currentConfiguration = validationParameters.ConfigurationManager.GetBaseConfigurationAsync($.$$.System.Threading.CancellationToken.None).ConfigureAwait$2(false).GetAwaiter().GetResult();
                            if (lastConfig !== currentConfiguration)
                            {
                                claimsPrincipal = outerToken !== null ? this.ValidateJWE(token, outerToken, validationParameters, currentConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo)) : this.ValidateJWS(token, validationParameters, currentConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo));
                                if (claimsPrincipal !== null)
                                {
                                    validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                                    return claimsPrincipal;
                                }
                            }
                        }
                        if (validationParameters.ConfigurationManager.UseLastKnownGoodConfiguration)
                        {
                            validationParameters.RefreshBeforeValidation = false;
                            validationParameters.ValidateWithLKG = true;
                            /*var*/ let recoverableException = exceptionThrown.SourceException;
                            /*string*/ let kid = outerToken !== null ? outerToken.Header.Kid : ($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.ValidateSignatureUsingDelegates(token, validationParameters, null) ?? this.GetJwtSecurityTokenFromToken(token, validationParameters)).Header.Kid;
                            let $i5 = 0;
                            let $arr5 = validationParameters.ConfigurationManager.GetValidLkgConfigurations();
                            while ($i5 < $arr5.length)
                            {
                                let lkgConfiguration = $arr5[$i5++];
                                if (!$.$$.System.Object.Equals$1.call(lkgConfiguration, currentConfiguration) && $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.IsRecoverableConfiguration(kid, currentConfiguration, lkgConfiguration, recoverableException))
                                {
                                    claimsPrincipal = outerToken !== null ? this.ValidateJWE(token, outerToken, validationParameters, lkgConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo)) : this.ValidateJWS(token, validationParameters, lkgConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo));
                                    if (claimsPrincipal !== null)
                                    {
                                        return claimsPrincipal;
                                    }
                                }
                            }
                        }
                    }
                }
                if (claimsPrincipal !== null)
                {
                    return claimsPrincipal;
                }
                exceptionThrown.Throw();
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(446677188729)
            
            //--TRIMMABLE-BOUNDARY-START(408022483065)
            /*ClaimsPrincipal */ ValidateJWE(/*string*/ decryptedJwt, /*JwtSecurityToken*/ outerToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ currentConfiguration, /*out SecurityToken*/ signatureValidatedToken, /*out ExceptionDispatchInfo*/ exceptionThrown)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022483065);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                exceptionThrown.$v = null;
                try
                {
                    /*SecurityToken*/ let innerToken;
                    /*ClaimsPrincipal*/ let claimsPrincipal = this.ValidateJWS(decryptedJwt, validationParameters, currentConfiguration, $.$ref(() => innerToken, ($v) => innerToken = $v, $.$mit.Microsoft.IdentityModel.Tokens.SecurityToken), exceptionThrown);
                    outerToken.InnerToken = $.$as(innerToken, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken);
                    signatureValidatedToken.$v = exceptionThrown.$v === null ? outerToken : null;
                    return claimsPrincipal;
                }
                catch(ex)
                {
                    exceptionThrown.$v = $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(ex);
                    signatureValidatedToken.$v = null;
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(408022483065)
            
            //--TRIMMABLE-BOUNDARY-START(412317450361)
            /*ClaimsPrincipal */ ValidateJWS(/*string*/ token, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ currentConfiguration, /*out SecurityToken*/ signatureValidatedToken, /*out ExceptionDispatchInfo*/ exceptionThrown)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412317450361);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                exceptionThrown.$v = null;
                try
                {
                    /*ClaimsPrincipal*/ let claimsPrincipal;
                    if (validationParameters.SignatureValidator !== null || validationParameters.SignatureValidatorUsingConfiguration !== null)
                    {
                        signatureValidatedToken.$v = $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.ValidateSignatureUsingDelegates(token, validationParameters, currentConfiguration);
                        claimsPrincipal = this.ValidateTokenPayload($.$as(signatureValidatedToken.$v, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken), validationParameters, currentConfiguration);
                        if (currentConfiguration === null)
                        {
                            this.ValidateIssuerSecurityKey(signatureValidatedToken.$v.SigningKey, $.$as(signatureValidatedToken.$v, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken), validationParameters);
                        }
                        else 
                        {
                            $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuerSecurityKey(signatureValidatedToken.$v.SigningKey, signatureValidatedToken.$v, validationParameters, currentConfiguration);
                        }
                    }
                    else 
                    {
                        /*JwtSecurityToken*/ let jwtToken = this.GetJwtSecurityTokenFromToken(token, validationParameters);
                        if (validationParameters.ValidateSignatureLast)
                        {
                            claimsPrincipal = this.ValidateTokenPayload(jwtToken, validationParameters, currentConfiguration);
                            jwtToken = this.ValidateSignatureAndIssuerSecurityKey(token, jwtToken, validationParameters, currentConfiguration);
                            signatureValidatedToken.$v = jwtToken;
                        }
                        else 
                        {
                            signatureValidatedToken.$v = this.ValidateSignatureAndIssuerSecurityKey(token, jwtToken, validationParameters, currentConfiguration);
                            claimsPrincipal = this.ValidateTokenPayload($.$as(signatureValidatedToken.$v, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken), validationParameters, currentConfiguration);
                        }
                    }
                    return claimsPrincipal;
                }
                catch(ex)
                {
                    exceptionThrown.$v = $.$$.System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(ex);
                    signatureValidatedToken.$v = null;
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(412317450361)
            
            //--TRIMMABLE-BOUNDARY-START(438087254137)
            static /*JwtSecurityToken */ ValidateSignatureUsingDelegates(/*string*/ token, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438087254137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(validationParameters, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters") });
                if (validationParameters.SignatureValidatorUsingConfiguration !== null)
                {
                    /*var*/ let validatedJwtToken = validationParameters.SignatureValidatorUsingConfiguration.Invoke(token, validationParameters, configuration);
                    if (validatedJwtToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10505: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters returned null when validating token: '{0}'."/*TokenLogMessages.IDX10505*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    let validatedJwt;
                    if (!($.$is(validatedJwtToken, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken, { set $v(v){ validatedJwt = v; } })))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10506: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters did not return a '{0}', but returned a '{1}' when validating token: '{2}'.\nIf you are using ASP.NET Core 8 or later, see https://learn.microsoft.com/en-us/dotnet/core/compatibility/aspnet-core/8.0/securitytoken-events for more details."/*TokenLogMessages.IDX10506*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken.$type), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Object.GetType.call(validatedJwtToken)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    return validatedJwt;
                }
                else if (validationParameters.SignatureValidator !== null)
                {
                    /*var*/ let validatedJwtToken = validationParameters.SignatureValidator.Invoke(token, validationParameters);
                    if (validatedJwtToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10505: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters returned null when validating token: '{0}'."/*TokenLogMessages.IDX10505*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    let validatedJwt;
                    if (!($.$is(validatedJwtToken, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken, { set $v(v){ validatedJwt = v; } })))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10506: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters did not return a '{0}', but returned a '{1}' when validating token: '{2}'.\nIf you are using ASP.NET Core 8 or later, see https://learn.microsoft.com/en-us/dotnet/core/compatibility/aspnet-core/8.0/securitytoken-events for more details."/*TokenLogMessages.IDX10506*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken.$type), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Object.GetType.call(validatedJwtToken)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    return validatedJwt;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(438087254137)
            
            //--TRIMMABLE-BOUNDARY-START(433792286841)
            /*JwtSecurityToken */ ValidateSignatureAndIssuerSecurityKey(/*string*/ token, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433792286841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*JwtSecurityToken*/ let validatedToken = this.ValidateSignature$2(token, jwtToken, validationParameters, configuration);
                if (configuration === null)
                {
                    this.ValidateIssuerSecurityKey(jwtToken.SigningKey, jwtToken, validationParameters);
                }
                else 
                {
                    $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuerSecurityKey(jwtToken.SigningKey, jwtToken, validationParameters, configuration);
                }
                return validatedToken;
            }
            //--TRIMMABLE-BOUNDARY-END(433792286841)
            
            //--TRIMMABLE-BOUNDARY-START(261993595001)
            /*JwtSecurityToken */ GetJwtSecurityTokenFromToken(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993595001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (validationParameters.TokenReader !== null)
                {
                    /*var*/ let securityToken = validationParameters.TokenReader.Invoke(token, validationParameters);
                    if (securityToken === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10510: Token validation failed. The user defined 'Delegate' set on TokenValidationParameters.TokenReader returned null when reading token: '{0}'."/*TokenLogMessages.IDX10510*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    let jwtToken;
                    if (!($.$is(securityToken, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken, { set $v(v){ jwtToken = v; } })))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10509: Token validation failed. The user defined 'Delegate' set on TokenValidationParameters.TokenReader did not return a '{0}', but returned a '{1}' when reading token: '{2}'."/*TokenLogMessages.IDX10509*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonWebToken.$type), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Object.GetType.call(securityToken)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    return jwtToken;
                }
                else 
                {
                    return this.ReadJwtToken(token);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(261993595001)
            
            //--TRIMMABLE-BOUNDARY-START(459562090617)
            /*ClaimsPrincipal */ ValidateTokenPayload$1(/*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459562090617);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ValidateTokenPayload(jwtToken, validationParameters, null);
            }
            //--TRIMMABLE-BOUNDARY-END(459562090617)
            
            //--TRIMMABLE-BOUNDARY-START(455267123321)
            /*ClaimsPrincipal */ ValidateTokenPayload(/*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455267123321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                /*DateTime?*/ let expires = (jwtToken.Payload.Expiration === null) ? null : new ($.$$.System.Nullable$$($.$$.System.DateTime))().$ctor$3(jwtToken.ValidTo);
                /*DateTime?*/ let notBefore = (jwtToken.Payload.NotBefore === null) ? null : new ($.$$.System.Nullable$$($.$$.System.DateTime))().$ctor$3(jwtToken.ValidFrom);
                this.ValidateLifetime(notBefore?.Clone() ?? null, expires?.Clone() ?? null, jwtToken, validationParameters);
                this.ValidateAudience(jwtToken.Audiences, jwtToken, validationParameters);
                /*string*/ let issuer = configuration === null ? this.ValidateIssuer(jwtToken.Issuer, jwtToken, validationParameters) : $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuer(jwtToken.Issuer, jwtToken, validationParameters, configuration);
                this.ValidateTokenReplay(expires?.Clone() ?? null, jwtToken.RawData, validationParameters);
                if (validationParameters.ValidateActor && !$.$$.System.String.IsNullOrWhiteSpace(jwtToken.Actor))
                {
                    this.ValidateToken(jwtToken.Actor, validationParameters.ActorValidationParameters ?? validationParameters, $.$discardRef());
                }
                $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateTokenType$1(jwtToken.Header.Typ, jwtToken, validationParameters);
                /*var*/ let identity = this.CreateClaimsIdentity(jwtToken, issuer, validationParameters);
                if (validationParameters.SaveSigninToken)
                {
                    identity.BootstrapContext = jwtToken.RawData;
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX10241: Security token validated. token: '{0}'."/*TokenLogMessages.IDX10241*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ jwtToken ], null, null));
                }
                return new $.$ssc.System.Security.Claims.ClaimsPrincipal().$ctor$5(identity);
            }
            //--TRIMMABLE-BOUNDARY-END(455267123321)
            
            //--TRIMMABLE-BOUNDARY-START(85899935865)
            /*ClaimsPrincipal */ CreateClaimsPrincipalFromToken(/*JwtSecurityToken*/ jwtToken, /*string*/ issuer, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899935865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let identity = this.CreateClaimsIdentity(jwtToken, issuer, validationParameters);
                if (validationParameters.SaveSigninToken)
                {
                    identity.BootstrapContext = jwtToken.RawData;
                }
                if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                {
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX10241: Security token validated. token: '{0}'."/*TokenLogMessages.IDX10241*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ jwtToken ], null, null));
                }
                return new $.$ssc.System.Security.Claims.ClaimsPrincipal().$ctor$5(identity);
            }
            //--TRIMMABLE-BOUNDARY-END(85899935865)
            
            //--TRIMMABLE-BOUNDARY-START(468152025209)
            /*string */ WriteToken(/*SecurityToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468152025209);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (token === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("token");
                }
                /*JwtSecurityToken*/ let jwtToken = $.$as(token, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken);
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$13($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12706: '{0}' can only write SecurityTokens of type: '{1}', 'token' type is: '{2}'."/*LogMessages.IDX12706*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler"/*_className*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken.$type), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Object.GetType.call(token)) ], null, null)), "token"));
                }
                /*var*/ let encodedPayload = jwtToken.EncodedPayload;
                /*var*/ let encodedSignature = $.$$.System.String.Empty;
                /*var*/ let encodedHeader = $.$$.System.String.Empty;
                if (jwtToken.InnerToken !== null)
                {
                    if (jwtToken.SigningCredentials !== null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14("IDX12736: JwtSecurityToken.SigningCredentials is not supported when JwtSecurityToken.InnerToken is set."/*LogMessages.IDX12736*/));
                    }
                    if (jwtToken.InnerToken.Header.EncryptingCredentials !== null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14("IDX12737: EncryptingCredentials set on JwtSecurityToken.InnerToken is not supported."/*LogMessages.IDX12737*/));
                    }
                    if (jwtToken.Header.EncryptingCredentials === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenEncryptionFailedException().$ctor$14("IDX12735: If JwtSecurityToken.InnerToken != null, then JwtSecurityToken.Header.EncryptingCredentials must be set."/*LogMessages.IDX12735*/));
                    }
                    if (jwtToken.InnerToken.SigningCredentials !== null)
                    {
                        encodedSignature = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CreateEncodedSignature$2($.$$.System.String.Concat$12(jwtToken.InnerToken.EncodedHeader, ".", jwtToken.EncodedPayload), jwtToken.InnerToken.SigningCredentials);
                    }
                    return this.EncryptToken(new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$4(jwtToken.InnerToken.Header, jwtToken.InnerToken.Payload, jwtToken.InnerToken.EncodedHeader, encodedPayload, encodedSignature), jwtToken.EncryptingCredentials, jwtToken.InnerToken.Header.Typ, null).RawData;
                }
                /*var*/ let header = jwtToken.EncryptingCredentials === null ? jwtToken.Header : new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader().$ctor$21(jwtToken.SigningCredentials);
                encodedHeader = header.Base64UrlEncode();
                if (jwtToken.SigningCredentials !== null)
                {
                    encodedSignature = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.CreateEncodedSignature$2($.$$.System.String.Concat$12(encodedHeader, ".", encodedPayload), jwtToken.SigningCredentials);
                }
                if (jwtToken.EncryptingCredentials !== null)
                {
                    return this.EncryptToken(new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$4(header, jwtToken.Payload, encodedHeader, encodedPayload, encodedSignature), jwtToken.EncryptingCredentials, jwtToken.Header.Typ, null).RawData;
                }
                else 
                {
                    return $.$$.System.String.Concat$10($.$$.System.ReadOnlySpan$$($.$$.System.String).op_Implicit$1([ encodedHeader, ".", encodedPayload, ".", encodedSignature ]));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(468152025209)
            
            //--TRIMMABLE-BOUNDARY-START(317828169849)
            static /*void */ RecordSignatureValidationTelemetry(/*Microsoft.IdentityModel.Telemetry.ITelemetryClient*/ telemetryClient, /*string*/ errorType, /*SecurityToken*/ securityToken, /*string*/ algorithm, /*SecurityKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828169849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mit.Microsoft.IdentityModel.Telemetry.CryptoTelemetry.RecordSignatureValidationTelemetry)
                {
                    telemetryClient.Microsoft$IdentityModel$Telemetry$ITelemetryClient$IncrementSignatureValidationCounter(errorType, securityToken.Issuer, algorithm, key);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(317828169849)
            
            //--TRIMMABLE-BOUNDARY-START(420907384953)
            static /*bool */ ValidateSignature(/*byte[]*/ encodedBytes, /*byte[]*/ signature, /*SecurityKey*/ key, /*string*/ algorithm, /*SecurityToken*/ securityToken, /*TokenValidationParameters*/ validationParameters, /*Microsoft.IdentityModel.Telemetry.ITelemetryClient*/ telemetryClient)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420907384953);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CryptoProviderFactory*/ let cryptoProviderFactory = null;
                /*SignatureProvider*/ let signatureProvider = null;
                try
                {
                    $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateAlgorithm(algorithm, key, securityToken, validationParameters);
                }
                catch($e)
                {
                    $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "AlgorithmNotSupported"/*TelemetryConstants.SignatureValidationErrors.AlgorithmNotSupported*/, securityToken, algorithm, key);
                    throw $e;
                }
                try
                {
                    cryptoProviderFactory = validationParameters.CryptoProviderFactory ?? key.CryptoProviderFactory;
                    signatureProvider = cryptoProviderFactory.CreateForVerifying$1(key, algorithm);
                    if (signatureProvider === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10636: CryptoProviderFactory.CreateForVerifying returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10636*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(key === null ? "Null" : key.KeyId), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(algorithm) ], null, null))));
                    }
                }
                catch($e)
                {
                    $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "SignatureProviderCreationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureProviderCreationFailed*/, securityToken, algorithm, key);
                    throw $e;
                }
                try
                {
                    /*bool*/ let isValid = signatureProvider.Verify(encodedBytes, signature);
                    $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, isValid ? "None"/*TelemetryConstants.SignatureValidationErrors.None*/ : "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, securityToken, algorithm, key);
                    return isValid;
                }
                catch($e)
                {
                    $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, securityToken, algorithm, key);
                    throw $e;
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(420907384953)
            
            //--TRIMMABLE-BOUNDARY-START(425202352249)
            /*JwtSecurityToken */ ValidateSignature$1(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425202352249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*JwtSecurityToken*/ let validatedJwt = $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.ValidateSignatureUsingDelegates(token, validationParameters, null);
                /*JwtSecurityToken*/ let parsedJwtToken = this.GetJwtSecurityTokenFromToken(token, validationParameters);
                return this.ValidateSignature$2(token, validatedJwt ?? parsedJwtToken, validationParameters, null);
            }
            //--TRIMMABLE-BOUNDARY-END(425202352249)
            
            //--TRIMMABLE-BOUNDARY-START(429497319545)
            /*JwtSecurityToken */ ValidateSignature$2(/*string*/ token, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429497319545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let encodedBytes = $.$$.System.Text.Encoding.UTF8.GetBytes$8(jwtToken.RawHeader + "." + jwtToken.RawPayload);
                /*bool*/ let kidMatched = false;
                /*IEnumerable<SecurityKey>*/ let keys = null;
                if ($.$$.System.String.IsNullOrEmpty(jwtToken.RawSignature))
                {
                    if (validationParameters.RequireSignedTokens)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10504: Unable to validate signature, token does not have a signature: '{0}'."/*TokenLogMessages.IDX10504*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ jwtToken ], null, null))));
                    }
                    else 
                    {
                        return jwtToken;
                    }
                }
                if (validationParameters.IssuerSigningKeyResolverUsingConfiguration !== null)
                {
                    keys = validationParameters.IssuerSigningKeyResolverUsingConfiguration.Invoke(token, jwtToken, jwtToken.Header.Kid, validationParameters, configuration);
                }
                if (validationParameters.IssuerSigningKeyResolver !== null)
                {
                    keys = validationParameters.IssuerSigningKeyResolver.Invoke(token, jwtToken, jwtToken.Header.Kid, validationParameters);
                }
                else 
                {
                    /*var*/ let key = configuration === null ? this.ResolveIssuerSigningKey(token, jwtToken, validationParameters) : $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ResolveTokenSigningKey$1(jwtToken.Header.Kid, jwtToken.Header.X5t, validationParameters, configuration);
                    if (key !== null)
                    {
                        kidMatched = true;
                        keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.$type, [ key ], null, null);
                    }
                }
                if (keys === null && validationParameters.TryAllIssuerSigningKeys)
                {
                    keys = $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetAllSigningKeys$1(configuration, validationParameters);
                }
                /*StringBuilder*/ let exceptionStrings = null;
                /*StringBuilder*/ let keysAttempted = null;
                /*bool*/ let kidExists = !$.$$.System.String.IsNullOrEmpty(jwtToken.Header.Kid);
                /*byte[]*/ let signatureBytes;
                try
                {
                    signatureBytes = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jwtToken.RawSignature);
                }
                catch(e)
                {
                    throw new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$19("IDX10508: Signature validation failed. Signature is improperly formatted."/*TokenLogMessages.IDX10508*/, e);
                }
                if (keys !== null)
                {
                    var $en3 = keys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var key = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            try
                            {
                                if ($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.ValidateSignature(encodedBytes, signatureBytes, key, jwtToken.Header.Alg, jwtToken, validationParameters, this.TelemetryClient))
                                {
                                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogInformation("IDX10242: Security token: '{0}' has a valid signature."/*TokenLogMessages.IDX10242*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ jwtToken ], null, null));
                                    }
                                    jwtToken.SigningKey = key;
                                    return jwtToken;
                                }
                            }
                            catch(ex)
                            {
                                (exceptionStrings ??= new $.$$.System.Text.StringBuilder().$ctor$1()).AppendLine$2($.$$.System.Exception.ToString.call(ex));
                            }
                            if (key !== null)
                            {
                                (keysAttempted ??= new $.$$.System.Text.StringBuilder().$ctor$1()).Append$19($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.ToString.call(key));
                                if (kidExists && !kidMatched && $.$$.System.String.op_Inequality(key.KeyId, null))
                                {
                                    kidMatched = $.$$.System.String.Equals$4.call(jwtToken.Header.Kid, key.KeyId, $.$is(key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/);
                                }
                            }
                        }
                    }
                }
                /*var*/ let keysInTokenValidationParameters = $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetAllSigningKeys$1(null, validationParameters);
                /*var*/ let keysInConfiguration = $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetAllSigningKeys$1(configuration, null);
                /*var*/ let numKeysInTokenValidationParameters = $.$sl.System.Linq.Enumerable.Count$1($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keysInTokenValidationParameters);
                /*var*/ let numKeysInConfiguration = $.$sl.System.Linq.Enumerable.Count$1($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keysInConfiguration);
                if (kidExists)
                {
                    if (kidMatched)
                    {
                        /*JwtSecurityToken*/ let localJwtToken = jwtToken;
                        /*var*/ let isKidInTVP = $.$sl.System.Linq.Enumerable.Any($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, keysInTokenValidationParameters, new ($.$$.System.Func$$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey, $.$$.System.Boolean))().$ctor(this,  (/*x*/ x) =>
                        {
                            return $.$$.System.String.Equals$5.call(x.KeyId, localJwtToken.Header.Kid);
                        }, {
  "r": 262145,
  "p": [
    {
      "n": "x",
      "p": 13631607
    }
  ],
  "n": "",
  "d": 589945,
  "h": 0,
  "f": 17825794
}));
                        /*var*/ let keyLocation = isKidInTVP ? "TokenValidationParameters" : "Configuration";
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10511: Signature validation failed. Keys tried: '{0}'. \nNumber of keys in TokenValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'. \nMatched key was in '{3}'. \nkid: '{4}'. \nExceptions caught:\n '{5}'.\ntoken: '{6}'. See https://aka.ms/IDX10511 for details."/*TokenLogMessages.IDX10511*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keyLocation), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jwtToken.Header.Kid), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                    /*DateTime?*/ let expires = (jwtToken.Payload.Expiration === null) ? null : new ($.$$.System.Nullable$$($.$$.System.DateTime))().$ctor$3(jwtToken.ValidTo);
                    /*DateTime?*/ let notBefore = (jwtToken.Payload.NotBefore === null) ? null : new ($.$$.System.Nullable$$($.$$.System.DateTime))().$ctor$3(jwtToken.ValidFrom);
                    if (!validationParameters.ValidateSignatureLast)
                    {
                        $.$mit.Microsoft.IdentityModel.Tokens.InternalValidators.ValidateAfterSignatureFailed(jwtToken, notBefore?.Clone() ?? null, expires?.Clone() ?? null, jwtToken.Audiences, validationParameters, configuration);
                    }
                }
                if (!(keysAttempted === null))
                {
                    if (kidExists)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenSignatureKeyNotFoundException().$ctor$28($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10503: Signature validation failed. The token's kid is: '{0}', but did not match any keys in TokenValidationParameters or Configuration. Keys tried: '{1}'.\nNumber of keys in TokenValidationParameters: '{2}'. \nNumber of keys in Configuration: '{3}'.\nExceptions caught:\n '{4}'.\ntoken: '{5}'. See https://aka.ms/IDX10503 for details."/*TokenLogMessages.IDX10503*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(jwtToken.Header.Kid), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.System.Int32)), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                    else 
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenSignatureKeyNotFoundException().$ctor$28($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10517: Signature validation failed. The token's kid is missing. Keys tried: '{0}'.\nNumber of keys in TokenValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'.\nExceptions caught:\n '{3}'.\ntoken: '{4}'. See https://aka.ms/IDX10503 for details."/*TokenLogMessages.IDX10517*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.System.Int32)), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                }
                $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SigningKeyNotFound"/*TelemetryConstants.SignatureValidationErrors.SigningKeyNotFound*/, jwtToken, jwtToken.SignatureAlgorithm, null);
                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenSignatureKeyNotFoundException().$ctor$28("IDX10500: Signature validation failed. No security keys were provided to validate the signature."/*TokenLogMessages.IDX10500*/));
            }
            //--TRIMMABLE-BOUNDARY-END(429497319545)
            
            //--TRIMMABLE-BOUNDARY-START(253403660409)
            static /*IEnumerable<SecurityKey> */ GetAllDecryptionKeys(/*TokenValidationParameters*/ validationParameters)
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$$.System.Object))().$ctor$1(function*()
                {
                    if (validationParameters.TokenDecryptionKey !== null)
                    {
                        yield validationParameters.TokenDecryptionKey;
                    }
                    if (validationParameters.TokenDecryptionKeys !== null)
                    {
                        var $en4 = validationParameters.TokenDecryptionKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var key = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                yield key;
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(253403660409)
            
            //--TRIMMABLE-BOUNDARY-START(73015033977)
            /*ClaimsIdentity */ CreateClaimsIdentity(/*JwtSecurityToken*/ jwtToken, /*string*/ issuer, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015033977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                /*var*/ let actualIssuer = issuer;
                if ($.$$.System.String.IsNullOrWhiteSpace(issuer))
                {
                    if ($.$mil.Microsoft.IdentityModel.Logging.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX10244: Issuer is null or empty. Using runtime default for creating claims '{0}'."/*TokenLogMessages.IDX10244*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/) ], null, null));
                    }
                    actualIssuer = "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                }
                return this.MapInboundClaims ? this.CreateClaimsIdentityWithMapping(jwtToken, actualIssuer, validationParameters) : this.CreateClaimsIdentityWithoutMapping(jwtToken, actualIssuer, validationParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(73015033977)
            
            //--TRIMMABLE-BOUNDARY-START(77310001273)
            /*ClaimsIdentity */ CreateClaimsIdentityWithMapping(/*JwtSecurityToken*/ jwtToken, /*string*/ actualIssuer, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001273);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, actualIssuer);
                var $en2 = jwtToken.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var jwtClaim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (this._inboundClaimFilter.System$Collections$Generic$ICollection$$$Contains(jwtClaim.Type, [$.$$.System.String]))
                        {
                            continue;
                        }
                        /*string*/ let claimType;
                        /*bool*/ let wasMapped = true;
                        if (!this._inboundClaimTypeMap.System$Collections$Generic$IDictionary$$$$TryGetValue(jwtClaim.Type, $.$ref(() => claimType, ($v) => claimType = $v, $.$$.System.String), [$.$$.System.String, $.$$.System.String]))
                        {
                            claimType = jwtClaim.Type;
                            wasMapped = false;
                        }
                        if ($.$$.System.String.op_Equality(claimType, "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/))
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12710: Only a single 'Actor' is supported. Found second claim of type: '{0}', value: '{1}'"/*LogMessages.IDX12710*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtClaim.Value, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JwtSecurityToken*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken);
                                identity.Actor = this.CreateClaimsIdentity(actor, actualIssuer, validationParameters);
                            }
                        }
                        /*Claim*/ let claim = new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, actualIssuer, actualIssuer, identity);
                        if (jwtClaim.Properties.System$Collections$Generic$ICollection$$$Count > 0)
                        {
                            var $en5 = jwtClaim.Properties.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var kv = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item(kv.Key, kv.Value, [$.$$.System.String, $.$$.System.String]);
                                }
                            }
                        }
                        if (wasMapped)
                        {
                            claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item($.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.ShortClaimTypeProperty, jwtClaim.Type, [$.$$.System.String, $.$$.System.String]);
                        }
                        identity.AddClaim(claim);
                    }
                }
                return identity;
            }
            //--TRIMMABLE-BOUNDARY-END(77310001273)
            
            //--TRIMMABLE-BOUNDARY-START(81604968569)
            /*ClaimsIdentity */ CreateClaimsIdentityWithoutMapping(/*JwtSecurityToken*/ jwtToken, /*string*/ actualIssuer, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604968569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, actualIssuer);
                var $en2 = jwtToken.Claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var jwtClaim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (this._inboundClaimFilter.System$Collections$Generic$ICollection$$$Contains(jwtClaim.Type, [$.$$.System.String]))
                        {
                            continue;
                        }
                        /*string*/ let claimType = jwtClaim.Type;
                        if ($.$$.System.String.op_Equality(claimType, "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/))
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.InvalidOperationException().$ctor$12($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12710: Only a single 'Actor' is supported. Found second claim of type: '{0}', value: '{1}'"/*LogMessages.IDX12710*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsSecurityArtifact$1(jwtClaim.Value, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JwtSecurityToken*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken);
                                identity.Actor = this.CreateClaimsIdentity(actor, actualIssuer, validationParameters);
                            }
                        }
                        /*Claim*/ let claim = new $.$ssc.System.Security.Claims.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, actualIssuer, actualIssuer, identity);
                        if (jwtClaim.Properties.System$Collections$Generic$ICollection$$$Count > 0)
                        {
                            var $en5 = jwtClaim.Properties.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var kv = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    claim.Properties.System$Collections$Generic$IDictionary$$$$set_Item(kv.Key, kv.Value, [$.$$.System.String, $.$$.System.String]);
                                }
                            }
                        }
                        identity.AddClaim(claim);
                    }
                }
                return identity;
            }
            //--TRIMMABLE-BOUNDARY-END(81604968569)
            
            //--TRIMMABLE-BOUNDARY-START(68720066681)
            /*string */ CreateActorValue(/*ClaimsIdentity*/ actor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720066681);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (actor === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("actor");
                }
                if (actor.BootstrapContext !== null)
                {
                    /*string*/ let encodedJwt = $.$as(actor.BootstrapContext, $.$$.System.String);
                    if ($.$$.System.String.op_Inequality(encodedJwt, null))
                    {
                        $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX12713: Creating actor value using actor.BootstrapContext(as string)"/*LogMessages.IDX12713*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                        return encodedJwt;
                    }
                    /*JwtSecurityToken*/ let jwtToken = $.$as(actor.BootstrapContext, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken);
                    if (jwtToken !== null)
                    {
                        if ($.$$.System.String.op_Inequality(jwtToken.RawData, null))
                        {
                            $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX12714: Creating actor value using actor.BootstrapContext.rawData"/*LogMessages.IDX12714*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                            return jwtToken.RawData;
                        }
                        else 
                        {
                            $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX12715: Creating actor value by writing the JwtSecurityToken created from actor.BootstrapContext"/*LogMessages.IDX12715*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                            return this.WriteToken(jwtToken);
                        }
                    }
                    $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX12711: actor.BootstrapContext is not a string AND actor.BootstrapContext is not a JWT"/*LogMessages.IDX12711*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                }
                $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogVerbose("IDX12712: actor.BootstrapContext is null. Creating the token using actor.Claims."/*LogMessages.IDX12712*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null));
                return this.WriteToken(new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityToken().$ctor$2(null, null, actor.Claims, null, null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(68720066681)
            
            //--TRIMMABLE-BOUNDARY-START(395137581177)
            /*void */ ValidateAudience(/*IEnumerable<string>*/ audiences, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395137581177);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateAudience(audiences, jwtToken, validationParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(395137581177)
            
            //--TRIMMABLE-BOUNDARY-START(416612417657)
            /*void */ ValidateLifetime(/*DateTime?*/ notBefore, /*DateTime?*/ expires, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612417657);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateLifetime$1(notBefore?.Clone() ?? null, expires?.Clone() ?? null, jwtToken, validationParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(416612417657)
            
            //--TRIMMABLE-BOUNDARY-START(399432548473)
            /*string */ ValidateIssuer(/*string*/ issuer, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399432548473);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuer$1(issuer, jwtToken, validationParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(399432548473)
            
            //--TRIMMABLE-BOUNDARY-START(463857057913)
            /*void */ ValidateTokenReplay(/*DateTime?*/ expires, /*string*/ securityToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463857057913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateTokenReplay$1(expires?.Clone() ?? null, securityToken, validationParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(463857057913)
            
            //--TRIMMABLE-BOUNDARY-START(322123137145)
            /*SecurityKey */ ResolveIssuerSigningKey(/*string*/ token, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123137145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                }
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.ResolveTokenSigningKey$1(jwtToken.Header.Kid, jwtToken.Header.X5t, validationParameters, null);
            }
            //--TRIMMABLE-BOUNDARY-END(322123137145)
            
            //--TRIMMABLE-BOUNDARY-START(326418104441)
            /*SecurityKey */ ResolveTokenDecryptionKey(/*string*/ token, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418104441);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                if (!$.$$.System.String.IsNullOrEmpty(jwtToken.Header.Kid))
                {
                    if (validationParameters.TokenDecryptionKey !== null && $.$$.System.String.Equals$2(validationParameters.TokenDecryptionKey.KeyId, jwtToken.Header.Kid, $.$is(validationParameters.TokenDecryptionKey, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/))
                    {
                        return validationParameters.TokenDecryptionKey;
                    }
                    if (validationParameters.TokenDecryptionKeys !== null)
                    {
                        var $en4 = validationParameters.TokenDecryptionKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var key = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (key !== null && $.$$.System.String.Equals$2(key.KeyId, jwtToken.Header.Kid, $.$is(key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/))
                                {
                                    return key;
                                }
                            }
                        }
                    }
                }
                if (!$.$$.System.String.IsNullOrEmpty(jwtToken.Header.X5t))
                {
                    if (validationParameters.TokenDecryptionKey !== null)
                    {
                        if ($.$$.System.String.Equals$2(validationParameters.TokenDecryptionKey.KeyId, jwtToken.Header.X5t, $.$is(validationParameters.TokenDecryptionKey, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/))
                        {
                            return validationParameters.TokenDecryptionKey;
                        }
                        /*X509SecurityKey*/ let x509Key = $.$as(validationParameters.TokenDecryptionKey, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey);
                        if (x509Key !== null && $.$$.System.String.Equals$2(x509Key.X5t, jwtToken.Header.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            return validationParameters.TokenDecryptionKey;
                        }
                    }
                    if (validationParameters.TokenDecryptionKeys !== null)
                    {
                        var $en4 = validationParameters.TokenDecryptionKeys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var key = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (key !== null && $.$$.System.String.Equals$2(key.KeyId, jwtToken.Header.X5t, $.$is(key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/))
                                {
                                    return key;
                                }
                                /*X509SecurityKey*/ let x509Key = $.$as(key, $.$mit.Microsoft.IdentityModel.Tokens.X509SecurityKey);
                                if (x509Key !== null && $.$$.System.String.Equals$2(x509Key.X5t, jwtToken.Header.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                                {
                                    return key;
                                }
                            }
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(326418104441)
            
            //--TRIMMABLE-BOUNDARY-START(137439543417)
            /*string */ DecryptToken(/*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439543417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("validationParameters");
                }
                if ($.$$.System.String.IsNullOrEmpty(jwtToken.Header.Enc))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10612: Decryption failed. Header.Enc is null or empty, it must be specified."/*TokenLogMessages.IDX10612*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [  ], null, null))));
                }
                /*var*/ let keys = this.GetContentEncryptionKeys(jwtToken, validationParameters);
                /*var*/ let decryptionParameters = this.CreateJwtTokenDecryptionParameters(jwtToken, keys);
                return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DecryptJwtToken$1(jwtToken, validationParameters, decryptionParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(137439543417)
            
            //--TRIMMABLE-BOUNDARY-START(128849608825)
            /*JwtTokenDecryptionParameters */ CreateJwtTokenDecryptionParameters(/*JwtSecurityToken*/ jwtToken, /*IEnumerable<SecurityKey>*/ keys)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849608825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenDecryptionParameters()
                    const $t1 = $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenDecryptionParameters;
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Alg = jwtToken.Header.Alg;
                    $i1.AuthenticationTagBytes = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jwtToken.RawAuthenticationTag);
                    $i1.CipherTextBytes = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jwtToken.RawCiphertext);
                    $i1.DecompressionFunction = new ($.$$.System.Func$$$$$($.$typeArray($.$$.System.Byte), $.$$.System.String, $.$$.System.Int32, $.$$.System.String))().$ctor($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities, $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.DecompressToken);
                    $i1.Enc = jwtToken.Header.Enc;
                    $i1.EncodedToken = jwtToken.RawData;
                    $i1.HeaderAsciiBytes = $.$$.System.Text.Encoding.ASCII.GetBytes$8(jwtToken.EncodedHeader);
                    $i1.InitializationVectorBytes = $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jwtToken.RawInitializationVector);
                    $i1.MaximumDeflateSize = this.MaximumTokenSizeInBytes;
                    $i1.Keys$1 = keys;
                    $i1.Zip = jwtToken.Header.Zip;
                    return $i1;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(128849608825)
            
            //--TRIMMABLE-BOUNDARY-START(257698627705)
            /*IEnumerable<SecurityKey> */ GetContentEncryptionKeys(/*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698627705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<SecurityKey>*/ let keys = null;
                if (validationParameters.TokenDecryptionKeyResolver !== null)
                {
                    keys = validationParameters.TokenDecryptionKeyResolver.Invoke(jwtToken.RawData, jwtToken, jwtToken.Header.Kid, validationParameters);
                }
                else 
                {
                    /*var*/ let key = this.ResolveTokenDecryptionKey(jwtToken.RawData, jwtToken, validationParameters);
                    if (key !== null)
                    {
                        keys = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey.$type, [ key ], null, null);
                    }
                }
                if (keys === null)
                {
                    keys = $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.GetAllDecryptionKeys(validationParameters);
                }
                if ($.$$.System.String.Equals$5.call(jwtToken.Header.Alg, "dir"/*JwtConstants.DirectKeyUseAlg*/))
                {
                    return keys;
                }
                /*var*/ let unwrappedKeys = new ($.$$.System.Collections.Generic.List$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey))().$ctor$1();
                /*var*/ let exceptionStrings = new $.$$.System.Text.StringBuilder().$ctor$1();
                /*var*/ let keysAttempted = new $.$$.System.Text.StringBuilder().$ctor$1();
                var $en2 = keys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var key = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        try
                        {
                            if ($.$mit.Microsoft.IdentityModel.Tokens.SupportedAlgorithms.EcdsaWrapAlgorithms.System$Collections$Generic$ICollection$$$Contains(jwtToken.Header.Alg, [$.$$.System.String]))
                            {
                                /*ECDsaSecurityKey*/ let publicKey;
                                if ($.$mit.Microsoft.IdentityModel.Tokens.AppContextSwitches.UseRfcDefinitionOfEpkAndKid)
                                {
                                    /*string*/ let epk = jwtToken.Header.GetStandardClaim("epk"/*JwtHeaderParameterNames.Epk*/);
                                    publicKey = new $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey().$ctor$5(new $.$mit.Microsoft.IdentityModel.Tokens.JsonWebKey().$ctor$4(epk), false);
                                }
                                else 
                                {
                                    publicKey = $.$as(validationParameters.TokenDecryptionKey, $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey);
                                }
                                /*var*/ let ecdhKeyExchangeProvider = new $.$mit.Microsoft.IdentityModel.Tokens.EcdhKeyExchangeProvider().$ctor$1($.$as(key, $.$mit.Microsoft.IdentityModel.Tokens.ECDsaSecurityKey), publicKey, jwtToken.Header.Alg, jwtToken.Header.Enc);
                                /*string*/ let apu = jwtToken.Header.GetStandardClaim("apu"/*JwtHeaderParameterNames.Apu*/);
                                /*string*/ let apv = jwtToken.Header.GetStandardClaim("apv"/*JwtHeaderParameterNames.Apv*/);
                                /*SecurityKey*/ let kdf = ecdhKeyExchangeProvider.GenerateKdf(apu, apv);
                                /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(kdf, ecdhKeyExchangeProvider.GetEncryptionAlgorithm());
                                /*var*/ let unwrappedKey = kwp.UnwrapKey($.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jwtToken.RawEncryptedKey));
                                unwrappedKeys.Add(new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3(unwrappedKey));
                            }
                            else if (key.CryptoProviderFactory.IsSupportedAlgorithm(jwtToken.Header.Alg, key))
                            {
                                /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(key, jwtToken.Header.Alg);
                                /*var*/ let unwrappedKey = kwp.UnwrapKey($.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jwtToken.RawEncryptedKey));
                                unwrappedKeys.Add(new $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey().$ctor$3(unwrappedKey));
                            }
                        }
                        catch(ex)
                        {
                            exceptionStrings.AppendLine$2($.$$.System.Exception.ToString.call(ex));
                        }
                        keysAttempted.AppendLine$2(key.KeyId);
                    }
                }
                if (unwrappedKeys.Count > 0 || exceptionStrings.Length === 0)
                {
                    return unwrappedKeys;
                }
                else 
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenKeyWrapException().$ctor$16($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX10618: Key unwrap failed using decryption Keys: '{0}'.\nExceptions caught:\n '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10618*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Text.StringBuilder.ToString.call(keysAttempted)), exceptionStrings, jwtToken ], null, null))));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(257698627705)
            
            //--TRIMMABLE-BOUNDARY-START(266288562297)
            static /*byte[] */ GetSymmetricSecurityKey(/*SecurityKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288562297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("key");
                }
                /*SymmetricSecurityKey*/ let symmetricSecurityKey = $.$as(key, $.$mit.Microsoft.IdentityModel.Tokens.SymmetricSecurityKey);
                if (symmetricSecurityKey !== null)
                {
                    return symmetricSecurityKey.Key;
                }
                else 
                {
                    /*JsonWebKey*/ let jsonWebKey = $.$as(key, $.$mit.Microsoft.IdentityModel.Tokens.JsonWebKey);
                    if (jsonWebKey !== null && $.$$.System.String.op_Inequality(jsonWebKey.K, null))
                    {
                        return $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.DecodeBytes(jsonWebKey.K);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(266288562297)
            
            //--TRIMMABLE-BOUNDARY-START(403727515769)
            /*void */ ValidateIssuerSecurityKey(/*SecurityKey*/ key, /*JwtSecurityToken*/ securityToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403727515769);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mit.Microsoft.IdentityModel.Tokens.Validators.ValidateIssuerSecurityKey$1(key, securityToken, validationParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(403727515769)
            
            //--TRIMMABLE-BOUNDARY-START(472446992505)
            /*void */ WriteToken$1(/*XmlWriter*/ writer, /*SecurityToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472446992505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(472446992505)
            
            //--TRIMMABLE-BOUNDARY-START(450972156025)
            /*Task<TokenValidationResult> */ ValidateTokenAsync$2(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450972156025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    /*var*/ let validatedToken;
                    /*var*/ let claimsPrincipal = this.ValidateToken(token, validationParameters, $.$ref(() => validatedToken, ($v) => validatedToken = $v, $.$mit.Microsoft.IdentityModel.Tokens.SecurityToken));
                    return $.$$.System.Threading.Tasks.Task.FromResult($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, (() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                        const $t2 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.SecurityToken = validatedToken;
                        $i2.ClaimsIdentity = $.$as((claimsPrincipal?.Identity ?? null), $.$ssc.System.Security.Claims.ClaimsIdentity);
                        $i2.IsValid = true;
                        return $i2;
                    })());
                }
                catch(ex)
                {
                    return $.$$.System.Threading.Tasks.Task.FromResult($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult, (() =>
                    {
                        //new $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult()
                        const $t1 = $.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.IsValid = false;
                        $i1.Exception = ex;
                        return $i1;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(450972156025)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475426425)
                this._mapInboundClaims = $.$sitj.System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler.DefaultMapInboundClaims;
                //--TRIMMABLE-BOUNDARY-END(21475426425)
                
                //--TRIMMABLE-BOUNDARY-START(386547646585)
                this.TelemetryClient = new $.$mit.Microsoft.IdentityModel.Telemetry.TelemetryClient().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(386547646585)
                
            }
            //--TRIMMABLE-BOUNDARY-START(47245230201)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(17180459129)
                    this._jsonClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claimproperties/json_type";
                    //--TRIMMABLE-BOUNDARY-END(17180459129)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770393721)
                    this._namespace = "http://schemas.xmlsoap.org/ws/2005/05/identity/claimproperties";
                    //--TRIMMABLE-BOUNDARY-END(25770393721)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295557241)
                    this._className = "System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler";
                    //--TRIMMABLE-BOUNDARY-END(4295557241)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655295609)
                    this._shortClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claimproperties/ShortTypeName";
                    //--TRIMMABLE-BOUNDARY-END(38655295609)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029478009)
                    this.DefaultInboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.InboundClaimTypeMap);
                    //--TRIMMABLE-BOUNDARY-END(146029478009)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158914379897)
                    this.DefaultOutboundClaimTypeMap = new ($.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String))().$ctor$3($.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.OutboundClaimTypeMap);
                    //--TRIMMABLE-BOUNDARY-END(158914379897)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734510713)
                    this.DefaultInboundClaimFilter = $.$mij.Microsoft.IdentityModel.JsonWebTokens.ClaimTypeMapping.InboundClaimFilter;
                    //--TRIMMABLE-BOUNDARY-END(141734510713)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154619412601)
                    this.DefaultOutboundAlgorithmMap = (() =>
                    {
                        //new $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String)()
                        const $t1 = $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha256"/*SecurityAlgorithms.EcdsaSha256Signature*/, "ES256"/*SecurityAlgorithms.EcdsaSha256*/);
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha384"/*SecurityAlgorithms.EcdsaSha384Signature*/, "ES384"/*SecurityAlgorithms.EcdsaSha384*/);
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha512"/*SecurityAlgorithms.EcdsaSha512Signature*/, "ES512"/*SecurityAlgorithms.EcdsaSha512*/);
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#hmac-sha256"/*SecurityAlgorithms.HmacSha256Signature*/, "HS256"/*SecurityAlgorithms.HmacSha256*/);
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#hmac-sha384"/*SecurityAlgorithms.HmacSha384Signature*/, "HS384"/*SecurityAlgorithms.HmacSha384*/);
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#hmac-sha512"/*SecurityAlgorithms.HmacSha512Signature*/, "HS512"/*SecurityAlgorithms.HmacSha512*/);
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"/*SecurityAlgorithms.RsaSha256Signature*/, "RS256"/*SecurityAlgorithms.RsaSha256*/);
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#rsa-sha384"/*SecurityAlgorithms.RsaSha384Signature*/, "RS384"/*SecurityAlgorithms.RsaSha384*/);
                        $i1.Add("http://www.w3.org/2001/04/xmldsig-more#rsa-sha512"/*SecurityAlgorithms.RsaSha512Signature*/, "RS512"/*SecurityAlgorithms.RsaSha512*/);
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(154619412601)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245230201)
            
            static $h = 589945;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 14418039,
  "p": [
//--TRIMMABLE-BOUNDARY-START(283468431481),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214748954745,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 360777842809,
        "f": 83886081
      },
      "n": "MapInboundClaims",
      "d": 589945,
      "h": 283468431481,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(283468431481),
//--TRIMMABLE-BOUNDARY-START(274878496889),
    {
      "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197569085561,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 343597973625,
        "f": 83886081
      },
      "n": "InboundClaimTypeMap",
      "d": 589945,
      "h": 274878496889,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(274878496889),
//--TRIMMABLE-BOUNDARY-START(292058366073),
    {
      "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231928823929,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 369367777401,
        "f": 83886081
      },
      "n": "OutboundClaimTypeMap",
      "d": 589945,
      "h": 292058366073,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(292058366073),
//--TRIMMABLE-BOUNDARY-START(287763398777),
    {
      "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223338889337,
        "f": 50331649
      },
      "n": "OutboundAlgorithmMap",
      "d": 589945,
      "h": 287763398777,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(287763398777),
//--TRIMMABLE-BOUNDARY-START(270583529593),
    {
      "p": $.$$.System.Collections.Generic.ISet$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979150969,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 335008039033,
        "f": 83886081
      },
      "n": "InboundClaimFilter",
      "d": 589945,
      "h": 270583529593,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270583529593),
//--TRIMMABLE-BOUNDARY-START(382252679289),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240518758521,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 377957711993,
        "f": 83886113
      },
      "n": "ShortClaimTypeProperty",
      "d": 589945,
      "h": 382252679289,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(382252679289),
//--TRIMMABLE-BOUNDARY-START(279173464185),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206159020153,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 352187908217,
        "f": 83886113
      },
      "n": "JsonClaimTypeProperty",
      "d": 589945,
      "h": 279173464185,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(279173464185),
//--TRIMMABLE-BOUNDARY-START(60130132089),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799281785,
        "f": 50364417
      },
      "n": "CanValidateToken",
      "d": 589945,
      "h": 60130132089,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60130132089),
//--TRIMMABLE-BOUNDARY-START(64425099385),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389216377,
        "f": 50364417
      },
      "n": "CanWriteToken",
      "d": 589945,
      "h": 64425099385,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(64425099385),
//--TRIMMABLE-BOUNDARY-START(390842613881),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249108693113,
        "f": 50364417
      },
      "n": "TokenType",
      "d": 589945,
      "h": 390842613881,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(390842613881)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(55835164793),
    {
      "r": 262145,
      "p": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "n": "CanReadToken",
      "d": 589945,
      "h": 55835164793,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835164793),
//--TRIMMABLE-BOUNDARY-START(103079805049),
    {
      "r": 1310721,
      "p": [
        {
          "n": "tokenDescriptor",
          "p": 14090359
        }
      ],
      "n": "CreateEncodedJwt",
      "o": "@$3",
      "d": 589945,
      "h": 103079805049,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(103079805049),
//--TRIMMABLE-BOUNDARY-START(98784837753),
    {
      "r": 1310721,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "subject",
          "p": 262213
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        }
      ],
      "n": "CreateEncodedJwt",
      "o": "@$2",
      "d": 589945,
      "h": 98784837753,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(98784837753),
//--TRIMMABLE-BOUNDARY-START(94489870457),
    {
      "r": 1310721,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "subject",
          "p": 262213
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        }
      ],
      "n": "CreateEncodedJwt",
      "o": "@$1",
      "d": 589945,
      "h": 94489870457,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(94489870457),
//--TRIMMABLE-BOUNDARY-START(90194903161),
    {
      "r": 1310721,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "subject",
          "p": 262213
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "claimCollection",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": "CreateEncodedJwt",
      "d": 589945,
      "h": 90194903161,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(90194903161),
//--TRIMMABLE-BOUNDARY-START(120259674233),
    {
      "r": 458873,
      "p": [
        {
          "n": "tokenDescriptor",
          "p": 14090359
        }
      ],
      "n": "CreateJwtSecurityToken",
      "o": "@$3",
      "d": 589945,
      "h": 120259674233,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(120259674233),
//--TRIMMABLE-BOUNDARY-START(111669739641),
    {
      "r": 458873,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "subject",
          "p": 262213
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        }
      ],
      "n": "CreateJwtSecurityToken",
      "o": "@$1",
      "d": 589945,
      "h": 111669739641,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(111669739641),
//--TRIMMABLE-BOUNDARY-START(107374772345),
    {
      "r": 458873,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "subject",
          "p": 262213
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "claimCollection",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": "CreateJwtSecurityToken",
      "d": 589945,
      "h": 107374772345,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(107374772345),
//--TRIMMABLE-BOUNDARY-START(115964706937),
    {
      "r": 458873,
      "p": [
        {
          "n": "issuer",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "audience",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "subject",
          "p": 262213,
          "f": 65
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.System.DateTime).$h,
          "f": 65
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.System.DateTime).$h,
          "f": 65
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.System.DateTime).$h,
          "f": 65
        },
        {
          "n": "signingCredentials",
          "p": 15925367,
          "f": 65
        }
      ],
      "n": "CreateJwtSecurityToken",
      "o": "@$2",
      "d": 589945,
      "h": 115964706937,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(115964706937),
//--TRIMMABLE-BOUNDARY-START(133144576121),
    {
      "r": 13762679,
      "p": [
        {
          "n": "tokenDescriptor",
          "p": 14090359
        }
      ],
      "n": "CreateToken",
      "d": 589945,
      "h": 133144576121,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(133144576121),
//--TRIMMABLE-BOUNDARY-START(124554641529),
    {
      "r": 458873,
      "p": [
        {
          "n": "tokenDescriptor",
          "p": 14090359
        }
      ],
      "n": "CreateJwtSecurityTokenPrivate",
      "d": 589945,
      "h": 124554641529,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124554641529),
//--TRIMMABLE-BOUNDARY-START(163209347193),
    {
      "r": 458873,
      "p": [
        {
          "n": "innerJwt",
          "p": 458873
        },
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "tokenType",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": "EncryptToken",
      "d": 589945,
      "h": 163209347193,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(163209347193),
//--TRIMMABLE-BOUNDARY-START(300648300665),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,
      "p": [
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h
        }
      ],
      "n": "OutboundClaimTypeTransform",
      "o": "@$1",
      "d": 589945,
      "h": 300648300665,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(300648300665),
//--TRIMMABLE-BOUNDARY-START(296353333369),
    {
      "r": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object).$h,
      "p": [
        {
          "n": "claimCollection",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": "OutboundClaimTypeTransform",
      "d": 589945,
      "h": 296353333369,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(296353333369),
//--TRIMMABLE-BOUNDARY-START(304943267961),
    {
      "r": 458873,
      "p": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "n": "ReadJwtToken",
      "d": 589945,
      "h": 304943267961,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(304943267961),
//--TRIMMABLE-BOUNDARY-START(309238235257),
    {
      "r": 13762679,
      "p": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "n": "ReadToken",
      "d": 589945,
      "h": 309238235257,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(309238235257),
//--TRIMMABLE-BOUNDARY-START(313533202553),
    {
      "r": 13762679,
      "p": [
        {
          "n": "reader",
          "p": 53346307
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ReadToken",
      "o": "@$1",
      "d": 589945,
      "h": 313533202553,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(313533202553),
//--TRIMMABLE-BOUNDARY-START(442382221433),
    {
      "r": 393285,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "validatedToken",
          "p": 13762679,
          "f": 2
        }
      ],
      "n": "ValidateToken",
      "d": 589945,
      "h": 442382221433,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(442382221433),
//--TRIMMABLE-BOUNDARY-START(446677188729),
    {
      "r": 393285,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "outerToken",
          "p": 458873
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "signatureValidatedToken",
          "p": 13762679,
          "f": 2
        }
      ],
      "n": "ValidateToken",
      "o": "@$2",
      "d": 589945,
      "h": 446677188729,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(446677188729),
//--TRIMMABLE-BOUNDARY-START(408022483065),
    {
      "r": 393285,
      "p": [
        {
          "n": "decryptedJwt",
          "p": 1310721
        },
        {
          "n": "outerToken",
          "p": 458873
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "currentConfiguration",
          "p": 1638519
        },
        {
          "n": "signatureValidatedToken",
          "p": 13762679,
          "f": 2
        },
        {
          "n": "exceptionThrown",
          "p": 135004161,
          "f": 2
        }
      ],
      "n": "ValidateJWE",
      "d": 589945,
      "h": 408022483065,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(408022483065),
//--TRIMMABLE-BOUNDARY-START(412317450361),
    {
      "r": 393285,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "currentConfiguration",
          "p": 1638519
        },
        {
          "n": "signatureValidatedToken",
          "p": 13762679,
          "f": 2
        },
        {
          "n": "exceptionThrown",
          "p": 135004161,
          "f": 2
        }
      ],
      "n": "ValidateJWS",
      "d": 589945,
      "h": 412317450361,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(412317450361),
//--TRIMMABLE-BOUNDARY-START(438087254137),
    {
      "r": 458873,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "configuration",
          "p": 1638519
        }
      ],
      "n": "ValidateSignatureUsingDelegates",
      "d": 589945,
      "h": 438087254137,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(438087254137),
//--TRIMMABLE-BOUNDARY-START(433792286841),
    {
      "r": 458873,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "jwtToken",
          "p": 458873
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "configuration",
          "p": 1638519
        }
      ],
      "n": "ValidateSignatureAndIssuerSecurityKey",
      "d": 589945,
      "h": 433792286841,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(433792286841),
//--TRIMMABLE-BOUNDARY-START(261993595001),
    {
      "r": 458873,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "GetJwtSecurityTokenFromToken",
      "d": 589945,
      "h": 261993595001,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(261993595001),
//--TRIMMABLE-BOUNDARY-START(459562090617),
    {
      "r": 393285,
      "p": [
        {
          "n": "jwtToken",
          "p": 458873
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ValidateTokenPayload",
      "o": "@$1",
      "d": 589945,
      "h": 459562090617,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(459562090617),
//--TRIMMABLE-BOUNDARY-START(455267123321),
    {
      "r": 393285,
      "p": [
        {
          "n": "jwtToken",
          "p": 458873
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "configuration",
          "p": 1638519
        }
      ],
      "n": "ValidateTokenPayload",
      "d": 589945,
      "h": 455267123321,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(455267123321),
//--TRIMMABLE-BOUNDARY-START(85899935865),
    {
      "r": 393285,
      "p": [
        {
          "n": "jwtToken",
          "p": 458873
        },
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "CreateClaimsPrincipalFromToken",
      "d": 589945,
      "h": 85899935865,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(85899935865),
//--TRIMMABLE-BOUNDARY-START(468152025209),
    {
      "r": 1310721,
      "p": [
        {
          "n": "token",
          "p": 13762679
        }
      ],
      "n": "WriteToken",
      "d": 589945,
      "h": 468152025209,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(468152025209),
//--TRIMMABLE-BOUNDARY-START(317828169849),
    {
      "r": 65537,
      "p": [
        {
          "n": "telemetryClient",
          "p": 196727
        },
        {
          "n": "errorType",
          "p": 1310721
        },
        {
          "n": "securityToken",
          "p": 13762679
        },
        {
          "n": "algorithm",
          "p": 1310721
        },
        {
          "n": "key",
          "p": 13631607
        }
      ],
      "n": "RecordSignatureValidationTelemetry",
      "d": 589945,
      "h": 317828169849,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(317828169849),
//--TRIMMABLE-BOUNDARY-START(420907384953),
    {
      "r": 262145,
      "p": [
        {
          "n": "encodedBytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "signature",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "key",
          "p": 13631607
        },
        {
          "n": "algorithm",
          "p": 1310721
        },
        {
          "n": "securityToken",
          "p": 13762679
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "telemetryClient",
          "p": 196727
        }
      ],
      "n": "ValidateSignature",
      "d": 589945,
      "h": 420907384953,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(420907384953),
//--TRIMMABLE-BOUNDARY-START(425202352249),
    {
      "r": 458873,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ValidateSignature",
      "o": "@$1",
      "d": 589945,
      "h": 425202352249,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(425202352249),
//--TRIMMABLE-BOUNDARY-START(429497319545),
    {
      "r": 458873,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "jwtToken",
          "p": 458873
        },
        {
          "n": "validationParameters",
          "p": 16777335
        },
        {
          "n": "configuration",
          "p": 1638519
        }
      ],
      "n": "ValidateSignature",
      "o": "@$2",
      "d": 589945,
      "h": 429497319545,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(429497319545),
//--TRIMMABLE-BOUNDARY-START(253403660409),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h,
      "p": [
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "GetAllDecryptionKeys",
      "d": 589945,
      "h": 253403660409,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(253403660409),
//--TRIMMABLE-BOUNDARY-START(73015033977),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 458873
        },
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "CreateClaimsIdentity",
      "d": 589945,
      "h": 73015033977,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(73015033977),
//--TRIMMABLE-BOUNDARY-START(77310001273),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 458873
        },
        {
          "n": "actualIssuer",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "CreateClaimsIdentityWithMapping",
      "d": 589945,
      "h": 77310001273,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77310001273),
//--TRIMMABLE-BOUNDARY-START(81604968569),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 458873
        },
        {
          "n": "actualIssuer",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "CreateClaimsIdentityWithoutMapping",
      "d": 589945,
      "h": 81604968569,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81604968569),
//--TRIMMABLE-BOUNDARY-START(68720066681),
    {
      "r": 1310721,
      "p": [
        {
          "n": "actor",
          "p": 262213
        }
      ],
      "n": "CreateActorValue",
      "d": 589945,
      "h": 68720066681,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(68720066681),
//--TRIMMABLE-BOUNDARY-START(395137581177),
    {
      "r": 65537,
      "p": [
        {
          "n": "audiences",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.String).$h
        },
        {
          "n": "jwtToken",
          "p": 458873
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ValidateAudience",
      "d": 589945,
      "h": 395137581177,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(395137581177),
//--TRIMMABLE-BOUNDARY-START(416612417657),
    {
      "r": 65537,
      "p": [
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "jwtToken",
          "p": 458873
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ValidateLifetime",
      "d": 589945,
      "h": 416612417657,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(416612417657),
//--TRIMMABLE-BOUNDARY-START(399432548473),
    {
      "r": 1310721,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "jwtToken",
          "p": 458873
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ValidateIssuer",
      "d": 589945,
      "h": 399432548473,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(399432548473),
//--TRIMMABLE-BOUNDARY-START(463857057913),
    {
      "r": 65537,
      "p": [
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "securityToken",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ValidateTokenReplay",
      "d": 589945,
      "h": 463857057913,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(463857057913),
//--TRIMMABLE-BOUNDARY-START(322123137145),
    {
      "r": 13631607,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "jwtToken",
          "p": 458873
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ResolveIssuerSigningKey",
      "d": 589945,
      "h": 322123137145,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(322123137145),
//--TRIMMABLE-BOUNDARY-START(326418104441),
    {
      "r": 13631607,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "jwtToken",
          "p": 458873
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ResolveTokenDecryptionKey",
      "d": 589945,
      "h": 326418104441,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(326418104441),
//--TRIMMABLE-BOUNDARY-START(137439543417),
    {
      "r": 1310721,
      "p": [
        {
          "n": "jwtToken",
          "p": 458873
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "DecryptToken",
      "d": 589945,
      "h": 137439543417,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(137439543417),
//--TRIMMABLE-BOUNDARY-START(128849608825),
    {
      "r": 786552,
      "p": [
        {
          "n": "jwtToken",
          "p": 458873
        },
        {
          "n": "keys",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h
        }
      ],
      "n": "CreateJwtTokenDecryptionParameters",
      "d": 589945,
      "h": 128849608825,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(128849608825),
//--TRIMMABLE-BOUNDARY-START(257698627705),
    {
      "r": $.$$.System.Collections.Generic.IEnumerable$$($.$mit.Microsoft.IdentityModel.Tokens.SecurityKey).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 458873
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "GetContentEncryptionKeys",
      "d": 589945,
      "h": 257698627705,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(257698627705),
//--TRIMMABLE-BOUNDARY-START(266288562297),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "key",
          "p": 13631607
        }
      ],
      "n": "GetSymmetricSecurityKey",
      "d": 589945,
      "h": 266288562297,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(266288562297),
//--TRIMMABLE-BOUNDARY-START(403727515769),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 13631607
        },
        {
          "n": "securityToken",
          "p": 458873
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ValidateIssuerSecurityKey",
      "d": 589945,
      "h": 403727515769,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(403727515769),
//--TRIMMABLE-BOUNDARY-START(472446992505),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 58392579
        },
        {
          "n": "token",
          "p": 13762679
        }
      ],
      "n": "WriteToken",
      "o": "@$1",
      "d": 589945,
      "h": 472446992505,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(472446992505),
//--TRIMMABLE-BOUNDARY-START(450972156025),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$mit.Microsoft.IdentityModel.Tokens.TokenValidationResult).$h,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777335
        }
      ],
      "n": "ValidateTokenAsync",
      "o": "@$2",
      "d": 589945,
      "h": 450972156025,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(450972156025)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590524537),
    {
      "t": $.$$.System.Collections.Generic.ISet$$($.$$.System.String).$h,
      "n": "_inboundClaimFilter",
      "d": 589945,
      "h": 8590524537,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524537),
//--TRIMMABLE-BOUNDARY-START(12885491833),
    {
      "t": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "n": "_inboundClaimTypeMap",
      "d": 589945,
      "h": 12885491833,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885491833),
//--TRIMMABLE-BOUNDARY-START(17180459129),
    {
      "t": 1310721,
      "n": "_jsonClaimType",
      "d": 589945,
      "h": 17180459129,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180459129),
//--TRIMMABLE-BOUNDARY-START(25770393721),
    {
      "t": 1310721,
      "n": "_namespace",
      "d": 589945,
      "h": 25770393721,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25770393721),
//--TRIMMABLE-BOUNDARY-START(4295557241),
    {
      "t": 1310721,
      "n": "_className",
      "d": 589945,
      "h": 4295557241,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295557241),
//--TRIMMABLE-BOUNDARY-START(34360328313),
    {
      "t": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "n": "_outboundClaimTypeMap",
      "d": 589945,
      "h": 34360328313,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360328313),
//--TRIMMABLE-BOUNDARY-START(30065361017),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "n": "_outboundAlgorithmMap",
      "d": 589945,
      "h": 30065361017,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065361017),
//--TRIMMABLE-BOUNDARY-START(38655295609),
    {
      "t": 1310721,
      "n": "_shortClaimType",
      "d": 589945,
      "h": 38655295609,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38655295609),
//--TRIMMABLE-BOUNDARY-START(21475426425),
    {
      "t": 262145,
      "n": "_mapInboundClaims",
      "d": 589945,
      "h": 21475426425,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475426425),
//--TRIMMABLE-BOUNDARY-START(386547646585),
    {
      "t": 196727,
      "n": "TelemetryClient",
      "d": 589945,
      "h": 386547646585,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(386547646585),
//--TRIMMABLE-BOUNDARY-START(146029478009),
    {
      "t": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "n": "DefaultInboundClaimTypeMap",
      "d": 589945,
      "h": 146029478009,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029478009),
//--TRIMMABLE-BOUNDARY-START(150324445305),
    {
      "t": 262145,
      "n": "DefaultMapInboundClaims",
      "d": 589945,
      "h": 150324445305,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324445305),
//--TRIMMABLE-BOUNDARY-START(158914379897),
    {
      "t": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "n": "DefaultOutboundClaimTypeMap",
      "d": 589945,
      "h": 158914379897,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158914379897),
//--TRIMMABLE-BOUNDARY-START(141734510713),
    {
      "t": $.$$.System.Collections.Generic.ISet$$($.$$.System.String).$h,
      "n": "DefaultInboundClaimFilter",
      "d": 589945,
      "h": 141734510713,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734510713),
//--TRIMMABLE-BOUNDARY-START(154619412601),
    {
      "t": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h,
      "n": "DefaultOutboundAlgorithmMap",
      "d": 589945,
      "h": 154619412601,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619412601)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(51540197497),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589945,
      "h": 51540197497,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51540197497)
  ],
  "i": [11272311
  ],
  "j": [655481
  ],
  "h": 589945
}; }
            static get $b() { return $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenHandler; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mit.Microsoft.IdentityModel.Tokens.ISecurityTokenValidator ]; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589945)
        
        
        //--TRIMMABLE-BOUNDARY-START(196729)
        $asm.$cls("$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader", ($self) => class JwtHeader extends $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(85899542649)
            /*string*/ ClassName = null;
            //--TRIMMABLE-BOUNDARY-END(85899542649)
            
            //--TRIMMABLE-BOUNDARY-START(17180065913)
            $ctor$10()
            {
                super.$ctor$6($.$$.System.StringComparer.Ordinal);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180065913);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065913)
            
            //--TRIMMABLE-BOUNDARY-START(21475033209)
            $ctor$11(/*string*/ json)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475033209);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    _ = $.$firstOf(json, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("json") });
                    /*Utf8JsonReader*/ let reader = new $.$stj.System.Text.Json.Utf8JsonReader().$ctor$4($.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1($.$$.System.Text.Encoding.UTF8.GetBytes$8(json)), new $.$stj.System.Text.Json.JsonReaderOptions());
                    if (!$.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), 1/*JsonTokenType.StartObject*/, true))
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$stj.System.Text.Json.JsonException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX11023: Expecting json reader to be positioned on '{0}', reader was positioned at: '{1}', Reading: '{2}', Position: '{3}', CurrentDepth: '{4}', BytesConsumed: '{5}'."/*Microsoft.IdentityModel.Tokens.LogMessages.IDX11023*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("JsonTokenType.StartObject"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.TokenType, $.$stj.System.Text.Json.JsonTokenType)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(this.ClassName), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.TokenStartIndex, $.$$.System.Int64)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.CurrentDepth, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.BytesConsumed, $.$$.System.Int64)) ], null, null))));
                    }
                    while(true)
                    {
                        if (reader.TokenType === 5/*JsonTokenType.PropertyName*/)
                        {
                            /*string*/ let propertyName = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadPropertyName($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), this.ClassName, true);
                            /*object*/ let obj;
                            if (reader.TokenType === 3/*JsonTokenType.StartArray*/)
                            {
                                obj = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadArrayOfObjects($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), propertyName, this.ClassName);
                            }
                            else 
                            {
                                obj = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadPropertyValueAsObject($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), propertyName, this.ClassName, false);
                            }
                            this.set_Item(propertyName, obj);
                        }
                        else if ($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), 2/*JsonTokenType.EndObject*/, true))
                        {
                            break;
                        }
                        else if (!reader.Read())
                        {
                            break;
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475033209)
            
            //--TRIMMABLE-BOUNDARY-START(64424706169)
            $ctor$21(/*SigningCredentials*/ signingCredentials)
            {
                this.$ctor$20(signingCredentials, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424706169);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64424706169)
            
            //--TRIMMABLE-BOUNDARY-START(42949869689)
            $ctor$16(/*EncryptingCredentials*/ encryptingCredentials)
            {
                this.$ctor$15(encryptingCredentials, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949869689);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42949869689)
            
            //--TRIMMABLE-BOUNDARY-START(60129738873)
            $ctor$20(/*SigningCredentials*/ signingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap)
            {
                this.$ctor$19(signingCredentials, outboundAlgorithmMap, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129738873);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60129738873)
            
            //--TRIMMABLE-BOUNDARY-START(55834771577)
            $ctor$19(/*SigningCredentials*/ signingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType)
            {
                this.$ctor$18(signingCredentials, outboundAlgorithmMap, tokenType, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834771577);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55834771577)
            
            //--TRIMMABLE-BOUNDARY-START(47244836985)
            $ctor$17(/*SigningCredentials*/ signingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType, /*IDictionary<string, object>*/ additionalInnerHeaderClaims, /*bool*/ includeKeyIdInHeader)
            {
                super.$ctor$6($.$$.System.StringComparer.Ordinal);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244836985);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (signingCredentials === null)
                    {
                        this.set_Item("alg"/*JwtHeaderParameterNames.Alg*/, "none"/*SecurityAlgorithms.None*/);
                    }
                    else 
                    {
                        /*string*/ let outboundAlg;
                        if (outboundAlgorithmMap !== null && outboundAlgorithmMap.System$Collections$Generic$IDictionary$$$$TryGetValue(signingCredentials.Algorithm, $.$ref(() => outboundAlg, ($v) => outboundAlg = $v, $.$$.System.String), [$.$$.System.String, $.$$.System.String]))
                        {
                            this.Alg = outboundAlg;
                        }
                        else 
                        {
                            this.Alg = signingCredentials.Algorithm;
                        }
                        if (includeKeyIdInHeader)
                        {
                            if (!$.$$.System.String.IsNullOrEmpty(signingCredentials.Key.KeyId))
                            {
                                this.Kid = signingCredentials.Key.KeyId;
                            }
                            let x509SigningCredentials;
                            if ($.$is(signingCredentials, $.$mit.Microsoft.IdentityModel.Tokens.X509SigningCredentials, { set $v(v){ x509SigningCredentials = v; } }))
                            {
                                this.set_Item("x5t"/*JwtHeaderParameterNames.X5t*/, $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$1(x509SigningCredentials.Certificate.GetCertHash()));
                            }
                        }
                    }
                    if ($.$$.System.String.IsNullOrEmpty(tokenType))
                    {
                        this.Typ = "JWT"/*JwtConstants.HeaderType*/;
                    }
                    else 
                    {
                        this.Typ = tokenType;
                    }
                    this.AddAdditionalClaims(additionalInnerHeaderClaims, false);
                    this.SigningCredentials = signingCredentials;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47244836985)
            
            //--TRIMMABLE-BOUNDARY-START(51539804281)
            $ctor$18(/*SigningCredentials*/ signingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType, /*IDictionary<string, object>*/ additionalInnerHeaderClaims)
            {
                this.$ctor$17(signingCredentials, outboundAlgorithmMap, tokenType, additionalInnerHeaderClaims, true);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539804281);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51539804281)
            
            //--TRIMMABLE-BOUNDARY-START(38654902393)
            $ctor$15(/*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap)
            {
                this.$ctor$14(encryptingCredentials, outboundAlgorithmMap, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654902393);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38654902393)
            
            //--TRIMMABLE-BOUNDARY-START(34359935097)
            $ctor$14(/*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType)
            {
                this.$ctor$13(encryptingCredentials, outboundAlgorithmMap, tokenType, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34359935097);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34359935097)
            
            //--TRIMMABLE-BOUNDARY-START(25770000505)
            $ctor$12(/*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType, /*IDictionary<string, object>*/ additionalHeaderClaims, /*bool*/ includeKeyIdInHeader)
            {
                super.$ctor$6($.$$.System.StringComparer.Ordinal);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770000505);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (encryptingCredentials === null)
                    {
                        throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("encryptingCredentials");
                    }
                    /*string*/ let outboundAlg;
                    if (outboundAlgorithmMap !== null && outboundAlgorithmMap.System$Collections$Generic$IDictionary$$$$TryGetValue(encryptingCredentials.Alg, $.$ref(() => outboundAlg, ($v) => outboundAlg = $v, $.$$.System.String), [$.$$.System.String, $.$$.System.String]))
                    {
                        this.Alg = outboundAlg;
                    }
                    else 
                    {
                        this.Alg = encryptingCredentials.Alg;
                    }
                    if (outboundAlgorithmMap !== null && outboundAlgorithmMap.System$Collections$Generic$IDictionary$$$$TryGetValue(encryptingCredentials.Enc, $.$ref(() => outboundAlg, ($v) => outboundAlg = $v, $.$$.System.String), [$.$$.System.String, $.$$.System.String]))
                    {
                        this.Enc = outboundAlg;
                    }
                    else 
                    {
                        this.Enc = encryptingCredentials.Enc;
                    }
                    if ($.$mit.Microsoft.IdentityModel.Tokens.AppContextSwitches.UseRfcDefinitionOfEpkAndKid)
                    {
                        if (includeKeyIdInHeader && !$.$$.System.String.IsNullOrEmpty(encryptingCredentials.KeyExchangePublicKey.KeyId))
                        {
                            this.Kid = encryptingCredentials.KeyExchangePublicKey.KeyId;
                        }
                        if ($.$mit.Microsoft.IdentityModel.Tokens.SupportedAlgorithms.EcdsaWrapAlgorithms.System$Collections$Generic$ICollection$$$Contains(encryptingCredentials.Alg, [$.$$.System.String]))
                        {
                            this.Add("epk"/*JwtHeaderParameterNames.Epk*/, $.$mit.Microsoft.IdentityModel.Tokens.JsonWebKeyConverter.ConvertFromSecurityKey(encryptingCredentials.Key).RepresentAsAsymmetricPublicJwk());
                        }
                    }
                    else 
                    {
                        if (includeKeyIdInHeader && !$.$$.System.String.IsNullOrEmpty(encryptingCredentials.Key.KeyId))
                        {
                            this.Kid = encryptingCredentials.Key.KeyId;
                        }
                    }
                    if ($.$$.System.String.IsNullOrEmpty(tokenType))
                    {
                        this.Typ = "JWT"/*JwtConstants.HeaderType*/;
                    }
                    else 
                    {
                        this.Typ = tokenType;
                    }
                    this.AddAdditionalClaims(additionalHeaderClaims, encryptingCredentials.SetDefaultCtyClaim);
                    this.EncryptingCredentials = encryptingCredentials;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770000505)
            
            //--TRIMMABLE-BOUNDARY-START(30064967801)
            $ctor$13(/*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                this.$ctor$12(encryptingCredentials, outboundAlgorithmMap, tokenType, additionalHeaderClaims, true);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064967801);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30064967801)
            
            //--TRIMMABLE-BOUNDARY-START(73014640761)
            /*string */ get Alg()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669346425);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("alg"/*JwtHeaderParameterNames.Alg*/);
            }
            /*string */ set Alg(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338496121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.set_Item("alg"/*JwtHeaderParameterNames.Alg*/, value);
            }
            //--TRIMMABLE-BOUNDARY-END(73014640761)
            
            //--TRIMMABLE-BOUNDARY-START(90194509945)
            /*string */ get Cty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259281017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("cty"/*JwtHeaderParameterNames.Cty*/);
            }
            /*string */ set Cty(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928430713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.set_Item("cty"/*JwtHeaderParameterNames.Cty*/, value);
            }
            //--TRIMMABLE-BOUNDARY-END(90194509945)
            
            //--TRIMMABLE-BOUNDARY-START(98784444537)
            /*string */ get Enc()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849215609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("enc"/*JwtHeaderParameterNames.Enc*/);
            }
            /*string */ set Enc(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518365305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.set_Item("enc"/*JwtHeaderParameterNames.Enc*/, value);
            }
            //--TRIMMABLE-BOUNDARY-END(98784444537)
            
            //--TRIMMABLE-BOUNDARY-START(103079411833)
            /*EncryptingCredentials*/ EncryptingCredentials = null;
            //--TRIMMABLE-BOUNDARY-END(103079411833)
            
            //--TRIMMABLE-BOUNDARY-START(206158626937)
            /*string */ get IV()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029084793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("iv"/*JwtHeaderParameterNames.IV*/);
            }
            //--TRIMMABLE-BOUNDARY-END(206158626937)
            
            //--TRIMMABLE-BOUNDARY-START(210453594233)
            /*string */ get Kid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619019385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("kid"/*JwtHeaderParameterNames.Kid*/);
            }
            /*string */ set Kid(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698234489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.set_Item("kid"/*JwtHeaderParameterNames.Kid*/, value);
            }
            //--TRIMMABLE-BOUNDARY-END(210453594233)
            
            //--TRIMMABLE-BOUNDARY-START(279173070969)
            /*SigningCredentials*/ SigningCredentials = null;
            //--TRIMMABLE-BOUNDARY-END(279173070969)
            
            //--TRIMMABLE-BOUNDARY-START(283468038265)
            /*string */ get Typ()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798888569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("typ"/*JwtHeaderParameterNames.Typ*/);
            }
            /*string */ set Typ(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878103673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.set_Item("typ"/*JwtHeaderParameterNames.Typ*/, value);
            }
            //--TRIMMABLE-BOUNDARY-END(283468038265)
            
            //--TRIMMABLE-BOUNDARY-START(292057972857)
            /*string */ get X5t()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978757753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("x5t"/*JwtHeaderParameterNames.X5t*/);
            }
            //--TRIMMABLE-BOUNDARY-END(292057972857)
            
            //--TRIMMABLE-BOUNDARY-START(287763005561)
            /*string */ get X5c()
            {
                return this.GetStandardClaim("x5c"/*JwtHeaderParameterNames.X5c*/);
            }
            //--TRIMMABLE-BOUNDARY-END(287763005561)
            
            //--TRIMMABLE-BOUNDARY-START(296352940153)
            /*string */ get Zip()
            {
                return this.GetStandardClaim("zip"/*JwtHeaderParameterNames.Zip*/);
            }
            //--TRIMMABLE-BOUNDARY-END(296352940153)
            
            //--TRIMMABLE-BOUNDARY-START(77309608057)
            static /*JwtHeader */ Base64UrlDeserialize(/*string*/ base64UrlEncodedJsonString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309608057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(base64UrlEncodedJsonString, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("base64UrlEncodedJsonString") });
                return new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader().$ctor$11($.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Decode$3(base64UrlEncodedJsonString));
            }
            //--TRIMMABLE-BOUNDARY-END(77309608057)
            
            //--TRIMMABLE-BOUNDARY-START(81604575353)
            /*string */ Base64UrlEncode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$3(this.SerializeToJson());
            }
            //--TRIMMABLE-BOUNDARY-END(81604575353)
            
            //--TRIMMABLE-BOUNDARY-START(201863659641)
            /*string */ GetStandardClaim(/*string*/ claimType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863659641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object*/ let value;
                if (this.TryGetValue(claimType, $.$ref(() => value, ($v) => value = $v, $.$$.System.Object)))
                {
                    if (value === null)
                    {
                        return null;
                    }
                    let str;
                    if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                    {
                        return str;
                    }
                    let jsonElement;
                    let list;
                    let objectList;
                    if ($.$is(value, $.$stj.System.Text.Json.JsonElement, { set $v(v){ jsonElement = v; } }))
                    {
                        return $.$stj.System.Text.Json.JsonElement.ToString.call(jsonElement);
                    }
                    else if ($.$is(value, $.$$.System.Collections.Generic.IList$$($.$$.System.String), { set $v(v){ list = v; } }))
                    {
                        /*JsonElement*/ let json = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.CreateJsonElement(list);
                        return $.$stj.System.Text.Json.JsonElement.ToString.call(json);
                    }
                    else if ($.$is(value, $.$$.System.Collections.Generic.IList$$($.$$.System.Object), { set $v(v){ objectList = v; } }))
                    {
                        /*var*/ let stringList = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$3(objectList.System$Collections$Generic$ICollection$$$Count);
                        var $en4 = objectList.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                let strItem;
                                if ($.$is(item, $.$$.System.String, { set $v(v){ strItem = v; } }))
                                {
                                    stringList.Add(strItem);
                                }
                                else 
                                {
                                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$stj.System.Text.Json.JsonException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX11026: Unable to get claim value as a string from claim type:'{0}', value type was:'{1}'. Acceptable types are String, IList<String>, and System.Text.Json.JsonElement."/*Microsoft.IdentityModel.Tokens.LogMessages.IDX11026*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII(claimType), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Object.GetType.call(item)) ], null, null))));
                                }
                            }
                        }
                        /*JsonElement*/ let json = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.CreateJsonElement(stringList);
                        return $.$stj.System.Text.Json.JsonElement.ToString.call(json);
                    }
                    return $.$$.System.String.Empty;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(201863659641)
            
            //--TRIMMABLE-BOUNDARY-START(68719673465)
            /*void */ AddAdditionalClaims(/*IDictionary<string, object>*/ additionalHeaderClaims, /*bool*/ setDefaultCtyClaim)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719673465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Int32.op_GreaterThan$1((additionalHeaderClaims?.System$Collections$Generic$ICollection$$$Count ?? null), 0) && $.$sl.System.Linq.Enumerable.Any$1($.$$.System.String, $.$sl.System.Linq.Enumerable.Intersect($.$$.System.String, additionalHeaderClaims.System$Collections$Generic$IDictionary$$$$Keys, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader.DefaultHeaderParameters, $.$$.System.StringComparer.OrdinalIgnoreCase)))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$mit.Microsoft.IdentityModel.Tokens.SecurityTokenException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12742: ''{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation."/*LogMessages.IDX12742*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ "additionalHeaderClaims", $.$$.System.String.Join$5(", ", $.$sitj.System.IdentityModel.Tokens.Jwt.JwtHeader.DefaultHeaderParameters) ], null, null))));
                }
                if (additionalHeaderClaims !== null)
                {
                    if (!additionalHeaderClaims.System$Collections$Generic$IDictionary$$$$TryGetValue("cty"/*JwtHeaderParameterNames.Cty*/, $.$discardRef(), [$.$$.System.String, $.$$.System.Object]) && setDefaultCtyClaim)
                    {
                        this.Cty = "JWT"/*JwtConstants.HeaderType*/;
                    }
                    var $en3 = additionalHeaderClaims.System$Collections$Generic$IDictionary$$$$Keys.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var claim = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            this.set_Item(claim, additionalHeaderClaims.System$Collections$Generic$IDictionary$$$$get_Item(claim, [$.$$.System.String, $.$$.System.Object]));
                        }
                    }
                }
                else if (setDefaultCtyClaim)
                {
                    this.Cty = "JWT"/*JwtConstants.HeaderType*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719673465)
            
            //--TRIMMABLE-BOUNDARY-START(94489477241)
            /*IList<string>*/ static DefaultHeaderParameters = null;
            //--TRIMMABLE-BOUNDARY-END(94489477241)
            
            //--TRIMMABLE-BOUNDARY-START(214748561529)
            /*string */ SerializeToJson()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748561529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let memoryStream = null;
                try
                {
                    memoryStream = new $.$$.System.IO.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let writer = null;
                    try
                    {
                        writer = new $.$stj.System.Text.Json.Utf8JsonWriter().$ctor$2(memoryStream, (() =>
                        {
                            //new $.$stj.System.Text.Json.JsonWriterOptions()
                            const $t1 = $.$stj.System.Text.Json.JsonWriterOptions;
                            const $i1 = new $t1();
                            $i1.Encoder = $.$stew.System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                            return $i1;
                        })());
                        writer.WriteStartObject();
                        $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteObjects($.$ref(() => writer, ($v) => writer = $v, $.$stj.System.Text.Json.Utf8JsonWriter), this);
                        writer.WriteEndObject();
                        writer.Flush();
                        return $.$$.System.Text.Encoding.UTF8.GetString(memoryStream.GetBuffer(), 0, $.$cast(memoryStream.Length, $.$$.System.Int32));
                    }
                    finally
                    {
                        {
                            writer?.Dispose();
                        }
                    }
                }
                finally
                {
                    memoryStream?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214748561529)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(85899542649)
                this.ClassName = "System.IdentityModel.Tokens.Jwt.JwtHeader";
                //--TRIMMABLE-BOUNDARY-END(85899542649)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12885098617)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(94489477241)
                    this.DefaultHeaderParameters = (() =>
                    {
                        //new $.$$.System.Collections.Generic.List$$($.$$.System.String)()
                        const $t1 = $.$$.System.Collections.Generic.List$$($.$$.System.String);
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Add("alg"/*JwtHeaderParameterNames.Alg*/);
                        $i1.Add("kid"/*JwtHeaderParameterNames.Kid*/);
                        $i1.Add("x5t"/*JwtHeaderParameterNames.X5t*/);
                        $i1.Add("enc"/*JwtHeaderParameterNames.Enc*/);
                        $i1.Add("zip"/*JwtHeaderParameterNames.Zip*/);
                        return $i1;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(94489477241)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885098617)
            
            static $h = 196729;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73014640761),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669346425,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338496121,
        "f": 83886082
      },
      "n": "Alg",
      "d": 196729,
      "h": 73014640761,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014640761),
//--TRIMMABLE-BOUNDARY-START(90194509945),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259281017,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928430713,
        "f": 83886082
      },
      "n": "Cty",
      "d": 196729,
      "h": 90194509945,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194509945),
//--TRIMMABLE-BOUNDARY-START(98784444537),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849215609,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518365305,
        "f": 83886082
      },
      "n": "Enc",
      "d": 196729,
      "h": 98784444537,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784444537),
//--TRIMMABLE-BOUNDARY-START(103079411833),
    {
      "p": 3932279,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439150201,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249108299897,
        "f": 83886082
      },
      "n": "EncryptingCredentials",
      "d": 196729,
      "h": 103079411833,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079411833),
//--TRIMMABLE-BOUNDARY-START(206158626937),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029084793,
        "f": 50331649
      },
      "n": "IV",
      "d": 196729,
      "h": 206158626937,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206158626937),
//--TRIMMABLE-BOUNDARY-START(210453594233),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619019385,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257698234489,
        "f": 83886082
      },
      "n": "Kid",
      "d": 196729,
      "h": 210453594233,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210453594233),
//--TRIMMABLE-BOUNDARY-START(279173070969),
    {
      "p": 15925367,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163208953977,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266288169081,
        "f": 83886082
      },
      "n": "SigningCredentials",
      "d": 196729,
      "h": 279173070969,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279173070969),
//--TRIMMABLE-BOUNDARY-START(283468038265),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171798888569,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274878103673,
        "f": 83886082
      },
      "n": "Typ",
      "d": 196729,
      "h": 283468038265,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(283468038265),
//--TRIMMABLE-BOUNDARY-START(292057972857),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188978757753,
        "f": 50331649
      },
      "n": "X5t",
      "d": 196729,
      "h": 292057972857,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(292057972857),
//--TRIMMABLE-BOUNDARY-START(287763005561),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180388823161,
        "f": 50331649
      },
      "n": "X5c",
      "d": 196729,
      "h": 287763005561,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(287763005561),
//--TRIMMABLE-BOUNDARY-START(296352940153),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197568692345,
        "f": 50331649
      },
      "n": "Zip",
      "d": 196729,
      "h": 296352940153,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(296352940153)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77309608057),
    {
      "r": 196729,
      "p": [
        {
          "n": "base64UrlEncodedJsonString",
          "p": 1310721
        }
      ],
      "n": "Base64UrlDeserialize",
      "d": 196729,
      "h": 77309608057,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77309608057),
//--TRIMMABLE-BOUNDARY-START(81604575353),
    {
      "r": 1310721,
      "n": "Base64UrlEncode",
      "d": 196729,
      "h": 81604575353,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(81604575353),
//--TRIMMABLE-BOUNDARY-START(201863659641),
    {
      "r": 1310721,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        }
      ],
      "n": "GetStandardClaim",
      "d": 196729,
      "h": 201863659641,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(201863659641),
//--TRIMMABLE-BOUNDARY-START(68719673465),
    {
      "r": 65537,
      "p": [
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        },
        {
          "n": "setDefaultCtyClaim",
          "p": 262145
        }
      ],
      "n": "AddAdditionalClaims",
      "d": 196729,
      "h": 68719673465,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(68719673465),
//--TRIMMABLE-BOUNDARY-START(214748561529),
    {
      "r": 1310721,
      "n": "SerializeToJson",
      "d": 196729,
      "h": 214748561529,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(214748561529)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(85899542649),
    {
      "t": 1310721,
      "n": "ClassName",
      "d": 196729,
      "h": 85899542649,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(85899542649),
//--TRIMMABLE-BOUNDARY-START(94489477241),
    {
      "t": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,
      "n": "DefaultHeaderParameters",
      "d": 196729,
      "h": 94489477241,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94489477241)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180065913),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 196729,
      "h": 17180065913,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180065913),
//--TRIMMABLE-BOUNDARY-START(21475033209),
    {
      "p": [
        {
          "n": "json",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$11",
      "d": 196729,
      "h": 21475033209,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21475033209),
//--TRIMMABLE-BOUNDARY-START(64424706169),
    {
      "p": [
        {
          "n": "signingCredentials",
          "p": 15925367
        }
      ],
      "n": ".ctor",
      "o": "$ctor$21",
      "d": 196729,
      "h": 64424706169,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424706169),
//--TRIMMABLE-BOUNDARY-START(42949869689),
    {
      "p": [
        {
          "n": "encryptingCredentials",
          "p": 3932279
        }
      ],
      "n": ".ctor",
      "o": "$ctor$16",
      "d": 196729,
      "h": 42949869689,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42949869689),
//--TRIMMABLE-BOUNDARY-START(60129738873),
    {
      "p": [
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "outboundAlgorithmMap",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$20",
      "d": 196729,
      "h": 60129738873,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129738873),
//--TRIMMABLE-BOUNDARY-START(55834771577),
    {
      "p": [
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "outboundAlgorithmMap",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$19",
      "d": 196729,
      "h": 55834771577,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834771577),
//--TRIMMABLE-BOUNDARY-START(47244836985),
    {
      "p": [
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "outboundAlgorithmMap",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        },
        {
          "n": "additionalInnerHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        },
        {
          "n": "includeKeyIdInHeader",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$17",
      "d": 196729,
      "h": 47244836985,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(47244836985),
//--TRIMMABLE-BOUNDARY-START(51539804281),
    {
      "p": [
        {
          "n": "signingCredentials",
          "p": 15925367
        },
        {
          "n": "outboundAlgorithmMap",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        },
        {
          "n": "additionalInnerHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$18",
      "d": 196729,
      "h": 51539804281,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539804281),
//--TRIMMABLE-BOUNDARY-START(38654902393),
    {
      "p": [
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "outboundAlgorithmMap",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$15",
      "d": 196729,
      "h": 38654902393,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654902393),
//--TRIMMABLE-BOUNDARY-START(34359935097),
    {
      "p": [
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "outboundAlgorithmMap",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$14",
      "d": 196729,
      "h": 34359935097,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359935097),
//--TRIMMABLE-BOUNDARY-START(25770000505),
    {
      "p": [
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "outboundAlgorithmMap",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        },
        {
          "n": "includeKeyIdInHeader",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$12",
      "d": 196729,
      "h": 25770000505,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(25770000505),
//--TRIMMABLE-BOUNDARY-START(30064967801),
    {
      "p": [
        {
          "n": "encryptingCredentials",
          "p": 3932279
        },
        {
          "n": "outboundAlgorithmMap",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.String).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$13",
      "d": 196729,
      "h": 30064967801,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064967801)
  ],
  "i": [$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,$.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,62521345,62390273,$.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,62652417,157483009,157220865
  ],
  "h": 196729
}; }
            static get $b() { return $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object), $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtHeader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196729)
        
        
        //--TRIMMABLE-BOUNDARY-START(327801)
        $asm.$cls("$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload", ($self) => class JwtPayload extends $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(163209085049)
            /*string*/ static ClassName = null;
            //--TRIMMABLE-BOUNDARY-END(163209085049)
            
            //--TRIMMABLE-BOUNDARY-START(4295295097)
            /*List<string>*/ _audiences = null;
            //--TRIMMABLE-BOUNDARY-END(4295295097)
            
            //--TRIMMABLE-BOUNDARY-START(8590262393)
            /*string*/ _azp = null;
            //--TRIMMABLE-BOUNDARY-END(8590262393)
            
            //--TRIMMABLE-BOUNDARY-START(12885229689)
            /*long?*/ _exp = null;
            //--TRIMMABLE-BOUNDARY-END(12885229689)
            
            //--TRIMMABLE-BOUNDARY-START(17180196985)
            /*DateTime?*/ _expDateTime = null;
            //--TRIMMABLE-BOUNDARY-END(17180196985)
            
            //--TRIMMABLE-BOUNDARY-START(21475164281)
            /*long?*/ _iat = null;
            //--TRIMMABLE-BOUNDARY-END(21475164281)
            
            //--TRIMMABLE-BOUNDARY-START(25770131577)
            /*DateTime?*/ _iatDateTime = null;
            //--TRIMMABLE-BOUNDARY-END(25770131577)
            
            //--TRIMMABLE-BOUNDARY-START(30065098873)
            /*string*/ _id = null;
            //--TRIMMABLE-BOUNDARY-END(30065098873)
            
            //--TRIMMABLE-BOUNDARY-START(34360066169)
            /*string*/ _iss = null;
            //--TRIMMABLE-BOUNDARY-END(34360066169)
            
            //--TRIMMABLE-BOUNDARY-START(38655033465)
            /*string*/ _jti = null;
            //--TRIMMABLE-BOUNDARY-END(38655033465)
            
            //--TRIMMABLE-BOUNDARY-START(42950000761)
            /*long?*/ _nbf = null;
            //--TRIMMABLE-BOUNDARY-END(42950000761)
            
            //--TRIMMABLE-BOUNDARY-START(47244968057)
            /*DateTime?*/ _nbfDateTime = null;
            //--TRIMMABLE-BOUNDARY-END(47244968057)
            
            //--TRIMMABLE-BOUNDARY-START(51539935353)
            /*string*/ _sub = null;
            //--TRIMMABLE-BOUNDARY-END(51539935353)
            
            //--TRIMMABLE-BOUNDARY-START(55834902649)
            /*string*/ _tid = null;
            //--TRIMMABLE-BOUNDARY-END(55834902649)
            
            //--TRIMMABLE-BOUNDARY-START(60129869945)
            $ctor$10()
            {
                this.$ctor$15(null, null, null, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129869945);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60129869945)
            
            //--TRIMMABLE-BOUNDARY-START(167504052345)
            static /*JwtPayload */ CreatePayload(/*byte[]*/ bytes, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504052345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*JwtPayload*/ let payload = new $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload().$ctor$10();
                /*Utf8JsonReader*/ let reader = new $.$stj.System.Text.Json.Utf8JsonReader().$ctor$4($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.MemoryExtensions.AsSpan$14($.$$.System.Byte, bytes).Slice(0, length)), new $.$stj.System.Text.Json.JsonReaderOptions());
                if (!$.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), 1/*JsonTokenType.StartObject*/, true))
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$stj.System.Text.Json.JsonException().$ctor$10($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX11023: Expecting json reader to be positioned on '{0}', reader was positioned at: '{1}', Reading: '{2}', Position: '{3}', CurrentDepth: '{4}', BytesConsumed: '{5}'."/*Microsoft.IdentityModel.Tokens.LogMessages.IDX11023*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("JsonTokenType.StartObject"), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.TokenType, $.$stj.System.Text.Json.JsonTokenType)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII("System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.TokenStartIndex, $.$$.System.Int64)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.CurrentDepth, $.$$.System.Int32)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$box(reader.BytesConsumed, $.$$.System.Int64)) ], null, null))));
                }
                while(true)
                {
                    if (reader.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        if (reader.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Aud))
                        {
                            reader.Read();
                            payload._audiences = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                            if (reader.TokenType === 3/*JsonTokenType.StartArray*/)
                            {
                                $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadStrings$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), payload._audiences, "aud"/*JwtRegisteredClaimNames.Aud*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, false);
                                payload.set_Item("aud"/*JwtRegisteredClaimNames.Aud*/, payload._audiences);
                            }
                            else 
                            {
                                payload._audiences.Add($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), "aud"/*JwtRegisteredClaimNames.Aud*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, false));
                                payload.set_Item("aud"/*JwtRegisteredClaimNames.Aud*/, payload._audiences.get_Item(0));
                            }
                        }
                        else if (reader.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Exp))
                        {
                            payload._exp = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadLong($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), "exp"/*JwtRegisteredClaimNames.Exp*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item("exp"/*JwtRegisteredClaimNames.Exp*/, $.$box(payload._exp, $.$$.System.Nullable$$($.$$.System.Int64)));
                            payload._expDateTime = $.$mit.Microsoft.IdentityModel.Tokens.EpochTime.DateTime($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(payload._exp));
                        }
                        else if (reader.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Iat))
                        {
                            payload._iat = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadLong($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), "iat"/*JwtRegisteredClaimNames.Iat*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item("iat"/*JwtRegisteredClaimNames.Iat*/, $.$box(payload._iat, $.$$.System.Nullable$$($.$$.System.Int64)));
                            payload._iatDateTime = $.$mit.Microsoft.IdentityModel.Tokens.EpochTime.DateTime($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(payload._iat));
                        }
                        else if (reader.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Iss))
                        {
                            payload._iss = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), "iss"/*JwtRegisteredClaimNames.Iss*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item("iss"/*JwtRegisteredClaimNames.Iss*/, payload._iss);
                        }
                        else if (reader.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Jti))
                        {
                            payload._jti = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadString($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), "jti"/*JwtRegisteredClaimNames.Jti*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item("jti"/*JwtRegisteredClaimNames.Jti*/, payload._jti);
                        }
                        else if (reader.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Nbf))
                        {
                            payload._nbf = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadLong($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), "nbf"/*JwtRegisteredClaimNames.Nbf*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload._nbfDateTime = $.$mit.Microsoft.IdentityModel.Tokens.EpochTime.DateTime($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(payload._nbf));
                            payload.set_Item("nbf"/*JwtRegisteredClaimNames.Nbf*/, $.$box(payload._nbf, $.$$.System.Nullable$$($.$$.System.Int64)));
                        }
                        else if (reader.ValueTextEquals($.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtPayloadUtf8Bytes.Sub))
                        {
                            payload._sub = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadStringOrNumberAsString($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), "sub"/*JwtRegisteredClaimNames.Sub*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item("sub"/*JwtRegisteredClaimNames.Sub*/, payload._sub);
                        }
                        else 
                        {
                            /*string*/ let propertyName = $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadPropertyName($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item(propertyName, $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.ReadPropertyValueAsObject($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), propertyName, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, false));
                        }
                    }
                    else if ($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$stj.System.Text.Json.Utf8JsonReader, () => reader, ($v) => reader = $v, null), 2/*JsonTokenType.EndObject*/, true))
                    {
                        break;
                    }
                    else if (!reader.Read())
                    {
                        break;
                    }
                }
                return payload;
            }
            //--TRIMMABLE-BOUNDARY-END(167504052345)
            
            //--TRIMMABLE-BOUNDARY-START(64424837241)
            $ctor$11(/*IEnumerable<Claim>*/ claims)
            {
                this.$ctor$15(null, null, claims, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424837241);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64424837241)
            
            //--TRIMMABLE-BOUNDARY-START(81604706425)
            $ctor$15(/*string*/ issuer, /*string*/ audience, /*IEnumerable<Claim>*/ claims, /*DateTime?*/ notBefore, /*DateTime?*/ expires)
            {
                this.$ctor$14(issuer, audience, claims, notBefore?.Clone() ?? null, expires?.Clone() ?? null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604706425);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81604706425)
            
            //--TRIMMABLE-BOUNDARY-START(77309739129)
            $ctor$14(/*string*/ issuer, /*string*/ audience, /*IEnumerable<Claim>*/ claims, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                super.$ctor$6($.$$.System.StringComparer.Ordinal);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309739129);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (claims !== null)
                    {
                        this.AddClaims(claims);
                    }
                    this.AddFirstPriorityClaims$1(issuer, audience, notBefore?.Clone() ?? null, expires?.Clone() ?? null, issuedAt?.Clone() ?? null);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77309739129)
            
            //--TRIMMABLE-BOUNDARY-START(68719804537)
            $ctor$12(/*string*/ issuer, /*IList<string>*/ audiences, /*IEnumerable<Claim>*/ claims, /*IDictionary<string, object>*/ claimsCollection, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                this.$ctor$16(issuer, "", audiences, claims, claimsCollection, notBefore?.Clone() ?? null, expires?.Clone() ?? null, issuedAt?.Clone() ?? null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719804537);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68719804537)
            
            //--TRIMMABLE-BOUNDARY-START(85899673721)
            $ctor$16(/*string*/ issuer, /*string*/ audience, /*IList<string>*/ audiences, /*IEnumerable<Claim>*/ claims, /*IDictionary<string, object>*/ claimsCollection, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                super.$ctor$6($.$$.System.StringComparer.Ordinal);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899673721);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (claims !== null)
                    {
                        this.AddClaims(claims);
                    }
                    if (claimsCollection !== null && $.$sl.System.Linq.Enumerable.Any$1($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object), claimsCollection))
                    {
                        this.AddDictionaryClaims(claimsCollection);
                    }
                    if (audiences !== null)
                    {
                        this.AddFirstPriorityClaims(issuer, audience, audiences, notBefore?.Clone() ?? null, expires?.Clone() ?? null, issuedAt?.Clone() ?? null);
                    }
                    else 
                    {
                        this.AddFirstPriorityClaims(issuer, audience, (() =>
                        {
                            let $t1 = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                            return $t1;
                        })(), notBefore?.Clone() ?? null, expires?.Clone() ?? null, issuedAt?.Clone() ?? null);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(85899673721)
            
            //--TRIMMABLE-BOUNDARY-START(120259412089)
            /*void */ AddFirstPriorityClaims$1(/*string*/ issuer, /*string*/ audience, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259412089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddFirstPriorityClaims(issuer, audience, (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    return $t1;
                })(), notBefore?.Clone() ?? null, expires?.Clone() ?? null, issuedAt?.Clone() ?? null);
            }
            //--TRIMMABLE-BOUNDARY-END(120259412089)
            
            //--TRIMMABLE-BOUNDARY-START(73014771833)
            $ctor$13(/*string*/ issuer, /*string*/ audience, /*IEnumerable<Claim>*/ claims, /*IDictionary<string, object>*/ claimsCollection, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                this.$ctor$16(issuer, audience, (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    return $t1;
                })(), claims, claimsCollection, notBefore?.Clone() ?? null, expires?.Clone() ?? null, issuedAt?.Clone() ?? null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014771833);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73014771833)
            
            //--TRIMMABLE-BOUNDARY-START(115964444793)
            /*void */ AddFirstPriorityClaims(/*string*/ issuer, /*string*/ audience, /*IList<string>*/ audiences, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964444793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(expires))
                {
                    if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(notBefore))
                    {
                        if ($.$$.System.DateTime.op_GreaterThanOrEqual($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(notBefore), $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(expires)))
                        {
                            throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentException().$ctor$14($.$mil.Microsoft.IdentityModel.Logging.LogHelper.FormatInvariant("IDX12401: Expires: '{0}' must be after NotBefore: '{1}'."/*LogMessages.IDX12401*/, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(expires)), $.$mil.Microsoft.IdentityModel.Logging.LogHelper.MarkAsNonPII($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(notBefore)) ], null, null))));
                        }
                        this.set_Item("nbf"/*JwtRegisteredClaimNames.Nbf*/, $.$box($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(notBefore).ToUniversalTime()), $.$$.System.Int64));
                    }
                    this.set_Item("exp"/*JwtRegisteredClaimNames.Exp*/, $.$box($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(expires).ToUniversalTime()), $.$$.System.Int64));
                }
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(issuedAt))
                {
                    this.set_Item("iat"/*JwtRegisteredClaimNames.Iat*/, $.$box($.$mit.Microsoft.IdentityModel.Tokens.EpochTime.GetIntDate($.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(issuedAt).ToUniversalTime()), $.$$.System.Int64));
                }
                if (!$.$$.System.String.IsNullOrEmpty(issuer))
                {
                    this.set_Item("iss"/*JwtRegisteredClaimNames.Iss*/, issuer);
                }
                if (!$.$$.System.String.IsNullOrEmpty(audience))
                {
                    this.AddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$7("aud"/*JwtRegisteredClaimNames.Aud*/, audience, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/));
                }
                var $en2 = audiences.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var aud = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (!$.$$.System.String.IsNullOrEmpty(aud))
                        {
                            this.AddClaim(new $.$ssc.System.Security.Claims.Claim().$ctor$7("aud"/*JwtRegisteredClaimNames.Aud*/, aud, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/));
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964444793)
            
            //--TRIMMABLE-BOUNDARY-START(94489608313)
            /*string */ get Actort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568823417);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("actort"/*JwtRegisteredClaimNames.Actort*/);
            }
            //--TRIMMABLE-BOUNDARY-END(94489608313)
            
            //--TRIMMABLE-BOUNDARY-START(90194641017)
            /*string */ get Acr()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978888825);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("acr"/*JwtRegisteredClaimNames.Acr*/);
            }
            //--TRIMMABLE-BOUNDARY-END(90194641017)
            
            //--TRIMMABLE-BOUNDARY-START(128849346681)
            /*IList<string> */ get Amr()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158758009);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetListOfClaims("amr"/*JwtRegisteredClaimNames.Amr*/);
            }
            //--TRIMMABLE-BOUNDARY-END(128849346681)
            
            //--TRIMMABLE-BOUNDARY-START(137439281273)
            /*int? */ get AuthTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338627193);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetIntClaim("auth_time"/*JwtRegisteredClaimNames.AuthTime*/);
            }
            //--TRIMMABLE-BOUNDARY-END(137439281273)
            
            //--TRIMMABLE-BOUNDARY-START(133144313977)
            /*IList<string> */ get Aud()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748692601);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._audiences === null)
                {
                    /*List<string>*/ let tmp = this.GetListOfClaims("aud"/*JwtRegisteredClaimNames.Aud*/);
                    $.$$.System.Threading.Interlocked.CompareExchange$14($.$$.System.Collections.Generic.List$$($.$$.System.String), $.$ref(() => this._audiences, ($v) => this._audiences = $v, $.$$.System.Collections.Generic.List$$($.$$.System.String)), tmp, null);
                }
                return this._audiences;
            }
            //--TRIMMABLE-BOUNDARY-END(133144313977)
            
            //--TRIMMABLE-BOUNDARY-START(141734248569)
            /*string */ get Azp()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928561785);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("azp"/*JwtRegisteredClaimNames.Azp*/);
            }
            //--TRIMMABLE-BOUNDARY-END(141734248569)
            
            //--TRIMMABLE-BOUNDARY-START(154619150457)
            /*string */ get CHash()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518496377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("c_hash"/*JwtRegisteredClaimNames.CHash*/);
            }
            //--TRIMMABLE-BOUNDARY-END(154619150457)
            
            //--TRIMMABLE-BOUNDARY-START(176093986937)
            /*int? */ get Exp()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698365561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetIntClaim("exp"/*JwtRegisteredClaimNames.Exp*/);
            }
            //--TRIMMABLE-BOUNDARY-END(176093986937)
            
            //--TRIMMABLE-BOUNDARY-START(180388954233)
            /*long? */ get Expiration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288300153);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetLongClaim("exp"/*JwtRegisteredClaimNames.Exp*/);
            }
            //--TRIMMABLE-BOUNDARY-END(180388954233)
            
            //--TRIMMABLE-BOUNDARY-START(390842351737)
            /*string */ get Jti()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648038521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._jti ??= this.GetStandardClaim("jti"/*JwtRegisteredClaimNames.Jti*/);
                return this._jti;
            }
            //--TRIMMABLE-BOUNDARY-END(390842351737)
            
            //--TRIMMABLE-BOUNDARY-START(377957449849)
            /*int? */ get Iat()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878234745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetIntClaim("iat"/*JwtRegisteredClaimNames.Iat*/);
            }
            //--TRIMMABLE-BOUNDARY-END(377957449849)
            
            //--TRIMMABLE-BOUNDARY-START(382252417145)
            /*string */ get Iss()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468169337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._iss ??= this.GetStandardClaim("iss"/*JwtRegisteredClaimNames.Iss*/);
                return this._iss;
            }
            //--TRIMMABLE-BOUNDARY-END(382252417145)
            
            //--TRIMMABLE-BOUNDARY-START(395137319033)
            /*int? */ get Nbf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309237973113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetIntClaim("nbf"/*JwtRegisteredClaimNames.Nbf*/);
            }
            //--TRIMMABLE-BOUNDARY-END(395137319033)
            
            //--TRIMMABLE-BOUNDARY-START(399432286329)
            /*string */ get Nonce()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317827907705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("nonce"/*JwtRegisteredClaimNames.Nonce*/);
            }
            //--TRIMMABLE-BOUNDARY-END(399432286329)
            
            //--TRIMMABLE-BOUNDARY-START(403727253625)
            /*long? */ get NotBefore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326417842297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetLongClaim("nbf"/*JwtRegisteredClaimNames.Nbf*/);
            }
            //--TRIMMABLE-BOUNDARY-END(403727253625)
            
            //--TRIMMABLE-BOUNDARY-START(412317188217)
            /*string */ get Sub()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335007776889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._sub ??= this.GetStandardClaim("sub"/*JwtRegisteredClaimNames.Sub*/);
                return this._sub;
            }
            //--TRIMMABLE-BOUNDARY-END(412317188217)
            
            //--TRIMMABLE-BOUNDARY-START(425202090105)
            /*DateTime */ get ValidFrom()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597711481);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(this._nbfDateTime))
                {
                    return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._nbfDateTime);
                }
                /*long?*/ let l = this.GetLongClaim("nbf"/*JwtRegisteredClaimNames.Nbf*/);
                if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(l))
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.EpochTime.DateTime($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(l));
                }
                this._nbfDateTime = $.$$.System.DateTime.MinValue;
                return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._nbfDateTime);
            }
            //--TRIMMABLE-BOUNDARY-END(425202090105)
            
            //--TRIMMABLE-BOUNDARY-START(429497057401)
            /*DateTime */ get ValidTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187646073);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(this._expDateTime))
                {
                    return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._expDateTime);
                }
                /*long?*/ let l = this.GetLongClaim("exp"/*JwtRegisteredClaimNames.Exp*/);
                if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(l))
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.EpochTime.DateTime($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(l));
                }
                this._expDateTime = $.$$.System.DateTime.MinValue;
                return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._expDateTime);
            }
            //--TRIMMABLE-BOUNDARY-END(429497057401)
            
            //--TRIMMABLE-BOUNDARY-START(386547384441)
            /*DateTime */ get IssuedAt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058103929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Nullable$$($.$$.System.DateTime).HasValue$get.call(this._iatDateTime))
                {
                    return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._iatDateTime);
                }
                /*long?*/ let l = this.GetLongClaim("iat"/*JwtRegisteredClaimNames.Iat*/);
                if ($.$$.System.Nullable$$($.$$.System.Int64).HasValue$get.call(l))
                {
                    return $.$mit.Microsoft.IdentityModel.Tokens.EpochTime.DateTime($.$$.System.Nullable$$($.$$.System.Int64).Value$get.call(l));
                }
                this._iatDateTime = $.$$.System.DateTime.MinValue;
                return $.$$.System.Nullable$$($.$$.System.DateTime).Value$get.call(this._iatDateTime);
            }
            //--TRIMMABLE-BOUNDARY-END(386547384441)
            
            //--TRIMMABLE-BOUNDARY-START(158914117753)
            /*IEnumerable<Claim> */ get Claims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108430969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<Claim>*/ let claims = new ($.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim))().$ctor$1();
                /*string*/ let issuer = this.Iss ?? "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                var $en2 = this.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var keyValuePair = $en2.Current;
                    {
                        let str;
                        let j;
                        let objects;
                        let dictionary;
                        let dateTime;
                        let boolValue;
                        if (keyValuePair.Value === null)
                        {
                            claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(keyValuePair.Key, $.$$.System.String.Empty, "JSON_NULL"/*JsonClaimValueTypes.JsonNull*/, issuer, issuer));
                        }
                        else if ($.$is(keyValuePair.Value, $.$$.System.String, { set $v(v){ str = v; } }))
                        {
                            claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(keyValuePair.Key, str, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.GetClaimValueType(keyValuePair.Key, str), issuer, issuer));
                        }
                        else if ($.$is(keyValuePair.Value, $.$stj.System.Text.Json.JsonElement, { set $v(v){ j = v; } }))
                        {
                            $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.AddClaimsFromJsonElement(keyValuePair.Key, issuer, j, claims);
                        }
                        else if ($.$is(keyValuePair.Value, $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Object), { set $v(v){ objects = v; } }))
                        {
                            this.AddListofObjects(keyValuePair.Key, objects, claims, issuer);
                        }
                        else if ($.$is(keyValuePair.Value, $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object), { set $v(v){ dictionary = v; } }))
                        {
                            var $en5 = dictionary.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var item = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    if (item.Value !== null)
                                    {
                                        claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(keyValuePair.Key, "{" + item.Key + ":" + $.$$.System.Object.ToString.call(item.Value) + "}", $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.GetClaimValueType(item.Key, item.Value), issuer, issuer));
                                    }
                                }
                            }
                        }
                        else if ($.$is(keyValuePair.Value, $.$$.System.DateTime, { set $v(v){ dateTime = v; } }))
                        {
                            claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(keyValuePair.Key, dateTime.ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#dateTime"/*ClaimValueTypes.DateTime*/, issuer, issuer));
                        }
                        else if ($.$is(keyValuePair.Value, $.$$.System.Boolean, { set $v(v){ boolValue = v; } }))
                        {
                            if (boolValue)
                            {
                                claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(keyValuePair.Key, "true", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                            }
                            else 
                            {
                                claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(keyValuePair.Key, "false", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                            }
                        }
                        else if (keyValuePair.Value !== null)
                        {
                            /*var*/ let value = keyValuePair.Value;
                            /*var*/ let claimValueType = $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.GetClaimValueType(keyValuePair.Key, value);
                            let formattable;
                            if ($.$is(value, $.$$.System.IFormattable, { set $v(v){ formattable = v; } }))
                            {
                                claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(keyValuePair.Key, formattable.System$IFormattable$ToString(null, $.$$.System.Globalization.CultureInfo.InvariantCulture), claimValueType, issuer, issuer));
                            }
                            else 
                            {
                                claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(keyValuePair.Key, $.$$.System.Object.ToString.call(value), claimValueType, issuer, issuer));
                            }
                        }
                    }
                }
                return claims;
            }
            //--TRIMMABLE-BOUNDARY-END(158914117753)
            
            //--TRIMMABLE-BOUNDARY-START(124554379385)
            /*void */ AddListofObjects(/*string*/ key, /*IEnumerable<object>*/ objects, /*List<Claim>*/ claims, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554379385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                var $en2 = objects.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var obj = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        let claimValue;
                        let boolValue;
                        let dateTimeValue;
                        let jsonElement;
                        let innerObjects;
                        if ($.$is(obj, $.$$.System.String, { set $v(v){ claimValue = v; } }))
                        {
                            claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(key, claimValue, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, issuer, issuer));
                        }
                        else if ($.$is(obj, $.$$.System.Boolean, { set $v(v){ boolValue = v; } }))
                        {
                            if (boolValue)
                            {
                                claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(key, "true", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                            }
                            else 
                            {
                                claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(key, "false", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                            }
                        }
                        else if ($.$is(obj, $.$$.System.DateTime, { set $v(v){ dateTimeValue = v; } }))
                        {
                            claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(key, dateTimeValue.ToString$2("o", $.$$.System.Globalization.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#dateTime"/*ClaimValueTypes.DateTime*/, issuer, issuer));
                        }
                        else if ($.$is(obj, $.$stj.System.Text.Json.JsonElement, { set $v(v){ jsonElement = v; } }))
                        {
                            claims.Add($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet.CreateClaimFromJsonElement(key, issuer, jsonElement));
                        }
                        else if ($.$is(obj, $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Object), { set $v(v){ innerObjects = v; } }))
                        {
                            this.AddListofObjects(key, innerObjects, claims, issuer);
                        }
                        else 
                        {
                            /*var*/ let claimValueType = $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.GetClaimValueType(key, obj);
                            let formattable;
                            if ($.$is(obj, $.$$.System.IFormattable, { set $v(v){ formattable = v; } }))
                            {
                                claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(key, formattable.System$IFormattable$ToString(null, $.$$.System.Globalization.CultureInfo.InvariantCulture), claimValueType, issuer, issuer));
                            }
                            else 
                            {
                                claims.Add(new $.$ssc.System.Security.Claims.Claim().$ctor$5(key, $.$$.System.Object.ToString.call(obj), claimValueType, issuer, issuer));
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554379385)
            
            //--TRIMMABLE-BOUNDARY-START(107374510201)
            static /*void */ AddClaimsFromJsonElement(/*string*/ claimType, /*string*/ issuer, /*JsonElement*/ jsonElement, /*List<Claim>*/ claims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374510201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jsonElement.ValueKind === 2/*JsonValueKind.Array*/)
                {
                    var $en3 = jsonElement.EnumerateArray().GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var element = $en3.Current;
                        {
                            claims.Add($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet.CreateClaimFromJsonElement(claimType, issuer, element));
                        }
                    }
                }
                else 
                {
                    claims.Add($.$mij.Microsoft.IdentityModel.JsonWebTokens.JsonClaimSet.CreateClaimFromJsonElement(claimType, issuer, jsonElement));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374510201)
            
            //--TRIMMABLE-BOUNDARY-START(98784575609)
            /*void */ AddClaim(/*Claim*/ claim)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784575609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (claim === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentNullException().$ctor$19("claim"));
                }
                this.AddClaims($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$ssc.System.Security.Claims.Claim), [claim], [-1], null));
            }
            //--TRIMMABLE-BOUNDARY-END(98784575609)
            
            //--TRIMMABLE-BOUNDARY-START(103079542905)
            /*void */ AddClaims(/*IEnumerable<Claim>*/ claims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079542905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (claims === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentNullException().$ctor$19("claims"));
                }
                var $en2 = claims.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var claim = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (claim === null)
                        {
                            continue;
                        }
                        /*string*/ let jsonClaimType = claim.Type;
                        /*object*/ let jsonClaimValue = $.$$.System.String.Equals$5.call(claim.ValueType, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/) ? claim.Value : $.$mit.Microsoft.IdentityModel.Tokens.TokenUtilities.GetClaimValueUsingValueType(claim);
                        /*object*/ let existingValue;
                        if (this.TryGetValue(jsonClaimType, $.$ref(() => existingValue, ($v) => existingValue = $v, $.$$.System.Object)))
                        {
                            /*IList<object>*/ let claimValues = $.$as(existingValue, $.$$.System.Collections.Generic.IList$$($.$$.System.Object));
                            if (claimValues === null)
                            {
                                claimValues = new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                                claimValues.System$Collections$Generic$ICollection$$$Add(existingValue, [$.$$.System.Object]);
                                this.set_Item(jsonClaimType, claimValues);
                            }
                            claimValues.System$Collections$Generic$ICollection$$$Add(jsonClaimValue, [$.$$.System.Object]);
                        }
                        else 
                        {
                            this.set_Item(jsonClaimType, jsonClaimValue);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079542905)
            
            //--TRIMMABLE-BOUNDARY-START(111669477497)
            /*void */ AddDictionaryClaims(/*IDictionary<string, object>*/ claimsCollection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669477497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (claimsCollection === null)
                {
                    throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogExceptionMessage$1(new $.$$.System.ArgumentNullException().$ctor$19("claimsCollection"));
                }
                var $en2 = claimsCollection.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var kvp = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.set_Item(kvp.Key, kvp.Value);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669477497)
            
            //--TRIMMABLE-BOUNDARY-START(356482613369)
            static /*string */ GetClaimValueType(/*string*/ claimType, /*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356482613369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return "JSON_NULL"/*JsonClaimValueTypes.JsonNull*/;
                }
                /*Type*/ let objType = $.$$.System.Object.GetType.call(value);
                let str;
                if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                {
                    return $.$mij.Microsoft.IdentityModel.JsonWebTokens.JwtTokenUtilities.GetStringClaimValueType(str, claimType);
                }
                else if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Int32.$type))
                {
                    return "http://www.w3.org/2001/XMLSchema#integer32"/*ClaimValueTypes.Integer32*/;
                }
                else if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Int64.$type))
                {
                    return "http://www.w3.org/2001/XMLSchema#integer64"/*ClaimValueTypes.Integer64*/;
                }
                else if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Boolean.$type))
                {
                    return "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/;
                }
                else if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Double.$type))
                {
                    return "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/;
                }
                else if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.DateTime.$type))
                {
                    return "http://www.w3.org/2001/XMLSchema#dateTime"/*ClaimValueTypes.DateTime*/;
                }
                else if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Single.$type))
                {
                    return "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/;
                }
                else if ($.$$.System.Type.op_Equality$1(objType, $.$$.System.Decimal.$type))
                {
                    return "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/;
                }
                else if (value === null)
                {
                    return "JSON_NULL"/*JsonClaimValueTypes.JsonNull*/;
                }
                else if ($.$$.System.Type.op_Equality$1(objType, $.$stj.System.Text.Json.JsonElement.$type))
                {
                    return "JSON"/*JsonClaimValueTypes.Json*/;
                }
                return $.$$.System.Type.ToString.call(objType);
            }
            //--TRIMMABLE-BOUNDARY-END(356482613369)
            
            //--TRIMMABLE-BOUNDARY-START(373662482553)
            /*string */ GetStandardClaim(/*string*/ claimType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662482553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object*/ let value;
                if (this.TryGetValue(claimType, $.$ref(() => value, ($v) => value = $v, $.$$.System.Object)))
                {
                    if (value === null)
                    {
                        return null;
                    }
                    let str;
                    if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                    {
                        return str;
                    }
                    return $.$$.System.String.Empty;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(373662482553)
            
            //--TRIMMABLE-BOUNDARY-START(360777580665)
            /*int? */ GetIntClaim(/*string*/ claimType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777580665);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object*/ let claimValue;
                if (this.TryGetValue(claimType, $.$ref(() => claimValue, ($v) => claimValue = $v, $.$$.System.Object)))
                {
                    /*int*/ let i = 0;
                    if ($.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.TryConvertToInt(claimValue, $.$ref(() => i, ($v) => i = $v, $.$$.System.Int32)))
                    {
                        return i;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(360777580665)
            
            //--TRIMMABLE-BOUNDARY-START(369367515257)
            /*long? */ GetLongClaim(/*string*/ claimType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367515257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object*/ let claimValue;
                if (this.TryGetValue(claimType, $.$ref(() => claimValue, ($v) => claimValue = $v, $.$$.System.Object)))
                {
                    /*long*/ let l = 0n;
                    if ($.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.TryConvertToLong(claimValue, $.$ref(() => l, ($v) => l = $v, $.$$.System.Int64)))
                    {
                        return l;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(369367515257)
            
            //--TRIMMABLE-BOUNDARY-START(416612155513)
            static /*bool */ TryConvertToInt(/*object*/ value, /*ref int*/ outVal)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612155513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                outVal.$v = 0;
                try
                {
                    let i;
                    if ($.$is(value, $.$$.System.Int32, { set $v(v){ i = v; } }))
                    {
                        outVal.$v = i;
                        return true;
                    }
                    let str;
                    if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                    {
                        /*int*/ let result;
                        if ($.$$.System.Int32.TryParse$8(str, $.$ref(() => result, ($v) => result = $v, $.$$.System.Int32)))
                        {
                            outVal.$v = result;
                            return true;
                        }
                    }
                    outVal.$v = $.$$.System.Convert.ToInt32$5($.$$.System.Math.Truncate$1($.$$.System.Convert.ToDouble$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture)));
                    return true;
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.FormatException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$$.System.OverflowException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$$.System.InvalidCastException)
                    {
                        return false;
                    }
                    else
                    {
                        throw $e;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(416612155513)
            
            //--TRIMMABLE-BOUNDARY-START(420907122809)
            static /*bool */ TryConvertToLong(/*object*/ value, /*ref long*/ outVal)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420907122809);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                outVal.$v = 0n;
                try
                {
                    let l;
                    if ($.$is(value, $.$$.System.Int64, { set $v(v){ l = v; } }))
                    {
                        outVal.$v = l;
                        return true;
                    }
                    let str;
                    if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                    {
                        /*long*/ let result;
                        if ($.$$.System.Int64.TryParse$8(str, $.$ref(() => result, ($v) => result = $v, $.$$.System.Int64)))
                        {
                            outVal.$v = result;
                            return true;
                        }
                    }
                    outVal.$v = $.$$.System.Convert.ToInt64$5($.$$.System.Math.Truncate$1($.$$.System.Convert.ToDouble$9(value, $.$$.System.Globalization.CultureInfo.InvariantCulture)));
                    return true;
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.FormatException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$$.System.OverflowException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$$.System.InvalidCastException)
                    {
                        return false;
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(420907122809)
            
            //--TRIMMABLE-BOUNDARY-START(365072547961)
            /*List<string> */ GetListOfClaims(/*string*/ claimType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365072547961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<string>*/ let claimValues = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                /*object*/ let value;
                if (!this.TryGetValue(claimType, $.$ref(() => value, ($v) => value = $v, $.$$.System.Object)))
                {
                    return claimValues;
                }
                let jsonElement;
                let str;
                let values;
                if ($.$is(value, $.$stj.System.Text.Json.JsonElement, { set $v(v){ jsonElement = v; } }))
                {
                    /*List<string>*/ let list;
                    if ($.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.TryCreateTypeFromJsonElement($.$$.System.Collections.Generic.List$$($.$$.System.String), jsonElement, $.$ref(() => list, ($v) => list = $v, $.$$.System.Collections.Generic.List$$($.$$.System.String))))
                    {
                        return list;
                    }
                }
                else if ($.$is(value, $.$$.System.String, { set $v(v){ str = v; } }))
                {
                    claimValues.Add(str);
                }
                else if ($.$is(value, $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Object), { set $v(v){ values = v; } }))
                {
                    var $en3 = values.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var item = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            claimValues.Add($.$$.System.Object.ToString.call(item));
                        }
                    }
                }
                else 
                {
                    claimValues.Add($.$$.System.Object.ToString.call(value));
                }
                return claimValues;
            }
            //--TRIMMABLE-BOUNDARY-END(365072547961)
            
            //--TRIMMABLE-BOUNDARY-START(408022220921)
            /*string */ SerializeToJson()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022220921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let memoryStream = null;
                try
                {
                    memoryStream = new $.$$.System.IO.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let writer = null;
                    try
                    {
                        writer = new $.$stj.System.Text.Json.Utf8JsonWriter().$ctor$2(memoryStream, (() =>
                        {
                            //new $.$stj.System.Text.Json.JsonWriterOptions()
                            const $t1 = $.$stj.System.Text.Json.JsonWriterOptions;
                            const $i1 = new $t1();
                            $i1.Encoder = $.$stew.System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                            return $i1;
                        })());
                        writer.WriteStartObject();
                        $.$mit.Microsoft.IdentityModel.Tokens.Json.JsonSerializerPrimitives.WriteObjects($.$ref(() => writer, ($v) => writer = $v, $.$stj.System.Text.Json.Utf8JsonWriter), this);
                        writer.WriteEndObject();
                        writer.Flush();
                        return $.$$.System.Text.Encoding.UTF8.GetString(memoryStream.GetBuffer(), 0, $.$cast(memoryStream.Length, $.$$.System.Int32));
                    }
                    finally
                    {
                        {
                            writer?.Dispose();
                        }
                    }
                }
                finally
                {
                    memoryStream?.System$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(408022220921)
            
            //--TRIMMABLE-BOUNDARY-START(146029215865)
            static /*JwtPayload */ Base64UrlDeserialize(/*string*/ base64UrlEncodedJsonString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029215865);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(base64UrlEncodedJsonString, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("base64UrlEncodedJsonString") });
                return $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoding.Decode$5($.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload, base64UrlEncodedJsonString, 0, base64UrlEncodedJsonString.length, new ($.$$.System.Func$$$$($.$typeArray($.$$.System.Byte), $.$$.System.Int32, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload))().$ctor($.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload, $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.CreatePayload));
            }
            //--TRIMMABLE-BOUNDARY-END(146029215865)
            
            //--TRIMMABLE-BOUNDARY-START(150324183161)
            /*string */ Base64UrlEncode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324183161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mit.Microsoft.IdentityModel.Tokens.Base64UrlEncoder.Encode$3(this.SerializeToJson());
            }
            //--TRIMMABLE-BOUNDARY-END(150324183161)
            
            //--TRIMMABLE-BOUNDARY-START(171799019641)
            static /*JwtPayload */ Deserialize(/*string*/ jsonString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799019641);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(jsonString, () => { throw $.$mil.Microsoft.IdentityModel.Logging.LogHelper.LogArgumentNullException("jsonString") });
                /*byte[]*/ let bytes = $.$$.System.Text.Encoding.UTF8.GetBytes$8(jsonString);
                return $.$sitj.System.IdentityModel.Tokens.Jwt.JwtPayload.CreatePayload(bytes, bytes.length);
            }
            //--TRIMMABLE-BOUNDARY-END(171799019641)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180196985)
                this._expDateTime = null;
                //--TRIMMABLE-BOUNDARY-END(17180196985)
                
                //--TRIMMABLE-BOUNDARY-START(25770131577)
                this._iatDateTime = null;
                //--TRIMMABLE-BOUNDARY-END(25770131577)
                
                //--TRIMMABLE-BOUNDARY-START(47244968057)
                this._nbfDateTime = null;
                //--TRIMMABLE-BOUNDARY-END(47244968057)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(163209085049)
                    this.ClassName = "System.IdentityModel.Tokens.Jwt.JwtPayload";
                    //--TRIMMABLE-BOUNDARY-END(163209085049)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 327801;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94489608313),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197568823417,
        "f": 50331649
      },
      "n": "Actort",
      "d": 327801,
      "h": 94489608313,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489608313),
//--TRIMMABLE-BOUNDARY-START(90194641017),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188978888825,
        "f": 50331649
      },
      "n": "Acr",
      "d": 327801,
      "h": 90194641017,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194641017),
//--TRIMMABLE-BOUNDARY-START(128849346681),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206158758009,
        "f": 50331649
      },
      "n": "Amr",
      "d": 327801,
      "h": 128849346681,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849346681),
//--TRIMMABLE-BOUNDARY-START(137439281273),
    {
      "p": $.$typeNullable($.$$.System.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223338627193,
        "f": 50331649
      },
      "n": "AuthTime",
      "d": 327801,
      "h": 137439281273,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439281273),
//--TRIMMABLE-BOUNDARY-START(133144313977),
    {
      "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214748692601,
        "f": 50331649
      },
      "n": "Aud",
      "d": 327801,
      "h": 133144313977,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144313977),
//--TRIMMABLE-BOUNDARY-START(141734248569),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231928561785,
        "f": 50331649
      },
      "n": "Azp",
      "d": 327801,
      "h": 141734248569,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141734248569),
//--TRIMMABLE-BOUNDARY-START(154619150457),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240518496377,
        "f": 50331649
      },
      "n": "CHash",
      "d": 327801,
      "h": 154619150457,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619150457),
//--TRIMMABLE-BOUNDARY-START(176093986937),
    {
      "p": $.$typeNullable($.$$.System.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257698365561,
        "f": 50331649
      },
      "n": "Exp",
      "d": 327801,
      "h": 176093986937,
      "f": 2097153,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "\u0060int? JwtPayload.Exp\u0060 is deprecated and will be removed in a future release. Use \u0060long? JwtPayload.Expiration\u0060 instead. For more information, see https://aka.ms/IdentityModel/7-breaking-changes",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176093986937),
//--TRIMMABLE-BOUNDARY-START(180388954233),
    {
      "p": $.$typeNullable($.$$.System.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266288300153,
        "f": 50331649
      },
      "n": "Expiration",
      "d": 327801,
      "h": 180388954233,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180388954233),
//--TRIMMABLE-BOUNDARY-START(390842351737),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 300648038521,
        "f": 50331649
      },
      "n": "Jti",
      "d": 327801,
      "h": 390842351737,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(390842351737),
//--TRIMMABLE-BOUNDARY-START(377957449849),
    {
      "p": $.$typeNullable($.$$.System.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274878234745,
        "f": 50331649
      },
      "n": "Iat",
      "d": 327801,
      "h": 377957449849,
      "f": 2097153,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "\u0060int? JwtPayload.Iat\u0060 is deprecated and will be removed in a future release. Use \u0060DateTime JwtPayload.IssuedAt\u0060 instead. For more information, see https://aka.ms/IdentityModel/7-breaking-changes",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(377957449849),
//--TRIMMABLE-BOUNDARY-START(382252417145),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283468169337,
        "f": 50331649
      },
      "n": "Iss",
      "d": 327801,
      "h": 382252417145,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(382252417145),
//--TRIMMABLE-BOUNDARY-START(395137319033),
    {
      "p": $.$typeNullable($.$$.System.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 309237973113,
        "f": 50331649
      },
      "n": "Nbf",
      "d": 327801,
      "h": 395137319033,
      "f": 2097153,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "\u0060int? JwtPayload.Nbf\u0060 is deprecated and will be removed in a future release. Use \u0060long? JwtPayload.NotBefore\u0060 instead. For more information, see https://aka.ms/IdentityModel/7-breaking-changes",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(395137319033),
//--TRIMMABLE-BOUNDARY-START(399432286329),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 317827907705,
        "f": 50331649
      },
      "n": "Nonce",
      "d": 327801,
      "h": 399432286329,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(399432286329),
//--TRIMMABLE-BOUNDARY-START(403727253625),
    {
      "p": $.$typeNullable($.$$.System.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 326417842297,
        "f": 50331649
      },
      "n": "NotBefore",
      "d": 327801,
      "h": 403727253625,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(403727253625),
//--TRIMMABLE-BOUNDARY-START(412317188217),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 335007776889,
        "f": 50331649
      },
      "n": "Sub",
      "d": 327801,
      "h": 412317188217,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(412317188217),
//--TRIMMABLE-BOUNDARY-START(425202090105),
    {
      "p": 65273857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 343597711481,
        "f": 50331649
      },
      "n": "ValidFrom",
      "d": 327801,
      "h": 425202090105,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(425202090105),
//--TRIMMABLE-BOUNDARY-START(429497057401),
    {
      "p": 65273857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 352187646073,
        "f": 50331649
      },
      "n": "ValidTo",
      "d": 327801,
      "h": 429497057401,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(429497057401),
//--TRIMMABLE-BOUNDARY-START(386547384441),
    {
      "p": 65273857,
      "g": {
        "r": 0,
        "d": 0,
        "h": 292058103929,
        "f": 50331649
      },
      "n": "IssuedAt",
      "d": 327801,
      "h": 386547384441,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(386547384441),
//--TRIMMABLE-BOUNDARY-START(158914117753),
    {
      "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249108430969,
        "f": 50331777
      },
      "n": "Claims",
      "d": 327801,
      "h": 158914117753,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(158914117753)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(167504052345),
    {
      "r": 327801,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "CreatePayload",
      "d": 327801,
      "h": 167504052345,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(167504052345),
//--TRIMMABLE-BOUNDARY-START(120259412089),
    {
      "r": 65537,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        }
      ],
      "n": "AddFirstPriorityClaims",
      "o": "@$1",
      "d": 327801,
      "h": 120259412089,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(120259412089),
//--TRIMMABLE-BOUNDARY-START(115964444793),
    {
      "r": 65537,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "audiences",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        }
      ],
      "n": "AddFirstPriorityClaims",
      "d": 327801,
      "h": 115964444793,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(115964444793),
//--TRIMMABLE-BOUNDARY-START(124554379385),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "objects",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Object).$h
        },
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim).$h
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "AddListofObjects",
      "d": 327801,
      "h": 124554379385,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124554379385),
//--TRIMMABLE-BOUNDARY-START(107374510201),
    {
      "r": 65537,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        },
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "jsonElement",
          "p": 2097236
        },
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.List$$($.$ssc.System.Security.Claims.Claim).$h
        }
      ],
      "n": "AddClaimsFromJsonElement",
      "d": 327801,
      "h": 107374510201,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(107374510201),
//--TRIMMABLE-BOUNDARY-START(98784575609),
    {
      "r": 65537,
      "p": [
        {
          "n": "claim",
          "p": 131141
        }
      ],
      "n": "AddClaim",
      "d": 327801,
      "h": 98784575609,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784575609),
//--TRIMMABLE-BOUNDARY-START(103079542905),
    {
      "r": 65537,
      "p": [
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h
        }
      ],
      "n": "AddClaims",
      "d": 327801,
      "h": 103079542905,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079542905),
//--TRIMMABLE-BOUNDARY-START(111669477497),
    {
      "r": 65537,
      "p": [
        {
          "n": "claimsCollection",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        }
      ],
      "n": "AddDictionaryClaims",
      "d": 327801,
      "h": 111669477497,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(111669477497),
//--TRIMMABLE-BOUNDARY-START(356482613369),
    {
      "r": 1310721,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "GetClaimValueType",
      "d": 327801,
      "h": 356482613369,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(356482613369),
//--TRIMMABLE-BOUNDARY-START(373662482553),
    {
      "r": 1310721,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        }
      ],
      "n": "GetStandardClaim",
      "d": 327801,
      "h": 373662482553,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(373662482553),
//--TRIMMABLE-BOUNDARY-START(360777580665),
    {
      "r": $.$typeNullable($.$$.System.Int32).$h,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        }
      ],
      "n": "GetIntClaim",
      "d": 327801,
      "h": 360777580665,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(360777580665),
//--TRIMMABLE-BOUNDARY-START(369367515257),
    {
      "r": $.$typeNullable($.$$.System.Int64).$h,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        }
      ],
      "n": "GetLongClaim",
      "d": 327801,
      "h": 369367515257,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(369367515257),
//--TRIMMABLE-BOUNDARY-START(416612155513),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "outVal",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "TryConvertToInt",
      "d": 327801,
      "h": 416612155513,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(416612155513),
//--TRIMMABLE-BOUNDARY-START(420907122809),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "outVal",
          "p": 917505,
          "f": 4
        }
      ],
      "n": "TryConvertToLong",
      "d": 327801,
      "h": 420907122809,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(420907122809),
//--TRIMMABLE-BOUNDARY-START(365072547961),
    {
      "r": $.$$.System.Collections.Generic.List$$($.$$.System.String).$h,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        }
      ],
      "n": "GetListOfClaims",
      "d": 327801,
      "h": 365072547961,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(365072547961),
//--TRIMMABLE-BOUNDARY-START(408022220921),
    {
      "r": 1310721,
      "n": "SerializeToJson",
      "d": 327801,
      "h": 408022220921,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(408022220921),
//--TRIMMABLE-BOUNDARY-START(146029215865),
    {
      "r": 327801,
      "p": [
        {
          "n": "base64UrlEncodedJsonString",
          "p": 1310721
        }
      ],
      "n": "Base64UrlDeserialize",
      "d": 327801,
      "h": 146029215865,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(146029215865),
//--TRIMMABLE-BOUNDARY-START(150324183161),
    {
      "r": 1310721,
      "n": "Base64UrlEncode",
      "d": 327801,
      "h": 150324183161,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(150324183161),
//--TRIMMABLE-BOUNDARY-START(171799019641),
    {
      "r": 327801,
      "p": [
        {
          "n": "jsonString",
          "p": 1310721
        }
      ],
      "n": "Deserialize",
      "d": 327801,
      "h": 171799019641,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(171799019641)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(163209085049),
    {
      "t": 1310721,
      "n": "ClassName",
      "d": 327801,
      "h": 163209085049,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163209085049),
//--TRIMMABLE-BOUNDARY-START(4295295097),
    {
      "t": $.$$.System.Collections.Generic.List$$($.$$.System.String).$h,
      "n": "_audiences",
      "d": 327801,
      "h": 4295295097,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295295097),
//--TRIMMABLE-BOUNDARY-START(8590262393),
    {
      "t": 1310721,
      "n": "_azp",
      "d": 327801,
      "h": 8590262393,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590262393),
//--TRIMMABLE-BOUNDARY-START(12885229689),
    {
      "t": $.$typeNullable($.$$.System.Int64).$h,
      "n": "_exp",
      "d": 327801,
      "h": 12885229689,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885229689),
//--TRIMMABLE-BOUNDARY-START(17180196985),
    {
      "t": $.$typeNullable($.$$.System.DateTime).$h,
      "n": "_expDateTime",
      "d": 327801,
      "h": 17180196985,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17180196985),
//--TRIMMABLE-BOUNDARY-START(21475164281),
    {
      "t": $.$typeNullable($.$$.System.Int64).$h,
      "n": "_iat",
      "d": 327801,
      "h": 21475164281,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21475164281),
//--TRIMMABLE-BOUNDARY-START(25770131577),
    {
      "t": $.$typeNullable($.$$.System.DateTime).$h,
      "n": "_iatDateTime",
      "d": 327801,
      "h": 25770131577,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(25770131577),
//--TRIMMABLE-BOUNDARY-START(30065098873),
    {
      "t": 1310721,
      "n": "_id",
      "d": 327801,
      "h": 30065098873,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(30065098873),
//--TRIMMABLE-BOUNDARY-START(34360066169),
    {
      "t": 1310721,
      "n": "_iss",
      "d": 327801,
      "h": 34360066169,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(34360066169),
//--TRIMMABLE-BOUNDARY-START(38655033465),
    {
      "t": 1310721,
      "n": "_jti",
      "d": 327801,
      "h": 38655033465,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(38655033465),
//--TRIMMABLE-BOUNDARY-START(42950000761),
    {
      "t": $.$typeNullable($.$$.System.Int64).$h,
      "n": "_nbf",
      "d": 327801,
      "h": 42950000761,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(42950000761),
//--TRIMMABLE-BOUNDARY-START(47244968057),
    {
      "t": $.$typeNullable($.$$.System.DateTime).$h,
      "n": "_nbfDateTime",
      "d": 327801,
      "h": 47244968057,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(47244968057),
//--TRIMMABLE-BOUNDARY-START(51539935353),
    {
      "t": 1310721,
      "n": "_sub",
      "d": 327801,
      "h": 51539935353,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(51539935353),
//--TRIMMABLE-BOUNDARY-START(55834902649),
    {
      "t": 1310721,
      "n": "_tid",
      "d": 327801,
      "h": 55834902649,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(55834902649)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(60129869945),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 327801,
      "h": 60129869945,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129869945),
//--TRIMMABLE-BOUNDARY-START(64424837241),
    {
      "p": [
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$11",
      "d": 327801,
      "h": 64424837241,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424837241),
//--TRIMMABLE-BOUNDARY-START(81604706425),
    {
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$15",
      "d": 327801,
      "h": 81604706425,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604706425),
//--TRIMMABLE-BOUNDARY-START(77309739129),
    {
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$14",
      "d": 327801,
      "h": 77309739129,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309739129),
//--TRIMMABLE-BOUNDARY-START(68719804537),
    {
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audiences",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h
        },
        {
          "n": "claimsCollection",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$12",
      "d": 327801,
      "h": 68719804537,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719804537),
//--TRIMMABLE-BOUNDARY-START(85899673721),
    {
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "audiences",
          "p": $.$$.System.Collections.Generic.IList$$($.$$.System.String).$h
        },
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h
        },
        {
          "n": "claimsCollection",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$16",
      "d": 327801,
      "h": 85899673721,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899673721),
//--TRIMMABLE-BOUNDARY-START(73014771833),
    {
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "claims",
          "p": $.$$.System.Collections.Generic.IEnumerable$$($.$ssc.System.Security.Claims.Claim).$h
        },
        {
          "n": "claimsCollection",
          "p": $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.System.DateTime).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$13",
      "d": 327801,
      "h": 73014771833,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014771833)
  ],
  "i": [$.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object).$h,$.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,62521345,62390273,$.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)).$h,62652417,157483009,157220865
  ],
  "h": 327801
}; }
            static get $b() { return $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.String, $.$$.System.Object); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.IDictionary$$$($.$$.System.String, $.$$.System.Object), $.$$.System.Collections.Generic.ICollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IDictionary, $.$$.System.Collections.ICollection, $.$$.System.Collections.Generic.IReadOnlyDictionary$$$($.$$.System.String, $.$$.System.Object), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.Generic.IEnumerable$$($.$$.System.Collections.Generic.KeyValuePair$$$($.$$.System.String, $.$$.System.Object)), $.$$.System.Collections.IEnumerable, $.$$.System.Runtime.Serialization.ISerializable, $.$$.System.Runtime.Serialization.IDeserializationCallback ]; }
            static get $fullName() { return `System.IdentityModel.Tokens.Jwt.JwtPayload`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327801)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.IdentityModel.Abstractions", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Collections.Immutable", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.Microsoft.IdentityModel.Logging", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Logging", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.IdentityModel.Tokens", "NetJs.Microsoft.IdentityModel.JsonWebTokens"))
//--TRIMMABLE-BOUNDARY-END(121)
