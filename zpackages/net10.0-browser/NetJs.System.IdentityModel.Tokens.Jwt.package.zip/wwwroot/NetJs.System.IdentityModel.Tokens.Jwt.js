
//--TRIMMABLE-BOUNDARY-START(128)
(async function () {
(function ($global, $, $$, $mia, $sc, $sm, $snv, $spu, $sr, $sdt, $st, $scc, $sris, $sl, $mwp, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sci, $sim, $srm, $sds, $srn, $sfa, $sscr, $snsc, $stc, $snq, $srij, $snh, $mil, $scm, $so, $sre, $srei, $srel, $srp, $sle, $mxdi, $med, $mexla, $mep, $scp, $scs, $sdp, $srw, $srl, $srsf, $str, $sdts, $spx, $spxl, $sxxd, $sct, $sca, $meo, $mexl, $sipl, $stew, $stj, $mit, $mij) {
    "use strict";
    let _;
    let $XZONsf;
    
    
    
	$.$asm(
    "NetJs.System.IdentityModel.Tokens.Jwt", 
    {
  "h": 128,
  "f": "System.IdentityModel.Tokens.Jwt",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "Serviceable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": true,
          "t": 262145
        }
      ]
    },
    {
      "t": 140836865,
      "c": 8730771457,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    },
    {
      "t": 130416641,
      "c": 13015318529,
      "a": [
        {
          "v": "System.IdentityModel.Tokens.Jwt.Tests, PublicKey=0024000004800000940000000602000000240000525341310004000001000100b5fc90e7027f67871e773a8fde8938c81dd402ba65b9201d60593e96c492651e889cc13f1415ebb53fac1131ae0bd333c5ee6021672d9718ea31a8aebd0da0072f25d87dba6fc90ffd598ed4da35e44c398c454307e8e33b8426143daec9f596836f97c8f74750e5975c64e2189f45def46b2a2b1247adc3652bf5c308055da9",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsTrimmable",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "IsAotCompatible",
          "t": 1310721
        },
        {
          "v": "True",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "Microsoft Corporation.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107347969,
      "c": 8697282561,
      "a": [
        {
          "v": "\u00A9 Microsoft Corporation. All rights reserved.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107610113,
      "c": 8697544705,
      "a": [
        {
          "v": "Includes types that provide support for creating, serializing and validating JSON Web Tokens. As of IdentityModel 7x, this is a legacy tool that should be replaced with Microsoft.IdentityModel.JsonWebTokens.",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "9.0.0.26312",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "Microsoft IdentityModel",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.IdentityModel.Tokens.Jwt",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108003329,
      "c": 12992905217,
      "a": [
        {
          "v": "RepositoryUrl",
          "t": 1310721
        },
        {
          "v": "https://github.com/AzureAD/azure-activedirectory-identitymodel-extensions-for-dotnet",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65664)
        $asm.$cls(`$sitj.SITJ.JsonClaimValueTypes`, ($self) => class JsonClaimValueTypes
        {
            //--TRIMMABLE-BOUNDARY-START(4295032960)
            /*string*/ static Json = null;
            //--TRIMMABLE-BOUNDARY-END(4295032960)
            
            //--TRIMMABLE-BOUNDARY-START(8590000256)
            /*string*/ static JsonArray = null;
            //--TRIMMABLE-BOUNDARY-END(8590000256)
            
            //--TRIMMABLE-BOUNDARY-START(12884967552)
            /*string*/ static JsonNull = null;
            //--TRIMMABLE-BOUNDARY-END(12884967552)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295032960)
                    this.Json = "JSON";
                    //--TRIMMABLE-BOUNDARY-END(4295032960)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590000256)
                    this.JsonArray = "JSON_ARRAY";
                    //--TRIMMABLE-BOUNDARY-END(8590000256)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12884967552)
                    this.JsonNull = "JSON_NULL";
                    //--TRIMMABLE-BOUNDARY-END(12884967552)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 65664;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295032960),
    {
      "t": 1310721,
      "n": "Json",
      "d": 65664,
      "h": 4295032960,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295032960),
//--TRIMMABLE-BOUNDARY-START(8590000256),
    {
      "t": 1310721,
      "n": "JsonArray",
      "d": 65664,
      "h": 8590000256,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590000256),
//--TRIMMABLE-BOUNDARY-START(12884967552),
    {
      "t": 1310721,
      "n": "JsonNull",
      "d": 65664,
      "h": 12884967552,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12884967552)
  ],
  "h": 65664
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IdentityModel.Tokens.Jwt.JsonClaimValueTypes`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IdentityModel${separator}Tokens${separator}Jwt${separator}JsonClaimValueTypes`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65664)
        
        

        //--TRIMMABLE-BOUNDARY-START(721024)
        $asm.$cls(`$sitj.SITJ.LogMessages`, ($self) => class LogMessages
        {
            //--TRIMMABLE-BOUNDARY-START(4295688320)
            /*string*/ static IDX12401 = null;
            //--TRIMMABLE-BOUNDARY-END(4295688320)
            
            //--TRIMMABLE-BOUNDARY-START(8590655616)
            /*string*/ static IDX12706 = null;
            //--TRIMMABLE-BOUNDARY-END(8590655616)
            
            //--TRIMMABLE-BOUNDARY-START(12885622912)
            /*string*/ static IDX12709 = null;
            //--TRIMMABLE-BOUNDARY-END(12885622912)
            
            //--TRIMMABLE-BOUNDARY-START(17180590208)
            /*string*/ static IDX12710 = null;
            //--TRIMMABLE-BOUNDARY-END(17180590208)
            
            //--TRIMMABLE-BOUNDARY-START(21475557504)
            /*string*/ static IDX12711 = null;
            //--TRIMMABLE-BOUNDARY-END(21475557504)
            
            //--TRIMMABLE-BOUNDARY-START(25770524800)
            /*string*/ static IDX12712 = null;
            //--TRIMMABLE-BOUNDARY-END(25770524800)
            
            //--TRIMMABLE-BOUNDARY-START(30065492096)
            /*string*/ static IDX12713 = null;
            //--TRIMMABLE-BOUNDARY-END(30065492096)
            
            //--TRIMMABLE-BOUNDARY-START(34360459392)
            /*string*/ static IDX12714 = null;
            //--TRIMMABLE-BOUNDARY-END(34360459392)
            
            //--TRIMMABLE-BOUNDARY-START(38655426688)
            /*string*/ static IDX12715 = null;
            //--TRIMMABLE-BOUNDARY-END(38655426688)
            
            //--TRIMMABLE-BOUNDARY-START(42950393984)
            /*string*/ static IDX12720 = null;
            //--TRIMMABLE-BOUNDARY-END(42950393984)
            
            //--TRIMMABLE-BOUNDARY-START(47245361280)
            /*string*/ static IDX12721 = null;
            //--TRIMMABLE-BOUNDARY-END(47245361280)
            
            //--TRIMMABLE-BOUNDARY-START(51540328576)
            /*string*/ static IDX12722 = null;
            //--TRIMMABLE-BOUNDARY-END(51540328576)
            
            //--TRIMMABLE-BOUNDARY-START(55835295872)
            /*string*/ static IDX12723 = null;
            //--TRIMMABLE-BOUNDARY-END(55835295872)
            
            //--TRIMMABLE-BOUNDARY-START(60130263168)
            /*string*/ static IDX12729 = null;
            //--TRIMMABLE-BOUNDARY-END(60130263168)
            
            //--TRIMMABLE-BOUNDARY-START(64425230464)
            /*string*/ static IDX12730 = null;
            //--TRIMMABLE-BOUNDARY-END(64425230464)
            
            //--TRIMMABLE-BOUNDARY-START(68720197760)
            /*string*/ static IDX12735 = null;
            //--TRIMMABLE-BOUNDARY-END(68720197760)
            
            //--TRIMMABLE-BOUNDARY-START(73015165056)
            /*string*/ static IDX12736 = null;
            //--TRIMMABLE-BOUNDARY-END(73015165056)
            
            //--TRIMMABLE-BOUNDARY-START(77310132352)
            /*string*/ static IDX12737 = null;
            //--TRIMMABLE-BOUNDARY-END(77310132352)
            
            //--TRIMMABLE-BOUNDARY-START(81605099648)
            /*string*/ static IDX12738 = null;
            //--TRIMMABLE-BOUNDARY-END(81605099648)
            
            //--TRIMMABLE-BOUNDARY-START(85900066944)
            /*string*/ static IDX12739 = null;
            //--TRIMMABLE-BOUNDARY-END(85900066944)
            
            //--TRIMMABLE-BOUNDARY-START(90195034240)
            /*string*/ static IDX12740 = null;
            //--TRIMMABLE-BOUNDARY-END(90195034240)
            
            //--TRIMMABLE-BOUNDARY-START(94490001536)
            /*string*/ static IDX12741 = null;
            //--TRIMMABLE-BOUNDARY-END(94490001536)
            
            //--TRIMMABLE-BOUNDARY-START(98784968832)
            /*string*/ static IDX12742 = null;
            //--TRIMMABLE-BOUNDARY-END(98784968832)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295688320)
                    this.IDX12401 = "IDX12401: Expires: '{0}' must be after NotBefore: '{1}'.";
                    //--TRIMMABLE-BOUNDARY-END(4295688320)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590655616)
                    this.IDX12706 = "IDX12706: '{0}' can only write SecurityTokens of type: '{1}', 'token' type is: '{2}'.";
                    //--TRIMMABLE-BOUNDARY-END(8590655616)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885622912)
                    this.IDX12709 = "IDX12709: CanReadToken() returned false. JWT is not well formed.\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'.";
                    //--TRIMMABLE-BOUNDARY-END(12885622912)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180590208)
                    this.IDX12710 = "IDX12710: Only a single 'Actor' is supported. Found second claim of type: '{0}', value: '{1}'";
                    //--TRIMMABLE-BOUNDARY-END(17180590208)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475557504)
                    this.IDX12711 = "IDX12711: actor.BootstrapContext is not a string AND actor.BootstrapContext is not a JWT";
                    //--TRIMMABLE-BOUNDARY-END(21475557504)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770524800)
                    this.IDX12712 = "IDX12712: actor.BootstrapContext is null. Creating the token using actor.Claims.";
                    //--TRIMMABLE-BOUNDARY-END(25770524800)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065492096)
                    this.IDX12713 = "IDX12713: Creating actor value using actor.BootstrapContext(as string)";
                    //--TRIMMABLE-BOUNDARY-END(30065492096)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360459392)
                    this.IDX12714 = "IDX12714: Creating actor value using actor.BootstrapContext.rawData";
                    //--TRIMMABLE-BOUNDARY-END(34360459392)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655426688)
                    this.IDX12715 = "IDX12715: Creating actor value by writing the JwtSecurityToken created from actor.BootstrapContext";
                    //--TRIMMABLE-BOUNDARY-END(38655426688)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950393984)
                    this.IDX12720 = "IDX12720: Token string does not match the token formats: JWE (header.encryptedKey.iv.ciphertext.tag) or JWS (header.payload.signature)";
                    //--TRIMMABLE-BOUNDARY-END(42950393984)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245361280)
                    this.IDX12721 = "IDX12721: Creating JwtSecurityToken: Issuer: '{0}', Audience: '{1}'";
                    //--TRIMMABLE-BOUNDARY-END(47245361280)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540328576)
                    this.IDX12722 = "IDX12722: Creating security token from the header: '{0}', payload: '{1}'.";
                    //--TRIMMABLE-BOUNDARY-END(51540328576)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835295872)
                    this.IDX12723 = "IDX12723: Unable to decode the payload '{0}' as Base64Url encoded string.";
                    //--TRIMMABLE-BOUNDARY-END(55835295872)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130263168)
                    this.IDX12729 = "IDX12729: Unable to decode the header '{0}' as Base64Url encoded string.";
                    //--TRIMMABLE-BOUNDARY-END(60130263168)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425230464)
                    this.IDX12730 = "IDX12730: Failed to create the token encryption provider.";
                    //--TRIMMABLE-BOUNDARY-END(64425230464)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720197760)
                    this.IDX12735 = "IDX12735: If JwtSecurityToken.InnerToken != null, then JwtSecurityToken.Header.EncryptingCredentials must be set.";
                    //--TRIMMABLE-BOUNDARY-END(68720197760)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015165056)
                    this.IDX12736 = "IDX12736: JwtSecurityToken.SigningCredentials is not supported when JwtSecurityToken.InnerToken is set.";
                    //--TRIMMABLE-BOUNDARY-END(73015165056)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310132352)
                    this.IDX12737 = "IDX12737: EncryptingCredentials set on JwtSecurityToken.InnerToken is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(77310132352)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81605099648)
                    this.IDX12738 = "IDX12738: Header.Cty != null, assuming JWS. Cty: '{0}'.";
                    //--TRIMMABLE-BOUNDARY-END(81605099648)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85900066944)
                    this.IDX12739 = "IDX12739: JWT has three segments but is not in proper JWS format.";
                    //--TRIMMABLE-BOUNDARY-END(85900066944)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90195034240)
                    this.IDX12740 = "IDX12740: JWT has five segments but is not in proper JWE format.";
                    //--TRIMMABLE-BOUNDARY-END(90195034240)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94490001536)
                    this.IDX12741 = "IDX12741: JWT must have three segments (JWS) or five segments (JWE).";
                    //--TRIMMABLE-BOUNDARY-END(94490001536)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784968832)
                    this.IDX12742 = "IDX12742: ''{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation.";
                    //--TRIMMABLE-BOUNDARY-END(98784968832)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 721024;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688320),
    {
      "t": 1310721,
      "n": "IDX12401",
      "d": 721024,
      "h": 4295688320,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295688320),
//--TRIMMABLE-BOUNDARY-START(8590655616),
    {
      "t": 1310721,
      "n": "IDX12706",
      "d": 721024,
      "h": 8590655616,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590655616),
//--TRIMMABLE-BOUNDARY-START(12885622912),
    {
      "t": 1310721,
      "n": "IDX12709",
      "d": 721024,
      "h": 12885622912,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885622912),
//--TRIMMABLE-BOUNDARY-START(17180590208),
    {
      "t": 1310721,
      "n": "IDX12710",
      "d": 721024,
      "h": 17180590208,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180590208),
//--TRIMMABLE-BOUNDARY-START(21475557504),
    {
      "t": 1310721,
      "n": "IDX12711",
      "d": 721024,
      "h": 21475557504,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475557504),
//--TRIMMABLE-BOUNDARY-START(25770524800),
    {
      "t": 1310721,
      "n": "IDX12712",
      "d": 721024,
      "h": 25770524800,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25770524800),
//--TRIMMABLE-BOUNDARY-START(30065492096),
    {
      "t": 1310721,
      "n": "IDX12713",
      "d": 721024,
      "h": 30065492096,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065492096),
//--TRIMMABLE-BOUNDARY-START(34360459392),
    {
      "t": 1310721,
      "n": "IDX12714",
      "d": 721024,
      "h": 34360459392,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34360459392),
//--TRIMMABLE-BOUNDARY-START(38655426688),
    {
      "t": 1310721,
      "n": "IDX12715",
      "d": 721024,
      "h": 38655426688,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38655426688),
//--TRIMMABLE-BOUNDARY-START(42950393984),
    {
      "t": 1310721,
      "n": "IDX12720",
      "d": 721024,
      "h": 42950393984,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42950393984),
//--TRIMMABLE-BOUNDARY-START(47245361280),
    {
      "t": 1310721,
      "n": "IDX12721",
      "d": 721024,
      "h": 47245361280,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47245361280),
//--TRIMMABLE-BOUNDARY-START(51540328576),
    {
      "t": 1310721,
      "n": "IDX12722",
      "d": 721024,
      "h": 51540328576,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51540328576),
//--TRIMMABLE-BOUNDARY-START(55835295872),
    {
      "t": 1310721,
      "n": "IDX12723",
      "d": 721024,
      "h": 55835295872,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55835295872),
//--TRIMMABLE-BOUNDARY-START(60130263168),
    {
      "t": 1310721,
      "n": "IDX12729",
      "d": 721024,
      "h": 60130263168,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60130263168),
//--TRIMMABLE-BOUNDARY-START(64425230464),
    {
      "t": 1310721,
      "n": "IDX12730",
      "d": 721024,
      "h": 64425230464,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64425230464),
//--TRIMMABLE-BOUNDARY-START(68720197760),
    {
      "t": 1310721,
      "n": "IDX12735",
      "d": 721024,
      "h": 68720197760,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68720197760),
//--TRIMMABLE-BOUNDARY-START(73015165056),
    {
      "t": 1310721,
      "n": "IDX12736",
      "d": 721024,
      "h": 73015165056,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73015165056),
//--TRIMMABLE-BOUNDARY-START(77310132352),
    {
      "t": 1310721,
      "n": "IDX12737",
      "d": 721024,
      "h": 77310132352,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77310132352),
//--TRIMMABLE-BOUNDARY-START(81605099648),
    {
      "t": 1310721,
      "n": "IDX12738",
      "d": 721024,
      "h": 81605099648,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81605099648),
//--TRIMMABLE-BOUNDARY-START(85900066944),
    {
      "t": 1310721,
      "n": "IDX12739",
      "d": 721024,
      "h": 85900066944,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85900066944),
//--TRIMMABLE-BOUNDARY-START(90195034240),
    {
      "t": 1310721,
      "n": "IDX12740",
      "d": 721024,
      "h": 90195034240,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90195034240),
//--TRIMMABLE-BOUNDARY-START(94490001536),
    {
      "t": 1310721,
      "n": "IDX12741",
      "d": 721024,
      "h": 94490001536,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94490001536),
//--TRIMMABLE-BOUNDARY-START(98784968832),
    {
      "t": 1310721,
      "n": "IDX12742",
      "d": 721024,
      "h": 98784968832,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98784968832)
  ],
  "h": 721024
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IdentityModel.Tokens.Jwt.LogMessages`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IdentityModel${separator}Tokens${separator}Jwt${separator}LogMessages`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721024)
        
        

        //--TRIMMABLE-BOUNDARY-START(131200)
        $asm.$cls(`$sitj.SITJ.JwtConstants`, ($self) => class JwtConstants
        {
            //--TRIMMABLE-BOUNDARY-START(8590065792)
            /*string*/ static HeaderType = null;
            //--TRIMMABLE-BOUNDARY-END(8590065792)
            
            //--TRIMMABLE-BOUNDARY-START(12885033088)
            /*string*/ static HeaderTypeAlt = null;
            //--TRIMMABLE-BOUNDARY-END(12885033088)
            
            //--TRIMMABLE-BOUNDARY-START(38654836864)
            /*string*/ static TokenType = null;
            //--TRIMMABLE-BOUNDARY-END(38654836864)
            
            //--TRIMMABLE-BOUNDARY-START(42949804160)
            /*string*/ static TokenTypeAlt = null;
            //--TRIMMABLE-BOUNDARY-END(42949804160)
            
            //--TRIMMABLE-BOUNDARY-START(17180000384)
            /*string*/ static JsonCompactSerializationRegex = null;
            //--TRIMMABLE-BOUNDARY-END(17180000384)
            
            //--TRIMMABLE-BOUNDARY-START(21474967680)
            /*string*/ static JweCompactSerializationRegex = null;
            //--TRIMMABLE-BOUNDARY-END(21474967680)
            
            //--TRIMMABLE-BOUNDARY-START(25769934976)
            /*int*/ static JweSegmentCount = 5;
            //--TRIMMABLE-BOUNDARY-END(25769934976)
            
            //--TRIMMABLE-BOUNDARY-START(30064902272)
            /*int*/ static JwsSegmentCount = 3;
            //--TRIMMABLE-BOUNDARY-END(30064902272)
            
            //--TRIMMABLE-BOUNDARY-START(34359869568)
            /*int*/ static MaxJwtSegmentCount = 5;
            //--TRIMMABLE-BOUNDARY-END(34359869568)
            
            //--TRIMMABLE-BOUNDARY-START(4295098496)
            /*string*/ static DirectKeyUseAlg = null;
            //--TRIMMABLE-BOUNDARY-END(4295098496)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590065792)
                    this.HeaderType = "JWT";
                    //--TRIMMABLE-BOUNDARY-END(8590065792)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885033088)
                    this.HeaderTypeAlt = "http://openid.net/specs/jwt/1.0";
                    //--TRIMMABLE-BOUNDARY-END(12885033088)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654836864)
                    this.TokenType = "JWT";
                    //--TRIMMABLE-BOUNDARY-END(38654836864)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949804160)
                    this.TokenTypeAlt = "urn:ietf:params:oauth:token-type:jwt";
                    //--TRIMMABLE-BOUNDARY-END(42949804160)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180000384)
                    this.JsonCompactSerializationRegex = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*$";
                    //--TRIMMABLE-BOUNDARY-END(17180000384)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21474967680)
                    this.JweCompactSerializationRegex = "^[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]*\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+\\.[A-Za-z0-9-_]+$";
                    //--TRIMMABLE-BOUNDARY-END(21474967680)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295098496)
                    this.DirectKeyUseAlg = "dir";
                    //--TRIMMABLE-BOUNDARY-END(4295098496)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 131200;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590065792),
    {
      "t": 1310721,
      "n": "HeaderType",
      "d": 131200,
      "h": 8590065792,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590065792),
//--TRIMMABLE-BOUNDARY-START(12885033088),
    {
      "t": 1310721,
      "n": "HeaderTypeAlt",
      "d": 131200,
      "h": 12885033088,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885033088),
//--TRIMMABLE-BOUNDARY-START(38654836864),
    {
      "t": 1310721,
      "n": "TokenType",
      "d": 131200,
      "h": 38654836864,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38654836864),
//--TRIMMABLE-BOUNDARY-START(42949804160),
    {
      "t": 1310721,
      "n": "TokenTypeAlt",
      "d": 131200,
      "h": 42949804160,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42949804160),
//--TRIMMABLE-BOUNDARY-START(17180000384),
    {
      "t": 1310721,
      "n": "JsonCompactSerializationRegex",
      "d": 131200,
      "h": 17180000384,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180000384),
//--TRIMMABLE-BOUNDARY-START(21474967680),
    {
      "t": 1310721,
      "n": "JweCompactSerializationRegex",
      "d": 131200,
      "h": 21474967680,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21474967680),
//--TRIMMABLE-BOUNDARY-START(25769934976),
    {
      "t": 655361,
      "n": "JweSegmentCount",
      "d": 131200,
      "h": 25769934976,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25769934976),
//--TRIMMABLE-BOUNDARY-START(30064902272),
    {
      "t": 655361,
      "n": "JwsSegmentCount",
      "d": 131200,
      "h": 30064902272,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30064902272),
//--TRIMMABLE-BOUNDARY-START(34359869568),
    {
      "t": 655361,
      "n": "MaxJwtSegmentCount",
      "d": 131200,
      "h": 34359869568,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34359869568),
//--TRIMMABLE-BOUNDARY-START(4295098496),
    {
      "t": 1310721,
      "n": "DirectKeyUseAlg",
      "d": 131200,
      "h": 4295098496,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295098496)
  ],
  "h": 131200
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IdentityModel.Tokens.Jwt.JwtConstants`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IdentityModel${separator}Tokens${separator}Jwt${separator}JwtConstants`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131200)
        
        

        //--TRIMMABLE-BOUNDARY-START(524416)
        $asm.$cls(`$sitj.SITJ.JwtSecurityTokenConverter`, ($self) => class JwtSecurityTokenConverter
        {
            //--TRIMMABLE-BOUNDARY-START(4295491712)
            static /*JwtSecurityToken */ Convert(/*JsonWebToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (token === null)
                {
                    throw new $.$$.S.ArgumentNullException().$ctor$19("token");
                }
                if (token.InnerToken !== null)
                {
                    /*var*/ let jwtSecurityToken = new $.$sitj.SITJ.JwtSecurityToken().$ctor$6(token.EncodedToken);
                    jwtSecurityToken.InnerToken = new $.$sitj.SITJ.JwtSecurityToken().$ctor$6(token.InnerToken.EncodedToken);
                    return jwtSecurityToken;
                }
                else if (!$.$$.S.String.IsNullOrEmpty(token.EncodedToken))
                {
                    return new $.$sitj.SITJ.JwtSecurityToken().$ctor$6(token.EncodedToken);
                }
                throw new $.$$.S.ArgumentException().$ctor$14("token.EncodedToken must be set");
            }
            //--TRIMMABLE-BOUNDARY-END(4295491712)
            
            static $h = 524416;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295491712),
    {
      "r": 458880,
      "p": [
        {
          "n": "token",
          "p": 262271
        }
      ],
      "n": "Convert",
      "d": 524416,
      "h": 4295491712,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295491712)
  ],
  "h": 524416
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IdentityModel.Tokens.Jwt.JwtSecurityTokenConverter`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IdentityModel${separator}Tokens${separator}Jwt${separator}JwtSecurityTokenConverter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524416)
        
        

        //--TRIMMABLE-BOUNDARY-START(393344)
        $asm.$str(`$sitj.SITJ.JwtRegisteredClaimNames`, ($self) => class JwtRegisteredClaimNames extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(12885295232)
            /*string*/ static Act = null;
            //--TRIMMABLE-BOUNDARY-END(12885295232)
            
            //--TRIMMABLE-BOUNDARY-START(17180262528)
            /*string*/ static Actort = null;
            //--TRIMMABLE-BOUNDARY-END(17180262528)
            
            //--TRIMMABLE-BOUNDARY-START(8590327936)
            /*string*/ static Acr = null;
            //--TRIMMABLE-BOUNDARY-END(8590327936)
            
            //--TRIMMABLE-BOUNDARY-START(25770197120)
            /*string*/ static Alg = null;
            //--TRIMMABLE-BOUNDARY-END(25770197120)
            
            //--TRIMMABLE-BOUNDARY-START(30065164416)
            /*string*/ static Amr = null;
            //--TRIMMABLE-BOUNDARY-END(30065164416)
            
            //--TRIMMABLE-BOUNDARY-START(21475229824)
            /*string*/ static Address = null;
            //--TRIMMABLE-BOUNDARY-END(21475229824)
            
            //--TRIMMABLE-BOUNDARY-START(34360131712)
            /*string*/ static AtHash = null;
            //--TRIMMABLE-BOUNDARY-END(34360131712)
            
            //--TRIMMABLE-BOUNDARY-START(38655099008)
            /*string*/ static Aud = null;
            //--TRIMMABLE-BOUNDARY-END(38655099008)
            
            //--TRIMMABLE-BOUNDARY-START(42950066304)
            /*string*/ static AuthTime = null;
            //--TRIMMABLE-BOUNDARY-END(42950066304)
            
            //--TRIMMABLE-BOUNDARY-START(47245033600)
            /*string*/ static Azp = null;
            //--TRIMMABLE-BOUNDARY-END(47245033600)
            
            //--TRIMMABLE-BOUNDARY-START(51540000896)
            /*string*/ static Birthdate = null;
            //--TRIMMABLE-BOUNDARY-END(51540000896)
            
            //--TRIMMABLE-BOUNDARY-START(55834968192)
            /*string*/ static CHash = null;
            //--TRIMMABLE-BOUNDARY-END(55834968192)
            
            //--TRIMMABLE-BOUNDARY-START(60129935488)
            /*string*/ static Email = null;
            //--TRIMMABLE-BOUNDARY-END(60129935488)
            
            //--TRIMMABLE-BOUNDARY-START(64424902784)
            /*string*/ static EmailVerified = null;
            //--TRIMMABLE-BOUNDARY-END(64424902784)
            
            //--TRIMMABLE-BOUNDARY-START(68719870080)
            /*string*/ static Exp = null;
            //--TRIMMABLE-BOUNDARY-END(68719870080)
            
            //--TRIMMABLE-BOUNDARY-START(77309804672)
            /*string*/ static Gender = null;
            //--TRIMMABLE-BOUNDARY-END(77309804672)
            
            //--TRIMMABLE-BOUNDARY-START(73014837376)
            /*string*/ static FamilyName = null;
            //--TRIMMABLE-BOUNDARY-END(73014837376)
            
            //--TRIMMABLE-BOUNDARY-START(81604771968)
            /*string*/ static GivenName = null;
            //--TRIMMABLE-BOUNDARY-END(81604771968)
            
            //--TRIMMABLE-BOUNDARY-START(85899739264)
            /*string*/ static Iat = null;
            //--TRIMMABLE-BOUNDARY-END(85899739264)
            
            //--TRIMMABLE-BOUNDARY-START(90194706560)
            /*string*/ static Iss = null;
            //--TRIMMABLE-BOUNDARY-END(90194706560)
            
            //--TRIMMABLE-BOUNDARY-START(94489673856)
            /*string*/ static Jti = null;
            //--TRIMMABLE-BOUNDARY-END(94489673856)
            
            //--TRIMMABLE-BOUNDARY-START(98784641152)
            /*string*/ static Locale = null;
            //--TRIMMABLE-BOUNDARY-END(98784641152)
            
            //--TRIMMABLE-BOUNDARY-START(103079608448)
            /*string*/ static MiddleName = null;
            //--TRIMMABLE-BOUNDARY-END(103079608448)
            
            //--TRIMMABLE-BOUNDARY-START(107374575744)
            /*string*/ static Name = null;
            //--TRIMMABLE-BOUNDARY-END(107374575744)
            
            //--TRIMMABLE-BOUNDARY-START(111669543040)
            /*string*/ static NameId = null;
            //--TRIMMABLE-BOUNDARY-END(111669543040)
            
            //--TRIMMABLE-BOUNDARY-START(120259477632)
            /*string*/ static Nickname = null;
            //--TRIMMABLE-BOUNDARY-END(120259477632)
            
            //--TRIMMABLE-BOUNDARY-START(124554444928)
            /*string*/ static Nonce = null;
            //--TRIMMABLE-BOUNDARY-END(124554444928)
            
            //--TRIMMABLE-BOUNDARY-START(115964510336)
            /*string*/ static Nbf = null;
            //--TRIMMABLE-BOUNDARY-END(115964510336)
            
            //--TRIMMABLE-BOUNDARY-START(128849412224)
            /*string*/ static PhoneNumber = null;
            //--TRIMMABLE-BOUNDARY-END(128849412224)
            
            //--TRIMMABLE-BOUNDARY-START(133144379520)
            /*string*/ static PhoneNumberVerified = null;
            //--TRIMMABLE-BOUNDARY-END(133144379520)
            
            //--TRIMMABLE-BOUNDARY-START(137439346816)
            /*string*/ static Picture = null;
            //--TRIMMABLE-BOUNDARY-END(137439346816)
            
            //--TRIMMABLE-BOUNDARY-START(146029281408)
            /*string*/ static Prn = null;
            //--TRIMMABLE-BOUNDARY-END(146029281408)
            
            //--TRIMMABLE-BOUNDARY-START(141734314112)
            /*string*/ static PreferredUsername = null;
            //--TRIMMABLE-BOUNDARY-END(141734314112)
            
            //--TRIMMABLE-BOUNDARY-START(150324248704)
            /*string*/ static Profile = null;
            //--TRIMMABLE-BOUNDARY-END(150324248704)
            
            //--TRIMMABLE-BOUNDARY-START(154619216000)
            /*string*/ static Sid = null;
            //--TRIMMABLE-BOUNDARY-END(154619216000)
            
            //--TRIMMABLE-BOUNDARY-START(158914183296)
            /*string*/ static Sub = null;
            //--TRIMMABLE-BOUNDARY-END(158914183296)
            
            //--TRIMMABLE-BOUNDARY-START(163209150592)
            /*string*/ static Typ = null;
            //--TRIMMABLE-BOUNDARY-END(163209150592)
            
            //--TRIMMABLE-BOUNDARY-START(167504117888)
            /*string*/ static UniqueName = null;
            //--TRIMMABLE-BOUNDARY-END(167504117888)
            
            //--TRIMMABLE-BOUNDARY-START(171799085184)
            /*string*/ static UpdatedAt = null;
            //--TRIMMABLE-BOUNDARY-END(171799085184)
            
            //--TRIMMABLE-BOUNDARY-START(176094052480)
            /*string*/ static Website = null;
            //--TRIMMABLE-BOUNDARY-END(176094052480)
            
            //--TRIMMABLE-BOUNDARY-START(180389019776)
            /*string*/ static ZoneInfo = null;
            //--TRIMMABLE-BOUNDARY-END(180389019776)
            
            //--TRIMMABLE-BOUNDARY-START(4295360640)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360640)
            
            //--TRIMMABLE-BOUNDARY-START(4295360640)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295360640)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(12885295232)
                    this.Act = "act";
                    //--TRIMMABLE-BOUNDARY-END(12885295232)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180262528)
                    this.Actort = "actort";
                    //--TRIMMABLE-BOUNDARY-END(17180262528)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590327936)
                    this.Acr = "acr";
                    //--TRIMMABLE-BOUNDARY-END(8590327936)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770197120)
                    this.Alg = "alg";
                    //--TRIMMABLE-BOUNDARY-END(25770197120)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065164416)
                    this.Amr = "amr";
                    //--TRIMMABLE-BOUNDARY-END(30065164416)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475229824)
                    this.Address = "address";
                    //--TRIMMABLE-BOUNDARY-END(21475229824)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360131712)
                    this.AtHash = "at_hash";
                    //--TRIMMABLE-BOUNDARY-END(34360131712)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655099008)
                    this.Aud = "aud";
                    //--TRIMMABLE-BOUNDARY-END(38655099008)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950066304)
                    this.AuthTime = "auth_time";
                    //--TRIMMABLE-BOUNDARY-END(42950066304)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245033600)
                    this.Azp = "azp";
                    //--TRIMMABLE-BOUNDARY-END(47245033600)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540000896)
                    this.Birthdate = "birthdate";
                    //--TRIMMABLE-BOUNDARY-END(51540000896)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834968192)
                    this.CHash = "c_hash";
                    //--TRIMMABLE-BOUNDARY-END(55834968192)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60129935488)
                    this.Email = "email";
                    //--TRIMMABLE-BOUNDARY-END(60129935488)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424902784)
                    this.EmailVerified = "email_verified";
                    //--TRIMMABLE-BOUNDARY-END(64424902784)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68719870080)
                    this.Exp = "exp";
                    //--TRIMMABLE-BOUNDARY-END(68719870080)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77309804672)
                    this.Gender = "gender";
                    //--TRIMMABLE-BOUNDARY-END(77309804672)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73014837376)
                    this.FamilyName = "family_name";
                    //--TRIMMABLE-BOUNDARY-END(73014837376)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81604771968)
                    this.GivenName = "given_name";
                    //--TRIMMABLE-BOUNDARY-END(81604771968)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899739264)
                    this.Iat = "iat";
                    //--TRIMMABLE-BOUNDARY-END(85899739264)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90194706560)
                    this.Iss = "iss";
                    //--TRIMMABLE-BOUNDARY-END(90194706560)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94489673856)
                    this.Jti = "jti";
                    //--TRIMMABLE-BOUNDARY-END(94489673856)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784641152)
                    this.Locale = "locale";
                    //--TRIMMABLE-BOUNDARY-END(98784641152)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079608448)
                    this.MiddleName = "middle_name";
                    //--TRIMMABLE-BOUNDARY-END(103079608448)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374575744)
                    this.Name = "name";
                    //--TRIMMABLE-BOUNDARY-END(107374575744)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669543040)
                    this.NameId = "nameid";
                    //--TRIMMABLE-BOUNDARY-END(111669543040)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259477632)
                    this.Nickname = "nickname";
                    //--TRIMMABLE-BOUNDARY-END(120259477632)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554444928)
                    this.Nonce = "nonce";
                    //--TRIMMABLE-BOUNDARY-END(124554444928)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964510336)
                    this.Nbf = "nbf";
                    //--TRIMMABLE-BOUNDARY-END(115964510336)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849412224)
                    this.PhoneNumber = "phone_number";
                    //--TRIMMABLE-BOUNDARY-END(128849412224)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144379520)
                    this.PhoneNumberVerified = "phone_number_verified";
                    //--TRIMMABLE-BOUNDARY-END(133144379520)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439346816)
                    this.Picture = "picture";
                    //--TRIMMABLE-BOUNDARY-END(137439346816)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029281408)
                    this.Prn = "prn";
                    //--TRIMMABLE-BOUNDARY-END(146029281408)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734314112)
                    this.PreferredUsername = "preferred_username";
                    //--TRIMMABLE-BOUNDARY-END(141734314112)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324248704)
                    this.Profile = "profile";
                    //--TRIMMABLE-BOUNDARY-END(150324248704)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154619216000)
                    this.Sid = "sid";
                    //--TRIMMABLE-BOUNDARY-END(154619216000)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158914183296)
                    this.Sub = "sub";
                    //--TRIMMABLE-BOUNDARY-END(158914183296)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163209150592)
                    this.Typ = "typ";
                    //--TRIMMABLE-BOUNDARY-END(163209150592)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167504117888)
                    this.UniqueName = "unique_name";
                    //--TRIMMABLE-BOUNDARY-END(167504117888)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171799085184)
                    this.UpdatedAt = "updated_at";
                    //--TRIMMABLE-BOUNDARY-END(171799085184)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176094052480)
                    this.Website = "website";
                    //--TRIMMABLE-BOUNDARY-END(176094052480)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180389019776)
                    this.ZoneInfo = "zoneinfo";
                    //--TRIMMABLE-BOUNDARY-END(180389019776)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 393344;
            static $z = 0;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885295232),
    {
      "t": 1310721,
      "n": "Act",
      "d": 393344,
      "h": 12885295232,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885295232),
//--TRIMMABLE-BOUNDARY-START(17180262528),
    {
      "t": 1310721,
      "n": "Actort",
      "d": 393344,
      "h": 17180262528,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180262528),
//--TRIMMABLE-BOUNDARY-START(8590327936),
    {
      "t": 1310721,
      "n": "Acr",
      "d": 393344,
      "h": 8590327936,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590327936),
//--TRIMMABLE-BOUNDARY-START(25770197120),
    {
      "t": 1310721,
      "n": "Alg",
      "d": 393344,
      "h": 25770197120,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770197120),
//--TRIMMABLE-BOUNDARY-START(30065164416),
    {
      "t": 1310721,
      "n": "Amr",
      "d": 393344,
      "h": 30065164416,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065164416),
//--TRIMMABLE-BOUNDARY-START(21475229824),
    {
      "t": 1310721,
      "n": "Address",
      "d": 393344,
      "h": 21475229824,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475229824),
//--TRIMMABLE-BOUNDARY-START(34360131712),
    {
      "t": 1310721,
      "n": "AtHash",
      "d": 393344,
      "h": 34360131712,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360131712),
//--TRIMMABLE-BOUNDARY-START(38655099008),
    {
      "t": 1310721,
      "n": "Aud",
      "d": 393344,
      "h": 38655099008,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655099008),
//--TRIMMABLE-BOUNDARY-START(42950066304),
    {
      "t": 1310721,
      "n": "AuthTime",
      "d": 393344,
      "h": 42950066304,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950066304),
//--TRIMMABLE-BOUNDARY-START(47245033600),
    {
      "t": 1310721,
      "n": "Azp",
      "d": 393344,
      "h": 47245033600,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245033600),
//--TRIMMABLE-BOUNDARY-START(51540000896),
    {
      "t": 1310721,
      "n": "Birthdate",
      "d": 393344,
      "h": 51540000896,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540000896),
//--TRIMMABLE-BOUNDARY-START(55834968192),
    {
      "t": 1310721,
      "n": "CHash",
      "d": 393344,
      "h": 55834968192,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834968192),
//--TRIMMABLE-BOUNDARY-START(60129935488),
    {
      "t": 1310721,
      "n": "Email",
      "d": 393344,
      "h": 60129935488,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60129935488),
//--TRIMMABLE-BOUNDARY-START(64424902784),
    {
      "t": 1310721,
      "n": "EmailVerified",
      "d": 393344,
      "h": 64424902784,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64424902784),
//--TRIMMABLE-BOUNDARY-START(68719870080),
    {
      "t": 1310721,
      "n": "Exp",
      "d": 393344,
      "h": 68719870080,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68719870080),
//--TRIMMABLE-BOUNDARY-START(77309804672),
    {
      "t": 1310721,
      "n": "Gender",
      "d": 393344,
      "h": 77309804672,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77309804672),
//--TRIMMABLE-BOUNDARY-START(73014837376),
    {
      "t": 1310721,
      "n": "FamilyName",
      "d": 393344,
      "h": 73014837376,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73014837376),
//--TRIMMABLE-BOUNDARY-START(81604771968),
    {
      "t": 1310721,
      "n": "GivenName",
      "d": 393344,
      "h": 81604771968,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81604771968),
//--TRIMMABLE-BOUNDARY-START(85899739264),
    {
      "t": 1310721,
      "n": "Iat",
      "d": 393344,
      "h": 85899739264,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899739264),
//--TRIMMABLE-BOUNDARY-START(90194706560),
    {
      "t": 1310721,
      "n": "Iss",
      "d": 393344,
      "h": 90194706560,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90194706560),
//--TRIMMABLE-BOUNDARY-START(94489673856),
    {
      "t": 1310721,
      "n": "Jti",
      "d": 393344,
      "h": 94489673856,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94489673856),
//--TRIMMABLE-BOUNDARY-START(98784641152),
    {
      "t": 1310721,
      "n": "Locale",
      "d": 393344,
      "h": 98784641152,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784641152),
//--TRIMMABLE-BOUNDARY-START(103079608448),
    {
      "t": 1310721,
      "n": "MiddleName",
      "d": 393344,
      "h": 103079608448,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103079608448),
//--TRIMMABLE-BOUNDARY-START(107374575744),
    {
      "t": 1310721,
      "n": "Name",
      "d": 393344,
      "h": 107374575744,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374575744),
//--TRIMMABLE-BOUNDARY-START(111669543040),
    {
      "t": 1310721,
      "n": "NameId",
      "d": 393344,
      "h": 111669543040,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669543040),
//--TRIMMABLE-BOUNDARY-START(120259477632),
    {
      "t": 1310721,
      "n": "Nickname",
      "d": 393344,
      "h": 120259477632,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259477632),
//--TRIMMABLE-BOUNDARY-START(124554444928),
    {
      "t": 1310721,
      "n": "Nonce",
      "d": 393344,
      "h": 124554444928,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554444928),
//--TRIMMABLE-BOUNDARY-START(115964510336),
    {
      "t": 1310721,
      "n": "Nbf",
      "d": 393344,
      "h": 115964510336,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964510336),
//--TRIMMABLE-BOUNDARY-START(128849412224),
    {
      "t": 1310721,
      "n": "PhoneNumber",
      "d": 393344,
      "h": 128849412224,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849412224),
//--TRIMMABLE-BOUNDARY-START(133144379520),
    {
      "t": 1310721,
      "n": "PhoneNumberVerified",
      "d": 393344,
      "h": 133144379520,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144379520),
//--TRIMMABLE-BOUNDARY-START(137439346816),
    {
      "t": 1310721,
      "n": "Picture",
      "d": 393344,
      "h": 137439346816,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439346816),
//--TRIMMABLE-BOUNDARY-START(146029281408),
    {
      "t": 1310721,
      "n": "Prn",
      "d": 393344,
      "h": 146029281408,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029281408),
//--TRIMMABLE-BOUNDARY-START(141734314112),
    {
      "t": 1310721,
      "n": "PreferredUsername",
      "d": 393344,
      "h": 141734314112,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734314112),
//--TRIMMABLE-BOUNDARY-START(150324248704),
    {
      "t": 1310721,
      "n": "Profile",
      "d": 393344,
      "h": 150324248704,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324248704),
//--TRIMMABLE-BOUNDARY-START(154619216000),
    {
      "t": 1310721,
      "n": "Sid",
      "d": 393344,
      "h": 154619216000,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619216000),
//--TRIMMABLE-BOUNDARY-START(158914183296),
    {
      "t": 1310721,
      "n": "Sub",
      "d": 393344,
      "h": 158914183296,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158914183296),
//--TRIMMABLE-BOUNDARY-START(163209150592),
    {
      "t": 1310721,
      "n": "Typ",
      "d": 393344,
      "h": 163209150592,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163209150592),
//--TRIMMABLE-BOUNDARY-START(167504117888),
    {
      "t": 1310721,
      "n": "UniqueName",
      "d": 393344,
      "h": 167504117888,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167504117888),
//--TRIMMABLE-BOUNDARY-START(171799085184),
    {
      "t": 1310721,
      "n": "UpdatedAt",
      "d": 393344,
      "h": 171799085184,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171799085184),
//--TRIMMABLE-BOUNDARY-START(176094052480),
    {
      "t": 1310721,
      "n": "Website",
      "d": 393344,
      "h": 176094052480,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176094052480),
//--TRIMMABLE-BOUNDARY-START(180389019776),
    {
      "t": 1310721,
      "n": "ZoneInfo",
      "d": 393344,
      "h": 180389019776,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180389019776)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360640),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 393344,
      "h": 4295360640,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360640)
  ],
  "h": 393344
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IdentityModel${separator}Tokens${separator}Jwt${separator}JwtRegisteredClaimNames`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393344)
        
        

        //--TRIMMABLE-BOUNDARY-START(262272)
        $asm.$str(`$sitj.SITJ.JwtHeaderParameterNames`, ($self) => class JwtHeaderParameterNames extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8590196864)
            /*string*/ static Alg = null;
            //--TRIMMABLE-BOUNDARY-END(8590196864)
            
            //--TRIMMABLE-BOUNDARY-START(21475098752)
            /*string*/ static Cty = null;
            //--TRIMMABLE-BOUNDARY-END(21475098752)
            
            //--TRIMMABLE-BOUNDARY-START(25770066048)
            /*string*/ static Enc = null;
            //--TRIMMABLE-BOUNDARY-END(25770066048)
            
            //--TRIMMABLE-BOUNDARY-START(34360000640)
            /*string*/ static IV = null;
            //--TRIMMABLE-BOUNDARY-END(34360000640)
            
            //--TRIMMABLE-BOUNDARY-START(38654967936)
            /*string*/ static Jku = null;
            //--TRIMMABLE-BOUNDARY-END(38654967936)
            
            //--TRIMMABLE-BOUNDARY-START(42949935232)
            /*string*/ static Jwk = null;
            //--TRIMMABLE-BOUNDARY-END(42949935232)
            
            //--TRIMMABLE-BOUNDARY-START(47244902528)
            /*string*/ static Kid = null;
            //--TRIMMABLE-BOUNDARY-END(47244902528)
            
            //--TRIMMABLE-BOUNDARY-START(51539869824)
            /*string*/ static Typ = null;
            //--TRIMMABLE-BOUNDARY-END(51539869824)
            
            //--TRIMMABLE-BOUNDARY-START(55834837120)
            /*string*/ static X5c = null;
            //--TRIMMABLE-BOUNDARY-END(55834837120)
            
            //--TRIMMABLE-BOUNDARY-START(60129804416)
            /*string*/ static X5t = null;
            //--TRIMMABLE-BOUNDARY-END(60129804416)
            
            //--TRIMMABLE-BOUNDARY-START(64424771712)
            /*string*/ static X5u = null;
            //--TRIMMABLE-BOUNDARY-END(64424771712)
            
            //--TRIMMABLE-BOUNDARY-START(68719739008)
            /*string*/ static Zip = null;
            //--TRIMMABLE-BOUNDARY-END(68719739008)
            
            //--TRIMMABLE-BOUNDARY-START(30065033344)
            /*string*/ static Epk = null;
            //--TRIMMABLE-BOUNDARY-END(30065033344)
            
            //--TRIMMABLE-BOUNDARY-START(12885164160)
            /*string*/ static Apu = null;
            //--TRIMMABLE-BOUNDARY-END(12885164160)
            
            //--TRIMMABLE-BOUNDARY-START(17180131456)
            /*string*/ static Apv = null;
            //--TRIMMABLE-BOUNDARY-END(17180131456)
            
            //--TRIMMABLE-BOUNDARY-START(4295229568)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229568)
            
            //--TRIMMABLE-BOUNDARY-START(4295229568)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295229568)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(8590196864)
                    this.Alg = "alg";
                    //--TRIMMABLE-BOUNDARY-END(8590196864)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475098752)
                    this.Cty = "cty";
                    //--TRIMMABLE-BOUNDARY-END(21475098752)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770066048)
                    this.Enc = "enc";
                    //--TRIMMABLE-BOUNDARY-END(25770066048)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360000640)
                    this.IV = "iv";
                    //--TRIMMABLE-BOUNDARY-END(34360000640)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38654967936)
                    this.Jku = "jku";
                    //--TRIMMABLE-BOUNDARY-END(38654967936)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42949935232)
                    this.Jwk = "jwk";
                    //--TRIMMABLE-BOUNDARY-END(42949935232)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47244902528)
                    this.Kid = "kid";
                    //--TRIMMABLE-BOUNDARY-END(47244902528)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51539869824)
                    this.Typ = "typ";
                    //--TRIMMABLE-BOUNDARY-END(51539869824)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55834837120)
                    this.X5c = "x5c";
                    //--TRIMMABLE-BOUNDARY-END(55834837120)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60129804416)
                    this.X5t = "x5t";
                    //--TRIMMABLE-BOUNDARY-END(60129804416)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64424771712)
                    this.X5u = "x5u";
                    //--TRIMMABLE-BOUNDARY-END(64424771712)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68719739008)
                    this.Zip = "zip";
                    //--TRIMMABLE-BOUNDARY-END(68719739008)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065033344)
                    this.Epk = "epk";
                    //--TRIMMABLE-BOUNDARY-END(30065033344)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885164160)
                    this.Apu = "apu";
                    //--TRIMMABLE-BOUNDARY-END(12885164160)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180131456)
                    this.Apv = "apv";
                    //--TRIMMABLE-BOUNDARY-END(17180131456)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 262272;
            static $z = 0;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590196864),
    {
      "t": 1310721,
      "n": "Alg",
      "d": 262272,
      "h": 8590196864,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590196864),
//--TRIMMABLE-BOUNDARY-START(21475098752),
    {
      "t": 1310721,
      "n": "Cty",
      "d": 262272,
      "h": 21475098752,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475098752),
//--TRIMMABLE-BOUNDARY-START(25770066048),
    {
      "t": 1310721,
      "n": "Enc",
      "d": 262272,
      "h": 25770066048,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770066048),
//--TRIMMABLE-BOUNDARY-START(34360000640),
    {
      "t": 1310721,
      "n": "IV",
      "d": 262272,
      "h": 34360000640,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360000640),
//--TRIMMABLE-BOUNDARY-START(38654967936),
    {
      "t": 1310721,
      "n": "Jku",
      "d": 262272,
      "h": 38654967936,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38654967936),
//--TRIMMABLE-BOUNDARY-START(42949935232),
    {
      "t": 1310721,
      "n": "Jwk",
      "d": 262272,
      "h": 42949935232,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42949935232),
//--TRIMMABLE-BOUNDARY-START(47244902528),
    {
      "t": 1310721,
      "n": "Kid",
      "d": 262272,
      "h": 47244902528,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47244902528),
//--TRIMMABLE-BOUNDARY-START(51539869824),
    {
      "t": 1310721,
      "n": "Typ",
      "d": 262272,
      "h": 51539869824,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51539869824),
//--TRIMMABLE-BOUNDARY-START(55834837120),
    {
      "t": 1310721,
      "n": "X5c",
      "d": 262272,
      "h": 55834837120,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834837120),
//--TRIMMABLE-BOUNDARY-START(60129804416),
    {
      "t": 1310721,
      "n": "X5t",
      "d": 262272,
      "h": 60129804416,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60129804416),
//--TRIMMABLE-BOUNDARY-START(64424771712),
    {
      "t": 1310721,
      "n": "X5u",
      "d": 262272,
      "h": 64424771712,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64424771712),
//--TRIMMABLE-BOUNDARY-START(68719739008),
    {
      "t": 1310721,
      "n": "Zip",
      "d": 262272,
      "h": 68719739008,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68719739008),
//--TRIMMABLE-BOUNDARY-START(30065033344),
    {
      "t": 1310721,
      "n": "Epk",
      "d": 262272,
      "h": 30065033344,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065033344),
//--TRIMMABLE-BOUNDARY-START(12885164160),
    {
      "t": 1310721,
      "n": "Apu",
      "d": 262272,
      "h": 12885164160,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885164160),
//--TRIMMABLE-BOUNDARY-START(17180131456),
    {
      "t": 1310721,
      "n": "Apv",
      "d": 262272,
      "h": 17180131456,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180131456)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229568),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 262272,
      "h": 4295229568,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229568)
  ],
  "h": 262272
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IdentityModel.Tokens.Jwt.JwtHeaderParameterNames`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IdentityModel${separator}Tokens${separator}Jwt${separator}JwtHeaderParameterNames`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262272)
        
        

        //--TRIMMABLE-BOUNDARY-START(458880)
        $asm.$cls(`$sitj.SITJ.JwtSecurityToken`, ($self) => class JwtSecurityToken extends $.$mit.MIT$1.SecurityToken
        {
            //--TRIMMABLE-BOUNDARY-START(4295426176)
            /*JwtPayload*/ _payload = null;
            //--TRIMMABLE-BOUNDARY-END(4295426176)
            
            //--TRIMMABLE-BOUNDARY-START(73014902912)
            $ctor$6(/*string*/ jwtEncodedString)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014902912);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.S.String.IsNullOrWhiteSpace(jwtEncodedString))
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("jwtEncodedString");
                    }
                    /*string[]*/ let tokenParts = $.$$.S.String.Split$3.call(jwtEncodedString, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Char), [/*.*/ 46], [-1], null), ((5/*JwtConstants.MaxJwtSegmentCount*/ + 1) | 0));
                    if (tokenParts.length === 3/*JwtConstants.JwsSegmentCount*/)
                    {
                        if (!$.$mij.MIJ.JwtTokenUtilities.RegexJws.IsMatch$9(jwtEncodedString))
                        {
                            throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenMalformedException().$ctor$22("IDX12739: JWT has three segments but is not in proper JWS format."/*LogMessages.IDX12739*/));
                        }
                    }
                    else if (tokenParts.length === 5/*JwtConstants.JweSegmentCount*/)
                    {
                        if (!$.$mij.MIJ.JwtTokenUtilities.RegexJwe.IsMatch$9(jwtEncodedString))
                        {
                            throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenMalformedException().$ctor$22("IDX12740: JWT has five segments but is not in proper JWE format."/*LogMessages.IDX12740*/));
                        }
                    }
                    else 
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenMalformedException().$ctor$22("IDX12741: JWT must have three segments (JWS) or five segments (JWE)."/*LogMessages.IDX12741*/));
                    }
                    this.Decode(tokenParts, jwtEncodedString);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73014902912)
            
            //--TRIMMABLE-BOUNDARY-START(55835033728)
            $ctor$2(/*JwtHeader*/ header, /*JwtPayload*/ payload, /*string*/ rawHeader, /*string*/ rawPayload, /*string*/ rawSignature)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55835033728);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (header === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("header");
                    }
                    if (payload === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("payload");
                    }
                    if ($.$$.S.String.IsNullOrWhiteSpace(rawHeader))
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("rawHeader");
                    }
                    if ($.$$.S.String.IsNullOrWhiteSpace(rawPayload))
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("rawPayload");
                    }
                    if (rawSignature === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("rawSignature");
                    }
                    this.Header = header;
                    this.Payload = payload;
                    this.RawData = $.$$.S.String.Concat$10($.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1([ rawHeader, ".", rawPayload, ".", rawSignature ]));
                    this.RawHeader = rawHeader;
                    this.RawPayload = rawPayload;
                    this.RawSignature = rawSignature;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55835033728)
            
            //--TRIMMABLE-BOUNDARY-START(64424968320)
            $ctor$4(/*JwtHeader*/ header, /*JwtSecurityToken*/ innerToken, /*string*/ rawHeader, /*string*/ rawEncryptedKey, /*string*/ rawInitializationVector, /*string*/ rawCiphertext, /*string*/ rawAuthenticationTag)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424968320);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (header === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("header");
                    }
                    if (innerToken === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("innerToken");
                    }
                    if (rawEncryptedKey === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("rawEncryptedKey");
                    }
                    if ($.$$.S.String.IsNullOrEmpty(rawInitializationVector))
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("rawInitializationVector");
                    }
                    if ($.$$.S.String.IsNullOrEmpty(rawCiphertext))
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("rawCiphertext");
                    }
                    if ($.$$.S.String.IsNullOrEmpty(rawAuthenticationTag))
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("rawAuthenticationTag");
                    }
                    this.Header = header;
                    this.InnerToken = innerToken;
                    this.RawData = $.$$.S.String.Join$8(".", $.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1([ rawHeader, rawEncryptedKey, rawInitializationVector, rawCiphertext, rawAuthenticationTag ]));
                    this.RawHeader = rawHeader;
                    this.RawEncryptedKey = rawEncryptedKey;
                    this.RawInitializationVector = rawInitializationVector;
                    this.RawCiphertext = rawCiphertext;
                    this.RawAuthenticationTag = rawAuthenticationTag;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64424968320)
            
            //--TRIMMABLE-BOUNDARY-START(60130001024)
            $ctor$3(/*JwtHeader*/ header, /*JwtPayload*/ payload)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130001024);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (header === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("header");
                    }
                    if (payload === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("payload");
                    }
                    this.Header = header;
                    this.Payload = payload;
                    this.RawSignature = $.$$.S.String.Empty;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60130001024)
            
            //--TRIMMABLE-BOUNDARY-START(68719935616)
            $ctor$5(/*string*/ issuer, /*string*/ audience, /*IEnumerable<Claim>*/ claims, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*SigningCredentials*/ signingCredentials)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719935616);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(expires) && $.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(notBefore))
                    {
                        if (notBefore >= expires)
                        {
                            throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14($.$mil.MIL.LogHelper.FormatInvariant("IDX12401: Expires: '{0}' must be after NotBefore: '{1}'."/*LogMessages.IDX12401*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(expires)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(notBefore)) ], null, null))));
                        }
                    }
                    this.Payload = new $.$sitj.SITJ.JwtPayload().$ctor$15(issuer, audience, claims, $.$clone(notBefore), $.$clone(expires));
                    this.Header = new $.$sitj.SITJ.JwtHeader().$ctor$20(signingCredentials);
                    this.RawSignature = $.$$.S.String.Empty;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68719935616)
            
            //--TRIMMABLE-BOUNDARY-START(77309870208)
            /*string */ get Actor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259543168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.Actort;
                }
                return $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(77309870208)
            
            //--TRIMMABLE-BOUNDARY-START(81604837504)
            /*IEnumerable<string> */ get Audiences()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849477760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.Aud;
                }
                return new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(81604837504)
            
            //--TRIMMABLE-BOUNDARY-START(85899804800)
            /*IEnumerable<Claim> */ get Claims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439412352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.Claims;
                }
                return new ($.$$.SCG.List$$($.$ssc.SSC.Claim))().$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(85899804800)
            
            //--TRIMMABLE-BOUNDARY-START(103079673984)
            /*string */ get EncodedHeader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029346944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Header.Base64UrlEncode();
            }
            //--TRIMMABLE-BOUNDARY-END(103079673984)
            
            //--TRIMMABLE-BOUNDARY-START(107374641280)
            /*string */ get EncodedPayload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619281536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.Base64UrlEncode();
                }
                return $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(107374641280)
            
            //--TRIMMABLE-BOUNDARY-START(347892809856)
            /*JwtHeader*/ Header = null;
            //--TRIMMABLE-BOUNDARY-END(347892809856)
            
            //--TRIMMABLE-BOUNDARY-START(352187777152)
            /*string */ get Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389085312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.Jti;
                }
                return $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(352187777152)
            
            //--TRIMMABLE-BOUNDARY-START(365072679040)
            /*string */ get Issuer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158889088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.Iss;
                }
                return $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(365072679040)
            
            //--TRIMMABLE-BOUNDARY-START(369367646336)
            /*JwtPayload */ get Payload()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748823680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.InnerToken !== null)
                {
                    return this.InnerToken.Payload;
                }
                return this._payload;
            }
            /*JwtPayload */ set Payload(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433792155776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._payload = value;
            }
            //--TRIMMABLE-BOUNDARY-END(369367646336)
            
            //--TRIMMABLE-BOUNDARY-START(356482744448)
            /*JwtSecurityToken*/ InnerToken = null;
            //--TRIMMABLE-BOUNDARY-END(356482744448)
            
            //--TRIMMABLE-BOUNDARY-START(373662613632)
            /*string*/ RawAuthenticationTag = null;
            //--TRIMMABLE-BOUNDARY-END(373662613632)
            
            //--TRIMMABLE-BOUNDARY-START(377957580928)
            /*string*/ RawCiphertext = null;
            //--TRIMMABLE-BOUNDARY-END(377957580928)
            
            //--TRIMMABLE-BOUNDARY-START(382252548224)
            /*string*/ RawData = null;
            //--TRIMMABLE-BOUNDARY-END(382252548224)
            
            //--TRIMMABLE-BOUNDARY-START(386547515520)
            /*string*/ RawEncryptedKey = null;
            //--TRIMMABLE-BOUNDARY-END(386547515520)
            
            //--TRIMMABLE-BOUNDARY-START(395137450112)
            /*string*/ RawInitializationVector = null;
            //--TRIMMABLE-BOUNDARY-END(395137450112)
            
            //--TRIMMABLE-BOUNDARY-START(390842482816)
            /*string*/ RawHeader = null;
            //--TRIMMABLE-BOUNDARY-END(390842482816)
            
            //--TRIMMABLE-BOUNDARY-START(399432417408)
            /*string*/ RawPayload = null;
            //--TRIMMABLE-BOUNDARY-END(399432417408)
            
            //--TRIMMABLE-BOUNDARY-START(403727384704)
            /*string*/ RawSignature = null;
            //--TRIMMABLE-BOUNDARY-END(403727384704)
            
            //--TRIMMABLE-BOUNDARY-START(408022352000)
            /*SecurityKey */ get SecurityKey()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058235008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(408022352000)
            
            //--TRIMMABLE-BOUNDARY-START(515396534400)
            /*string */ get SignatureAlgorithm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648169600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Header.Alg;
            }
            //--TRIMMABLE-BOUNDARY-END(515396534400)
            
            //--TRIMMABLE-BOUNDARY-START(519691501696)
            /*SigningCredentials */ get SigningCredentials()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238104192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Header.SigningCredentials;
            }
            //--TRIMMABLE-BOUNDARY-END(519691501696)
            
            //--TRIMMABLE-BOUNDARY-START(111669608576)
            /*EncryptingCredentials */ get EncryptingCredentials()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209216128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Header.EncryptingCredentials;
            }
            //--TRIMMABLE-BOUNDARY-END(111669608576)
            
            //--TRIMMABLE-BOUNDARY-START(523986468992)
            /*SecurityKey*/ SigningKey = null;
            //--TRIMMABLE-BOUNDARY-END(523986468992)
            
            //--TRIMMABLE-BOUNDARY-START(528281436288)
            /*string */ get Subject()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326417973376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.Sub;
                }
                return $.$$.S.String.Empty;
            }
            //--TRIMMABLE-BOUNDARY-END(528281436288)
            
            //--TRIMMABLE-BOUNDARY-START(541166338176)
            /*DateTime */ get ValidFrom()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335007907968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.ValidFrom;
                }
                return $.$$.S.DateTime.MinValue;
            }
            //--TRIMMABLE-BOUNDARY-END(541166338176)
            
            //--TRIMMABLE-BOUNDARY-START(545461305472)
            /*DateTime */ get ValidTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597842560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.ValidTo;
                }
                return $.$$.S.DateTime.MinValue;
            }
            //--TRIMMABLE-BOUNDARY-END(545461305472)
            
            //--TRIMMABLE-BOUNDARY-START(360777711744)
            /*DateTime */ get IssuedAt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568954496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return this.Payload.IssuedAt;
                }
                return $.$$.S.DateTime.MinValue;
            }
            //--TRIMMABLE-BOUNDARY-END(360777711744)
            
            //--TRIMMABLE-BOUNDARY-START(532576403584)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532576403584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Payload !== null)
                {
                    return $.$strNN($.$strNN(this.Header.SerializeToJson()) + ".") + $.$strNN(this.Payload.SerializeToJson());
                }
                else 
                {
                    return $.$strNN(this.Header.SerializeToJson()) + ".";
                }
            }
            //--TRIMMABLE-BOUNDARY-END(532576403584)
            
            //--TRIMMABLE-BOUNDARY-START(536871370880)
            /*string */ UnsafeToString()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(536871370880);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.RawData;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(536871370880)
            
            //--TRIMMABLE-BOUNDARY-START(90194772096)
            /*void */ Decode(/*string[]*/ tokenParts, /*string*/ rawData)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194772096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    this.Header = $.$sitj.SITJ.JwtHeader.Base64UrlDeserialize($.$$.System.Array.$ReadT1.call(tokenParts, 0));
                }
                catch(ex)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$11($.$mil.MIL.LogHelper.FormatInvariant("IDX12729: Unable to decode the header '{0}' as Base64Url encoded string."/*LogMessages.IDX12729*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$$.System.Array.$ReadT1.call(tokenParts, 0) ], null, null)), ex));
                }
                if (tokenParts.length === 5/*JwtConstants.JweSegmentCount*/)
                {
                    this.DecodeJwe(tokenParts);
                }
                else 
                {
                    this.DecodeJws($.$$.System.Array.$ReadT1.call(tokenParts, 1));
                    this.RawHeader = $.$$.System.Array.$ReadT1.call(tokenParts, 0);
                    this.RawPayload = $.$$.System.Array.$ReadT1.call(tokenParts, 1);
                    this.RawSignature = $.$$.System.Array.$ReadT1.call(tokenParts, 2);
                }
                this.RawData = rawData;
            }
            //--TRIMMABLE-BOUNDARY-END(90194772096)
            
            //--TRIMMABLE-BOUNDARY-START(98784706688)
            /*void */ DecodeJws(/*string*/ payload)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784706688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Header.Cty !== null && $.$mil.MIL.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                {
                    $.$mil.MIL.LogHelper.LogVerbose($.$mil.MIL.LogHelper.FormatInvariant("IDX12738: Header.Cty != null, assuming JWS. Cty: '{0}'."/*LogMessages.IDX12738*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ this.Header.Cty ], null, null)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
                try
                {
                    this.Payload = $.$mit.MIT$1.Base64UrlEncoding.Decode$5($.$sitj.SITJ.JwtPayload, payload, 0, payload.length, new ($.$$.S.Func$$$$($.$typeArray($.$$.S.Byte), $.$$.S.Int32, $.$sitj.SITJ.JwtPayload))().$ctor($.$sitj.SITJ.JwtPayload, $.$sitj.SITJ.JwtPayload.CreatePayload));
                }
                catch(ex)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$11($.$mil.MIL.LogHelper.FormatInvariant("IDX12723: Unable to decode the payload '{0}' as Base64Url encoded string."/*LogMessages.IDX12723*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ payload ], null, null)), ex));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784706688)
            
            //--TRIMMABLE-BOUNDARY-START(94489739392)
            /*void */ DecodeJwe(/*string[]*/ tokenParts)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.RawHeader = $.$$.System.Array.$ReadT1.call(tokenParts, 0);
                this.RawEncryptedKey = $.$$.System.Array.$ReadT1.call(tokenParts, 1);
                this.RawInitializationVector = $.$$.System.Array.$ReadT1.call(tokenParts, 2);
                this.RawCiphertext = $.$$.System.Array.$ReadT1.call(tokenParts, 3);
                this.RawAuthenticationTag = $.$$.System.Array.$ReadT1.call(tokenParts, 4);
            }
            //--TRIMMABLE-BOUNDARY-END(94489739392)
            
            static $h = 458880;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mit.MIT$1.SecurityToken; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77309870208),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259543168,
        "f": 50331649
      },
      "n": "Actor",
      "d": 458880,
      "h": 77309870208,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309870208),
//--TRIMMABLE-BOUNDARY-START(81604837504),
    {
      "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849477760,
        "f": 50331649
      },
      "n": "Audiences",
      "d": 458880,
      "h": 81604837504,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604837504),
//--TRIMMABLE-BOUNDARY-START(85899804800),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439412352,
        "f": 50331649
      },
      "n": "Claims",
      "d": 458880,
      "h": 85899804800,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899804800),
//--TRIMMABLE-BOUNDARY-START(103079673984),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029346944,
        "f": 50331777
      },
      "n": "EncodedHeader",
      "d": 458880,
      "h": 103079673984,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(103079673984),
//--TRIMMABLE-BOUNDARY-START(107374641280),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619281536,
        "f": 50331777
      },
      "n": "EncodedPayload",
      "d": 458880,
      "h": 107374641280,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(107374641280),
//--TRIMMABLE-BOUNDARY-START(347892809856),
    {
      "p": 196736,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799150720,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 416612286592,
        "f": 83886088
      },
      "n": "Header",
      "d": 458880,
      "h": 347892809856,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(347892809856),
//--TRIMMABLE-BOUNDARY-START(352187777152),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389085312,
        "f": 50364417
      },
      "n": "Id",
      "d": 458880,
      "h": 352187777152,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(352187777152),
//--TRIMMABLE-BOUNDARY-START(365072679040),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206158889088,
        "f": 50364417
      },
      "n": "Issuer",
      "d": 458880,
      "h": 365072679040,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(365072679040),
//--TRIMMABLE-BOUNDARY-START(369367646336),
    {
      "p": 327808,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214748823680,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 433792155776,
        "f": 83886088
      },
      "n": "Payload",
      "d": 458880,
      "h": 369367646336,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(369367646336),
//--TRIMMABLE-BOUNDARY-START(356482744448),
    {
      "p": 458880,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979019904,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 425202221184,
        "f": 83886088
      },
      "n": "InnerToken",
      "d": 458880,
      "h": 356482744448,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(356482744448),
//--TRIMMABLE-BOUNDARY-START(373662613632),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223338758272,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 442382090368,
        "f": 83886082
      },
      "n": "RawAuthenticationTag",
      "d": 458880,
      "h": 373662613632,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(373662613632),
//--TRIMMABLE-BOUNDARY-START(377957580928),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231928692864,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 450972024960,
        "f": 83886082
      },
      "n": "RawCiphertext",
      "d": 458880,
      "h": 377957580928,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(377957580928),
//--TRIMMABLE-BOUNDARY-START(382252548224),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240518627456,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 459561959552,
        "f": 83886082
      },
      "n": "RawData",
      "d": 458880,
      "h": 382252548224,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(382252548224),
//--TRIMMABLE-BOUNDARY-START(386547515520),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249108562048,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 468151894144,
        "f": 83886082
      },
      "n": "RawEncryptedKey",
      "d": 458880,
      "h": 386547515520,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(386547515520),
//--TRIMMABLE-BOUNDARY-START(395137450112),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266288431232,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 485331763328,
        "f": 83886082
      },
      "n": "RawInitializationVector",
      "d": 458880,
      "h": 395137450112,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(395137450112),
//--TRIMMABLE-BOUNDARY-START(390842482816),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257698496640,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 476741828736,
        "f": 83886088
      },
      "n": "RawHeader",
      "d": 458880,
      "h": 390842482816,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(390842482816),
//--TRIMMABLE-BOUNDARY-START(399432417408),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274878365824,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 493921697920,
        "f": 83886088
      },
      "n": "RawPayload",
      "d": 458880,
      "h": 399432417408,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(399432417408),
//--TRIMMABLE-BOUNDARY-START(403727384704),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283468300416,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 502511632512,
        "f": 83886088
      },
      "n": "RawSignature",
      "d": 458880,
      "h": 403727384704,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(403727384704),
//--TRIMMABLE-BOUNDARY-START(408022352000),
    {
      "p": 13631614,
      "g": {
        "r": 0,
        "d": 0,
        "h": 292058235008,
        "f": 50364417
      },
      "n": "SecurityKey",
      "d": 458880,
      "h": 408022352000,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(408022352000),
//--TRIMMABLE-BOUNDARY-START(515396534400),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 300648169600,
        "f": 50331649
      },
      "n": "SignatureAlgorithm",
      "d": 458880,
      "h": 515396534400,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(515396534400),
//--TRIMMABLE-BOUNDARY-START(519691501696),
    {
      "p": 15925374,
      "g": {
        "r": 0,
        "d": 0,
        "h": 309238104192,
        "f": 50331649
      },
      "n": "SigningCredentials",
      "d": 458880,
      "h": 519691501696,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(519691501696),
//--TRIMMABLE-BOUNDARY-START(111669608576),
    {
      "p": 3932286,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209216128,
        "f": 50331649
      },
      "n": "EncryptingCredentials",
      "d": 458880,
      "h": 111669608576,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669608576),
//--TRIMMABLE-BOUNDARY-START(523986468992),
    {
      "p": 13631614,
      "g": {
        "r": 0,
        "d": 0,
        "h": 317828038784,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 511101567104,
        "f": 83918849
      },
      "n": "SigningKey",
      "d": 458880,
      "h": 523986468992,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(523986468992),
//--TRIMMABLE-BOUNDARY-START(528281436288),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 326417973376,
        "f": 50331649
      },
      "n": "Subject",
      "d": 458880,
      "h": 528281436288,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(528281436288),
//--TRIMMABLE-BOUNDARY-START(541166338176),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 335007907968,
        "f": 50364417
      },
      "n": "ValidFrom",
      "d": 458880,
      "h": 541166338176,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(541166338176),
//--TRIMMABLE-BOUNDARY-START(545461305472),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 343597842560,
        "f": 50364417
      },
      "n": "ValidTo",
      "d": 458880,
      "h": 545461305472,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(545461305472),
//--TRIMMABLE-BOUNDARY-START(360777711744),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197568954496,
        "f": 50331777
      },
      "n": "IssuedAt",
      "d": 458880,
      "h": 360777711744,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(360777711744)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(532576403584),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 458880,
      "h": 532576403584,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(532576403584),
//--TRIMMABLE-BOUNDARY-START(536871370880),
    {
      "r": 1310721,
      "n": "UnsafeToString",
      "d": 458880,
      "h": 536871370880,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(536871370880),
//--TRIMMABLE-BOUNDARY-START(90194772096),
    {
      "r": 65537,
      "p": [
        {
          "n": "tokenParts",
          "p": $.$typeArray($.$$.S.String).$h
        },
        {
          "n": "rawData",
          "p": 1310721
        }
      ],
      "n": "Decode",
      "d": 458880,
      "h": 90194772096,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(90194772096),
//--TRIMMABLE-BOUNDARY-START(98784706688),
    {
      "r": 65537,
      "p": [
        {
          "n": "payload",
          "p": 1310721
        }
      ],
      "n": "DecodeJws",
      "d": 458880,
      "h": 98784706688,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(98784706688),
//--TRIMMABLE-BOUNDARY-START(94489739392),
    {
      "r": 65537,
      "p": [
        {
          "n": "tokenParts",
          "p": $.$typeArray($.$$.S.String).$h
        }
      ],
      "n": "DecodeJwe",
      "d": 458880,
      "h": 94489739392,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(94489739392)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295426176),
    {
      "t": 327808,
      "n": "_payload",
      "d": 458880,
      "h": 4295426176,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295426176)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(73014902912),
    {
      "p": [
        {
          "n": "jwtEncodedString",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 458880,
      "h": 73014902912,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014902912),
//--TRIMMABLE-BOUNDARY-START(55835033728),
    {
      "p": [
        {
          "n": "header",
          "p": 196736
        },
        {
          "n": "payload",
          "p": 327808
        },
        {
          "n": "rawHeader",
          "p": 1310721
        },
        {
          "n": "rawPayload",
          "p": 1310721
        },
        {
          "n": "rawSignature",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 458880,
      "h": 55835033728,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835033728),
//--TRIMMABLE-BOUNDARY-START(64424968320),
    {
      "p": [
        {
          "n": "header",
          "p": 196736
        },
        {
          "n": "innerToken",
          "p": 458880
        },
        {
          "n": "rawHeader",
          "p": 1310721
        },
        {
          "n": "rawEncryptedKey",
          "p": 1310721
        },
        {
          "n": "rawInitializationVector",
          "p": 1310721
        },
        {
          "n": "rawCiphertext",
          "p": 1310721
        },
        {
          "n": "rawAuthenticationTag",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 458880,
      "h": 64424968320,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424968320),
//--TRIMMABLE-BOUNDARY-START(60130001024),
    {
      "p": [
        {
          "n": "header",
          "p": 196736
        },
        {
          "n": "payload",
          "p": 327808
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 458880,
      "h": 60130001024,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130001024),
//--TRIMMABLE-BOUNDARY-START(68719935616),
    {
      "p": [
        {
          "n": "issuer",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "audience",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "claims",
          "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h,
          "f": 65
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.S.DateTime).$h,
          "f": 65
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.S.DateTime).$h,
          "f": 65
        },
        {
          "n": "signingCredentials",
          "p": 15925374,
          "f": 65
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 458880,
      "h": 68719935616,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719935616)
  ],
  "h": 458880
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mil.MIL.ISafeLogSecurityArtifact ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IdentityModel.Tokens.Jwt.JwtSecurityToken`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IdentityModel${separator}Tokens${separator}Jwt${separator}JwtSecurityToken`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458880)
        
        

        //--TRIMMABLE-BOUNDARY-START(589952)
        $asm.$cls(`$sitj.SITJ.JwtSecurityTokenHandler`, ($self) => class JwtSecurityTokenHandler extends $.$mit.MIT$1.SecurityTokenHandler
        {
            //--TRIMMABLE-BOUNDARY-START(655488)
            static $_CertMatcher;
            static get CertMatcher()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(655488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sitj.SITJ.JwtSecurityTokenHandler;
                return $cls.$_CertMatcher ??= $asm.$ncls(`$sitj.SITJ.JwtSecurityTokenHandler.CertMatcher`, ($self) => class CertMatcher extends $.$$.S.MulticastDelegate
                {
                    $ctor(/*object*/ target, fn, anmodel)
                    {
                        this.$target = target;
                        this.$nativeFunction = fn;
                        if (anmodel) this.$nfmodel = anmodel;
                        if (typeof(target) === 'object') this._target = target;
                        return this;
                    }
                    /*bool*/ Invoke(/**/ cert)
                    {
                        return this.$nativeFunction.call(this.$target, cert);
                    }
                    static $h = 655488;
                    static $f = 0b10000000010000000;
                    static $k = 5;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180524672),
    {
      "r": 262145,
      "p": [
        {
          "n": "cert",
          "p": 28180510
        }
      ],
      "n": "Invoke",
      "d": 655488,
      "h": 17180524672,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180524672),
//--TRIMMABLE-BOUNDARY-START(8590590080),
    {
      "r": 90570753,
      "p": [
        {
          "n": "cert",
          "p": 28180510
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 655488,
      "h": 8590590080,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590590080),
//--TRIMMABLE-BOUNDARY-START(12885557376),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 655488,
      "h": 12885557376,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885557376)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622784),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 655488,
      "h": 4295622784,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622784)
  ],
  "d": 589952,
  "h": 655488
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler+CertMatcher`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IdentityModel${separator}Tokens${separator}Jwt${separator}JwtSecurityTokenHandler${separator}CertMatcher`; }
                }, $cls, ($v) => $cls.$_CertMatcher = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655488)
            
            //--TRIMMABLE-BOUNDARY-START(8590524544)
            /*ISet<string>*/ _inboundClaimFilter = null;
            //--TRIMMABLE-BOUNDARY-END(8590524544)
            
            //--TRIMMABLE-BOUNDARY-START(12885491840)
            /*IDictionary<string, string>*/ _inboundClaimTypeMap = null;
            //--TRIMMABLE-BOUNDARY-END(12885491840)
            
            //--TRIMMABLE-BOUNDARY-START(17180459136)
            /*string*/ static _jsonClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(17180459136)
            
            //--TRIMMABLE-BOUNDARY-START(25770393728)
            /*string*/ static _namespace = null;
            //--TRIMMABLE-BOUNDARY-END(25770393728)
            
            //--TRIMMABLE-BOUNDARY-START(4295557248)
            /*string*/ static _className = null;
            //--TRIMMABLE-BOUNDARY-END(4295557248)
            
            //--TRIMMABLE-BOUNDARY-START(34360328320)
            /*IDictionary<string, string>*/ _outboundClaimTypeMap = null;
            //--TRIMMABLE-BOUNDARY-END(34360328320)
            
            //--TRIMMABLE-BOUNDARY-START(30065361024)
            /*Dictionary<string, string>*/ _outboundAlgorithmMap = null;
            //--TRIMMABLE-BOUNDARY-END(30065361024)
            
            //--TRIMMABLE-BOUNDARY-START(38655295616)
            /*string*/ static _shortClaimType = null;
            //--TRIMMABLE-BOUNDARY-END(38655295616)
            
            //--TRIMMABLE-BOUNDARY-START(21475426432)
            /*bool*/ _mapInboundClaims = false;
            //--TRIMMABLE-BOUNDARY-END(21475426432)
            
            //--TRIMMABLE-BOUNDARY-START(382252679296)
            /*Microsoft.IdentityModel.Telemetry.ITelemetryClient*/ TelemetryClient = null;
            //--TRIMMABLE-BOUNDARY-END(382252679296)
            
            //--TRIMMABLE-BOUNDARY-START(141734510720)
            /*IDictionary<string, string>*/ static DefaultInboundClaimTypeMap = null;
            //--TRIMMABLE-BOUNDARY-END(141734510720)
            
            //--TRIMMABLE-BOUNDARY-START(146029478016)
            /*bool*/ static DefaultMapInboundClaims = true;
            //--TRIMMABLE-BOUNDARY-END(146029478016)
            
            //--TRIMMABLE-BOUNDARY-START(154619412608)
            /*IDictionary<string, string>*/ static DefaultOutboundClaimTypeMap = null;
            //--TRIMMABLE-BOUNDARY-END(154619412608)
            
            //--TRIMMABLE-BOUNDARY-START(137439543424)
            /*ISet<string>*/ static DefaultInboundClaimFilter = null;
            //--TRIMMABLE-BOUNDARY-END(137439543424)
            
            //--TRIMMABLE-BOUNDARY-START(150324445312)
            /*IDictionary<string, string>*/ static DefaultOutboundAlgorithmMap = null;
            //--TRIMMABLE-BOUNDARY-END(150324445312)
            
            //--TRIMMABLE-BOUNDARY-START(42950262912)
            /*Static constructor*/ static $cctor()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950262912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42950262912)
            
            //--TRIMMABLE-BOUNDARY-START(47245230208)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245230208);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (this._mapInboundClaims)
                    {
                        this._inboundClaimTypeMap = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$3($.$sitj.SITJ.JwtSecurityTokenHandler.DefaultInboundClaimTypeMap);
                    }
                    else 
                    {
                        this._inboundClaimTypeMap = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$1();
                    }
                    this._outboundClaimTypeMap = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$3($.$sitj.SITJ.JwtSecurityTokenHandler.DefaultOutboundClaimTypeMap);
                    this._inboundClaimFilter = new ($.$$.SCG.HashSet$$($.$$.S.String))().$ctor$3($.$sitj.SITJ.JwtSecurityTokenHandler.DefaultInboundClaimFilter);
                    this._outboundAlgorithmMap = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$3($.$sitj.SITJ.JwtSecurityTokenHandler.DefaultOutboundAlgorithmMap);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245230208)
            
            //--TRIMMABLE-BOUNDARY-START(279173464192)
            /*bool */ get MapInboundClaims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453987456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._mapInboundClaims;
            }
            /*bool */ set MapInboundClaims(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356482875520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this._mapInboundClaims && value && this._inboundClaimTypeMap.SCG$ICollection$$$Count === 0)
                {
                    this._inboundClaimTypeMap = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$3($.$sitj.SITJ.JwtSecurityTokenHandler.DefaultInboundClaimTypeMap);
                }
                this._mapInboundClaims = value;
            }
            //--TRIMMABLE-BOUNDARY-END(279173464192)
            
            //--TRIMMABLE-BOUNDARY-START(270583529600)
            /*IDictionary<string, string> */ get InboundClaimTypeMap()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274118272);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inboundClaimTypeMap;
            }
            /*IDictionary<string, string> */ set InboundClaimTypeMap(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303006336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._inboundClaimTypeMap = $.$firstOf(value, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("value") });
            }
            //--TRIMMABLE-BOUNDARY-END(270583529600)
            
            //--TRIMMABLE-BOUNDARY-START(287763398784)
            /*IDictionary<string, string> */ get OutboundClaimTypeMap()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633856640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._outboundClaimTypeMap;
            }
            /*IDictionary<string, string> */ set OutboundClaimTypeMap(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365072810112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("value");
                }
                this._outboundClaimTypeMap = value;
            }
            //--TRIMMABLE-BOUNDARY-END(287763398784)
            
            //--TRIMMABLE-BOUNDARY-START(283468431488)
            /*IDictionary<string, string> */ get OutboundAlgorithmMap()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043922048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._outboundAlgorithmMap;
            }
            //--TRIMMABLE-BOUNDARY-END(283468431488)
            
            //--TRIMMABLE-BOUNDARY-START(266288562304)
            /*ISet<string> */ get InboundClaimFilter()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684183680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._inboundClaimFilter;
            }
            /*ISet<string> */ set InboundClaimFilter(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713071744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("value");
                }
                this._inboundClaimFilter = value;
            }
            //--TRIMMABLE-BOUNDARY-END(266288562304)
            
            //--TRIMMABLE-BOUNDARY-START(377957712000)
            static /*string */ get ShortClaimTypeProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223791232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sitj.SITJ.JwtSecurityTokenHandler._shortClaimType;
            }
            static /*string */ set ShortClaimTypeProperty(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662744704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrWhiteSpace(value))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("value");
                }
                $.$sitj.SITJ.JwtSecurityTokenHandler._shortClaimType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(377957712000)
            
            //--TRIMMABLE-BOUNDARY-START(274878496896)
            static /*string */ get JsonClaimTypeProperty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864052864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sitj.SITJ.JwtSecurityTokenHandler._jsonClaimType;
            }
            static /*string */ set JsonClaimTypeProperty(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892940928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrWhiteSpace(value))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("value");
                }
                $.$sitj.SITJ.JwtSecurityTokenHandler._jsonClaimType = value;
            }
            //--TRIMMABLE-BOUNDARY-END(274878496896)
            
            //--TRIMMABLE-BOUNDARY-START(55835164800)
            /*bool */ get CanValidateToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504314496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(55835164800)
            
            //--TRIMMABLE-BOUNDARY-START(60130132096)
            /*bool */ get CanWriteToken()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094249088);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(60130132096)
            
            //--TRIMMABLE-BOUNDARY-START(386547646592)
            /*Type */ get TokenType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813725824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sitj.SITJ.JwtSecurityToken.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(386547646592)
            
            //--TRIMMABLE-BOUNDARY-START(51540197504)
            /*bool */ CanReadToken(/*string*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540197504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrWhiteSpace(token))
                {
                    return false;
                }
                if (token.length > this.MaximumTokenSizeInBytes)
                {
                    if ($.$mil.MIL.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                    {
                        $.$mil.MIL.LogHelper.LogInformation("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.S.Int32)) ], null, null));
                    }
                    return false;
                }
                /*int*/ let tokenPartCount = $.$mij.MIJ.JwtTokenUtilities.CountJwtTokenPart(token, ((5/*JwtConstants.MaxJwtSegmentCount*/ + 1) | 0));
                if (tokenPartCount === 3/*JwtConstants.JwsSegmentCount*/)
                {
                    return $.$mij.MIJ.JwtTokenUtilities.RegexJws.IsMatch$9(token);
                }
                else if (tokenPartCount === 5/*JwtConstants.JweSegmentCount*/)
                {
                    return $.$mij.MIJ.JwtTokenUtilities.RegexJwe.IsMatch$9(token);
                }
                $.$mil.MIL.LogHelper.LogInformation("IDX12720: Token string does not match the token formats: JWE (header.encryptedKey.iv.ciphertext.tag) or JWS (header.payload.signature)"/*LogMessages.IDX12720*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(51540197504)
            
            //--TRIMMABLE-BOUNDARY-START(85899935872)
            /*string */ CreateEncodedJwt(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899935872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (tokenDescriptor === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("tokenDescriptor");
                }
                return this.CreateJwtSecurityToken(tokenDescriptor).RawData;
            }
            //--TRIMMABLE-BOUNDARY-END(85899935872)
            
            //--TRIMMABLE-BOUNDARY-START(98784837760)
            /*string */ CreateEncodedJwt$3(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784837760);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CreateJwtSecurityTokenPrivate((() =>
                    {
                        //new $.$mit.MIT$1.SecurityTokenDescriptor()
                        const $t1 = $.$mit.MIT$1.SecurityTokenDescriptor;
                        const $i1 = new $t1();
                        $i1.$ctor$1();
                        $i1.Issuer = issuer;
                        $i1.Audience = audience;
                        $i1.Subject = subject;
                        $i1.NotBefore = $.$clone(notBefore);
                        $i1.Expires = $.$clone(expires);
                        $i1.IssuedAt = $.$clone(issuedAt);
                        $i1.SigningCredentials = signingCredentials;
                        return $i1;
                    })()).RawData;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784837760)
            
            //--TRIMMABLE-BOUNDARY-START(94489870464)
            /*string */ CreateEncodedJwt$2(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94489870464);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CreateJwtSecurityTokenPrivate((() =>
                    {
                        //new $.$mit.MIT$1.SecurityTokenDescriptor()
                        const $t2 = $.$mit.MIT$1.SecurityTokenDescriptor;
                        const $i2 = new $t2();
                        $i2.$ctor$1();
                        $i2.Issuer = issuer;
                        $i2.Audience = audience;
                        $i2.Subject = subject;
                        $i2.NotBefore = $.$clone(notBefore);
                        $i2.Expires = $.$clone(expires);
                        $i2.IssuedAt = $.$clone(issuedAt);
                        $i2.SigningCredentials = signingCredentials;
                        $i2.EncryptingCredentials = encryptingCredentials;
                        return $i2;
                    })()).RawData;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489870464)
            
            //--TRIMMABLE-BOUNDARY-START(90194903168)
            /*string */ CreateEncodedJwt$1(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ claimCollection)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(90194903168);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CreateJwtSecurityTokenPrivate((() =>
                    {
                        //new $.$mit.MIT$1.SecurityTokenDescriptor()
                        const $t3 = $.$mit.MIT$1.SecurityTokenDescriptor;
                        const $i3 = new $t3();
                        $i3.$ctor$1();
                        $i3.Issuer = issuer;
                        $i3.Audience = audience;
                        $i3.Subject = subject;
                        $i3.NotBefore = $.$clone(notBefore);
                        $i3.Expires = $.$clone(expires);
                        $i3.IssuedAt = $.$clone(issuedAt);
                        $i3.SigningCredentials = signingCredentials;
                        $i3.EncryptingCredentials = encryptingCredentials;
                        $i3.Claims = claimCollection;
                        return $i3;
                    })()).RawData;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194903168)
            
            //--TRIMMABLE-BOUNDARY-START(103079805056)
            /*JwtSecurityToken */ CreateJwtSecurityToken(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079805056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (tokenDescriptor === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("tokenDescriptor");
                }
                return this.CreateJwtSecurityTokenPrivate(tokenDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(103079805056)
            
            //--TRIMMABLE-BOUNDARY-START(111669739648)
            /*JwtSecurityToken */ CreateJwtSecurityToken$2(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111669739648);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CreateJwtSecurityTokenPrivate((() =>
                    {
                        //new $.$mit.MIT$1.SecurityTokenDescriptor()
                        const $t4 = $.$mit.MIT$1.SecurityTokenDescriptor;
                        const $i4 = new $t4();
                        $i4.$ctor$1();
                        $i4.Issuer = issuer;
                        $i4.Audience = audience;
                        $i4.Subject = subject;
                        $i4.NotBefore = $.$clone(notBefore);
                        $i4.Expires = $.$clone(expires);
                        $i4.IssuedAt = $.$clone(issuedAt);
                        $i4.SigningCredentials = signingCredentials;
                        $i4.EncryptingCredentials = encryptingCredentials;
                        return $i4;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669739648)
            
            //--TRIMMABLE-BOUNDARY-START(107374772352)
            /*JwtSecurityToken */ CreateJwtSecurityToken$1(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials, /*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, object>*/ claimCollection)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374772352);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CreateJwtSecurityTokenPrivate((() =>
                    {
                        //new $.$mit.MIT$1.SecurityTokenDescriptor()
                        const $t5 = $.$mit.MIT$1.SecurityTokenDescriptor;
                        const $i5 = new $t5();
                        $i5.$ctor$1();
                        $i5.Issuer = issuer;
                        $i5.Audience = audience;
                        $i5.Subject = subject;
                        $i5.NotBefore = $.$clone(notBefore);
                        $i5.Expires = $.$clone(expires);
                        $i5.IssuedAt = $.$clone(issuedAt);
                        $i5.SigningCredentials = signingCredentials;
                        $i5.EncryptingCredentials = encryptingCredentials;
                        $i5.Claims = claimCollection;
                        return $i5;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374772352)
            
            //--TRIMMABLE-BOUNDARY-START(115964706944)
            /*JwtSecurityToken */ CreateJwtSecurityToken$3(/*string*/ issuer, /*string*/ audience, /*ClaimsIdentity*/ subject, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt, /*SigningCredentials*/ signingCredentials)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964706944);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.CreateJwtSecurityTokenPrivate((() =>
                    {
                        //new $.$mit.MIT$1.SecurityTokenDescriptor()
                        const $t6 = $.$mit.MIT$1.SecurityTokenDescriptor;
                        const $i6 = new $t6();
                        $i6.$ctor$1();
                        $i6.Issuer = issuer;
                        $i6.Audience = audience;
                        $i6.Subject = subject;
                        $i6.NotBefore = $.$clone(notBefore);
                        $i6.Expires = $.$clone(expires);
                        $i6.IssuedAt = $.$clone(issuedAt);
                        $i6.SigningCredentials = signingCredentials;
                        return $i6;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964706944)
            
            //--TRIMMABLE-BOUNDARY-START(128849608832)
            /*SecurityToken */ CreateToken(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849608832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (tokenDescriptor === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("tokenDescriptor");
                }
                return this.CreateJwtSecurityTokenPrivate(tokenDescriptor);
            }
            //--TRIMMABLE-BOUNDARY-END(128849608832)
            
            //--TRIMMABLE-BOUNDARY-START(120259674240)
            /*JwtSecurityToken */ CreateJwtSecurityTokenPrivate(/*SecurityTokenDescriptor*/ tokenDescriptor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259674240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*DateTime?*/ let expires = tokenDescriptor.Expires;
                /*DateTime?*/ let issuedAt = tokenDescriptor.IssuedAt;
                /*DateTime?*/ let notBefore = tokenDescriptor.NotBefore;
                if (this.SetDefaultTimesOnTokenCreation && (!$.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(expires) || !$.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(issuedAt) || !$.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(notBefore)))
                {
                    /*DateTime*/ let now = $.$$.S.DateTime.UtcNow;
                    if (!$.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(expires))
                    {
                        expires = $.$$.S.DateTime.op_Addition(now, $.$$.S.TimeSpan.FromMinutes$2(BigInt(this.TokenLifetimeInMinutes)));
                    }
                    if (!$.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(issuedAt))
                    {
                        issuedAt = now;
                    }
                    if (!$.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(notBefore))
                    {
                        notBefore = now;
                    }
                }
                /*string*/ let issuer = tokenDescriptor.Issuer;
                /*ClaimsIdentity*/ let subject = tokenDescriptor.Subject;
                /*IDictionary<string, object>*/ let claimCollection = tokenDescriptor.Claims;
                /*JwtPayload*/ let payload = new $.$sitj.SITJ.JwtPayload().$ctor$16(issuer, tokenDescriptor.Audience, tokenDescriptor.Audiences, (subject === null ? null : this.OutboundClaimTypeTransform$1(subject.Claims)), (claimCollection === null ? null : this.OutboundClaimTypeTransform(claimCollection)), $.$clone(notBefore), $.$clone(expires), $.$clone(issuedAt));
                /*SigningCredentials*/ let signingCredentials = tokenDescriptor.SigningCredentials;
                /*string*/ let tokenType = tokenDescriptor.TokenType;
                /*JwtHeader*/ let header = new $.$sitj.SITJ.JwtHeader().$ctor$16(signingCredentials, this.OutboundAlgorithmMap, tokenType, tokenDescriptor.AdditionalInnerHeaderClaims, tokenDescriptor.IncludeKeyIdInHeader);
                if ($.$mil.MIL.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                {
                    $.$mil.MIL.LogHelper.LogVerbose("IDX12721: Creating JwtSecurityToken: Issuer: '{0}', Audience: '{1}'"/*LogMessages.IDX12721*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(issuer ?? "null"), $.$mil.MIL.LogHelper.MarkAsNonPII($.$dsp(payload.Aud, $.$$.S.Object, ($t) => $t.ToString) ?? "null") ], null, null));
                }
                if ((subject?.Actor ?? null) !== null)
                {
                    payload.AddClaim(new $.$ssc.SSC.Claim().$ctor$8("actort"/*JwtRegisteredClaimNames.Actort*/, this.CreateActorValue(subject.Actor)));
                }
                /*string*/ let rawHeader = header.Base64UrlEncode();
                /*string*/ let rawPayload = payload.Base64UrlEncode();
                /*string*/ let rawSignature = $.$$.S.String.Empty;
                if (signingCredentials !== null)
                {
                    /*string*/ let message = $.$$.S.String.Concat$13(rawHeader, ".", rawPayload);
                    rawSignature = $.$mij.MIJ.JwtTokenUtilities.CreateEncodedSignature$2(message, signingCredentials);
                }
                if ($.$mil.MIL.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                {
                    $.$mil.MIL.LogHelper.LogInformation("IDX12722: Creating security token from the header: '{0}', payload: '{1}'."/*LogMessages.IDX12722*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ rawHeader, rawPayload ], null, null));
                }
                /*EncryptingCredentials*/ let encryptingCredentials = tokenDescriptor.EncryptingCredentials;
                if (encryptingCredentials !== null)
                {
                    return this.EncryptToken(new $.$sitj.SITJ.JwtSecurityToken().$ctor$2(header, payload, rawHeader, rawPayload, rawSignature), encryptingCredentials, tokenType, tokenDescriptor.AdditionalHeaderClaims);
                }
                return new $.$sitj.SITJ.JwtSecurityToken().$ctor$2(header, payload, rawHeader, rawPayload, rawSignature);
            }
            //--TRIMMABLE-BOUNDARY-END(120259674240)
            
            //--TRIMMABLE-BOUNDARY-START(158914379904)
            /*JwtSecurityToken */ EncryptToken(/*JwtSecurityToken*/ innerJwt, /*EncryptingCredentials*/ encryptingCredentials, /*string*/ tokenType, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                /*byte[]*/ let wrappedKey;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914379904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (encryptingCredentials === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("encryptingCredentials");
                }
                /*var*/ let cryptoProviderFactory = encryptingCredentials.CryptoProviderFactory ?? encryptingCredentials.Key.CryptoProviderFactory;
                if (cryptoProviderFactory === null)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14("IDX10620: Unable to obtain a CryptoProviderFactory, both EncryptingCredentials.CryptoProviderFactory and EncryptingCredentials.Key.CryptoProviderFactory are null."/*TokenLogMessages.IDX10620*/));
                }
                /*SecurityKey*/ let securityKey = $.$mij.MIJ.JwtTokenUtilities.GetSecurityKey(encryptingCredentials, cryptoProviderFactory, additionalHeaderClaims, $.$ref(() => wrappedKey, ($v) => wrappedKey = $v, $.$typeArray($.$$.S.Byte)));
                let encryptionProvider = null;
                try
                {
                    encryptionProvider = cryptoProviderFactory.CreateAuthenticatedEncryptionProvider(securityKey, encryptingCredentials.Enc);
                    if (encryptionProvider === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenEncryptionFailedException().$ctor$14("IDX12730: Failed to create the token encryption provider."/*LogMessages.IDX12730*/));
                    }
                    try
                    {
                        /*var*/ let header = new $.$sitj.SITJ.JwtHeader().$ctor$12(encryptingCredentials, this.OutboundAlgorithmMap, tokenType, additionalHeaderClaims);
                        /*var*/ let encodedHeader = header.Base64UrlEncode();
                        /*AuthenticatedEncryptionResult*/ let encryptionResult = encryptionProvider.Encrypt$1($.$$.ST.Encoding.UTF8.GetBytes$8(innerJwt.RawData), $.$$.ST.Encoding.ASCII.GetBytes$8(encodedHeader));
                        return $.$$.S.String.Equals$5.call("dir"/*JwtConstants.DirectKeyUseAlg*/, encryptingCredentials.Alg) ? new $.$sitj.SITJ.JwtSecurityToken().$ctor$4(header, innerJwt, encodedHeader, $.$$.S.String.Empty, $.$mit.MIT$1.Base64UrlEncoder.Encode$1(encryptionResult.IV), $.$mit.MIT$1.Base64UrlEncoder.Encode$1(encryptionResult.Ciphertext), $.$mit.MIT$1.Base64UrlEncoder.Encode$1(encryptionResult.AuthenticationTag)) : new $.$sitj.SITJ.JwtSecurityToken().$ctor$4(header, innerJwt, encodedHeader, $.$mit.MIT$1.Base64UrlEncoder.Encode$1(wrappedKey), $.$mit.MIT$1.Base64UrlEncoder.Encode$1(encryptionResult.IV), $.$mit.MIT$1.Base64UrlEncoder.Encode$1(encryptionResult.Ciphertext), $.$mit.MIT$1.Base64UrlEncoder.Encode$1(encryptionResult.AuthenticationTag));
                    }
                    catch(ex)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenEncryptionFailedException().$ctor$13($.$mil.MIL.LogHelper.FormatInvariant("IDX10616: Encryption failed. EncryptionProvider failed for: Algorithm: '{0}', SecurityKey: '{1}'. See inner exception."/*TokenLogMessages.IDX10616*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(encryptingCredentials.Enc), $.$mil.MIL.LogHelper.MarkAsNonPII(encryptingCredentials.Key.KeyId) ], null, null)), ex));
                    }
                }
                finally
                {
                    encryptionProvider?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914379904)
            
            //--TRIMMABLE-BOUNDARY-START(296353333376)
            /*IEnumerable<Claim> */ OutboundClaimTypeTransform$1(/*IEnumerable<Claim>*/ claims)
            {
                return new ($.$$.N.YieldToIterator$$($.$ssc.SSC.Claim))().$ctor$1(function*()
                {
                    let $en8 = claims.SCG$IEnumerable$$$GetEnumerator();
                    while ($en8.SC$1$IEnumerator$MoveNext())
                    {
                        let claim = $en8.SCG$IEnumerator$$$Current;
                        {
                            /*string*/ let type = null;
                            if (this._outboundClaimTypeMap.SCG$IDictionary$$$$TryGetValue(claim.Type, $.$ref(() => type, ($v) => type = $v, $.$$.S.String)))
                            {
                                yield new $.$ssc.SSC.Claim().$ctor$4(type, claim.Value, claim.ValueType, claim.Issuer, claim.OriginalIssuer, claim.Subject);
                            }
                            else 
                            {
                                yield claim;
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(296353333376)
            
            //--TRIMMABLE-BOUNDARY-START(292058366080)
            /*Dictionary<string, object> */ OutboundClaimTypeTransform(/*IDictionary<string, object>*/ claimCollection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058366080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let claims = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object))().$ctor$1();
                let $en10 = claimCollection.SCG$IDictionary$$$$Keys.SCG$IEnumerable$$$GetEnumerator();
                while ($en10.SC$1$IEnumerator$MoveNext())
                {
                    let claimType = $en10.SCG$IEnumerator$$$Current;
                    {
                        /*string*/ let type;
                        if (this._outboundClaimTypeMap.SCG$IDictionary$$$$TryGetValue(claimType, $.$ref(() => type, ($v) => type = $v, $.$$.S.String)))
                        {
                            claims.set_Item(type, claimCollection.SCG$IDictionary$$$$get_Item(claimType));
                        }
                        else 
                        {
                            claims.set_Item(claimType, claimCollection.SCG$IDictionary$$$$get_Item(claimType));
                        }
                    }
                }
                return claims;
            }
            //--TRIMMABLE-BOUNDARY-END(292058366080)
            
            //--TRIMMABLE-BOUNDARY-START(300648300672)
            /*JwtSecurityToken */ ReadJwtToken(/*string*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648300672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrEmpty(token))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("token");
                }
                if (token.length > this.MaximumTokenSizeInBytes)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14($.$mil.MIL.LogHelper.FormatInvariant("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.S.Int32)) ], null, null))));
                }
                if (!this.CanReadToken(token))
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenMalformedException().$ctor$22("IDX12709: CanReadToken() returned false. JWT is not well formed.\nThe token needs to be in JWS or JWE Compact Serialization Format. (JWS): 'EncodedHeader.EncodedPayload.EncodedSignature'. (JWE): 'EncodedProtectedHeader.EncodedEncryptedKey.EncodedInitializationVector.EncodedCiphertext.EncodedAuthenticationTag'."/*LogMessages.IDX12709*/));
                }
                /*var*/ let jwtToken = new $.$sitj.SITJ.JwtSecurityToken().$ctor$5(null, null, null, null, null, null);
                jwtToken.Decode($.$$.S.String.Split$1.call(token, /*.*/ 46, 0), token);
                return jwtToken;
            }
            //--TRIMMABLE-BOUNDARY-END(300648300672)
            
            //--TRIMMABLE-BOUNDARY-START(304943267968)
            /*SecurityToken */ ReadToken(/*string*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943267968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ReadJwtToken(token);
            }
            //--TRIMMABLE-BOUNDARY-END(304943267968)
            
            //--TRIMMABLE-BOUNDARY-START(309238235264)
            /*SecurityToken */ ReadToken$1(/*XmlReader*/ reader, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238235264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(309238235264)
            
            //--TRIMMABLE-BOUNDARY-START(438087254144)
            /*ClaimsPrincipal */ ValidateToken(/*string*/ token, /*TokenValidationParameters*/ validationParameters, /*out SecurityToken*/ validatedToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438087254144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.String.IsNullOrWhiteSpace(token))
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("token");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters");
                }
                if (token.length > this.MaximumTokenSizeInBytes)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14($.$mil.MIL.LogHelper.FormatInvariant("IDX10209: Token has length: '{0}' which is larger than the MaximumTokenSizeInBytes: '{1}'."/*TokenLogMessages.IDX10209*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(token.length, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(this.MaximumTokenSizeInBytes, $.$$.S.Int32)) ], null, null))));
                }
                /*int*/ let tokenPartCount = $.$mij.MIJ.JwtTokenUtilities.CountJwtTokenPart(token, ((5/*JwtConstants.MaxJwtSegmentCount*/ + 1) | 0));
                if (tokenPartCount !== 3/*JwtConstants.JwsSegmentCount*/ && tokenPartCount !== 5/*JwtConstants.JweSegmentCount*/)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenMalformedException().$ctor$22("IDX12741: JWT must have three segments (JWS) or five segments (JWE)."/*LogMessages.IDX12741*/));
                }
                if (tokenPartCount === 5/*JwtConstants.JweSegmentCount*/)
                {
                    /*var*/ let jwtToken = this.ReadJwtToken(token);
                    /*var*/ let decryptedJwt = this.DecryptToken(jwtToken, validationParameters);
                    return this.ValidateToken$2(decryptedJwt, jwtToken, validationParameters, validatedToken);
                }
                else 
                {
                    return this.ValidateToken$2(token, null, validationParameters, validatedToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(438087254144)
            
            //--TRIMMABLE-BOUNDARY-START(442382221440)
            /*ClaimsPrincipal */ ValidateToken$2(/*string*/ token, /*JwtSecurityToken*/ outerToken, /*TokenValidationParameters*/ validationParameters, /*out SecurityToken*/ signatureValidatedToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442382221440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*BaseConfiguration*/ let currentConfiguration = null;
                if (validationParameters.ConfigurationManager !== null)
                {
                    try
                    {
                        currentConfiguration = validationParameters.ConfigurationManager.GetBaseConfigurationAsync($.$$.ST$1.CancellationToken.None).ConfigureAwait$2(false).GetAwaiter().GetResult();
                    }
                    catch(ex)
                    {
                        if ($.$mil.MIL.LogHelper.IsEnabled(3/*EventLogLevel.Warning*/))
                        {
                            $.$mil.MIL.LogHelper.LogWarning($.$mil.MIL.LogHelper.FormatInvariant("IDX10261: Unable to retrieve configuration from authority: '{0}'. \nProceeding with token validation in case the relevant properties have been set manually on the TokenValidationParameters. Exception caught: \n {1}. See https://aka.ms/validate-using-configuration-manager for additional information."/*TokenLogMessages.IDX10261*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(validationParameters.ConfigurationManager.MetadataAddress), ex.ToString() ], null, null)), $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                        }
                    }
                }
                /*ExceptionDispatchInfo*/ let exceptionThrown;
                /*ClaimsPrincipal*/ let claimsPrincipal = outerToken !== null ? this.ValidateJWE(token, outerToken, validationParameters, currentConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.SRE$1.ExceptionDispatchInfo)) : this.ValidateJWS(token, validationParameters, currentConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.SRE$1.ExceptionDispatchInfo));
                if (validationParameters.ConfigurationManager !== null)
                {
                    if (claimsPrincipal !== null)
                    {
                        if (currentConfiguration !== null)
                        {
                            validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                        }
                        return claimsPrincipal;
                    }
                    else if ($.$mit.MIT$1.TokenUtilities.IsRecoverableException(exceptionThrown.SourceException, (currentConfiguration !== null && currentConfiguration.TokenDecryptionKeys.SCG$ICollection$$$Count > 0)))
                    {
                        if (currentConfiguration !== null)
                        {
                            this.TelemetryClient.MIT$ITelemetryClient$IncrementConfigurationRefreshRequestCounter$2(validationParameters.ConfigurationManager.MetadataAddress, "LastKnownGood"/*TelemetryConstants.Protocols.Lkg*/, "Unknown"/*TelemetryConstants.Protocols.ConfigurationSourceUnknown*/);
                            validationParameters.ConfigurationManager.RequestRefresh();
                            validationParameters.RefreshBeforeValidation = true;
                            /*var*/ let lastConfig = currentConfiguration;
                            currentConfiguration = validationParameters.ConfigurationManager.GetBaseConfigurationAsync($.$$.ST$1.CancellationToken.None).ConfigureAwait$2(false).GetAwaiter().GetResult();
                            if (lastConfig !== currentConfiguration)
                            {
                                claimsPrincipal = outerToken !== null ? this.ValidateJWE(token, outerToken, validationParameters, currentConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.SRE$1.ExceptionDispatchInfo)) : this.ValidateJWS(token, validationParameters, currentConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.SRE$1.ExceptionDispatchInfo));
                                if (claimsPrincipal !== null)
                                {
                                    validationParameters.ConfigurationManager.LastKnownGoodConfiguration = currentConfiguration;
                                    return claimsPrincipal;
                                }
                            }
                        }
                        if (validationParameters.ConfigurationManager.UseLastKnownGoodConfiguration)
                        {
                            validationParameters.RefreshBeforeValidation = false;
                            validationParameters.ValidateWithLKG = true;
                            /*var*/ let recoverableException = exceptionThrown.SourceException;
                            /*string*/ let kid = outerToken !== null ? outerToken.Header.Kid : ($.$sitj.SITJ.JwtSecurityTokenHandler.ValidateSignatureUsingDelegates(token, validationParameters, null) ?? this.GetJwtSecurityTokenFromToken(token, validationParameters)).Header.Kid;
                            let $i22 = 0;
                            let $arr22 = validationParameters.ConfigurationManager.GetValidLkgConfigurations();
                            while ($i22 < $arr22.length)
                            {
                                let lkgConfiguration = $arr22[$i22++];
                                if (!$.$dsp(lkgConfiguration, $.$$.S.Object, ($t) => $t.Equals$1, currentConfiguration) && $.$mit.MIT$1.TokenUtilities.IsRecoverableConfiguration(kid, currentConfiguration, lkgConfiguration, recoverableException))
                                {
                                    claimsPrincipal = outerToken !== null ? this.ValidateJWE(token, outerToken, validationParameters, lkgConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.SRE$1.ExceptionDispatchInfo)) : this.ValidateJWS(token, validationParameters, lkgConfiguration, signatureValidatedToken, $.$ref(() => exceptionThrown, ($v) => exceptionThrown = $v, $.$$.SRE$1.ExceptionDispatchInfo));
                                    if (claimsPrincipal !== null)
                                    {
                                        return claimsPrincipal;
                                    }
                                }
                            }
                        }
                    }
                }
                if (claimsPrincipal !== null)
                {
                    return claimsPrincipal;
                }
                exceptionThrown.Throw();
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(442382221440)
            
            //--TRIMMABLE-BOUNDARY-START(403727515776)
            /*ClaimsPrincipal */ ValidateJWE(/*string*/ decryptedJwt, /*JwtSecurityToken*/ outerToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ currentConfiguration, /*out SecurityToken*/ signatureValidatedToken, /*out ExceptionDispatchInfo*/ exceptionThrown)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403727515776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                exceptionThrown.$v = null;
                try
                {
                    /*SecurityToken*/ let innerToken;
                    /*ClaimsPrincipal*/ let claimsPrincipal = this.ValidateJWS(decryptedJwt, validationParameters, currentConfiguration, $.$ref(() => innerToken, ($v) => innerToken = $v, $.$mit.MIT$1.SecurityToken), exceptionThrown);
                    outerToken.InnerToken = $.$as(innerToken, $.$sitj.SITJ.JwtSecurityToken);
                    signatureValidatedToken.$v = exceptionThrown.$v === null ? outerToken : null;
                    return claimsPrincipal;
                }
                catch(ex)
                {
                    exceptionThrown.$v = $.$$.SRE$1.ExceptionDispatchInfo.Capture(ex);
                    signatureValidatedToken.$v = null;
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(403727515776)
            
            //--TRIMMABLE-BOUNDARY-START(408022483072)
            /*ClaimsPrincipal */ ValidateJWS(/*string*/ token, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ currentConfiguration, /*out SecurityToken*/ signatureValidatedToken, /*out ExceptionDispatchInfo*/ exceptionThrown)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022483072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                exceptionThrown.$v = null;
                try
                {
                    /*ClaimsPrincipal*/ let claimsPrincipal;
                    if (validationParameters.SignatureValidator !== null || validationParameters.SignatureValidatorUsingConfiguration !== null)
                    {
                        signatureValidatedToken.$v = $.$sitj.SITJ.JwtSecurityTokenHandler.ValidateSignatureUsingDelegates(token, validationParameters, currentConfiguration);
                        claimsPrincipal = this.ValidateTokenPayload($.$as(signatureValidatedToken.$v, $.$sitj.SITJ.JwtSecurityToken), validationParameters, currentConfiguration);
                        if (currentConfiguration === null)
                        {
                            this.ValidateIssuerSecurityKey(signatureValidatedToken.$v.SigningKey, $.$as(signatureValidatedToken.$v, $.$sitj.SITJ.JwtSecurityToken), validationParameters);
                        }
                        else 
                        {
                            $.$mit.MIT$1.Validators.ValidateIssuerSecurityKey(signatureValidatedToken.$v.SigningKey, signatureValidatedToken.$v, validationParameters, currentConfiguration);
                        }
                    }
                    else 
                    {
                        /*JwtSecurityToken*/ let jwtToken = this.GetJwtSecurityTokenFromToken(token, validationParameters);
                        if (validationParameters.ValidateSignatureLast)
                        {
                            claimsPrincipal = this.ValidateTokenPayload(jwtToken, validationParameters, currentConfiguration);
                            jwtToken = this.ValidateSignatureAndIssuerSecurityKey(token, jwtToken, validationParameters, currentConfiguration);
                            signatureValidatedToken.$v = jwtToken;
                        }
                        else 
                        {
                            signatureValidatedToken.$v = this.ValidateSignatureAndIssuerSecurityKey(token, jwtToken, validationParameters, currentConfiguration);
                            claimsPrincipal = this.ValidateTokenPayload($.$as(signatureValidatedToken.$v, $.$sitj.SITJ.JwtSecurityToken), validationParameters, currentConfiguration);
                        }
                    }
                    return claimsPrincipal;
                }
                catch(ex)
                {
                    exceptionThrown.$v = $.$$.SRE$1.ExceptionDispatchInfo.Capture(ex);
                    signatureValidatedToken.$v = null;
                    return null;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(408022483072)
            
            //--TRIMMABLE-BOUNDARY-START(433792286848)
            static /*JwtSecurityToken */ ValidateSignatureUsingDelegates(/*string*/ token, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433792286848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(validationParameters, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters") });
                if (validationParameters.SignatureValidatorUsingConfiguration !== null)
                {
                    /*var*/ let validatedJwtToken = validationParameters.SignatureValidatorUsingConfiguration.Invoke(token, validationParameters, configuration);
                    if (validatedJwtToken === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10505: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters returned null when validating token: '{0}'."/*TokenLogMessages.IDX10505*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    let validatedJwt;
                    if (!($.$is(validatedJwtToken, $.$sitj.SITJ.JwtSecurityToken, { set $v($v){ validatedJwt = $v; } })))
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10506: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters did not return a '{0}', but returned a '{1}' when validating token: '{2}'.\nIf you are using ASP.NET Core 8 or later, see https://learn.microsoft.com/en-us/dotnet/core/compatibility/aspnet-core/8.0/securitytoken-events for more details."/*TokenLogMessages.IDX10506*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$sitj.SITJ.JwtSecurityToken.$type), $.$mil.MIL.LogHelper.MarkAsNonPII($.$$.S.Object.GetType.call(validatedJwtToken)), $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    return validatedJwt;
                }
                else if (validationParameters.SignatureValidator !== null)
                {
                    /*var*/ let validatedJwtToken = validationParameters.SignatureValidator.Invoke(token, validationParameters);
                    if (validatedJwtToken === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10505: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters returned null when validating token: '{0}'."/*TokenLogMessages.IDX10505*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    let validatedJwt;
                    if (!($.$is(validatedJwtToken, $.$sitj.SITJ.JwtSecurityToken, { set $v($v){ validatedJwt = $v; } })))
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10506: Signature validation failed. The user defined 'Delegate' specified on TokenValidationParameters did not return a '{0}', but returned a '{1}' when validating token: '{2}'.\nIf you are using ASP.NET Core 8 or later, see https://learn.microsoft.com/en-us/dotnet/core/compatibility/aspnet-core/8.0/securitytoken-events for more details."/*TokenLogMessages.IDX10506*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$sitj.SITJ.JwtSecurityToken.$type), $.$mil.MIL.LogHelper.MarkAsNonPII($.$$.S.Object.GetType.call(validatedJwtToken)), $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    return validatedJwt;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(433792286848)
            
            //--TRIMMABLE-BOUNDARY-START(429497319552)
            /*JwtSecurityToken */ ValidateSignatureAndIssuerSecurityKey(/*string*/ token, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429497319552);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*JwtSecurityToken*/ let validatedToken = this.ValidateSignature$2(token, jwtToken, validationParameters, configuration);
                if (configuration === null)
                {
                    this.ValidateIssuerSecurityKey(jwtToken.SigningKey, jwtToken, validationParameters);
                }
                else 
                {
                    $.$mit.MIT$1.Validators.ValidateIssuerSecurityKey(jwtToken.SigningKey, jwtToken, validationParameters, configuration);
                }
                return validatedToken;
            }
            //--TRIMMABLE-BOUNDARY-END(429497319552)
            
            //--TRIMMABLE-BOUNDARY-START(257698627712)
            /*JwtSecurityToken */ GetJwtSecurityTokenFromToken(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698627712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (validationParameters.TokenReader !== null)
                {
                    /*var*/ let securityToken = validationParameters.TokenReader.Invoke(token, validationParameters);
                    if (securityToken === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10510: Token validation failed. The user defined 'Delegate' set on TokenValidationParameters.TokenReader returned null when reading token: '{0}'."/*TokenLogMessages.IDX10510*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    let jwtToken;
                    if (!($.$is(securityToken, $.$sitj.SITJ.JwtSecurityToken, { set $v($v){ jwtToken = $v; } })))
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10509: Token validation failed. The user defined 'Delegate' set on TokenValidationParameters.TokenReader did not return a '{0}', but returned a '{1}' when reading token: '{2}'."/*TokenLogMessages.IDX10509*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$mij.MIJ.JsonWebToken.$type), $.$mil.MIL.LogHelper.MarkAsNonPII($.$$.S.Object.GetType.call(securityToken)), $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(token, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                    }
                    return jwtToken;
                }
                else 
                {
                    return this.ReadJwtToken(token);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(257698627712)
            
            //--TRIMMABLE-BOUNDARY-START(455267123328)
            /*ClaimsPrincipal */ ValidateTokenPayload$1(/*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455267123328);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.ValidateTokenPayload(jwtToken, validationParameters, null);
            }
            //--TRIMMABLE-BOUNDARY-END(455267123328)
            
            //--TRIMMABLE-BOUNDARY-START(450972156032)
            /*ClaimsPrincipal */ ValidateTokenPayload(/*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450972156032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters");
                }
                /*DateTime?*/ let expires = (jwtToken.Payload.Expiration === null) ? null : new ($.$$.S.Nullable$$($.$$.S.DateTime))().$ctor$3(jwtToken.ValidTo);
                /*DateTime?*/ let notBefore = (jwtToken.Payload.NotBefore === null) ? null : new ($.$$.S.Nullable$$($.$$.S.DateTime))().$ctor$3(jwtToken.ValidFrom);
                this.ValidateLifetime($.$clone(notBefore), $.$clone(expires), jwtToken, validationParameters);
                this.ValidateAudience(jwtToken.Audiences, jwtToken, validationParameters);
                /*string*/ let issuer = configuration === null ? this.ValidateIssuer(jwtToken.Issuer, jwtToken, validationParameters) : $.$mit.MIT$1.Validators.ValidateIssuer(jwtToken.Issuer, jwtToken, validationParameters, configuration);
                this.ValidateTokenReplay($.$clone(expires), jwtToken.RawData, validationParameters);
                if (validationParameters.ValidateActor && !$.$$.S.String.IsNullOrWhiteSpace(jwtToken.Actor))
                {
                    this.ValidateToken(jwtToken.Actor, validationParameters.ActorValidationParameters ?? validationParameters, $.$discardRef());
                }
                $.$mit.MIT$1.Validators.ValidateTokenType$1(jwtToken.Header.Typ, jwtToken, validationParameters);
                /*var*/ let identity = this.CreateClaimsIdentity(jwtToken, issuer, validationParameters);
                if (validationParameters.SaveSigninToken)
                {
                    identity.BootstrapContext = jwtToken.RawData;
                }
                if ($.$mil.MIL.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                {
                    $.$mil.MIL.LogHelper.LogInformation("IDX10241: Security token validated. token: '{0}'."/*TokenLogMessages.IDX10241*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ jwtToken ], null, null));
                }
                return new $.$ssc.SSC.ClaimsPrincipal().$ctor$5(identity);
            }
            //--TRIMMABLE-BOUNDARY-END(450972156032)
            
            //--TRIMMABLE-BOUNDARY-START(81604968576)
            /*ClaimsPrincipal */ CreateClaimsPrincipalFromToken(/*JwtSecurityToken*/ jwtToken, /*string*/ issuer, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604968576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let identity = this.CreateClaimsIdentity(jwtToken, issuer, validationParameters);
                if (validationParameters.SaveSigninToken)
                {
                    identity.BootstrapContext = jwtToken.RawData;
                }
                if ($.$mil.MIL.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                {
                    $.$mil.MIL.LogHelper.LogInformation("IDX10241: Security token validated. token: '{0}'."/*TokenLogMessages.IDX10241*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ jwtToken ], null, null));
                }
                return new $.$ssc.SSC.ClaimsPrincipal().$ctor$5(identity);
            }
            //--TRIMMABLE-BOUNDARY-END(81604968576)
            
            //--TRIMMABLE-BOUNDARY-START(463857057920)
            /*string */ WriteToken(/*SecurityToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463857057920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (token === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("token");
                }
                /*JwtSecurityToken*/ let jwtToken = $.$as(token, $.$sitj.SITJ.JwtSecurityToken);
                if (jwtToken === null)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$13($.$mil.MIL.LogHelper.FormatInvariant("IDX12706: '{0}' can only write SecurityTokens of type: '{1}', 'token' type is: '{2}'."/*LogMessages.IDX12706*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler"/*_className*/), $.$mil.MIL.LogHelper.MarkAsNonPII($.$sitj.SITJ.JwtSecurityToken.$type), $.$mil.MIL.LogHelper.MarkAsNonPII($.$$.S.Object.GetType.call(token)) ], null, null)), "token"));
                }
                /*var*/ let encodedPayload = jwtToken.EncodedPayload;
                /*var*/ let encodedSignature = $.$$.S.String.Empty;
                /*var*/ let encodedHeader = $.$$.S.String.Empty;
                if (jwtToken.InnerToken !== null)
                {
                    if (jwtToken.SigningCredentials !== null)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenEncryptionFailedException().$ctor$14("IDX12736: JwtSecurityToken.SigningCredentials is not supported when JwtSecurityToken.InnerToken is set."/*LogMessages.IDX12736*/));
                    }
                    if (jwtToken.InnerToken.Header.EncryptingCredentials !== null)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenEncryptionFailedException().$ctor$14("IDX12737: EncryptingCredentials set on JwtSecurityToken.InnerToken is not supported."/*LogMessages.IDX12737*/));
                    }
                    if (jwtToken.Header.EncryptingCredentials === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenEncryptionFailedException().$ctor$14("IDX12735: If JwtSecurityToken.InnerToken != null, then JwtSecurityToken.Header.EncryptingCredentials must be set."/*LogMessages.IDX12735*/));
                    }
                    if (jwtToken.InnerToken.SigningCredentials !== null)
                    {
                        encodedSignature = $.$mij.MIJ.JwtTokenUtilities.CreateEncodedSignature$2($.$$.S.String.Concat$13(jwtToken.InnerToken.EncodedHeader, ".", jwtToken.EncodedPayload), jwtToken.InnerToken.SigningCredentials);
                    }
                    return this.EncryptToken(new $.$sitj.SITJ.JwtSecurityToken().$ctor$2(jwtToken.InnerToken.Header, jwtToken.InnerToken.Payload, jwtToken.InnerToken.EncodedHeader, encodedPayload, encodedSignature), jwtToken.EncryptingCredentials, jwtToken.InnerToken.Header.Typ, null).RawData;
                }
                /*var*/ let header = jwtToken.EncryptingCredentials === null ? jwtToken.Header : new $.$sitj.SITJ.JwtHeader().$ctor$20(jwtToken.SigningCredentials);
                encodedHeader = header.Base64UrlEncode();
                if (jwtToken.SigningCredentials !== null)
                {
                    encodedSignature = $.$mij.MIJ.JwtTokenUtilities.CreateEncodedSignature$2($.$$.S.String.Concat$13(encodedHeader, ".", encodedPayload), jwtToken.SigningCredentials);
                }
                if (jwtToken.EncryptingCredentials !== null)
                {
                    return this.EncryptToken(new $.$sitj.SITJ.JwtSecurityToken().$ctor$2(header, jwtToken.Payload, encodedHeader, encodedPayload, encodedSignature), jwtToken.EncryptingCredentials, jwtToken.Header.Typ, null).RawData;
                }
                else 
                {
                    return $.$$.S.String.Concat$10($.$$.S.ReadOnlySpan$$($.$$.S.String).op_Implicit$1([ encodedHeader, ".", encodedPayload, ".", encodedSignature ]));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(463857057920)
            
            //--TRIMMABLE-BOUNDARY-START(313533202560)
            static /*void */ RecordSignatureValidationTelemetry(/*Microsoft.IdentityModel.Telemetry.ITelemetryClient*/ telemetryClient, /*string*/ errorType, /*SecurityToken*/ securityToken, /*string*/ algorithm, /*SecurityKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533202560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$mit.MIT.CryptoTelemetry.RecordSignatureValidationTelemetry)
                {
                    telemetryClient.MIT$ITelemetryClient$IncrementSignatureValidationCounter(errorType, securityToken.Issuer, algorithm, key);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(313533202560)
            
            //--TRIMMABLE-BOUNDARY-START(416612417664)
            static /*bool */ ValidateSignature(/*byte[]*/ encodedBytes, /*byte[]*/ signature, /*SecurityKey*/ key, /*string*/ algorithm, /*SecurityToken*/ securityToken, /*TokenValidationParameters*/ validationParameters, /*Microsoft.IdentityModel.Telemetry.ITelemetryClient*/ telemetryClient)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612417664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*CryptoProviderFactory*/ let cryptoProviderFactory = null;
                /*SignatureProvider*/ let signatureProvider = null;
                try
                {
                    $.$mit.MIT$1.Validators.ValidateAlgorithm(algorithm, key, securityToken, validationParameters);
                }
                catch($e)
                {
                    $.$sitj.SITJ.JwtSecurityTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "AlgorithmNotSupported"/*TelemetryConstants.SignatureValidationErrors.AlgorithmNotSupported*/, securityToken, algorithm, key);
                    throw $e;
                }
                try
                {
                    cryptoProviderFactory = validationParameters.CryptoProviderFactory ?? key.CryptoProviderFactory;
                    signatureProvider = cryptoProviderFactory.CreateForVerifying$1(key, algorithm);
                    if (signatureProvider === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.InvalidOperationException().$ctor$12($.$mil.MIL.LogHelper.FormatInvariant("IDX10636: CryptoProviderFactory.CreateForVerifying returned null for key: '{0}', signatureAlgorithm: '{1}'."/*TokenLogMessages.IDX10636*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(key === null ? "Null" : key.KeyId), $.$mil.MIL.LogHelper.MarkAsNonPII(algorithm) ], null, null))));
                    }
                }
                catch($e)
                {
                    $.$sitj.SITJ.JwtSecurityTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "SignatureProviderCreationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureProviderCreationFailed*/, securityToken, algorithm, key);
                    throw $e;
                }
                try
                {
                    /*bool*/ let isValid = signatureProvider.Verify(encodedBytes, signature);
                    $.$sitj.SITJ.JwtSecurityTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, isValid ? "None"/*TelemetryConstants.SignatureValidationErrors.None*/ : "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, securityToken, algorithm, key);
                    return isValid;
                }
                catch($e)
                {
                    $.$sitj.SITJ.JwtSecurityTokenHandler.RecordSignatureValidationTelemetry(telemetryClient, "SignatureVerificationFailed"/*TelemetryConstants.SignatureValidationErrors.SignatureVerificationFailed*/, securityToken, algorithm, key);
                    throw $e;
                }
                finally
                {
                    {
                        cryptoProviderFactory.ReleaseSignatureProvider(signatureProvider);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(416612417664)
            
            //--TRIMMABLE-BOUNDARY-START(420907384960)
            /*JwtSecurityToken */ ValidateSignature$1(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420907384960);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*JwtSecurityToken*/ let validatedJwt = $.$sitj.SITJ.JwtSecurityTokenHandler.ValidateSignatureUsingDelegates(token, validationParameters, null);
                /*JwtSecurityToken*/ let parsedJwtToken = this.GetJwtSecurityTokenFromToken(token, validationParameters);
                return this.ValidateSignature$2(token, validatedJwt ?? parsedJwtToken, validationParameters, null);
            }
            //--TRIMMABLE-BOUNDARY-END(420907384960)
            
            //--TRIMMABLE-BOUNDARY-START(425202352256)
            /*JwtSecurityToken */ ValidateSignature$2(/*string*/ token, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters, /*BaseConfiguration*/ configuration)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425202352256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*byte[]*/ let encodedBytes = $.$$.ST.Encoding.UTF8.GetBytes$8($.$strNN($.$strNN(jwtToken.RawHeader) + ".") + $.$strNN(jwtToken.RawPayload));
                /*bool*/ let kidMatched = false;
                /*IEnumerable<SecurityKey>*/ let keys = null;
                if ($.$$.S.String.IsNullOrEmpty(jwtToken.RawSignature))
                {
                    if (validationParameters.RequireSignedTokens)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10504: Unable to validate signature, token does not have a signature: '{0}'."/*TokenLogMessages.IDX10504*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ jwtToken ], null, null))));
                    }
                    else 
                    {
                        return jwtToken;
                    }
                }
                if (validationParameters.IssuerSigningKeyResolverUsingConfiguration !== null)
                {
                    keys = validationParameters.IssuerSigningKeyResolverUsingConfiguration.Invoke(token, jwtToken, jwtToken.Header.Kid, validationParameters, configuration);
                }
                if (validationParameters.IssuerSigningKeyResolver !== null)
                {
                    keys = validationParameters.IssuerSigningKeyResolver.Invoke(token, jwtToken, jwtToken.Header.Kid, validationParameters);
                }
                else 
                {
                    /*var*/ let key = configuration === null ? this.ResolveIssuerSigningKey(token, jwtToken, validationParameters) : $.$mij.MIJ.JwtTokenUtilities.ResolveTokenSigningKey(jwtToken.Header.Kid, jwtToken.Header.X5t, validationParameters, configuration);
                    if (key !== null)
                    {
                        kidMatched = true;
                        keys = $.$$.SRC.RuntimeHelpers.CreateArray($.$mit.MIT$1.SecurityKey.$type, [ key ], null, null);
                    }
                }
                if (keys === null && validationParameters.TryAllIssuerSigningKeys)
                {
                    keys = $.$mit.MIT$1.TokenUtilities.GetAllSigningKeys$1(configuration, validationParameters);
                }
                /*StringBuilder*/ let exceptionStrings = null;
                /*StringBuilder*/ let keysAttempted = null;
                /*bool*/ let kidExists = !$.$$.S.String.IsNullOrEmpty(jwtToken.Header.Kid);
                /*byte[]*/ let signatureBytes;
                try
                {
                    signatureBytes = $.$mit.MIT$1.Base64UrlEncoder.DecodeBytes(jwtToken.RawSignature);
                }
                catch(e)
                {
                    throw new $.$mit.MIT$1.SecurityTokenInvalidSignatureException().$ctor$21("IDX10508: Signature validation failed. Signature is improperly formatted."/*TokenLogMessages.IDX10508*/, e);
                }
                if (keys !== null)
                {
                    let $en29 = keys.SCG$IEnumerable$$$GetEnumerator();
                    while ($en29.SC$1$IEnumerator$MoveNext())
                    {
                        let key = $en29.SCG$IEnumerator$$$Current;
                        {
                            try
                            {
                                if ($.$sitj.SITJ.JwtSecurityTokenHandler.ValidateSignature(encodedBytes, signatureBytes, key, jwtToken.Header.Alg, jwtToken, validationParameters, this.TelemetryClient))
                                {
                                    if ($.$mil.MIL.LogHelper.IsEnabled(4/*EventLogLevel.Informational*/))
                                    {
                                        $.$mil.MIL.LogHelper.LogInformation("IDX10242: Security token: '{0}' has a valid signature."/*TokenLogMessages.IDX10242*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ jwtToken ], null, null));
                                    }
                                    jwtToken.SigningKey = key;
                                    return jwtToken;
                                }
                            }
                            catch(ex)
                            {
                                (exceptionStrings ??= new $.$$.ST.StringBuilder().$ctor$1()).AppendLine$3(ex.ToString());
                            }
                            if (key !== null)
                            {
                                (keysAttempted ??= new $.$$.ST.StringBuilder().$ctor$1()).Append$21(key.ToString());
                                if (kidExists && !kidMatched && key.KeyId !== null)
                                {
                                    kidMatched = $.$$.S.String.Equals$2.call(jwtToken.Header.Kid, key.KeyId, $.$is(key, $.$mit.MIT$1.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/);
                                }
                            }
                        }
                    }
                }
                /*var*/ let keysInTokenValidationParameters = $.$mit.MIT$1.TokenUtilities.GetAllSigningKeys$1(null, validationParameters);
                /*var*/ let keysInConfiguration = $.$mit.MIT$1.TokenUtilities.GetAllSigningKeys$1(configuration, null);
                /*var*/ let numKeysInTokenValidationParameters = $.$sl.SL.Enumerable.Count$1($.$mit.MIT$1.SecurityKey, keysInTokenValidationParameters);
                /*var*/ let numKeysInConfiguration = $.$sl.SL.Enumerable.Count$1($.$mit.MIT$1.SecurityKey, keysInConfiguration);
                if (kidExists)
                {
                    if (kidMatched)
                    {
                        /*JwtSecurityToken*/ let localJwtToken = jwtToken;
                        /*var*/ let isKidInTVP = $.$sl.SL.Enumerable.Any($.$mit.MIT$1.SecurityKey, keysInTokenValidationParameters, new ($.$$.S.Func$$$($.$mit.MIT$1.SecurityKey, $.$$.S.Boolean))().$ctor(this,  (/*x*/ x) =>
                        {
                            return $.$$.S.String.Equals$5.call(x.KeyId, localJwtToken.Header.Kid);
                        }, $XZONsf ??= {"r":262145,"p":[{"n":"x","p":13631614}],"n":"","d":589952,"h":0,"f":17825794}));
                        /*var*/ let keyLocation = isKidInTVP ? "TokenValidationParameters" : "Configuration";
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenInvalidSignatureException().$ctor$22($.$mil.MIL.LogHelper.FormatInvariant("IDX10511: Signature validation failed. Keys tried: '{0}'. \nNumber of keys in TokenValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'. \nMatched key was in '{3}'. \nkid: '{4}'. \nExceptions caught:\n '{5}'.\ntoken: '{6}'. See https://aka.ms/IDX10511 for details."/*TokenLogMessages.IDX10511*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII(keyLocation), $.$mil.MIL.LogHelper.MarkAsNonPII(jwtToken.Header.Kid), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                    /*DateTime?*/ let expires = (jwtToken.Payload.Expiration === null) ? null : new ($.$$.S.Nullable$$($.$$.S.DateTime))().$ctor$3(jwtToken.ValidTo);
                    /*DateTime?*/ let notBefore = (jwtToken.Payload.NotBefore === null) ? null : new ($.$$.S.Nullable$$($.$$.S.DateTime))().$ctor$3(jwtToken.ValidFrom);
                    if (!validationParameters.ValidateSignatureLast)
                    {
                        $.$mit.MIT$1.InternalValidators.ValidateAfterSignatureFailed(jwtToken, $.$clone(notBefore), $.$clone(expires), jwtToken.Audiences, validationParameters, configuration);
                    }
                }
                if (!(keysAttempted === null))
                {
                    if (kidExists)
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenSignatureKeyNotFoundException().$ctor$28($.$mil.MIL.LogHelper.FormatInvariant("IDX10503: Signature validation failed. The token's kid is: '{0}', but did not match any keys in TokenValidationParameters or Configuration. Keys tried: '{1}'.\nNumber of keys in TokenValidationParameters: '{2}'. \nNumber of keys in Configuration: '{3}'.\nExceptions caught:\n '{4}'.\ntoken: '{5}'. See https://aka.ms/IDX10503 for details."/*TokenLogMessages.IDX10503*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(jwtToken.Header.Kid), $.$mil.MIL.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.S.Int32)), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                    else 
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenSignatureKeyNotFoundException().$ctor$28($.$mil.MIL.LogHelper.FormatInvariant("IDX10517: Signature validation failed. The token's kid is missing. Keys tried: '{0}'.\nNumber of keys in TokenValidationParameters: '{1}'. \nNumber of keys in Configuration: '{2}'.\nExceptions caught:\n '{3}'.\ntoken: '{4}'. See https://aka.ms/IDX10503 for details."/*TokenLogMessages.IDX10517*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(keysAttempted ?? ""), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(numKeysInTokenValidationParameters, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(numKeysInConfiguration, $.$$.S.Int32)), exceptionStrings ?? "", jwtToken ], null, null))));
                    }
                }
                $.$sitj.SITJ.JwtSecurityTokenHandler.RecordSignatureValidationTelemetry(this.TelemetryClient, "SigningKeyNotFound"/*TelemetryConstants.SignatureValidationErrors.SigningKeyNotFound*/, jwtToken, jwtToken.SignatureAlgorithm, null);
                throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenSignatureKeyNotFoundException().$ctor$28("IDX10500: Signature validation failed. No security keys were provided to validate the signature."/*TokenLogMessages.IDX10500*/));
            }
            //--TRIMMABLE-BOUNDARY-END(425202352256)
            
            //--TRIMMABLE-BOUNDARY-START(249108693120)
            static /*IEnumerable<SecurityKey> */ GetAllDecryptionKeys(/*TokenValidationParameters*/ validationParameters)
            {
                return new ($.$$.N.YieldToIterator$$($.$mit.MIT$1.SecurityKey))().$ctor$1(function*()
                {
                    if (validationParameters.TokenDecryptionKey !== null)
                    {
                        yield validationParameters.TokenDecryptionKey;
                    }
                    if (validationParameters.TokenDecryptionKeys !== null)
                    {
                        let $en30 = validationParameters.TokenDecryptionKeys.SCG$IEnumerable$$$GetEnumerator();
                        while ($en30.SC$1$IEnumerator$MoveNext())
                        {
                            let key = $en30.SCG$IEnumerator$$$Current;
                            {
                                yield key;
                            }
                        }
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(249108693120)
            
            //--TRIMMABLE-BOUNDARY-START(68720066688)
            /*ClaimsIdentity */ CreateClaimsIdentity(/*JwtSecurityToken*/ jwtToken, /*string*/ issuer, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720066688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters");
                }
                /*var*/ let actualIssuer = issuer;
                if ($.$$.S.String.IsNullOrWhiteSpace(issuer))
                {
                    if ($.$mil.MIL.LogHelper.IsEnabled(5/*EventLogLevel.Verbose*/))
                    {
                        $.$mil.MIL.LogHelper.LogVerbose("IDX10244: Issuer is null or empty. Using runtime default for creating claims '{0}'."/*TokenLogMessages.IDX10244*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/) ], null, null));
                    }
                    actualIssuer = "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                }
                return this.MapInboundClaims ? this.CreateClaimsIdentityWithMapping(jwtToken, actualIssuer, validationParameters) : this.CreateClaimsIdentityWithoutMapping(jwtToken, actualIssuer, validationParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(68720066688)
            
            //--TRIMMABLE-BOUNDARY-START(73015033984)
            /*ClaimsIdentity */ CreateClaimsIdentityWithMapping(/*JwtSecurityToken*/ jwtToken, /*string*/ actualIssuer, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015033984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, actualIssuer);
                let $en31 = jwtToken.Claims.SCG$IEnumerable$$$GetEnumerator();
                while ($en31.SC$1$IEnumerator$MoveNext())
                {
                    let jwtClaim = $en31.SCG$IEnumerator$$$Current;
                    {
                        if (this._inboundClaimFilter.SCG$ICollection$$$Contains(jwtClaim.Type))
                        {
                            continue;
                        }
                        /*string*/ let claimType;
                        /*bool*/ let wasMapped = true;
                        if (!this._inboundClaimTypeMap.SCG$IDictionary$$$$TryGetValue(jwtClaim.Type, $.$ref(() => claimType, ($v) => claimType = $v, $.$$.S.String)))
                        {
                            claimType = jwtClaim.Type;
                            wasMapped = false;
                        }
                        if (claimType === "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/)
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.InvalidOperationException().$ctor$12($.$mil.MIL.LogHelper.FormatInvariant("IDX12710: Only a single 'Actor' is supported. Found second claim of type: '{0}', value: '{1}'"/*LogMessages.IDX12710*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(jwtClaim.Value, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JwtSecurityToken*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$sitj.SITJ.JwtSecurityToken);
                                identity.Actor = this.CreateClaimsIdentity(actor, actualIssuer, validationParameters);
                            }
                        }
                        /*Claim*/ let claim = new $.$ssc.SSC.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, actualIssuer, actualIssuer, identity);
                        if (jwtClaim.Properties.SCG$ICollection$$$Count > 0)
                        {
                            let $en33 = jwtClaim.Properties.SCG$IEnumerable$$$GetEnumerator();
                            while ($en33.SC$1$IEnumerator$MoveNext())
                            {
                                let kv = $en33.SCG$IEnumerator$$$Current;
                                {
                                    claim.Properties.SCG$IDictionary$$$$set_Item(kv.Key, kv.Value);
                                }
                            }
                        }
                        if (wasMapped)
                        {
                            claim.Properties.SCG$IDictionary$$$$set_Item($.$sitj.SITJ.JwtSecurityTokenHandler.ShortClaimTypeProperty, jwtClaim.Type);
                        }
                        identity.AddClaim(claim);
                    }
                }
                return identity;
            }
            //--TRIMMABLE-BOUNDARY-END(73015033984)
            
            //--TRIMMABLE-BOUNDARY-START(77310001280)
            /*ClaimsIdentity */ CreateClaimsIdentityWithoutMapping(/*JwtSecurityToken*/ jwtToken, /*string*/ actualIssuer, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ClaimsIdentity*/ let identity = validationParameters.CreateClaimsIdentity(jwtToken, actualIssuer);
                let $en34 = jwtToken.Claims.SCG$IEnumerable$$$GetEnumerator();
                while ($en34.SC$1$IEnumerator$MoveNext())
                {
                    let jwtClaim = $en34.SCG$IEnumerator$$$Current;
                    {
                        if (this._inboundClaimFilter.SCG$ICollection$$$Contains(jwtClaim.Type))
                        {
                            continue;
                        }
                        /*string*/ let claimType = jwtClaim.Type;
                        if (claimType === "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"/*ClaimTypes.Actor*/)
                        {
                            if (identity.Actor !== null)
                            {
                                throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.InvalidOperationException().$ctor$12($.$mil.MIL.LogHelper.FormatInvariant("IDX12710: Only a single 'Actor' is supported. Found second claim of type: '{0}', value: '{1}'"/*LogMessages.IDX12710*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("actort"/*JwtRegisteredClaimNames.Actort*/), $.$mil.MIL.LogHelper.MarkAsSecurityArtifact$1(jwtClaim.Value, new ($.$$.S.Func$$$($.$$.S.Object, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.SafeLogJwtToken)) ], null, null))));
                            }
                            if (this.CanReadToken(jwtClaim.Value))
                            {
                                /*JwtSecurityToken*/ let actor = $.$as(this.ReadToken(jwtClaim.Value), $.$sitj.SITJ.JwtSecurityToken);
                                identity.Actor = this.CreateClaimsIdentity(actor, actualIssuer, validationParameters);
                            }
                        }
                        /*Claim*/ let claim = new $.$ssc.SSC.Claim().$ctor$4(claimType, jwtClaim.Value, jwtClaim.ValueType, actualIssuer, actualIssuer, identity);
                        if (jwtClaim.Properties.SCG$ICollection$$$Count > 0)
                        {
                            let $en35 = jwtClaim.Properties.SCG$IEnumerable$$$GetEnumerator();
                            while ($en35.SC$1$IEnumerator$MoveNext())
                            {
                                let kv = $en35.SCG$IEnumerator$$$Current;
                                {
                                    claim.Properties.SCG$IDictionary$$$$set_Item(kv.Key, kv.Value);
                                }
                            }
                        }
                        identity.AddClaim(claim);
                    }
                }
                return identity;
            }
            //--TRIMMABLE-BOUNDARY-END(77310001280)
            
            //--TRIMMABLE-BOUNDARY-START(64425099392)
            /*string */ CreateActorValue(/*ClaimsIdentity*/ actor)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425099392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (actor === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("actor");
                }
                if (actor.BootstrapContext !== null)
                {
                    /*string*/ let encodedJwt = $.$as(actor.BootstrapContext, $.$$.S.String);
                    if (encodedJwt !== null)
                    {
                        $.$mil.MIL.LogHelper.LogVerbose("IDX12713: Creating actor value using actor.BootstrapContext(as string)"/*LogMessages.IDX12713*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                        return encodedJwt;
                    }
                    /*JwtSecurityToken*/ let jwtToken = $.$as(actor.BootstrapContext, $.$sitj.SITJ.JwtSecurityToken);
                    if (jwtToken !== null)
                    {
                        if (jwtToken.RawData !== null)
                        {
                            $.$mil.MIL.LogHelper.LogVerbose("IDX12714: Creating actor value using actor.BootstrapContext.rawData"/*LogMessages.IDX12714*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                            return jwtToken.RawData;
                        }
                        else 
                        {
                            $.$mil.MIL.LogHelper.LogVerbose("IDX12715: Creating actor value by writing the JwtSecurityToken created from actor.BootstrapContext"/*LogMessages.IDX12715*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                            return this.WriteToken(jwtToken);
                        }
                    }
                    $.$mil.MIL.LogHelper.LogVerbose("IDX12711: actor.BootstrapContext is not a string AND actor.BootstrapContext is not a JWT"/*LogMessages.IDX12711*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                }
                $.$mil.MIL.LogHelper.LogVerbose("IDX12712: actor.BootstrapContext is null. Creating the token using actor.Claims."/*LogMessages.IDX12712*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null));
                return this.WriteToken(new $.$sitj.SITJ.JwtSecurityToken().$ctor$5(null, null, actor.Claims, null, null, null));
            }
            //--TRIMMABLE-BOUNDARY-END(64425099392)
            
            //--TRIMMABLE-BOUNDARY-START(390842613888)
            /*void */ ValidateAudience(/*IEnumerable<string>*/ audiences, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842613888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mit.MIT$1.Validators.ValidateAudience(audiences, jwtToken, validationParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(390842613888)
            
            //--TRIMMABLE-BOUNDARY-START(412317450368)
            /*void */ ValidateLifetime(/*DateTime?*/ notBefore, /*DateTime?*/ expires, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412317450368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mit.MIT$1.Validators.ValidateLifetime$1($.$clone(notBefore), $.$clone(expires), jwtToken, validationParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(412317450368)
            
            //--TRIMMABLE-BOUNDARY-START(395137581184)
            /*string */ ValidateIssuer(/*string*/ issuer, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395137581184);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mit.MIT$1.Validators.ValidateIssuer$1(issuer, jwtToken, validationParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(395137581184)
            
            //--TRIMMABLE-BOUNDARY-START(459562090624)
            /*void */ ValidateTokenReplay(/*DateTime?*/ expires, /*string*/ securityToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459562090624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mit.MIT$1.Validators.ValidateTokenReplay$1($.$clone(expires), securityToken, validationParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(459562090624)
            
            //--TRIMMABLE-BOUNDARY-START(317828169856)
            /*SecurityKey */ ResolveIssuerSigningKey(/*string*/ token, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828169856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (validationParameters === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters");
                }
                if (jwtToken === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("jwtToken");
                }
                return $.$mij.MIJ.JwtTokenUtilities.ResolveTokenSigningKey(jwtToken.Header.Kid, jwtToken.Header.X5t, validationParameters, null);
            }
            //--TRIMMABLE-BOUNDARY-END(317828169856)
            
            //--TRIMMABLE-BOUNDARY-START(322123137152)
            /*SecurityKey */ ResolveTokenDecryptionKey(/*string*/ token, /*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123137152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters");
                }
                if (!$.$$.S.String.IsNullOrEmpty(jwtToken.Header.Kid))
                {
                    if (validationParameters.TokenDecryptionKey !== null && $.$$.S.String.Equals$3(validationParameters.TokenDecryptionKey.KeyId, jwtToken.Header.Kid, $.$is(validationParameters.TokenDecryptionKey, $.$mit.MIT$1.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/))
                    {
                        return validationParameters.TokenDecryptionKey;
                    }
                    if (validationParameters.TokenDecryptionKeys !== null)
                    {
                        let $en36 = validationParameters.TokenDecryptionKeys.SCG$IEnumerable$$$GetEnumerator();
                        while ($en36.SC$1$IEnumerator$MoveNext())
                        {
                            let key = $en36.SCG$IEnumerator$$$Current;
                            {
                                if (key !== null && $.$$.S.String.Equals$3(key.KeyId, jwtToken.Header.Kid, $.$is(key, $.$mit.MIT$1.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/))
                                {
                                    return key;
                                }
                            }
                        }
                    }
                }
                if (!$.$$.S.String.IsNullOrEmpty(jwtToken.Header.X5t))
                {
                    if (validationParameters.TokenDecryptionKey !== null)
                    {
                        if ($.$$.S.String.Equals$3(validationParameters.TokenDecryptionKey.KeyId, jwtToken.Header.X5t, $.$is(validationParameters.TokenDecryptionKey, $.$mit.MIT$1.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/))
                        {
                            return validationParameters.TokenDecryptionKey;
                        }
                        /*X509SecurityKey*/ let x509Key = $.$as(validationParameters.TokenDecryptionKey, $.$mit.MIT$1.X509SecurityKey);
                        if (x509Key !== null && $.$$.S.String.Equals$3(x509Key.X5t, jwtToken.Header.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            return validationParameters.TokenDecryptionKey;
                        }
                    }
                    if (validationParameters.TokenDecryptionKeys !== null)
                    {
                        let $en37 = validationParameters.TokenDecryptionKeys.SCG$IEnumerable$$$GetEnumerator();
                        while ($en37.SC$1$IEnumerator$MoveNext())
                        {
                            let key = $en37.SCG$IEnumerator$$$Current;
                            {
                                if (key !== null && $.$$.S.String.Equals$3(key.KeyId, jwtToken.Header.X5t, $.$is(key, $.$mit.MIT$1.X509SecurityKey) ? 5/*StringComparison.OrdinalIgnoreCase*/ : 4/*StringComparison.Ordinal*/))
                                {
                                    return key;
                                }
                                /*X509SecurityKey*/ let x509Key = $.$as(key, $.$mit.MIT$1.X509SecurityKey);
                                if (x509Key !== null && $.$$.S.String.Equals$3(x509Key.X5t, jwtToken.Header.X5t, 5/*StringComparison.OrdinalIgnoreCase*/))
                                {
                                    return key;
                                }
                            }
                        }
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(322123137152)
            
            //--TRIMMABLE-BOUNDARY-START(133144576128)
            /*string */ DecryptToken(/*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144576128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jwtToken === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("jwtToken");
                }
                if (validationParameters === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("validationParameters");
                }
                if ($.$$.S.String.IsNullOrEmpty(jwtToken.Header.Enc))
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenException().$ctor$10($.$mil.MIL.LogHelper.FormatInvariant("IDX10612: Decryption failed. Header.Enc is null or empty, it must be specified."/*TokenLogMessages.IDX10612*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [  ], null, null))));
                }
                /*var*/ let keys = this.GetContentEncryptionKeys(jwtToken, validationParameters);
                /*var*/ let decryptionParameters = this.CreateJwtTokenDecryptionParameters(jwtToken, keys);
                return $.$mij.MIJ.JwtTokenUtilities.DecryptJwtToken$1(jwtToken, validationParameters, decryptionParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(133144576128)
            
            //--TRIMMABLE-BOUNDARY-START(124554641536)
            /*JwtTokenDecryptionParameters */ CreateJwtTokenDecryptionParameters(/*JwtSecurityToken*/ jwtToken, /*IEnumerable<SecurityKey>*/ keys)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554641536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return (() =>
                {
                    //new $.$mij.MIJ.JwtTokenDecryptionParameters()
                    const $t38 = $.$mij.MIJ.JwtTokenDecryptionParameters;
                    const $i38 = new $t38();
                    $i38.$ctor$1();
                    $i38.Alg = jwtToken.Header.Alg;
                    $i38.AuthenticationTagBytes = $.$mit.MIT$1.Base64UrlEncoder.DecodeBytes(jwtToken.RawAuthenticationTag);
                    $i38.CipherTextBytes = $.$mit.MIT$1.Base64UrlEncoder.DecodeBytes(jwtToken.RawCiphertext);
                    $i38.DecompressionFunction = new ($.$$.S.Func$$$$$($.$typeArray($.$$.S.Byte), $.$$.S.String, $.$$.S.Int32, $.$$.S.String))().$ctor($.$mij.MIJ.JwtTokenUtilities, $.$mij.MIJ.JwtTokenUtilities.DecompressToken);
                    $i38.Enc = jwtToken.Header.Enc;
                    $i38.EncodedToken = jwtToken.RawData;
                    $i38.HeaderAsciiBytes = $.$$.ST.Encoding.ASCII.GetBytes$8(jwtToken.EncodedHeader);
                    $i38.InitializationVectorBytes = $.$mit.MIT$1.Base64UrlEncoder.DecodeBytes(jwtToken.RawInitializationVector);
                    $i38.MaximumDeflateSize = this.MaximumTokenSizeInBytes;
                    $i38.Keys = keys;
                    $i38.Zip = jwtToken.Header.Zip;
                    return $i38;
                })();
            }
            //--TRIMMABLE-BOUNDARY-END(124554641536)
            
            //--TRIMMABLE-BOUNDARY-START(253403660416)
            /*IEnumerable<SecurityKey> */ GetContentEncryptionKeys(/*JwtSecurityToken*/ jwtToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403660416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IEnumerable<SecurityKey>*/ let keys = null;
                if (validationParameters.TokenDecryptionKeyResolver !== null)
                {
                    keys = validationParameters.TokenDecryptionKeyResolver.Invoke(jwtToken.RawData, jwtToken, jwtToken.Header.Kid, validationParameters);
                }
                else 
                {
                    /*var*/ let key = this.ResolveTokenDecryptionKey(jwtToken.RawData, jwtToken, validationParameters);
                    if (key !== null)
                    {
                        keys = $.$$.SRC.RuntimeHelpers.CreateArray($.$mit.MIT$1.SecurityKey.$type, [ key ], null, null);
                    }
                }
                if (keys === null)
                {
                    keys = $.$sitj.SITJ.JwtSecurityTokenHandler.GetAllDecryptionKeys(validationParameters);
                }
                if ($.$$.S.String.Equals$5.call(jwtToken.Header.Alg, "dir"/*JwtConstants.DirectKeyUseAlg*/))
                {
                    return keys;
                }
                /*var*/ let unwrappedKeys = new ($.$$.SCG.List$$($.$mit.MIT$1.SecurityKey))().$ctor$1();
                /*var*/ let exceptionStrings = new $.$$.ST.StringBuilder().$ctor$1();
                /*var*/ let keysAttempted = new $.$$.ST.StringBuilder().$ctor$1();
                let $en39 = keys.SCG$IEnumerable$$$GetEnumerator();
                while ($en39.SC$1$IEnumerator$MoveNext())
                {
                    let key = $en39.SCG$IEnumerator$$$Current;
                    {
                        try
                        {
                            if ($.$mit.MIT$1.SupportedAlgorithms.EcdsaWrapAlgorithms.SCG$ICollection$$$Contains(jwtToken.Header.Alg))
                            {
                                /*ECDsaSecurityKey*/ let publicKey;
                                if ($.$mit.MIT$1.AppContextSwitches.UseRfcDefinitionOfEpkAndKid)
                                {
                                    /*string*/ let epk = jwtToken.Header.GetStandardClaim("epk"/*JwtHeaderParameterNames.Epk*/);
                                    publicKey = new $.$mit.MIT$1.ECDsaSecurityKey().$ctor$5(new $.$mit.MIT$1.JsonWebKey().$ctor$4(epk), false);
                                }
                                else 
                                {
                                    publicKey = $.$as(validationParameters.TokenDecryptionKey, $.$mit.MIT$1.ECDsaSecurityKey);
                                }
                                /*var*/ let ecdhKeyExchangeProvider = new $.$mit.MIT$1.EcdhKeyExchangeProvider().$ctor$1($.$as(key, $.$mit.MIT$1.ECDsaSecurityKey), publicKey, jwtToken.Header.Alg, jwtToken.Header.Enc);
                                /*string*/ let apu = jwtToken.Header.GetStandardClaim("apu"/*JwtHeaderParameterNames.Apu*/);
                                /*string*/ let apv = jwtToken.Header.GetStandardClaim("apv"/*JwtHeaderParameterNames.Apv*/);
                                /*SecurityKey*/ let kdf = ecdhKeyExchangeProvider.GenerateKdf(apu, apv);
                                /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(kdf, ecdhKeyExchangeProvider.GetEncryptionAlgorithm());
                                /*var*/ let unwrappedKey = kwp.UnwrapKey($.$mit.MIT$1.Base64UrlEncoder.DecodeBytes(jwtToken.RawEncryptedKey));
                                unwrappedKeys.Add(new $.$mit.MIT$1.SymmetricSecurityKey().$ctor$4(unwrappedKey));
                            }
                            else if (key.CryptoProviderFactory.IsSupportedAlgorithm(jwtToken.Header.Alg, key))
                            {
                                /*var*/ let kwp = key.CryptoProviderFactory.CreateKeyWrapProviderForUnwrap(key, jwtToken.Header.Alg);
                                /*var*/ let unwrappedKey = kwp.UnwrapKey($.$mit.MIT$1.Base64UrlEncoder.DecodeBytes(jwtToken.RawEncryptedKey));
                                unwrappedKeys.Add(new $.$mit.MIT$1.SymmetricSecurityKey().$ctor$4(unwrappedKey));
                            }
                        }
                        catch(ex)
                        {
                            exceptionStrings.AppendLine$3(ex.ToString());
                        }
                        keysAttempted.AppendLine$3(key.KeyId);
                    }
                }
                if (unwrappedKeys.Count > 0 || exceptionStrings.Length === 0)
                {
                    return unwrappedKeys;
                }
                else 
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenKeyWrapException().$ctor$16($.$mil.MIL.LogHelper.FormatInvariant("IDX10618: Key unwrap failed using decryption Keys: '{0}'.\nExceptions caught:\n '{1}'.\ntoken: '{2}'."/*TokenLogMessages.IDX10618*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(keysAttempted.ToString()), exceptionStrings, jwtToken ], null, null))));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(253403660416)
            
            //--TRIMMABLE-BOUNDARY-START(261993595008)
            static /*byte[] */ GetSymmetricSecurityKey(/*SecurityKey*/ key)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993595008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (key === null)
                {
                    throw $.$mil.MIL.LogHelper.LogArgumentNullException("key");
                }
                /*SymmetricSecurityKey*/ let symmetricSecurityKey = $.$as(key, $.$mit.MIT$1.SymmetricSecurityKey);
                if (symmetricSecurityKey !== null)
                {
                    return symmetricSecurityKey.Key;
                }
                else 
                {
                    /*JsonWebKey*/ let jsonWebKey = $.$as(key, $.$mit.MIT$1.JsonWebKey);
                    if (jsonWebKey !== null && jsonWebKey.K !== null)
                    {
                        return $.$mit.MIT$1.Base64UrlEncoder.DecodeBytes(jsonWebKey.K);
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(261993595008)
            
            //--TRIMMABLE-BOUNDARY-START(399432548480)
            /*void */ ValidateIssuerSecurityKey(/*SecurityKey*/ key, /*JwtSecurityToken*/ securityToken, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399432548480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$mit.MIT$1.Validators.ValidateIssuerSecurityKey$1(key, securityToken, validationParameters);
            }
            //--TRIMMABLE-BOUNDARY-END(399432548480)
            
            //--TRIMMABLE-BOUNDARY-START(468152025216)
            /*void */ WriteToken$1(/*XmlWriter*/ writer, /*SecurityToken*/ token)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468152025216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.NotImplementedException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(468152025216)
            
            //--TRIMMABLE-BOUNDARY-START(446677188736)
            /*Task<TokenValidationResult> */ ValidateTokenAsync$5(/*string*/ token, /*TokenValidationParameters*/ validationParameters)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446677188736);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                try
                {
                    /*var*/ let validatedToken;
                    /*var*/ let claimsPrincipal = this.ValidateToken(token, validationParameters, $.$ref(() => validatedToken, ($v) => validatedToken = $v, $.$mit.MIT$1.SecurityToken));
                    return $.$$.STT.Task.FromResult($.$mit.MIT$1.TokenValidationResult, (() =>
                    {
                        //new $.$mit.MIT$1.TokenValidationResult()
                        const $t41 = $.$mit.MIT$1.TokenValidationResult;
                        const $i41 = new $t41();
                        $i41.$ctor$1();
                        $i41.SecurityToken = validatedToken;
                        $i41.ClaimsIdentity = $.$as((claimsPrincipal?.Identity ?? null), $.$ssc.SSC.ClaimsIdentity);
                        $i41.IsValid = true;
                        return $i41;
                    })());
                }
                catch(ex)
                {
                    return $.$$.STT.Task.FromResult($.$mit.MIT$1.TokenValidationResult, (() =>
                    {
                        //new $.$mit.MIT$1.TokenValidationResult()
                        const $t42 = $.$mit.MIT$1.TokenValidationResult;
                        const $i42 = new $t42();
                        $i42.$ctor$1();
                        $i42.IsValid = false;
                        $i42.Exception = ex;
                        return $i42;
                    })());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(446677188736)
            
            //--TRIMMABLE-BOUNDARY-START(47245230208)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(47245230208)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(21475426432)
                this._mapInboundClaims = $.$sitj.SITJ.JwtSecurityTokenHandler.DefaultMapInboundClaims;
                //--TRIMMABLE-BOUNDARY-END(21475426432)
                
                //--TRIMMABLE-BOUNDARY-START(382252679296)
                this.TelemetryClient = new $.$mit.MIT.TelemetryClient().$ctor$1();
                //--TRIMMABLE-BOUNDARY-END(382252679296)
                
            }
            //--TRIMMABLE-BOUNDARY-START(42950262912)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950262912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(17180459136)
                    this._jsonClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claimproperties/json_type";
                    //--TRIMMABLE-BOUNDARY-END(17180459136)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770393728)
                    this._namespace = "http://schemas.xmlsoap.org/ws/2005/05/identity/claimproperties";
                    //--TRIMMABLE-BOUNDARY-END(25770393728)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295557248)
                    this._className = "System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler";
                    //--TRIMMABLE-BOUNDARY-END(4295557248)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655295616)
                    this._shortClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claimproperties/ShortTypeName";
                    //--TRIMMABLE-BOUNDARY-END(38655295616)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734510720)
                    this.DefaultInboundClaimTypeMap = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$3($.$mij.MIJ.ClaimTypeMapping.InboundClaimTypeMap);
                    //--TRIMMABLE-BOUNDARY-END(141734510720)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154619412608)
                    this.DefaultOutboundClaimTypeMap = new ($.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String))().$ctor$3($.$mij.MIJ.ClaimTypeMapping.OutboundClaimTypeMap);
                    //--TRIMMABLE-BOUNDARY-END(154619412608)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439543424)
                    this.DefaultInboundClaimFilter = $.$mij.MIJ.ClaimTypeMapping.InboundClaimFilter;
                    //--TRIMMABLE-BOUNDARY-END(137439543424)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324445312)
                    this.DefaultOutboundAlgorithmMap = (() =>
                    {
                        //new $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String)()
                        const $t43 = $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String);
                        const $i43 = new $t43();
                        $i43.$ctor$1();
                        $i43.Add("http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha256"/*SecurityAlgorithms.EcdsaSha256Signature*/, "ES256"/*SecurityAlgorithms.EcdsaSha256*/);
                        $i43.Add("http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha384"/*SecurityAlgorithms.EcdsaSha384Signature*/, "ES384"/*SecurityAlgorithms.EcdsaSha384*/);
                        $i43.Add("http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha512"/*SecurityAlgorithms.EcdsaSha512Signature*/, "ES512"/*SecurityAlgorithms.EcdsaSha512*/);
                        $i43.Add("http://www.w3.org/2001/04/xmldsig-more#hmac-sha256"/*SecurityAlgorithms.HmacSha256Signature*/, "HS256"/*SecurityAlgorithms.HmacSha256*/);
                        $i43.Add("http://www.w3.org/2001/04/xmldsig-more#hmac-sha384"/*SecurityAlgorithms.HmacSha384Signature*/, "HS384"/*SecurityAlgorithms.HmacSha384*/);
                        $i43.Add("http://www.w3.org/2001/04/xmldsig-more#hmac-sha512"/*SecurityAlgorithms.HmacSha512Signature*/, "HS512"/*SecurityAlgorithms.HmacSha512*/);
                        $i43.Add("http://www.w3.org/2001/04/xmldsig-more#rsa-sha256"/*SecurityAlgorithms.RsaSha256Signature*/, "RS256"/*SecurityAlgorithms.RsaSha256*/);
                        $i43.Add("http://www.w3.org/2001/04/xmldsig-more#rsa-sha384"/*SecurityAlgorithms.RsaSha384Signature*/, "RS384"/*SecurityAlgorithms.RsaSha384*/);
                        $i43.Add("http://www.w3.org/2001/04/xmldsig-more#rsa-sha512"/*SecurityAlgorithms.RsaSha512Signature*/, "RS512"/*SecurityAlgorithms.RsaSha512*/);
                        return $i43;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(150324445312)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950262912)
            
            static $h = 589952;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$mit.MIT$1.SecurityTokenHandler; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(279173464192),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210453987456,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 356482875520,
        "f": 83886081
      },
      "n": "MapInboundClaims",
      "d": 589952,
      "h": 279173464192,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279173464192),
//--TRIMMABLE-BOUNDARY-START(270583529600),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193274118272,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339303006336,
        "f": 83886081
      },
      "n": "InboundClaimTypeMap",
      "d": 589952,
      "h": 270583529600,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(270583529600),
//--TRIMMABLE-BOUNDARY-START(287763398784),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227633856640,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 365072810112,
        "f": 83886081
      },
      "n": "OutboundClaimTypeMap",
      "d": 589952,
      "h": 287763398784,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(287763398784),
//--TRIMMABLE-BOUNDARY-START(283468431488),
    {
      "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219043922048,
        "f": 50331649
      },
      "n": "OutboundAlgorithmMap",
      "d": 589952,
      "h": 283468431488,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(283468431488),
//--TRIMMABLE-BOUNDARY-START(266288562304),
    {
      "p": $.$$.SCG.ISet$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684183680,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330713071744,
        "f": 83886081
      },
      "n": "InboundClaimFilter",
      "d": 589952,
      "h": 266288562304,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(266288562304),
//--TRIMMABLE-BOUNDARY-START(377957712000),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236223791232,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 373662744704,
        "f": 83886113
      },
      "n": "ShortClaimTypeProperty",
      "d": 589952,
      "h": 377957712000,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(377957712000),
//--TRIMMABLE-BOUNDARY-START(274878496896),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201864052864,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347892940928,
        "f": 83886113
      },
      "n": "JsonClaimTypeProperty",
      "d": 589952,
      "h": 274878496896,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(274878496896),
//--TRIMMABLE-BOUNDARY-START(55835164800),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504314496,
        "f": 50364417
      },
      "n": "CanValidateToken",
      "d": 589952,
      "h": 55835164800,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(55835164800),
//--TRIMMABLE-BOUNDARY-START(60130132096),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094249088,
        "f": 50364417
      },
      "n": "CanWriteToken",
      "d": 589952,
      "h": 60130132096,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(60130132096),
//--TRIMMABLE-BOUNDARY-START(386547646592),
    {
      "p": 188547073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244813725824,
        "f": 50364417
      },
      "n": "TokenType",
      "d": 589952,
      "h": 386547646592,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(386547646592)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(51540197504),
    {
      "r": 262145,
      "p": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "n": "CanReadToken",
      "d": 589952,
      "h": 51540197504,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540197504),
//--TRIMMABLE-BOUNDARY-START(85899935872),
    {
      "r": 1310721,
      "p": [
        {
          "n": "tokenDescriptor",
          "p": 14090366
        }
      ],
      "n": "CreateEncodedJwt",
      "d": 589952,
      "h": 85899935872,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(85899935872),
//--TRIMMABLE-BOUNDARY-START(98784837760),
    {
      "r": 1310721,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "subject",
          "p": 262213
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        }
      ],
      "n": "CreateEncodedJwt",
      "o": "@$3",
      "d": 589952,
      "h": 98784837760,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(98784837760),
//--TRIMMABLE-BOUNDARY-START(94489870464),
    {
      "r": 1310721,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "subject",
          "p": 262213
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        }
      ],
      "n": "CreateEncodedJwt",
      "o": "@$2",
      "d": 589952,
      "h": 94489870464,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(94489870464),
//--TRIMMABLE-BOUNDARY-START(90194903168),
    {
      "r": 1310721,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "subject",
          "p": 262213
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "claimCollection",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "CreateEncodedJwt",
      "o": "@$1",
      "d": 589952,
      "h": 90194903168,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(90194903168),
//--TRIMMABLE-BOUNDARY-START(103079805056),
    {
      "r": 458880,
      "p": [
        {
          "n": "tokenDescriptor",
          "p": 14090366
        }
      ],
      "n": "CreateJwtSecurityToken",
      "d": 589952,
      "h": 103079805056,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(103079805056),
//--TRIMMABLE-BOUNDARY-START(111669739648),
    {
      "r": 458880,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "subject",
          "p": 262213
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        }
      ],
      "n": "CreateJwtSecurityToken",
      "o": "@$2",
      "d": 589952,
      "h": 111669739648,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(111669739648),
//--TRIMMABLE-BOUNDARY-START(107374772352),
    {
      "r": 458880,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "subject",
          "p": 262213
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "claimCollection",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "CreateJwtSecurityToken",
      "o": "@$1",
      "d": 589952,
      "h": 107374772352,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(107374772352),
//--TRIMMABLE-BOUNDARY-START(115964706944),
    {
      "r": 458880,
      "p": [
        {
          "n": "issuer",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "audience",
          "p": 1310721,
          "f": 65
        },
        {
          "n": "subject",
          "p": 262213,
          "f": 65
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.S.DateTime).$h,
          "f": 65
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.S.DateTime).$h,
          "f": 65
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.S.DateTime).$h,
          "f": 65
        },
        {
          "n": "signingCredentials",
          "p": 15925374,
          "f": 65
        }
      ],
      "n": "CreateJwtSecurityToken",
      "o": "@$3",
      "d": 589952,
      "h": 115964706944,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(115964706944),
//--TRIMMABLE-BOUNDARY-START(128849608832),
    {
      "r": 13762686,
      "p": [
        {
          "n": "tokenDescriptor",
          "p": 14090366
        }
      ],
      "n": "CreateToken",
      "d": 589952,
      "h": 128849608832,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128849608832),
//--TRIMMABLE-BOUNDARY-START(120259674240),
    {
      "r": 458880,
      "p": [
        {
          "n": "tokenDescriptor",
          "p": 14090366
        }
      ],
      "n": "CreateJwtSecurityTokenPrivate",
      "d": 589952,
      "h": 120259674240,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(120259674240),
//--TRIMMABLE-BOUNDARY-START(158914379904),
    {
      "r": 458880,
      "p": [
        {
          "n": "innerJwt",
          "p": 458880
        },
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "tokenType",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "EncryptToken",
      "d": 589952,
      "h": 158914379904,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(158914379904),
//--TRIMMABLE-BOUNDARY-START(296353333376),
    {
      "r": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h,
      "p": [
        {
          "n": "claims",
          "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h
        }
      ],
      "n": "OutboundClaimTypeTransform",
      "o": "@$1",
      "d": 589952,
      "h": 296353333376,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(296353333376),
//--TRIMMABLE-BOUNDARY-START(292058366080),
    {
      "r": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object).$h,
      "p": [
        {
          "n": "claimCollection",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "OutboundClaimTypeTransform",
      "d": 589952,
      "h": 292058366080,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(292058366080),
//--TRIMMABLE-BOUNDARY-START(300648300672),
    {
      "r": 458880,
      "p": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "n": "ReadJwtToken",
      "d": 589952,
      "h": 300648300672,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(300648300672),
//--TRIMMABLE-BOUNDARY-START(304943267968),
    {
      "r": 13762686,
      "p": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "n": "ReadToken",
      "d": 589952,
      "h": 304943267968,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(304943267968),
//--TRIMMABLE-BOUNDARY-START(309238235264),
    {
      "r": 13762686,
      "p": [
        {
          "n": "reader",
          "p": 53346307
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ReadToken",
      "o": "@$1",
      "d": 589952,
      "h": 309238235264,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(309238235264),
//--TRIMMABLE-BOUNDARY-START(438087254144),
    {
      "r": 393285,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "validatedToken",
          "p": 13762686,
          "f": 2
        }
      ],
      "n": "ValidateToken",
      "d": 589952,
      "h": 438087254144,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(438087254144),
//--TRIMMABLE-BOUNDARY-START(442382221440),
    {
      "r": 393285,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "outerToken",
          "p": 458880
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "signatureValidatedToken",
          "p": 13762686,
          "f": 2
        }
      ],
      "n": "ValidateToken",
      "o": "@$2",
      "d": 589952,
      "h": 442382221440,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(442382221440),
//--TRIMMABLE-BOUNDARY-START(403727515776),
    {
      "r": 393285,
      "p": [
        {
          "n": "decryptedJwt",
          "p": 1310721
        },
        {
          "n": "outerToken",
          "p": 458880
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "currentConfiguration",
          "p": 1638526
        },
        {
          "n": "signatureValidatedToken",
          "p": 13762686,
          "f": 2
        },
        {
          "n": "exceptionThrown",
          "p": 135790593,
          "f": 2
        }
      ],
      "n": "ValidateJWE",
      "d": 589952,
      "h": 403727515776,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(403727515776),
//--TRIMMABLE-BOUNDARY-START(408022483072),
    {
      "r": 393285,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "currentConfiguration",
          "p": 1638526
        },
        {
          "n": "signatureValidatedToken",
          "p": 13762686,
          "f": 2
        },
        {
          "n": "exceptionThrown",
          "p": 135790593,
          "f": 2
        }
      ],
      "n": "ValidateJWS",
      "d": 589952,
      "h": 408022483072,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(408022483072),
//--TRIMMABLE-BOUNDARY-START(433792286848),
    {
      "r": 458880,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "configuration",
          "p": 1638526
        }
      ],
      "n": "ValidateSignatureUsingDelegates",
      "d": 589952,
      "h": 433792286848,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(433792286848),
//--TRIMMABLE-BOUNDARY-START(429497319552),
    {
      "r": 458880,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "jwtToken",
          "p": 458880
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "configuration",
          "p": 1638526
        }
      ],
      "n": "ValidateSignatureAndIssuerSecurityKey",
      "d": 589952,
      "h": 429497319552,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(429497319552),
//--TRIMMABLE-BOUNDARY-START(257698627712),
    {
      "r": 458880,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "GetJwtSecurityTokenFromToken",
      "d": 589952,
      "h": 257698627712,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(257698627712),
//--TRIMMABLE-BOUNDARY-START(455267123328),
    {
      "r": 393285,
      "p": [
        {
          "n": "jwtToken",
          "p": 458880
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ValidateTokenPayload",
      "o": "@$1",
      "d": 589952,
      "h": 455267123328,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(455267123328),
//--TRIMMABLE-BOUNDARY-START(450972156032),
    {
      "r": 393285,
      "p": [
        {
          "n": "jwtToken",
          "p": 458880
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "configuration",
          "p": 1638526
        }
      ],
      "n": "ValidateTokenPayload",
      "d": 589952,
      "h": 450972156032,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(450972156032),
//--TRIMMABLE-BOUNDARY-START(81604968576),
    {
      "r": 393285,
      "p": [
        {
          "n": "jwtToken",
          "p": 458880
        },
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "CreateClaimsPrincipalFromToken",
      "d": 589952,
      "h": 81604968576,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81604968576),
//--TRIMMABLE-BOUNDARY-START(463857057920),
    {
      "r": 1310721,
      "p": [
        {
          "n": "token",
          "p": 13762686
        }
      ],
      "n": "WriteToken",
      "d": 589952,
      "h": 463857057920,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(463857057920),
//--TRIMMABLE-BOUNDARY-START(313533202560),
    {
      "r": 65537,
      "p": [
        {
          "n": "telemetryClient",
          "p": 196734
        },
        {
          "n": "errorType",
          "p": 1310721
        },
        {
          "n": "securityToken",
          "p": 13762686
        },
        {
          "n": "algorithm",
          "p": 1310721
        },
        {
          "n": "key",
          "p": 13631614
        }
      ],
      "n": "RecordSignatureValidationTelemetry",
      "d": 589952,
      "h": 313533202560,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(313533202560),
//--TRIMMABLE-BOUNDARY-START(416612417664),
    {
      "r": 262145,
      "p": [
        {
          "n": "encodedBytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "signature",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "key",
          "p": 13631614
        },
        {
          "n": "algorithm",
          "p": 1310721
        },
        {
          "n": "securityToken",
          "p": 13762686
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "telemetryClient",
          "p": 196734
        }
      ],
      "n": "ValidateSignature",
      "d": 589952,
      "h": 416612417664,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(416612417664),
//--TRIMMABLE-BOUNDARY-START(420907384960),
    {
      "r": 458880,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ValidateSignature",
      "o": "@$1",
      "d": 589952,
      "h": 420907384960,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(420907384960),
//--TRIMMABLE-BOUNDARY-START(425202352256),
    {
      "r": 458880,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "jwtToken",
          "p": 458880
        },
        {
          "n": "validationParameters",
          "p": 16777342
        },
        {
          "n": "configuration",
          "p": 1638526
        }
      ],
      "n": "ValidateSignature",
      "o": "@$2",
      "d": 589952,
      "h": 425202352256,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(425202352256),
//--TRIMMABLE-BOUNDARY-START(249108693120),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mit.MIT$1.SecurityKey).$h,
      "p": [
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "GetAllDecryptionKeys",
      "d": 589952,
      "h": 249108693120,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(249108693120),
//--TRIMMABLE-BOUNDARY-START(68720066688),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 458880
        },
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "CreateClaimsIdentity",
      "d": 589952,
      "h": 68720066688,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(68720066688),
//--TRIMMABLE-BOUNDARY-START(73015033984),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 458880
        },
        {
          "n": "actualIssuer",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "CreateClaimsIdentityWithMapping",
      "d": 589952,
      "h": 73015033984,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73015033984),
//--TRIMMABLE-BOUNDARY-START(77310001280),
    {
      "r": 262213,
      "p": [
        {
          "n": "jwtToken",
          "p": 458880
        },
        {
          "n": "actualIssuer",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "CreateClaimsIdentityWithoutMapping",
      "d": 589952,
      "h": 77310001280,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(77310001280),
//--TRIMMABLE-BOUNDARY-START(64425099392),
    {
      "r": 1310721,
      "p": [
        {
          "n": "actor",
          "p": 262213
        }
      ],
      "n": "CreateActorValue",
      "d": 589952,
      "h": 64425099392,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(64425099392),
//--TRIMMABLE-BOUNDARY-START(390842613888),
    {
      "r": 65537,
      "p": [
        {
          "n": "audiences",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.String).$h
        },
        {
          "n": "jwtToken",
          "p": 458880
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ValidateAudience",
      "d": 589952,
      "h": 390842613888,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(390842613888),
//--TRIMMABLE-BOUNDARY-START(412317450368),
    {
      "r": 65537,
      "p": [
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "jwtToken",
          "p": 458880
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ValidateLifetime",
      "d": 589952,
      "h": 412317450368,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(412317450368),
//--TRIMMABLE-BOUNDARY-START(395137581184),
    {
      "r": 1310721,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "jwtToken",
          "p": 458880
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ValidateIssuer",
      "d": 589952,
      "h": 395137581184,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(395137581184),
//--TRIMMABLE-BOUNDARY-START(459562090624),
    {
      "r": 65537,
      "p": [
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "securityToken",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ValidateTokenReplay",
      "d": 589952,
      "h": 459562090624,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(459562090624),
//--TRIMMABLE-BOUNDARY-START(317828169856),
    {
      "r": 13631614,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "jwtToken",
          "p": 458880
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ResolveIssuerSigningKey",
      "d": 589952,
      "h": 317828169856,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(317828169856),
//--TRIMMABLE-BOUNDARY-START(322123137152),
    {
      "r": 13631614,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "jwtToken",
          "p": 458880
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ResolveTokenDecryptionKey",
      "d": 589952,
      "h": 322123137152,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(322123137152),
//--TRIMMABLE-BOUNDARY-START(133144576128),
    {
      "r": 1310721,
      "p": [
        {
          "n": "jwtToken",
          "p": 458880
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "DecryptToken",
      "d": 589952,
      "h": 133144576128,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(133144576128),
//--TRIMMABLE-BOUNDARY-START(124554641536),
    {
      "r": 786559,
      "p": [
        {
          "n": "jwtToken",
          "p": 458880
        },
        {
          "n": "keys",
          "p": $.$$.SCG.IEnumerable$$($.$mit.MIT$1.SecurityKey).$h
        }
      ],
      "n": "CreateJwtTokenDecryptionParameters",
      "d": 589952,
      "h": 124554641536,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124554641536),
//--TRIMMABLE-BOUNDARY-START(253403660416),
    {
      "r": $.$$.SCG.IEnumerable$$($.$mit.MIT$1.SecurityKey).$h,
      "p": [
        {
          "n": "jwtToken",
          "p": 458880
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "GetContentEncryptionKeys",
      "d": 589952,
      "h": 253403660416,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(253403660416),
//--TRIMMABLE-BOUNDARY-START(261993595008),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "key",
          "p": 13631614
        }
      ],
      "n": "GetSymmetricSecurityKey",
      "d": 589952,
      "h": 261993595008,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(261993595008),
//--TRIMMABLE-BOUNDARY-START(399432548480),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 13631614
        },
        {
          "n": "securityToken",
          "p": 458880
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ValidateIssuerSecurityKey",
      "d": 589952,
      "h": 399432548480,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(399432548480),
//--TRIMMABLE-BOUNDARY-START(468152025216),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": 58458115
        },
        {
          "n": "token",
          "p": 13762686
        }
      ],
      "n": "WriteToken",
      "o": "@$1",
      "d": 589952,
      "h": 468152025216,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(468152025216),
//--TRIMMABLE-BOUNDARY-START(446677188736),
    {
      "r": $.$$.STT.Task$$($.$mit.MIT$1.TokenValidationResult).$h,
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "validationParameters",
          "p": 16777342
        }
      ],
      "n": "ValidateTokenAsync",
      "o": "@$5",
      "d": 589952,
      "h": 446677188736,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(446677188736)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590524544),
    {
      "t": $.$$.SCG.ISet$$($.$$.S.String).$h,
      "n": "_inboundClaimFilter",
      "d": 589952,
      "h": 8590524544,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524544),
//--TRIMMABLE-BOUNDARY-START(12885491840),
    {
      "t": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "n": "_inboundClaimTypeMap",
      "d": 589952,
      "h": 12885491840,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885491840),
//--TRIMMABLE-BOUNDARY-START(17180459136),
    {
      "t": 1310721,
      "n": "_jsonClaimType",
      "d": 589952,
      "h": 17180459136,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(17180459136),
//--TRIMMABLE-BOUNDARY-START(25770393728),
    {
      "t": 1310721,
      "n": "_namespace",
      "d": 589952,
      "h": 25770393728,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25770393728),
//--TRIMMABLE-BOUNDARY-START(4295557248),
    {
      "t": 1310721,
      "n": "_className",
      "d": 589952,
      "h": 4295557248,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(4295557248),
//--TRIMMABLE-BOUNDARY-START(34360328320),
    {
      "t": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "n": "_outboundClaimTypeMap",
      "d": 589952,
      "h": 34360328320,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(34360328320),
//--TRIMMABLE-BOUNDARY-START(30065361024),
    {
      "t": $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "n": "_outboundAlgorithmMap",
      "d": 589952,
      "h": 30065361024,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(30065361024),
//--TRIMMABLE-BOUNDARY-START(38655295616),
    {
      "t": 1310721,
      "n": "_shortClaimType",
      "d": 589952,
      "h": 38655295616,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(38655295616),
//--TRIMMABLE-BOUNDARY-START(21475426432),
    {
      "t": 262145,
      "n": "_mapInboundClaims",
      "d": 589952,
      "h": 21475426432,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(21475426432),
//--TRIMMABLE-BOUNDARY-START(382252679296),
    {
      "t": 196734,
      "n": "TelemetryClient",
      "d": 589952,
      "h": 382252679296,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(382252679296),
//--TRIMMABLE-BOUNDARY-START(141734510720),
    {
      "t": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "n": "DefaultInboundClaimTypeMap",
      "d": 589952,
      "h": 141734510720,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734510720),
//--TRIMMABLE-BOUNDARY-START(146029478016),
    {
      "t": 262145,
      "n": "DefaultMapInboundClaims",
      "d": 589952,
      "h": 146029478016,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029478016),
//--TRIMMABLE-BOUNDARY-START(154619412608),
    {
      "t": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "n": "DefaultOutboundClaimTypeMap",
      "d": 589952,
      "h": 154619412608,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619412608),
//--TRIMMABLE-BOUNDARY-START(137439543424),
    {
      "t": $.$$.SCG.ISet$$($.$$.S.String).$h,
      "n": "DefaultInboundClaimFilter",
      "d": 589952,
      "h": 137439543424,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439543424),
//--TRIMMABLE-BOUNDARY-START(150324445312),
    {
      "t": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h,
      "n": "DefaultOutboundAlgorithmMap",
      "d": 589952,
      "h": 150324445312,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324445312)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(47245230208),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589952,
      "h": 47245230208,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245230208)
  ],
  "h": 589952
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$mit.MIT$1.ISecurityTokenValidator ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sitj.SITJ.JwtSecurityTokenHandler.CertMatcher ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IdentityModel${separator}Tokens${separator}Jwt${separator}JwtSecurityTokenHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589952)
        
        

        //--TRIMMABLE-BOUNDARY-START(196736)
        $asm.$cls(`$sitj.SITJ.JwtHeader`, ($self) => class JwtHeader extends $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(85899542656)
            /*string*/ ClassName = null;
            //--TRIMMABLE-BOUNDARY-END(85899542656)
            
            //--TRIMMABLE-BOUNDARY-START(17180065920)
            $ctor$10()
            {
                super.$ctor$6($.$$.S.StringComparer.Ordinal);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180065920);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180065920)
            
            //--TRIMMABLE-BOUNDARY-START(64424706176)
            $ctor$21(/*string*/ json)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424706176);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    _ = $.$firstOf(json, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("json") });
                    /*Utf8JsonReader*/ let reader = new $.$stj.STJ.Utf8JsonReader().$ctor$6($.$$.S.ReadOnlySpan$$($.$$.S.Byte).op_Implicit$1($.$$.ST.Encoding.UTF8.GetBytes$8(json)), new $.$stj.STJ.JsonReaderOptions());
                    if (!$.$mit.MITJ.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), 1/*JsonTokenType.StartObject*/, true))
                    {
                        throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$stj.STJ.JsonException().$ctor$10($.$mil.MIL.LogHelper.FormatInvariant("IDX11023: Expecting json reader to be positioned on '{0}', reader was positioned at: '{1}', Reading: '{2}', Position: '{3}', CurrentDepth: '{4}', BytesConsumed: '{5}'."/*Microsoft.IdentityModel.Tokens.LogMessages.IDX11023*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("JsonTokenType.StartObject"), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(reader.TokenType, $.$stj.STJ.JsonTokenType)), $.$mil.MIL.LogHelper.MarkAsNonPII(this.ClassName), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(reader.TokenStartIndex, $.$$.S.Int64)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(reader.CurrentDepth, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(reader.BytesConsumed, $.$$.S.Int64)) ], null, null))));
                    }
                    while(true)
                    {
                        if (reader.TokenType === 5/*JsonTokenType.PropertyName*/)
                        {
                            /*string*/ let propertyName = $.$mit.MITJ.JsonSerializerPrimitives.ReadPropertyName($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), this.ClassName, true);
                            /*object*/ let obj;
                            if (reader.TokenType === 3/*JsonTokenType.StartArray*/)
                            {
                                obj = $.$mit.MITJ.JsonSerializerPrimitives.ReadArrayOfObjects($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), propertyName, this.ClassName);
                            }
                            else 
                            {
                                obj = $.$mit.MITJ.JsonSerializerPrimitives.ReadPropertyValueAsObject($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), propertyName, this.ClassName, false);
                            }
                            this.set_Item(propertyName, obj);
                        }
                        else if ($.$mit.MITJ.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), 2/*JsonTokenType.EndObject*/, true))
                        {
                            break;
                        }
                        else if (!reader.Read())
                        {
                            break;
                        }
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64424706176)
            
            //--TRIMMABLE-BOUNDARY-START(60129738880)
            $ctor$20(/*SigningCredentials*/ signingCredentials)
            {
                this.$ctor$19(signingCredentials, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129738880);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60129738880)
            
            //--TRIMMABLE-BOUNDARY-START(38654902400)
            $ctor$15(/*EncryptingCredentials*/ encryptingCredentials)
            {
                this.$ctor$14(encryptingCredentials, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654902400);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38654902400)
            
            //--TRIMMABLE-BOUNDARY-START(55834771584)
            $ctor$19(/*SigningCredentials*/ signingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap)
            {
                this.$ctor$18(signingCredentials, outboundAlgorithmMap, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834771584);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(55834771584)
            
            //--TRIMMABLE-BOUNDARY-START(51539804288)
            $ctor$18(/*SigningCredentials*/ signingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType)
            {
                this.$ctor$17(signingCredentials, outboundAlgorithmMap, tokenType, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539804288);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(51539804288)
            
            //--TRIMMABLE-BOUNDARY-START(42949869696)
            $ctor$16(/*SigningCredentials*/ signingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType, /*IDictionary<string, object>*/ additionalInnerHeaderClaims, /*bool*/ includeKeyIdInHeader)
            {
                super.$ctor$6($.$$.S.StringComparer.Ordinal);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949869696);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (signingCredentials === null)
                    {
                        this.set_Item("alg"/*JwtHeaderParameterNames.Alg*/, "none"/*SecurityAlgorithms.None*/);
                    }
                    else 
                    {
                        /*string*/ let outboundAlg;
                        if (outboundAlgorithmMap !== null && outboundAlgorithmMap.SCG$IDictionary$$$$TryGetValue(signingCredentials.Algorithm, $.$ref(() => outboundAlg, ($v) => outboundAlg = $v, $.$$.S.String)))
                        {
                            this.Alg = outboundAlg;
                        }
                        else 
                        {
                            this.Alg = signingCredentials.Algorithm;
                        }
                        if (includeKeyIdInHeader)
                        {
                            if (!$.$$.S.String.IsNullOrEmpty(signingCredentials.Key.KeyId))
                            {
                                this.Kid = signingCredentials.Key.KeyId;
                            }
                            let x509SigningCredentials;
                            if ($.$is(signingCredentials, $.$mit.MIT$1.X509SigningCredentials, { set $v($v){ x509SigningCredentials = $v; } }))
                            {
                                this.set_Item("x5t"/*JwtHeaderParameterNames.X5t*/, $.$mit.MIT$1.Base64UrlEncoder.Encode$1(x509SigningCredentials.Certificate.GetCertHash()));
                            }
                        }
                    }
                    if ($.$$.S.String.IsNullOrEmpty(tokenType))
                    {
                        this.Typ = "JWT"/*JwtConstants.HeaderType*/;
                    }
                    else 
                    {
                        this.Typ = tokenType;
                    }
                    this.AddAdditionalClaims(additionalInnerHeaderClaims, false);
                    this.SigningCredentials = signingCredentials;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42949869696)
            
            //--TRIMMABLE-BOUNDARY-START(47244836992)
            $ctor$17(/*SigningCredentials*/ signingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType, /*IDictionary<string, object>*/ additionalInnerHeaderClaims)
            {
                this.$ctor$16(signingCredentials, outboundAlgorithmMap, tokenType, additionalInnerHeaderClaims, true);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244836992);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47244836992)
            
            //--TRIMMABLE-BOUNDARY-START(34359935104)
            $ctor$14(/*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap)
            {
                this.$ctor$13(encryptingCredentials, outboundAlgorithmMap, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34359935104);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34359935104)
            
            //--TRIMMABLE-BOUNDARY-START(30064967808)
            $ctor$13(/*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType)
            {
                this.$ctor$12(encryptingCredentials, outboundAlgorithmMap, tokenType, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064967808);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30064967808)
            
            //--TRIMMABLE-BOUNDARY-START(21475033216)
            $ctor$11(/*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType, /*IDictionary<string, object>*/ additionalHeaderClaims, /*bool*/ includeKeyIdInHeader)
            {
                super.$ctor$6($.$$.S.StringComparer.Ordinal);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475033216);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (encryptingCredentials === null)
                    {
                        throw $.$mil.MIL.LogHelper.LogArgumentNullException("encryptingCredentials");
                    }
                    /*string*/ let outboundAlg;
                    if (outboundAlgorithmMap !== null && outboundAlgorithmMap.SCG$IDictionary$$$$TryGetValue(encryptingCredentials.Alg, $.$ref(() => outboundAlg, ($v) => outboundAlg = $v, $.$$.S.String)))
                    {
                        this.Alg = outboundAlg;
                    }
                    else 
                    {
                        this.Alg = encryptingCredentials.Alg;
                    }
                    if (outboundAlgorithmMap !== null && outboundAlgorithmMap.SCG$IDictionary$$$$TryGetValue(encryptingCredentials.Enc, $.$ref(() => outboundAlg, ($v) => outboundAlg = $v, $.$$.S.String)))
                    {
                        this.Enc = outboundAlg;
                    }
                    else 
                    {
                        this.Enc = encryptingCredentials.Enc;
                    }
                    if ($.$mit.MIT$1.AppContextSwitches.UseRfcDefinitionOfEpkAndKid)
                    {
                        if (includeKeyIdInHeader && !$.$$.S.String.IsNullOrEmpty(encryptingCredentials.KeyExchangePublicKey.KeyId))
                        {
                            this.Kid = encryptingCredentials.KeyExchangePublicKey.KeyId;
                        }
                        if ($.$mit.MIT$1.SupportedAlgorithms.EcdsaWrapAlgorithms.SCG$ICollection$$$Contains(encryptingCredentials.Alg))
                        {
                            this.Add("epk"/*JwtHeaderParameterNames.Epk*/, $.$mit.MIT$1.JsonWebKeyConverter.ConvertFromSecurityKey(encryptingCredentials.Key).RepresentAsAsymmetricPublicJwk());
                        }
                    }
                    else 
                    {
                        if (includeKeyIdInHeader && !$.$$.S.String.IsNullOrEmpty(encryptingCredentials.Key.KeyId))
                        {
                            this.Kid = encryptingCredentials.Key.KeyId;
                        }
                    }
                    if ($.$$.S.String.IsNullOrEmpty(tokenType))
                    {
                        this.Typ = "JWT"/*JwtConstants.HeaderType*/;
                    }
                    else 
                    {
                        this.Typ = tokenType;
                    }
                    this.AddAdditionalClaims(additionalHeaderClaims, encryptingCredentials.SetDefaultCtyClaim);
                    this.EncryptingCredentials = encryptingCredentials;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475033216)
            
            //--TRIMMABLE-BOUNDARY-START(25770000512)
            $ctor$12(/*EncryptingCredentials*/ encryptingCredentials, /*IDictionary<string, string>*/ outboundAlgorithmMap, /*string*/ tokenType, /*IDictionary<string, object>*/ additionalHeaderClaims)
            {
                this.$ctor$11(encryptingCredentials, outboundAlgorithmMap, tokenType, additionalHeaderClaims, true);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770000512);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770000512)
            
            //--TRIMMABLE-BOUNDARY-START(73014640768)
            /*string */ get Alg()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669346432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("alg"/*JwtHeaderParameterNames.Alg*/);
            }
            /*string */ set Alg(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338496128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.set_Item("alg"/*JwtHeaderParameterNames.Alg*/, value);
            }
            //--TRIMMABLE-BOUNDARY-END(73014640768)
            
            //--TRIMMABLE-BOUNDARY-START(90194509952)
            /*string */ get Cty()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259281024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("cty"/*JwtHeaderParameterNames.Cty*/);
            }
            /*string */ set Cty(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928430720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.set_Item("cty"/*JwtHeaderParameterNames.Cty*/, value);
            }
            //--TRIMMABLE-BOUNDARY-END(90194509952)
            
            //--TRIMMABLE-BOUNDARY-START(98784444544)
            /*string */ get Enc()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849215616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("enc"/*JwtHeaderParameterNames.Enc*/);
            }
            /*string */ set Enc(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518365312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.set_Item("enc"/*JwtHeaderParameterNames.Enc*/, value);
            }
            //--TRIMMABLE-BOUNDARY-END(98784444544)
            
            //--TRIMMABLE-BOUNDARY-START(103079411840)
            /*EncryptingCredentials*/ EncryptingCredentials = null;
            //--TRIMMABLE-BOUNDARY-END(103079411840)
            
            //--TRIMMABLE-BOUNDARY-START(206158626944)
            /*string */ get IV()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029084800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("iv"/*JwtHeaderParameterNames.IV*/);
            }
            //--TRIMMABLE-BOUNDARY-END(206158626944)
            
            //--TRIMMABLE-BOUNDARY-START(210453594240)
            /*string */ get Kid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619019392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("kid"/*JwtHeaderParameterNames.Kid*/);
            }
            /*string */ set Kid(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698234496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.set_Item("kid"/*JwtHeaderParameterNames.Kid*/, value);
            }
            //--TRIMMABLE-BOUNDARY-END(210453594240)
            
            //--TRIMMABLE-BOUNDARY-START(279173070976)
            /*SigningCredentials*/ SigningCredentials = null;
            //--TRIMMABLE-BOUNDARY-END(279173070976)
            
            //--TRIMMABLE-BOUNDARY-START(283468038272)
            /*string */ get Typ()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798888576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("typ"/*JwtHeaderParameterNames.Typ*/);
            }
            /*string */ set Typ(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878103680);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.set_Item("typ"/*JwtHeaderParameterNames.Typ*/, value);
            }
            //--TRIMMABLE-BOUNDARY-END(283468038272)
            
            //--TRIMMABLE-BOUNDARY-START(292057972864)
            /*string */ get X5t()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978757760);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("x5t"/*JwtHeaderParameterNames.X5t*/);
            }
            //--TRIMMABLE-BOUNDARY-END(292057972864)
            
            //--TRIMMABLE-BOUNDARY-START(287763005568)
            /*string */ get X5c()
            {
                return this.GetStandardClaim("x5c"/*JwtHeaderParameterNames.X5c*/);
            }
            //--TRIMMABLE-BOUNDARY-END(287763005568)
            
            //--TRIMMABLE-BOUNDARY-START(296352940160)
            /*string */ get Zip()
            {
                return this.GetStandardClaim("zip"/*JwtHeaderParameterNames.Zip*/);
            }
            //--TRIMMABLE-BOUNDARY-END(296352940160)
            
            //--TRIMMABLE-BOUNDARY-START(77309608064)
            static /*JwtHeader */ Base64UrlDeserialize(/*string*/ base64UrlEncodedJsonString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309608064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(base64UrlEncodedJsonString, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("base64UrlEncodedJsonString") });
                return new $.$sitj.SITJ.JwtHeader().$ctor$21($.$mit.MIT$1.Base64UrlEncoder.Decode$3(base64UrlEncodedJsonString));
            }
            //--TRIMMABLE-BOUNDARY-END(77309608064)
            
            //--TRIMMABLE-BOUNDARY-START(81604575360)
            /*string */ Base64UrlEncode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mit.MIT$1.Base64UrlEncoder.Encode$3(this.SerializeToJson());
            }
            //--TRIMMABLE-BOUNDARY-END(81604575360)
            
            //--TRIMMABLE-BOUNDARY-START(201863659648)
            /*string */ GetStandardClaim(/*string*/ claimType)
            {
                /*object*/ let value;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863659648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.TryGetValue(claimType, $.$ref(() => value, ($v) => value = $v, $.$$.S.Object)))
                {
                    if (value === null)
                    {
                        return null;
                    }
                    let str;
                    if ($.$is(value, $.$$.S.String, { set $v($v){ str = $v; } }))
                    {
                        return str;
                    }
                    let jsonElement;
                    let list;
                    let objectList;
                    if ($.$is(value, $.$stj.STJ.JsonElement, { set $v($v){ jsonElement = $v; } }))
                    {
                        return jsonElement.ToString();
                    }
                    else if ($.$is(value, $.$$.SCG.IList$$($.$$.S.String), { set $v($v){ list = $v; } }))
                    {
                        /*JsonElement*/ let json = $.$mit.MITJ.JsonSerializerPrimitives.CreateJsonElement(list);
                        return json.ToString();
                    }
                    else if ($.$is(value, $.$$.SCG.IList$$($.$$.S.Object), { set $v($v){ objectList = $v; } }))
                    {
                        /*var*/ let stringList = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$3(objectList.SCG$ICollection$$$Count);
                        let $en10 = objectList.SCG$IEnumerable$$$GetEnumerator();
                        while ($en10.SC$1$IEnumerator$MoveNext())
                        {
                            let item = $en10.SCG$IEnumerator$$$Current;
                            {
                                let strItem;
                                if ($.$is(item, $.$$.S.String, { set $v($v){ strItem = $v; } }))
                                {
                                    stringList.Add(strItem);
                                }
                                else 
                                {
                                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$stj.STJ.JsonException().$ctor$10($.$mil.MIL.LogHelper.FormatInvariant("IDX11026: Unable to get claim value as a string from claim type:'{0}', value type was:'{1}'. Acceptable types are String, IList<String>, and System.Text.Json.JsonElement."/*Microsoft.IdentityModel.Tokens.LogMessages.IDX11026*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII(claimType), $.$mil.MIL.LogHelper.MarkAsNonPII($.$$.S.Object.GetType.call(item)) ], null, null))));
                                }
                            }
                        }
                        /*JsonElement*/ let json = $.$mit.MITJ.JsonSerializerPrimitives.CreateJsonElement(stringList);
                        return json.ToString();
                    }
                    return $.$$.S.String.Empty;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(201863659648)
            
            //--TRIMMABLE-BOUNDARY-START(68719673472)
            /*void */ AddAdditionalClaims(/*IDictionary<string, object>*/ additionalHeaderClaims, /*bool*/ setDefaultCtyClaim)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719673472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Int32.op_GreaterThan((additionalHeaderClaims?.SCG$ICollection$$$Count ?? null), 0) && $.$sl.SL.Enumerable.Any$1($.$$.S.String, $.$sl.SL.Enumerable.Intersect($.$$.S.String, additionalHeaderClaims.SCG$IDictionary$$$$Keys, $.$sitj.SITJ.JwtHeader.DefaultHeaderParameters, $.$$.S.StringComparer.OrdinalIgnoreCase)))
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$mit.MIT$1.SecurityTokenException().$ctor$10($.$mil.MIL.LogHelper.FormatInvariant("IDX12742: ''{0}' cannot contain the following claims: '{1}'. These values are added by default (if necessary) during security token creation."/*LogMessages.IDX12742*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ "additionalHeaderClaims", $.$$.S.String.Join$5(", ", $.$sitj.SITJ.JwtHeader.DefaultHeaderParameters) ], null, null))));
                }
                if (additionalHeaderClaims !== null)
                {
                    if (!additionalHeaderClaims.SCG$IDictionary$$$$TryGetValue("cty"/*JwtHeaderParameterNames.Cty*/, $.$discardRef()) && setDefaultCtyClaim)
                    {
                        this.Cty = "JWT"/*JwtConstants.HeaderType*/;
                    }
                    let $en11 = additionalHeaderClaims.SCG$IDictionary$$$$Keys.SCG$IEnumerable$$$GetEnumerator();
                    while ($en11.SC$1$IEnumerator$MoveNext())
                    {
                        let claim = $en11.SCG$IEnumerator$$$Current;
                        {
                            this.set_Item(claim, additionalHeaderClaims.SCG$IDictionary$$$$get_Item(claim));
                        }
                    }
                }
                else if (setDefaultCtyClaim)
                {
                    this.Cty = "JWT"/*JwtConstants.HeaderType*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719673472)
            
            //--TRIMMABLE-BOUNDARY-START(94489477248)
            /*IList<string>*/ static DefaultHeaderParameters = null;
            //--TRIMMABLE-BOUNDARY-END(94489477248)
            
            //--TRIMMABLE-BOUNDARY-START(214748561536)
            /*string */ SerializeToJson()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748561536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let memoryStream = null;
                try
                {
                    memoryStream = new $.$$.SI.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let writer = null;
                    try
                    {
                        writer = new $.$stj.STJ.Utf8JsonWriter().$ctor$3(memoryStream, (() =>
                        {
                            //new $.$stj.STJ.JsonWriterOptions()
                            const $t12 = $.$stj.STJ.JsonWriterOptions;
                            const $i12 = new $t12();
                            $i12.$ctor$2();
                            $i12.Encoder = $.$stew.STEW.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                            return $i12;
                        })());
                        writer.WriteStartObject();
                        $.$mit.MITJ.JsonSerializerPrimitives.WriteObjects($.$ref(() => writer, ($v) => writer = $v, $.$stj.STJ.Utf8JsonWriter), this);
                        writer.WriteEndObject();
                        writer.Flush();
                        return $.$$.ST.Encoding.UTF8.GetString(memoryStream.GetBuffer(), 0, $.$cast(memoryStream.Length, $.$$.S.Int32));
                    }
                    finally
                    {
                        {
                            writer?.Dispose();
                        }
                    }
                }
                finally
                {
                    memoryStream?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214748561536)
            
            //--TRIMMABLE-BOUNDARY-START(17180065920)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(17180065920)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(85899542656)
                this.ClassName = "System.IdentityModel.Tokens.Jwt.JwtHeader";
                //--TRIMMABLE-BOUNDARY-END(85899542656)
                
            }
            //--TRIMMABLE-BOUNDARY-START(12885098624)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(94489477248)
                    this.DefaultHeaderParameters = (() =>
                    {
                        //new $.$$.SCG.List$$($.$$.S.String)()
                        const $t14 = $.$$.SCG.List$$($.$$.S.String);
                        const $i14 = new $t14();
                        $i14.$ctor$1();
                        $i14.Add("alg"/*JwtHeaderParameterNames.Alg*/);
                        $i14.Add("kid"/*JwtHeaderParameterNames.Kid*/);
                        $i14.Add("x5t"/*JwtHeaderParameterNames.X5t*/);
                        $i14.Add("enc"/*JwtHeaderParameterNames.Enc*/);
                        $i14.Add("zip"/*JwtHeaderParameterNames.Zip*/);
                        return $i14;
                    })();
                    //--TRIMMABLE-BOUNDARY-END(94489477248)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885098624)
            
            static $h = 196736;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(73014640768),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669346432,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338496128,
        "f": 83886082
      },
      "n": "Alg",
      "d": 196736,
      "h": 73014640768,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014640768),
//--TRIMMABLE-BOUNDARY-START(90194509952),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259281024,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928430720,
        "f": 83886082
      },
      "n": "Cty",
      "d": 196736,
      "h": 90194509952,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194509952),
//--TRIMMABLE-BOUNDARY-START(98784444544),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849215616,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518365312,
        "f": 83886082
      },
      "n": "Enc",
      "d": 196736,
      "h": 98784444544,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784444544),
//--TRIMMABLE-BOUNDARY-START(103079411840),
    {
      "p": 3932286,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439150208,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249108299904,
        "f": 83886082
      },
      "n": "EncryptingCredentials",
      "d": 196736,
      "h": 103079411840,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079411840),
//--TRIMMABLE-BOUNDARY-START(206158626944),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029084800,
        "f": 50331649
      },
      "n": "IV",
      "d": 196736,
      "h": 206158626944,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206158626944),
//--TRIMMABLE-BOUNDARY-START(210453594240),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619019392,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257698234496,
        "f": 83886082
      },
      "n": "Kid",
      "d": 196736,
      "h": 210453594240,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210453594240),
//--TRIMMABLE-BOUNDARY-START(279173070976),
    {
      "p": 15925374,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163208953984,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266288169088,
        "f": 83886082
      },
      "n": "SigningCredentials",
      "d": 196736,
      "h": 279173070976,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279173070976),
//--TRIMMABLE-BOUNDARY-START(283468038272),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171798888576,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274878103680,
        "f": 83886082
      },
      "n": "Typ",
      "d": 196736,
      "h": 283468038272,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(283468038272),
//--TRIMMABLE-BOUNDARY-START(292057972864),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188978757760,
        "f": 50331649
      },
      "n": "X5t",
      "d": 196736,
      "h": 292057972864,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(292057972864),
//--TRIMMABLE-BOUNDARY-START(287763005568),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180388823168,
        "f": 50331649
      },
      "n": "X5c",
      "d": 196736,
      "h": 287763005568,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(287763005568),
//--TRIMMABLE-BOUNDARY-START(296352940160),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197568692352,
        "f": 50331649
      },
      "n": "Zip",
      "d": 196736,
      "h": 296352940160,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(296352940160)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(77309608064),
    {
      "r": 196736,
      "p": [
        {
          "n": "base64UrlEncodedJsonString",
          "p": 1310721
        }
      ],
      "n": "Base64UrlDeserialize",
      "d": 196736,
      "h": 77309608064,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77309608064),
//--TRIMMABLE-BOUNDARY-START(81604575360),
    {
      "r": 1310721,
      "n": "Base64UrlEncode",
      "d": 196736,
      "h": 81604575360,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(81604575360),
//--TRIMMABLE-BOUNDARY-START(201863659648),
    {
      "r": 1310721,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        }
      ],
      "n": "GetStandardClaim",
      "d": 196736,
      "h": 201863659648,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(201863659648),
//--TRIMMABLE-BOUNDARY-START(68719673472),
    {
      "r": 65537,
      "p": [
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        },
        {
          "n": "setDefaultCtyClaim",
          "p": 262145
        }
      ],
      "n": "AddAdditionalClaims",
      "d": 196736,
      "h": 68719673472,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(68719673472),
//--TRIMMABLE-BOUNDARY-START(214748561536),
    {
      "r": 1310721,
      "n": "SerializeToJson",
      "d": 196736,
      "h": 214748561536,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(214748561536)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(85899542656),
    {
      "t": 1310721,
      "n": "ClassName",
      "d": 196736,
      "h": 85899542656,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(85899542656),
//--TRIMMABLE-BOUNDARY-START(94489477248),
    {
      "t": $.$$.SCG.IList$$($.$$.S.String).$h,
      "n": "DefaultHeaderParameters",
      "d": 196736,
      "h": 94489477248,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94489477248)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180065920),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 196736,
      "h": 17180065920,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180065920),
//--TRIMMABLE-BOUNDARY-START(64424706176),
    {
      "p": [
        {
          "n": "json",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$21",
      "d": 196736,
      "h": 64424706176,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(64424706176),
//--TRIMMABLE-BOUNDARY-START(60129738880),
    {
      "p": [
        {
          "n": "signingCredentials",
          "p": 15925374
        }
      ],
      "n": ".ctor",
      "o": "$ctor$20",
      "d": 196736,
      "h": 60129738880,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129738880),
//--TRIMMABLE-BOUNDARY-START(38654902400),
    {
      "p": [
        {
          "n": "encryptingCredentials",
          "p": 3932286
        }
      ],
      "n": ".ctor",
      "o": "$ctor$15",
      "d": 196736,
      "h": 38654902400,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654902400),
//--TRIMMABLE-BOUNDARY-START(55834771584),
    {
      "p": [
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "outboundAlgorithmMap",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$19",
      "d": 196736,
      "h": 55834771584,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55834771584),
//--TRIMMABLE-BOUNDARY-START(51539804288),
    {
      "p": [
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "outboundAlgorithmMap",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$18",
      "d": 196736,
      "h": 51539804288,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(51539804288),
//--TRIMMABLE-BOUNDARY-START(42949869696),
    {
      "p": [
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "outboundAlgorithmMap",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        },
        {
          "n": "additionalInnerHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        },
        {
          "n": "includeKeyIdInHeader",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$16",
      "d": 196736,
      "h": 42949869696,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(42949869696),
//--TRIMMABLE-BOUNDARY-START(47244836992),
    {
      "p": [
        {
          "n": "signingCredentials",
          "p": 15925374
        },
        {
          "n": "outboundAlgorithmMap",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        },
        {
          "n": "additionalInnerHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$17",
      "d": 196736,
      "h": 47244836992,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47244836992),
//--TRIMMABLE-BOUNDARY-START(34359935104),
    {
      "p": [
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "outboundAlgorithmMap",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$14",
      "d": 196736,
      "h": 34359935104,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34359935104),
//--TRIMMABLE-BOUNDARY-START(30064967808),
    {
      "p": [
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "outboundAlgorithmMap",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$13",
      "d": 196736,
      "h": 30064967808,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30064967808),
//--TRIMMABLE-BOUNDARY-START(21475033216),
    {
      "p": [
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "outboundAlgorithmMap",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        },
        {
          "n": "includeKeyIdInHeader",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$11",
      "d": 196736,
      "h": 21475033216,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(21475033216),
//--TRIMMABLE-BOUNDARY-START(25770000512),
    {
      "p": [
        {
          "n": "encryptingCredentials",
          "p": 3932286
        },
        {
          "n": "outboundAlgorithmMap",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.String).$h
        },
        {
          "n": "tokenType",
          "p": 1310721
        },
        {
          "n": "additionalHeaderClaims",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$12",
      "d": 196736,
      "h": 25770000512,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770000512)
  ],
  "h": 196736
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), $.$$.SCG.ICollection$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$$.SC$1.IDictionary, $.$$.SC$1.ICollection, $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$$.S.Object), $.$$.SCG.IReadOnlyCollection$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$$.SC$1.IEnumerable, $.$$.SRS.ISerializable, $.$$.SRS.IDeserializationCallback ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IdentityModel.Tokens.Jwt.JwtHeader`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IdentityModel${separator}Tokens${separator}Jwt${separator}JwtHeader`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196736)
        
        

        //--TRIMMABLE-BOUNDARY-START(327808)
        $asm.$cls(`$sitj.SITJ.JwtPayload`, ($self) => class JwtPayload extends $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object)
        {
            //--TRIMMABLE-BOUNDARY-START(163209085056)
            /*string*/ static ClassName = null;
            //--TRIMMABLE-BOUNDARY-END(163209085056)
            
            //--TRIMMABLE-BOUNDARY-START(4295295104)
            /*List<string>*/ _audiences = null;
            //--TRIMMABLE-BOUNDARY-END(4295295104)
            
            //--TRIMMABLE-BOUNDARY-START(8590262400)
            /*string*/ _azp = null;
            //--TRIMMABLE-BOUNDARY-END(8590262400)
            
            //--TRIMMABLE-BOUNDARY-START(12885229696)
            /*long?*/ _exp = null;
            //--TRIMMABLE-BOUNDARY-END(12885229696)
            
            //--TRIMMABLE-BOUNDARY-START(17180196992)
            /*DateTime?*/ _expDateTime = null;
            //--TRIMMABLE-BOUNDARY-END(17180196992)
            
            //--TRIMMABLE-BOUNDARY-START(21475164288)
            /*long?*/ _iat = null;
            //--TRIMMABLE-BOUNDARY-END(21475164288)
            
            //--TRIMMABLE-BOUNDARY-START(25770131584)
            /*DateTime?*/ _iatDateTime = null;
            //--TRIMMABLE-BOUNDARY-END(25770131584)
            
            //--TRIMMABLE-BOUNDARY-START(30065098880)
            /*string*/ _id = null;
            //--TRIMMABLE-BOUNDARY-END(30065098880)
            
            //--TRIMMABLE-BOUNDARY-START(34360066176)
            /*string*/ _iss = null;
            //--TRIMMABLE-BOUNDARY-END(34360066176)
            
            //--TRIMMABLE-BOUNDARY-START(38655033472)
            /*string*/ _jti = null;
            //--TRIMMABLE-BOUNDARY-END(38655033472)
            
            //--TRIMMABLE-BOUNDARY-START(42950000768)
            /*long?*/ _nbf = null;
            //--TRIMMABLE-BOUNDARY-END(42950000768)
            
            //--TRIMMABLE-BOUNDARY-START(47244968064)
            /*DateTime?*/ _nbfDateTime = null;
            //--TRIMMABLE-BOUNDARY-END(47244968064)
            
            //--TRIMMABLE-BOUNDARY-START(51539935360)
            /*string*/ _sub = null;
            //--TRIMMABLE-BOUNDARY-END(51539935360)
            
            //--TRIMMABLE-BOUNDARY-START(55834902656)
            /*string*/ _tid = null;
            //--TRIMMABLE-BOUNDARY-END(55834902656)
            
            //--TRIMMABLE-BOUNDARY-START(60129869952)
            $ctor$10()
            {
                this.$ctor$15(null, null, null, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129869952);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(60129869952)
            
            //--TRIMMABLE-BOUNDARY-START(167504052352)
            static /*JwtPayload */ CreatePayload(/*byte[]*/ bytes, /*int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504052352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*JwtPayload*/ let payload = new $.$sitj.SITJ.JwtPayload().$ctor$10();
                /*Utf8JsonReader*/ let reader = new $.$stj.STJ.Utf8JsonReader().$ctor$6($.$$.S.Span$$($.$$.S.Byte).op_Implicit($.$$.S.MemoryExtensions.AsSpan$14($.$$.S.Byte, bytes).Slice(0, length)), new $.$stj.STJ.JsonReaderOptions());
                if (!$.$mit.MITJ.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), 1/*JsonTokenType.StartObject*/, true))
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$stj.STJ.JsonException().$ctor$10($.$mil.MIL.LogHelper.FormatInvariant("IDX11023: Expecting json reader to be positioned on '{0}', reader was positioned at: '{1}', Reading: '{2}', Position: '{3}', CurrentDepth: '{4}', BytesConsumed: '{5}'."/*Microsoft.IdentityModel.Tokens.LogMessages.IDX11023*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII("JsonTokenType.StartObject"), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(reader.TokenType, $.$stj.STJ.JsonTokenType)), $.$mil.MIL.LogHelper.MarkAsNonPII("System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(reader.TokenStartIndex, $.$$.S.Int64)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(reader.CurrentDepth, $.$$.S.Int32)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$box(reader.BytesConsumed, $.$$.S.Int64)) ], null, null))));
                }
                while(true)
                {
                    if (reader.TokenType === 5/*JsonTokenType.PropertyName*/)
                    {
                        if (reader.ValueTextEquals($.$mij.MIJ.JwtPayloadUtf8Bytes.Aud))
                        {
                            reader.Read();
                            payload._audiences = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                            if (reader.TokenType === 3/*JsonTokenType.StartArray*/)
                            {
                                $.$mit.MITJ.JsonSerializerPrimitives.ReadStrings$1($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), payload._audiences, "aud"/*JwtRegisteredClaimNames.Aud*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, false);
                                payload.set_Item("aud"/*JwtRegisteredClaimNames.Aud*/, payload._audiences);
                            }
                            else 
                            {
                                payload._audiences.Add($.$mit.MITJ.JsonSerializerPrimitives.ReadString($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), "aud"/*JwtRegisteredClaimNames.Aud*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, false));
                                payload.set_Item("aud"/*JwtRegisteredClaimNames.Aud*/, payload._audiences.get_Item(0));
                            }
                        }
                        else if (reader.ValueTextEquals($.$mij.MIJ.JwtPayloadUtf8Bytes.Exp))
                        {
                            payload._exp = $.$mit.MITJ.JsonSerializerPrimitives.ReadLong($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), "exp"/*JwtRegisteredClaimNames.Exp*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item("exp"/*JwtRegisteredClaimNames.Exp*/, $.$box(payload._exp, $.$$.S.Int64));
                            payload._expDateTime = $.$mit.MIT$1.EpochTime.DateTime($.$$.S.Nullable$$($.$$.S.Int64).Value$get.call(payload._exp));
                        }
                        else if (reader.ValueTextEquals($.$mij.MIJ.JwtPayloadUtf8Bytes.Iat))
                        {
                            payload._iat = $.$mit.MITJ.JsonSerializerPrimitives.ReadLong($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), "iat"/*JwtRegisteredClaimNames.Iat*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item("iat"/*JwtRegisteredClaimNames.Iat*/, $.$box(payload._iat, $.$$.S.Int64));
                            payload._iatDateTime = $.$mit.MIT$1.EpochTime.DateTime($.$$.S.Nullable$$($.$$.S.Int64).Value$get.call(payload._iat));
                        }
                        else if (reader.ValueTextEquals($.$mij.MIJ.JwtPayloadUtf8Bytes.Iss))
                        {
                            payload._iss = $.$mit.MITJ.JsonSerializerPrimitives.ReadString($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), "iss"/*JwtRegisteredClaimNames.Iss*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item("iss"/*JwtRegisteredClaimNames.Iss*/, payload._iss);
                        }
                        else if (reader.ValueTextEquals($.$mij.MIJ.JwtPayloadUtf8Bytes.Jti))
                        {
                            payload._jti = $.$mit.MITJ.JsonSerializerPrimitives.ReadString($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), "jti"/*JwtRegisteredClaimNames.Jti*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item("jti"/*JwtRegisteredClaimNames.Jti*/, payload._jti);
                        }
                        else if (reader.ValueTextEquals($.$mij.MIJ.JwtPayloadUtf8Bytes.Nbf))
                        {
                            payload._nbf = $.$mit.MITJ.JsonSerializerPrimitives.ReadLong($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), "nbf"/*JwtRegisteredClaimNames.Nbf*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload._nbfDateTime = $.$mit.MIT$1.EpochTime.DateTime($.$$.S.Nullable$$($.$$.S.Int64).Value$get.call(payload._nbf));
                            payload.set_Item("nbf"/*JwtRegisteredClaimNames.Nbf*/, $.$box(payload._nbf, $.$$.S.Int64));
                        }
                        else if (reader.ValueTextEquals($.$mij.MIJ.JwtPayloadUtf8Bytes.Sub))
                        {
                            payload._sub = $.$mit.MITJ.JsonSerializerPrimitives.ReadStringOrNumberAsString($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), "sub"/*JwtRegisteredClaimNames.Sub*/, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item("sub"/*JwtRegisteredClaimNames.Sub*/, payload._sub);
                        }
                        else 
                        {
                            /*string*/ let propertyName = $.$mit.MITJ.JsonSerializerPrimitives.ReadPropertyName($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, true);
                            payload.set_Item(propertyName, $.$mit.MITJ.JsonSerializerPrimitives.ReadPropertyValueAsObject($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), propertyName, "System.IdentityModel.Tokens.Jwt.JwtPayload"/*ClassName*/, false));
                        }
                    }
                    else if ($.$mit.MITJ.JsonSerializerPrimitives.IsReaderAtTokenType($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$stj.STJ.Utf8JsonReader, () => reader, ($v) => reader = $v, null, true), 2/*JsonTokenType.EndObject*/, true))
                    {
                        break;
                    }
                    else if (!reader.Read())
                    {
                        break;
                    }
                }
                return payload;
            }
            //--TRIMMABLE-BOUNDARY-END(167504052352)
            
            //--TRIMMABLE-BOUNDARY-START(64424837248)
            $ctor$11(/*IEnumerable<Claim>*/ claims)
            {
                this.$ctor$15(null, null, claims, null, null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424837248);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(64424837248)
            
            //--TRIMMABLE-BOUNDARY-START(81604706432)
            $ctor$15(/*string*/ issuer, /*string*/ audience, /*IEnumerable<Claim>*/ claims, /*DateTime?*/ notBefore, /*DateTime?*/ expires)
            {
                this.$ctor$14(issuer, audience, claims, $.$clone(notBefore), $.$clone(expires), null);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(81604706432);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(81604706432)
            
            //--TRIMMABLE-BOUNDARY-START(77309739136)
            $ctor$14(/*string*/ issuer, /*string*/ audience, /*IEnumerable<Claim>*/ claims, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                super.$ctor$6($.$$.S.StringComparer.Ordinal);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309739136);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (claims !== null)
                    {
                        this.AddClaims(claims);
                    }
                    this.AddFirstPriorityClaims$1(issuer, audience, $.$clone(notBefore), $.$clone(expires), $.$clone(issuedAt));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(77309739136)
            
            //--TRIMMABLE-BOUNDARY-START(68719804544)
            $ctor$12(/*string*/ issuer, /*IList<string>*/ audiences, /*IEnumerable<Claim>*/ claims, /*IDictionary<string, object>*/ claimsCollection, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                this.$ctor$16(issuer, "", audiences, claims, claimsCollection, $.$clone(notBefore), $.$clone(expires), $.$clone(issuedAt));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719804544);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(68719804544)
            
            //--TRIMMABLE-BOUNDARY-START(85899673728)
            $ctor$16(/*string*/ issuer, /*string*/ audience, /*IList<string>*/ audiences, /*IEnumerable<Claim>*/ claims, /*IDictionary<string, object>*/ claimsCollection, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                super.$ctor$6($.$$.S.StringComparer.Ordinal);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(85899673728);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (claims !== null)
                    {
                        this.AddClaims(claims);
                    }
                    if (claimsCollection !== null && $.$sl.SL.Enumerable.Any$1($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object), claimsCollection))
                    {
                        this.AddDictionaryClaims(claimsCollection);
                    }
                    if (audiences !== null)
                    {
                        this.AddFirstPriorityClaims(issuer, audience, audiences, $.$clone(notBefore), $.$clone(expires), $.$clone(issuedAt));
                    }
                    else 
                    {
                        this.AddFirstPriorityClaims(issuer, audience, (() =>
                        {
                            let $t13 = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                            return $t13;
                        })(), $.$clone(notBefore), $.$clone(expires), $.$clone(issuedAt));
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(85899673728)
            
            //--TRIMMABLE-BOUNDARY-START(120259412096)
            /*void */ AddFirstPriorityClaims$1(/*string*/ issuer, /*string*/ audience, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259412096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.AddFirstPriorityClaims(issuer, audience, (() =>
                {
                    let $t14 = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                    return $t14;
                })(), $.$clone(notBefore), $.$clone(expires), $.$clone(issuedAt));
            }
            //--TRIMMABLE-BOUNDARY-END(120259412096)
            
            //--TRIMMABLE-BOUNDARY-START(73014771840)
            $ctor$13(/*string*/ issuer, /*string*/ audience, /*IEnumerable<Claim>*/ claims, /*IDictionary<string, object>*/ claimsCollection, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                this.$ctor$16(issuer, audience, (() =>
                {
                    let $t15 = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                    return $t15;
                })(), claims, claimsCollection, $.$clone(notBefore), $.$clone(expires), $.$clone(issuedAt));
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014771840);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(73014771840)
            
            //--TRIMMABLE-BOUNDARY-START(115964444800)
            /*void */ AddFirstPriorityClaims(/*string*/ issuer, /*string*/ audience, /*IList<string>*/ audiences, /*DateTime?*/ notBefore, /*DateTime?*/ expires, /*DateTime?*/ issuedAt)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964444800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(expires))
                {
                    if ($.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(notBefore))
                    {
                        if ($.$$.S.DateTime.op_GreaterThanOrEqual($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(notBefore), $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(expires)))
                        {
                            throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentException().$ctor$14($.$mil.MIL.LogHelper.FormatInvariant("IDX12401: Expires: '{0}' must be after NotBefore: '{1}'."/*LogMessages.IDX12401*/, $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Object), [ $.$mil.MIL.LogHelper.MarkAsNonPII($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(expires)), $.$mil.MIL.LogHelper.MarkAsNonPII($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(notBefore)) ], null, null))));
                        }
                        this.set_Item("nbf"/*JwtRegisteredClaimNames.Nbf*/, $.$box($.$mit.MIT$1.EpochTime.GetIntDate($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(notBefore).ToUniversalTime()), $.$$.S.Int64));
                    }
                    this.set_Item("exp"/*JwtRegisteredClaimNames.Exp*/, $.$box($.$mit.MIT$1.EpochTime.GetIntDate($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(expires).ToUniversalTime()), $.$$.S.Int64));
                }
                if ($.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(issuedAt))
                {
                    this.set_Item("iat"/*JwtRegisteredClaimNames.Iat*/, $.$box($.$mit.MIT$1.EpochTime.GetIntDate($.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(issuedAt).ToUniversalTime()), $.$$.S.Int64));
                }
                if (!$.$$.S.String.IsNullOrEmpty(issuer))
                {
                    this.set_Item("iss"/*JwtRegisteredClaimNames.Iss*/, issuer);
                }
                if (!$.$$.S.String.IsNullOrEmpty(audience))
                {
                    this.AddClaim(new $.$ssc.SSC.Claim().$ctor$7("aud"/*JwtRegisteredClaimNames.Aud*/, audience, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/));
                }
                let $en16 = audiences.SCG$IEnumerable$$$GetEnumerator();
                while ($en16.SC$1$IEnumerator$MoveNext())
                {
                    let aud = $en16.SCG$IEnumerator$$$Current;
                    {
                        if (!$.$$.S.String.IsNullOrEmpty(aud))
                        {
                            this.AddClaim(new $.$ssc.SSC.Claim().$ctor$7("aud"/*JwtRegisteredClaimNames.Aud*/, aud, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/));
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964444800)
            
            //--TRIMMABLE-BOUNDARY-START(94489608320)
            /*string */ get Actort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568823424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("actort"/*JwtRegisteredClaimNames.Actort*/);
            }
            //--TRIMMABLE-BOUNDARY-END(94489608320)
            
            //--TRIMMABLE-BOUNDARY-START(90194641024)
            /*string */ get Acr()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978888832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("acr"/*JwtRegisteredClaimNames.Acr*/);
            }
            //--TRIMMABLE-BOUNDARY-END(90194641024)
            
            //--TRIMMABLE-BOUNDARY-START(128849346688)
            /*IList<string> */ get Amr()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158758016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetListOfClaims("amr"/*JwtRegisteredClaimNames.Amr*/);
            }
            //--TRIMMABLE-BOUNDARY-END(128849346688)
            
            //--TRIMMABLE-BOUNDARY-START(137439281280)
            /*int? */ get AuthTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338627200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetIntClaim("auth_time"/*JwtRegisteredClaimNames.AuthTime*/);
            }
            //--TRIMMABLE-BOUNDARY-END(137439281280)
            
            //--TRIMMABLE-BOUNDARY-START(133144313984)
            /*IList<string> */ get Aud()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748692608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._audiences === null)
                {
                    /*List<string>*/ let tmp = this.GetListOfClaims("aud"/*JwtRegisteredClaimNames.Aud*/);
                    $.$$.ST$1.Interlocked.CompareExchange$14($.$$.SCG.List$$($.$$.S.String), $.$ref(() => this._audiences, ($v) => this._audiences = $v, $.$$.SCG.List$$($.$$.S.String)), tmp, null);
                }
                return this._audiences;
            }
            //--TRIMMABLE-BOUNDARY-END(133144313984)
            
            //--TRIMMABLE-BOUNDARY-START(141734248576)
            /*string */ get Azp()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928561792);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("azp"/*JwtRegisteredClaimNames.Azp*/);
            }
            //--TRIMMABLE-BOUNDARY-END(141734248576)
            
            //--TRIMMABLE-BOUNDARY-START(154619150464)
            /*string */ get CHash()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518496384);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("c_hash"/*JwtRegisteredClaimNames.CHash*/);
            }
            //--TRIMMABLE-BOUNDARY-END(154619150464)
            
            //--TRIMMABLE-BOUNDARY-START(176093986944)
            /*int? */ get Exp()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698365568);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetIntClaim("exp"/*JwtRegisteredClaimNames.Exp*/);
            }
            //--TRIMMABLE-BOUNDARY-END(176093986944)
            
            //--TRIMMABLE-BOUNDARY-START(180388954240)
            /*long? */ get Expiration()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288300160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetLongClaim("exp"/*JwtRegisteredClaimNames.Exp*/);
            }
            //--TRIMMABLE-BOUNDARY-END(180388954240)
            
            //--TRIMMABLE-BOUNDARY-START(390842351744)
            /*string */ get Jti()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648038528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._jti ??= this.GetStandardClaim("jti"/*JwtRegisteredClaimNames.Jti*/);
                return this._jti;
            }
            //--TRIMMABLE-BOUNDARY-END(390842351744)
            
            //--TRIMMABLE-BOUNDARY-START(377957449856)
            /*int? */ get Iat()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878234752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetIntClaim("iat"/*JwtRegisteredClaimNames.Iat*/);
            }
            //--TRIMMABLE-BOUNDARY-END(377957449856)
            
            //--TRIMMABLE-BOUNDARY-START(382252417152)
            /*string */ get Iss()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468169344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._iss ??= this.GetStandardClaim("iss"/*JwtRegisteredClaimNames.Iss*/);
                return this._iss;
            }
            //--TRIMMABLE-BOUNDARY-END(382252417152)
            
            //--TRIMMABLE-BOUNDARY-START(395137319040)
            /*int? */ get Nbf()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309237973120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetIntClaim("nbf"/*JwtRegisteredClaimNames.Nbf*/);
            }
            //--TRIMMABLE-BOUNDARY-END(395137319040)
            
            //--TRIMMABLE-BOUNDARY-START(399432286336)
            /*string */ get Nonce()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317827907712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetStandardClaim("nonce"/*JwtRegisteredClaimNames.Nonce*/);
            }
            //--TRIMMABLE-BOUNDARY-END(399432286336)
            
            //--TRIMMABLE-BOUNDARY-START(403727253632)
            /*long? */ get NotBefore()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326417842304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetLongClaim("nbf"/*JwtRegisteredClaimNames.Nbf*/);
            }
            //--TRIMMABLE-BOUNDARY-END(403727253632)
            
            //--TRIMMABLE-BOUNDARY-START(412317188224)
            /*string */ get Sub()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335007776896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._sub ??= this.GetStandardClaim("sub"/*JwtRegisteredClaimNames.Sub*/);
                return this._sub;
            }
            //--TRIMMABLE-BOUNDARY-END(412317188224)
            
            //--TRIMMABLE-BOUNDARY-START(425202090112)
            /*DateTime */ get ValidFrom()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597711488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(this._nbfDateTime))
                {
                    return $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this._nbfDateTime);
                }
                /*long?*/ let l = this.GetLongClaim("nbf"/*JwtRegisteredClaimNames.Nbf*/);
                if ($.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(l))
                {
                    return $.$mit.MIT$1.EpochTime.DateTime($.$$.S.Nullable$$($.$$.S.Int64).Value$get.call(l));
                }
                this._nbfDateTime = $.$$.S.DateTime.MinValue;
                return $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this._nbfDateTime);
            }
            //--TRIMMABLE-BOUNDARY-END(425202090112)
            
            //--TRIMMABLE-BOUNDARY-START(429497057408)
            /*DateTime */ get ValidTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187646080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(this._expDateTime))
                {
                    return $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this._expDateTime);
                }
                /*long?*/ let l = this.GetLongClaim("exp"/*JwtRegisteredClaimNames.Exp*/);
                if ($.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(l))
                {
                    return $.$mit.MIT$1.EpochTime.DateTime($.$$.S.Nullable$$($.$$.S.Int64).Value$get.call(l));
                }
                this._expDateTime = $.$$.S.DateTime.MinValue;
                return $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this._expDateTime);
            }
            //--TRIMMABLE-BOUNDARY-END(429497057408)
            
            //--TRIMMABLE-BOUNDARY-START(386547384448)
            /*DateTime */ get IssuedAt()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058103936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Nullable$$($.$$.S.DateTime).HasValue$get.call(this._iatDateTime))
                {
                    return $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this._iatDateTime);
                }
                /*long?*/ let l = this.GetLongClaim("iat"/*JwtRegisteredClaimNames.Iat*/);
                if ($.$$.S.Nullable$$($.$$.S.Int64).HasValue$get.call(l))
                {
                    return $.$mit.MIT$1.EpochTime.DateTime($.$$.S.Nullable$$($.$$.S.Int64).Value$get.call(l));
                }
                this._iatDateTime = $.$$.S.DateTime.MinValue;
                return $.$$.S.Nullable$$($.$$.S.DateTime).Value$get.call(this._iatDateTime);
            }
            //--TRIMMABLE-BOUNDARY-END(386547384448)
            
            //--TRIMMABLE-BOUNDARY-START(158914117760)
            /*IEnumerable<Claim> */ get Claims()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108430976);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<Claim>*/ let claims = new ($.$$.SCG.List$$($.$ssc.SSC.Claim))().$ctor$1();
                /*string*/ let issuer = this.Iss ?? "LOCAL AUTHORITY"/*ClaimsIdentity.DefaultIssuer*/;
                let $en18 = this.GetEnumerator();
                while ($en18.MoveNext())
                {
                    let keyValuePair = $en18.Current;
                    {
                        let str;
                        let j;
                        let objects;
                        let dictionary;
                        let dateTime;
                        let boolValue;
                        if (keyValuePair.Value === null)
                        {
                            claims.Add(new $.$ssc.SSC.Claim().$ctor$5(keyValuePair.Key, $.$$.S.String.Empty, "JSON_NULL"/*JsonClaimValueTypes.JsonNull*/, issuer, issuer));
                        }
                        else if ($.$is(keyValuePair.Value, $.$$.S.String, { set $v($v){ str = $v; } }))
                        {
                            claims.Add(new $.$ssc.SSC.Claim().$ctor$5(keyValuePair.Key, str, $.$sitj.SITJ.JwtPayload.GetClaimValueType(keyValuePair.Key, str), issuer, issuer));
                        }
                        else if ($.$is(keyValuePair.Value, $.$stj.STJ.JsonElement, { set $v($v){ j = $v; } }))
                        {
                            $.$sitj.SITJ.JwtPayload.AddClaimsFromJsonElement(keyValuePair.Key, issuer, j, claims);
                        }
                        else if ($.$is(keyValuePair.Value, $.$$.SCG.IEnumerable$$($.$$.S.Object), { set $v($v){ objects = $v; } }))
                        {
                            this.AddListofObjects(keyValuePair.Key, objects, claims, issuer);
                        }
                        else if ($.$is(keyValuePair.Value, $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), { set $v($v){ dictionary = $v; } }))
                        {
                            let $en19 = dictionary.SCG$IEnumerable$$$GetEnumerator();
                            while ($en19.SC$1$IEnumerator$MoveNext())
                            {
                                let item = $en19.SCG$IEnumerator$$$Current;
                                {
                                    if (item.Value !== null)
                                    {
                                        claims.Add(new $.$ssc.SSC.Claim().$ctor$5(keyValuePair.Key, $.$strNN($.$strNN($.$strNN("{" + $.$strNN(item.Key)) + ":") + $.$strNN($.$dsp(item.Value, $.$$.S.Object, ($t) => $t.ToString))) + "}", $.$sitj.SITJ.JwtPayload.GetClaimValueType(item.Key, item.Value), issuer, issuer));
                                    }
                                }
                            }
                        }
                        else if ($.$is(keyValuePair.Value, $.$$.S.DateTime, { set $v($v){ dateTime = $v; } }))
                        {
                            claims.Add(new $.$ssc.SSC.Claim().$ctor$5(keyValuePair.Key, dateTime.ToString$2("o", $.$$.SG.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#dateTime"/*ClaimValueTypes.DateTime*/, issuer, issuer));
                        }
                        else if ($.$is(keyValuePair.Value, $.$$.S.Boolean, { set $v($v){ boolValue = $v; } }))
                        {
                            if (boolValue)
                            {
                                claims.Add(new $.$ssc.SSC.Claim().$ctor$5(keyValuePair.Key, "true", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                            }
                            else 
                            {
                                claims.Add(new $.$ssc.SSC.Claim().$ctor$5(keyValuePair.Key, "false", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                            }
                        }
                        else if (keyValuePair.Value !== null)
                        {
                            /*var*/ let value = keyValuePair.Value;
                            /*var*/ let claimValueType = $.$sitj.SITJ.JwtPayload.GetClaimValueType(keyValuePair.Key, value);
                            let formattable;
                            if ($.$is(value, $.$$.S.IFormattable, { set $v($v){ formattable = $v; } }))
                            {
                                claims.Add(new $.$ssc.SSC.Claim().$ctor$5(keyValuePair.Key, formattable.S$IFormattable$ToString(null, $.$$.SG.CultureInfo.InvariantCulture), claimValueType, issuer, issuer));
                            }
                            else 
                            {
                                claims.Add(new $.$ssc.SSC.Claim().$ctor$5(keyValuePair.Key, $.$dspc(value, $.$$.S.Object, ($t) => $t.ToString), claimValueType, issuer, issuer));
                            }
                        }
                    }
                }
                return claims;
            }
            //--TRIMMABLE-BOUNDARY-END(158914117760)
            
            //--TRIMMABLE-BOUNDARY-START(124554379392)
            /*void */ AddListofObjects(/*string*/ key, /*IEnumerable<object>*/ objects, /*List<Claim>*/ claims, /*string*/ issuer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554379392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $en20 = objects.SCG$IEnumerable$$$GetEnumerator();
                while ($en20.SC$1$IEnumerator$MoveNext())
                {
                    let obj = $en20.SCG$IEnumerator$$$Current;
                    {
                        let claimValue;
                        let boolValue;
                        let dateTimeValue;
                        let jsonElement;
                        let innerObjects;
                        if ($.$is(obj, $.$$.S.String, { set $v($v){ claimValue = $v; } }))
                        {
                            claims.Add(new $.$ssc.SSC.Claim().$ctor$5(key, claimValue, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/, issuer, issuer));
                        }
                        else if ($.$is(obj, $.$$.S.Boolean, { set $v($v){ boolValue = $v; } }))
                        {
                            if (boolValue)
                            {
                                claims.Add(new $.$ssc.SSC.Claim().$ctor$5(key, "true", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                            }
                            else 
                            {
                                claims.Add(new $.$ssc.SSC.Claim().$ctor$5(key, "false", "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/, issuer, issuer));
                            }
                        }
                        else if ($.$is(obj, $.$$.S.DateTime, { set $v($v){ dateTimeValue = $v; } }))
                        {
                            claims.Add(new $.$ssc.SSC.Claim().$ctor$5(key, dateTimeValue.ToString$2("o", $.$$.SG.CultureInfo.InvariantCulture), "http://www.w3.org/2001/XMLSchema#dateTime"/*ClaimValueTypes.DateTime*/, issuer, issuer));
                        }
                        else if ($.$is(obj, $.$stj.STJ.JsonElement, { set $v($v){ jsonElement = $v; } }))
                        {
                            claims.Add($.$mij.MIJ.JsonClaimSet.CreateClaimFromJsonElement(key, issuer, jsonElement));
                        }
                        else if ($.$is(obj, $.$$.SCG.IEnumerable$$($.$$.S.Object), { set $v($v){ innerObjects = $v; } }))
                        {
                            this.AddListofObjects(key, innerObjects, claims, issuer);
                        }
                        else 
                        {
                            /*var*/ let claimValueType = $.$sitj.SITJ.JwtPayload.GetClaimValueType(key, obj);
                            let formattable;
                            if ($.$is(obj, $.$$.S.IFormattable, { set $v($v){ formattable = $v; } }))
                            {
                                claims.Add(new $.$ssc.SSC.Claim().$ctor$5(key, formattable.S$IFormattable$ToString(null, $.$$.SG.CultureInfo.InvariantCulture), claimValueType, issuer, issuer));
                            }
                            else 
                            {
                                claims.Add(new $.$ssc.SSC.Claim().$ctor$5(key, $.$dspc(obj, $.$$.S.Object, ($t) => $t.ToString), claimValueType, issuer, issuer));
                            }
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554379392)
            
            //--TRIMMABLE-BOUNDARY-START(107374510208)
            static /*void */ AddClaimsFromJsonElement(/*string*/ claimType, /*string*/ issuer, /*JsonElement*/ jsonElement, /*List<Claim>*/ claims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374510208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (jsonElement.ValueKind === 2/*JsonValueKind.Array*/)
                {
                    let $en21 = jsonElement.EnumerateArray().GetEnumerator();
                    while ($en21.MoveNext())
                    {
                        let element = $en21.Current;
                        {
                            claims.Add($.$mij.MIJ.JsonClaimSet.CreateClaimFromJsonElement(claimType, issuer, element));
                        }
                    }
                }
                else 
                {
                    claims.Add($.$mij.MIJ.JsonClaimSet.CreateClaimFromJsonElement(claimType, issuer, jsonElement));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374510208)
            
            //--TRIMMABLE-BOUNDARY-START(98784575616)
            /*void */ AddClaim(/*Claim*/ claim)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784575616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (claim === null)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentNullException().$ctor$19("claim"));
                }
                this.AddClaims($.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$ssc.SSC.Claim), [claim], [-1], null));
            }
            //--TRIMMABLE-BOUNDARY-END(98784575616)
            
            //--TRIMMABLE-BOUNDARY-START(103079542912)
            /*void */ AddClaims(/*IEnumerable<Claim>*/ claims)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079542912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (claims === null)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentNullException().$ctor$19("claims"));
                }
                let $en22 = claims.SCG$IEnumerable$$$GetEnumerator();
                while ($en22.SC$1$IEnumerator$MoveNext())
                {
                    let claim = $en22.SCG$IEnumerator$$$Current;
                    {
                        if (claim === null)
                        {
                            continue;
                        }
                        /*string*/ let jsonClaimType = claim.Type;
                        /*object*/ let jsonClaimValue = $.$$.S.String.Equals$5.call(claim.ValueType, "http://www.w3.org/2001/XMLSchema#string"/*ClaimValueTypes.String*/) ? claim.Value : $.$mit.MIT$1.TokenUtilities.GetClaimValueUsingValueType(claim);
                        /*object*/ let existingValue;
                        if (this.TryGetValue(jsonClaimType, $.$ref(() => existingValue, ($v) => existingValue = $v, $.$$.S.Object)))
                        {
                            /*IList<object>*/ let claimValues = $.$as(existingValue, $.$$.SCG.IList$$($.$$.S.Object));
                            if (claimValues === null)
                            {
                                claimValues = new ($.$$.SCG.List$$($.$$.S.Object))().$ctor$1();
                                claimValues.SCG$ICollection$$$Add(existingValue);
                                this.set_Item(jsonClaimType, claimValues);
                            }
                            claimValues.SCG$ICollection$$$Add(jsonClaimValue);
                        }
                        else 
                        {
                            this.set_Item(jsonClaimType, jsonClaimValue);
                        }
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079542912)
            
            //--TRIMMABLE-BOUNDARY-START(111669477504)
            /*void */ AddDictionaryClaims(/*IDictionary<string, object>*/ claimsCollection)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669477504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (claimsCollection === null)
                {
                    throw $.$mil.MIL.LogHelper.LogExceptionMessage$1(new $.$$.S.ArgumentNullException().$ctor$19("claimsCollection"));
                }
                let $en24 = claimsCollection.SCG$IEnumerable$$$GetEnumerator();
                while ($en24.SC$1$IEnumerator$MoveNext())
                {
                    let kvp = $en24.SCG$IEnumerator$$$Current;
                    {
                        this.set_Item(kvp.Key, kvp.Value);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669477504)
            
            //--TRIMMABLE-BOUNDARY-START(356482613376)
            static /*string */ GetClaimValueType(/*string*/ claimType, /*object*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356482613376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (value === null)
                {
                    return "JSON_NULL"/*JsonClaimValueTypes.JsonNull*/;
                }
                /*Type*/ let objType = $.$$.S.Object.GetType.call(value);
                let str;
                if ($.$is(value, $.$$.S.String, { set $v($v){ str = $v; } }))
                {
                    return $.$mij.MIJ.JwtTokenUtilities.GetStringClaimValueType(str, claimType);
                }
                else if (objType === $.$$.S.Int32.$type)
                {
                    return "http://www.w3.org/2001/XMLSchema#integer32"/*ClaimValueTypes.Integer32*/;
                }
                else if (objType === $.$$.S.Int64.$type)
                {
                    return "http://www.w3.org/2001/XMLSchema#integer64"/*ClaimValueTypes.Integer64*/;
                }
                else if (objType === $.$$.S.Boolean.$type)
                {
                    return "http://www.w3.org/2001/XMLSchema#boolean"/*ClaimValueTypes.Boolean*/;
                }
                else if (objType === $.$$.S.Double.$type)
                {
                    return "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/;
                }
                else if (objType === $.$$.S.DateTime.$type)
                {
                    return "http://www.w3.org/2001/XMLSchema#dateTime"/*ClaimValueTypes.DateTime*/;
                }
                else if (objType === $.$$.S.Single.$type)
                {
                    return "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/;
                }
                else if (objType === $.$$.S.Decimal.$type)
                {
                    return "http://www.w3.org/2001/XMLSchema#double"/*ClaimValueTypes.Double*/;
                }
                else if (value === null)
                {
                    return "JSON_NULL"/*JsonClaimValueTypes.JsonNull*/;
                }
                else if (objType === $.$stj.STJ.JsonElement.$type)
                {
                    return "JSON"/*JsonClaimValueTypes.Json*/;
                }
                return objType.ToString();
            }
            //--TRIMMABLE-BOUNDARY-END(356482613376)
            
            //--TRIMMABLE-BOUNDARY-START(373662482560)
            /*string */ GetStandardClaim(/*string*/ claimType)
            {
                /*object*/ let value;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662482560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.TryGetValue(claimType, $.$ref(() => value, ($v) => value = $v, $.$$.S.Object)))
                {
                    if (value === null)
                    {
                        return null;
                    }
                    let str;
                    if ($.$is(value, $.$$.S.String, { set $v($v){ str = $v; } }))
                    {
                        return str;
                    }
                    return $.$$.S.String.Empty;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(373662482560)
            
            //--TRIMMABLE-BOUNDARY-START(360777580672)
            /*int? */ GetIntClaim(/*string*/ claimType)
            {
                /*object*/ let claimValue;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777580672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.TryGetValue(claimType, $.$ref(() => claimValue, ($v) => claimValue = $v, $.$$.S.Object)))
                {
                    /*int*/ let i = 0;
                    if ($.$sitj.SITJ.JwtPayload.TryConvertToInt(claimValue, $.$ref(() => i, ($v) => i = $v, $.$$.S.Int32)))
                    {
                        return i;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(360777580672)
            
            //--TRIMMABLE-BOUNDARY-START(369367515264)
            /*long? */ GetLongClaim(/*string*/ claimType)
            {
                /*object*/ let claimValue;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367515264);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.TryGetValue(claimType, $.$ref(() => claimValue, ($v) => claimValue = $v, $.$$.S.Object)))
                {
                    /*long*/ let l = 0n;
                    if ($.$sitj.SITJ.JwtPayload.TryConvertToLong(claimValue, $.$ref(() => l, ($v) => l = $v, $.$$.S.Int64)))
                    {
                        return l;
                    }
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(369367515264)
            
            //--TRIMMABLE-BOUNDARY-START(416612155520)
            static /*bool */ TryConvertToInt(/*object*/ value, /*ref int*/ outVal)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612155520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                outVal.$v = 0;
                try
                {
                    let i;
                    if ($.$is(value, $.$$.S.Int32, { set $v($v){ i = $v; } }))
                    {
                        outVal.$v = i;
                        return true;
                    }
                    let str;
                    if ($.$is(value, $.$$.S.String, { set $v($v){ str = $v; } }))
                    {
                        /*int*/ let result;
                        if ($.$$.S.Int32.TryParse$6(str, $.$ref(() => result, ($v) => result = $v, $.$$.S.Int32)))
                        {
                            outVal.$v = result;
                            return true;
                        }
                    }
                    outVal.$v = $.$$.S.Convert.ToInt32$5($.$$.S.Math.Truncate$1($.$$.S.Convert.ToDouble$9(value, $.$$.SG.CultureInfo.InvariantCulture)));
                    return true;
                }
                catch($e)
                {
                    if ($e instanceof $.$$.S.FormatException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$$.S.OverflowException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$$.S.InvalidCastException)
                    {
                        return false;
                    }
                    else
                    {
                        throw $e;
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(416612155520)
            
            //--TRIMMABLE-BOUNDARY-START(420907122816)
            static /*bool */ TryConvertToLong(/*object*/ value, /*ref long*/ outVal)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420907122816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                outVal.$v = 0n;
                try
                {
                    let l;
                    if ($.$is(value, $.$$.S.Int64, { set $v($v){ l = $v; } }))
                    {
                        outVal.$v = l;
                        return true;
                    }
                    let str;
                    if ($.$is(value, $.$$.S.String, { set $v($v){ str = $v; } }))
                    {
                        /*long*/ let result;
                        if ($.$$.S.Int64.TryParse$6(str, $.$ref(() => result, ($v) => result = $v, $.$$.S.Int64)))
                        {
                            outVal.$v = result;
                            return true;
                        }
                    }
                    outVal.$v = $.$$.S.Convert.ToInt64$5($.$$.S.Math.Truncate$1($.$$.S.Convert.ToDouble$9(value, $.$$.SG.CultureInfo.InvariantCulture)));
                    return true;
                }
                catch($e)
                {
                    if ($e instanceof $.$$.S.FormatException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$$.S.OverflowException)
                    {
                        return false;
                    }
                    else if ($e instanceof $.$$.S.InvalidCastException)
                    {
                        return false;
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(420907122816)
            
            //--TRIMMABLE-BOUNDARY-START(365072547968)
            /*List<string> */ GetListOfClaims(/*string*/ claimType)
            {
                /*object*/ let value;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365072547968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*List<string>*/ let claimValues = new ($.$$.SCG.List$$($.$$.S.String))().$ctor$1();
                if (!this.TryGetValue(claimType, $.$ref(() => value, ($v) => value = $v, $.$$.S.Object)))
                {
                    return claimValues;
                }
                let jsonElement;
                let str;
                let values;
                if ($.$is(value, $.$stj.STJ.JsonElement, { set $v($v){ jsonElement = $v; } }))
                {
                    /*List<string>*/ let list;
                    if ($.$mit.MITJ.JsonSerializerPrimitives.TryCreateTypeFromJsonElement($.$$.SCG.List$$($.$$.S.String), jsonElement, $.$ref(() => list, ($v) => list = $v, $.$$.SCG.List$$($.$$.S.String))))
                    {
                        return list;
                    }
                }
                else if ($.$is(value, $.$$.S.String, { set $v($v){ str = $v; } }))
                {
                    claimValues.Add(str);
                }
                else if ($.$is(value, $.$$.SCG.IEnumerable$$($.$$.S.Object), { set $v($v){ values = $v; } }))
                {
                    let $en34 = values.SCG$IEnumerable$$$GetEnumerator();
                    while ($en34.SC$1$IEnumerator$MoveNext())
                    {
                        let item = $en34.SCG$IEnumerator$$$Current;
                        {
                            claimValues.Add($.$dsp(item, $.$$.S.Object, ($t) => $t.ToString));
                        }
                    }
                }
                else 
                {
                    claimValues.Add($.$dsp(value, $.$$.S.Object, ($t) => $t.ToString));
                }
                return claimValues;
            }
            //--TRIMMABLE-BOUNDARY-END(365072547968)
            
            //--TRIMMABLE-BOUNDARY-START(408022220928)
            /*string */ SerializeToJson()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022220928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let memoryStream = null;
                try
                {
                    memoryStream = new $.$$.SI.MemoryStream().$ctor$3();
                    /*Utf8JsonWriter*/ let writer = null;
                    try
                    {
                        writer = new $.$stj.STJ.Utf8JsonWriter().$ctor$3(memoryStream, (() =>
                        {
                            //new $.$stj.STJ.JsonWriterOptions()
                            const $t35 = $.$stj.STJ.JsonWriterOptions;
                            const $i35 = new $t35();
                            $i35.$ctor$2();
                            $i35.Encoder = $.$stew.STEW.JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
                            return $i35;
                        })());
                        writer.WriteStartObject();
                        $.$mit.MITJ.JsonSerializerPrimitives.WriteObjects($.$ref(() => writer, ($v) => writer = $v, $.$stj.STJ.Utf8JsonWriter), this);
                        writer.WriteEndObject();
                        writer.Flush();
                        return $.$$.ST.Encoding.UTF8.GetString(memoryStream.GetBuffer(), 0, $.$cast(memoryStream.Length, $.$$.S.Int32));
                    }
                    finally
                    {
                        {
                            writer?.Dispose();
                        }
                    }
                }
                finally
                {
                    memoryStream?.S$IDisposable$Dispose();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(408022220928)
            
            //--TRIMMABLE-BOUNDARY-START(146029215872)
            static /*JwtPayload */ Base64UrlDeserialize(/*string*/ base64UrlEncodedJsonString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029215872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(base64UrlEncodedJsonString, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("base64UrlEncodedJsonString") });
                return $.$mit.MIT$1.Base64UrlEncoding.Decode$5($.$sitj.SITJ.JwtPayload, base64UrlEncodedJsonString, 0, base64UrlEncodedJsonString.length, new ($.$$.S.Func$$$$($.$typeArray($.$$.S.Byte), $.$$.S.Int32, $.$sitj.SITJ.JwtPayload))().$ctor($.$sitj.SITJ.JwtPayload, $.$sitj.SITJ.JwtPayload.CreatePayload));
            }
            //--TRIMMABLE-BOUNDARY-END(146029215872)
            
            //--TRIMMABLE-BOUNDARY-START(150324183168)
            /*string */ Base64UrlEncode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324183168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$mit.MIT$1.Base64UrlEncoder.Encode$3(this.SerializeToJson());
            }
            //--TRIMMABLE-BOUNDARY-END(150324183168)
            
            //--TRIMMABLE-BOUNDARY-START(171799019648)
            static /*JwtPayload */ Deserialize(/*string*/ jsonString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799019648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                _ = $.$firstOf(jsonString, () => { throw $.$mil.MIL.LogHelper.LogArgumentNullException("jsonString") });
                /*byte[]*/ let bytes = $.$$.ST.Encoding.UTF8.GetBytes$8(jsonString);
                return $.$sitj.SITJ.JwtPayload.CreatePayload(bytes, bytes.length);
            }
            //--TRIMMABLE-BOUNDARY-END(171799019648)
            
            //--TRIMMABLE-BOUNDARY-START(60129869952)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$10();
            }
            //--TRIMMABLE-BOUNDARY-END(60129869952)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180196992)
                this._expDateTime = null;
                //--TRIMMABLE-BOUNDARY-END(17180196992)
                
                //--TRIMMABLE-BOUNDARY-START(25770131584)
                this._iatDateTime = null;
                //--TRIMMABLE-BOUNDARY-END(25770131584)
                
                //--TRIMMABLE-BOUNDARY-START(47244968064)
                this._nbfDateTime = null;
                //--TRIMMABLE-BOUNDARY-END(47244968064)
                
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(163209085056)
                    this.ClassName = "System.IdentityModel.Tokens.Jwt.JwtPayload";
                    //--TRIMMABLE-BOUNDARY-END(163209085056)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 327808;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SCG.Dictionary$$$($.$$.S.String, $.$$.S.Object); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94489608320),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197568823424,
        "f": 50331649
      },
      "n": "Actort",
      "d": 327808,
      "h": 94489608320,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489608320),
//--TRIMMABLE-BOUNDARY-START(90194641024),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188978888832,
        "f": 50331649
      },
      "n": "Acr",
      "d": 327808,
      "h": 90194641024,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194641024),
//--TRIMMABLE-BOUNDARY-START(128849346688),
    {
      "p": $.$$.SCG.IList$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206158758016,
        "f": 50331649
      },
      "n": "Amr",
      "d": 327808,
      "h": 128849346688,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849346688),
//--TRIMMABLE-BOUNDARY-START(137439281280),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223338627200,
        "f": 50331649
      },
      "n": "AuthTime",
      "d": 327808,
      "h": 137439281280,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439281280),
//--TRIMMABLE-BOUNDARY-START(133144313984),
    {
      "p": $.$$.SCG.IList$$($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214748692608,
        "f": 50331649
      },
      "n": "Aud",
      "d": 327808,
      "h": 133144313984,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144313984),
//--TRIMMABLE-BOUNDARY-START(141734248576),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231928561792,
        "f": 50331649
      },
      "n": "Azp",
      "d": 327808,
      "h": 141734248576,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141734248576),
//--TRIMMABLE-BOUNDARY-START(154619150464),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240518496384,
        "f": 50331649
      },
      "n": "CHash",
      "d": 327808,
      "h": 154619150464,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619150464),
//--TRIMMABLE-BOUNDARY-START(176093986944),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257698365568,
        "f": 50331649
      },
      "n": "Exp",
      "d": 327808,
      "h": 176093986944,
      "f": 2097153,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "\u0060int? JwtPayload.Exp\u0060 is deprecated and will be removed in a future release. Use \u0060long? JwtPayload.Expiration\u0060 instead. For more information, see https://aka.ms/IdentityModel/7-breaking-changes",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(176093986944),
//--TRIMMABLE-BOUNDARY-START(180388954240),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266288300160,
        "f": 50331649
      },
      "n": "Expiration",
      "d": 327808,
      "h": 180388954240,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180388954240),
//--TRIMMABLE-BOUNDARY-START(390842351744),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 300648038528,
        "f": 50331649
      },
      "n": "Jti",
      "d": 327808,
      "h": 390842351744,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(390842351744),
//--TRIMMABLE-BOUNDARY-START(377957449856),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274878234752,
        "f": 50331649
      },
      "n": "Iat",
      "d": 327808,
      "h": 377957449856,
      "f": 2097153,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "\u0060int? JwtPayload.Iat\u0060 is deprecated and will be removed in a future release. Use \u0060DateTime JwtPayload.IssuedAt\u0060 instead. For more information, see https://aka.ms/IdentityModel/7-breaking-changes",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(377957449856),
//--TRIMMABLE-BOUNDARY-START(382252417152),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283468169344,
        "f": 50331649
      },
      "n": "Iss",
      "d": 327808,
      "h": 382252417152,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(382252417152),
//--TRIMMABLE-BOUNDARY-START(395137319040),
    {
      "p": $.$typeNullable($.$$.S.Int32).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 309237973120,
        "f": 50331649
      },
      "n": "Nbf",
      "d": 327808,
      "h": 395137319040,
      "f": 2097153,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "\u0060int? JwtPayload.Nbf\u0060 is deprecated and will be removed in a future release. Use \u0060long? JwtPayload.NotBefore\u0060 instead. For more information, see https://aka.ms/IdentityModel/7-breaking-changes",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(395137319040),
//--TRIMMABLE-BOUNDARY-START(399432286336),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 317827907712,
        "f": 50331649
      },
      "n": "Nonce",
      "d": 327808,
      "h": 399432286336,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(399432286336),
//--TRIMMABLE-BOUNDARY-START(403727253632),
    {
      "p": $.$typeNullable($.$$.S.Int64).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 326417842304,
        "f": 50331649
      },
      "n": "NotBefore",
      "d": 327808,
      "h": 403727253632,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(403727253632),
//--TRIMMABLE-BOUNDARY-START(412317188224),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 335007776896,
        "f": 50331649
      },
      "n": "Sub",
      "d": 327808,
      "h": 412317188224,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(412317188224),
//--TRIMMABLE-BOUNDARY-START(425202090112),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 343597711488,
        "f": 50331649
      },
      "n": "ValidFrom",
      "d": 327808,
      "h": 425202090112,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(425202090112),
//--TRIMMABLE-BOUNDARY-START(429497057408),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 352187646080,
        "f": 50331649
      },
      "n": "ValidTo",
      "d": 327808,
      "h": 429497057408,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(429497057408),
//--TRIMMABLE-BOUNDARY-START(386547384448),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 292058103936,
        "f": 50331649
      },
      "n": "IssuedAt",
      "d": 327808,
      "h": 386547384448,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(386547384448),
//--TRIMMABLE-BOUNDARY-START(158914117760),
    {
      "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249108430976,
        "f": 50331777
      },
      "n": "Claims",
      "d": 327808,
      "h": 158914117760,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(158914117760)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(167504052352),
    {
      "r": 327808,
      "p": [
        {
          "n": "bytes",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "CreatePayload",
      "d": 327808,
      "h": 167504052352,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(167504052352),
//--TRIMMABLE-BOUNDARY-START(120259412096),
    {
      "r": 65537,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        }
      ],
      "n": "AddFirstPriorityClaims",
      "o": "@$1",
      "d": 327808,
      "h": 120259412096,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(120259412096),
//--TRIMMABLE-BOUNDARY-START(115964444800),
    {
      "r": 65537,
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "audiences",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        }
      ],
      "n": "AddFirstPriorityClaims",
      "d": 327808,
      "h": 115964444800,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(115964444800),
//--TRIMMABLE-BOUNDARY-START(124554379392),
    {
      "r": 65537,
      "p": [
        {
          "n": "key",
          "p": 1310721
        },
        {
          "n": "objects",
          "p": $.$$.SCG.IEnumerable$$($.$$.S.Object).$h
        },
        {
          "n": "claims",
          "p": $.$$.SCG.List$$($.$ssc.SSC.Claim).$h
        },
        {
          "n": "issuer",
          "p": 1310721
        }
      ],
      "n": "AddListofObjects",
      "d": 327808,
      "h": 124554379392,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(124554379392),
//--TRIMMABLE-BOUNDARY-START(107374510208),
    {
      "r": 65537,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        },
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "jsonElement",
          "p": 2097236
        },
        {
          "n": "claims",
          "p": $.$$.SCG.List$$($.$ssc.SSC.Claim).$h
        }
      ],
      "n": "AddClaimsFromJsonElement",
      "d": 327808,
      "h": 107374510208,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(107374510208),
//--TRIMMABLE-BOUNDARY-START(98784575616),
    {
      "r": 65537,
      "p": [
        {
          "n": "claim",
          "p": 131141
        }
      ],
      "n": "AddClaim",
      "d": 327808,
      "h": 98784575616,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784575616),
//--TRIMMABLE-BOUNDARY-START(103079542912),
    {
      "r": 65537,
      "p": [
        {
          "n": "claims",
          "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h
        }
      ],
      "n": "AddClaims",
      "d": 327808,
      "h": 103079542912,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079542912),
//--TRIMMABLE-BOUNDARY-START(111669477504),
    {
      "r": 65537,
      "p": [
        {
          "n": "claimsCollection",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        }
      ],
      "n": "AddDictionaryClaims",
      "d": 327808,
      "h": 111669477504,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(111669477504),
//--TRIMMABLE-BOUNDARY-START(356482613376),
    {
      "r": 1310721,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 131073
        }
      ],
      "n": "GetClaimValueType",
      "d": 327808,
      "h": 356482613376,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(356482613376),
//--TRIMMABLE-BOUNDARY-START(373662482560),
    {
      "r": 1310721,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        }
      ],
      "n": "GetStandardClaim",
      "d": 327808,
      "h": 373662482560,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(373662482560),
//--TRIMMABLE-BOUNDARY-START(360777580672),
    {
      "r": $.$typeNullable($.$$.S.Int32).$h,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        }
      ],
      "n": "GetIntClaim",
      "d": 327808,
      "h": 360777580672,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(360777580672),
//--TRIMMABLE-BOUNDARY-START(369367515264),
    {
      "r": $.$typeNullable($.$$.S.Int64).$h,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        }
      ],
      "n": "GetLongClaim",
      "d": 327808,
      "h": 369367515264,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(369367515264),
//--TRIMMABLE-BOUNDARY-START(416612155520),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "outVal",
          "p": 655361,
          "f": 4
        }
      ],
      "n": "TryConvertToInt",
      "d": 327808,
      "h": 416612155520,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(416612155520),
//--TRIMMABLE-BOUNDARY-START(420907122816),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 131073
        },
        {
          "n": "outVal",
          "p": 917505,
          "f": 4
        }
      ],
      "n": "TryConvertToLong",
      "d": 327808,
      "h": 420907122816,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(420907122816),
//--TRIMMABLE-BOUNDARY-START(365072547968),
    {
      "r": $.$$.SCG.List$$($.$$.S.String).$h,
      "p": [
        {
          "n": "claimType",
          "p": 1310721
        }
      ],
      "n": "GetListOfClaims",
      "d": 327808,
      "h": 365072547968,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(365072547968),
//--TRIMMABLE-BOUNDARY-START(408022220928),
    {
      "r": 1310721,
      "n": "SerializeToJson",
      "d": 327808,
      "h": 408022220928,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(408022220928),
//--TRIMMABLE-BOUNDARY-START(146029215872),
    {
      "r": 327808,
      "p": [
        {
          "n": "base64UrlEncodedJsonString",
          "p": 1310721
        }
      ],
      "n": "Base64UrlDeserialize",
      "d": 327808,
      "h": 146029215872,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(146029215872),
//--TRIMMABLE-BOUNDARY-START(150324183168),
    {
      "r": 1310721,
      "n": "Base64UrlEncode",
      "d": 327808,
      "h": 150324183168,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(150324183168),
//--TRIMMABLE-BOUNDARY-START(171799019648),
    {
      "r": 327808,
      "p": [
        {
          "n": "jsonString",
          "p": 1310721
        }
      ],
      "n": "Deserialize",
      "d": 327808,
      "h": 171799019648,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(171799019648)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(163209085056),
    {
      "t": 1310721,
      "n": "ClassName",
      "d": 327808,
      "h": 163209085056,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163209085056),
//--TRIMMABLE-BOUNDARY-START(4295295104),
    {
      "t": $.$$.SCG.List$$($.$$.S.String).$h,
      "n": "_audiences",
      "d": 327808,
      "h": 4295295104,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(4295295104),
//--TRIMMABLE-BOUNDARY-START(8590262400),
    {
      "t": 1310721,
      "n": "_azp",
      "d": 327808,
      "h": 8590262400,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(8590262400),
//--TRIMMABLE-BOUNDARY-START(12885229696),
    {
      "t": $.$typeNullable($.$$.S.Int64).$h,
      "n": "_exp",
      "d": 327808,
      "h": 12885229696,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(12885229696),
//--TRIMMABLE-BOUNDARY-START(17180196992),
    {
      "t": $.$typeNullable($.$$.S.DateTime).$h,
      "n": "_expDateTime",
      "d": 327808,
      "h": 17180196992,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(17180196992),
//--TRIMMABLE-BOUNDARY-START(21475164288),
    {
      "t": $.$typeNullable($.$$.S.Int64).$h,
      "n": "_iat",
      "d": 327808,
      "h": 21475164288,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(21475164288),
//--TRIMMABLE-BOUNDARY-START(25770131584),
    {
      "t": $.$typeNullable($.$$.S.DateTime).$h,
      "n": "_iatDateTime",
      "d": 327808,
      "h": 25770131584,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(25770131584),
//--TRIMMABLE-BOUNDARY-START(30065098880),
    {
      "t": 1310721,
      "n": "_id",
      "d": 327808,
      "h": 30065098880,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(30065098880),
//--TRIMMABLE-BOUNDARY-START(34360066176),
    {
      "t": 1310721,
      "n": "_iss",
      "d": 327808,
      "h": 34360066176,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(34360066176),
//--TRIMMABLE-BOUNDARY-START(38655033472),
    {
      "t": 1310721,
      "n": "_jti",
      "d": 327808,
      "h": 38655033472,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(38655033472),
//--TRIMMABLE-BOUNDARY-START(42950000768),
    {
      "t": $.$typeNullable($.$$.S.Int64).$h,
      "n": "_nbf",
      "d": 327808,
      "h": 42950000768,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(42950000768),
//--TRIMMABLE-BOUNDARY-START(47244968064),
    {
      "t": $.$typeNullable($.$$.S.DateTime).$h,
      "n": "_nbfDateTime",
      "d": 327808,
      "h": 47244968064,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(47244968064),
//--TRIMMABLE-BOUNDARY-START(51539935360),
    {
      "t": 1310721,
      "n": "_sub",
      "d": 327808,
      "h": 51539935360,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(51539935360),
//--TRIMMABLE-BOUNDARY-START(55834902656),
    {
      "t": 1310721,
      "n": "_tid",
      "d": 327808,
      "h": 55834902656,
      "f": 4194312
    },
//--TRIMMABLE-BOUNDARY-END(55834902656)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(60129869952),
    {
      "n": ".ctor",
      "o": "$ctor$10",
      "d": 327808,
      "h": 60129869952,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60129869952),
//--TRIMMABLE-BOUNDARY-START(64424837248),
    {
      "p": [
        {
          "n": "claims",
          "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$11",
      "d": 327808,
      "h": 64424837248,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64424837248),
//--TRIMMABLE-BOUNDARY-START(81604706432),
    {
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "claims",
          "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$15",
      "d": 327808,
      "h": 81604706432,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81604706432),
//--TRIMMABLE-BOUNDARY-START(77309739136),
    {
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "claims",
          "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$14",
      "d": 327808,
      "h": 77309739136,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77309739136),
//--TRIMMABLE-BOUNDARY-START(68719804544),
    {
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audiences",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "claims",
          "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h
        },
        {
          "n": "claimsCollection",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$12",
      "d": 327808,
      "h": 68719804544,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68719804544),
//--TRIMMABLE-BOUNDARY-START(85899673728),
    {
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "audiences",
          "p": $.$$.SCG.IList$$($.$$.S.String).$h
        },
        {
          "n": "claims",
          "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h
        },
        {
          "n": "claimsCollection",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$16",
      "d": 327808,
      "h": 85899673728,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(85899673728),
//--TRIMMABLE-BOUNDARY-START(73014771840),
    {
      "p": [
        {
          "n": "issuer",
          "p": 1310721
        },
        {
          "n": "audience",
          "p": 1310721
        },
        {
          "n": "claims",
          "p": $.$$.SCG.IEnumerable$$($.$ssc.SSC.Claim).$h
        },
        {
          "n": "claimsCollection",
          "p": $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object).$h
        },
        {
          "n": "notBefore",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "expires",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        },
        {
          "n": "issuedAt",
          "p": $.$typeNullable($.$$.S.DateTime).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$13",
      "d": 327808,
      "h": 73014771840,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73014771840)
  ],
  "h": 327808
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SCG.IDictionary$$$($.$$.S.String, $.$$.S.Object), $.$$.SCG.ICollection$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$$.SC$1.IDictionary, $.$$.SC$1.ICollection, $.$$.SCG.IReadOnlyDictionary$$$($.$$.S.String, $.$$.S.Object), $.$$.SCG.IReadOnlyCollection$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$$.SCG.IEnumerable$$($.$$.SCG.KeyValuePair$$$($.$$.S.String, $.$$.S.Object)), $.$$.SC$1.IEnumerable, $.$$.SRS.ISerializable, $.$$.SRS.IDeserializationCallback ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.IdentityModel.Tokens.Jwt.JwtPayload`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}IdentityModel${separator}Tokens${separator}Jwt${separator}JwtPayload`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327808)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.IdentityModel.Abstractions", "NetJs.System.Collections", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Collections.Immutable", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.Microsoft.IdentityModel.Logging", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions", "NetJs.Microsoft.Extensions.DependencyInjection.Abstractions", "NetJs.Microsoft.Extensions.DependencyInjection", "NetJs.Microsoft.Extensions.Logging.Abstractions", "NetJs.Microsoft.Extensions.Primitives", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Drawing.Primitives", "NetJs.System.Resources.Writer", "NetJs.System.Runtime.Loader", "NetJs.System.Runtime.Serialization.Formatters", "NetJs.System.Text.RegularExpressions", "NetJs.System.Diagnostics.TraceSource", "NetJs.System.Private.Xml", "NetJs.System.Private.Xml.Linq", "NetJs.System.Xml.XDocument", "NetJs.System.ComponentModel.TypeConverter", "NetJs.System.ComponentModel.Annotations", "NetJs.Microsoft.Extensions.Options", "NetJs.Microsoft.Extensions.Logging", "NetJs.System.IO.Pipelines", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.Json", "NetJs.Microsoft.IdentityModel.Tokens", "NetJs.Microsoft.IdentityModel.JsonWebTokens"));
})();
//--TRIMMABLE-BOUNDARY-END(128)
