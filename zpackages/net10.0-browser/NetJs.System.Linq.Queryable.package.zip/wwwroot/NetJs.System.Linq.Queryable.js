
//--TRIMMABLE-BOUNDARY-START(36)
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $sic, $stt, $sim, $so, $stee, $srm, $sre, $srei, $srel, $srp, $sle) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Linq.Queryable", 
    {
  "h": 36,
  "f": "System.Linq.Queryable",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Linq.Queryable",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Linq.Queryable",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65572)
        $asm.$cls("$slq.System.Linq.EnumerableExecutor", ($self) => class EnumerableExecutor extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295032868)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295032868);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032868)
            
            //--TRIMMABLE-BOUNDARY-START(8590000164)
            static /*EnumerableExecutor */ Create(/*Expression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let execType = $.$slq.System.Linq.EnumerableExecutor$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ expression.Type ], null, null));
                return $.$cast($.$$.System.Activator.CreateInstance$6(execType, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ expression ], null, null)), $.$slq.System.Linq.EnumerableExecutor);
            }
            //--TRIMMABLE-BOUNDARY-END(8590000164)
            
            static $h = 65572;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12884967460),
    {
      "r": 131073,
      "n": "ExecuteBoxed",
      "d": 65572,
      "h": 12884967460,
      "f": 16777480
    },
//--TRIMMABLE-BOUNDARY-END(12884967460),
//--TRIMMABLE-BOUNDARY-START(8590000164),
    {
      "r": 65572,
      "p": [
        {
          "n": "expression",
          "p": 8781861
        }
      ],
      "n": "Create",
      "d": 65572,
      "h": 8590000164,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590000164)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032868),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65572,
      "h": 4295032868,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295032868)
  ],
  "h": 65572
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Linq.EnumerableExecutor`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65572)
        
        
        //--TRIMMABLE-BOUNDARY-START(196644)
        $asm.$cls("$slq.System.Linq.EnumerableQuery", ($self) => class EnumerableQuery extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295163940)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295163940);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163940)
            
            //--TRIMMABLE-BOUNDARY-START(8590131236)
            static /*IQueryable */ Create(/*Type*/ elementType, /*IEnumerable*/ sequence)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let seqType = $.$slq.System.Linq.EnumerableQuery$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ elementType ], null, null));
                return $.$cast($.$$.System.Activator.CreateInstance$6(seqType, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ sequence ], null, null)), $.$sle.System.Linq.IQueryable);
            }
            //--TRIMMABLE-BOUNDARY-END(8590131236)
            
            //--TRIMMABLE-BOUNDARY-START(12885098532)
            static /*IQueryable */ Create$1(/*Type*/ elementType, /*Expression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let seqType = $.$slq.System.Linq.EnumerableQuery$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ elementType ], null, null));
                return $.$cast($.$$.System.Activator.CreateInstance$6(seqType, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ expression ], null, null)), $.$sle.System.Linq.IQueryable);
            }
            //--TRIMMABLE-BOUNDARY-END(12885098532)
            
            static $h = 196644;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475033124),
    {
      "p": 8781861,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654902308,
        "f": 50331912
      },
      "n": "Expression",
      "d": 196644,
      "h": 21475033124,
      "f": 2097416
    },
//--TRIMMABLE-BOUNDARY-END(21475033124),
//--TRIMMABLE-BOUNDARY-START(17180065828),
    {
      "p": 62652417,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064967716,
        "f": 50331912
      },
      "n": "Enumerable",
      "d": 196644,
      "h": 17180065828,
      "f": 2097416
    },
//--TRIMMABLE-BOUNDARY-END(17180065828)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590131236),
    {
      "r": 42467365,
      "p": [
        {
          "n": "elementType",
          "p": 187760641
        },
        {
          "n": "sequence",
          "p": 62652417
        }
      ],
      "n": "Create",
      "d": 196644,
      "h": 8590131236,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590131236),
//--TRIMMABLE-BOUNDARY-START(12885098532),
    {
      "r": 42467365,
      "p": [
        {
          "n": "elementType",
          "p": 187760641
        },
        {
          "n": "expression",
          "p": 8781861
        }
      ],
      "n": "Create",
      "o": "@$1",
      "d": 196644,
      "h": 12885098532,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885098532)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163940),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196644,
      "h": 4295163940,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295163940)
  ],
  "h": 196644
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Linq.EnumerableQuery`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196644)
        
        
        //--TRIMMABLE-BOUNDARY-START(655396)
        $asm.$cls("$slq.System.Obsoletions", ($self) => class Obsoletions
        {
            //--TRIMMABLE-BOUNDARY-START(382252744740)
            /*string*/ static SharedUrlFormat = null;
            //--TRIMMABLE-BOUNDARY-END(382252744740)
            
            //--TRIMMABLE-BOUNDARY-START(433792352292)
            /*string*/ static SystemTextEncodingUTF7Message = null;
            //--TRIMMABLE-BOUNDARY-END(433792352292)
            
            //--TRIMMABLE-BOUNDARY-START(429497384996)
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(429497384996)
            
            //--TRIMMABLE-BOUNDARY-START(266288627748)
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(266288627748)
            
            //--TRIMMABLE-BOUNDARY-START(261993660452)
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(261993660452)
            
            //--TRIMMABLE-BOUNDARY-START(77310066724)
            /*string*/ static CodeAccessSecurityMessage = null;
            //--TRIMMABLE-BOUNDARY-END(77310066724)
            
            //--TRIMMABLE-BOUNDARY-START(73015099428)
            /*string*/ static CodeAccessSecurityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(73015099428)
            
            //--TRIMMABLE-BOUNDARY-START(94489935908)
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            //--TRIMMABLE-BOUNDARY-END(94489935908)
            
            //--TRIMMABLE-BOUNDARY-START(90194968612)
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(90194968612)
            
            //--TRIMMABLE-BOUNDARY-START(214749020196)
            /*string*/ static GlobalAssemblyCacheMessage = null;
            //--TRIMMABLE-BOUNDARY-END(214749020196)
            
            //--TRIMMABLE-BOUNDARY-START(210454052900)
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(210454052900)
            
            //--TRIMMABLE-BOUNDARY-START(442382286884)
            /*string*/ static ThreadAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(442382286884)
            
            //--TRIMMABLE-BOUNDARY-START(446677254180)
            /*string*/ static ThreadResetAbortMessage = null;
            //--TRIMMABLE-BOUNDARY-END(446677254180)
            
            //--TRIMMABLE-BOUNDARY-START(438087319588)
            /*string*/ static ThreadAbortDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(438087319588)
            
            //--TRIMMABLE-BOUNDARY-START(146029543460)
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(146029543460)
            
            //--TRIMMABLE-BOUNDARY-START(141734576164)
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(141734576164)
            
            //--TRIMMABLE-BOUNDARY-START(120259739684)
            /*string*/ static CreatePdbGeneratorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(120259739684)
            
            //--TRIMMABLE-BOUNDARY-START(115964772388)
            /*string*/ static CreatePdbGeneratorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(115964772388)
            
            //--TRIMMABLE-BOUNDARY-START(51540262948)
            /*string*/ static AuthenticationManagerMessage = null;
            //--TRIMMABLE-BOUNDARY-END(51540262948)
            
            //--TRIMMABLE-BOUNDARY-START(47245295652)
            /*string*/ static AuthenticationManagerDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(47245295652)
            
            //--TRIMMABLE-BOUNDARY-START(326418169892)
            /*string*/ static RemotingApisMessage = null;
            //--TRIMMABLE-BOUNDARY-END(326418169892)
            
            //--TRIMMABLE-BOUNDARY-START(322123202596)
            /*string*/ static RemotingApisDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(322123202596)
            
            //--TRIMMABLE-BOUNDARY-START(60130197540)
            /*string*/ static BinaryFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(60130197540)
            
            //--TRIMMABLE-BOUNDARY-START(55835230244)
            /*string*/ static BinaryFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(55835230244)
            
            //--TRIMMABLE-BOUNDARY-START(85900001316)
            /*string*/ static CodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85900001316)
            
            //--TRIMMABLE-BOUNDARY-START(81605034020)
            /*string*/ static CodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(81605034020)
            
            //--TRIMMABLE-BOUNDARY-START(197569151012)
            /*string*/ static EscapeUriStringMessage = null;
            //--TRIMMABLE-BOUNDARY-END(197569151012)
            
            //--TRIMMABLE-BOUNDARY-START(193274183716)
            /*string*/ static EscapeUriStringDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(193274183716)
            
            //--TRIMMABLE-BOUNDARY-START(489626927140)
            /*string*/ static WebRequestMessage = null;
            //--TRIMMABLE-BOUNDARY-END(489626927140)
            
            //--TRIMMABLE-BOUNDARY-START(485331959844)
            /*string*/ static WebRequestDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(485331959844)
            
            //--TRIMMABLE-BOUNDARY-START(163209412644)
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(163209412644)
            
            //--TRIMMABLE-BOUNDARY-START(158914445348)
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(158914445348)
            
            //--TRIMMABLE-BOUNDARY-START(206159085604)
            /*string*/ static GetContextInfoMessage = null;
            //--TRIMMABLE-BOUNDARY-END(206159085604)
            
            //--TRIMMABLE-BOUNDARY-START(201864118308)
            /*string*/ static GetContextInfoDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(201864118308)
            
            //--TRIMMABLE-BOUNDARY-START(399432613924)
            /*string*/ static StrongNameKeyPairMessage = null;
            //--TRIMMABLE-BOUNDARY-END(399432613924)
            
            //--TRIMMABLE-BOUNDARY-START(395137646628)
            /*string*/ static StrongNameKeyPairDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(395137646628)
            
            //--TRIMMABLE-BOUNDARY-START(300648366116)
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            //--TRIMMABLE-BOUNDARY-END(300648366116)
            
            //--TRIMMABLE-BOUNDARY-START(296353398820)
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(296353398820)
            
            //--TRIMMABLE-BOUNDARY-START(377957777444)
            /*string*/ static RuntimeEnvironmentMessage = null;
            //--TRIMMABLE-BOUNDARY-END(377957777444)
            
            //--TRIMMABLE-BOUNDARY-START(373662810148)
            /*string*/ static RuntimeEnvironmentDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(373662810148)
            
            //--TRIMMABLE-BOUNDARY-START(231928889380)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(231928889380)
            
            //--TRIMMABLE-BOUNDARY-START(227633922084)
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(227633922084)
            
            //--TRIMMABLE-BOUNDARY-START(154619478052)
            /*string*/ static DerivedCryptographicTypesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(154619478052)
            
            //--TRIMMABLE-BOUNDARY-START(150324510756)
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(150324510756)
            
            //--TRIMMABLE-BOUNDARY-START(352187973668)
            /*string*/ static RijndaelMessage = null;
            //--TRIMMABLE-BOUNDARY-END(352187973668)
            
            //--TRIMMABLE-BOUNDARY-START(347893006372)
            /*string*/ static RijndaelDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(347893006372)
            
            //--TRIMMABLE-BOUNDARY-START(360777908260)
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            //--TRIMMABLE-BOUNDARY-END(360777908260)
            
            //--TRIMMABLE-BOUNDARY-START(356482940964)
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(356482940964)
            
            //--TRIMMABLE-BOUNDARY-START(17180524580)
            /*string*/ static AppDomainCreateUnloadMessage = null;
            //--TRIMMABLE-BOUNDARY-END(17180524580)
            
            //--TRIMMABLE-BOUNDARY-START(12885557284)
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(12885557284)
            
            //--TRIMMABLE-BOUNDARY-START(408022548516)
            /*string*/ static SuppressIldasmAttributeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(408022548516)
            
            //--TRIMMABLE-BOUNDARY-START(403727581220)
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(403727581220)
            
            //--TRIMMABLE-BOUNDARY-START(498216861732)
            /*string*/ static X509CertificateImmutableMessage = null;
            //--TRIMMABLE-BOUNDARY-END(498216861732)
            
            //--TRIMMABLE-BOUNDARY-START(493921894436)
            /*string*/ static X509CertificateImmutableDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(493921894436)
            
            //--TRIMMABLE-BOUNDARY-START(283468496932)
            /*string*/ static PublicKeyPropertyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(283468496932)
            
            //--TRIMMABLE-BOUNDARY-START(279173529636)
            /*string*/ static PublicKeyPropertyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(279173529636)
            
            //--TRIMMABLE-BOUNDARY-START(506806796324)
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(506806796324)
            
            //--TRIMMABLE-BOUNDARY-START(502511829028)
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(502511829028)
            
            //--TRIMMABLE-BOUNDARY-START(274878562340)
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            //--TRIMMABLE-BOUNDARY-END(274878562340)
            
            //--TRIMMABLE-BOUNDARY-START(270583595044)
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(270583595044)
            
            //--TRIMMABLE-BOUNDARY-START(481036992548)
            /*string*/ static UseManagedSha1Message = null;
            //--TRIMMABLE-BOUNDARY-END(481036992548)
            
            //--TRIMMABLE-BOUNDARY-START(476742025252)
            /*string*/ static UseManagedSha1DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(476742025252)
            
            //--TRIMMABLE-BOUNDARY-START(128849674276)
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            //--TRIMMABLE-BOUNDARY-END(128849674276)
            
            //--TRIMMABLE-BOUNDARY-START(124554706980)
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(124554706980)
            
            //--TRIMMABLE-BOUNDARY-START(111669805092)
            /*string*/ static CorruptedStateRecoveryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(111669805092)
            
            //--TRIMMABLE-BOUNDARY-START(107374837796)
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(107374837796)
            
            //--TRIMMABLE-BOUNDARY-START(335008104484)
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(335008104484)
            
            //--TRIMMABLE-BOUNDARY-START(330713137188)
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(330713137188)
            
            //--TRIMMABLE-BOUNDARY-START(68720132132)
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(68720132132)
            
            //--TRIMMABLE-BOUNDARY-START(64425164836)
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(64425164836)
            
            //--TRIMMABLE-BOUNDARY-START(390842679332)
            /*string*/ static SignerInfoCounterSigMessage = null;
            //--TRIMMABLE-BOUNDARY-END(390842679332)
            
            //--TRIMMABLE-BOUNDARY-START(386547712036)
            /*string*/ static SignerInfoCounterSigDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(386547712036)
            
            //--TRIMMABLE-BOUNDARY-START(309238300708)
            /*string*/ static RegexCompileToAssemblyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(309238300708)
            
            //--TRIMMABLE-BOUNDARY-START(304943333412)
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(304943333412)
            
            //--TRIMMABLE-BOUNDARY-START(42950328356)
            /*string*/ static AssemblyNameMembersMessage = null;
            //--TRIMMABLE-BOUNDARY-END(42950328356)
            
            //--TRIMMABLE-BOUNDARY-START(38655361060)
            /*string*/ static AssemblyNameMembersDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(38655361060)
            
            //--TRIMMABLE-BOUNDARY-START(416612483108)
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(416612483108)
            
            //--TRIMMABLE-BOUNDARY-START(412317515812)
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(412317515812)
            
            //--TRIMMABLE-BOUNDARY-START(472447057956)
            /*string*/ static TlsVersion10and11Message = null;
            //--TRIMMABLE-BOUNDARY-END(472447057956)
            
            //--TRIMMABLE-BOUNDARY-START(468152090660)
            /*string*/ static TlsVersion10and11DiagId = null;
            //--TRIMMABLE-BOUNDARY-END(468152090660)
            
            //--TRIMMABLE-BOUNDARY-START(188979216420)
            /*string*/ static EncryptionPolicyMessage = null;
            //--TRIMMABLE-BOUNDARY-END(188979216420)
            
            //--TRIMMABLE-BOUNDARY-START(184684249124)
            /*string*/ static EncryptionPolicyDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(184684249124)
            
            //--TRIMMABLE-BOUNDARY-START(171799347236)
            /*string*/ static EccXmlExportImportMessage = null;
            //--TRIMMABLE-BOUNDARY-END(171799347236)
            
            //--TRIMMABLE-BOUNDARY-START(167504379940)
            /*string*/ static EccXmlExportImportDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(167504379940)
            
            //--TRIMMABLE-BOUNDARY-START(180389281828)
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            //--TRIMMABLE-BOUNDARY-END(180389281828)
            
            //--TRIMMABLE-BOUNDARY-START(176094314532)
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(176094314532)
            
            //--TRIMMABLE-BOUNDARY-START(34360393764)
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            //--TRIMMABLE-BOUNDARY-END(34360393764)
            
            //--TRIMMABLE-BOUNDARY-START(30065426468)
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(30065426468)
            
            //--TRIMMABLE-BOUNDARY-START(137439608868)
            /*string*/ static CryptoStringFactoryMessage = null;
            //--TRIMMABLE-BOUNDARY-END(137439608868)
            
            //--TRIMMABLE-BOUNDARY-START(133144641572)
            /*string*/ static CryptoStringFactoryDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(133144641572)
            
            //--TRIMMABLE-BOUNDARY-START(103079870500)
            /*string*/ static ControlledExecutionRunMessage = null;
            //--TRIMMABLE-BOUNDARY-END(103079870500)
            
            //--TRIMMABLE-BOUNDARY-START(98784903204)
            /*string*/ static ControlledExecutionRunDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(98784903204)
            
            //--TRIMMABLE-BOUNDARY-START(523986665508)
            /*string*/ static XmlSecureResolverMessage = null;
            //--TRIMMABLE-BOUNDARY-END(523986665508)
            
            //--TRIMMABLE-BOUNDARY-START(519691698212)
            /*string*/ static XmlSecureResolverDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(519691698212)
            
            //--TRIMMABLE-BOUNDARY-START(369367842852)
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            //--TRIMMABLE-BOUNDARY-END(369367842852)
            
            //--TRIMMABLE-BOUNDARY-START(365072875556)
            /*string*/ static RsaEncryptDecryptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(365072875556)
            
            //--TRIMMABLE-BOUNDARY-START(223338954788)
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            //--TRIMMABLE-BOUNDARY-END(223338954788)
            
            //--TRIMMABLE-BOUNDARY-START(219043987492)
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(219043987492)
            
            //--TRIMMABLE-BOUNDARY-START(249108758564)
            /*string*/ static LegacyFormatterMessage = null;
            //--TRIMMABLE-BOUNDARY-END(249108758564)
            
            //--TRIMMABLE-BOUNDARY-START(236223856676)
            /*string*/ static LegacyFormatterDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(236223856676)
            
            //--TRIMMABLE-BOUNDARY-START(244813791268)
            /*string*/ static LegacyFormatterImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(244813791268)
            
            //--TRIMMABLE-BOUNDARY-START(240518823972)
            /*string*/ static LegacyFormatterImplDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(240518823972)
            
            //--TRIMMABLE-BOUNDARY-START(317828235300)
            /*string*/ static RegexExtensibilityImplMessage = null;
            //--TRIMMABLE-BOUNDARY-END(317828235300)
            
            //--TRIMMABLE-BOUNDARY-START(313533268004)
            /*string*/ static RegexExtensibilityDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(313533268004)
            
            //--TRIMMABLE-BOUNDARY-START(8590589988)
            /*string*/ static AesGcmTagConstructorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(8590589988)
            
            //--TRIMMABLE-BOUNDARY-START(4295622692)
            /*string*/ static AesGcmTagConstructorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(4295622692)
            
            //--TRIMMABLE-BOUNDARY-START(455267188772)
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(455267188772)
            
            //--TRIMMABLE-BOUNDARY-START(450972221476)
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(450972221476)
            
            //--TRIMMABLE-BOUNDARY-START(25770459172)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            //--TRIMMABLE-BOUNDARY-END(25770459172)
            
            //--TRIMMABLE-BOUNDARY-START(21475491876)
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(21475491876)
            
            //--TRIMMABLE-BOUNDARY-START(257698693156)
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            //--TRIMMABLE-BOUNDARY-END(257698693156)
            
            //--TRIMMABLE-BOUNDARY-START(253403725860)
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(253403725860)
            
            //--TRIMMABLE-BOUNDARY-START(515396730916)
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(515396730916)
            
            //--TRIMMABLE-BOUNDARY-START(511101763620)
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(511101763620)
            
            //--TRIMMABLE-BOUNDARY-START(463857123364)
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            //--TRIMMABLE-BOUNDARY-END(463857123364)
            
            //--TRIMMABLE-BOUNDARY-START(459562156068)
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(459562156068)
            
            //--TRIMMABLE-BOUNDARY-START(425202417700)
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            //--TRIMMABLE-BOUNDARY-END(425202417700)
            
            //--TRIMMABLE-BOUNDARY-START(420907450404)
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(420907450404)
            
            //--TRIMMABLE-BOUNDARY-START(343598039076)
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            //--TRIMMABLE-BOUNDARY-END(343598039076)
            
            //--TRIMMABLE-BOUNDARY-START(339303071780)
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(339303071780)
            
            //--TRIMMABLE-BOUNDARY-START(292058431524)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            //--TRIMMABLE-BOUNDARY-END(292058431524)
            
            //--TRIMMABLE-BOUNDARY-START(287763464228)
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(287763464228)
            
            //--TRIMMABLE-BOUNDARY-START(532576600100)
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            //--TRIMMABLE-BOUNDARY-END(532576600100)
            
            //--TRIMMABLE-BOUNDARY-START(528281632804)
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //--TRIMMABLE-BOUNDARY-END(528281632804)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(382252744740)
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                    //--TRIMMABLE-BOUNDARY-END(382252744740)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(433792352292)
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                    //--TRIMMABLE-BOUNDARY-END(433792352292)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(429497384996)
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                    //--TRIMMABLE-BOUNDARY-END(429497384996)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(266288627748)
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                    //--TRIMMABLE-BOUNDARY-END(266288627748)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993660452)
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                    //--TRIMMABLE-BOUNDARY-END(261993660452)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(77310066724)
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                    //--TRIMMABLE-BOUNDARY-END(77310066724)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(73015099428)
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                    //--TRIMMABLE-BOUNDARY-END(73015099428)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(94489935908)
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(94489935908)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(90194968612)
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                    //--TRIMMABLE-BOUNDARY-END(90194968612)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(214749020196)
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(214749020196)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(210454052900)
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                    //--TRIMMABLE-BOUNDARY-END(210454052900)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(442382286884)
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(442382286884)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(446677254180)
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(446677254180)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(438087319588)
                    this.ThreadAbortDiagId = "SYSLIB0006";
                    //--TRIMMABLE-BOUNDARY-END(438087319588)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(146029543460)
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(146029543460)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(141734576164)
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                    //--TRIMMABLE-BOUNDARY-END(141734576164)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(120259739684)
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(120259739684)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(115964772388)
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                    //--TRIMMABLE-BOUNDARY-END(115964772388)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540262948)
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(51540262948)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(47245295652)
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                    //--TRIMMABLE-BOUNDARY-END(47245295652)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(326418169892)
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(326418169892)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(322123202596)
                    this.RemotingApisDiagId = "SYSLIB0010";
                    //--TRIMMABLE-BOUNDARY-END(322123202596)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(60130197540)
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                    //--TRIMMABLE-BOUNDARY-END(60130197540)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835230244)
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                    //--TRIMMABLE-BOUNDARY-END(55835230244)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85900001316)
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                    //--TRIMMABLE-BOUNDARY-END(85900001316)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(81605034020)
                    this.CodeBaseDiagId = "SYSLIB0012";
                    //--TRIMMABLE-BOUNDARY-END(81605034020)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(197569151012)
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                    //--TRIMMABLE-BOUNDARY-END(197569151012)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(193274183716)
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                    //--TRIMMABLE-BOUNDARY-END(193274183716)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(489626927140)
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                    //--TRIMMABLE-BOUNDARY-END(489626927140)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(485331959844)
                    this.WebRequestDiagId = "SYSLIB0014";
                    //--TRIMMABLE-BOUNDARY-END(485331959844)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(163209412644)
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(163209412644)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(158914445348)
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                    //--TRIMMABLE-BOUNDARY-END(158914445348)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(206159085604)
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                    //--TRIMMABLE-BOUNDARY-END(206159085604)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(201864118308)
                    this.GetContextInfoDiagId = "SYSLIB0016";
                    //--TRIMMABLE-BOUNDARY-END(201864118308)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(399432613924)
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(399432613924)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(395137646628)
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                    //--TRIMMABLE-BOUNDARY-END(395137646628)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(300648366116)
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(300648366116)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(296353398820)
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                    //--TRIMMABLE-BOUNDARY-END(296353398820)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(377957777444)
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                    //--TRIMMABLE-BOUNDARY-END(377957777444)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(373662810148)
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                    //--TRIMMABLE-BOUNDARY-END(373662810148)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(231928889380)
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                    //--TRIMMABLE-BOUNDARY-END(231928889380)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(227633922084)
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                    //--TRIMMABLE-BOUNDARY-END(227633922084)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(154619478052)
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                    //--TRIMMABLE-BOUNDARY-END(154619478052)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(150324510756)
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                    //--TRIMMABLE-BOUNDARY-END(150324510756)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(352187973668)
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                    //--TRIMMABLE-BOUNDARY-END(352187973668)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(347893006372)
                    this.RijndaelDiagId = "SYSLIB0022";
                    //--TRIMMABLE-BOUNDARY-END(347893006372)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(360777908260)
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                    //--TRIMMABLE-BOUNDARY-END(360777908260)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(356482940964)
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                    //--TRIMMABLE-BOUNDARY-END(356482940964)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(17180524580)
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                    //--TRIMMABLE-BOUNDARY-END(17180524580)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(12885557284)
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                    //--TRIMMABLE-BOUNDARY-END(12885557284)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(408022548516)
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                    //--TRIMMABLE-BOUNDARY-END(408022548516)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(403727581220)
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                    //--TRIMMABLE-BOUNDARY-END(403727581220)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(498216861732)
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                    //--TRIMMABLE-BOUNDARY-END(498216861732)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(493921894436)
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                    //--TRIMMABLE-BOUNDARY-END(493921894436)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(283468496932)
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                    //--TRIMMABLE-BOUNDARY-END(283468496932)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(279173529636)
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                    //--TRIMMABLE-BOUNDARY-END(279173529636)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(506806796324)
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                    //--TRIMMABLE-BOUNDARY-END(506806796324)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(502511829028)
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                    //--TRIMMABLE-BOUNDARY-END(502511829028)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(274878562340)
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(274878562340)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(270583595044)
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                    //--TRIMMABLE-BOUNDARY-END(270583595044)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(481036992548)
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                    //--TRIMMABLE-BOUNDARY-END(481036992548)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(476742025252)
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                    //--TRIMMABLE-BOUNDARY-END(476742025252)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(128849674276)
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                    //--TRIMMABLE-BOUNDARY-END(128849674276)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(124554706980)
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                    //--TRIMMABLE-BOUNDARY-END(124554706980)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(111669805092)
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                    //--TRIMMABLE-BOUNDARY-END(111669805092)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(107374837796)
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                    //--TRIMMABLE-BOUNDARY-END(107374837796)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(335008104484)
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                    //--TRIMMABLE-BOUNDARY-END(335008104484)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(330713137188)
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                    //--TRIMMABLE-BOUNDARY-END(330713137188)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(68720132132)
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                    //--TRIMMABLE-BOUNDARY-END(68720132132)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(64425164836)
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                    //--TRIMMABLE-BOUNDARY-END(64425164836)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(390842679332)
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                    //--TRIMMABLE-BOUNDARY-END(390842679332)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(386547712036)
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                    //--TRIMMABLE-BOUNDARY-END(386547712036)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309238300708)
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                    //--TRIMMABLE-BOUNDARY-END(309238300708)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(304943333412)
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                    //--TRIMMABLE-BOUNDARY-END(304943333412)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(42950328356)
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                    //--TRIMMABLE-BOUNDARY-END(42950328356)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(38655361060)
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                    //--TRIMMABLE-BOUNDARY-END(38655361060)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(416612483108)
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                    //--TRIMMABLE-BOUNDARY-END(416612483108)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(412317515812)
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                    //--TRIMMABLE-BOUNDARY-END(412317515812)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(472447057956)
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                    //--TRIMMABLE-BOUNDARY-END(472447057956)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(468152090660)
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                    //--TRIMMABLE-BOUNDARY-END(468152090660)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(188979216420)
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(188979216420)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(184684249124)
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                    //--TRIMMABLE-BOUNDARY-END(184684249124)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(171799347236)
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                    //--TRIMMABLE-BOUNDARY-END(171799347236)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(167504379940)
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                    //--TRIMMABLE-BOUNDARY-END(167504379940)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(180389281828)
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                    //--TRIMMABLE-BOUNDARY-END(180389281828)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(176094314532)
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                    //--TRIMMABLE-BOUNDARY-END(176094314532)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(34360393764)
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(34360393764)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(30065426468)
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                    //--TRIMMABLE-BOUNDARY-END(30065426468)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(137439608868)
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                    //--TRIMMABLE-BOUNDARY-END(137439608868)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(133144641572)
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                    //--TRIMMABLE-BOUNDARY-END(133144641572)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(103079870500)
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                    //--TRIMMABLE-BOUNDARY-END(103079870500)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(98784903204)
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                    //--TRIMMABLE-BOUNDARY-END(98784903204)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(523986665508)
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                    //--TRIMMABLE-BOUNDARY-END(523986665508)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(519691698212)
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                    //--TRIMMABLE-BOUNDARY-END(519691698212)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(369367842852)
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                    //--TRIMMABLE-BOUNDARY-END(369367842852)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(365072875556)
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                    //--TRIMMABLE-BOUNDARY-END(365072875556)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(223338954788)
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                    //--TRIMMABLE-BOUNDARY-END(223338954788)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(219043987492)
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                    //--TRIMMABLE-BOUNDARY-END(219043987492)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(249108758564)
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                    //--TRIMMABLE-BOUNDARY-END(249108758564)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(236223856676)
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                    //--TRIMMABLE-BOUNDARY-END(236223856676)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(244813791268)
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                    //--TRIMMABLE-BOUNDARY-END(244813791268)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(240518823972)
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                    //--TRIMMABLE-BOUNDARY-END(240518823972)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(317828235300)
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                    //--TRIMMABLE-BOUNDARY-END(317828235300)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(313533268004)
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                    //--TRIMMABLE-BOUNDARY-END(313533268004)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(8590589988)
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                    //--TRIMMABLE-BOUNDARY-END(8590589988)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(4295622692)
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                    //--TRIMMABLE-BOUNDARY-END(4295622692)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(455267188772)
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                    //--TRIMMABLE-BOUNDARY-END(455267188772)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(450972221476)
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                    //--TRIMMABLE-BOUNDARY-END(450972221476)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(25770459172)
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                    //--TRIMMABLE-BOUNDARY-END(25770459172)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(21475491876)
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                    //--TRIMMABLE-BOUNDARY-END(21475491876)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(257698693156)
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                    //--TRIMMABLE-BOUNDARY-END(257698693156)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(253403725860)
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                    //--TRIMMABLE-BOUNDARY-END(253403725860)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(515396730916)
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                    //--TRIMMABLE-BOUNDARY-END(515396730916)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(511101763620)
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                    //--TRIMMABLE-BOUNDARY-END(511101763620)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(463857123364)
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                    //--TRIMMABLE-BOUNDARY-END(463857123364)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(459562156068)
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                    //--TRIMMABLE-BOUNDARY-END(459562156068)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(425202417700)
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                    //--TRIMMABLE-BOUNDARY-END(425202417700)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(420907450404)
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                    //--TRIMMABLE-BOUNDARY-END(420907450404)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(343598039076)
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                    //--TRIMMABLE-BOUNDARY-END(343598039076)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(339303071780)
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                    //--TRIMMABLE-BOUNDARY-END(339303071780)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(292058431524)
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                    //--TRIMMABLE-BOUNDARY-END(292058431524)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(287763464228)
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                    //--TRIMMABLE-BOUNDARY-END(287763464228)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(532576600100)
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                    //--TRIMMABLE-BOUNDARY-END(532576600100)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(528281632804)
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                    //--TRIMMABLE-BOUNDARY-END(528281632804)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 655396;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "l": [
//--TRIMMABLE-BOUNDARY-START(382252744740),
    {
      "t": 1310721,
      "n": "SharedUrlFormat",
      "d": 655396,
      "h": 382252744740,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(382252744740),
//--TRIMMABLE-BOUNDARY-START(433792352292),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7Message",
      "d": 655396,
      "h": 433792352292,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(433792352292),
//--TRIMMABLE-BOUNDARY-START(429497384996),
    {
      "t": 1310721,
      "n": "SystemTextEncodingUTF7DiagId",
      "d": 655396,
      "h": 429497384996,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(429497384996),
//--TRIMMABLE-BOUNDARY-START(266288627748),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeMessage",
      "d": 655396,
      "h": 266288627748,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(266288627748),
//--TRIMMABLE-BOUNDARY-START(261993660452),
    {
      "t": 1310721,
      "n": "PrincipalPermissionAttributeDiagId",
      "d": 655396,
      "h": 261993660452,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(261993660452),
//--TRIMMABLE-BOUNDARY-START(77310066724),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityMessage",
      "d": 655396,
      "h": 77310066724,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(77310066724),
//--TRIMMABLE-BOUNDARY-START(73015099428),
    {
      "t": 1310721,
      "n": "CodeAccessSecurityDiagId",
      "d": 655396,
      "h": 73015099428,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(73015099428),
//--TRIMMABLE-BOUNDARY-START(94489935908),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionMessage",
      "d": 655396,
      "h": 94489935908,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(94489935908),
//--TRIMMABLE-BOUNDARY-START(90194968612),
    {
      "t": 1310721,
      "n": "ConstrainedExecutionRegionDiagId",
      "d": 655396,
      "h": 90194968612,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90194968612),
//--TRIMMABLE-BOUNDARY-START(214749020196),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheMessage",
      "d": 655396,
      "h": 214749020196,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(214749020196),
//--TRIMMABLE-BOUNDARY-START(210454052900),
    {
      "t": 1310721,
      "n": "GlobalAssemblyCacheDiagId",
      "d": 655396,
      "h": 210454052900,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(210454052900),
//--TRIMMABLE-BOUNDARY-START(442382286884),
    {
      "t": 1310721,
      "n": "ThreadAbortMessage",
      "d": 655396,
      "h": 442382286884,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(442382286884),
//--TRIMMABLE-BOUNDARY-START(446677254180),
    {
      "t": 1310721,
      "n": "ThreadResetAbortMessage",
      "d": 655396,
      "h": 446677254180,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(446677254180),
//--TRIMMABLE-BOUNDARY-START(438087319588),
    {
      "t": 1310721,
      "n": "ThreadAbortDiagId",
      "d": 655396,
      "h": 438087319588,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(438087319588),
//--TRIMMABLE-BOUNDARY-START(146029543460),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsMessage",
      "d": 655396,
      "h": 146029543460,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(146029543460),
//--TRIMMABLE-BOUNDARY-START(141734576164),
    {
      "t": 1310721,
      "n": "DefaultCryptoAlgorithmsDiagId",
      "d": 655396,
      "h": 141734576164,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(141734576164),
//--TRIMMABLE-BOUNDARY-START(120259739684),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorMessage",
      "d": 655396,
      "h": 120259739684,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(120259739684),
//--TRIMMABLE-BOUNDARY-START(115964772388),
    {
      "t": 1310721,
      "n": "CreatePdbGeneratorDiagId",
      "d": 655396,
      "h": 115964772388,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(115964772388),
//--TRIMMABLE-BOUNDARY-START(51540262948),
    {
      "t": 1310721,
      "n": "AuthenticationManagerMessage",
      "d": 655396,
      "h": 51540262948,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(51540262948),
//--TRIMMABLE-BOUNDARY-START(47245295652),
    {
      "t": 1310721,
      "n": "AuthenticationManagerDiagId",
      "d": 655396,
      "h": 47245295652,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(47245295652),
//--TRIMMABLE-BOUNDARY-START(326418169892),
    {
      "t": 1310721,
      "n": "RemotingApisMessage",
      "d": 655396,
      "h": 326418169892,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(326418169892),
//--TRIMMABLE-BOUNDARY-START(322123202596),
    {
      "t": 1310721,
      "n": "RemotingApisDiagId",
      "d": 655396,
      "h": 322123202596,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(322123202596),
//--TRIMMABLE-BOUNDARY-START(60130197540),
    {
      "t": 1310721,
      "n": "BinaryFormatterMessage",
      "d": 655396,
      "h": 60130197540,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(60130197540),
//--TRIMMABLE-BOUNDARY-START(55835230244),
    {
      "t": 1310721,
      "n": "BinaryFormatterDiagId",
      "d": 655396,
      "h": 55835230244,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(55835230244),
//--TRIMMABLE-BOUNDARY-START(85900001316),
    {
      "t": 1310721,
      "n": "CodeBaseMessage",
      "d": 655396,
      "h": 85900001316,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85900001316),
//--TRIMMABLE-BOUNDARY-START(81605034020),
    {
      "t": 1310721,
      "n": "CodeBaseDiagId",
      "d": 655396,
      "h": 81605034020,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(81605034020),
//--TRIMMABLE-BOUNDARY-START(197569151012),
    {
      "t": 1310721,
      "n": "EscapeUriStringMessage",
      "d": 655396,
      "h": 197569151012,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(197569151012),
//--TRIMMABLE-BOUNDARY-START(193274183716),
    {
      "t": 1310721,
      "n": "EscapeUriStringDiagId",
      "d": 655396,
      "h": 193274183716,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(193274183716),
//--TRIMMABLE-BOUNDARY-START(489626927140),
    {
      "t": 1310721,
      "n": "WebRequestMessage",
      "d": 655396,
      "h": 489626927140,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(489626927140),
//--TRIMMABLE-BOUNDARY-START(485331959844),
    {
      "t": 1310721,
      "n": "WebRequestDiagId",
      "d": 655396,
      "h": 485331959844,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(485331959844),
//--TRIMMABLE-BOUNDARY-START(163209412644),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeMessage",
      "d": 655396,
      "h": 163209412644,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(163209412644),
//--TRIMMABLE-BOUNDARY-START(158914445348),
    {
      "t": 1310721,
      "n": "DisablePrivateReflectionAttributeDiagId",
      "d": 655396,
      "h": 158914445348,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(158914445348),
//--TRIMMABLE-BOUNDARY-START(206159085604),
    {
      "t": 1310721,
      "n": "GetContextInfoMessage",
      "d": 655396,
      "h": 206159085604,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(206159085604),
//--TRIMMABLE-BOUNDARY-START(201864118308),
    {
      "t": 1310721,
      "n": "GetContextInfoDiagId",
      "d": 655396,
      "h": 201864118308,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(201864118308),
//--TRIMMABLE-BOUNDARY-START(399432613924),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairMessage",
      "d": 655396,
      "h": 399432613924,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(399432613924),
//--TRIMMABLE-BOUNDARY-START(395137646628),
    {
      "t": 1310721,
      "n": "StrongNameKeyPairDiagId",
      "d": 655396,
      "h": 395137646628,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(395137646628),
//--TRIMMABLE-BOUNDARY-START(300648366116),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingMessage",
      "d": 655396,
      "h": 300648366116,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(300648366116),
//--TRIMMABLE-BOUNDARY-START(296353398820),
    {
      "t": 1310721,
      "n": "ReflectionOnlyLoadingDiagId",
      "d": 655396,
      "h": 296353398820,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(296353398820),
//--TRIMMABLE-BOUNDARY-START(377957777444),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentMessage",
      "d": 655396,
      "h": 377957777444,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(377957777444),
//--TRIMMABLE-BOUNDARY-START(373662810148),
    {
      "t": 1310721,
      "n": "RuntimeEnvironmentDiagId",
      "d": 655396,
      "h": 373662810148,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(373662810148),
//--TRIMMABLE-BOUNDARY-START(231928889380),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesMessage",
      "d": 655396,
      "h": 231928889380,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(231928889380),
//--TRIMMABLE-BOUNDARY-START(227633922084),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsIgnoreNullValuesDiagId",
      "d": 655396,
      "h": 227633922084,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(227633922084),
//--TRIMMABLE-BOUNDARY-START(154619478052),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesMessage",
      "d": 655396,
      "h": 154619478052,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(154619478052),
//--TRIMMABLE-BOUNDARY-START(150324510756),
    {
      "t": 1310721,
      "n": "DerivedCryptographicTypesDiagId",
      "d": 655396,
      "h": 150324510756,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(150324510756),
//--TRIMMABLE-BOUNDARY-START(352187973668),
    {
      "t": 1310721,
      "n": "RijndaelMessage",
      "d": 655396,
      "h": 352187973668,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(352187973668),
//--TRIMMABLE-BOUNDARY-START(347893006372),
    {
      "t": 1310721,
      "n": "RijndaelDiagId",
      "d": 655396,
      "h": 347893006372,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(347893006372),
//--TRIMMABLE-BOUNDARY-START(360777908260),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderMessage",
      "d": 655396,
      "h": 360777908260,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(360777908260),
//--TRIMMABLE-BOUNDARY-START(356482940964),
    {
      "t": 1310721,
      "n": "RNGCryptoServiceProviderDiagId",
      "d": 655396,
      "h": 356482940964,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(356482940964),
//--TRIMMABLE-BOUNDARY-START(17180524580),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadMessage",
      "d": 655396,
      "h": 17180524580,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(17180524580),
//--TRIMMABLE-BOUNDARY-START(12885557284),
    {
      "t": 1310721,
      "n": "AppDomainCreateUnloadDiagId",
      "d": 655396,
      "h": 12885557284,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(12885557284),
//--TRIMMABLE-BOUNDARY-START(408022548516),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeMessage",
      "d": 655396,
      "h": 408022548516,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(408022548516),
//--TRIMMABLE-BOUNDARY-START(403727581220),
    {
      "t": 1310721,
      "n": "SuppressIldasmAttributeDiagId",
      "d": 655396,
      "h": 403727581220,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(403727581220),
//--TRIMMABLE-BOUNDARY-START(498216861732),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableMessage",
      "d": 655396,
      "h": 498216861732,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(498216861732),
//--TRIMMABLE-BOUNDARY-START(493921894436),
    {
      "t": 1310721,
      "n": "X509CertificateImmutableDiagId",
      "d": 655396,
      "h": 493921894436,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(493921894436),
//--TRIMMABLE-BOUNDARY-START(283468496932),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyMessage",
      "d": 655396,
      "h": 283468496932,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(283468496932),
//--TRIMMABLE-BOUNDARY-START(279173529636),
    {
      "t": 1310721,
      "n": "PublicKeyPropertyDiagId",
      "d": 655396,
      "h": 279173529636,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(279173529636),
//--TRIMMABLE-BOUNDARY-START(506806796324),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyMessage",
      "d": 655396,
      "h": 506806796324,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(506806796324),
//--TRIMMABLE-BOUNDARY-START(502511829028),
    {
      "t": 1310721,
      "n": "X509CertificatePrivateKeyDiagId",
      "d": 655396,
      "h": 502511829028,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(502511829028),
//--TRIMMABLE-BOUNDARY-START(274878562340),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesMessage",
      "d": 655396,
      "h": 274878562340,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(274878562340),
//--TRIMMABLE-BOUNDARY-START(270583595044),
    {
      "t": 1310721,
      "n": "ProduceLegacyHmacValuesDiagId",
      "d": 655396,
      "h": 270583595044,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(270583595044),
//--TRIMMABLE-BOUNDARY-START(481036992548),
    {
      "t": 1310721,
      "n": "UseManagedSha1Message",
      "d": 655396,
      "h": 481036992548,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(481036992548),
//--TRIMMABLE-BOUNDARY-START(476742025252),
    {
      "t": 1310721,
      "n": "UseManagedSha1DiagId",
      "d": 655396,
      "h": 476742025252,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(476742025252),
//--TRIMMABLE-BOUNDARY-START(128849674276),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDMessage",
      "d": 655396,
      "h": 128849674276,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(128849674276),
//--TRIMMABLE-BOUNDARY-START(124554706980),
    {
      "t": 1310721,
      "n": "CryptoConfigEncodeOIDDiagId",
      "d": 655396,
      "h": 124554706980,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(124554706980),
//--TRIMMABLE-BOUNDARY-START(111669805092),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryMessage",
      "d": 655396,
      "h": 111669805092,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(111669805092),
//--TRIMMABLE-BOUNDARY-START(107374837796),
    {
      "t": 1310721,
      "n": "CorruptedStateRecoveryDiagId",
      "d": 655396,
      "h": 107374837796,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(107374837796),
//--TRIMMABLE-BOUNDARY-START(335008104484),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyMessage",
      "d": 655396,
      "h": 335008104484,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(335008104484),
//--TRIMMABLE-BOUNDARY-START(330713137188),
    {
      "t": 1310721,
      "n": "Rfc2898CryptDeriveKeyDiagId",
      "d": 655396,
      "h": 330713137188,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(330713137188),
//--TRIMMABLE-BOUNDARY-START(68720132132),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorMessage",
      "d": 655396,
      "h": 68720132132,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(68720132132),
//--TRIMMABLE-BOUNDARY-START(64425164836),
    {
      "t": 1310721,
      "n": "CmsSignerCspParamsCtorDiagId",
      "d": 655396,
      "h": 64425164836,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(64425164836),
//--TRIMMABLE-BOUNDARY-START(390842679332),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigMessage",
      "d": 655396,
      "h": 390842679332,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(390842679332),
//--TRIMMABLE-BOUNDARY-START(386547712036),
    {
      "t": 1310721,
      "n": "SignerInfoCounterSigDiagId",
      "d": 655396,
      "h": 386547712036,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(386547712036),
//--TRIMMABLE-BOUNDARY-START(309238300708),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyMessage",
      "d": 655396,
      "h": 309238300708,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309238300708),
//--TRIMMABLE-BOUNDARY-START(304943333412),
    {
      "t": 1310721,
      "n": "RegexCompileToAssemblyDiagId",
      "d": 655396,
      "h": 304943333412,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(304943333412),
//--TRIMMABLE-BOUNDARY-START(42950328356),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersMessage",
      "d": 655396,
      "h": 42950328356,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(42950328356),
//--TRIMMABLE-BOUNDARY-START(38655361060),
    {
      "t": 1310721,
      "n": "AssemblyNameMembersDiagId",
      "d": 655396,
      "h": 38655361060,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(38655361060),
//--TRIMMABLE-BOUNDARY-START(416612483108),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryMessage",
      "d": 655396,
      "h": 416612483108,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(416612483108),
//--TRIMMABLE-BOUNDARY-START(412317515812),
    {
      "t": 1310721,
      "n": "SystemDataSerializationFormatBinaryDiagId",
      "d": 655396,
      "h": 412317515812,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(412317515812),
//--TRIMMABLE-BOUNDARY-START(472447057956),
    {
      "t": 1310721,
      "n": "TlsVersion10and11Message",
      "d": 655396,
      "h": 472447057956,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(472447057956),
//--TRIMMABLE-BOUNDARY-START(468152090660),
    {
      "t": 1310721,
      "n": "TlsVersion10and11DiagId",
      "d": 655396,
      "h": 468152090660,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(468152090660),
//--TRIMMABLE-BOUNDARY-START(188979216420),
    {
      "t": 1310721,
      "n": "EncryptionPolicyMessage",
      "d": 655396,
      "h": 188979216420,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(188979216420),
//--TRIMMABLE-BOUNDARY-START(184684249124),
    {
      "t": 1310721,
      "n": "EncryptionPolicyDiagId",
      "d": 655396,
      "h": 184684249124,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(184684249124),
//--TRIMMABLE-BOUNDARY-START(171799347236),
    {
      "t": 1310721,
      "n": "EccXmlExportImportMessage",
      "d": 655396,
      "h": 171799347236,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(171799347236),
//--TRIMMABLE-BOUNDARY-START(167504379940),
    {
      "t": 1310721,
      "n": "EccXmlExportImportDiagId",
      "d": 655396,
      "h": 167504379940,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(167504379940),
//--TRIMMABLE-BOUNDARY-START(180389281828),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobMessage",
      "d": 655396,
      "h": 180389281828,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(180389281828),
//--TRIMMABLE-BOUNDARY-START(176094314532),
    {
      "t": 1310721,
      "n": "EcDhPublicKeyBlobDiagId",
      "d": 655396,
      "h": 176094314532,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(176094314532),
//--TRIMMABLE-BOUNDARY-START(34360393764),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseMessage",
      "d": 655396,
      "h": 34360393764,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(34360393764),
//--TRIMMABLE-BOUNDARY-START(30065426468),
    {
      "t": 1310721,
      "n": "AssemblyNameCodeBaseDiagId",
      "d": 655396,
      "h": 30065426468,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(30065426468),
//--TRIMMABLE-BOUNDARY-START(137439608868),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryMessage",
      "d": 655396,
      "h": 137439608868,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(137439608868),
//--TRIMMABLE-BOUNDARY-START(133144641572),
    {
      "t": 1310721,
      "n": "CryptoStringFactoryDiagId",
      "d": 655396,
      "h": 133144641572,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(133144641572),
//--TRIMMABLE-BOUNDARY-START(103079870500),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunMessage",
      "d": 655396,
      "h": 103079870500,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(103079870500),
//--TRIMMABLE-BOUNDARY-START(98784903204),
    {
      "t": 1310721,
      "n": "ControlledExecutionRunDiagId",
      "d": 655396,
      "h": 98784903204,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(98784903204),
//--TRIMMABLE-BOUNDARY-START(523986665508),
    {
      "t": 1310721,
      "n": "XmlSecureResolverMessage",
      "d": 655396,
      "h": 523986665508,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(523986665508),
//--TRIMMABLE-BOUNDARY-START(519691698212),
    {
      "t": 1310721,
      "n": "XmlSecureResolverDiagId",
      "d": 655396,
      "h": 519691698212,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(519691698212),
//--TRIMMABLE-BOUNDARY-START(369367842852),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptValueMessage",
      "d": 655396,
      "h": 369367842852,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(369367842852),
//--TRIMMABLE-BOUNDARY-START(365072875556),
    {
      "t": 1310721,
      "n": "RsaEncryptDecryptDiagId",
      "d": 655396,
      "h": 365072875556,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(365072875556),
//--TRIMMABLE-BOUNDARY-START(223338954788),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextMessage",
      "d": 655396,
      "h": 223338954788,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(223338954788),
//--TRIMMABLE-BOUNDARY-START(219043987492),
    {
      "t": 1310721,
      "n": "JsonSerializerOptionsAddContextDiagId",
      "d": 655396,
      "h": 219043987492,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(219043987492),
//--TRIMMABLE-BOUNDARY-START(249108758564),
    {
      "t": 1310721,
      "n": "LegacyFormatterMessage",
      "d": 655396,
      "h": 249108758564,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(249108758564),
//--TRIMMABLE-BOUNDARY-START(236223856676),
    {
      "t": 1310721,
      "n": "LegacyFormatterDiagId",
      "d": 655396,
      "h": 236223856676,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(236223856676),
//--TRIMMABLE-BOUNDARY-START(244813791268),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplMessage",
      "d": 655396,
      "h": 244813791268,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(244813791268),
//--TRIMMABLE-BOUNDARY-START(240518823972),
    {
      "t": 1310721,
      "n": "LegacyFormatterImplDiagId",
      "d": 655396,
      "h": 240518823972,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(240518823972),
//--TRIMMABLE-BOUNDARY-START(317828235300),
    {
      "t": 1310721,
      "n": "RegexExtensibilityImplMessage",
      "d": 655396,
      "h": 317828235300,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(317828235300),
//--TRIMMABLE-BOUNDARY-START(313533268004),
    {
      "t": 1310721,
      "n": "RegexExtensibilityDiagId",
      "d": 655396,
      "h": 313533268004,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313533268004),
//--TRIMMABLE-BOUNDARY-START(8590589988),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorMessage",
      "d": 655396,
      "h": 8590589988,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(8590589988),
//--TRIMMABLE-BOUNDARY-START(4295622692),
    {
      "t": 1310721,
      "n": "AesGcmTagConstructorDiagId",
      "d": 655396,
      "h": 4295622692,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295622692),
//--TRIMMABLE-BOUNDARY-START(455267188772),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteMessage",
      "d": 655396,
      "h": 455267188772,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(455267188772),
//--TRIMMABLE-BOUNDARY-START(450972221476),
    {
      "t": 1310721,
      "n": "ThreadVolatileReadWriteDiagId",
      "d": 655396,
      "h": 450972221476,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(450972221476),
//--TRIMMABLE-BOUNDARY-START(25770459172),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationMessage",
      "d": 655396,
      "h": 25770459172,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(25770459172),
//--TRIMMABLE-BOUNDARY-START(21475491876),
    {
      "t": 1310721,
      "n": "ArmIntrinsicPerformsUnsignedOperationDiagId",
      "d": 655396,
      "h": 21475491876,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(21475491876),
//--TRIMMABLE-BOUNDARY-START(257698693156),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmMessage",
      "d": 655396,
      "h": 257698693156,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(257698693156),
//--TRIMMABLE-BOUNDARY-START(253403725860),
    {
      "t": 1310721,
      "n": "LoadFromHashAlgorithmDiagId",
      "d": 655396,
      "h": 253403725860,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(253403725860),
//--TRIMMABLE-BOUNDARY-START(515396730916),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteMessage",
      "d": 655396,
      "h": 515396730916,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(515396730916),
//--TRIMMABLE-BOUNDARY-START(511101763620),
    {
      "t": 1310721,
      "n": "X509CtorCertDataObsoleteDiagId",
      "d": 655396,
      "h": 511101763620,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(511101763620),
//--TRIMMABLE-BOUNDARY-START(463857123364),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsMessage",
      "d": 655396,
      "h": 463857123364,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(463857123364),
//--TRIMMABLE-BOUNDARY-START(459562156068),
    {
      "t": 1310721,
      "n": "TlsCipherAlgorithmEnumsDiagId",
      "d": 655396,
      "h": 459562156068,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(459562156068),
//--TRIMMABLE-BOUNDARY-START(425202417700),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownMessage",
      "d": 655396,
      "h": 425202417700,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(425202417700),
//--TRIMMABLE-BOUNDARY-START(420907450404),
    {
      "t": 1310721,
      "n": "SystemEventsEventsThreadShutdownDiagId",
      "d": 655396,
      "h": 420907450404,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(420907450404),
//--TRIMMABLE-BOUNDARY-START(343598039076),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorMessage",
      "d": 655396,
      "h": 343598039076,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(343598039076),
//--TRIMMABLE-BOUNDARY-START(339303071780),
    {
      "t": 1310721,
      "n": "Rfc2898DeriveBytesCtorDiagId",
      "d": 655396,
      "h": 339303071780,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(339303071780),
//--TRIMMABLE-BOUNDARY-START(292058431524),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteMessage",
      "d": 655396,
      "h": 292058431524,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(292058431524),
//--TRIMMABLE-BOUNDARY-START(287763464228),
    {
      "t": 1310721,
      "n": "QueryableMinByMaxByTSourceObsoleteDiagId",
      "d": 655396,
      "h": 287763464228,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(287763464228),
//--TRIMMABLE-BOUNDARY-START(532576600100),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptMessage",
      "d": 655396,
      "h": 532576600100,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(532576600100),
//--TRIMMABLE-BOUNDARY-START(528281632804),
    {
      "t": 1310721,
      "n": "XsltSettingsEnableScriptDiagId",
      "d": 655396,
      "h": 528281632804,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(528281632804)
  ],
  "h": 655396
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655396)
        
        
        //--TRIMMABLE-BOUNDARY-START(524324)
        $asm.$cls("$slq.System.Linq.Strings", ($self) => class Strings
        {
            //--TRIMMABLE-BOUNDARY-START(4295491620)
            static /*string */ ArgumentNotIEnumerableGeneric(/*string*/ message)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295491620);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$slq.System.SR.Format$6($.$slq.System.SR.ArgumentNotIEnumerableGeneric, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295491620)
            
            //--TRIMMABLE-BOUNDARY-START(8590458916)
            static /*string */ ArgumentNotValid(/*string*/ message)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590458916);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$slq.System.SR.Format$6($.$slq.System.SR.ArgumentNotValid, message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590458916)
            
            //--TRIMMABLE-BOUNDARY-START(17180393508)
            static /*string */ NoMethodOnType(/*string*/ name, /*object*/ type)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180393508);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$slq.System.SR.Format$5($.$slq.System.SR.NoMethodOnType, name, type);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180393508)
            
            //--TRIMMABLE-BOUNDARY-START(21475360804)
            static /*string */ NoMethodOnTypeMatchingArguments(/*string*/ name, /*object*/ type)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475360804);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$slq.System.SR.Format$5($.$slq.System.SR.NoMethodOnTypeMatchingArguments, name, type);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475360804)
            
            //--TRIMMABLE-BOUNDARY-START(12885426212)
            static /*string */ EnumeratingNullEnumerableExpression()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885426212);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$slq.System.SR.EnumeratingNullEnumerableExpression;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885426212)
            
            static $h = 524324;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295491620),
    {
      "r": 1310721,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "ArgumentNotIEnumerableGeneric",
      "d": 524324,
      "h": 4295491620,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295491620),
//--TRIMMABLE-BOUNDARY-START(8590458916),
    {
      "r": 1310721,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "ArgumentNotValid",
      "d": 524324,
      "h": 8590458916,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590458916),
//--TRIMMABLE-BOUNDARY-START(17180393508),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 131073
        }
      ],
      "n": "NoMethodOnType",
      "d": 524324,
      "h": 17180393508,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17180393508),
//--TRIMMABLE-BOUNDARY-START(21475360804),
    {
      "r": 1310721,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 131073
        }
      ],
      "n": "NoMethodOnTypeMatchingArguments",
      "d": 524324,
      "h": 21475360804,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21475360804),
//--TRIMMABLE-BOUNDARY-START(12885426212),
    {
      "r": 1310721,
      "n": "EnumeratingNullEnumerableExpression",
      "d": 524324,
      "h": 12885426212,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885426212)
  ],
  "h": 524324
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Linq.Strings`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524324)
        
        
        //--TRIMMABLE-BOUNDARY-START(589860)
        $asm.$cls("$slq.System.Linq.TypeHelper", ($self) => class TypeHelper
        {
            //--TRIMMABLE-BOUNDARY-START(4295557156)
            static /*Type? */ FindGenericType(/*Type*/ definition, /*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295557156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool?*/ let definitionIsInterface = null;
                while($.$$.System.Type.op_Inequality$1(type, null) && $.$$.System.Type.op_Inequality$1(type, $.$$.System.Object.$type))
                {
                    if (type.IsGenericType && $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), definition))
                    {
                        return type;
                    }
                    if (!$.$$.System.Nullable$$($.$$.System.Boolean).HasValue$get.call(definitionIsInterface))
                    {
                        definitionIsInterface = definition.IsInterface;
                    }
                    if ($.$$.System.Nullable$$($.$$.System.Boolean).GetValueOrDefault.call(definitionIsInterface))
                    {
                        let $i1 = 0;
                        let $arr1 = type.GetInterfaces();
                        while ($i1 < $arr1.length)
                        {
                            let itype = $arr1[$i1++];
                            /*Type?*/ let found = $.$slq.System.Linq.TypeHelper.FindGenericType(definition, itype);
                            if ($.$$.System.Type.op_Inequality$1(found, null))
                            {
                                return found;
                            }
                        }
                    }
                    type = type.BaseType;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557156)
            
            static $h = 589860;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295557156),
    {
      "r": 187760641,
      "p": [
        {
          "n": "definition",
          "p": 187760641
        },
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "FindGenericType",
      "d": 589860,
      "h": 4295557156,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295557156)
  ],
  "h": 589860
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Linq.TypeHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589860)
        
        
        //--TRIMMABLE-BOUNDARY-START(393252)
        $asm.$cls("$slq.System.Linq.Error", ($self) => class Error
        {
            //--TRIMMABLE-BOUNDARY-START(4295360548)
            static /*Exception */ ArgumentNotIEnumerableGeneric(/*string*/ message)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360548);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.System.ArgumentException().$ctor$14($.$slq.System.Linq.Strings.ArgumentNotIEnumerableGeneric(message));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360548)
            
            //--TRIMMABLE-BOUNDARY-START(8590327844)
            static /*Exception */ ArgumentNotValid(/*string*/ message)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327844);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.System.ArgumentException().$ctor$14($.$slq.System.Linq.Strings.ArgumentNotValid(message));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590327844)
            
            //--TRIMMABLE-BOUNDARY-START(12885295140)
            static /*Exception */ ArgumentOutOfRange(/*string*/ message)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885295140);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.System.ArgumentOutOfRangeException().$ctor$20(message);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885295140)
            
            //--TRIMMABLE-BOUNDARY-START(21475229732)
            static /*Exception */ NoMethodOnType(/*string*/ name, /*object*/ type)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475229732);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.System.InvalidOperationException().$ctor$12($.$slq.System.Linq.Strings.NoMethodOnType(name, type));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475229732)
            
            //--TRIMMABLE-BOUNDARY-START(25770197028)
            static /*Exception */ NoMethodOnTypeMatchingArguments(/*string*/ name, /*object*/ type)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770197028);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.System.InvalidOperationException().$ctor$12($.$slq.System.Linq.Strings.NoMethodOnTypeMatchingArguments(name, type));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770197028)
            
            //--TRIMMABLE-BOUNDARY-START(17180262436)
            static /*Exception */ EnumeratingNullEnumerableExpression()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180262436);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new $.$$.System.InvalidOperationException().$ctor$12($.$slq.System.Linq.Strings.EnumeratingNullEnumerableExpression());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180262436)
            
            static $h = 393252;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295360548),
    {
      "r": 80019457,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "ArgumentNotIEnumerableGeneric",
      "d": 393252,
      "h": 4295360548,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295360548),
//--TRIMMABLE-BOUNDARY-START(8590327844),
    {
      "r": 80019457,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "ArgumentNotValid",
      "d": 393252,
      "h": 8590327844,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590327844),
//--TRIMMABLE-BOUNDARY-START(12885295140),
    {
      "r": 80019457,
      "p": [
        {
          "n": "message",
          "p": 1310721
        }
      ],
      "n": "ArgumentOutOfRange",
      "d": 393252,
      "h": 12885295140,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885295140),
//--TRIMMABLE-BOUNDARY-START(21475229732),
    {
      "r": 80019457,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 131073
        }
      ],
      "n": "NoMethodOnType",
      "d": 393252,
      "h": 21475229732,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(21475229732),
//--TRIMMABLE-BOUNDARY-START(25770197028),
    {
      "r": 80019457,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 131073
        }
      ],
      "n": "NoMethodOnTypeMatchingArguments",
      "d": 393252,
      "h": 25770197028,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(25770197028),
//--TRIMMABLE-BOUNDARY-START(17180262436),
    {
      "r": 80019457,
      "n": "EnumeratingNullEnumerableExpression",
      "d": 393252,
      "h": 17180262436,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17180262436)
  ],
  "h": 393252
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Linq.Error`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393252)
        
        
        //--TRIMMABLE-BOUNDARY-START(720932)
        $asm.$cls("$slq.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(171799412772)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(171799412772)
            
            //--TRIMMABLE-BOUNDARY-START(146029608996)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146029608996);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029608996)
            
            //--TRIMMABLE-BOUNDARY-START(184684314660)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(184684314660);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$slq.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684314660)
            
            //--TRIMMABLE-BOUNDARY-START(141734641700)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734641700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$slq.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(141734641700)
            
            //--TRIMMABLE-BOUNDARY-START(137439674404)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439674404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$slq.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(137439674404)
            
            //--TRIMMABLE-BOUNDARY-START(51540328484)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(51540328484)
            
            //--TRIMMABLE-BOUNDARY-START(47245361188)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(47245361188)
            
            //--TRIMMABLE-BOUNDARY-START(42950393892)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(42950393892)
            
            //--TRIMMABLE-BOUNDARY-START(55835295780)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$slq.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(55835295780)
            
            //--TRIMMABLE-BOUNDARY-START(34360459300)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360459300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(34360459300)
            
            //--TRIMMABLE-BOUNDARY-START(30065492004)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065492004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(30065492004)
            
            //--TRIMMABLE-BOUNDARY-START(25770524708)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770524708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(25770524708)
            
            //--TRIMMABLE-BOUNDARY-START(38655426596)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655426596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$slq.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(38655426596)
            
            //--TRIMMABLE-BOUNDARY-START(167504445476)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(167504445476)
            
            //--TRIMMABLE-BOUNDARY-START(158914510884)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(158914510884)
            
            //--TRIMMABLE-BOUNDARY-START(163209478180)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144707108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$slq.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Linq.Queryable", $.$slq.System.SR.$type.Assembly);
                    $.$slq.System.SR.s_resourceManager = temp;
                }
                return $.$slq.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(163209478180)
            
            //--TRIMMABLE-BOUNDARY-START(17180590116)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$slq.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389347364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$slq.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(17180590116)
            
            //--TRIMMABLE-BOUNDARY-START(8590655524)
            static /*string */ get ArgumentNotIEnumerableGeneric()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605099556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "{0} is not IEnumerable<>";
            }
            //--TRIMMABLE-BOUNDARY-END(8590655524)
            
            //--TRIMMABLE-BOUNDARY-START(60130263076)
            static /*string */ FormatArgumentNotIEnumerableGeneric(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130263076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("{0} is not IEnumerable<>", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(60130263076)
            
            //--TRIMMABLE-BOUNDARY-START(12885622820)
            static /*string */ get ArgumentNotValid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195034148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Argument {0} is not valid";
            }
            //--TRIMMABLE-BOUNDARY-END(12885622820)
            
            //--TRIMMABLE-BOUNDARY-START(64425230372)
            static /*string */ FormatArgumentNotValid(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Argument {0} is not valid", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(64425230372)
            
            //--TRIMMABLE-BOUNDARY-START(150324576292)
            static /*string */ get NoMethodOnType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964837924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "There is no method '{0}' on type '{1}'";
            }
            //--TRIMMABLE-BOUNDARY-END(150324576292)
            
            //--TRIMMABLE-BOUNDARY-START(68720197668)
            static /*string */ FormatNoMethodOnType(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720197668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("There is no method '{0}' on type '{1}'", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(68720197668)
            
            //--TRIMMABLE-BOUNDARY-START(154619543588)
            static /*string */ get NoMethodOnTypeMatchingArguments()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554772516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "There is no method '{0}' on type '{1}' that matches the specified arguments";
            }
            //--TRIMMABLE-BOUNDARY-END(154619543588)
            
            //--TRIMMABLE-BOUNDARY-START(73015164964)
            static /*string */ FormatNoMethodOnTypeMatchingArguments(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015164964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("There is no method '{0}' on type '{1}' that matches the specified arguments", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(73015164964)
            
            //--TRIMMABLE-BOUNDARY-START(21475557412)
            static /*string */ get EnumeratingNullEnumerableExpression()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374903332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot enumerate a query created from a null IEnumerable<>";
            }
            //--TRIMMABLE-BOUNDARY-END(21475557412)
            
            //--TRIMMABLE-BOUNDARY-START(4295688228)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(171799412772)
                    this.s_usingResourceKeys = $.$slq.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(171799412772)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295688228)
            
            static $h = 720932;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 720932
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720932)
        
        
        //--TRIMMABLE-BOUNDARY-START(458788)
        $asm.$cls("$slq.System.Linq.Queryable", ($self) => class Queryable
        {
            //--TRIMMABLE-BOUNDARY-START(313533071396)
            /*string*/ static InMemoryQueryableExtensionMethodsRequiresUnreferencedCode = null;
            //--TRIMMABLE-BOUNDARY-END(313533071396)
            
            //--TRIMMABLE-BOUNDARY-START(309238104100)
            /*string*/ static InMemoryQueryableExtensionMethodsRequiresDynamicCode = null;
            //--TRIMMABLE-BOUNDARY-END(309238104100)
            
            //--TRIMMABLE-BOUNDARY-START(47245099044)
            static /*IQueryable<TElement> */ AsQueryable$1(TElement, /*this IEnumerable<TElement>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245099044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$as(source, $.$sle.System.Linq.IQueryable$$(TElement)) ?? new ($.$slq.System.Linq.EnumerableQuery$$(TElement))().$ctor$2(source);
            }
            //--TRIMMABLE-BOUNDARY-END(47245099044)
            
            //--TRIMMABLE-BOUNDARY-START(42950131748)
            static /*IQueryable */ AsQueryable(/*this IEnumerable*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950131748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                let queryable;
                if ($.$is(source, $.$sle.System.Linq.IQueryable, { set $v(v){ queryable = v; } }))
                {
                    return queryable;
                }
                /*Type?*/ let enumType = $.$slq.System.Linq.TypeHelper.FindGenericType($.$$.System.Collections.Generic.IEnumerable$$().$type, $.$$.System.Object.GetType.call(source));
                if ($.$$.System.Type.op_Equality$1(enumType, null))
                {
                    throw $.$slq.System.Linq.Error.ArgumentNotIEnumerableGeneric("source");
                }
                return $.$slq.System.Linq.EnumerableQuery.Create($.$$.System.Array.$ReadT1.call(enumType.GenericTypeArguments, 0), source);
            }
            //--TRIMMABLE-BOUNDARY-END(42950131748)
            
            //--TRIMMABLE-BOUNDARY-START(717259997220)
            static /*IQueryable<TSource> */ Where(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(717259997220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Where).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            //--TRIMMABLE-BOUNDARY-END(717259997220)
            
            //--TRIMMABLE-BOUNDARY-START(721554964516)
            static /*IQueryable<TSource> */ Where$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, bool>>*/ predicate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(721554964516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Where$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            //--TRIMMABLE-BOUNDARY-END(721554964516)
            
            //--TRIMMABLE-BOUNDARY-START(438087122980)
            static /*IQueryable<TResult> */ OfType(TResult, /*this IQueryable*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(438087122980);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, $.$slq.System.Linq.Queryable.OfType.Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(438087122980)
            
            //--TRIMMABLE-BOUNDARY-START(137439412260)
            static /*IQueryable<TResult> */ Cast(TResult, /*this IQueryable*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439412260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, $.$slq.System.Linq.Queryable.Cast.Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(137439412260)
            
            //--TRIMMABLE-BOUNDARY-START(498216665124)
            static /*IQueryable<TResult> */ Select$1(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TResult>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498216665124);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Select$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(498216665124)
            
            //--TRIMMABLE-BOUNDARY-START(493921697828)
            static /*IQueryable<TResult> */ Select(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, TResult>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493921697828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Select).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(493921697828)
            
            //--TRIMMABLE-BOUNDARY-START(511101567012)
            static /*IQueryable<TResult> */ SelectMany$2(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, IEnumerable<TResult>>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511101567012);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Collections.Generic.IEnumerable$$(TResult))), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SelectMany$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(511101567012)
            
            //--TRIMMABLE-BOUNDARY-START(515396534308)
            static /*IQueryable<TResult> */ SelectMany$3(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, IEnumerable<TResult>>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515396534308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Collections.Generic.IEnumerable$$(TResult))), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SelectMany$3).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(515396534308)
            
            //--TRIMMABLE-BOUNDARY-START(506806599716)
            static /*IQueryable<TResult> */ SelectMany$1(TSource, TCollection, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, IEnumerable<TCollection>>>*/ collectionSelector, /*Expression<Func<TSource, TCollection, TResult>>*/ resultSelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506806599716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collectionSelector, "collectionSelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Collections.Generic.IEnumerable$$(TCollection))), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, TCollection, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SelectMany$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(collectionSelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector)));
            }
            //--TRIMMABLE-BOUNDARY-END(506806599716)
            
            //--TRIMMABLE-BOUNDARY-START(502511632420)
            static /*IQueryable<TResult> */ SelectMany(TSource, TCollection, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, IEnumerable<TCollection>>>*/ collectionSelector, /*Expression<Func<TSource, TCollection, TResult>>*/ resultSelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502511632420);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collectionSelector, "collectionSelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Collections.Generic.IEnumerable$$(TCollection))), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, TCollection, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SelectMany).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(collectionSelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector)));
            }
            //--TRIMMABLE-BOUNDARY-END(502511632420)
            
            //--TRIMMABLE-BOUNDARY-START(257698496548)
            static /*Expression */ GetSourceExpression(TSource, /*IEnumerable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698496548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*IQueryable<TSource>?*/ let q = $.$as(source, $.$sle.System.Linq.IQueryable$$(TSource));
                return q !== null ? q.System$Linq$IQueryable$Expression : $.$sle.System.Linq.Expressions.Expression.Constant(source, $.$$.System.Collections.Generic.IEnumerable$$(TSource).$type);
            }
            //--TRIMMABLE-BOUNDARY-END(257698496548)
            
            //--TRIMMABLE-BOUNDARY-START(339302875172)
            static /*IQueryable<TResult> */ Join$1(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, TInner, TResult>>*/ resultSelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339302875172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outer, "outer");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outerKeySelector, "outerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerKeySelector, "innerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$$.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Join$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(339302875172)
            
            //--TRIMMABLE-BOUNDARY-START(335007907876)
            static /*IQueryable<TResult> */ Join(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, TInner, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335007907876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outer, "outer");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outerKeySelector, "outerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerKeySelector, "innerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$$.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Join).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(335007907876)
            
            //--TRIMMABLE-BOUNDARY-START(300648169508)
            static /*IQueryable<TResult> */ GroupJoin$1(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, IEnumerable<TInner>, TResult>>*/ resultSelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648169508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outer, "outer");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outerKeySelector, "outerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerKeySelector, "innerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$$.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, $.$$.System.Collections.Generic.IEnumerable$$(TInner), TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupJoin$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(300648169508)
            
            //--TRIMMABLE-BOUNDARY-START(296353202212)
            static /*IQueryable<TResult> */ GroupJoin(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, IEnumerable<TInner>, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353202212);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outer, "outer");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outerKeySelector, "outerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerKeySelector, "innerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$$.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, $.$$.System.Collections.Generic.IEnumerable$$(TInner), TResult)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupJoin).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(296353202212)
            
            //--TRIMMABLE-BOUNDARY-START(373662613540)
            static /*IQueryable<TResult> */ LeftJoin$1(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, TInner?, TResult>>*/ resultSelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662613540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outer, "outer");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outerKeySelector, "outerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerKeySelector, "innerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$$.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LeftJoin$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(373662613540)
            
            //--TRIMMABLE-BOUNDARY-START(369367646244)
            static /*IQueryable<TResult> */ LeftJoin(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, TInner?, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369367646244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outer, "outer");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outerKeySelector, "outerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerKeySelector, "innerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$$.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LeftJoin).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(369367646244)
            
            //--TRIMMABLE-BOUNDARY-START(446677057572)
            static /*IOrderedQueryable<T> */ Order$1(T, /*this IQueryable<T>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(446677057572);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(T, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(T), $.$sle.System.Linq.IOrderedQueryable$$(T)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Order$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null))), $.$sle.System.Linq.IOrderedQueryable$$(T));
            }
            //--TRIMMABLE-BOUNDARY-END(446677057572)
            
            //--TRIMMABLE-BOUNDARY-START(442382090276)
            static /*IOrderedQueryable<T> */ Order(T, /*this IQueryable<T>*/ source, /*IComparer<T>*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442382090276);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(T, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(T), $.$$.System.Collections.Generic.IComparer$$(T), $.$sle.System.Linq.IOrderedQueryable$$(T)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Order).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(T).$type))), $.$sle.System.Linq.IOrderedQueryable$$(T));
            }
            //--TRIMMABLE-BOUNDARY-END(442382090276)
            
            //--TRIMMABLE-BOUNDARY-START(455266992164)
            static /*IOrderedQueryable<TSource> */ OrderBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(455266992164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderBy$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            //--TRIMMABLE-BOUNDARY-END(455266992164)
            
            //--TRIMMABLE-BOUNDARY-START(450972024868)
            static /*IOrderedQueryable<TSource> */ OrderBy(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450972024868);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IComparer$$(TKey), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TKey).$type))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            //--TRIMMABLE-BOUNDARY-END(450972024868)
            
            //--TRIMMABLE-BOUNDARY-START(472446861348)
            static /*IOrderedQueryable<T> */ OrderDescending$1(T, /*this IQueryable<T>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(472446861348);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(T, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(T), $.$sle.System.Linq.IOrderedQueryable$$(T)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderDescending$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null))), $.$sle.System.Linq.IOrderedQueryable$$(T));
            }
            //--TRIMMABLE-BOUNDARY-END(472446861348)
            
            //--TRIMMABLE-BOUNDARY-START(468151894052)
            static /*IOrderedQueryable<T> */ OrderDescending(T, /*this IQueryable<T>*/ source, /*IComparer<T>*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468151894052);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(T, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(T), $.$$.System.Collections.Generic.IComparer$$(T), $.$sle.System.Linq.IOrderedQueryable$$(T)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderDescending).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(T).$type))), $.$sle.System.Linq.IOrderedQueryable$$(T));
            }
            //--TRIMMABLE-BOUNDARY-END(468151894052)
            
            //--TRIMMABLE-BOUNDARY-START(463856926756)
            static /*IOrderedQueryable<TSource> */ OrderByDescending$1(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(463856926756);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderByDescending$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            //--TRIMMABLE-BOUNDARY-END(463856926756)
            
            //--TRIMMABLE-BOUNDARY-START(459561959460)
            static /*IOrderedQueryable<TSource> */ OrderByDescending(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459561959460);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IComparer$$(TKey), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderByDescending).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TKey).$type))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            //--TRIMMABLE-BOUNDARY-END(459561959460)
            
            //--TRIMMABLE-BOUNDARY-START(489626730532)
            static /*IQueryable<TResult> */ RightJoin$1(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter?, TInner, TResult>>*/ resultSelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(489626730532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outer, "outer");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outerKeySelector, "outerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerKeySelector, "innerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$$.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.RightJoin$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(489626730532)
            
            //--TRIMMABLE-BOUNDARY-START(485331763236)
            static /*IQueryable<TResult> */ RightJoin(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter?, TInner, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485331763236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outer, "outer");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outerKeySelector, "outerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerKeySelector, "innerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$$.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.RightJoin).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(485331763236)
            
            //--TRIMMABLE-BOUNDARY-START(687195226148)
            static /*IOrderedQueryable<TSource> */ ThenBy$1(TSource, TKey, /*this IOrderedQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(687195226148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IOrderedQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ThenBy$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            //--TRIMMABLE-BOUNDARY-END(687195226148)
            
            //--TRIMMABLE-BOUNDARY-START(682900258852)
            static /*IOrderedQueryable<TSource> */ ThenBy(TSource, TKey, /*this IOrderedQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(682900258852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IOrderedQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IComparer$$(TKey), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ThenBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TKey).$type))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            //--TRIMMABLE-BOUNDARY-END(682900258852)
            
            //--TRIMMABLE-BOUNDARY-START(695785160740)
            static /*IOrderedQueryable<TSource> */ ThenByDescending$1(TSource, TKey, /*this IOrderedQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(695785160740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IOrderedQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ThenByDescending$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            //--TRIMMABLE-BOUNDARY-END(695785160740)
            
            //--TRIMMABLE-BOUNDARY-START(691490193444)
            static /*IOrderedQueryable<TSource> */ ThenByDescending(TSource, TKey, /*this IOrderedQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(691490193444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IOrderedQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IComparer$$(TKey), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ThenByDescending).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TKey).$type))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            //--TRIMMABLE-BOUNDARY-END(691490193444)
            
            //--TRIMMABLE-BOUNDARY-START(661425422372)
            static /*IQueryable<TSource> */ Take(TSource, /*this IQueryable<TSource>*/ source, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(661425422372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int32, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Take).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(count, $.$$.System.Int32))));
            }
            //--TRIMMABLE-BOUNDARY-END(661425422372)
            
            //--TRIMMABLE-BOUNDARY-START(665720389668)
            static /*IQueryable<TSource> */ Take$1(TSource, /*this IQueryable<TSource>*/ source, /*Range*/ range)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(665720389668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Range, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Take$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1(range)));
            }
            //--TRIMMABLE-BOUNDARY-END(665720389668)
            
            //--TRIMMABLE-BOUNDARY-START(674310324260)
            static /*IQueryable<TSource> */ TakeWhile(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(674310324260);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.TakeWhile).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            //--TRIMMABLE-BOUNDARY-END(674310324260)
            
            //--TRIMMABLE-BOUNDARY-START(678605291556)
            static /*IQueryable<TSource> */ TakeWhile$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, bool>>*/ predicate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(678605291556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.TakeWhile$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            //--TRIMMABLE-BOUNDARY-END(678605291556)
            
            //--TRIMMABLE-BOUNDARY-START(558346207268)
            static /*IQueryable<TSource> */ Skip(TSource, /*this IQueryable<TSource>*/ source, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(558346207268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int32, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Skip).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(count, $.$$.System.Int32))));
            }
            //--TRIMMABLE-BOUNDARY-END(558346207268)
            
            //--TRIMMABLE-BOUNDARY-START(566936141860)
            static /*IQueryable<TSource> */ SkipWhile(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(566936141860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SkipWhile).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            //--TRIMMABLE-BOUNDARY-END(566936141860)
            
            //--TRIMMABLE-BOUNDARY-START(571231109156)
            static /*IQueryable<TSource> */ SkipWhile$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, bool>>*/ predicate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(571231109156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SkipWhile$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            //--TRIMMABLE-BOUNDARY-END(571231109156)
            
            //--TRIMMABLE-BOUNDARY-START(292058234916)
            static /*IQueryable<IGrouping<TKey, TSource>> */ GroupBy$7(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058234916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$sl.System.Linq.IGrouping$$$(TKey, TSource), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TSource))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$7).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            //--TRIMMABLE-BOUNDARY-END(292058234916)
            
            //--TRIMMABLE-BOUNDARY-START(274878365732)
            static /*IQueryable<IGrouping<TKey, TElement>> */ GroupBy$3(TSource, TKey, TElement, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TSource, TElement>>*/ elementSelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878365732);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(elementSelector, "elementSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$sl.System.Linq.IGrouping$$$(TKey, TElement), $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TElement)), $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$3).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(elementSelector)));
            }
            //--TRIMMABLE-BOUNDARY-END(274878365732)
            
            //--TRIMMABLE-BOUNDARY-START(287763267620)
            static /*IQueryable<IGrouping<TKey, TSource>> */ GroupBy$6(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763267620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$sl.System.Linq.IGrouping$$$(TKey, TSource), $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TSource))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$6).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(287763267620)
            
            //--TRIMMABLE-BOUNDARY-START(270583398436)
            static /*IQueryable<IGrouping<TKey, TElement>> */ GroupBy$2(TSource, TKey, TElement, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TSource, TElement>>*/ elementSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583398436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(elementSelector, "elementSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$sl.System.Linq.IGrouping$$$(TKey, TElement), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TElement)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$2).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(elementSelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(270583398436)
            
            //--TRIMMABLE-BOUNDARY-START(266288431140)
            static /*IQueryable<TResult> */ GroupBy$1(TSource, TKey, TElement, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TSource, TElement>>*/ elementSelector, /*Expression<Func<TKey, IEnumerable<TElement>, TResult>>*/ resultSelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288431140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(elementSelector, "elementSelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TElement)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TKey, $.$$.System.Collections.Generic.IEnumerable$$(TElement), TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(elementSelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(266288431140)
            
            //--TRIMMABLE-BOUNDARY-START(283468300324)
            static /*IQueryable<TResult> */ GroupBy$5(TSource, TKey, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TKey, IEnumerable<TSource>, TResult>>*/ resultSelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468300324);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TKey, $.$$.System.Collections.Generic.IEnumerable$$(TSource), TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$5).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector)));
            }
            //--TRIMMABLE-BOUNDARY-END(283468300324)
            
            //--TRIMMABLE-BOUNDARY-START(279173333028)
            static /*IQueryable<TResult> */ GroupBy$4(TSource, TKey, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TKey, IEnumerable<TSource>, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173333028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TKey, $.$$.System.Collections.Generic.IEnumerable$$(TSource), TResult)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$4).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(279173333028)
            
            //--TRIMMABLE-BOUNDARY-START(261993463844)
            static /*IQueryable<TResult> */ GroupBy(TSource, TKey, TElement, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TSource, TElement>>*/ elementSelector, /*Expression<Func<TKey, IEnumerable<TElement>, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993463844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(elementSelector, "elementSelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TElement)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TKey, $.$$.System.Collections.Generic.IEnumerable$$(TElement), TResult)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(elementSelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(261993463844)
            
            //--TRIMMABLE-BOUNDARY-START(184684052516)
            static /*IQueryable<TSource> */ Distinct$1(TSource, /*this IQueryable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684052516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Distinct$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(184684052516)
            
            //--TRIMMABLE-BOUNDARY-START(180389085220)
            static /*IQueryable<TSource> */ Distinct(TSource, /*this IQueryable<TSource>*/ source, /*IEqualityComparer<TSource>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389085220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEqualityComparer$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Distinct).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(180389085220)
            
            //--TRIMMABLE-BOUNDARY-START(193273987108)
            static /*IQueryable<TSource> */ DistinctBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273987108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.DistinctBy$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            //--TRIMMABLE-BOUNDARY-END(193273987108)
            
            //--TRIMMABLE-BOUNDARY-START(188979019812)
            static /*IQueryable<TSource> */ DistinctBy(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979019812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.DistinctBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(188979019812)
            
            //--TRIMMABLE-BOUNDARY-START(141734379556)
            static /*IQueryable<TSource[]> */ Chunk(TSource, /*this IQueryable<TSource>*/ source, /*int*/ size)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734379556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$typeArray(TSource), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int32, $.$sle.System.Linq.IQueryable$$($.$typeArray(TSource))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Chunk).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(size, $.$$.System.Int32))));
            }
            //--TRIMMABLE-BOUNDARY-END(141734379556)
            
            //--TRIMMABLE-BOUNDARY-START(146029346852)
            static /*IQueryable<TSource> */ Concat(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029346852);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Concat).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2)));
            }
            //--TRIMMABLE-BOUNDARY-END(146029346852)
            
            //--TRIMMABLE-BOUNDARY-START(734439866404)
            static /*IQueryable<(TFirst First, TSecond Second)> */ Zip$2(TFirst, TSecond, /*this IQueryable<TFirst>*/ source1, /*IEnumerable<TSecond>*/ source2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(734439866404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$$.System.ValueTuple$$$(TFirst, TSecond), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TFirst), $.$$.System.Collections.Generic.IEnumerable$$(TSecond), $.$sle.System.Linq.IQueryable$$($.$$.System.ValueTuple$$$(TFirst, TSecond))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Zip$2).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSecond, source2)));
            }
            //--TRIMMABLE-BOUNDARY-END(734439866404)
            
            //--TRIMMABLE-BOUNDARY-START(725849931812)
            static /*IQueryable<TResult> */ Zip(TFirst, TSecond, TResult, /*this IQueryable<TFirst>*/ source1, /*IEnumerable<TSecond>*/ source2, /*Expression<Func<TFirst, TSecond, TResult>>*/ resultSelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(725849931812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TFirst), $.$$.System.Collections.Generic.IEnumerable$$(TSecond), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TFirst, TSecond, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Zip).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSecond, source2), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector)));
            }
            //--TRIMMABLE-BOUNDARY-END(725849931812)
            
            //--TRIMMABLE-BOUNDARY-START(730144899108)
            static /*IQueryable<(TFirst First, TSecond Second, TThird Third)> */ Zip$1(TFirst, TSecond, TThird, /*this IQueryable<TFirst>*/ source1, /*IEnumerable<TSecond>*/ source2, /*IEnumerable<TThird>*/ source3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(730144899108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source3, "source3");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$$.System.ValueTuple$$$$(TFirst, TSecond, TThird), $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TFirst), $.$$.System.Collections.Generic.IEnumerable$$(TSecond), $.$$.System.Collections.Generic.IEnumerable$$(TThird), $.$sle.System.Linq.IQueryable$$($.$$.System.ValueTuple$$$$(TFirst, TSecond, TThird))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Zip$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSecond, source2), $.$slq.System.Linq.Queryable.GetSourceExpression(TThird, source3)));
            }
            //--TRIMMABLE-BOUNDARY-END(730144899108)
            
            //--TRIMMABLE-BOUNDARY-START(704375095332)
            static /*IQueryable<TSource> */ Union$1(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(704375095332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Union$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2)));
            }
            //--TRIMMABLE-BOUNDARY-END(704375095332)
            
            //--TRIMMABLE-BOUNDARY-START(700080128036)
            static /*IQueryable<TSource> */ Union(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*IEqualityComparer<TSource>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(700080128036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$$.System.Collections.Generic.IEqualityComparer$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Union).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(700080128036)
            
            //--TRIMMABLE-BOUNDARY-START(712965029924)
            static /*IQueryable<TSource> */ UnionBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(712965029924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.UnionBy$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            //--TRIMMABLE-BOUNDARY-END(712965029924)
            
            //--TRIMMABLE-BOUNDARY-START(708670062628)
            static /*IQueryable<TSource> */ UnionBy(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(708670062628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.UnionBy).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(708670062628)
            
            //--TRIMMABLE-BOUNDARY-START(304943136804)
            static /*IQueryable<(int Index, TSource Item)> */ Index(TSource, /*this IQueryable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943136804);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$$.System.ValueTuple$$$($.$$.System.Int32, TSource), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.IQueryable$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TSource))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Index).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(304943136804)
            
            //--TRIMMABLE-BOUNDARY-START(322123005988)
            static /*IQueryable<TSource> */ Intersect$1(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123005988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Intersect$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2)));
            }
            //--TRIMMABLE-BOUNDARY-END(322123005988)
            
            //--TRIMMABLE-BOUNDARY-START(317828038692)
            static /*IQueryable<TSource> */ Intersect(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*IEqualityComparer<TSource>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828038692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$$.System.Collections.Generic.IEqualityComparer$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Intersect).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(317828038692)
            
            //--TRIMMABLE-BOUNDARY-START(330712940580)
            static /*IQueryable<TSource> */ IntersectBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TKey>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330712940580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TKey), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.IntersectBy$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TKey, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            //--TRIMMABLE-BOUNDARY-END(330712940580)
            
            //--TRIMMABLE-BOUNDARY-START(326417973284)
            static /*IQueryable<TSource> */ IntersectBy(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TKey>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326417973284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TKey), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.IntersectBy).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TKey, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(326417973284)
            
            //--TRIMMABLE-BOUNDARY-START(219043790884)
            static /*IQueryable<TSource> */ Except$1(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043790884);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Except$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2)));
            }
            //--TRIMMABLE-BOUNDARY-END(219043790884)
            
            //--TRIMMABLE-BOUNDARY-START(214748823588)
            static /*IQueryable<TSource> */ Except(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*IEqualityComparer<TSource>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748823588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$$.System.Collections.Generic.IEqualityComparer$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Except).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(214748823588)
            
            //--TRIMMABLE-BOUNDARY-START(227633725476)
            static /*IQueryable<TSource> */ ExceptBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TKey>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633725476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TKey), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ExceptBy$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TKey, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            //--TRIMMABLE-BOUNDARY-END(227633725476)
            
            //--TRIMMABLE-BOUNDARY-START(223338758180)
            static /*IQueryable<TSource> */ ExceptBy(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TKey>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338758180);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TKey), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ExceptBy).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TKey, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(223338758180)
            
            //--TRIMMABLE-BOUNDARY-START(236223660068)
            static /*TSource */ First$1(TSource, /*this IQueryable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223660068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.First$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(236223660068)
            
            //--TRIMMABLE-BOUNDARY-START(231928692772)
            static /*TSource */ First(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928692772);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.First).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            //--TRIMMABLE-BOUNDARY-END(231928692772)
            
            //--TRIMMABLE-BOUNDARY-START(253403529252)
            static /*TSource? */ FirstOrDefault$3(TSource, /*this IQueryable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403529252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.FirstOrDefault$3).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(253403529252)
            
            //--TRIMMABLE-BOUNDARY-START(249108561956)
            static /*TSource */ FirstOrDefault$2(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108561956);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.FirstOrDefault$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(defaultValue, TSource), TSource.$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(249108561956)
            
            //--TRIMMABLE-BOUNDARY-START(244813594660)
            static /*TSource? */ FirstOrDefault$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813594660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.FirstOrDefault$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            //--TRIMMABLE-BOUNDARY-END(244813594660)
            
            //--TRIMMABLE-BOUNDARY-START(240518627364)
            static /*TSource */ FirstOrDefault(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate, /*TSource*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518627364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.FirstOrDefault).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate), $.$sle.System.Linq.Expressions.Expression.Constant($.$box(defaultValue, TSource), TSource.$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(240518627364)
            
            //--TRIMMABLE-BOUNDARY-START(347892809764)
            static /*TSource */ Last$1(TSource, /*this IQueryable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347892809764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Last$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(347892809764)
            
            //--TRIMMABLE-BOUNDARY-START(343597842468)
            static /*TSource */ Last(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343597842468);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Last).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            //--TRIMMABLE-BOUNDARY-END(343597842468)
            
            //--TRIMMABLE-BOUNDARY-START(365072678948)
            static /*TSource? */ LastOrDefault$3(TSource, /*this IQueryable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365072678948);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LastOrDefault$3).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(365072678948)
            
            //--TRIMMABLE-BOUNDARY-START(360777711652)
            static /*TSource */ LastOrDefault$2(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777711652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LastOrDefault$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(defaultValue, TSource), TSource.$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(360777711652)
            
            //--TRIMMABLE-BOUNDARY-START(356482744356)
            static /*TSource? */ LastOrDefault$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356482744356);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LastOrDefault$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            //--TRIMMABLE-BOUNDARY-END(356482744356)
            
            //--TRIMMABLE-BOUNDARY-START(352187777060)
            static /*TSource */ LastOrDefault(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate, /*TSource*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187777060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LastOrDefault).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate), $.$sle.System.Linq.Expressions.Expression.Constant($.$box(defaultValue, TSource), TSource.$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(352187777060)
            
            //--TRIMMABLE-BOUNDARY-START(536871370788)
            static /*TSource */ Single$1(TSource, /*this IQueryable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536871370788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Single$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(536871370788)
            
            //--TRIMMABLE-BOUNDARY-START(532576403492)
            static /*TSource */ Single(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(532576403492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Single).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            //--TRIMMABLE-BOUNDARY-END(532576403492)
            
            //--TRIMMABLE-BOUNDARY-START(554051239972)
            static /*TSource? */ SingleOrDefault$3(TSource, /*this IQueryable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(554051239972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SingleOrDefault$3).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(554051239972)
            
            //--TRIMMABLE-BOUNDARY-START(549756272676)
            static /*TSource */ SingleOrDefault$2(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(549756272676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SingleOrDefault$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(defaultValue, TSource), TSource.$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(549756272676)
            
            //--TRIMMABLE-BOUNDARY-START(545461305380)
            static /*TSource? */ SingleOrDefault$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545461305380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SingleOrDefault$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            //--TRIMMABLE-BOUNDARY-END(545461305380)
            
            //--TRIMMABLE-BOUNDARY-START(541166338084)
            static /*TSource */ SingleOrDefault(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate, /*TSource*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541166338084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SingleOrDefault).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate), $.$sle.System.Linq.Expressions.Expression.Constant($.$box(defaultValue, TSource), TSource.$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(541166338084)
            
            //--TRIMMABLE-BOUNDARY-START(201863921700)
            static /*TSource */ ElementAt$1(TSource, /*this IQueryable<TSource>*/ source, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863921700);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                if (index < 0)
                {
                    throw $.$slq.System.Linq.Error.ArgumentOutOfRange("index");
                }
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int32, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ElementAt$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(index, $.$$.System.Int32))));
            }
            //--TRIMMABLE-BOUNDARY-END(201863921700)
            
            //--TRIMMABLE-BOUNDARY-START(197568954404)
            static /*TSource */ ElementAt(TSource, /*this IQueryable<TSource>*/ source, /*Index*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568954404);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                if (index.IsFromEnd && index.Value === 0)
                {
                    throw $.$slq.System.Linq.Error.ArgumentOutOfRange("index");
                }
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Index, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ElementAt).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1(index)));
            }
            //--TRIMMABLE-BOUNDARY-END(197568954404)
            
            //--TRIMMABLE-BOUNDARY-START(210453856292)
            static /*TSource? */ ElementAtOrDefault$1(TSource, /*this IQueryable<TSource>*/ source, /*int*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453856292);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int32, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ElementAtOrDefault$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(index, $.$$.System.Int32))));
            }
            //--TRIMMABLE-BOUNDARY-END(210453856292)
            
            //--TRIMMABLE-BOUNDARY-START(206158888996)
            static /*TSource? */ ElementAtOrDefault(TSource, /*this IQueryable<TSource>*/ source, /*Index*/ index)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158888996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Index, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ElementAtOrDefault).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1(index)));
            }
            //--TRIMMABLE-BOUNDARY-END(206158888996)
            
            //--TRIMMABLE-BOUNDARY-START(176094117924)
            static /*IQueryable<TSource?> */ DefaultIfEmpty$1(TSource, /*this IQueryable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094117924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.DefaultIfEmpty$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(176094117924)
            
            //--TRIMMABLE-BOUNDARY-START(171799150628)
            static /*IQueryable<TSource> */ DefaultIfEmpty(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ defaultValue)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799150628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.DefaultIfEmpty).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(defaultValue, TSource), TSource.$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(171799150628)
            
            //--TRIMMABLE-BOUNDARY-START(154619281444)
            static /*bool */ Contains$1(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ item)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619281444);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, $.$$.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Contains$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(item, TSource), TSource.$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(154619281444)
            
            //--TRIMMABLE-BOUNDARY-START(150324314148)
            static /*bool */ Contains(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ item, /*IEqualityComparer<TSource>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324314148);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, $.$$.System.Collections.Generic.IEqualityComparer$$(TSource), $.$$.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Contains).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(item, TSource), TSource.$type), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(150324314148)
            
            //--TRIMMABLE-BOUNDARY-START(481036795940)
            static /*IQueryable<TSource> */ Reverse(TSource, /*this IQueryable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481036795940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Reverse).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(481036795940)
            
            //--TRIMMABLE-BOUNDARY-START(523986468900)
            static /*bool */ SequenceEqual$1(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(523986468900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$$.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SequenceEqual$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2)));
            }
            //--TRIMMABLE-BOUNDARY-END(523986468900)
            
            //--TRIMMABLE-BOUNDARY-START(519691501604)
            static /*bool */ SequenceEqual(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*IEqualityComparer<TSource>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519691501604);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$$.System.Collections.Generic.IEqualityComparer$$(TSource), $.$$.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SequenceEqual).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(519691501604)
            
            //--TRIMMABLE-BOUNDARY-START(528281436196)
            static /*IQueryable<TSource> */ Shuffle(TSource, /*this IQueryable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528281436196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Shuffle).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(528281436196)
            
            //--TRIMMABLE-BOUNDARY-START(34360197156)
            static /*bool */ Any$1(TSource, /*this IQueryable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Any$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(34360197156)
            
            //--TRIMMABLE-BOUNDARY-START(30065229860)
            static /*bool */ Any(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), $.$$.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Any).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            //--TRIMMABLE-BOUNDARY-END(30065229860)
            
            //--TRIMMABLE-BOUNDARY-START(25770262564)
            static /*bool */ All(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770262564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), $.$$.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.All).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            //--TRIMMABLE-BOUNDARY-END(25770262564)
            
            //--TRIMMABLE-BOUNDARY-START(163209216036)
            static /*int */ Count$1(TSource, /*this IQueryable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209216036);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Int32, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int32))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Count$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(163209216036)
            
            //--TRIMMABLE-BOUNDARY-START(158914248740)
            static /*int */ Count(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914248740);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Int32, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), $.$$.System.Int32))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Count).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            //--TRIMMABLE-BOUNDARY-END(158914248740)
            
            //--TRIMMABLE-BOUNDARY-START(167504183332)
            static /*IQueryable<KeyValuePair<TKey, int>> */ CountBy(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504183332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, $.$$.System.Int32), $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, $.$$.System.Int32))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.CountBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(167504183332)
            
            //--TRIMMABLE-BOUNDARY-START(382252548132)
            static /*long */ LongCount$1(TSource, /*this IQueryable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382252548132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Int64, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int64))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LongCount$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(382252548132)
            
            //--TRIMMABLE-BOUNDARY-START(377957580836)
            static /*long */ LongCount(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377957580836);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Int64, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), $.$$.System.Int64))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LongCount).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            //--TRIMMABLE-BOUNDARY-END(377957580836)
            
            //--TRIMMABLE-BOUNDARY-START(420907253796)
            static /*TSource? */ Min$2(TSource, /*this IQueryable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420907253796);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Min$2).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(420907253796)
            
            //--TRIMMABLE-BOUNDARY-START(416612286500)
            static /*TSource? */ Min$1(TSource, /*this IQueryable<TSource>*/ source, /*IComparer<TSource>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612286500);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IComparer$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Min$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TSource).$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(416612286500)
            
            //--TRIMMABLE-BOUNDARY-START(412317319204)
            static /*TResult? */ Min(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TResult>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412317319204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TResult)), TResult))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Min).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(412317319204)
            
            //--TRIMMABLE-BOUNDARY-START(433792155684)
            static /*TSource? */ MinBy$2(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433792155684);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MinBy$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            //--TRIMMABLE-BOUNDARY-END(433792155684)
            
            //--TRIMMABLE-BOUNDARY-START(429497188388)
            static /*TSource? */ MinBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TSource>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429497188388);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IComparer$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MinBy$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TSource).$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(429497188388)
            
            //--TRIMMABLE-BOUNDARY-START(425202221092)
            static /*TSource? */ MinBy(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425202221092);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IComparer$$(TKey), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MinBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TKey).$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(425202221092)
            
            //--TRIMMABLE-BOUNDARY-START(395137450020)
            static /*TSource? */ Max$2(TSource, /*this IQueryable<TSource>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395137450020);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Max$2).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(395137450020)
            
            //--TRIMMABLE-BOUNDARY-START(390842482724)
            static /*TSource? */ Max$1(TSource, /*this IQueryable<TSource>*/ source, /*IComparer<TSource>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842482724);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IComparer$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Max$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TSource).$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(390842482724)
            
            //--TRIMMABLE-BOUNDARY-START(386547515428)
            static /*TResult? */ Max(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TResult>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386547515428);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TResult)), TResult))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Max).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(386547515428)
            
            //--TRIMMABLE-BOUNDARY-START(408022351908)
            static /*TSource? */ MaxBy$2(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022351908);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MaxBy$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            //--TRIMMABLE-BOUNDARY-END(408022351908)
            
            //--TRIMMABLE-BOUNDARY-START(403727384612)
            static /*TSource? */ MaxBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TSource>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403727384612);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IComparer$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MaxBy$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TSource).$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(403727384612)
            
            //--TRIMMABLE-BOUNDARY-START(399432417316)
            static /*TSource? */ MaxBy(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399432417316);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IComparer$$(TKey), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MaxBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TKey).$type)));
            }
            //--TRIMMABLE-BOUNDARY-END(399432417316)
            
            //--TRIMMABLE-BOUNDARY-START(584116011044)
            static /*int */ Sum$2(/*this IQueryable<int>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584116011044);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Int32, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Int32), $.$$.System.Int32))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$2).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(584116011044)
            
            //--TRIMMABLE-BOUNDARY-START(601295880228)
            static /*int? */ Sum$6(/*this IQueryable<int?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(601295880228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Int32), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Int32)), $.$$.System.Nullable$$($.$$.System.Int32)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$6).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(601295880228)
            
            //--TRIMMABLE-BOUNDARY-START(588410978340)
            static /*long */ Sum$3(/*this IQueryable<long>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(588410978340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Int64, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Int64), $.$$.System.Int64))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$3).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(588410978340)
            
            //--TRIMMABLE-BOUNDARY-START(605590847524)
            static /*long? */ Sum$7(/*this IQueryable<long?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(605590847524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Int64), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Int64)), $.$$.System.Nullable$$($.$$.System.Int64)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$7).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(605590847524)
            
            //--TRIMMABLE-BOUNDARY-START(614180782116)
            static /*float */ Sum$9(/*this IQueryable<float>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(614180782116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Single, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Single), $.$$.System.Single))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$9).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(614180782116)
            
            //--TRIMMABLE-BOUNDARY-START(609885814820)
            static /*float? */ Sum$8(/*this IQueryable<float?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(609885814820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Single), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Single)), $.$$.System.Nullable$$($.$$.System.Single)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$8).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(609885814820)
            
            //--TRIMMABLE-BOUNDARY-START(579821043748)
            static /*double */ Sum$1(/*this IQueryable<double>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(579821043748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Double), $.$$.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(579821043748)
            
            //--TRIMMABLE-BOUNDARY-START(597000912932)
            static /*double? */ Sum$5(/*this IQueryable<double?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(597000912932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Double)), $.$$.System.Nullable$$($.$$.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$5).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(597000912932)
            
            //--TRIMMABLE-BOUNDARY-START(575526076452)
            static /*decimal */ Sum(/*this IQueryable<decimal>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(575526076452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Decimal, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Decimal), $.$$.System.Decimal))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(575526076452)
            
            //--TRIMMABLE-BOUNDARY-START(592705945636)
            static /*decimal? */ Sum$4(/*this IQueryable<decimal?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(592705945636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Decimal), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Decimal)), $.$$.System.Nullable$$($.$$.System.Decimal)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$4)?.Clone() ?? null.Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(592705945636)
            
            //--TRIMMABLE-BOUNDARY-START(627065684004)
            static /*int */ Sum$12(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(627065684004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Int32, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Int32)), $.$$.System.Int32))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$12).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(627065684004)
            
            //--TRIMMABLE-BOUNDARY-START(644245553188)
            static /*int? */ Sum$16(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int?>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(644245553188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Int32), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Int32))), $.$$.System.Nullable$$($.$$.System.Int32)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$16).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(644245553188)
            
            //--TRIMMABLE-BOUNDARY-START(631360651300)
            static /*long */ Sum$13(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, long>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(631360651300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Int64, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Int64)), $.$$.System.Int64))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$13).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(631360651300)
            
            //--TRIMMABLE-BOUNDARY-START(648540520484)
            static /*long? */ Sum$17(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, long?>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(648540520484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Int64), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Int64))), $.$$.System.Nullable$$($.$$.System.Int64)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$17).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(648540520484)
            
            //--TRIMMABLE-BOUNDARY-START(657130455076)
            static /*float */ Sum$19(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, float>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(657130455076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Single, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Single)), $.$$.System.Single))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$19).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(657130455076)
            
            //--TRIMMABLE-BOUNDARY-START(652835487780)
            static /*float? */ Sum$18(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, float?>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(652835487780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Single), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Single))), $.$$.System.Nullable$$($.$$.System.Single)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$18).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(652835487780)
            
            //--TRIMMABLE-BOUNDARY-START(622770716708)
            static /*double */ Sum$11(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, double>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(622770716708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Double)), $.$$.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$11).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(622770716708)
            
            //--TRIMMABLE-BOUNDARY-START(639950585892)
            static /*double? */ Sum$15(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, double?>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(639950585892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Double))), $.$$.System.Nullable$$($.$$.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$15).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(639950585892)
            
            //--TRIMMABLE-BOUNDARY-START(618475749412)
            static /*decimal */ Sum$10(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, decimal>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(618475749412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Decimal, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Decimal)), $.$$.System.Decimal))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$10).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(618475749412)
            
            //--TRIMMABLE-BOUNDARY-START(635655618596)
            static /*decimal? */ Sum$14(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, decimal?>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(635655618596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Decimal), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Decimal))), $.$$.System.Nullable$$($.$$.System.Decimal)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$14)?.Clone() ?? null.Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(635655618596)
            
            //--TRIMMABLE-BOUNDARY-START(60130000932)
            static /*double */ Average$2(/*this IQueryable<int>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130000932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Int32), $.$$.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$2).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(60130000932)
            
            //--TRIMMABLE-BOUNDARY-START(77309870116)
            static /*double? */ Average$6(/*this IQueryable<int?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309870116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Int32)), $.$$.System.Nullable$$($.$$.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$6).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(77309870116)
            
            //--TRIMMABLE-BOUNDARY-START(64424968228)
            static /*double */ Average$3(/*this IQueryable<long>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424968228);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Int64), $.$$.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$3).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(64424968228)
            
            //--TRIMMABLE-BOUNDARY-START(81604837412)
            static /*double? */ Average$7(/*this IQueryable<long?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604837412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Int64)), $.$$.System.Nullable$$($.$$.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$7).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(81604837412)
            
            //--TRIMMABLE-BOUNDARY-START(90194772004)
            static /*float */ Average$9(/*this IQueryable<float>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194772004);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Single, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Single), $.$$.System.Single))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$9).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(90194772004)
            
            //--TRIMMABLE-BOUNDARY-START(85899804708)
            static /*float? */ Average$8(/*this IQueryable<float?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899804708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Single), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Single)), $.$$.System.Nullable$$($.$$.System.Single)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$8).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(85899804708)
            
            //--TRIMMABLE-BOUNDARY-START(55835033636)
            static /*double */ Average$1(/*this IQueryable<double>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835033636);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Double), $.$$.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(55835033636)
            
            //--TRIMMABLE-BOUNDARY-START(73014902820)
            static /*double? */ Average$5(/*this IQueryable<double?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014902820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Double)), $.$$.System.Nullable$$($.$$.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$5).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(73014902820)
            
            //--TRIMMABLE-BOUNDARY-START(51540066340)
            static /*decimal */ Average(/*this IQueryable<decimal>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Decimal, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Decimal), $.$$.System.Decimal))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(51540066340)
            
            //--TRIMMABLE-BOUNDARY-START(68719935524)
            static /*decimal? */ Average$4(/*this IQueryable<decimal?>*/ source)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Decimal), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Decimal)), $.$$.System.Nullable$$($.$$.System.Decimal)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$4)?.Clone() ?? null.Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(68719935524)
            
            //--TRIMMABLE-BOUNDARY-START(103079673892)
            static /*double */ Average$12(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079673892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Int32)), $.$$.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$12).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(103079673892)
            
            //--TRIMMABLE-BOUNDARY-START(120259543076)
            static /*double? */ Average$16(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int?>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259543076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Int32))), $.$$.System.Nullable$$($.$$.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$16).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(120259543076)
            
            //--TRIMMABLE-BOUNDARY-START(133144444964)
            static /*float */ Average$19(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, float>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144444964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Single, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Single)), $.$$.System.Single))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$19).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(133144444964)
            
            //--TRIMMABLE-BOUNDARY-START(128849477668)
            static /*float? */ Average$18(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, float?>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849477668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Single), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Single))), $.$$.System.Nullable$$($.$$.System.Single)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$18).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(128849477668)
            
            //--TRIMMABLE-BOUNDARY-START(107374641188)
            static /*double */ Average$13(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, long>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374641188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Int64)), $.$$.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$13).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(107374641188)
            
            //--TRIMMABLE-BOUNDARY-START(124554510372)
            static /*double? */ Average$17(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, long?>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554510372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Int64))), $.$$.System.Nullable$$($.$$.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$17).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(124554510372)
            
            //--TRIMMABLE-BOUNDARY-START(98784706596)
            static /*double */ Average$11(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, double>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784706596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Double)), $.$$.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$11).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(98784706596)
            
            //--TRIMMABLE-BOUNDARY-START(115964575780)
            static /*double? */ Average$15(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, double?>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964575780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Double))), $.$$.System.Nullable$$($.$$.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$15).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(115964575780)
            
            //--TRIMMABLE-BOUNDARY-START(94489739300)
            static /*decimal */ Average$10(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, decimal>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Decimal, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Decimal)), $.$$.System.Decimal))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$10).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(94489739300)
            
            //--TRIMMABLE-BOUNDARY-START(111669608484)
            static /*decimal? */ Average$14(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, decimal?>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Decimal), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Decimal))), $.$$.System.Nullable$$($.$$.System.Decimal)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$14)?.Clone() ?? null.Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            //--TRIMMABLE-BOUNDARY-END(111669608484)
            
            //--TRIMMABLE-BOUNDARY-START(12885360676)
            static /*TSource */ Aggregate$2(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TSource, TSource>>*/ func)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(func, "func");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, TSource, TSource)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Aggregate$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(func)));
            }
            //--TRIMMABLE-BOUNDARY-END(12885360676)
            
            //--TRIMMABLE-BOUNDARY-START(8590393380)
            static /*TAccumulate */ Aggregate$1(TSource, TAccumulate, /*this IQueryable<TSource>*/ source, /*TAccumulate*/ seed, /*Expression<Func<TAccumulate, TSource, TAccumulate>>*/ func)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(func, "func");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TAccumulate, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), TAccumulate, $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TAccumulate, TSource, TAccumulate)), TAccumulate))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Aggregate$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(seed, TAccumulate)), $.$sle.System.Linq.Expressions.Expression.Quote(func)));
            }
            //--TRIMMABLE-BOUNDARY-END(8590393380)
            
            //--TRIMMABLE-BOUNDARY-START(4295426084)
            static /*TResult */ Aggregate(TSource, TAccumulate, TResult, /*this IQueryable<TSource>*/ source, /*TAccumulate*/ seed, /*Expression<Func<TAccumulate, TSource, TAccumulate>>*/ func, /*Expression<Func<TAccumulate, TResult>>*/ selector)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295426084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(func, "func");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), TAccumulate, $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TAccumulate, TSource, TAccumulate)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TAccumulate, TResult)), TResult))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Aggregate).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(seed, TAccumulate)), $.$sle.System.Linq.Expressions.Expression.Quote(func), $.$sle.System.Linq.Expressions.Expression.Quote(selector) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(4295426084)
            
            //--TRIMMABLE-BOUNDARY-START(21475295268)
            static /*IQueryable<KeyValuePair<TKey, TAccumulate>> */ AggregateBy$1(TSource, TKey, TAccumulate, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*TAccumulate*/ seed, /*Expression<Func<TAccumulate, TSource, TAccumulate>>*/ func, /*IEqualityComparer<TKey>?*/ keyComparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(func, "func");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), TAccumulate, $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TAccumulate, TSource, TAccumulate)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.AggregateBy$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(seed, TAccumulate)), $.$sle.System.Linq.Expressions.Expression.Quote(func), $.$sle.System.Linq.Expressions.Expression.Constant(keyComparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(21475295268)
            
            //--TRIMMABLE-BOUNDARY-START(17180327972)
            static /*IQueryable<KeyValuePair<TKey, TAccumulate>> */ AggregateBy(TSource, TKey, TAccumulate, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TKey, TAccumulate>>*/ seedSelector, /*Expression<Func<TAccumulate, TSource, TAccumulate>>*/ func, /*IEqualityComparer<TKey>?*/ keyComparer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180327972);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(seedSelector, "seedSelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(func, "func");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TKey, TAccumulate)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TAccumulate, TSource, TAccumulate)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.AggregateBy).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(seedSelector), $.$sle.System.Linq.Expressions.Expression.Quote(func), $.$sle.System.Linq.Expressions.Expression.Constant(keyComparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            //--TRIMMABLE-BOUNDARY-END(17180327972)
            
            //--TRIMMABLE-BOUNDARY-START(562641174564)
            static /*IQueryable<TSource> */ SkipLast(TSource, /*this IQueryable<TSource>*/ source, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(562641174564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int32, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SkipLast).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(count, $.$$.System.Int32))));
            }
            //--TRIMMABLE-BOUNDARY-END(562641174564)
            
            //--TRIMMABLE-BOUNDARY-START(670015356964)
            static /*IQueryable<TSource> */ TakeLast(TSource, /*this IQueryable<TSource>*/ source, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(670015356964);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int32, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.TakeLast).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(count, $.$$.System.Int32))));
            }
            //--TRIMMABLE-BOUNDARY-END(670015356964)
            
            //--TRIMMABLE-BOUNDARY-START(38655164452)
            static /*IQueryable<TSource> */ Append(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ element)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Append).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(element, TSource))));
            }
            //--TRIMMABLE-BOUNDARY-END(38655164452)
            
            //--TRIMMABLE-BOUNDARY-START(476741828644)
            static /*IQueryable<TSource> */ Prepend(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ element)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476741828644);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Prepend).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(element, TSource))));
            }
            //--TRIMMABLE-BOUNDARY-END(476741828644)
            
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(313533071396)
                    this.InMemoryQueryableExtensionMethodsRequiresUnreferencedCode = "Enumerating in-memory collections as IQueryable can require unreferenced code because expressions referencing IQueryable extension methods can get rebound to IEnumerable extension methods. The IEnumerable extension methods could be trimmed causing the application to fail at runtime.";
                    //--TRIMMABLE-BOUNDARY-END(313533071396)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(309238104100)
                    this.InMemoryQueryableExtensionMethodsRequiresDynamicCode = "Enumerating in-memory collections as IQueryable can require creating new generic types or methods, which requires creating code at runtime. This may not work when AOT compiling.";
                    //--TRIMMABLE-BOUNDARY-END(309238104100)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 458788;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(47245099044),
    {
      "r": (TElement) => $.$sle.System.Linq.IQueryable$$(TElement).$h,
      "p": [
        {
          "n": "source",
          "p": (TElement) => $.$$.System.Collections.Generic.IEnumerable$$(TElement).$h
        }
      ],
      "g": [
        "TElement"
      ],
      "n": "AsQueryable",
      "o": "@$1",
      "d": 458788,
      "h": 47245099044,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(47245099044),
//--TRIMMABLE-BOUNDARY-START(42950131748),
    {
      "r": 42467365,
      "p": [
        {
          "n": "source",
          "p": 62652417
        }
      ],
      "n": "AsQueryable",
      "d": 458788,
      "h": 42950131748,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950131748),
//--TRIMMABLE-BOUNDARY-START(717259997220),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Where",
      "d": 458788,
      "h": 717259997220,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(717259997220),
//--TRIMMABLE-BOUNDARY-START(721554964516),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Boolean)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Where",
      "o": "@$1",
      "d": 458788,
      "h": 721554964516,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(721554964516),
//--TRIMMABLE-BOUNDARY-START(438087122980),
    {
      "r": (TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "source",
          "p": 42467365
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "OfType",
      "d": 458788,
      "h": 438087122980,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(438087122980),
//--TRIMMABLE-BOUNDARY-START(137439412260),
    {
      "r": (TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "source",
          "p": 42467365
        }
      ],
      "g": [
        "TResult"
      ],
      "n": "Cast",
      "d": 458788,
      "h": 137439412260,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(137439412260),
//--TRIMMABLE-BOUNDARY-START(498216665124),
    {
      "r": (TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TResult)).$h
        }
      ],
      "g": [
        "TSource",
        "TResult"
      ],
      "n": "Select",
      "o": "@$1",
      "d": 458788,
      "h": 498216665124,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(498216665124),
//--TRIMMABLE-BOUNDARY-START(493921697828),
    {
      "r": (TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, TResult)).$h
        }
      ],
      "g": [
        "TSource",
        "TResult"
      ],
      "n": "Select",
      "d": 458788,
      "h": 493921697828,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(493921697828),
//--TRIMMABLE-BOUNDARY-START(511101567012),
    {
      "r": (TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Collections.Generic.IEnumerable$$(TResult))).$h
        }
      ],
      "g": [
        "TSource",
        "TResult"
      ],
      "n": "SelectMany",
      "o": "@$2",
      "d": 458788,
      "h": 511101567012,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(511101567012),
//--TRIMMABLE-BOUNDARY-START(515396534308),
    {
      "r": (TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Collections.Generic.IEnumerable$$(TResult))).$h
        }
      ],
      "g": [
        "TSource",
        "TResult"
      ],
      "n": "SelectMany",
      "o": "@$3",
      "d": 458788,
      "h": 515396534308,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(515396534308),
//--TRIMMABLE-BOUNDARY-START(506806599716),
    {
      "r": (TSource, TCollection, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TCollection, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "collectionSelector",
          "p": (TSource, TCollection, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Collections.Generic.IEnumerable$$(TCollection))).$h
        },
        {
          "n": "resultSelector",
          "p": (TSource, TCollection, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, TCollection, TResult)).$h
        }
      ],
      "g": [
        "TSource",
        "TCollection",
        "TResult"
      ],
      "n": "SelectMany",
      "o": "@$1",
      "d": 458788,
      "h": 506806599716,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(506806599716),
//--TRIMMABLE-BOUNDARY-START(502511632420),
    {
      "r": (TSource, TCollection, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TCollection, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "collectionSelector",
          "p": (TSource, TCollection, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Collections.Generic.IEnumerable$$(TCollection))).$h
        },
        {
          "n": "resultSelector",
          "p": (TSource, TCollection, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, TCollection, TResult)).$h
        }
      ],
      "g": [
        "TSource",
        "TCollection",
        "TResult"
      ],
      "n": "SelectMany",
      "d": 458788,
      "h": 502511632420,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(502511632420),
//--TRIMMABLE-BOUNDARY-START(257698496548),
    {
      "r": 8781861,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "GetSourceExpression",
      "d": 458788,
      "h": 257698496548,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(257698496548),
//--TRIMMABLE-BOUNDARY-START(339302875172),
    {
      "r": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "outer",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h
        },
        {
          "n": "inner",
          "p": (TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TInner).$h
        },
        {
          "n": "outerKeySelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)).$h
        },
        {
          "n": "innerKeySelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)).$h
        },
        {
          "n": "resultSelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)).$h
        }
      ],
      "g": [
        "TOuter",
        "TInner",
        "TKey",
        "TResult"
      ],
      "n": "Join",
      "o": "@$1",
      "d": 458788,
      "h": 339302875172,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(339302875172),
//--TRIMMABLE-BOUNDARY-START(335007907876),
    {
      "r": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "outer",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h
        },
        {
          "n": "inner",
          "p": (TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TInner).$h
        },
        {
          "n": "outerKeySelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)).$h
        },
        {
          "n": "innerKeySelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)).$h
        },
        {
          "n": "resultSelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)).$h
        },
        {
          "n": "comparer",
          "p": (TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "g": [
        "TOuter",
        "TInner",
        "TKey",
        "TResult"
      ],
      "n": "Join",
      "d": 458788,
      "h": 335007907876,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(335007907876),
//--TRIMMABLE-BOUNDARY-START(300648169508),
    {
      "r": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "outer",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h
        },
        {
          "n": "inner",
          "p": (TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TInner).$h
        },
        {
          "n": "outerKeySelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)).$h
        },
        {
          "n": "innerKeySelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)).$h
        },
        {
          "n": "resultSelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, $.$$.System.Collections.Generic.IEnumerable$$(TInner), TResult)).$h
        }
      ],
      "g": [
        "TOuter",
        "TInner",
        "TKey",
        "TResult"
      ],
      "n": "GroupJoin",
      "o": "@$1",
      "d": 458788,
      "h": 300648169508,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(300648169508),
//--TRIMMABLE-BOUNDARY-START(296353202212),
    {
      "r": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "outer",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h
        },
        {
          "n": "inner",
          "p": (TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TInner).$h
        },
        {
          "n": "outerKeySelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)).$h
        },
        {
          "n": "innerKeySelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)).$h
        },
        {
          "n": "resultSelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, $.$$.System.Collections.Generic.IEnumerable$$(TInner), TResult)).$h
        },
        {
          "n": "comparer",
          "p": (TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "g": [
        "TOuter",
        "TInner",
        "TKey",
        "TResult"
      ],
      "n": "GroupJoin",
      "d": 458788,
      "h": 296353202212,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(296353202212),
//--TRIMMABLE-BOUNDARY-START(373662613540),
    {
      "r": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "outer",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h
        },
        {
          "n": "inner",
          "p": (TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TInner).$h
        },
        {
          "n": "outerKeySelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)).$h
        },
        {
          "n": "innerKeySelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)).$h
        },
        {
          "n": "resultSelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)).$h
        }
      ],
      "g": [
        "TOuter",
        "TInner",
        "TKey",
        "TResult"
      ],
      "n": "LeftJoin",
      "o": "@$1",
      "d": 458788,
      "h": 373662613540,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(373662613540),
//--TRIMMABLE-BOUNDARY-START(369367646244),
    {
      "r": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "outer",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h
        },
        {
          "n": "inner",
          "p": (TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TInner).$h
        },
        {
          "n": "outerKeySelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)).$h
        },
        {
          "n": "innerKeySelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)).$h
        },
        {
          "n": "resultSelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)).$h
        },
        {
          "n": "comparer",
          "p": (TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "g": [
        "TOuter",
        "TInner",
        "TKey",
        "TResult"
      ],
      "n": "LeftJoin",
      "d": 458788,
      "h": 369367646244,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(369367646244),
//--TRIMMABLE-BOUNDARY-START(446677057572),
    {
      "r": (T) => $.$sle.System.Linq.IOrderedQueryable$$(T).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$sle.System.Linq.IQueryable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Order",
      "o": "@$1",
      "d": 458788,
      "h": 446677057572,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(446677057572),
//--TRIMMABLE-BOUNDARY-START(442382090276),
    {
      "r": (T) => $.$sle.System.Linq.IOrderedQueryable$$(T).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$sle.System.Linq.IQueryable$$(T).$h
        },
        {
          "n": "comparer",
          "p": (T) => $.$$.System.Collections.Generic.IComparer$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Order",
      "d": 458788,
      "h": 442382090276,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(442382090276),
//--TRIMMABLE-BOUNDARY-START(455266992164),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "OrderBy",
      "o": "@$1",
      "d": 458788,
      "h": 455266992164,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(455266992164),
//--TRIMMABLE-BOUNDARY-START(450972024868),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IComparer$$(TKey).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "OrderBy",
      "d": 458788,
      "h": 450972024868,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(450972024868),
//--TRIMMABLE-BOUNDARY-START(472446861348),
    {
      "r": (T) => $.$sle.System.Linq.IOrderedQueryable$$(T).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$sle.System.Linq.IQueryable$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "OrderDescending",
      "o": "@$1",
      "d": 458788,
      "h": 472446861348,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(472446861348),
//--TRIMMABLE-BOUNDARY-START(468151894052),
    {
      "r": (T) => $.$sle.System.Linq.IOrderedQueryable$$(T).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$sle.System.Linq.IQueryable$$(T).$h
        },
        {
          "n": "comparer",
          "p": (T) => $.$$.System.Collections.Generic.IComparer$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "OrderDescending",
      "d": 458788,
      "h": 468151894052,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(468151894052),
//--TRIMMABLE-BOUNDARY-START(463856926756),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "OrderByDescending",
      "o": "@$1",
      "d": 458788,
      "h": 463856926756,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(463856926756),
//--TRIMMABLE-BOUNDARY-START(459561959460),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IComparer$$(TKey).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "OrderByDescending",
      "d": 458788,
      "h": 459561959460,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(459561959460),
//--TRIMMABLE-BOUNDARY-START(489626730532),
    {
      "r": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "outer",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h
        },
        {
          "n": "inner",
          "p": (TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TInner).$h
        },
        {
          "n": "outerKeySelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)).$h
        },
        {
          "n": "innerKeySelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)).$h
        },
        {
          "n": "resultSelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)).$h
        }
      ],
      "g": [
        "TOuter",
        "TInner",
        "TKey",
        "TResult"
      ],
      "n": "RightJoin",
      "o": "@$1",
      "d": 458788,
      "h": 489626730532,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(489626730532),
//--TRIMMABLE-BOUNDARY-START(485331763236),
    {
      "r": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "outer",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h
        },
        {
          "n": "inner",
          "p": (TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TInner).$h
        },
        {
          "n": "outerKeySelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)).$h
        },
        {
          "n": "innerKeySelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)).$h
        },
        {
          "n": "resultSelector",
          "p": (TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)).$h
        },
        {
          "n": "comparer",
          "p": (TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "g": [
        "TOuter",
        "TInner",
        "TKey",
        "TResult"
      ],
      "n": "RightJoin",
      "d": 458788,
      "h": 485331763236,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(485331763236),
//--TRIMMABLE-BOUNDARY-START(687195226148),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "ThenBy",
      "o": "@$1",
      "d": 458788,
      "h": 687195226148,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(687195226148),
//--TRIMMABLE-BOUNDARY-START(682900258852),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IComparer$$(TKey).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "ThenBy",
      "d": 458788,
      "h": 682900258852,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(682900258852),
//--TRIMMABLE-BOUNDARY-START(695785160740),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "ThenByDescending",
      "o": "@$1",
      "d": 458788,
      "h": 695785160740,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(695785160740),
//--TRIMMABLE-BOUNDARY-START(691490193444),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IComparer$$(TKey).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "ThenByDescending",
      "d": 458788,
      "h": 691490193444,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(691490193444),
//--TRIMMABLE-BOUNDARY-START(661425422372),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Take",
      "d": 458788,
      "h": 661425422372,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(661425422372),
//--TRIMMABLE-BOUNDARY-START(665720389668),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "range",
          "p": 105906177
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Take",
      "o": "@$1",
      "d": 458788,
      "h": 665720389668,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(665720389668),
//--TRIMMABLE-BOUNDARY-START(674310324260),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "TakeWhile",
      "d": 458788,
      "h": 674310324260,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(674310324260),
//--TRIMMABLE-BOUNDARY-START(678605291556),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Boolean)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "TakeWhile",
      "o": "@$1",
      "d": 458788,
      "h": 678605291556,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(678605291556),
//--TRIMMABLE-BOUNDARY-START(558346207268),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Skip",
      "d": 458788,
      "h": 558346207268,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(558346207268),
//--TRIMMABLE-BOUNDARY-START(566936141860),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "SkipWhile",
      "d": 458788,
      "h": 566936141860,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(566936141860),
//--TRIMMABLE-BOUNDARY-START(571231109156),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Boolean)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "SkipWhile",
      "o": "@$1",
      "d": 458788,
      "h": 571231109156,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(571231109156),
//--TRIMMABLE-BOUNDARY-START(292058234916),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TSource)).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "GroupBy",
      "o": "@$7",
      "d": 458788,
      "h": 292058234916,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(292058234916),
//--TRIMMABLE-BOUNDARY-START(274878365732),
    {
      "r": (TSource, TKey, TElement) => $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey, TElement) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey, TElement) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "elementSelector",
          "p": (TSource, TKey, TElement) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TElement)).$h
        }
      ],
      "g": [
        "TSource",
        "TKey",
        "TElement"
      ],
      "n": "GroupBy",
      "o": "@$3",
      "d": 458788,
      "h": 274878365732,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(274878365732),
//--TRIMMABLE-BOUNDARY-START(287763267620),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TSource)).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "GroupBy",
      "o": "@$6",
      "d": 458788,
      "h": 287763267620,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(287763267620),
//--TRIMMABLE-BOUNDARY-START(270583398436),
    {
      "r": (TSource, TKey, TElement) => $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey, TElement) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey, TElement) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "elementSelector",
          "p": (TSource, TKey, TElement) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TElement)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey, TElement) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "g": [
        "TSource",
        "TKey",
        "TElement"
      ],
      "n": "GroupBy",
      "o": "@$2",
      "d": 458788,
      "h": 270583398436,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(270583398436),
//--TRIMMABLE-BOUNDARY-START(266288431140),
    {
      "r": (TSource, TKey, TElement, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey, TElement, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "elementSelector",
          "p": (TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TElement)).$h
        },
        {
          "n": "resultSelector",
          "p": (TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TKey, $.$$.System.Collections.Generic.IEnumerable$$(TElement), TResult)).$h
        }
      ],
      "g": [
        "TSource",
        "TKey",
        "TElement",
        "TResult"
      ],
      "n": "GroupBy",
      "o": "@$1",
      "d": 458788,
      "h": 266288431140,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(266288431140),
//--TRIMMABLE-BOUNDARY-START(283468300324),
    {
      "r": (TSource, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "resultSelector",
          "p": (TSource, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TKey, $.$$.System.Collections.Generic.IEnumerable$$(TSource), TResult)).$h
        }
      ],
      "g": [
        "TSource",
        "TKey",
        "TResult"
      ],
      "n": "GroupBy",
      "o": "@$5",
      "d": 458788,
      "h": 283468300324,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(283468300324),
//--TRIMMABLE-BOUNDARY-START(279173333028),
    {
      "r": (TSource, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "resultSelector",
          "p": (TSource, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TKey, $.$$.System.Collections.Generic.IEnumerable$$(TSource), TResult)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey, TResult) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "g": [
        "TSource",
        "TKey",
        "TResult"
      ],
      "n": "GroupBy",
      "o": "@$4",
      "d": 458788,
      "h": 279173333028,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(279173333028),
//--TRIMMABLE-BOUNDARY-START(261993463844),
    {
      "r": (TSource, TKey, TElement, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey, TElement, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "elementSelector",
          "p": (TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TElement)).$h
        },
        {
          "n": "resultSelector",
          "p": (TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TKey, $.$$.System.Collections.Generic.IEnumerable$$(TElement), TResult)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey, TElement, TResult) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "g": [
        "TSource",
        "TKey",
        "TElement",
        "TResult"
      ],
      "n": "GroupBy",
      "d": 458788,
      "h": 261993463844,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(261993463844),
//--TRIMMABLE-BOUNDARY-START(184684052516),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Distinct",
      "o": "@$1",
      "d": 458788,
      "h": 184684052516,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(184684052516),
//--TRIMMABLE-BOUNDARY-START(180389085220),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "comparer",
          "p": (TSource) => $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Distinct",
      "d": 458788,
      "h": 180389085220,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(180389085220),
//--TRIMMABLE-BOUNDARY-START(193273987108),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "DistinctBy",
      "o": "@$1",
      "d": 458788,
      "h": 193273987108,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(193273987108),
//--TRIMMABLE-BOUNDARY-START(188979019812),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "DistinctBy",
      "d": 458788,
      "h": 188979019812,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(188979019812),
//--TRIMMABLE-BOUNDARY-START(141734379556),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$($.$typeArray(TSource)).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "size",
          "p": 655361
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Chunk",
      "d": 458788,
      "h": 141734379556,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(141734379556),
//--TRIMMABLE-BOUNDARY-START(146029346852),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source1",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "source2",
          "p": (TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Concat",
      "d": 458788,
      "h": 146029346852,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(146029346852),
//--TRIMMABLE-BOUNDARY-START(734439866404),
    {
      "r": (TFirst, TSecond) => $.$sle.System.Linq.IQueryable$$($.$$.System.ValueTuple$$$(TFirst, TSecond)).$h,
      "p": [
        {
          "n": "source1",
          "p": (TFirst, TSecond) => $.$sle.System.Linq.IQueryable$$(TFirst).$h
        },
        {
          "n": "source2",
          "p": (TFirst, TSecond) => $.$$.System.Collections.Generic.IEnumerable$$(TSecond).$h
        }
      ],
      "g": [
        "TFirst",
        "TSecond"
      ],
      "n": "Zip",
      "o": "@$2",
      "d": 458788,
      "h": 734439866404,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(734439866404),
//--TRIMMABLE-BOUNDARY-START(725849931812),
    {
      "r": (TFirst, TSecond, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,
      "p": [
        {
          "n": "source1",
          "p": (TFirst, TSecond, TResult) => $.$sle.System.Linq.IQueryable$$(TFirst).$h
        },
        {
          "n": "source2",
          "p": (TFirst, TSecond, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TSecond).$h
        },
        {
          "n": "resultSelector",
          "p": (TFirst, TSecond, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TFirst, TSecond, TResult)).$h
        }
      ],
      "g": [
        "TFirst",
        "TSecond",
        "TResult"
      ],
      "n": "Zip",
      "d": 458788,
      "h": 725849931812,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(725849931812),
//--TRIMMABLE-BOUNDARY-START(730144899108),
    {
      "r": (TFirst, TSecond, TThird) => $.$sle.System.Linq.IQueryable$$($.$$.System.ValueTuple$$$$(TFirst, TSecond, TThird)).$h,
      "p": [
        {
          "n": "source1",
          "p": (TFirst, TSecond, TThird) => $.$sle.System.Linq.IQueryable$$(TFirst).$h
        },
        {
          "n": "source2",
          "p": (TFirst, TSecond, TThird) => $.$$.System.Collections.Generic.IEnumerable$$(TSecond).$h
        },
        {
          "n": "source3",
          "p": (TFirst, TSecond, TThird) => $.$$.System.Collections.Generic.IEnumerable$$(TThird).$h
        }
      ],
      "g": [
        "TFirst",
        "TSecond",
        "TThird"
      ],
      "n": "Zip",
      "o": "@$1",
      "d": 458788,
      "h": 730144899108,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(730144899108),
//--TRIMMABLE-BOUNDARY-START(704375095332),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source1",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "source2",
          "p": (TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Union",
      "o": "@$1",
      "d": 458788,
      "h": 704375095332,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(704375095332),
//--TRIMMABLE-BOUNDARY-START(700080128036),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source1",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "source2",
          "p": (TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h
        },
        {
          "n": "comparer",
          "p": (TSource) => $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Union",
      "d": 458788,
      "h": 700080128036,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(700080128036),
//--TRIMMABLE-BOUNDARY-START(712965029924),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source1",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "source2",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "UnionBy",
      "o": "@$1",
      "d": 458788,
      "h": 712965029924,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(712965029924),
//--TRIMMABLE-BOUNDARY-START(708670062628),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source1",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "source2",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "UnionBy",
      "d": 458788,
      "h": 708670062628,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(708670062628),
//--TRIMMABLE-BOUNDARY-START(304943136804),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TSource)).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Index",
      "d": 458788,
      "h": 304943136804,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(304943136804),
//--TRIMMABLE-BOUNDARY-START(322123005988),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source1",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "source2",
          "p": (TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Intersect",
      "o": "@$1",
      "d": 458788,
      "h": 322123005988,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(322123005988),
//--TRIMMABLE-BOUNDARY-START(317828038692),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source1",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "source2",
          "p": (TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h
        },
        {
          "n": "comparer",
          "p": (TSource) => $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Intersect",
      "d": 458788,
      "h": 317828038692,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(317828038692),
//--TRIMMABLE-BOUNDARY-START(330712940580),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source1",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "source2",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IEnumerable$$(TKey).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "IntersectBy",
      "o": "@$1",
      "d": 458788,
      "h": 330712940580,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(330712940580),
//--TRIMMABLE-BOUNDARY-START(326417973284),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source1",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "source2",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IEnumerable$$(TKey).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "IntersectBy",
      "d": 458788,
      "h": 326417973284,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(326417973284),
//--TRIMMABLE-BOUNDARY-START(219043790884),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source1",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "source2",
          "p": (TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Except",
      "o": "@$1",
      "d": 458788,
      "h": 219043790884,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(219043790884),
//--TRIMMABLE-BOUNDARY-START(214748823588),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source1",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "source2",
          "p": (TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h
        },
        {
          "n": "comparer",
          "p": (TSource) => $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Except",
      "d": 458788,
      "h": 214748823588,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(214748823588),
//--TRIMMABLE-BOUNDARY-START(227633725476),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source1",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "source2",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IEnumerable$$(TKey).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "ExceptBy",
      "o": "@$1",
      "d": 458788,
      "h": 227633725476,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(227633725476),
//--TRIMMABLE-BOUNDARY-START(223338758180),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source1",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "source2",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IEnumerable$$(TKey).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "ExceptBy",
      "d": 458788,
      "h": 223338758180,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(223338758180),
//--TRIMMABLE-BOUNDARY-START(236223660068),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "First",
      "o": "@$1",
      "d": 458788,
      "h": 236223660068,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(236223660068),
//--TRIMMABLE-BOUNDARY-START(231928692772),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "First",
      "d": 458788,
      "h": 231928692772,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(231928692772),
//--TRIMMABLE-BOUNDARY-START(253403529252),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "FirstOrDefault",
      "o": "@$3",
      "d": 458788,
      "h": 253403529252,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(253403529252),
//--TRIMMABLE-BOUNDARY-START(249108561956),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "defaultValue",
          "p": (TSource) => TSource.$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "FirstOrDefault",
      "o": "@$2",
      "d": 458788,
      "h": 249108561956,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(249108561956),
//--TRIMMABLE-BOUNDARY-START(244813594660),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "FirstOrDefault",
      "o": "@$1",
      "d": 458788,
      "h": 244813594660,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(244813594660),
//--TRIMMABLE-BOUNDARY-START(240518627364),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h
        },
        {
          "n": "defaultValue",
          "p": (TSource) => TSource.$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "FirstOrDefault",
      "d": 458788,
      "h": 240518627364,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(240518627364),
//--TRIMMABLE-BOUNDARY-START(347892809764),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Last",
      "o": "@$1",
      "d": 458788,
      "h": 347892809764,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(347892809764),
//--TRIMMABLE-BOUNDARY-START(343597842468),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Last",
      "d": 458788,
      "h": 343597842468,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(343597842468),
//--TRIMMABLE-BOUNDARY-START(365072678948),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "LastOrDefault",
      "o": "@$3",
      "d": 458788,
      "h": 365072678948,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(365072678948),
//--TRIMMABLE-BOUNDARY-START(360777711652),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "defaultValue",
          "p": (TSource) => TSource.$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "LastOrDefault",
      "o": "@$2",
      "d": 458788,
      "h": 360777711652,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(360777711652),
//--TRIMMABLE-BOUNDARY-START(356482744356),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "LastOrDefault",
      "o": "@$1",
      "d": 458788,
      "h": 356482744356,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(356482744356),
//--TRIMMABLE-BOUNDARY-START(352187777060),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h
        },
        {
          "n": "defaultValue",
          "p": (TSource) => TSource.$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "LastOrDefault",
      "d": 458788,
      "h": 352187777060,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(352187777060),
//--TRIMMABLE-BOUNDARY-START(536871370788),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Single",
      "o": "@$1",
      "d": 458788,
      "h": 536871370788,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(536871370788),
//--TRIMMABLE-BOUNDARY-START(532576403492),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Single",
      "d": 458788,
      "h": 532576403492,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(532576403492),
//--TRIMMABLE-BOUNDARY-START(554051239972),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "SingleOrDefault",
      "o": "@$3",
      "d": 458788,
      "h": 554051239972,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(554051239972),
//--TRIMMABLE-BOUNDARY-START(549756272676),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "defaultValue",
          "p": (TSource) => TSource.$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "SingleOrDefault",
      "o": "@$2",
      "d": 458788,
      "h": 549756272676,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(549756272676),
//--TRIMMABLE-BOUNDARY-START(545461305380),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "SingleOrDefault",
      "o": "@$1",
      "d": 458788,
      "h": 545461305380,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(545461305380),
//--TRIMMABLE-BOUNDARY-START(541166338084),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h
        },
        {
          "n": "defaultValue",
          "p": (TSource) => TSource.$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "SingleOrDefault",
      "d": 458788,
      "h": 541166338084,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(541166338084),
//--TRIMMABLE-BOUNDARY-START(201863921700),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "ElementAt",
      "o": "@$1",
      "d": 458788,
      "h": 201863921700,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(201863921700),
//--TRIMMABLE-BOUNDARY-START(197568954404),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "index",
          "p": 90636289
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "ElementAt",
      "d": 458788,
      "h": 197568954404,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(197568954404),
//--TRIMMABLE-BOUNDARY-START(210453856292),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "ElementAtOrDefault",
      "o": "@$1",
      "d": 458788,
      "h": 210453856292,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(210453856292),
//--TRIMMABLE-BOUNDARY-START(206158888996),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "index",
          "p": 90636289
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "ElementAtOrDefault",
      "d": 458788,
      "h": 206158888996,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(206158888996),
//--TRIMMABLE-BOUNDARY-START(176094117924),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "DefaultIfEmpty",
      "o": "@$1",
      "d": 458788,
      "h": 176094117924,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(176094117924),
//--TRIMMABLE-BOUNDARY-START(171799150628),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "defaultValue",
          "p": (TSource) => TSource.$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "DefaultIfEmpty",
      "d": 458788,
      "h": 171799150628,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(171799150628),
//--TRIMMABLE-BOUNDARY-START(154619281444),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "item",
          "p": (TSource) => TSource.$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Contains",
      "o": "@$1",
      "d": 458788,
      "h": 154619281444,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(154619281444),
//--TRIMMABLE-BOUNDARY-START(150324314148),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "item",
          "p": (TSource) => TSource.$h
        },
        {
          "n": "comparer",
          "p": (TSource) => $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Contains",
      "d": 458788,
      "h": 150324314148,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(150324314148),
//--TRIMMABLE-BOUNDARY-START(481036795940),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Reverse",
      "d": 458788,
      "h": 481036795940,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(481036795940),
//--TRIMMABLE-BOUNDARY-START(523986468900),
    {
      "r": 262145,
      "p": [
        {
          "n": "source1",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "source2",
          "p": (TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "SequenceEqual",
      "o": "@$1",
      "d": 458788,
      "h": 523986468900,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(523986468900),
//--TRIMMABLE-BOUNDARY-START(519691501604),
    {
      "r": 262145,
      "p": [
        {
          "n": "source1",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "source2",
          "p": (TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h
        },
        {
          "n": "comparer",
          "p": (TSource) => $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "SequenceEqual",
      "d": 458788,
      "h": 519691501604,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(519691501604),
//--TRIMMABLE-BOUNDARY-START(528281436196),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Shuffle",
      "d": 458788,
      "h": 528281436196,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(528281436196),
//--TRIMMABLE-BOUNDARY-START(34360197156),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Any",
      "o": "@$1",
      "d": 458788,
      "h": 34360197156,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(34360197156),
//--TRIMMABLE-BOUNDARY-START(30065229860),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Any",
      "d": 458788,
      "h": 30065229860,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(30065229860),
//--TRIMMABLE-BOUNDARY-START(25770262564),
    {
      "r": 262145,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "All",
      "d": 458788,
      "h": 25770262564,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25770262564),
//--TRIMMABLE-BOUNDARY-START(163209216036),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Count",
      "o": "@$1",
      "d": 458788,
      "h": 163209216036,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(163209216036),
//--TRIMMABLE-BOUNDARY-START(158914248740),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Count",
      "d": 458788,
      "h": 158914248740,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(158914248740),
//--TRIMMABLE-BOUNDARY-START(167504183332),
    {
      "r": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, $.$$.System.Int32)).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h,
          "f": 65
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "CountBy",
      "d": 458788,
      "h": 167504183332,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(167504183332),
//--TRIMMABLE-BOUNDARY-START(382252548132),
    {
      "r": 917505,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "LongCount",
      "o": "@$1",
      "d": 458788,
      "h": 382252548132,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(382252548132),
//--TRIMMABLE-BOUNDARY-START(377957580836),
    {
      "r": 917505,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "predicate",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "LongCount",
      "d": 458788,
      "h": 377957580836,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(377957580836),
//--TRIMMABLE-BOUNDARY-START(420907253796),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Min",
      "o": "@$2",
      "d": 458788,
      "h": 420907253796,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(420907253796),
//--TRIMMABLE-BOUNDARY-START(416612286500),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "comparer",
          "p": (TSource) => $.$$.System.Collections.Generic.IComparer$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Min",
      "o": "@$1",
      "d": 458788,
      "h": 416612286500,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(416612286500),
//--TRIMMABLE-BOUNDARY-START(412317319204),
    {
      "r": (TSource, TResult) => TResult.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TResult)).$h
        }
      ],
      "g": [
        "TSource",
        "TResult"
      ],
      "n": "Min",
      "d": 458788,
      "h": 412317319204,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(412317319204),
//--TRIMMABLE-BOUNDARY-START(433792155684),
    {
      "r": (TSource, TKey) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "MinBy",
      "o": "@$2",
      "d": 458788,
      "h": 433792155684,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(433792155684),
//--TRIMMABLE-BOUNDARY-START(429497188388),
    {
      "r": (TSource, TKey) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IComparer$$(TSource).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "MinBy",
      "o": "@$1",
      "d": 458788,
      "h": 429497188388,
      "f": 16908321,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "The Queryable MinBy and MaxBy taking an IComparer\u003CTSource\u003E are obsolete. Use the new ones that take an IComparer\u003CTKey\u003E.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0061",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        },
        {
          "t": 131465217,
          "c": 8721399809,
          "a": [
            {
              "v": -1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(429497188388),
//--TRIMMABLE-BOUNDARY-START(425202221092),
    {
      "r": (TSource, TKey) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IComparer$$(TKey).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "MinBy",
      "d": 458788,
      "h": 425202221092,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(425202221092),
//--TRIMMABLE-BOUNDARY-START(395137450020),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Max",
      "o": "@$2",
      "d": 458788,
      "h": 395137450020,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(395137450020),
//--TRIMMABLE-BOUNDARY-START(390842482724),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "comparer",
          "p": (TSource) => $.$$.System.Collections.Generic.IComparer$$(TSource).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Max",
      "o": "@$1",
      "d": 458788,
      "h": 390842482724,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(390842482724),
//--TRIMMABLE-BOUNDARY-START(386547515428),
    {
      "r": (TSource, TResult) => TResult.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TResult)).$h
        }
      ],
      "g": [
        "TSource",
        "TResult"
      ],
      "n": "Max",
      "d": 458788,
      "h": 386547515428,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(386547515428),
//--TRIMMABLE-BOUNDARY-START(408022351908),
    {
      "r": (TSource, TKey) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "MaxBy",
      "o": "@$2",
      "d": 458788,
      "h": 408022351908,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(408022351908),
//--TRIMMABLE-BOUNDARY-START(403727384612),
    {
      "r": (TSource, TKey) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IComparer$$(TSource).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "MaxBy",
      "o": "@$1",
      "d": 458788,
      "h": 403727384612,
      "f": 16908321,
      "a": [
        {
          "t": 103743489,
          "c": 30168514561,
          "a": [
            {
              "v": "The Queryable MinBy and MaxBy taking an IComparer\u003CTSource\u003E are obsolete. Use the new ones that take an IComparer\u003CTKey\u003E.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0061",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        },
        {
          "t": 131465217,
          "c": 8721399809,
          "a": [
            {
              "v": -1,
              "t": 655361
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(403727384612),
//--TRIMMABLE-BOUNDARY-START(399432417316),
    {
      "r": (TSource, TKey) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "comparer",
          "p": (TSource, TKey) => $.$$.System.Collections.Generic.IComparer$$(TKey).$h
        }
      ],
      "g": [
        "TSource",
        "TKey"
      ],
      "n": "MaxBy",
      "d": 458788,
      "h": 399432417316,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(399432417316),
//--TRIMMABLE-BOUNDARY-START(584116011044),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Int32).$h
        }
      ],
      "n": "Sum",
      "o": "@$2",
      "d": 458788,
      "h": 584116011044,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(584116011044),
//--TRIMMABLE-BOUNDARY-START(601295880228),
    {
      "r": $.$typeNullable($.$$.System.Int32).$h,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Int32)).$h
        }
      ],
      "n": "Sum",
      "o": "@$6",
      "d": 458788,
      "h": 601295880228,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(601295880228),
//--TRIMMABLE-BOUNDARY-START(588410978340),
    {
      "r": 917505,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Int64).$h
        }
      ],
      "n": "Sum",
      "o": "@$3",
      "d": 458788,
      "h": 588410978340,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(588410978340),
//--TRIMMABLE-BOUNDARY-START(605590847524),
    {
      "r": $.$typeNullable($.$$.System.Int64).$h,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Int64)).$h
        }
      ],
      "n": "Sum",
      "o": "@$7",
      "d": 458788,
      "h": 605590847524,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(605590847524),
//--TRIMMABLE-BOUNDARY-START(614180782116),
    {
      "r": 1114113,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Single).$h
        }
      ],
      "n": "Sum",
      "o": "@$9",
      "d": 458788,
      "h": 614180782116,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(614180782116),
//--TRIMMABLE-BOUNDARY-START(609885814820),
    {
      "r": $.$typeNullable($.$$.System.Single).$h,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Single)).$h
        }
      ],
      "n": "Sum",
      "o": "@$8",
      "d": 458788,
      "h": 609885814820,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(609885814820),
//--TRIMMABLE-BOUNDARY-START(579821043748),
    {
      "r": 1179649,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Double).$h
        }
      ],
      "n": "Sum",
      "o": "@$1",
      "d": 458788,
      "h": 579821043748,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(579821043748),
//--TRIMMABLE-BOUNDARY-START(597000912932),
    {
      "r": $.$typeNullable($.$$.System.Double).$h,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Double)).$h
        }
      ],
      "n": "Sum",
      "o": "@$5",
      "d": 458788,
      "h": 597000912932,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(597000912932),
//--TRIMMABLE-BOUNDARY-START(575526076452),
    {
      "r": 66125825,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Decimal).$h
        }
      ],
      "n": "Sum",
      "d": 458788,
      "h": 575526076452,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(575526076452),
//--TRIMMABLE-BOUNDARY-START(592705945636),
    {
      "r": $.$typeNullable($.$$.System.Decimal).$h,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Decimal)).$h
        }
      ],
      "n": "Sum",
      "o": "@$4",
      "d": 458788,
      "h": 592705945636,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(592705945636),
//--TRIMMABLE-BOUNDARY-START(627065684004),
    {
      "r": 655361,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Int32)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Sum",
      "o": "@$12",
      "d": 458788,
      "h": 627065684004,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(627065684004),
//--TRIMMABLE-BOUNDARY-START(644245553188),
    {
      "r": $.$typeNullable($.$$.System.Int32).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Int32))).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Sum",
      "o": "@$16",
      "d": 458788,
      "h": 644245553188,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(644245553188),
//--TRIMMABLE-BOUNDARY-START(631360651300),
    {
      "r": 917505,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Int64)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Sum",
      "o": "@$13",
      "d": 458788,
      "h": 631360651300,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(631360651300),
//--TRIMMABLE-BOUNDARY-START(648540520484),
    {
      "r": $.$typeNullable($.$$.System.Int64).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Int64))).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Sum",
      "o": "@$17",
      "d": 458788,
      "h": 648540520484,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(648540520484),
//--TRIMMABLE-BOUNDARY-START(657130455076),
    {
      "r": 1114113,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Single)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Sum",
      "o": "@$19",
      "d": 458788,
      "h": 657130455076,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(657130455076),
//--TRIMMABLE-BOUNDARY-START(652835487780),
    {
      "r": $.$typeNullable($.$$.System.Single).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Single))).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Sum",
      "o": "@$18",
      "d": 458788,
      "h": 652835487780,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(652835487780),
//--TRIMMABLE-BOUNDARY-START(622770716708),
    {
      "r": 1179649,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Double)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Sum",
      "o": "@$11",
      "d": 458788,
      "h": 622770716708,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(622770716708),
//--TRIMMABLE-BOUNDARY-START(639950585892),
    {
      "r": $.$typeNullable($.$$.System.Double).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Double))).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Sum",
      "o": "@$15",
      "d": 458788,
      "h": 639950585892,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(639950585892),
//--TRIMMABLE-BOUNDARY-START(618475749412),
    {
      "r": 66125825,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Decimal)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Sum",
      "o": "@$10",
      "d": 458788,
      "h": 618475749412,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(618475749412),
//--TRIMMABLE-BOUNDARY-START(635655618596),
    {
      "r": $.$typeNullable($.$$.System.Decimal).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Decimal))).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Sum",
      "o": "@$14",
      "d": 458788,
      "h": 635655618596,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(635655618596),
//--TRIMMABLE-BOUNDARY-START(60130000932),
    {
      "r": 1179649,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Int32).$h
        }
      ],
      "n": "Average",
      "o": "@$2",
      "d": 458788,
      "h": 60130000932,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60130000932),
//--TRIMMABLE-BOUNDARY-START(77309870116),
    {
      "r": $.$typeNullable($.$$.System.Double).$h,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Int32)).$h
        }
      ],
      "n": "Average",
      "o": "@$6",
      "d": 458788,
      "h": 77309870116,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77309870116),
//--TRIMMABLE-BOUNDARY-START(64424968228),
    {
      "r": 1179649,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Int64).$h
        }
      ],
      "n": "Average",
      "o": "@$3",
      "d": 458788,
      "h": 64424968228,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64424968228),
//--TRIMMABLE-BOUNDARY-START(81604837412),
    {
      "r": $.$typeNullable($.$$.System.Double).$h,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Int64)).$h
        }
      ],
      "n": "Average",
      "o": "@$7",
      "d": 458788,
      "h": 81604837412,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81604837412),
//--TRIMMABLE-BOUNDARY-START(90194772004),
    {
      "r": 1114113,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Single).$h
        }
      ],
      "n": "Average",
      "o": "@$9",
      "d": 458788,
      "h": 90194772004,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90194772004),
//--TRIMMABLE-BOUNDARY-START(85899804708),
    {
      "r": $.$typeNullable($.$$.System.Single).$h,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Single)).$h
        }
      ],
      "n": "Average",
      "o": "@$8",
      "d": 458788,
      "h": 85899804708,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85899804708),
//--TRIMMABLE-BOUNDARY-START(55835033636),
    {
      "r": 1179649,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Double).$h
        }
      ],
      "n": "Average",
      "o": "@$1",
      "d": 458788,
      "h": 55835033636,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55835033636),
//--TRIMMABLE-BOUNDARY-START(73014902820),
    {
      "r": $.$typeNullable($.$$.System.Double).$h,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Double)).$h
        }
      ],
      "n": "Average",
      "o": "@$5",
      "d": 458788,
      "h": 73014902820,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73014902820),
//--TRIMMABLE-BOUNDARY-START(51540066340),
    {
      "r": 66125825,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Decimal).$h
        }
      ],
      "n": "Average",
      "d": 458788,
      "h": 51540066340,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540066340),
//--TRIMMABLE-BOUNDARY-START(68719935524),
    {
      "r": $.$typeNullable($.$$.System.Decimal).$h,
      "p": [
        {
          "n": "source",
          "p": $.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Decimal)).$h
        }
      ],
      "n": "Average",
      "o": "@$4",
      "d": 458788,
      "h": 68719935524,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68719935524),
//--TRIMMABLE-BOUNDARY-START(103079673892),
    {
      "r": 1179649,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Int32)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Average",
      "o": "@$12",
      "d": 458788,
      "h": 103079673892,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(103079673892),
//--TRIMMABLE-BOUNDARY-START(120259543076),
    {
      "r": $.$typeNullable($.$$.System.Double).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Int32))).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Average",
      "o": "@$16",
      "d": 458788,
      "h": 120259543076,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(120259543076),
//--TRIMMABLE-BOUNDARY-START(133144444964),
    {
      "r": 1114113,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Single)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Average",
      "o": "@$19",
      "d": 458788,
      "h": 133144444964,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(133144444964),
//--TRIMMABLE-BOUNDARY-START(128849477668),
    {
      "r": $.$typeNullable($.$$.System.Single).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Single))).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Average",
      "o": "@$18",
      "d": 458788,
      "h": 128849477668,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(128849477668),
//--TRIMMABLE-BOUNDARY-START(107374641188),
    {
      "r": 1179649,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Int64)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Average",
      "o": "@$13",
      "d": 458788,
      "h": 107374641188,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(107374641188),
//--TRIMMABLE-BOUNDARY-START(124554510372),
    {
      "r": $.$typeNullable($.$$.System.Double).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Int64))).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Average",
      "o": "@$17",
      "d": 458788,
      "h": 124554510372,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(124554510372),
//--TRIMMABLE-BOUNDARY-START(98784706596),
    {
      "r": 1179649,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Double)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Average",
      "o": "@$11",
      "d": 458788,
      "h": 98784706596,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(98784706596),
//--TRIMMABLE-BOUNDARY-START(115964575780),
    {
      "r": $.$typeNullable($.$$.System.Double).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Double))).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Average",
      "o": "@$15",
      "d": 458788,
      "h": 115964575780,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(115964575780),
//--TRIMMABLE-BOUNDARY-START(94489739300),
    {
      "r": 66125825,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Decimal)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Average",
      "o": "@$10",
      "d": 458788,
      "h": 94489739300,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(94489739300),
//--TRIMMABLE-BOUNDARY-START(111669608484),
    {
      "r": $.$typeNullable($.$$.System.Decimal).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "selector",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Decimal))).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Average",
      "o": "@$14",
      "d": 458788,
      "h": 111669608484,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(111669608484),
//--TRIMMABLE-BOUNDARY-START(12885360676),
    {
      "r": (TSource) => TSource.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "func",
          "p": (TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, TSource, TSource)).$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Aggregate",
      "o": "@$2",
      "d": 458788,
      "h": 12885360676,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885360676),
//--TRIMMABLE-BOUNDARY-START(8590393380),
    {
      "r": (TSource, TAccumulate) => TAccumulate.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TAccumulate) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "seed",
          "p": (TSource, TAccumulate) => TAccumulate.$h
        },
        {
          "n": "func",
          "p": (TSource, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TAccumulate, TSource, TAccumulate)).$h
        }
      ],
      "g": [
        "TSource",
        "TAccumulate"
      ],
      "n": "Aggregate",
      "o": "@$1",
      "d": 458788,
      "h": 8590393380,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8590393380),
//--TRIMMABLE-BOUNDARY-START(4295426084),
    {
      "r": (TSource, TAccumulate, TResult) => TResult.$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TAccumulate, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "seed",
          "p": (TSource, TAccumulate, TResult) => TAccumulate.$h
        },
        {
          "n": "func",
          "p": (TSource, TAccumulate, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TAccumulate, TSource, TAccumulate)).$h
        },
        {
          "n": "selector",
          "p": (TSource, TAccumulate, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TAccumulate, TResult)).$h
        }
      ],
      "g": [
        "TSource",
        "TAccumulate",
        "TResult"
      ],
      "n": "Aggregate",
      "d": 458788,
      "h": 4295426084,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295426084),
//--TRIMMABLE-BOUNDARY-START(21475295268),
    {
      "r": (TSource, TKey, TAccumulate) => $.$sle.System.Linq.IQueryable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate)).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey, TAccumulate) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "seed",
          "p": (TSource, TKey, TAccumulate) => TAccumulate.$h
        },
        {
          "n": "func",
          "p": (TSource, TKey, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TAccumulate, TSource, TAccumulate)).$h
        },
        {
          "n": "keyComparer",
          "p": (TSource, TKey, TAccumulate) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h,
          "f": 65
        }
      ],
      "g": [
        "TSource",
        "TKey",
        "TAccumulate"
      ],
      "n": "AggregateBy",
      "o": "@$1",
      "d": 458788,
      "h": 21475295268,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21475295268),
//--TRIMMABLE-BOUNDARY-START(17180327972),
    {
      "r": (TSource, TKey, TAccumulate) => $.$sle.System.Linq.IQueryable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate)).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource, TKey, TAccumulate) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "keySelector",
          "p": (TSource, TKey, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h
        },
        {
          "n": "seedSelector",
          "p": (TSource, TKey, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TKey, TAccumulate)).$h
        },
        {
          "n": "func",
          "p": (TSource, TKey, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TAccumulate, TSource, TAccumulate)).$h
        },
        {
          "n": "keyComparer",
          "p": (TSource, TKey, TAccumulate) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h,
          "f": 65
        }
      ],
      "g": [
        "TSource",
        "TKey",
        "TAccumulate"
      ],
      "n": "AggregateBy",
      "d": 458788,
      "h": 17180327972,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180327972),
//--TRIMMABLE-BOUNDARY-START(562641174564),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "SkipLast",
      "d": 458788,
      "h": 562641174564,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(562641174564),
//--TRIMMABLE-BOUNDARY-START(670015356964),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "TakeLast",
      "d": 458788,
      "h": 670015356964,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(670015356964),
//--TRIMMABLE-BOUNDARY-START(38655164452),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "element",
          "p": (TSource) => TSource.$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Append",
      "d": 458788,
      "h": 38655164452,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(38655164452),
//--TRIMMABLE-BOUNDARY-START(476741828644),
    {
      "r": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,
      "p": [
        {
          "n": "source",
          "p": (TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h
        },
        {
          "n": "element",
          "p": (TSource) => TSource.$h
        }
      ],
      "g": [
        "TSource"
      ],
      "n": "Prepend",
      "d": 458788,
      "h": 476741828644,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(476741828644)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(313533071396),
    {
      "t": 1310721,
      "n": "InMemoryQueryableExtensionMethodsRequiresUnreferencedCode",
      "d": 458788,
      "h": 313533071396,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(313533071396),
//--TRIMMABLE-BOUNDARY-START(309238104100),
    {
      "t": 1310721,
      "n": "InMemoryQueryableExtensionMethodsRequiresDynamicCode",
      "d": 458788,
      "h": 309238104100,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(309238104100)
  ],
  "h": 458788
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Linq.Queryable`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458788)
        
        
        //--TRIMMABLE-BOUNDARY-START(327716)
        $asm.$cls("$slq.System.Linq.EnumerableRewriter", ($self) => class EnumerableRewriter extends $.$sle.System.Linq.Expressions.ExpressionVisitor
        {
            //--TRIMMABLE-BOUNDARY-START(8590262308)
            /*Dictionary<LabelTarget, LabelTarget>?*/ _targetCache = null;
            //--TRIMMABLE-BOUNDARY-END(8590262308)
            
            //--TRIMMABLE-BOUNDARY-START(4295295012)
            /*Dictionary<Type, Type>?*/ _equivalentTypeCache = null;
            //--TRIMMABLE-BOUNDARY-END(4295295012)
            
            //--TRIMMABLE-BOUNDARY-START(12885229604)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885229604);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885229604)
            
            //--TRIMMABLE-BOUNDARY-START(81604706340)
            /*Expression */ VisitMethodCall(/*MethodCallExpression*/ m)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604706340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Expression?*/ let obj = this.Visit$1(m.Object);
                /*ReadOnlyCollection<Expression>*/ let args = this.Visit(m.Arguments);
                if (obj !== m.Object || args !== m.Arguments)
                {
                    /*MethodInfo*/ let mInfo = m.Method;
                    /*Type[]?*/ let typeArgs = (mInfo.IsGenericMethod) ? mInfo.GetGenericArguments() : null;
                    if ((mInfo.IsStatic$1 || mInfo.DeclaringType.IsAssignableFrom(obj.Type)) && $.$slq.System.Linq.EnumerableRewriter.ArgsMatch(mInfo, args, typeArgs))
                    {
                        return $.$sle.System.Linq.Expressions.Expression.Call$9(obj, mInfo, args);
                    }
                    else if ($.$$.System.Type.op_Equality$1(mInfo.DeclaringType, $.$slq.System.Linq.Queryable.$type))
                    {
                        /*MethodInfo*/ let seqMethod = $.$slq.System.Linq.EnumerableRewriter.FindEnumerableMethodForQueryable(mInfo.Name, args, typeArgs);
                        args = $.$slq.System.Linq.EnumerableRewriter.FixupQuotedArgs(seqMethod, args);
                        return $.$sle.System.Linq.Expressions.Expression.Call$9(obj, seqMethod, args);
                    }
                    else 
                    {
                        /*MethodInfo*/ let method = $.$slq.System.Linq.EnumerableRewriter.FindMethod(mInfo.DeclaringType, mInfo.Name, args, typeArgs);
                        args = $.$slq.System.Linq.EnumerableRewriter.FixupQuotedArgs(method, args);
                        return $.$sle.System.Linq.Expressions.Expression.Call$9(obj, method, args);
                    }
                }
                return m;
            }
            //--TRIMMABLE-BOUNDARY-END(81604706340)
            
            //--TRIMMABLE-BOUNDARY-START(30065098788)
            static /*ReadOnlyCollection<Expression> */ FixupQuotedArgs(/*MethodInfo*/ mi, /*ReadOnlyCollection<Expression>*/ argList)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065098788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ParameterInfo[]*/ let pis = mi.GetParameters();
                if (pis.length > 0)
                {
                    /*List<Expression>?*/ let newArgs = null;
                    for(/*int*/ let i = 0, n = pis.length; i < n; i++)
                    {
                        /*Expression*/ let arg = argList.get_Item(i);
                        /*ParameterInfo*/ let pi = $.$$.System.Array.$ReadT1.call(pis, i);
                        arg = $.$slq.System.Linq.EnumerableRewriter.FixupQuotedExpression(pi.ParameterType, arg);
                        if (newArgs === null && arg !== argList.get_Item(i))
                        {
                            newArgs = new ($.$$.System.Collections.Generic.List$$($.$sle.System.Linq.Expressions.Expression))().$ctor$3(argList.Count);
                            for(/*int*/ let j = 0; j < i; j++)
                            {
                                newArgs.Add(argList.get_Item(j));
                            }
                        }
                        newArgs?.Add(arg);
                    }
                    if (newArgs !== null)
                    {
                        argList = newArgs.AsReadOnly();
                    }
                }
                return argList;
            }
            //--TRIMMABLE-BOUNDARY-END(30065098788)
            
            //--TRIMMABLE-BOUNDARY-START(34360066084)
            static /*Expression */ FixupQuotedExpression(/*Type*/ type, /*Expression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Expression*/ let expr = expression;
                while(true)
                {
                    if (type.IsAssignableFrom(expr.Type))
                    {
                        return expr;
                    }
                    if (expr.NodeType !== 40/*ExpressionType.Quote*/)
                    {
                        break;
                    }
                    expr = ($.$cast(expr, $.$sle.System.Linq.Expressions.UnaryExpression)).Operand;
                }
                if (!type.IsAssignableFrom(expr.Type) && type.IsArray && expr.NodeType === 32/*ExpressionType.NewArrayInit*/)
                {
                    /*Type*/ let strippedType = $.$slq.System.Linq.EnumerableRewriter.StripExpression(expr.Type);
                    if (type.IsAssignableFrom(strippedType))
                    {
                        /*Type*/ let elementType = type.GetElementType();
                        /*NewArrayExpression*/ let na = $.$cast(expr, $.$sle.System.Linq.Expressions.NewArrayExpression);
                        /*List<Expression>*/ let exprs = new ($.$$.System.Collections.Generic.List$$($.$sle.System.Linq.Expressions.Expression))().$ctor$3(na.Expressions.Count);
                        for(/*int*/ let i = 0, n = na.Expressions.Count; i < n; i++)
                        {
                            exprs.Add($.$slq.System.Linq.EnumerableRewriter.FixupQuotedExpression(elementType, na.Expressions.get_Item(i)));
                        }
                        expression = $.$sle.System.Linq.Expressions.Expression.NewArrayInit(elementType, exprs);
                    }
                }
                return expression;
            }
            //--TRIMMABLE-BOUNDARY-END(34360066084)
            
            //--TRIMMABLE-BOUNDARY-START(77309739044)
            /*Expression */ VisitLambda(T, /*Expression<T>*/ node)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309739044);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return node;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309739044)
            
            //--TRIMMABLE-BOUNDARY-START(42950000676)
            static /*Type */ GetPublicType(/*Type*/ t)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950000676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (t.IsGenericType && $.$sl.System.Linq.Enumerable.Contains$1($.$$.System.Type, t.GetGenericTypeDefinition().GetInterfaces(), $.$sl.System.Linq.IGrouping$$$().$type))
                {
                    return $.$sl.System.Linq.IGrouping$$$().$type.MakeGenericType(t.GetGenericArguments());
                }
                if (!t.IsNestedPrivate)
                {
                    return t;
                }
                let $i1 = 0;
                let $arr1 = t.GetInterfaces();
                while ($i1 < $arr1.length)
                {
                    let iType = $arr1[$i1++];
                    if (iType.IsGenericType && $.$$.System.Type.op_Equality$1(iType.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.IEnumerable$$().$type))
                    {
                        return iType;
                    }
                }
                if ($.$$.System.Collections.IEnumerable.$type.IsAssignableFrom(t))
                {
                    return $.$$.System.Collections.IEnumerable.$type;
                }
                return t;
            }
            //--TRIMMABLE-BOUNDARY-END(42950000676)
            
            //--TRIMMABLE-BOUNDARY-START(38655033380)
            /*Type */ GetEquivalentType(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655033380);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type?*/ let equiv;
                this._equivalentTypeCache ??= (() =>
                {
                    //new $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Type, $.$$.System.Type)()
                    const $t1 = $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Type, $.$$.System.Type);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Add($.$sle.System.Linq.IQueryable.$type, $.$$.System.Collections.IEnumerable.$type);
                    $i1.Add($.$$.System.Collections.IEnumerable.$type, $.$$.System.Collections.IEnumerable.$type);
                    return $i1;
                })();
                if (!this._equivalentTypeCache.TryGetValue(type, $.$ref(() => equiv, ($v) => equiv = $v, $.$$.System.Type)))
                {
                    /*Type*/ let pubType = $.$slq.System.Linq.EnumerableRewriter.GetPublicType(type);
                    if (pubType.IsInterface && pubType.IsGenericType)
                    {
                        /*Type*/ let genericType = pubType.GetGenericTypeDefinition();
                        if ($.$$.System.Type.op_Equality$1(genericType, $.$sl.System.Linq.IOrderedEnumerable$$().$type))
                        {
                            equiv = pubType;
                        }
                        else if ($.$$.System.Type.op_Equality$1(genericType, $.$sle.System.Linq.IOrderedQueryable$$().$type))
                        {
                            equiv = $.$sl.System.Linq.IOrderedEnumerable$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ $.$$.System.Array.$ReadT1.call(pubType.GenericTypeArguments, 0) ], null, null));
                        }
                        else if ($.$$.System.Type.op_Equality$1(genericType, $.$$.System.Collections.Generic.IEnumerable$$().$type))
                        {
                            equiv = pubType;
                        }
                        else if ($.$$.System.Type.op_Equality$1(genericType, $.$sle.System.Linq.IQueryable$$().$type))
                        {
                            equiv = $.$$.System.Collections.Generic.IEnumerable$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ $.$$.System.Array.$ReadT1.call(pubType.GenericTypeArguments, 0) ], null, null));
                        }
                    }
                    if ($.$$.System.Type.op_Equality$1(equiv, null))
                    {
                        /*var*/ let interfacesWithInfo = pubType.GetInterfaces();
                        /*var*/ let singleTypeGenInterfacesWithGetType = $.$sl.System.Linq.Enumerable.ToArray($.$$.System.Object, $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Type, $.$$.System.Object, $.$sl.System.Linq.Enumerable.Where($.$$.System.Type, interfacesWithInfo, new ($.$$.System.Func$$$($.$$.System.Type, $.$$.System.Boolean))().$ctor(this,  (/*i*/ i) =>
                        {
                            return i.IsGenericType && i.GenericTypeArguments.length === 1;
                        }, {
  "r": 262145,
  "p": [
    {
      "n": "i",
      "p": 187760641
    }
  ],
  "n": "",
  "d": 327716,
  "h": 0,
  "f": 17825794
})), new ($.$$.System.Func$$$($.$$.System.Type, $.$$.System.Object))().$ctor(this,  (/**/ i) =>
                        {
                            return { Info : i, GenType : i.GetGenericTypeDefinition() };
                        }, {
  "r": 0,
  "p": [
    {
      "n": "i",
      "p": 187760641
    }
  ],
  "n": "",
  "d": 327716,
  "h": 0,
  "f": 17825794
})));
                        /*Type?*/ let typeArg = $.$sl.System.Linq.Enumerable.SingleOrDefault$3($.$$.System.Type, $.$sl.System.Linq.Enumerable.Distinct$1($.$$.System.Type, $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Object, $.$$.System.Type, $.$sl.System.Linq.Enumerable.Where($.$$.System.Object, singleTypeGenInterfacesWithGetType, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Boolean))().$ctor(this,  (/*i*/ i) =>
                        {
                            return $.$$.System.Type.op_Equality$1(i.GenType, $.$sle.System.Linq.IOrderedQueryable$$().$type) || $.$$.System.Type.op_Equality$1(i.GenType, $.$sl.System.Linq.IOrderedEnumerable$$().$type);
                        }, {
  "r": 262145,
  "p": [
    {
      "n": "i",
      "p": 0
    }
  ],
  "n": "",
  "d": 327716,
  "h": 0,
  "f": 17825794
})), new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Type))().$ctor(this,  (/*i*/ i) =>
                        {
                            return $.$$.System.Array.$ReadT1.call(i.Info.GenericTypeArguments, 0);
                        }, {
  "r": 187760641,
  "p": [
    {
      "n": "i",
      "p": 0
    }
  ],
  "n": "",
  "d": 327716,
  "h": 0,
  "f": 17825794
}))));
                        if ($.$$.System.Type.op_Inequality$1(typeArg, null))
                        {
                            equiv = $.$sl.System.Linq.IOrderedEnumerable$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ typeArg ], null, null));
                        }
                        else 
                        {
                            typeArg = $.$sl.System.Linq.Enumerable.Single$1($.$$.System.Type, $.$sl.System.Linq.Enumerable.Distinct$1($.$$.System.Type, $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Object, $.$$.System.Type, $.$sl.System.Linq.Enumerable.Where($.$$.System.Object, singleTypeGenInterfacesWithGetType, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Boolean))().$ctor(this,  (/*i*/ i) =>
                            {
                                return $.$$.System.Type.op_Equality$1(i.GenType, $.$sle.System.Linq.IQueryable$$().$type) || $.$$.System.Type.op_Equality$1(i.GenType, $.$$.System.Collections.Generic.IEnumerable$$().$type);
                            }, {
  "r": 262145,
  "p": [
    {
      "n": "i",
      "p": 0
    }
  ],
  "n": "",
  "d": 327716,
  "h": 0,
  "f": 17825794
})), new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Type))().$ctor(this,  (/*i*/ i) =>
                            {
                                return $.$$.System.Array.$ReadT1.call(i.Info.GenericTypeArguments, 0);
                            }, {
  "r": 187760641,
  "p": [
    {
      "n": "i",
      "p": 0
    }
  ],
  "n": "",
  "d": 327716,
  "h": 0,
  "f": 17825794
}))));
                            equiv = $.$$.System.Collections.Generic.IEnumerable$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ typeArg ], null, null));
                        }
                    }
                    this._equivalentTypeCache.Add(type, equiv);
                }
                return equiv;
            }
            //--TRIMMABLE-BOUNDARY-END(38655033380)
            
            //--TRIMMABLE-BOUNDARY-START(64424837156)
            /*Expression */ VisitConstant(/*ConstantExpression*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424837156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let sq;
                if ($.$is(c.Value, $.$slq.System.Linq.EnumerableQuery, { set $v(v){ sq = v; } }))
                {
                    if (sq.Enumerable !== null)
                    {
                        /*Type*/ let t = $.$slq.System.Linq.EnumerableRewriter.GetPublicType($.$$.System.Object.GetType.call(sq.Enumerable));
                        return $.$sle.System.Linq.Expressions.Expression.Constant(sq.Enumerable, t);
                    }
                    /*Expression*/ let exp = sq.Expression;
                    if (exp !== c)
                    {
                        return this.Visit$1(exp);
                    }
                }
                return c;
            }
            //--TRIMMABLE-BOUNDARY-END(64424837156)
            
            //--TRIMMABLE-BOUNDARY-START(47244967972)
            /*ILookup<string, MethodInfo>?*/ static s_seqMethods = null;
            //--TRIMMABLE-BOUNDARY-END(47244967972)
            
            //--TRIMMABLE-BOUNDARY-START(21475164196)
            static /*MethodInfo */ FindEnumerableMethodForQueryable(/*string*/ name, /*ReadOnlyCollection<Expression>*/ args, /*params Type[]?*/ typeArgs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475164196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$slq.System.Linq.EnumerableRewriter.s_seqMethods ??= $.$sl.System.Linq.Enumerable.ToLookup$3($.$$.System.Reflection.MethodInfo, $.$$.System.String, GetEnumerableStaticMethods($.$sl.System.Linq.Enumerable.$type), new ($.$$.System.Func$$$($.$$.System.Reflection.MethodInfo, $.$$.System.String))().$ctor(this,  (/**/ m) =>
                {
                    return m.Name;
                }, {
  "r": 1310721,
  "p": [
    {
      "n": "m",
      "p": 116850689
    }
  ],
  "n": "",
  "d": 327716,
  "h": 0,
  "f": 17825794
}));
                /*MethodInfo[]*/ let matchingMethods = $.$sl.System.Linq.Enumerable.ToArray($.$$.System.Reflection.MethodInfo, $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Reflection.MethodInfo, $.$$.System.Reflection.MethodInfo, $.$sl.System.Linq.Enumerable.Where($.$$.System.Reflection.MethodInfo, $.$slq.System.Linq.EnumerableRewriter.s_seqMethods.System$Linq$ILookup$$$$get_Item(name, [$.$$.System.String, $.$$.System.Reflection.MethodInfo]), new ($.$$.System.Func$$$($.$$.System.Reflection.MethodInfo, $.$$.System.Boolean))().$ctor(this,  (/**/ m) =>
                {
                    return $.$slq.System.Linq.EnumerableRewriter.ArgsMatch(m, args, typeArgs);
                }, {
  "r": 262145,
  "p": [
    {
      "n": "m",
      "p": 116850689
    }
  ],
  "n": "",
  "d": 327716,
  "h": 0,
  "f": 17825794
})), new ($.$$.System.Func$$$($.$$.System.Reflection.MethodInfo, $.$$.System.Reflection.MethodInfo))().$ctor(this, ApplyTypeArgs)));
                $.$$.System.Diagnostics.Debug.Assert$2(matchingMethods.length > 0, "All static methods with arguments on Queryable have equivalents on Enumerable.");
                if (matchingMethods.length > 1)
                {
                    return DisambiguateMatches(matchingMethods);
                }
                return $.$$.System.Array.$ReadT1.call(matchingMethods, 0);
                /*static MethodInfo[]*/  function GetEnumerableStaticMethods(/*Type*/ type)
                {
                    {
                        return type.GetMethods$1(16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/);
                    }
                }
                /*MethodInfo*/  function ApplyTypeArgs(/*MethodInfo*/ methodInfo)
                {
                    {
                        return typeArgs === null ? methodInfo : methodInfo.MakeGenericMethod(typeArgs);
                    }
                }
                /*static MethodInfo*/  function DisambiguateMatches(/*MethodInfo[]*/ matchingMethods)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(matchingMethods.length > 1, "matchingMethods.Length > 1");
                    /*ParameterInfo[][]*/ let parameters = $.$sl.System.Linq.Enumerable.ToArray($.$typeArray($.$$.System.Reflection.ParameterInfo), $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Reflection.ParameterInfo), matchingMethods, new ($.$$.System.Func$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Reflection.ParameterInfo)))().$ctor(this,  (/**/ m) =>
                    {
                        return m.GetParameters();
                    }, {
  "r": $.$typeArray($.$$.System.Reflection.ParameterInfo).$h,
  "p": [
    {
      "n": "m",
      "p": 116850689
    }
  ],
  "n": "",
  "d": 327716,
  "h": 0,
  "f": 17825794
})));
                    for(/*int*/ let i = 0; i < matchingMethods.length; i++)
                    {
                        /*bool*/ let isMaximal = true;
                        for(/*int*/ let j = 0; j < matchingMethods.length; j++)
                        {
                            if (i !== j && AreAssignableFromStrict($.$$.System.Array.$ReadT1.call(parameters, i), $.$$.System.Array.$ReadT1.call(parameters, j)))
                            {
                                isMaximal = false;
                                break;
                            }
                        }
                        if (isMaximal)
                        {
                            return $.$$.System.Array.$ReadT1.call(matchingMethods, i);
                        }
                    }
                    $.$$.System.Diagnostics.Debug.Fail$1("Search should have found a maximal element");
                    throw new $.$$.System.Exception().$ctor$1();
                    /*static bool*/  function AreAssignableFromStrict(/*ParameterInfo[]*/ left, /*ParameterInfo[]*/ right)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(left.length === right.length, "left.Length == right.Length");
                        /*bool*/ let areEqual = true;
                        /*bool*/ let areAssignableFrom = true;
                        for(/*int*/ let i = 0; i < left.length; i++)
                        {
                            /*Type*/ let leftParam = $.$$.System.Array.$ReadT1.call(left, i).ParameterType;
                            /*Type*/ let rightParam = $.$$.System.Array.$ReadT1.call(right, i).ParameterType;
                            areEqual = areEqual && $.$$.System.Type.op_Equality$1(leftParam, rightParam);
                            areAssignableFrom = areAssignableFrom && leftParam.IsAssignableFrom(rightParam);
                        }
                        return !areEqual && areAssignableFrom;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475164196)
            
            //--TRIMMABLE-BOUNDARY-START(25770131492)
            static /*MethodInfo */ FindMethod(/*Type*/ type, /*string*/ name, /*ReadOnlyCollection<Expression>*/ args, /*Type[]?*/ typeArgs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770131492);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let en = null;
                try
                {
                    en = $.$sl.System.Linq.Enumerable.Where($.$$.System.Reflection.MethodInfo, type.GetMethods$1(16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 8/*BindingFlags.Static*/), new ($.$$.System.Func$$$($.$$.System.Reflection.MethodInfo, $.$$.System.Boolean))().$ctor(this,  (/*m*/ m) =>
                    {
                        return $.$$.System.String.op_Equality(m.Name, name);
                    }, {
  "r": 262145,
  "p": [
    {
      "n": "m",
      "p": 116850689
    }
  ],
  "n": "",
  "d": 327716,
  "h": 0,
  "f": 17825794
})).System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Reflection.MethodInfo]);
                    if (!en.System$Collections$IEnumerator$MoveNext())
                    {
                        throw $.$slq.System.Linq.Error.NoMethodOnType(name, type);
                    }
                    do
                    {
                        /*MethodInfo*/ let mi = en.System$Collections$Generic$IEnumerator$$$Current;
                        if ($.$slq.System.Linq.EnumerableRewriter.ArgsMatch(mi, args, typeArgs))
                        {
                            return (typeArgs !== null) ? mi.MakeGenericMethod(typeArgs) : mi;
                        }
                    }
                    while(en.System$Collections$IEnumerator$MoveNext());
                }
                finally
                {
                    en?.System$IDisposable$Dispose();
                }
                throw $.$slq.System.Linq.Error.NoMethodOnTypeMatchingArguments(name, type);
            }
            //--TRIMMABLE-BOUNDARY-END(25770131492)
            
            //--TRIMMABLE-BOUNDARY-START(17180196900)
            static /*bool */ ArgsMatch(/*MethodInfo*/ m, /*ReadOnlyCollection<Expression>*/ args, /*Type[]?*/ typeArgs)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180196900);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ParameterInfo[]*/ let mParams = m.GetParameters();
                if (mParams.length !== args.Count)
                {
                    return false;
                }
                if (!m.IsGenericMethod && typeArgs !== null && typeArgs.length > 0)
                {
                    return false;
                }
                if (!m.IsGenericMethodDefinition && m.IsGenericMethod && m.ContainsGenericParameters$1)
                {
                    m = m.GetGenericMethodDefinition();
                }
                if (m.IsGenericMethodDefinition)
                {
                    if (typeArgs === null || typeArgs.length === 0)
                    {
                        return false;
                    }
                    if (m.GetGenericArguments().length !== typeArgs.length)
                    {
                        return false;
                    }
                    mParams = GetConstrutedGenericParameters(m, typeArgs);
                    /*static ParameterInfo[]*/  function GetConstrutedGenericParameters(/*MethodInfo*/ method, /*Type[]*/ genericTypes)
                    {
                        {
                            return method.MakeGenericMethod(genericTypes).GetParameters();
                        }
                    }
                }
                for(/*int*/ let i = 0, n = args.Count; i < n; i++)
                {
                    /*Type*/ let parameterType = $.$$.System.Array.$ReadT1.call(mParams, i).ParameterType;
                    if ($.$$.System.Type.op_Equality$1(parameterType, null))
                    {
                        return false;
                    }
                    if (parameterType.IsByRef)
                    {
                        parameterType = parameterType.GetElementType();
                    }
                    /*Expression*/ let arg = args.get_Item(i);
                    if (!parameterType.IsAssignableFrom(arg.Type))
                    {
                        if (arg.NodeType === 40/*ExpressionType.Quote*/)
                        {
                            arg = ($.$cast(arg, $.$sle.System.Linq.Expressions.UnaryExpression)).Operand;
                        }
                        if (!parameterType.IsAssignableFrom(arg.Type) && !parameterType.IsAssignableFrom($.$slq.System.Linq.EnumerableRewriter.StripExpression(arg.Type)))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(17180196900)
            
            //--TRIMMABLE-BOUNDARY-START(51539935268)
            static /*Type */ StripExpression(/*Type*/ type)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539935268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let isArray = type.IsArray;
                /*Type*/ let tmp = isArray ? type.GetElementType() : type;
                /*Type?*/ let eType = $.$slq.System.Linq.TypeHelper.FindGenericType($.$sle.System.Linq.Expressions.Expression$$().$type, tmp);
                if ($.$$.System.Type.op_Inequality$1(eType, null))
                {
                    tmp = $.$$.System.Array.$ReadT1.call(eType.GetGenericArguments(), 0);
                }
                if (isArray)
                {
                    /*int*/ let rank = type.GetArrayRank();
                    return (rank === 1) ? tmp.MakeArrayType() : tmp.MakeArrayType$1(rank);
                }
                return type;
            }
            //--TRIMMABLE-BOUNDARY-END(51539935268)
            
            //--TRIMMABLE-BOUNDARY-START(60129869860)
            /*Expression */ VisitConditional(/*ConditionalExpression*/ c)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129869860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let type = c.Type;
                if (!$.$sle.System.Linq.IQueryable.$type.IsAssignableFrom(type))
                {
                    return super.VisitConditional(c);
                }
                /*Expression*/ let test = this.Visit$1(c.Test);
                /*Expression*/ let ifTrue = this.Visit$1(c.IfTrue);
                /*Expression*/ let ifFalse = this.Visit$1(c.IfFalse);
                /*Type*/ let trueType = ifTrue.Type;
                /*Type*/ let falseType = ifFalse.Type;
                if (trueType.IsAssignableFrom(falseType))
                {
                    return $.$sle.System.Linq.Expressions.Expression.Condition(test, ifTrue, ifFalse, trueType);
                }
                if (falseType.IsAssignableFrom(trueType))
                {
                    return $.$sle.System.Linq.Expressions.Expression.Condition(test, ifTrue, ifFalse, falseType);
                }
                return $.$sle.System.Linq.Expressions.Expression.Condition(test, ifTrue, ifFalse, this.GetEquivalentType(type));
            }
            //--TRIMMABLE-BOUNDARY-END(60129869860)
            
            //--TRIMMABLE-BOUNDARY-START(55834902564)
            /*Expression */ VisitBlock(/*BlockExpression*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834902564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let type = node.Type;
                if (!$.$sle.System.Linq.IQueryable.$type.IsAssignableFrom(type))
                {
                    return super.VisitBlock(node);
                }
                /*ReadOnlyCollection<Expression>*/ let nodes = this.Visit(node.Expressions);
                /*ReadOnlyCollection<ParameterExpression>*/ let variables = this.VisitAndConvert($.$sle.System.Linq.Expressions.ParameterExpression, node.Variables, "EnumerableRewriter.VisitBlock");
                if ($.$$.System.Type.op_Equality$1(type, $.$sl.System.Linq.Enumerable.Last$1($.$sle.System.Linq.Expressions.Expression, node.Expressions).Type))
                {
                    return $.$sle.System.Linq.Expressions.Expression.Block$1(variables, nodes);
                }
                return $.$sle.System.Linq.Expressions.Expression.Block$4(this.GetEquivalentType(type), variables, nodes);
            }
            //--TRIMMABLE-BOUNDARY-END(55834902564)
            
            //--TRIMMABLE-BOUNDARY-START(68719804452)
            /*Expression */ VisitGoto(/*GotoExpression*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719804452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Type*/ let type = node.Value.Type;
                if (!$.$sle.System.Linq.IQueryable.$type.IsAssignableFrom(type))
                {
                    return super.VisitGoto(node);
                }
                /*LabelTarget*/ let target = this.VisitLabelTarget(node.Target);
                /*Expression*/ let value = this.Visit$1(node.Value);
                return $.$sle.System.Linq.Expressions.Expression.MakeGoto(node.Kind, target, value, this.GetEquivalentType($.$slq.System.Linq.EnumerableQuery.$type.IsAssignableFrom(type) ? value.Type : type));
            }
            //--TRIMMABLE-BOUNDARY-END(68719804452)
            
            //--TRIMMABLE-BOUNDARY-START(73014771748)
            /*LabelTarget */ VisitLabelTarget(/*LabelTarget?*/ node)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014771748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*LabelTarget?*/ let newTarget;
                if (this._targetCache === null)
                {
                    this._targetCache = new ($.$$.System.Collections.Generic.Dictionary$$$($.$sle.System.Linq.Expressions.LabelTarget, $.$sle.System.Linq.Expressions.LabelTarget))().$ctor$1();
                }
                else if (this._targetCache.TryGetValue(node, $.$ref(() => newTarget, ($v) => newTarget = $v, $.$sle.System.Linq.Expressions.LabelTarget)))
                {
                    return newTarget;
                }
                /*Type*/ let type = node.Type;
                if (!$.$sle.System.Linq.IQueryable.$type.IsAssignableFrom(type))
                {
                    newTarget = super.VisitLabelTarget(node);
                }
                else 
                {
                    newTarget = $.$sle.System.Linq.Expressions.Expression.Label$2(this.GetEquivalentType(type), node.Name);
                }
                this._targetCache.Add(node, newTarget);
                return newTarget;
            }
            //--TRIMMABLE-BOUNDARY-END(73014771748)
            
            static $h = 327716;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 11337765,
  "m": [
//--TRIMMABLE-BOUNDARY-START(81604706340),
    {
      "r": 8781861,
      "p": [
        {
          "n": "m",
          "p": 39649317
        }
      ],
      "n": "VisitMethodCall",
      "d": 327716,
      "h": 81604706340,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(81604706340),
//--TRIMMABLE-BOUNDARY-START(30065098788),
    {
      "r": $.$$.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sle.System.Linq.Expressions.Expression).$h,
      "p": [
        {
          "n": "mi",
          "p": 116850689
        },
        {
          "n": "argList",
          "p": $.$$.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sle.System.Linq.Expressions.Expression).$h
        }
      ],
      "n": "FixupQuotedArgs",
      "d": 327716,
      "h": 30065098788,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30065098788),
//--TRIMMABLE-BOUNDARY-START(34360066084),
    {
      "r": 8781861,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "expression",
          "p": 8781861
        }
      ],
      "n": "FixupQuotedExpression",
      "d": 327716,
      "h": 34360066084,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34360066084),
//--TRIMMABLE-BOUNDARY-START(77309739044),
    {
      "r": 8781861,
      "p": [
        {
          "n": "node",
          "p": (T) => $.$sle.System.Linq.Expressions.Expression$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "VisitLambda",
      "d": 327716,
      "h": 77309739044,
      "f": 16941060
    },
//--TRIMMABLE-BOUNDARY-END(77309739044),
//--TRIMMABLE-BOUNDARY-START(42950000676),
    {
      "r": 187760641,
      "p": [
        {
          "n": "t",
          "p": 187760641
        }
      ],
      "n": "GetPublicType",
      "d": 327716,
      "h": 42950000676,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42950000676),
//--TRIMMABLE-BOUNDARY-START(38655033380),
    {
      "r": 187760641,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "GetEquivalentType",
      "d": 327716,
      "h": 38655033380,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(38655033380),
//--TRIMMABLE-BOUNDARY-START(64424837156),
    {
      "r": 8781861,
      "p": [
        {
          "n": "c",
          "p": 7864357
        }
      ],
      "n": "VisitConstant",
      "d": 327716,
      "h": 64424837156,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(64424837156),
//--TRIMMABLE-BOUNDARY-START(21475164196),
    {
      "r": 116850689,
      "p": [
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$$.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sle.System.Linq.Expressions.Expression).$h
        },
        {
          "n": "typeArgs",
          "p": $.$typeArray($.$$.System.Type).$h,
          "f": 16
        }
      ],
      "n": "FindEnumerableMethodForQueryable",
      "d": 327716,
      "h": 21475164196,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21475164196),
//--TRIMMABLE-BOUNDARY-START(25770131492),
    {
      "r": 116850689,
      "p": [
        {
          "n": "type",
          "p": 187760641
        },
        {
          "n": "name",
          "p": 1310721
        },
        {
          "n": "args",
          "p": $.$$.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sle.System.Linq.Expressions.Expression).$h
        },
        {
          "n": "typeArgs",
          "p": $.$typeArray($.$$.System.Type).$h
        }
      ],
      "n": "FindMethod",
      "d": 327716,
      "h": 25770131492,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25770131492),
//--TRIMMABLE-BOUNDARY-START(17180196900),
    {
      "r": 262145,
      "p": [
        {
          "n": "m",
          "p": 116850689
        },
        {
          "n": "args",
          "p": $.$$.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sle.System.Linq.Expressions.Expression).$h
        },
        {
          "n": "typeArgs",
          "p": $.$typeArray($.$$.System.Type).$h
        }
      ],
      "n": "ArgsMatch",
      "d": 327716,
      "h": 17180196900,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17180196900),
//--TRIMMABLE-BOUNDARY-START(51539935268),
    {
      "r": 187760641,
      "p": [
        {
          "n": "type",
          "p": 187760641
        }
      ],
      "n": "StripExpression",
      "d": 327716,
      "h": 51539935268,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(51539935268),
//--TRIMMABLE-BOUNDARY-START(60129869860),
    {
      "r": 8781861,
      "p": [
        {
          "n": "c",
          "p": 7733285
        }
      ],
      "n": "VisitConditional",
      "d": 327716,
      "h": 60129869860,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(60129869860),
//--TRIMMABLE-BOUNDARY-START(55834902564),
    {
      "r": 8781861,
      "p": [
        {
          "n": "node",
          "p": 3997733
        }
      ],
      "n": "VisitBlock",
      "d": 327716,
      "h": 55834902564,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(55834902564),
//--TRIMMABLE-BOUNDARY-START(68719804452),
    {
      "r": 8781861,
      "p": [
        {
          "n": "node",
          "p": 11665445
        }
      ],
      "n": "VisitGoto",
      "d": 327716,
      "h": 68719804452,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(68719804452),
//--TRIMMABLE-BOUNDARY-START(73014771748),
    {
      "r": 38731813,
      "p": [
        {
          "n": "node",
          "p": 38731813
        }
      ],
      "n": "VisitLabelTarget",
      "d": 327716,
      "h": 73014771748,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(73014771748)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590262308),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$sle.System.Linq.Expressions.LabelTarget, $.$sle.System.Linq.Expressions.LabelTarget).$h,
      "n": "_targetCache",
      "d": 327716,
      "h": 8590262308,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590262308),
//--TRIMMABLE-BOUNDARY-START(4295295012),
    {
      "t": $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Type, $.$$.System.Type).$h,
      "n": "_equivalentTypeCache",
      "d": 327716,
      "h": 4295295012,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295295012),
//--TRIMMABLE-BOUNDARY-START(47244967972),
    {
      "t": $.$sl.System.Linq.ILookup$$$($.$$.System.String, $.$$.System.Reflection.MethodInfo).$h,
      "n": "s_seqMethods",
      "d": 327716,
      "h": 47244967972,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47244967972)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885229604),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327716,
      "h": 12885229604,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885229604)
  ],
  "h": 327716
}; }
            static get $b() { return $.$sle.System.Linq.Expressions.ExpressionVisitor; }
            static get $fullName() { return `System.Linq.EnumerableRewriter`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327716)
        
        
        //--TRIMMABLE-BOUNDARY-START(131108)
        $asm.$cls("$slq.System.Linq.EnumerableExecutor<>", (T) => $asm.$gt("$slq.System.Linq.EnumerableExecutor<>", [T], ($self) => class EnumerableExecutor$$ extends $.$slq.System.Linq.EnumerableExecutor
        {
            //--TRIMMABLE-BOUNDARY-START(4295098404)
            /*Expression*/ _expression = null;
            //--TRIMMABLE-BOUNDARY-END(4295098404)
            
            //--TRIMMABLE-BOUNDARY-START(8590065700)
            $ctor$2(/*Expression*/ expression)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065700);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._expression = expression;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065700)
            
            //--TRIMMABLE-BOUNDARY-START(17180000292)
            /*object? */ ExecuteBoxed()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180000292);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$box(this.Execute(), T);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180000292)
            
            //--TRIMMABLE-BOUNDARY-START(12885032996)
            /*T */ Execute()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885032996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*EnumerableRewriter*/ let rewriter = new $.$slq.System.Linq.EnumerableRewriter().$ctor$2();
                /*Expression*/ let body = rewriter.Visit$1(this._expression);
                /*Expression<Func<T>>*/ let f = $.$sle.System.Linq.Expressions.Expression.Lambda$14($.$$.System.Func$$(T), body, null);
                /*Func<T>*/ let func = f.Compile$3();
                return func.Invoke();
            }
            //--TRIMMABLE-BOUNDARY-END(12885032996)
            
            static $h = 131108;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 65572,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180000292),
    {
      "r": 131073,
      "n": "ExecuteBoxed",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16809992
    },
//--TRIMMABLE-BOUNDARY-END(17180000292),
//--TRIMMABLE-BOUNDARY-START(12885032996),
    {
      "r": T?.$h??1507328,
      "n": "Execute",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(12885032996)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295098404),
    {
      "t": 8781861,
      "n": "_expression",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295098404)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590065700),
    {
      "p": [
        {
          "n": "expression",
          "p": 8781861
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065700)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$slq.System.Linq.EnumerableExecutor; }
            static get $fullName() { return `System.Linq.EnumerableExecutor<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(131108)
        
        
        //--TRIMMABLE-BOUNDARY-START(262180)
        $asm.$cls("$slq.System.Linq.EnumerableQuery<>", (T) => $asm.$gt("$slq.System.Linq.EnumerableQuery<>", [T], ($self) => class EnumerableQuery$$ extends $.$slq.System.Linq.EnumerableQuery
        {
            //--TRIMMABLE-BOUNDARY-START(8590196772)
            /*Expression*/ _expression = null;
            //--TRIMMABLE-BOUNDARY-END(8590196772)
            
            //--TRIMMABLE-BOUNDARY-START(4295229476)
            /*IEnumerable<T>?*/ _enumerable = null;
            //--TRIMMABLE-BOUNDARY-END(4295229476)
            
            //--TRIMMABLE-BOUNDARY-START(94489542692)
            /*IQueryProvider */ get System$Linq$IQueryable$Provider()
            {
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(94489542692)
            
            //--TRIMMABLE-BOUNDARY-START(12885164068)
            $ctor$2(/*IEnumerable<T>*/ enumerable)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885164068);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._enumerable = enumerable;
                    this._expression = $.$sle.System.Linq.Expressions.Expression.Constant$1(this);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885164068)
            
            //--TRIMMABLE-BOUNDARY-START(17180131364)
            $ctor$3(/*Expression*/ expression)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180131364);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._expression = expression;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131364)
            
            //--TRIMMABLE-BOUNDARY-START(25770065956)
            /*Expression */ get Expression()
            {
                return this._expression;
            }
            //--TRIMMABLE-BOUNDARY-END(25770065956)
            
            //--TRIMMABLE-BOUNDARY-START(21475098660)
            /*IEnumerable? */ get Enumerable()
            {
                return this._enumerable;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098660)
            
            //--TRIMMABLE-BOUNDARY-START(64424771620)
            /*Expression */ get System$Linq$IQueryable$Expression()
            {
                return this._expression;
            }
            //--TRIMMABLE-BOUNDARY-END(64424771620)
            
            //--TRIMMABLE-BOUNDARY-START(60129804324)
            /*Type */ get System$Linq$IQueryable$ElementType()
            {
                return T.$type;
            }
            //--TRIMMABLE-BOUNDARY-END(60129804324)
            
            //--TRIMMABLE-BOUNDARY-START(98784509988)
            /*IQueryable */ System$Linq$IQueryProvider$CreateQuery(/*Expression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784509988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(expression, "expression");
                /*Type?*/ let iqType = $.$slq.System.Linq.TypeHelper.FindGenericType($.$sle.System.Linq.IQueryable$$().$type, expression.Type);
                if ($.$$.System.Type.op_Equality$1(iqType, null))
                {
                    throw $.$slq.System.Linq.Error.ArgumentNotValid("expression");
                }
                return $.$slq.System.Linq.EnumerableQuery.Create$1($.$$.System.Array.$ReadT1.call(iqType.GetGenericArguments(), 0), expression);
            }
            //--TRIMMABLE-BOUNDARY-END(98784509988)
            
            //--TRIMMABLE-BOUNDARY-START(103079477284)
            /*IQueryable<TElement> */ System$Linq$IQueryProvider$CreateQuery$1(TElement, /*Expression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079477284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(expression, "expression");
                if (!$.$sle.System.Linq.IQueryable$$(TElement).$type.IsAssignableFrom(expression.Type))
                {
                    throw $.$slq.System.Linq.Error.ArgumentNotValid("expression");
                }
                return new ($.$slq.System.Linq.EnumerableQuery$$(TElement))().$ctor$3(expression);
            }
            //--TRIMMABLE-BOUNDARY-END(103079477284)
            
            //--TRIMMABLE-BOUNDARY-START(107374444580)
            /*object? */ System$Linq$IQueryProvider$Execute(/*Expression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374444580);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(expression, "expression");
                return $.$slq.System.Linq.EnumerableExecutor.Create(expression).ExecuteBoxed();
            }
            //--TRIMMABLE-BOUNDARY-END(107374444580)
            
            //--TRIMMABLE-BOUNDARY-START(111669411876)
            /*TElement */ System$Linq$IQueryProvider$Execute$1(TElement, /*Expression*/ expression)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669411876);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(expression, "expression");
                if (!TElement.$type.IsAssignableFrom(expression.Type))
                {
                    throw $.$slq.System.Linq.Error.ArgumentNotValid("expression");
                }
                return new ($.$slq.System.Linq.EnumerableExecutor$$(TElement))().$ctor$2(expression).Execute();
            }
            //--TRIMMABLE-BOUNDARY-END(111669411876)
            
            //--TRIMMABLE-BOUNDARY-START(55834837028)
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834837028);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834837028)
            
            //--TRIMMABLE-BOUNDARY-START(51539869732)
            /*IEnumerator<T> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539869732);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.GetEnumerator();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51539869732)
            
            //--TRIMMABLE-BOUNDARY-START(47244902436)
            /*IEnumerator<T> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244902436);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._enumerable === null)
                {
                    /*EnumerableRewriter*/ let rewriter = new $.$slq.System.Linq.EnumerableRewriter().$ctor$2();
                    /*Expression*/ let body = rewriter.Visit$1(this._expression);
                    /*Expression<Func<IEnumerable<T>>>*/ let f = $.$sle.System.Linq.Expressions.Expression.Lambda$14($.$$.System.Func$$($.$$.System.Collections.Generic.IEnumerable$$(T)), body, null);
                    /*IEnumerable<T>*/ let enumerable = f.Compile$3().Invoke();
                    if (enumerable === this)
                    {
                        throw $.$slq.System.Linq.Error.EnumeratingNullEnumerableExpression();
                    }
                    this._enumerable = enumerable;
                }
                return this._enumerable.System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            //--TRIMMABLE-BOUNDARY-END(47244902436)
            
            //--TRIMMABLE-BOUNDARY-START(115964379172)
            static/*conventional*/ /*string? */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964379172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let c;
                if ($.$is(this._expression, $.$sle.System.Linq.Expressions.ConstantExpression, { set $v(v){ c = v; } }) && c.Value === this)
                {
                    if (this._enumerable !== null)
                    {
                        return $.$$.System.Object.ToString.call(this._enumerable);
                    }
                    return "null";
                }
                return $.$sle.System.Linq.Expressions.Expression.ToString.call(this._expression);
            }
            //Static convention instance redirect
            /*string? */ ToString() { return $.$slq.System.Linq.EnumerableQuery$$(T).ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(115964379172)
            
            static $h = 262180;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196644,
  "p": [
//--TRIMMABLE-BOUNDARY-START(94489542692),
    {
      "p": 42598437,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331650
      },
      "n": "{42467365}.Provider",
      "o": "System$Linq$IQueryable$Provider",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(94489542692),
//--TRIMMABLE-BOUNDARY-START(25770065956),
    {
      "p": 8781861,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50364424
      },
      "n": "Expression",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2129928
    },
//--TRIMMABLE-BOUNDARY-END(25770065956),
//--TRIMMABLE-BOUNDARY-START(21475098660),
    {
      "p": 62652417,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50364424
      },
      "n": "Enumerable",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2129928
    },
//--TRIMMABLE-BOUNDARY-END(21475098660),
//--TRIMMABLE-BOUNDARY-START(64424771620),
    {
      "p": 8781861,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331650
      },
      "n": "{42467365}.Expression",
      "o": "System$Linq$IQueryable$Expression",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(64424771620),
//--TRIMMABLE-BOUNDARY-START(60129804324),
    {
      "p": 187760641,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331650
      },
      "n": "{42467365}.ElementType",
      "o": "System$Linq$IQueryable$ElementType",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 2097154
    },
//--TRIMMABLE-BOUNDARY-END(60129804324)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(47244902436),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$(T).$h,
      "n": "GetEnumerator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(47244902436),
//--TRIMMABLE-BOUNDARY-START(115964379172),
    {
      "r": 1310721,
      "n": "ToString",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(115964379172)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8590196772),
    {
      "t": 8781861,
      "n": "_expression",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590196772),
//--TRIMMABLE-BOUNDARY-START(4295229476),
    {
      "t": $.$$.System.Collections.Generic.IEnumerable$$(T).$h,
      "n": "_enumerable",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295229476)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885164068),
    {
      "p": [
        {
          "n": "enumerable",
          "p": $.$$.System.Collections.Generic.IEnumerable$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885164068),
//--TRIMMABLE-BOUNDARY-START(17180131364),
    {
      "p": [
        {
          "n": "expression",
          "p": 8781861
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180131364)
  ],
  "i": [$.$sle.System.Linq.IOrderedQueryable$$(T).$h,$.$sle.System.Linq.IQueryable$$(T).$h,$.$$.System.Collections.Generic.IEnumerable$$(T).$h,42336293,42467365,62652417,42598437
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$slq.System.Linq.EnumerableQuery; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sle.System.Linq.IOrderedQueryable$$(T), $.$sle.System.Linq.IQueryable$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$sle.System.Linq.IOrderedQueryable, $.$sle.System.Linq.IQueryable, $.$$.System.Collections.IEnumerable, $.$sle.System.Linq.IQueryProvider ]; }
            static get $fullName() { return `System.Linq.EnumerableQuery<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(262180)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.ObjectModel", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions"))
//--TRIMMABLE-BOUNDARY-END(36)
