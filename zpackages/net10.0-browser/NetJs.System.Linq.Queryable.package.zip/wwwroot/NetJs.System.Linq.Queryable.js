
(function ($global, $, $$, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $sic, $stt, $sim, $so, $stee, $srm, $sre, $srei, $srel, $srp, $sle) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Linq.Queryable", 
    {"h":42372,"f":"System.Linq.Queryable","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Linq.Queryable","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Linq.Queryable","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$slq.System.Linq.EnumerableExecutor", ($self) => class EnumerableExecutor extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*EnumerableExecutor */ Create(/*Expression*/ expression)
            {
                /*Type*/ let execType = $.$slq.System.Linq.EnumerableExecutor$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ expression.Type ], null, null));
                return $.$cast($.$$.System.Activator.CreateInstance$6(execType, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ expression ], null, null)), $.$slq.System.Linq.EnumerableExecutor);
            }
            static $h = 107908;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":131073,"n":"ExecuteBoxed","d":107908,"h":4295075204,"f":16777480},{"r":107908,"p":[{"n":"expression","p":8687477}],"n":"Create","d":107908,"h":12885009796,"f":16777256}],"c":[{"n":".ctor","o":"$ctor$1","d":107908,"h":8590042500,"f":16777224}],"h":107908}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Linq.EnumerableExecutor`; }
        });
        
        $asm.$cls("$slq.System.Linq.EnumerableQuery", ($self) => class EnumerableQuery extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*IQueryable */ Create(/*Type*/ elementType, /*IEnumerable*/ sequence)
            {
                /*Type*/ let seqType = $.$slq.System.Linq.EnumerableQuery$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ elementType ], null, null));
                return $.$cast($.$$.System.Activator.CreateInstance$6(seqType, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ sequence ], null, null)), $.$sle.System.Linq.IQueryable);
            }
            static /*IQueryable */ Create$1(/*Type*/ elementType, /*Expression*/ expression)
            {
                /*Type*/ let seqType = $.$slq.System.Linq.EnumerableQuery$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ elementType ], null, null));
                return $.$cast($.$$.System.Activator.CreateInstance$6(seqType, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Object), [ expression ], null, null)), $.$sle.System.Linq.IQueryable);
            }
            static $h = 238980;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":8687477,"g":{"r":0,"d":0,"h":8590173572,"f":50331912},"n":"Expression","d":238980,"h":4295206276,"f":2097416},{"p":31719425,"g":{"r":0,"d":0,"h":17180108164,"f":50331912},"n":"Enumerable","d":238980,"h":12885140868,"f":2097416}],"m":[{"r":42110837,"p":[{"n":"elementType","p":142475265},{"n":"sequence","p":31719425}],"n":"Create","d":238980,"h":25770042756,"f":16777256},{"r":42110837,"p":[{"n":"elementType","p":142475265},{"n":"expression","p":8687477}],"n":"Create","o":"@$1","d":238980,"h":30065010052,"f":16777256}],"c":[{"n":".ctor","o":"$ctor$1","d":238980,"h":21475075460,"f":16777224}],"h":238980}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Linq.EnumerableQuery`; }
        });
        
        $asm.$cls("$slq.System.Linq.Strings", ($self) => class Strings
        {
            static /*string */ ArgumentNotIEnumerableGeneric(/*string*/ message)
            {
                return $.$slq.System.SR.Format$6($.$slq.System.SR.ArgumentNotIEnumerableGeneric, message);
            }
            static /*string */ ArgumentNotValid(/*string*/ message)
            {
                return $.$slq.System.SR.Format$6($.$slq.System.SR.ArgumentNotValid, message);
            }
            static /*string */ NoMethodOnType(/*string*/ name, /*object*/ type)
            {
                return $.$slq.System.SR.Format$5($.$slq.System.SR.NoMethodOnType, name, type);
            }
            static /*string */ NoMethodOnTypeMatchingArguments(/*string*/ name, /*object*/ type)
            {
                return $.$slq.System.SR.Format$5($.$slq.System.SR.NoMethodOnTypeMatchingArguments, name, type);
            }
            static /*string */ EnumeratingNullEnumerableExpression()
            {
                return $.$slq.System.SR.EnumeratingNullEnumerableExpression;
            }
            static $h = 566660;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"message","p":1310721}],"n":"ArgumentNotIEnumerableGeneric","d":566660,"h":4295533956,"f":16777256},{"r":1310721,"p":[{"n":"message","p":1310721}],"n":"ArgumentNotValid","d":566660,"h":8590501252,"f":16777256},{"r":1310721,"p":[{"n":"name","p":1310721},{"n":"type","p":131073}],"n":"NoMethodOnType","d":566660,"h":12885468548,"f":16777256},{"r":1310721,"p":[{"n":"name","p":1310721},{"n":"type","p":131073}],"n":"NoMethodOnTypeMatchingArguments","d":566660,"h":17180435844,"f":16777256},{"r":1310721,"n":"EnumeratingNullEnumerableExpression","d":566660,"h":21475403140,"f":16777256}],"h":566660}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Linq.Strings`; }
        });
        
        $asm.$cls("$slq.System.Linq.Error", ($self) => class Error
        {
            static /*Exception */ ArgumentNotIEnumerableGeneric(/*string*/ message)
            {
                return new $.$$.System.ArgumentException().$ctor$14($.$slq.System.Linq.Strings.ArgumentNotIEnumerableGeneric(message));
            }
            static /*Exception */ ArgumentNotValid(/*string*/ message)
            {
                return new $.$$.System.ArgumentException().$ctor$14($.$slq.System.Linq.Strings.ArgumentNotValid(message));
            }
            static /*Exception */ ArgumentOutOfRange(/*string*/ message)
            {
                return new $.$$.System.ArgumentOutOfRangeException().$ctor$20(message);
            }
            static /*Exception */ NoMethodOnType(/*string*/ name, /*object*/ type)
            {
                return new $.$$.System.InvalidOperationException().$ctor$12($.$slq.System.Linq.Strings.NoMethodOnType(name, type));
            }
            static /*Exception */ NoMethodOnTypeMatchingArguments(/*string*/ name, /*object*/ type)
            {
                return new $.$$.System.InvalidOperationException().$ctor$12($.$slq.System.Linq.Strings.NoMethodOnTypeMatchingArguments(name, type));
            }
            static /*Exception */ EnumeratingNullEnumerableExpression()
            {
                return new $.$$.System.InvalidOperationException().$ctor$12($.$slq.System.Linq.Strings.EnumeratingNullEnumerableExpression());
            }
            static $h = 435588;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":47251457,"p":[{"n":"message","p":1310721}],"n":"ArgumentNotIEnumerableGeneric","d":435588,"h":4295402884,"f":16777256},{"r":47251457,"p":[{"n":"message","p":1310721}],"n":"ArgumentNotValid","d":435588,"h":8590370180,"f":16777256},{"r":47251457,"p":[{"n":"message","p":1310721}],"n":"ArgumentOutOfRange","d":435588,"h":12885337476,"f":16777256},{"r":47251457,"p":[{"n":"name","p":1310721},{"n":"type","p":131073}],"n":"NoMethodOnType","d":435588,"h":17180304772,"f":16777256},{"r":47251457,"p":[{"n":"name","p":1310721},{"n":"type","p":131073}],"n":"NoMethodOnTypeMatchingArguments","d":435588,"h":21475272068,"f":16777256},{"r":47251457,"n":"EnumeratingNullEnumerableExpression","d":435588,"h":25770239364,"f":16777256}],"h":435588}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Linq.Error`; }
        });
        
        $asm.$cls("$slq.System.Linq.TypeHelper", ($self) => class TypeHelper
        {
            static /*Type? */ FindGenericType(/*Type*/ definition, /*Type*/ type)
            {
                /*bool?*/ let definitionIsInterface = null;
                while($.$$.System.Type.op_Inequality$1(type, null) && $.$$.System.Type.op_Inequality$1(type, $.$$.System.Object.$type))
                {
                    if (type.IsGenericType && $.$$.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), definition))
                    {
                        return type;
                    }
                    if (!$.$$.System.Nullable$$($.$$.System.Boolean).HasValue$get.call(definitionIsInterface))
                    {
                        definitionIsInterface = definition.IsInterface;
                    }
                    if ($.$$.System.Nullable$$($.$$.System.Boolean).GetValueOrDefault.call(definitionIsInterface))
                    {
                        let $i1 = 0;
                        let $arr1 = type.GetInterfaces();
                        while ($i1 < $arr1.length)
                        {
                            let itype = $arr1[$i1++];
                            /*Type?*/ let found = $.$slq.System.Linq.TypeHelper.FindGenericType(definition, itype);
                            if ($.$$.System.Type.op_Inequality$1(found, null))
                            {
                                return found;
                            }
                        }
                    }
                    type = type.BaseType;
                }
                return null;
            }
            static $h = 632196;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":142475265,"p":[{"n":"definition","p":142475265},{"n":"type","p":142475265}],"n":"FindGenericType","d":632196,"h":4295599492,"f":16777256}],"h":632196}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Linq.TypeHelper`; }
        });
        
        $asm.$cls("$slq.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 697732;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":697732,"h":4295665028,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":697732,"h":8590632324,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":697732,"h":12885599620,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":697732,"h":17180566916,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":697732,"h":21475534212,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityMessage","d":697732,"h":25770501508,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":697732,"h":30065468804,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":697732,"h":34360436100,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":697732,"h":38655403396,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":697732,"h":42950370692,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":697732,"h":47245337988,"f":4194344},{"t":1310721,"n":"ThreadAbortMessage","d":697732,"h":51540305284,"f":4194344},{"t":1310721,"n":"ThreadResetAbortMessage","d":697732,"h":55835272580,"f":4194344},{"t":1310721,"n":"ThreadAbortDiagId","d":697732,"h":60130239876,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":697732,"h":64425207172,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":697732,"h":68720174468,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":697732,"h":73015141764,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":697732,"h":77310109060,"f":4194344},{"t":1310721,"n":"AuthenticationManagerMessage","d":697732,"h":81605076356,"f":4194344},{"t":1310721,"n":"AuthenticationManagerDiagId","d":697732,"h":85900043652,"f":4194344},{"t":1310721,"n":"RemotingApisMessage","d":697732,"h":90195010948,"f":4194344},{"t":1310721,"n":"RemotingApisDiagId","d":697732,"h":94489978244,"f":4194344},{"t":1310721,"n":"BinaryFormatterMessage","d":697732,"h":98784945540,"f":4194344},{"t":1310721,"n":"BinaryFormatterDiagId","d":697732,"h":103079912836,"f":4194344},{"t":1310721,"n":"CodeBaseMessage","d":697732,"h":107374880132,"f":4194344},{"t":1310721,"n":"CodeBaseDiagId","d":697732,"h":111669847428,"f":4194344},{"t":1310721,"n":"EscapeUriStringMessage","d":697732,"h":115964814724,"f":4194344},{"t":1310721,"n":"EscapeUriStringDiagId","d":697732,"h":120259782020,"f":4194344},{"t":1310721,"n":"WebRequestMessage","d":697732,"h":124554749316,"f":4194344},{"t":1310721,"n":"WebRequestDiagId","d":697732,"h":128849716612,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":697732,"h":133144683908,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":697732,"h":137439651204,"f":4194344},{"t":1310721,"n":"GetContextInfoMessage","d":697732,"h":141734618500,"f":4194344},{"t":1310721,"n":"GetContextInfoDiagId","d":697732,"h":146029585796,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairMessage","d":697732,"h":150324553092,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":697732,"h":154619520388,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":697732,"h":158914487684,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":697732,"h":163209454980,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":697732,"h":167504422276,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":697732,"h":171799389572,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":697732,"h":176094356868,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":697732,"h":180389324164,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":697732,"h":184684291460,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":697732,"h":188979258756,"f":4194344},{"t":1310721,"n":"RijndaelMessage","d":697732,"h":193274226052,"f":4194344},{"t":1310721,"n":"RijndaelDiagId","d":697732,"h":197569193348,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":697732,"h":201864160644,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":697732,"h":206159127940,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":697732,"h":210454095236,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":697732,"h":214749062532,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":697732,"h":219044029828,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":697732,"h":223338997124,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableMessage","d":697732,"h":227633964420,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":697732,"h":231928931716,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyMessage","d":697732,"h":236223899012,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":697732,"h":240518866308,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":697732,"h":244813833604,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":697732,"h":249108800900,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":697732,"h":253403768196,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":697732,"h":257698735492,"f":4194344},{"t":1310721,"n":"UseManagedSha1Message","d":697732,"h":261993702788,"f":4194344},{"t":1310721,"n":"UseManagedSha1DiagId","d":697732,"h":266288670084,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":697732,"h":270583637380,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":697732,"h":274878604676,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":697732,"h":279173571972,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":697732,"h":283468539268,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":697732,"h":287763506564,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":697732,"h":292058473860,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":697732,"h":296353441156,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":697732,"h":300648408452,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":697732,"h":304943375748,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":697732,"h":309238343044,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":697732,"h":313533310340,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":697732,"h":317828277636,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersMessage","d":697732,"h":322123244932,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":697732,"h":326418212228,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":697732,"h":330713179524,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":697732,"h":335008146820,"f":4194344},{"t":1310721,"n":"TlsVersion10and11Message","d":697732,"h":339303114116,"f":4194344},{"t":1310721,"n":"TlsVersion10and11DiagId","d":697732,"h":343598081412,"f":4194344},{"t":1310721,"n":"EncryptionPolicyMessage","d":697732,"h":347893048708,"f":4194344},{"t":1310721,"n":"EncryptionPolicyDiagId","d":697732,"h":352188016004,"f":4194344},{"t":1310721,"n":"EccXmlExportImportMessage","d":697732,"h":356482983300,"f":4194344},{"t":1310721,"n":"EccXmlExportImportDiagId","d":697732,"h":360777950596,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":697732,"h":365072917892,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":697732,"h":369367885188,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":697732,"h":373662852484,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":697732,"h":377957819780,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryMessage","d":697732,"h":382252787076,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":697732,"h":386547754372,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunMessage","d":697732,"h":390842721668,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":697732,"h":395137688964,"f":4194344},{"t":1310721,"n":"XmlSecureResolverMessage","d":697732,"h":399432656260,"f":4194344},{"t":1310721,"n":"XmlSecureResolverDiagId","d":697732,"h":403727623556,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":697732,"h":408022590852,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":697732,"h":412317558148,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":697732,"h":416612525444,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":697732,"h":420907492740,"f":4194344},{"t":1310721,"n":"LegacyFormatterMessage","d":697732,"h":425202460036,"f":4194344},{"t":1310721,"n":"LegacyFormatterDiagId","d":697732,"h":429497427332,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplMessage","d":697732,"h":433792394628,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":697732,"h":438087361924,"f":4194344},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":697732,"h":442382329220,"f":4194344},{"t":1310721,"n":"RegexExtensibilityDiagId","d":697732,"h":446677296516,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":697732,"h":450972263812,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":697732,"h":455267231108,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":697732,"h":459562198404,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":697732,"h":463857165700,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":697732,"h":468152132996,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":697732,"h":472447100292,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":697732,"h":476742067588,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":697732,"h":481037034884,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":697732,"h":485332002180,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":697732,"h":489626969476,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":697732,"h":493921936772,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":697732,"h":498216904068,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":697732,"h":502511871364,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":697732,"h":506806838660,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":697732,"h":511101805956,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":697732,"h":515396773252,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":697732,"h":519691740548,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":697732,"h":523986707844,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":697732,"h":528281675140,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":697732,"h":532576642436,"f":4194344}],"h":697732}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$slq.System.SR", ($self) => class SR
        {
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$slq.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$slq.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$slq.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$slq.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$slq.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$slq.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Linq.Queryable", $.$slq.System.SR.$type.Assembly);
                    $.$slq.System.SR.s_resourceManager = temp;
                }
                return $.$slq.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$slq.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$slq.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentNotIEnumerableGeneric()
            {
                return "{0} is not IEnumerable<>";
            }
            static /*string */ FormatArgumentNotIEnumerableGeneric(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("{0} is not IEnumerable<>", arg1);
            }
            static /*string */ get ArgumentNotValid()
            {
                return "Argument {0} is not valid";
            }
            static /*string */ FormatArgumentNotValid(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Argument {0} is not valid", arg1);
            }
            static /*string */ get NoMethodOnType()
            {
                return "There is no method '{0}' on type '{1}'";
            }
            static /*string */ FormatNoMethodOnType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("There is no method '{0}' on type '{1}'", arg1, arg2);
            }
            static /*string */ get NoMethodOnTypeMatchingArguments()
            {
                return "There is no method '{0}' on type '{1}' that matches the specified arguments";
            }
            static /*string */ FormatNoMethodOnTypeMatchingArguments(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("There is no method '{0}' on type '{1}' that matches the specified arguments", arg1, arg2);
            }
            static /*string */ get EnumeratingNullEnumerableExpression()
            {
                return "Cannot enumerate a query created from a null IEnumerable<>";
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$slq.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 763268;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":763268}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$slq.System.Linq.Queryable", ($self) => class Queryable
        {
            /*string*/ static InMemoryQueryableExtensionMethodsRequiresUnreferencedCode = null;
            /*string*/ static InMemoryQueryableExtensionMethodsRequiresDynamicCode = null;
            static /*IQueryable<TElement> */ AsQueryable$1(TElement, /*this IEnumerable<TElement>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$as(source, $.$sle.System.Linq.IQueryable$$(TElement)) ?? new ($.$slq.System.Linq.EnumerableQuery$$(TElement))().$ctor$2(source);
            }
            static /*IQueryable */ AsQueryable(/*this IEnumerable*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                let queryable;
                if ($.$is(source, $.$sle.System.Linq.IQueryable, { set $v(v){ queryable = v; } }))
                {
                    return queryable;
                }
                /*Type?*/ let enumType = $.$slq.System.Linq.TypeHelper.FindGenericType($.$$.System.Collections.Generic.IEnumerable$$().$type, $.$$.System.Object.GetType.call(source));
                if ($.$$.System.Type.op_Equality$1(enumType, null))
                {
                    throw $.$slq.System.Linq.Error.ArgumentNotIEnumerableGeneric("source");
                }
                return $.$slq.System.Linq.EnumerableQuery.Create($.$$.System.Array.$ReadT1.call(enumType.GenericTypeArguments, 0), source);
            }
            static /*IQueryable<TSource> */ Where(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Where).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*IQueryable<TSource> */ Where$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, bool>>*/ predicate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Where$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*IQueryable<TResult> */ OfType(TResult, /*this IQueryable*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, $.$slq.System.Linq.Queryable.OfType.Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*IQueryable<TResult> */ Cast(TResult, /*this IQueryable*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, $.$slq.System.Linq.Queryable.Cast.Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*IQueryable<TResult> */ Select$1(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TResult>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Select$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*IQueryable<TResult> */ Select(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, TResult>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Select).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*IQueryable<TResult> */ SelectMany$2(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, IEnumerable<TResult>>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Collections.Generic.IEnumerable$$(TResult))), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SelectMany$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*IQueryable<TResult> */ SelectMany$3(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, IEnumerable<TResult>>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Collections.Generic.IEnumerable$$(TResult))), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SelectMany$3).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*IQueryable<TResult> */ SelectMany$1(TSource, TCollection, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, IEnumerable<TCollection>>>*/ collectionSelector, /*Expression<Func<TSource, TCollection, TResult>>*/ resultSelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collectionSelector, "collectionSelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Collections.Generic.IEnumerable$$(TCollection))), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, TCollection, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SelectMany$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(collectionSelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector)));
            }
            static /*IQueryable<TResult> */ SelectMany(TSource, TCollection, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, IEnumerable<TCollection>>>*/ collectionSelector, /*Expression<Func<TSource, TCollection, TResult>>*/ resultSelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(collectionSelector, "collectionSelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Collections.Generic.IEnumerable$$(TCollection))), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, TCollection, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SelectMany).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(collectionSelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector)));
            }
            static /*Expression */ GetSourceExpression(TSource, /*IEnumerable<TSource>*/ source)
            {
                /*IQueryable<TSource>?*/ let q = $.$as(source, $.$sle.System.Linq.IQueryable$$(TSource));
                return q !== null ? q.System$Linq$IQueryable$Expression : $.$sle.System.Linq.Expressions.Expression.Constant(source, $.$$.System.Collections.Generic.IEnumerable$$(TSource).$type);
            }
            static /*IQueryable<TResult> */ Join$1(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, TInner, TResult>>*/ resultSelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outer, "outer");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outerKeySelector, "outerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerKeySelector, "innerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$$.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Join$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector) ], null, null)));
            }
            static /*IQueryable<TResult> */ Join(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, TInner, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outer, "outer");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outerKeySelector, "outerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerKeySelector, "innerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$$.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Join).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<TResult> */ GroupJoin$1(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, IEnumerable<TInner>, TResult>>*/ resultSelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outer, "outer");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outerKeySelector, "outerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerKeySelector, "innerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$$.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, $.$$.System.Collections.Generic.IEnumerable$$(TInner), TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupJoin$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector) ], null, null)));
            }
            static /*IQueryable<TResult> */ GroupJoin(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, IEnumerable<TInner>, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outer, "outer");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outerKeySelector, "outerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerKeySelector, "innerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$$.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, $.$$.System.Collections.Generic.IEnumerable$$(TInner), TResult)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupJoin).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<TResult> */ LeftJoin$1(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, TInner?, TResult>>*/ resultSelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outer, "outer");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outerKeySelector, "outerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerKeySelector, "innerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$$.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LeftJoin$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector) ], null, null)));
            }
            static /*IQueryable<TResult> */ LeftJoin(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, TInner?, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outer, "outer");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outerKeySelector, "outerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerKeySelector, "innerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$$.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LeftJoin).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IOrderedQueryable<T> */ Order$1(T, /*this IQueryable<T>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(T, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(T), $.$sle.System.Linq.IOrderedQueryable$$(T)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Order$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null))), $.$sle.System.Linq.IOrderedQueryable$$(T));
            }
            static /*IOrderedQueryable<T> */ Order(T, /*this IQueryable<T>*/ source, /*IComparer<T>*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(T, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(T), $.$$.System.Collections.Generic.IComparer$$(T), $.$sle.System.Linq.IOrderedQueryable$$(T)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Order).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(T).$type))), $.$sle.System.Linq.IOrderedQueryable$$(T));
            }
            static /*IOrderedQueryable<TSource> */ OrderBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderBy$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            static /*IOrderedQueryable<TSource> */ OrderBy(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IComparer$$(TKey), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TKey).$type))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            static /*IOrderedQueryable<T> */ OrderDescending$1(T, /*this IQueryable<T>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(T, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(T), $.$sle.System.Linq.IOrderedQueryable$$(T)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderDescending$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null))), $.$sle.System.Linq.IOrderedQueryable$$(T));
            }
            static /*IOrderedQueryable<T> */ OrderDescending(T, /*this IQueryable<T>*/ source, /*IComparer<T>*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(T, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(T), $.$$.System.Collections.Generic.IComparer$$(T), $.$sle.System.Linq.IOrderedQueryable$$(T)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderDescending).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(T).$type))), $.$sle.System.Linq.IOrderedQueryable$$(T));
            }
            static /*IOrderedQueryable<TSource> */ OrderByDescending$1(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderByDescending$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            static /*IOrderedQueryable<TSource> */ OrderByDescending(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IComparer$$(TKey), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderByDescending).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TKey).$type))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            static /*IQueryable<TResult> */ RightJoin$1(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter?, TInner, TResult>>*/ resultSelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outer, "outer");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outerKeySelector, "outerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerKeySelector, "innerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$$.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.RightJoin$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector) ], null, null)));
            }
            static /*IQueryable<TResult> */ RightJoin(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter?, TInner, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outer, "outer");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inner, "inner");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(outerKeySelector, "outerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(innerKeySelector, "innerKeySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$$.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.RightJoin).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IOrderedQueryable<TSource> */ ThenBy$1(TSource, TKey, /*this IOrderedQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IOrderedQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ThenBy$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            static /*IOrderedQueryable<TSource> */ ThenBy(TSource, TKey, /*this IOrderedQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IOrderedQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IComparer$$(TKey), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ThenBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TKey).$type))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            static /*IOrderedQueryable<TSource> */ ThenByDescending$1(TSource, TKey, /*this IOrderedQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IOrderedQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ThenByDescending$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            static /*IOrderedQueryable<TSource> */ ThenByDescending(TSource, TKey, /*this IOrderedQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IOrderedQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IComparer$$(TKey), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ThenByDescending).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TKey).$type))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            static /*IQueryable<TSource> */ Take(TSource, /*this IQueryable<TSource>*/ source, /*int*/ count)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int32, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Take).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(count, $.$$.System.Int32))));
            }
            static /*IQueryable<TSource> */ Take$1(TSource, /*this IQueryable<TSource>*/ source, /*Range*/ range)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Range, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Take$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1(range)));
            }
            static /*IQueryable<TSource> */ TakeWhile(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.TakeWhile).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*IQueryable<TSource> */ TakeWhile$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, bool>>*/ predicate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.TakeWhile$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*IQueryable<TSource> */ Skip(TSource, /*this IQueryable<TSource>*/ source, /*int*/ count)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int32, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Skip).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(count, $.$$.System.Int32))));
            }
            static /*IQueryable<TSource> */ SkipWhile(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SkipWhile).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*IQueryable<TSource> */ SkipWhile$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, bool>>*/ predicate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SkipWhile$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*IQueryable<IGrouping<TKey, TSource>> */ GroupBy$7(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$sl.System.Linq.IGrouping$$$(TKey, TSource), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TSource))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$7).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            static /*IQueryable<IGrouping<TKey, TElement>> */ GroupBy$3(TSource, TKey, TElement, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TSource, TElement>>*/ elementSelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(elementSelector, "elementSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$sl.System.Linq.IGrouping$$$(TKey, TElement), $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TElement)), $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$3).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(elementSelector)));
            }
            static /*IQueryable<IGrouping<TKey, TSource>> */ GroupBy$6(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$sl.System.Linq.IGrouping$$$(TKey, TSource), $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TSource))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$6).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type)));
            }
            static /*IQueryable<IGrouping<TKey, TElement>> */ GroupBy$2(TSource, TKey, TElement, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TSource, TElement>>*/ elementSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(elementSelector, "elementSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$sl.System.Linq.IGrouping$$$(TKey, TElement), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TElement)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$2).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(elementSelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<TResult> */ GroupBy$1(TSource, TKey, TElement, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TSource, TElement>>*/ elementSelector, /*Expression<Func<TKey, IEnumerable<TElement>, TResult>>*/ resultSelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(elementSelector, "elementSelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TElement)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TKey, $.$$.System.Collections.Generic.IEnumerable$$(TElement), TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(elementSelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector) ], null, null)));
            }
            static /*IQueryable<TResult> */ GroupBy$5(TSource, TKey, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TKey, IEnumerable<TSource>, TResult>>*/ resultSelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TKey, $.$$.System.Collections.Generic.IEnumerable$$(TSource), TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$5).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector)));
            }
            static /*IQueryable<TResult> */ GroupBy$4(TSource, TKey, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TKey, IEnumerable<TSource>, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TKey, $.$$.System.Collections.Generic.IEnumerable$$(TSource), TResult)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$4).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<TResult> */ GroupBy(TSource, TKey, TElement, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TSource, TElement>>*/ elementSelector, /*Expression<Func<TKey, IEnumerable<TElement>, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(elementSelector, "elementSelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TElement)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TKey, $.$$.System.Collections.Generic.IEnumerable$$(TElement), TResult)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(elementSelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<TSource> */ Distinct$1(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Distinct$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*IQueryable<TSource> */ Distinct(TSource, /*this IQueryable<TSource>*/ source, /*IEqualityComparer<TSource>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEqualityComparer$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Distinct).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            static /*IQueryable<TSource> */ DistinctBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.DistinctBy$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            static /*IQueryable<TSource> */ DistinctBy(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.DistinctBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type)));
            }
            static /*IQueryable<TSource[]> */ Chunk(TSource, /*this IQueryable<TSource>*/ source, /*int*/ size)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$typeArray(TSource), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int32, $.$sle.System.Linq.IQueryable$$($.$typeArray(TSource))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Chunk).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(size, $.$$.System.Int32))));
            }
            static /*IQueryable<TSource> */ Concat(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Concat).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2)));
            }
            static /*IQueryable<(TFirst First, TSecond Second)> */ Zip$2(TFirst, TSecond, /*this IQueryable<TFirst>*/ source1, /*IEnumerable<TSecond>*/ source2)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$$.System.ValueTuple$$$(TFirst, TSecond), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TFirst), $.$$.System.Collections.Generic.IEnumerable$$(TSecond), $.$sle.System.Linq.IQueryable$$($.$$.System.ValueTuple$$$(TFirst, TSecond))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Zip$2).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSecond, source2)));
            }
            static /*IQueryable<TResult> */ Zip(TFirst, TSecond, TResult, /*this IQueryable<TFirst>*/ source1, /*IEnumerable<TSecond>*/ source2, /*Expression<Func<TFirst, TSecond, TResult>>*/ resultSelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(resultSelector, "resultSelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TFirst), $.$$.System.Collections.Generic.IEnumerable$$(TSecond), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TFirst, TSecond, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Zip).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSecond, source2), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector)));
            }
            static /*IQueryable<(TFirst First, TSecond Second, TThird Third)> */ Zip$1(TFirst, TSecond, TThird, /*this IQueryable<TFirst>*/ source1, /*IEnumerable<TSecond>*/ source2, /*IEnumerable<TThird>*/ source3)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source3, "source3");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$$.System.ValueTuple$$$$(TFirst, TSecond, TThird), $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TFirst), $.$$.System.Collections.Generic.IEnumerable$$(TSecond), $.$$.System.Collections.Generic.IEnumerable$$(TThird), $.$sle.System.Linq.IQueryable$$($.$$.System.ValueTuple$$$$(TFirst, TSecond, TThird))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Zip$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSecond, source2), $.$slq.System.Linq.Queryable.GetSourceExpression(TThird, source3)));
            }
            static /*IQueryable<TSource> */ Union$1(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Union$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2)));
            }
            static /*IQueryable<TSource> */ Union(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*IEqualityComparer<TSource>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$$.System.Collections.Generic.IEqualityComparer$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Union).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            static /*IQueryable<TSource> */ UnionBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.UnionBy$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            static /*IQueryable<TSource> */ UnionBy(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.UnionBy).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<(int Index, TSource Item)> */ Index(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$$.System.ValueTuple$$$($.$$.System.Int32, TSource), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.IQueryable$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TSource))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Index).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*IQueryable<TSource> */ Intersect$1(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Intersect$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2)));
            }
            static /*IQueryable<TSource> */ Intersect(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*IEqualityComparer<TSource>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$$.System.Collections.Generic.IEqualityComparer$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Intersect).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            static /*IQueryable<TSource> */ IntersectBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TKey>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TKey), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.IntersectBy$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TKey, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            static /*IQueryable<TSource> */ IntersectBy(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TKey>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TKey), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.IntersectBy).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TKey, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<TSource> */ Except$1(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Except$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2)));
            }
            static /*IQueryable<TSource> */ Except(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*IEqualityComparer<TSource>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$$.System.Collections.Generic.IEqualityComparer$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Except).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            static /*IQueryable<TSource> */ ExceptBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TKey>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TKey), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ExceptBy$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TKey, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            static /*IQueryable<TSource> */ ExceptBy(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TKey>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TKey), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ExceptBy).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TKey, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*TSource */ First$1(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.First$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*TSource */ First(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.First).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*TSource? */ FirstOrDefault$3(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.FirstOrDefault$3).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*TSource */ FirstOrDefault$2(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ defaultValue)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.FirstOrDefault$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(defaultValue, TSource), TSource.$type)));
            }
            static /*TSource? */ FirstOrDefault$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.FirstOrDefault$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*TSource */ FirstOrDefault(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate, /*TSource*/ defaultValue)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.FirstOrDefault).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate), $.$sle.System.Linq.Expressions.Expression.Constant($.$box(defaultValue, TSource), TSource.$type)));
            }
            static /*TSource */ Last$1(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Last$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*TSource */ Last(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Last).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*TSource? */ LastOrDefault$3(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LastOrDefault$3).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*TSource */ LastOrDefault$2(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ defaultValue)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LastOrDefault$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(defaultValue, TSource), TSource.$type)));
            }
            static /*TSource? */ LastOrDefault$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LastOrDefault$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*TSource */ LastOrDefault(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate, /*TSource*/ defaultValue)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LastOrDefault).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate), $.$sle.System.Linq.Expressions.Expression.Constant($.$box(defaultValue, TSource), TSource.$type)));
            }
            static /*TSource */ Single$1(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Single$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*TSource */ Single(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Single).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*TSource? */ SingleOrDefault$3(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SingleOrDefault$3).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*TSource */ SingleOrDefault$2(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ defaultValue)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SingleOrDefault$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(defaultValue, TSource), TSource.$type)));
            }
            static /*TSource? */ SingleOrDefault$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SingleOrDefault$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*TSource */ SingleOrDefault(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate, /*TSource*/ defaultValue)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SingleOrDefault).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate), $.$sle.System.Linq.Expressions.Expression.Constant($.$box(defaultValue, TSource), TSource.$type)));
            }
            static /*TSource */ ElementAt$1(TSource, /*this IQueryable<TSource>*/ source, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                if (index < 0)
                {
                    throw $.$slq.System.Linq.Error.ArgumentOutOfRange("index");
                }
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int32, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ElementAt$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(index, $.$$.System.Int32))));
            }
            static /*TSource */ ElementAt(TSource, /*this IQueryable<TSource>*/ source, /*Index*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                if (index.IsFromEnd && index.Value === 0)
                {
                    throw $.$slq.System.Linq.Error.ArgumentOutOfRange("index");
                }
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Index, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ElementAt).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1(index)));
            }
            static /*TSource? */ ElementAtOrDefault$1(TSource, /*this IQueryable<TSource>*/ source, /*int*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int32, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ElementAtOrDefault$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(index, $.$$.System.Int32))));
            }
            static /*TSource? */ ElementAtOrDefault(TSource, /*this IQueryable<TSource>*/ source, /*Index*/ index)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Index, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ElementAtOrDefault).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1(index)));
            }
            static /*IQueryable<TSource?> */ DefaultIfEmpty$1(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.DefaultIfEmpty$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*IQueryable<TSource> */ DefaultIfEmpty(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ defaultValue)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.DefaultIfEmpty).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(defaultValue, TSource), TSource.$type)));
            }
            static /*bool */ Contains$1(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ item)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, $.$$.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Contains$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(item, TSource), TSource.$type)));
            }
            static /*bool */ Contains(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ item, /*IEqualityComparer<TSource>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, $.$$.System.Collections.Generic.IEqualityComparer$$(TSource), $.$$.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Contains).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(item, TSource), TSource.$type), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            static /*IQueryable<TSource> */ Reverse(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Reverse).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*bool */ SequenceEqual$1(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$$.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SequenceEqual$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2)));
            }
            static /*bool */ SequenceEqual(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*IEqualityComparer<TSource>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source1, "source1");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IEnumerable$$(TSource), $.$$.System.Collections.Generic.IEqualityComparer$$(TSource), $.$$.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SequenceEqual).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            static /*IQueryable<TSource> */ Shuffle(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Shuffle).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*bool */ Any$1(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Any$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*bool */ Any(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), $.$$.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Any).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*bool */ All(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), $.$$.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.All).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*int */ Count$1(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Int32, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int32))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Count$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*int */ Count(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Int32, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), $.$$.System.Int32))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Count).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*IQueryable<KeyValuePair<TKey, int>> */ CountBy(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, $.$$.System.Int32), $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, $.$$.System.Int32))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.CountBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type)));
            }
            static /*long */ LongCount$1(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Int64, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int64))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LongCount$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*long */ LongCount(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Int64, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)), $.$$.System.Int64))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LongCount).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*TSource? */ Min$2(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Min$2).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*TSource? */ Min$1(TSource, /*this IQueryable<TSource>*/ source, /*IComparer<TSource>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IComparer$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Min$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TSource).$type)));
            }
            static /*TResult? */ Min(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TResult>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TResult)), TResult))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Min).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*TSource? */ MinBy$2(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MinBy$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            static /*TSource? */ MinBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TSource>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IComparer$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MinBy$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TSource).$type)));
            }
            static /*TSource? */ MinBy(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IComparer$$(TKey), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MinBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TKey).$type)));
            }
            static /*TSource? */ Max$2(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Max$2).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*TSource? */ Max$1(TSource, /*this IQueryable<TSource>*/ source, /*IComparer<TSource>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Collections.Generic.IComparer$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Max$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TSource).$type)));
            }
            static /*TResult? */ Max(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TResult>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TResult)), TResult))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Max).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*TSource? */ MaxBy$2(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MaxBy$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            static /*TSource? */ MaxBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TSource>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IComparer$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MaxBy$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TSource).$type)));
            }
            static /*TSource? */ MaxBy(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$$.System.Collections.Generic.IComparer$$(TKey), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MaxBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant(comparer, $.$$.System.Collections.Generic.IComparer$$(TKey).$type)));
            }
            static /*int */ Sum$2(/*this IQueryable<int>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Int32, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Int32), $.$$.System.Int32))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$2).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*int? */ Sum$6(/*this IQueryable<int?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Int32), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Int32)), $.$$.System.Nullable$$($.$$.System.Int32)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$6).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*long */ Sum$3(/*this IQueryable<long>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Int64, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Int64), $.$$.System.Int64))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$3).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*long? */ Sum$7(/*this IQueryable<long?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Int64), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Int64)), $.$$.System.Nullable$$($.$$.System.Int64)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$7).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*float */ Sum$9(/*this IQueryable<float>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Single, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Single), $.$$.System.Single))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$9).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*float? */ Sum$8(/*this IQueryable<float?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Single), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Single)), $.$$.System.Nullable$$($.$$.System.Single)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$8).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*double */ Sum$1(/*this IQueryable<double>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Double), $.$$.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*double? */ Sum$5(/*this IQueryable<double?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Double)), $.$$.System.Nullable$$($.$$.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$5).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*decimal */ Sum(/*this IQueryable<decimal>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Decimal, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Decimal), $.$$.System.Decimal))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*decimal? */ Sum$4(/*this IQueryable<decimal?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Decimal), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Decimal)), $.$$.System.Nullable$$($.$$.System.Decimal)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$4)?.Clone() ?? null.Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*int */ Sum$12(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Int32, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Int32)), $.$$.System.Int32))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$12).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*int? */ Sum$16(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int?>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Int32), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Int32))), $.$$.System.Nullable$$($.$$.System.Int32)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$16).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*long */ Sum$13(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, long>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Int64, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Int64)), $.$$.System.Int64))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$13).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*long? */ Sum$17(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, long?>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Int64), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Int64))), $.$$.System.Nullable$$($.$$.System.Int64)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$17).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*float */ Sum$19(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, float>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Single, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Single)), $.$$.System.Single))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$19).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*float? */ Sum$18(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, float?>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Single), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Single))), $.$$.System.Nullable$$($.$$.System.Single)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$18).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*double */ Sum$11(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, double>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Double)), $.$$.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$11).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*double? */ Sum$15(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, double?>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Double))), $.$$.System.Nullable$$($.$$.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$15).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*decimal */ Sum$10(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, decimal>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Decimal, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Decimal)), $.$$.System.Decimal))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$10).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*decimal? */ Sum$14(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, decimal?>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Decimal), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Decimal))), $.$$.System.Nullable$$($.$$.System.Decimal)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$14)?.Clone() ?? null.Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*double */ Average$2(/*this IQueryable<int>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Int32), $.$$.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$2).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*double? */ Average$6(/*this IQueryable<int?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Int32)), $.$$.System.Nullable$$($.$$.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$6).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*double */ Average$3(/*this IQueryable<long>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Int64), $.$$.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$3).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*double? */ Average$7(/*this IQueryable<long?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Int64)), $.$$.System.Nullable$$($.$$.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$7).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*float */ Average$9(/*this IQueryable<float>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Single, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Single), $.$$.System.Single))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$9).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*float? */ Average$8(/*this IQueryable<float?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Single), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Single)), $.$$.System.Nullable$$($.$$.System.Single)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$8).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*double */ Average$1(/*this IQueryable<double>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Double), $.$$.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*double? */ Average$5(/*this IQueryable<double?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Double)), $.$$.System.Nullable$$($.$$.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$5).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*decimal */ Average(/*this IQueryable<decimal>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Decimal, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Decimal), $.$$.System.Decimal))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*decimal? */ Average$4(/*this IQueryable<decimal?>*/ source)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Decimal), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Decimal)), $.$$.System.Nullable$$($.$$.System.Decimal)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$4)?.Clone() ?? null.Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*double */ Average$12(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Int32)), $.$$.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$12).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*double? */ Average$16(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int?>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Int32))), $.$$.System.Nullable$$($.$$.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$16).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*float */ Average$19(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, float>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Single, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Single)), $.$$.System.Single))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$19).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*float? */ Average$18(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, float?>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Single), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Single))), $.$$.System.Nullable$$($.$$.System.Single)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$18).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*double */ Average$13(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, long>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Int64)), $.$$.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$13).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*double? */ Average$17(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, long?>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Int64))), $.$$.System.Nullable$$($.$$.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$17).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*double */ Average$11(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, double>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Double)), $.$$.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$11).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*double? */ Average$15(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, double?>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Double))), $.$$.System.Nullable$$($.$$.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$15).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*decimal */ Average$10(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, decimal>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$$.System.Decimal, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Decimal)), $.$$.System.Decimal))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$10).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*decimal? */ Average$14(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, decimal?>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$$.System.Decimal), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Decimal))), $.$$.System.Nullable$$($.$$.System.Decimal)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$14)?.Clone() ?? null.Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*TSource */ Aggregate$2(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TSource, TSource>>*/ func)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(func, "func");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, TSource, TSource)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Aggregate$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(func)));
            }
            static /*TAccumulate */ Aggregate$1(TSource, TAccumulate, /*this IQueryable<TSource>*/ source, /*TAccumulate*/ seed, /*Expression<Func<TAccumulate, TSource, TAccumulate>>*/ func)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(func, "func");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TAccumulate, $.$sle.System.Linq.Expressions.Expression.Call$10(null, new ($.$$.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), TAccumulate, $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TAccumulate, TSource, TAccumulate)), TAccumulate))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Aggregate$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(seed, TAccumulate)), $.$sle.System.Linq.Expressions.Expression.Quote(func)));
            }
            static /*TResult */ Aggregate(TSource, TAccumulate, TResult, /*this IQueryable<TSource>*/ source, /*TAccumulate*/ seed, /*Expression<Func<TAccumulate, TSource, TAccumulate>>*/ func, /*Expression<Func<TAccumulate, TResult>>*/ selector)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(func, "func");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), TAccumulate, $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TAccumulate, TSource, TAccumulate)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TAccumulate, TResult)), TResult))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Aggregate).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(seed, TAccumulate)), $.$sle.System.Linq.Expressions.Expression.Quote(func), $.$sle.System.Linq.Expressions.Expression.Quote(selector) ], null, null)));
            }
            static /*IQueryable<KeyValuePair<TKey, TAccumulate>> */ AggregateBy$1(TSource, TKey, TAccumulate, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*TAccumulate*/ seed, /*Expression<Func<TAccumulate, TSource, TAccumulate>>*/ func, /*IEqualityComparer<TKey>?*/ keyComparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(func, "func");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), TAccumulate, $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TAccumulate, TSource, TAccumulate)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.AggregateBy$1).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(seed, TAccumulate)), $.$sle.System.Linq.Expressions.Expression.Quote(func), $.$sle.System.Linq.Expressions.Expression.Constant(keyComparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<KeyValuePair<TKey, TAccumulate>> */ AggregateBy(TSource, TKey, TAccumulate, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TKey, TAccumulate>>*/ seedSelector, /*Expression<Func<TAccumulate, TSource, TAccumulate>>*/ func, /*IEqualityComparer<TKey>?*/ keyComparer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(keySelector, "keySelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(seedSelector, "seedSelector");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(func, "func");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate), $.$sle.System.Linq.Expressions.Expression.Call$13(null, new ($.$$.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TKey, TAccumulate)), $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TAccumulate, TSource, TAccumulate)), $.$$.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.AggregateBy).Method, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(seedSelector), $.$sle.System.Linq.Expressions.Expression.Quote(func), $.$sle.System.Linq.Expressions.Expression.Constant(keyComparer, $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<TSource> */ SkipLast(TSource, /*this IQueryable<TSource>*/ source, /*int*/ count)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int32, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SkipLast).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(count, $.$$.System.Int32))));
            }
            static /*IQueryable<TSource> */ TakeLast(TSource, /*this IQueryable<TSource>*/ source, /*int*/ count)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$$.System.Int32, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.TakeLast).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(count, $.$$.System.Int32))));
            }
            static /*IQueryable<TSource> */ Append(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Append).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(element, TSource))));
            }
            static /*IQueryable<TSource> */ Prepend(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ element)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$$.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Prepend).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(element, TSource))));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.InMemoryQueryableExtensionMethodsRequiresUnreferencedCode = "Enumerating in-memory collections as IQueryable can require unreferenced code because expressions referencing IQueryable extension methods can get rebound to IEnumerable extension methods. The IEnumerable extension methods could be trimmed causing the application to fail at runtime.";
                }
                {
                    this.InMemoryQueryableExtensionMethodsRequiresDynamicCode = "Enumerating in-memory collections as IQueryable can require creating new generic types or methods, which requires creating code at runtime. This may not work when AOT compiling.";
                }
            }
            static $h = 501124;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":(TElement) => $.$sle.System.Linq.IQueryable$$(TElement).$h,"p":[{"n":"source","p":(TElement) => $.$$.System.Collections.Generic.IEnumerable$$(TElement).$h}],"g":["TElement"],"n":"AsQueryable","o":"@$1","d":501124,"h":12885403012,"f":16908321},{"r":42110837,"p":[{"n":"source","p":31719425}],"n":"AsQueryable","d":501124,"h":17180370308,"f":16777249},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h}],"g":["TSource"],"n":"Where","d":501124,"h":21475337604,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Boolean)).$h}],"g":["TSource"],"n":"Where","o":"@$1","d":501124,"h":25770304900,"f":16908321},{"r":(TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":42110837}],"g":["TResult"],"n":"OfType","d":501124,"h":30065272196,"f":16908321},{"r":(TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":42110837}],"g":["TResult"],"n":"Cast","d":501124,"h":34360239492,"f":16908321},{"r":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TResult)).$h}],"g":["TSource","TResult"],"n":"Select","o":"@$1","d":501124,"h":38655206788,"f":16908321},{"r":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, TResult)).$h}],"g":["TSource","TResult"],"n":"Select","d":501124,"h":42950174084,"f":16908321},{"r":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Collections.Generic.IEnumerable$$(TResult))).$h}],"g":["TSource","TResult"],"n":"SelectMany","o":"@$2","d":501124,"h":47245141380,"f":16908321},{"r":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Collections.Generic.IEnumerable$$(TResult))).$h}],"g":["TSource","TResult"],"n":"SelectMany","o":"@$3","d":501124,"h":51540108676,"f":16908321},{"r":(TSource, TCollection, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TCollection, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"collectionSelector","p":(TSource, TCollection, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Collections.Generic.IEnumerable$$(TCollection))).$h},{"n":"resultSelector","p":(TSource, TCollection, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, TCollection, TResult)).$h}],"g":["TSource","TCollection","TResult"],"n":"SelectMany","o":"@$1","d":501124,"h":55835075972,"f":16908321},{"r":(TSource, TCollection, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TCollection, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"collectionSelector","p":(TSource, TCollection, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Collections.Generic.IEnumerable$$(TCollection))).$h},{"n":"resultSelector","p":(TSource, TCollection, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, TCollection, TResult)).$h}],"g":["TSource","TCollection","TResult"],"n":"SelectMany","d":501124,"h":60130043268,"f":16908321},{"r":8687477,"p":[{"n":"source","p":(TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h}],"g":["TSource"],"n":"GetSourceExpression","d":501124,"h":64425010564,"f":16908322},{"r":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"outer","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h},{"n":"inner","p":(TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TInner).$h},{"n":"outerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)).$h},{"n":"innerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)).$h},{"n":"resultSelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)).$h}],"g":["TOuter","TInner","TKey","TResult"],"n":"Join","o":"@$1","d":501124,"h":68719977860,"f":16908321},{"r":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"outer","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h},{"n":"inner","p":(TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TInner).$h},{"n":"outerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)).$h},{"n":"innerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)).$h},{"n":"resultSelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)).$h},{"n":"comparer","p":(TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TOuter","TInner","TKey","TResult"],"n":"Join","d":501124,"h":73014945156,"f":16908321},{"r":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"outer","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h},{"n":"inner","p":(TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TInner).$h},{"n":"outerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)).$h},{"n":"innerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)).$h},{"n":"resultSelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, $.$$.System.Collections.Generic.IEnumerable$$(TInner), TResult)).$h}],"g":["TOuter","TInner","TKey","TResult"],"n":"GroupJoin","o":"@$1","d":501124,"h":77309912452,"f":16908321},{"r":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"outer","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h},{"n":"inner","p":(TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TInner).$h},{"n":"outerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)).$h},{"n":"innerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)).$h},{"n":"resultSelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, $.$$.System.Collections.Generic.IEnumerable$$(TInner), TResult)).$h},{"n":"comparer","p":(TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TOuter","TInner","TKey","TResult"],"n":"GroupJoin","d":501124,"h":81604879748,"f":16908321},{"r":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"outer","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h},{"n":"inner","p":(TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TInner).$h},{"n":"outerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)).$h},{"n":"innerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)).$h},{"n":"resultSelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)).$h}],"g":["TOuter","TInner","TKey","TResult"],"n":"LeftJoin","o":"@$1","d":501124,"h":85899847044,"f":16908321},{"r":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"outer","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h},{"n":"inner","p":(TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TInner).$h},{"n":"outerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)).$h},{"n":"innerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)).$h},{"n":"resultSelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)).$h},{"n":"comparer","p":(TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TOuter","TInner","TKey","TResult"],"n":"LeftJoin","d":501124,"h":90194814340,"f":16908321},{"r":(T) => $.$sle.System.Linq.IOrderedQueryable$$(T).$h,"p":[{"n":"source","p":(T) => $.$sle.System.Linq.IQueryable$$(T).$h}],"g":["T"],"n":"Order","o":"@$1","d":501124,"h":94489781636,"f":16908321},{"r":(T) => $.$sle.System.Linq.IOrderedQueryable$$(T).$h,"p":[{"n":"source","p":(T) => $.$sle.System.Linq.IQueryable$$(T).$h},{"n":"comparer","p":(T) => $.$$.System.Collections.Generic.IComparer$$(T).$h}],"g":["T"],"n":"Order","d":501124,"h":98784748932,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"OrderBy","o":"@$1","d":501124,"h":103079716228,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$$.System.Collections.Generic.IComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"OrderBy","d":501124,"h":107374683524,"f":16908321},{"r":(T) => $.$sle.System.Linq.IOrderedQueryable$$(T).$h,"p":[{"n":"source","p":(T) => $.$sle.System.Linq.IQueryable$$(T).$h}],"g":["T"],"n":"OrderDescending","o":"@$1","d":501124,"h":111669650820,"f":16908321},{"r":(T) => $.$sle.System.Linq.IOrderedQueryable$$(T).$h,"p":[{"n":"source","p":(T) => $.$sle.System.Linq.IQueryable$$(T).$h},{"n":"comparer","p":(T) => $.$$.System.Collections.Generic.IComparer$$(T).$h}],"g":["T"],"n":"OrderDescending","d":501124,"h":115964618116,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"OrderByDescending","o":"@$1","d":501124,"h":120259585412,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$$.System.Collections.Generic.IComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"OrderByDescending","d":501124,"h":124554552708,"f":16908321},{"r":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"outer","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h},{"n":"inner","p":(TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TInner).$h},{"n":"outerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)).$h},{"n":"innerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)).$h},{"n":"resultSelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)).$h}],"g":["TOuter","TInner","TKey","TResult"],"n":"RightJoin","o":"@$1","d":501124,"h":128849520004,"f":16908321},{"r":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"outer","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h},{"n":"inner","p":(TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TInner).$h},{"n":"outerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TOuter, TKey)).$h},{"n":"innerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TInner, TKey)).$h},{"n":"resultSelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TOuter, TInner, TResult)).$h},{"n":"comparer","p":(TOuter, TInner, TKey, TResult) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TOuter","TInner","TKey","TResult"],"n":"RightJoin","d":501124,"h":133144487300,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"ThenBy","o":"@$1","d":501124,"h":137439454596,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$$.System.Collections.Generic.IComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"ThenBy","d":501124,"h":141734421892,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"ThenByDescending","o":"@$1","d":501124,"h":146029389188,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$$.System.Collections.Generic.IComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"ThenByDescending","d":501124,"h":150324356484,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"count","p":655361}],"g":["TSource"],"n":"Take","d":501124,"h":154619323780,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"range","p":73072641}],"g":["TSource"],"n":"Take","o":"@$1","d":501124,"h":158914291076,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h}],"g":["TSource"],"n":"TakeWhile","d":501124,"h":163209258372,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Boolean)).$h}],"g":["TSource"],"n":"TakeWhile","o":"@$1","d":501124,"h":167504225668,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"count","p":655361}],"g":["TSource"],"n":"Skip","d":501124,"h":171799192964,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h}],"g":["TSource"],"n":"SkipWhile","d":501124,"h":176094160260,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, $.$$.System.Int32, $.$$.System.Boolean)).$h}],"g":["TSource"],"n":"SkipWhile","o":"@$1","d":501124,"h":180389127556,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TSource)).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"GroupBy","o":"@$7","d":501124,"h":184684094852,"f":16908321},{"r":(TSource, TKey, TElement) => $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)).$h,"p":[{"n":"source","p":(TSource, TKey, TElement) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey, TElement) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"elementSelector","p":(TSource, TKey, TElement) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TElement)).$h}],"g":["TSource","TKey","TElement"],"n":"GroupBy","o":"@$3","d":501124,"h":188979062148,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TSource)).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"GroupBy","o":"@$6","d":501124,"h":193274029444,"f":16908321},{"r":(TSource, TKey, TElement) => $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)).$h,"p":[{"n":"source","p":(TSource, TKey, TElement) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey, TElement) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"elementSelector","p":(TSource, TKey, TElement) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TElement)).$h},{"n":"comparer","p":(TSource, TKey, TElement) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TSource","TKey","TElement"],"n":"GroupBy","o":"@$2","d":501124,"h":197568996740,"f":16908321},{"r":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"elementSelector","p":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TElement)).$h},{"n":"resultSelector","p":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TKey, $.$$.System.Collections.Generic.IEnumerable$$(TElement), TResult)).$h}],"g":["TSource","TKey","TElement","TResult"],"n":"GroupBy","o":"@$1","d":501124,"h":201863964036,"f":16908321},{"r":(TSource, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"resultSelector","p":(TSource, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TKey, $.$$.System.Collections.Generic.IEnumerable$$(TSource), TResult)).$h}],"g":["TSource","TKey","TResult"],"n":"GroupBy","o":"@$5","d":501124,"h":206158931332,"f":16908321},{"r":(TSource, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"resultSelector","p":(TSource, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TKey, $.$$.System.Collections.Generic.IEnumerable$$(TSource), TResult)).$h},{"n":"comparer","p":(TSource, TKey, TResult) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TSource","TKey","TResult"],"n":"GroupBy","o":"@$4","d":501124,"h":210453898628,"f":16908321},{"r":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"elementSelector","p":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TElement)).$h},{"n":"resultSelector","p":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TKey, $.$$.System.Collections.Generic.IEnumerable$$(TElement), TResult)).$h},{"n":"comparer","p":(TSource, TKey, TElement, TResult) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TSource","TKey","TElement","TResult"],"n":"GroupBy","d":501124,"h":214748865924,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Distinct","o":"@$1","d":501124,"h":219043833220,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"comparer","p":(TSource) => $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$h}],"g":["TSource"],"n":"Distinct","d":501124,"h":223338800516,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"DistinctBy","o":"@$1","d":501124,"h":227633767812,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"DistinctBy","d":501124,"h":231928735108,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$($.$typeArray(TSource)).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"size","p":655361}],"g":["TSource"],"n":"Chunk","d":501124,"h":236223702404,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h}],"g":["TSource"],"n":"Concat","d":501124,"h":240518669700,"f":16908321},{"r":(TFirst, TSecond) => $.$sle.System.Linq.IQueryable$$($.$$.System.ValueTuple$$$(TFirst, TSecond)).$h,"p":[{"n":"source1","p":(TFirst, TSecond) => $.$sle.System.Linq.IQueryable$$(TFirst).$h},{"n":"source2","p":(TFirst, TSecond) => $.$$.System.Collections.Generic.IEnumerable$$(TSecond).$h}],"g":["TFirst","TSecond"],"n":"Zip","o":"@$2","d":501124,"h":244813636996,"f":16908321},{"r":(TFirst, TSecond, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source1","p":(TFirst, TSecond, TResult) => $.$sle.System.Linq.IQueryable$$(TFirst).$h},{"n":"source2","p":(TFirst, TSecond, TResult) => $.$$.System.Collections.Generic.IEnumerable$$(TSecond).$h},{"n":"resultSelector","p":(TFirst, TSecond, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TFirst, TSecond, TResult)).$h}],"g":["TFirst","TSecond","TResult"],"n":"Zip","d":501124,"h":249108604292,"f":16908321},{"r":(TFirst, TSecond, TThird) => $.$sle.System.Linq.IQueryable$$($.$$.System.ValueTuple$$$$(TFirst, TSecond, TThird)).$h,"p":[{"n":"source1","p":(TFirst, TSecond, TThird) => $.$sle.System.Linq.IQueryable$$(TFirst).$h},{"n":"source2","p":(TFirst, TSecond, TThird) => $.$$.System.Collections.Generic.IEnumerable$$(TSecond).$h},{"n":"source3","p":(TFirst, TSecond, TThird) => $.$$.System.Collections.Generic.IEnumerable$$(TThird).$h}],"g":["TFirst","TSecond","TThird"],"n":"Zip","o":"@$1","d":501124,"h":253403571588,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h}],"g":["TSource"],"n":"Union","o":"@$1","d":501124,"h":257698538884,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h},{"n":"comparer","p":(TSource) => $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$h}],"g":["TSource"],"n":"Union","d":501124,"h":261993506180,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource, TKey) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"UnionBy","o":"@$1","d":501124,"h":266288473476,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource, TKey) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"UnionBy","d":501124,"h":270583440772,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$($.$$.System.ValueTuple$$$($.$$.System.Int32, TSource)).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Index","d":501124,"h":274878408068,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h}],"g":["TSource"],"n":"Intersect","o":"@$1","d":501124,"h":279173375364,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h},{"n":"comparer","p":(TSource) => $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$h}],"g":["TSource"],"n":"Intersect","d":501124,"h":283468342660,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource, TKey) => $.$$.System.Collections.Generic.IEnumerable$$(TKey).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"IntersectBy","o":"@$1","d":501124,"h":287763309956,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource, TKey) => $.$$.System.Collections.Generic.IEnumerable$$(TKey).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"IntersectBy","d":501124,"h":292058277252,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h}],"g":["TSource"],"n":"Except","o":"@$1","d":501124,"h":296353244548,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h},{"n":"comparer","p":(TSource) => $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$h}],"g":["TSource"],"n":"Except","d":501124,"h":300648211844,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource, TKey) => $.$$.System.Collections.Generic.IEnumerable$$(TKey).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"ExceptBy","o":"@$1","d":501124,"h":304943179140,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource, TKey) => $.$$.System.Collections.Generic.IEnumerable$$(TKey).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"ExceptBy","d":501124,"h":309238146436,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"First","o":"@$1","d":501124,"h":313533113732,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h}],"g":["TSource"],"n":"First","d":501124,"h":317828081028,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"FirstOrDefault","o":"@$3","d":501124,"h":322123048324,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"defaultValue","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"FirstOrDefault","o":"@$2","d":501124,"h":326418015620,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h}],"g":["TSource"],"n":"FirstOrDefault","o":"@$1","d":501124,"h":330712982916,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h},{"n":"defaultValue","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"FirstOrDefault","d":501124,"h":335007950212,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Last","o":"@$1","d":501124,"h":339302917508,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h}],"g":["TSource"],"n":"Last","d":501124,"h":343597884804,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"LastOrDefault","o":"@$3","d":501124,"h":347892852100,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"defaultValue","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"LastOrDefault","o":"@$2","d":501124,"h":352187819396,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h}],"g":["TSource"],"n":"LastOrDefault","o":"@$1","d":501124,"h":356482786692,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h},{"n":"defaultValue","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"LastOrDefault","d":501124,"h":360777753988,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Single","o":"@$1","d":501124,"h":365072721284,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h}],"g":["TSource"],"n":"Single","d":501124,"h":369367688580,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"SingleOrDefault","o":"@$3","d":501124,"h":373662655876,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"defaultValue","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"SingleOrDefault","o":"@$2","d":501124,"h":377957623172,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h}],"g":["TSource"],"n":"SingleOrDefault","o":"@$1","d":501124,"h":382252590468,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h},{"n":"defaultValue","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"SingleOrDefault","d":501124,"h":386547557764,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"index","p":655361}],"g":["TSource"],"n":"ElementAt","o":"@$1","d":501124,"h":390842525060,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"index","p":57868289}],"g":["TSource"],"n":"ElementAt","d":501124,"h":395137492356,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"index","p":655361}],"g":["TSource"],"n":"ElementAtOrDefault","o":"@$1","d":501124,"h":399432459652,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"index","p":57868289}],"g":["TSource"],"n":"ElementAtOrDefault","d":501124,"h":403727426948,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"DefaultIfEmpty","o":"@$1","d":501124,"h":408022394244,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"defaultValue","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"DefaultIfEmpty","d":501124,"h":412317361540,"f":16908321},{"r":262145,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"item","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"Contains","o":"@$1","d":501124,"h":416612328836,"f":16908321},{"r":262145,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"item","p":(TSource) => TSource.$h},{"n":"comparer","p":(TSource) => $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$h}],"g":["TSource"],"n":"Contains","d":501124,"h":420907296132,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Reverse","d":501124,"h":425202263428,"f":16908321},{"r":262145,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h}],"g":["TSource"],"n":"SequenceEqual","o":"@$1","d":501124,"h":429497230724,"f":16908321},{"r":262145,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$$.System.Collections.Generic.IEnumerable$$(TSource).$h},{"n":"comparer","p":(TSource) => $.$$.System.Collections.Generic.IEqualityComparer$$(TSource).$h}],"g":["TSource"],"n":"SequenceEqual","d":501124,"h":433792198020,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Shuffle","d":501124,"h":438087165316,"f":16908321},{"r":262145,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Any","o":"@$1","d":501124,"h":442382132612,"f":16908321},{"r":262145,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h}],"g":["TSource"],"n":"Any","d":501124,"h":446677099908,"f":16908321},{"r":262145,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h}],"g":["TSource"],"n":"All","d":501124,"h":450972067204,"f":16908321},{"r":655361,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Count","o":"@$1","d":501124,"h":455267034500,"f":16908321},{"r":655361,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h}],"g":["TSource"],"n":"Count","d":501124,"h":459562001796,"f":16908321},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, $.$$.System.Int32)).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h,"f":65}],"g":["TSource","TKey"],"n":"CountBy","d":501124,"h":463856969092,"f":16908321},{"r":917505,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"LongCount","o":"@$1","d":501124,"h":468151936388,"f":16908321},{"r":917505,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Boolean)).$h}],"g":["TSource"],"n":"LongCount","d":501124,"h":472446903684,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Min","o":"@$2","d":501124,"h":476741870980,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"comparer","p":(TSource) => $.$$.System.Collections.Generic.IComparer$$(TSource).$h}],"g":["TSource"],"n":"Min","o":"@$1","d":501124,"h":481036838276,"f":16908321},{"r":(TSource, TResult) => TResult.$h,"p":[{"n":"source","p":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TResult)).$h}],"g":["TSource","TResult"],"n":"Min","d":501124,"h":485331805572,"f":16908321},{"r":(TSource, TKey) => TSource.$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"MinBy","o":"@$2","d":501124,"h":489626772868,"f":16908321},{"r":(TSource, TKey) => TSource.$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$$.System.Collections.Generic.IComparer$$(TSource).$h}],"g":["TSource","TKey"],"n":"MinBy","o":"@$1","d":501124,"h":493921740164,"f":16908321,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"The Queryable MinBy and MaxBy taking an IComparer\u003CTSource\u003E are obsolete. Use the new ones that take an IComparer\u003CTKey\u003E.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0061","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]},{"t":93847553,"c":4388814849,"a":[{"v":-1,"t":655361}]}]},{"r":(TSource, TKey) => TSource.$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$$.System.Collections.Generic.IComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"MinBy","d":501124,"h":498216707460,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Max","o":"@$2","d":501124,"h":502511674756,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"comparer","p":(TSource) => $.$$.System.Collections.Generic.IComparer$$(TSource).$h}],"g":["TSource"],"n":"Max","o":"@$1","d":501124,"h":506806642052,"f":16908321},{"r":(TSource, TResult) => TResult.$h,"p":[{"n":"source","p":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TResult)).$h}],"g":["TSource","TResult"],"n":"Max","d":501124,"h":511101609348,"f":16908321},{"r":(TSource, TKey) => TSource.$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"MaxBy","o":"@$2","d":501124,"h":515396576644,"f":16908321},{"r":(TSource, TKey) => TSource.$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$$.System.Collections.Generic.IComparer$$(TSource).$h}],"g":["TSource","TKey"],"n":"MaxBy","o":"@$1","d":501124,"h":519691543940,"f":16908321,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"The Queryable MinBy and MaxBy taking an IComparer\u003CTSource\u003E are obsolete. Use the new ones that take an IComparer\u003CTKey\u003E.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0061","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]},{"t":93847553,"c":4388814849,"a":[{"v":-1,"t":655361}]}]},{"r":(TSource, TKey) => TSource.$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$$.System.Collections.Generic.IComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"MaxBy","d":501124,"h":523986511236,"f":16908321},{"r":655361,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Int32).$h}],"n":"Sum","o":"@$2","d":501124,"h":528281478532,"f":16777249},{"r":$.$typeNullable($.$$.System.Int32).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Int32)).$h}],"n":"Sum","o":"@$6","d":501124,"h":532576445828,"f":16777249},{"r":917505,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Int64).$h}],"n":"Sum","o":"@$3","d":501124,"h":536871413124,"f":16777249},{"r":$.$typeNullable($.$$.System.Int64).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Int64)).$h}],"n":"Sum","o":"@$7","d":501124,"h":541166380420,"f":16777249},{"r":1114113,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Single).$h}],"n":"Sum","o":"@$9","d":501124,"h":545461347716,"f":16777249},{"r":$.$typeNullable($.$$.System.Single).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Single)).$h}],"n":"Sum","o":"@$8","d":501124,"h":549756315012,"f":16777249},{"r":1179649,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Double).$h}],"n":"Sum","o":"@$1","d":501124,"h":554051282308,"f":16777249},{"r":$.$typeNullable($.$$.System.Double).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Double)).$h}],"n":"Sum","o":"@$5","d":501124,"h":558346249604,"f":16777249},{"r":35127297,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Decimal).$h}],"n":"Sum","d":501124,"h":562641216900,"f":16777249},{"r":$.$typeNullable($.$$.System.Decimal).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Decimal)).$h}],"n":"Sum","o":"@$4","d":501124,"h":566936184196,"f":16777249},{"r":655361,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Int32)).$h}],"g":["TSource"],"n":"Sum","o":"@$12","d":501124,"h":571231151492,"f":16908321},{"r":$.$typeNullable($.$$.System.Int32).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Int32))).$h}],"g":["TSource"],"n":"Sum","o":"@$16","d":501124,"h":575526118788,"f":16908321},{"r":917505,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Int64)).$h}],"g":["TSource"],"n":"Sum","o":"@$13","d":501124,"h":579821086084,"f":16908321},{"r":$.$typeNullable($.$$.System.Int64).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Int64))).$h}],"g":["TSource"],"n":"Sum","o":"@$17","d":501124,"h":584116053380,"f":16908321},{"r":1114113,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Single)).$h}],"g":["TSource"],"n":"Sum","o":"@$19","d":501124,"h":588411020676,"f":16908321},{"r":$.$typeNullable($.$$.System.Single).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Single))).$h}],"g":["TSource"],"n":"Sum","o":"@$18","d":501124,"h":592705987972,"f":16908321},{"r":1179649,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Double)).$h}],"g":["TSource"],"n":"Sum","o":"@$11","d":501124,"h":597000955268,"f":16908321},{"r":$.$typeNullable($.$$.System.Double).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Double))).$h}],"g":["TSource"],"n":"Sum","o":"@$15","d":501124,"h":601295922564,"f":16908321},{"r":35127297,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Decimal)).$h}],"g":["TSource"],"n":"Sum","o":"@$10","d":501124,"h":605590889860,"f":16908321},{"r":$.$typeNullable($.$$.System.Decimal).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Decimal))).$h}],"g":["TSource"],"n":"Sum","o":"@$14","d":501124,"h":609885857156,"f":16908321},{"r":1179649,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Int32).$h}],"n":"Average","o":"@$2","d":501124,"h":614180824452,"f":16777249},{"r":$.$typeNullable($.$$.System.Double).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Int32)).$h}],"n":"Average","o":"@$6","d":501124,"h":618475791748,"f":16777249},{"r":1179649,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Int64).$h}],"n":"Average","o":"@$3","d":501124,"h":622770759044,"f":16777249},{"r":$.$typeNullable($.$$.System.Double).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Int64)).$h}],"n":"Average","o":"@$7","d":501124,"h":627065726340,"f":16777249},{"r":1114113,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Single).$h}],"n":"Average","o":"@$9","d":501124,"h":631360693636,"f":16777249},{"r":$.$typeNullable($.$$.System.Single).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Single)).$h}],"n":"Average","o":"@$8","d":501124,"h":635655660932,"f":16777249},{"r":1179649,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Double).$h}],"n":"Average","o":"@$1","d":501124,"h":639950628228,"f":16777249},{"r":$.$typeNullable($.$$.System.Double).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Double)).$h}],"n":"Average","o":"@$5","d":501124,"h":644245595524,"f":16777249},{"r":35127297,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Decimal).$h}],"n":"Average","d":501124,"h":648540562820,"f":16777249},{"r":$.$typeNullable($.$$.System.Decimal).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$$.System.Nullable$$($.$$.System.Decimal)).$h}],"n":"Average","o":"@$4","d":501124,"h":652835530116,"f":16777249},{"r":1179649,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Int32)).$h}],"g":["TSource"],"n":"Average","o":"@$12","d":501124,"h":657130497412,"f":16908321},{"r":$.$typeNullable($.$$.System.Double).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Int32))).$h}],"g":["TSource"],"n":"Average","o":"@$16","d":501124,"h":661425464708,"f":16908321},{"r":1114113,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Single)).$h}],"g":["TSource"],"n":"Average","o":"@$19","d":501124,"h":665720432004,"f":16908321},{"r":$.$typeNullable($.$$.System.Single).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Single))).$h}],"g":["TSource"],"n":"Average","o":"@$18","d":501124,"h":670015399300,"f":16908321},{"r":1179649,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Int64)).$h}],"g":["TSource"],"n":"Average","o":"@$13","d":501124,"h":674310366596,"f":16908321},{"r":$.$typeNullable($.$$.System.Double).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Int64))).$h}],"g":["TSource"],"n":"Average","o":"@$17","d":501124,"h":678605333892,"f":16908321},{"r":1179649,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Double)).$h}],"g":["TSource"],"n":"Average","o":"@$11","d":501124,"h":682900301188,"f":16908321},{"r":$.$typeNullable($.$$.System.Double).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Double))).$h}],"g":["TSource"],"n":"Average","o":"@$15","d":501124,"h":687195268484,"f":16908321},{"r":35127297,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Decimal)).$h}],"g":["TSource"],"n":"Average","o":"@$10","d":501124,"h":691490235780,"f":16908321},{"r":$.$typeNullable($.$$.System.Decimal).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, $.$$.System.Nullable$$($.$$.System.Decimal))).$h}],"g":["TSource"],"n":"Average","o":"@$14","d":501124,"h":695785203076,"f":16908321},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"func","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TSource, TSource, TSource)).$h}],"g":["TSource"],"n":"Aggregate","o":"@$2","d":501124,"h":700080170372,"f":16908321},{"r":(TSource, TAccumulate) => TAccumulate.$h,"p":[{"n":"source","p":(TSource, TAccumulate) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"seed","p":(TSource, TAccumulate) => TAccumulate.$h},{"n":"func","p":(TSource, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TAccumulate, TSource, TAccumulate)).$h}],"g":["TSource","TAccumulate"],"n":"Aggregate","o":"@$1","d":501124,"h":704375137668,"f":16908321},{"r":(TSource, TAccumulate, TResult) => TResult.$h,"p":[{"n":"source","p":(TSource, TAccumulate, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"seed","p":(TSource, TAccumulate, TResult) => TAccumulate.$h},{"n":"func","p":(TSource, TAccumulate, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TAccumulate, TSource, TAccumulate)).$h},{"n":"selector","p":(TSource, TAccumulate, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TAccumulate, TResult)).$h}],"g":["TSource","TAccumulate","TResult"],"n":"Aggregate","d":501124,"h":708670104964,"f":16908321},{"r":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.IQueryable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate)).$h,"p":[{"n":"source","p":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"seed","p":(TSource, TKey, TAccumulate) => TAccumulate.$h},{"n":"func","p":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TAccumulate, TSource, TAccumulate)).$h},{"n":"keyComparer","p":(TSource, TKey, TAccumulate) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h,"f":65}],"g":["TSource","TKey","TAccumulate"],"n":"AggregateBy","o":"@$1","d":501124,"h":712965072260,"f":16908321},{"r":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.IQueryable$$($.$$.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate)).$h,"p":[{"n":"source","p":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TSource, TKey)).$h},{"n":"seedSelector","p":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$(TKey, TAccumulate)).$h},{"n":"func","p":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$$.System.Func$$$$(TAccumulate, TSource, TAccumulate)).$h},{"n":"keyComparer","p":(TSource, TKey, TAccumulate) => $.$$.System.Collections.Generic.IEqualityComparer$$(TKey).$h,"f":65}],"g":["TSource","TKey","TAccumulate"],"n":"AggregateBy","d":501124,"h":717260039556,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"count","p":655361}],"g":["TSource"],"n":"SkipLast","d":501124,"h":721555006852,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"count","p":655361}],"g":["TSource"],"n":"TakeLast","d":501124,"h":725849974148,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"element","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"Append","d":501124,"h":730144941444,"f":16908321},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"element","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"Prepend","d":501124,"h":734439908740,"f":16908321}],"l":[{"t":1310721,"n":"InMemoryQueryableExtensionMethodsRequiresUnreferencedCode","d":501124,"h":4295468420,"f":4194344},{"t":1310721,"n":"InMemoryQueryableExtensionMethodsRequiresDynamicCode","d":501124,"h":8590435716,"f":4194344}],"h":501124}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Linq.Queryable`; }
        });
        
        $asm.$cls("$slq.System.Linq.EnumerableExecutor<>", (T) => $asm.$gt("$slq.System.Linq.EnumerableExecutor<>", [T], ($self) => class EnumerableExecutor$$ extends $.$slq.System.Linq.EnumerableExecutor
        {
            /*Expression*/ _expression = null;
            $ctor$2(/*Expression*/ expression)
            {
                super.$ctor$1();
                {
                    this._expression = expression;
                }
                return this;
            }
            /*object? */ ExecuteBoxed()
            {
                return $.$box(this.Execute(), T);
            }
            /*T */ Execute()
            {
                /*EnumerableRewriter*/ let rewriter = new $.$slq.System.Linq.EnumerableRewriter().$ctor$2();
                /*Expression*/ let body = rewriter.Visit$1(this._expression);
                /*Expression<Func<T>>*/ let f = $.$sle.System.Linq.Expressions.Expression.Lambda$14($.$$.System.Func$$(T), body, null);
                /*Func<T>*/ let func = f.Compile$3();
                return func.Invoke();
            }
            static $h = 173444;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":107908,"m":[{"r":131073,"n":"ExecuteBoxed","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16809992},{"r":T?.$h??1507328,"n":"Execute","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777224}],"l":[{"t":8687477,"n":"_expression","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"expression","p":8687477}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$slq.System.Linq.EnumerableExecutor; }
            static get $fullName() { return `System.Linq.EnumerableExecutor<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$slq.System.Linq.EnumerableRewriter", ($self) => class EnumerableRewriter extends $.$sle.System.Linq.Expressions.ExpressionVisitor
        {
            /*Dictionary<LabelTarget, LabelTarget>?*/ _targetCache = null;
            /*Dictionary<Type, Type>?*/ _equivalentTypeCache = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*Expression */ VisitMethodCall(/*MethodCallExpression*/ m)
            {
                /*Expression?*/ let obj = this.Visit$1(m.Object);
                /*ReadOnlyCollection<Expression>*/ let args = this.Visit(m.Arguments);
                if (obj !== m.Object || args !== m.Arguments)
                {
                    /*MethodInfo*/ let mInfo = m.Method;
                    /*Type[]?*/ let typeArgs = (mInfo.IsGenericMethod) ? mInfo.GetGenericArguments() : null;
                    if ((mInfo.IsStatic$1 || mInfo.DeclaringType.IsAssignableFrom(obj.Type)) && $.$slq.System.Linq.EnumerableRewriter.ArgsMatch(mInfo, args, typeArgs))
                    {
                        return $.$sle.System.Linq.Expressions.Expression.Call$9(obj, mInfo, args);
                    }
                    else if ($.$$.System.Type.op_Equality$1(mInfo.DeclaringType, $.$slq.System.Linq.Queryable.$type))
                    {
                        /*MethodInfo*/ let seqMethod = $.$slq.System.Linq.EnumerableRewriter.FindEnumerableMethodForQueryable(mInfo.Name, args, typeArgs);
                        args = $.$slq.System.Linq.EnumerableRewriter.FixupQuotedArgs(seqMethod, args);
                        return $.$sle.System.Linq.Expressions.Expression.Call$9(obj, seqMethod, args);
                    }
                    else 
                    {
                        /*MethodInfo*/ let method = $.$slq.System.Linq.EnumerableRewriter.FindMethod(mInfo.DeclaringType, mInfo.Name, args, typeArgs);
                        args = $.$slq.System.Linq.EnumerableRewriter.FixupQuotedArgs(method, args);
                        return $.$sle.System.Linq.Expressions.Expression.Call$9(obj, method, args);
                    }
                }
                return m;
            }
            static /*ReadOnlyCollection<Expression> */ FixupQuotedArgs(/*MethodInfo*/ mi, /*ReadOnlyCollection<Expression>*/ argList)
            {
                /*ParameterInfo[]*/ let pis = mi.GetParameters();
                if (pis.length > 0)
                {
                    /*List<Expression>?*/ let newArgs = null;
                    for(/*int*/ let i = 0, n = pis.length; i < n; i++)
                    {
                        /*Expression*/ let arg = argList.get_Item(i);
                        /*ParameterInfo*/ let pi = $.$$.System.Array.$ReadT1.call(pis, i);
                        arg = $.$slq.System.Linq.EnumerableRewriter.FixupQuotedExpression(pi.ParameterType, arg);
                        if (newArgs === null && arg !== argList.get_Item(i))
                        {
                            newArgs = new ($.$$.System.Collections.Generic.List$$($.$sle.System.Linq.Expressions.Expression))().$ctor$3(argList.Count);
                            for(/*int*/ let j = 0; j < i; j++)
                            {
                                newArgs.Add(argList.get_Item(j));
                            }
                        }
                        newArgs?.Add(arg);
                    }
                    if (newArgs !== null)
                    {
                        argList = newArgs.AsReadOnly();
                    }
                }
                return argList;
            }
            static /*Expression */ FixupQuotedExpression(/*Type*/ type, /*Expression*/ expression)
            {
                /*Expression*/ let expr = expression;
                while(true)
                {
                    if (type.IsAssignableFrom(expr.Type))
                    {
                        return expr;
                    }
                    if (expr.NodeType !== 40/*ExpressionType.Quote*/)
                    {
                        break;
                    }
                    expr = ($.$cast(expr, $.$sle.System.Linq.Expressions.UnaryExpression)).Operand;
                }
                if (!type.IsAssignableFrom(expr.Type) && type.IsArray && expr.NodeType === 32/*ExpressionType.NewArrayInit*/)
                {
                    /*Type*/ let strippedType = $.$slq.System.Linq.EnumerableRewriter.StripExpression(expr.Type);
                    if (type.IsAssignableFrom(strippedType))
                    {
                        /*Type*/ let elementType = type.GetElementType();
                        /*NewArrayExpression*/ let na = $.$cast(expr, $.$sle.System.Linq.Expressions.NewArrayExpression);
                        /*List<Expression>*/ let exprs = new ($.$$.System.Collections.Generic.List$$($.$sle.System.Linq.Expressions.Expression))().$ctor$3(na.Expressions.Count);
                        for(/*int*/ let i = 0, n = na.Expressions.Count; i < n; i++)
                        {
                            exprs.Add($.$slq.System.Linq.EnumerableRewriter.FixupQuotedExpression(elementType, na.Expressions.get_Item(i)));
                        }
                        expression = $.$sle.System.Linq.Expressions.Expression.NewArrayInit(elementType, exprs);
                    }
                }
                return expression;
            }
            /*Expression */ VisitLambda(T, /*Expression<T>*/ node)
            {
                return node;
            }
            static /*Type */ GetPublicType(/*Type*/ t)
            {
                if (t.IsGenericType && $.$sl.System.Linq.Enumerable.Contains$1($.$$.System.Type, t.GetGenericTypeDefinition().GetInterfaces(), $.$sl.System.Linq.IGrouping$$$().$type))
                {
                    return $.$sl.System.Linq.IGrouping$$$().$type.MakeGenericType(t.GetGenericArguments());
                }
                if (!t.IsNestedPrivate)
                {
                    return t;
                }
                let $i1 = 0;
                let $arr1 = t.GetInterfaces();
                while ($i1 < $arr1.length)
                {
                    let iType = $arr1[$i1++];
                    if (iType.IsGenericType && $.$$.System.Type.op_Equality$1(iType.GetGenericTypeDefinition(), $.$$.System.Collections.Generic.IEnumerable$$().$type))
                    {
                        return iType;
                    }
                }
                if ($.$$.System.Collections.IEnumerable.$type.IsAssignableFrom(t))
                {
                    return $.$$.System.Collections.IEnumerable.$type;
                }
                return t;
            }
            /*Type */ GetEquivalentType(/*Type*/ type)
            {
                /*Type?*/ let equiv;
                this._equivalentTypeCache ??= (() =>
                {
                    //new $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Type, $.$$.System.Type)()
                    const $t1 = $.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Type, $.$$.System.Type);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Add($.$sle.System.Linq.IQueryable.$type, $.$$.System.Collections.IEnumerable.$type);
                    $i1.Add($.$$.System.Collections.IEnumerable.$type, $.$$.System.Collections.IEnumerable.$type);
                    return $i1;
                })();
                if (!this._equivalentTypeCache.TryGetValue(type, $.$ref(() => equiv, ($v) => equiv = $v, $.$$.System.Type)))
                {
                    /*Type*/ let pubType = $.$slq.System.Linq.EnumerableRewriter.GetPublicType(type);
                    if (pubType.IsInterface && pubType.IsGenericType)
                    {
                        /*Type*/ let genericType = pubType.GetGenericTypeDefinition();
                        if ($.$$.System.Type.op_Equality$1(genericType, $.$sl.System.Linq.IOrderedEnumerable$$().$type))
                        {
                            equiv = pubType;
                        }
                        else if ($.$$.System.Type.op_Equality$1(genericType, $.$sle.System.Linq.IOrderedQueryable$$().$type))
                        {
                            equiv = $.$sl.System.Linq.IOrderedEnumerable$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ $.$$.System.Array.$ReadT1.call(pubType.GenericTypeArguments, 0) ], null, null));
                        }
                        else if ($.$$.System.Type.op_Equality$1(genericType, $.$$.System.Collections.Generic.IEnumerable$$().$type))
                        {
                            equiv = pubType;
                        }
                        else if ($.$$.System.Type.op_Equality$1(genericType, $.$sle.System.Linq.IQueryable$$().$type))
                        {
                            equiv = $.$$.System.Collections.Generic.IEnumerable$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ $.$$.System.Array.$ReadT1.call(pubType.GenericTypeArguments, 0) ], null, null));
                        }
                    }
                    if ($.$$.System.Type.op_Equality$1(equiv, null))
                    {
                        /*var*/ let interfacesWithInfo = pubType.GetInterfaces();
                        /*var*/ let singleTypeGenInterfacesWithGetType = $.$sl.System.Linq.Enumerable.ToArray($.$$.System.Object, $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Type, $.$$.System.Object, $.$sl.System.Linq.Enumerable.Where($.$$.System.Type, interfacesWithInfo, new ($.$$.System.Func$$$($.$$.System.Type, $.$$.System.Boolean))().$ctor(this,  (/*i*/ i) =>
                        {
                            return i.IsGenericType && i.GenericTypeArguments.length === 1;
                        }, {"r":262145,"p":[{"n":"i","p":142475265}],"n":"","d":370052,"h":0,"f":17825794})), new ($.$$.System.Func$$$($.$$.System.Type, $.$$.System.Object))().$ctor(this,  (/*i*/ i) =>
                        {
                            return { Info : i, GenType : i.GetGenericTypeDefinition() };
                        }, {"r":0,"p":[{"n":"i","p":142475265}],"n":"","d":370052,"h":0,"f":17825794})));
                        /*Type?*/ let typeArg = $.$sl.System.Linq.Enumerable.SingleOrDefault$3($.$$.System.Type, $.$sl.System.Linq.Enumerable.Distinct$1($.$$.System.Type, $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Object, $.$$.System.Type, $.$sl.System.Linq.Enumerable.Where($.$$.System.Object, singleTypeGenInterfacesWithGetType, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Boolean))().$ctor(this,  (/*i*/ i) =>
                        {
                            return $.$$.System.Type.op_Equality$1(i.GenType, $.$sle.System.Linq.IOrderedQueryable$$().$type) || $.$$.System.Type.op_Equality$1(i.GenType, $.$sl.System.Linq.IOrderedEnumerable$$().$type);
                        }, {"r":262145,"p":[{"n":"i","p":0}],"n":"","d":370052,"h":0,"f":17825794})), new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Type))().$ctor(this,  (/*i*/ i) =>
                        {
                            return $.$$.System.Array.$ReadT1.call(i.Info.GenericTypeArguments, 0);
                        }, {"r":142475265,"p":[{"n":"i","p":0}],"n":"","d":370052,"h":0,"f":17825794}))));
                        if ($.$$.System.Type.op_Inequality$1(typeArg, null))
                        {
                            equiv = $.$sl.System.Linq.IOrderedEnumerable$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ typeArg ], null, null));
                        }
                        else 
                        {
                            typeArg = $.$sl.System.Linq.Enumerable.Single$1($.$$.System.Type, $.$sl.System.Linq.Enumerable.Distinct$1($.$$.System.Type, $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Object, $.$$.System.Type, $.$sl.System.Linq.Enumerable.Where($.$$.System.Object, singleTypeGenInterfacesWithGetType, new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Boolean))().$ctor(this,  (/**/ i) =>
                            {
                                return $.$$.System.Type.op_Equality$1(i.GenType, $.$sle.System.Linq.IQueryable$$().$type) || $.$$.System.Type.op_Equality$1(i.GenType, $.$$.System.Collections.Generic.IEnumerable$$().$type);
                            }, {"r":262145,"p":[{"n":"i","p":0}],"n":"","d":370052,"h":0,"f":17825794})), new ($.$$.System.Func$$$($.$$.System.Object, $.$$.System.Type))().$ctor(this,  (/*i*/ i) =>
                            {
                                return $.$$.System.Array.$ReadT1.call(i.Info.GenericTypeArguments, 0);
                            }, {"r":142475265,"p":[{"n":"i","p":0}],"n":"","d":370052,"h":0,"f":17825794}))));
                            equiv = $.$$.System.Collections.Generic.IEnumerable$$().$type.MakeGenericType($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Type), [ typeArg ], null, null));
                        }
                    }
                    this._equivalentTypeCache.Add(type, equiv);
                }
                return equiv;
            }
            /*Expression */ VisitConstant(/*ConstantExpression*/ c)
            {
                let sq;
                if ($.$is(c.Value, $.$slq.System.Linq.EnumerableQuery, { set $v(v){ sq = v; } }))
                {
                    if (sq.Enumerable !== null)
                    {
                        /*Type*/ let t = $.$slq.System.Linq.EnumerableRewriter.GetPublicType($.$$.System.Object.GetType.call(sq.Enumerable));
                        return $.$sle.System.Linq.Expressions.Expression.Constant(sq.Enumerable, t);
                    }
                    /*Expression*/ let exp = sq.Expression;
                    if (exp !== c)
                    {
                        return this.Visit$1(exp);
                    }
                }
                return c;
            }
            /*ILookup<string, MethodInfo>?*/ static s_seqMethods = null;
            static /*MethodInfo */ FindEnumerableMethodForQueryable(/*string*/ name, /*ReadOnlyCollection<Expression>*/ args, /*params Type[]?*/ typeArgs)
            {
                $.$slq.System.Linq.EnumerableRewriter.s_seqMethods ??= $.$sl.System.Linq.Enumerable.ToLookup$3($.$$.System.Reflection.MethodInfo, $.$$.System.String, GetEnumerableStaticMethods($.$sl.System.Linq.Enumerable.$type), new ($.$$.System.Func$$$($.$$.System.Reflection.MethodInfo, $.$$.System.String))().$ctor(this,  (/*m*/ m) =>
                {
                    return m.Name;
                }, {"r":1310721,"p":[{"n":"m","p":79626241}],"n":"","d":370052,"h":0,"f":17825794}));
                /*MethodInfo[]*/ let matchingMethods = $.$sl.System.Linq.Enumerable.ToArray($.$$.System.Reflection.MethodInfo, $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Reflection.MethodInfo, $.$$.System.Reflection.MethodInfo, $.$sl.System.Linq.Enumerable.Where($.$$.System.Reflection.MethodInfo, $.$slq.System.Linq.EnumerableRewriter.s_seqMethods.System$Linq$ILookup$$$$get_Item(name, [$.$$.System.String, $.$$.System.Reflection.MethodInfo]), new ($.$$.System.Func$$$($.$$.System.Reflection.MethodInfo, $.$$.System.Boolean))().$ctor(this,  (/**/ m) =>
                {
                    return $.$slq.System.Linq.EnumerableRewriter.ArgsMatch(m, args, typeArgs);
                }, {"r":262145,"p":[{"n":"m","p":79626241}],"n":"","d":370052,"h":0,"f":17825794})), new ($.$$.System.Func$$$($.$$.System.Reflection.MethodInfo, $.$$.System.Reflection.MethodInfo))().$ctor(this, ApplyTypeArgs)));
                $.$$.System.Diagnostics.Debug.Assert$2(matchingMethods.length > 0, "All static methods with arguments on Queryable have equivalents on Enumerable.");
                if (matchingMethods.length > 1)
                {
                    return DisambiguateMatches(matchingMethods);
                }
                return $.$$.System.Array.$ReadT1.call(matchingMethods, 0);
                /*static MethodInfo[]*/  function GetEnumerableStaticMethods(/*Type*/ type)
                {
                    return type.GetMethods$1(16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/);
                }
                /*MethodInfo*/  function ApplyTypeArgs(/*MethodInfo*/ methodInfo)
                {
                    return typeArgs === null ? methodInfo : methodInfo.MakeGenericMethod(typeArgs);
                }
                /*static MethodInfo*/  function DisambiguateMatches(/*MethodInfo[]*/ matchingMethods)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(matchingMethods.length > 1, "matchingMethods.Length > 1");
                    /*ParameterInfo[][]*/ let parameters = $.$sl.System.Linq.Enumerable.ToArray($.$typeArray($.$$.System.Reflection.ParameterInfo), $.$sl.System.Linq.Enumerable.Select$1($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Reflection.ParameterInfo), matchingMethods, new ($.$$.System.Func$$$($.$$.System.Reflection.MethodInfo, $.$typeArray($.$$.System.Reflection.ParameterInfo)))().$ctor(this,  (/**/ m) =>
                    {
                        return m.GetParameters();
                    }, {"r":$.$typeArray($.$$.System.Reflection.ParameterInfo).$h,"p":[{"n":"m","p":79626241}],"n":"","d":370052,"h":0,"f":17825794})));
                    for(/*int*/ let i = 0; i < matchingMethods.length; i++)
                    {
                        /*bool*/ let isMaximal = true;
                        for(/*int*/ let j = 0; j < matchingMethods.length; j++)
                        {
                            if (i !== j && AreAssignableFromStrict($.$$.System.Array.$ReadT1.call(parameters, i), $.$$.System.Array.$ReadT1.call(parameters, j)))
                            {
                                isMaximal = false;
                                break;
                            }
                        }
                        if (isMaximal)
                        {
                            return $.$$.System.Array.$ReadT1.call(matchingMethods, i);
                        }
                    }
                    $.$$.System.Diagnostics.Debug.Fail$1("Search should have found a maximal element");
                    throw new $.$$.System.Exception().$ctor$1();
                    /*static bool*/  function AreAssignableFromStrict(/*ParameterInfo[]*/ left, /*ParameterInfo[]*/ right)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(left.length === right.length, "left.Length == right.Length");
                        /*bool*/ let areEqual = true;
                        /*bool*/ let areAssignableFrom = true;
                        for(/*int*/ let i = 0; i < left.length; i++)
                        {
                            /*Type*/ let leftParam = $.$$.System.Array.$ReadT1.call(left, i).ParameterType;
                            /*Type*/ let rightParam = $.$$.System.Array.$ReadT1.call(right, i).ParameterType;
                            areEqual = areEqual && $.$$.System.Type.op_Equality$1(leftParam, rightParam);
                            areAssignableFrom = areAssignableFrom && leftParam.IsAssignableFrom(rightParam);
                        }
                        return !areEqual && areAssignableFrom;
                    }
                }
            }
            static /*MethodInfo */ FindMethod(/*Type*/ type, /*string*/ name, /*ReadOnlyCollection<Expression>*/ args, /*Type[]?*/ typeArgs)
            {
                let en = null;
                try
                {
                    en = $.$sl.System.Linq.Enumerable.Where($.$$.System.Reflection.MethodInfo, type.GetMethods$1(16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 8/*BindingFlags.Static*/), new ($.$$.System.Func$$$($.$$.System.Reflection.MethodInfo, $.$$.System.Boolean))().$ctor(this,  (/*m*/ m) =>
                    {
                        return $.$$.System.String.op_Equality(m.Name, name);
                    }, {"r":262145,"p":[{"n":"m","p":79626241}],"n":"","d":370052,"h":0,"f":17825794})).System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$$.System.Reflection.MethodInfo]);
                    if (!en.System$Collections$IEnumerator$MoveNext())
                    {
                        throw $.$slq.System.Linq.Error.NoMethodOnType(name, type);
                    }
                    do
                    {
                        /*MethodInfo*/ let mi = en.System$Collections$Generic$IEnumerator$$$Current;
                        if ($.$slq.System.Linq.EnumerableRewriter.ArgsMatch(mi, args, typeArgs))
                        {
                            return (typeArgs !== null) ? mi.MakeGenericMethod(typeArgs) : mi;
                        }
                    }
                    while(en.System$Collections$IEnumerator$MoveNext());
                }
                finally
                {
                    en?.System$IDisposable$Dispose();
                }
                throw $.$slq.System.Linq.Error.NoMethodOnTypeMatchingArguments(name, type);
            }
            static /*bool */ ArgsMatch(/*MethodInfo*/ m, /*ReadOnlyCollection<Expression>*/ args, /*Type[]?*/ typeArgs)
            {
                /*ParameterInfo[]*/ let mParams = m.GetParameters();
                if (mParams.length !== args.Count)
                {
                    return false;
                }
                if (!m.IsGenericMethod && typeArgs !== null && typeArgs.length > 0)
                {
                    return false;
                }
                if (!m.IsGenericMethodDefinition && m.IsGenericMethod && m.ContainsGenericParameters$1)
                {
                    m = m.GetGenericMethodDefinition();
                }
                if (m.IsGenericMethodDefinition)
                {
                    if (typeArgs === null || typeArgs.length === 0)
                    {
                        return false;
                    }
                    if (m.GetGenericArguments().length !== typeArgs.length)
                    {
                        return false;
                    }
                    mParams = GetConstrutedGenericParameters(m, typeArgs);
                    /*static ParameterInfo[]*/  function GetConstrutedGenericParameters(/*MethodInfo*/ method, /*Type[]*/ genericTypes)
                    {
                        return method.MakeGenericMethod(genericTypes).GetParameters();
                    }
                }
                for(/*int*/ let i = 0, n = args.Count; i < n; i++)
                {
                    /*Type*/ let parameterType = $.$$.System.Array.$ReadT1.call(mParams, i).ParameterType;
                    if ($.$$.System.Type.op_Equality$1(parameterType, null))
                    {
                        return false;
                    }
                    if (parameterType.IsByRef)
                    {
                        parameterType = parameterType.GetElementType();
                    }
                    /*Expression*/ let arg = args.get_Item(i);
                    if (!parameterType.IsAssignableFrom(arg.Type))
                    {
                        if (arg.NodeType === 40/*ExpressionType.Quote*/)
                        {
                            arg = ($.$cast(arg, $.$sle.System.Linq.Expressions.UnaryExpression)).Operand;
                        }
                        if (!parameterType.IsAssignableFrom(arg.Type) && !parameterType.IsAssignableFrom($.$slq.System.Linq.EnumerableRewriter.StripExpression(arg.Type)))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            static /*Type */ StripExpression(/*Type*/ type)
            {
                /*bool*/ let isArray = type.IsArray;
                /*Type*/ let tmp = isArray ? type.GetElementType() : type;
                /*Type?*/ let eType = $.$slq.System.Linq.TypeHelper.FindGenericType($.$sle.System.Linq.Expressions.Expression$$().$type, tmp);
                if ($.$$.System.Type.op_Inequality$1(eType, null))
                {
                    tmp = $.$$.System.Array.$ReadT1.call(eType.GetGenericArguments(), 0);
                }
                if (isArray)
                {
                    /*int*/ let rank = type.GetArrayRank();
                    return (rank === 1) ? tmp.MakeArrayType() : tmp.MakeArrayType$1(rank);
                }
                return type;
            }
            /*Expression */ VisitConditional(/*ConditionalExpression*/ c)
            {
                /*Type*/ let type = c.Type;
                if (!$.$sle.System.Linq.IQueryable.$type.IsAssignableFrom(type))
                {
                    return super.VisitConditional(c);
                }
                /*Expression*/ let test = this.Visit$1(c.Test);
                /*Expression*/ let ifTrue = this.Visit$1(c.IfTrue);
                /*Expression*/ let ifFalse = this.Visit$1(c.IfFalse);
                /*Type*/ let trueType = ifTrue.Type;
                /*Type*/ let falseType = ifFalse.Type;
                if (trueType.IsAssignableFrom(falseType))
                {
                    return $.$sle.System.Linq.Expressions.Expression.Condition(test, ifTrue, ifFalse, trueType);
                }
                if (falseType.IsAssignableFrom(trueType))
                {
                    return $.$sle.System.Linq.Expressions.Expression.Condition(test, ifTrue, ifFalse, falseType);
                }
                return $.$sle.System.Linq.Expressions.Expression.Condition(test, ifTrue, ifFalse, this.GetEquivalentType(type));
            }
            /*Expression */ VisitBlock(/*BlockExpression*/ node)
            {
                /*Type*/ let type = node.Type;
                if (!$.$sle.System.Linq.IQueryable.$type.IsAssignableFrom(type))
                {
                    return super.VisitBlock(node);
                }
                /*ReadOnlyCollection<Expression>*/ let nodes = this.Visit(node.Expressions);
                /*ReadOnlyCollection<ParameterExpression>*/ let variables = this.VisitAndConvert($.$sle.System.Linq.Expressions.ParameterExpression, node.Variables, "EnumerableRewriter.VisitBlock");
                if ($.$$.System.Type.op_Equality$1(type, $.$sl.System.Linq.Enumerable.Last$1($.$sle.System.Linq.Expressions.Expression, node.Expressions).Type))
                {
                    return $.$sle.System.Linq.Expressions.Expression.Block$1(variables, nodes);
                }
                return $.$sle.System.Linq.Expressions.Expression.Block$4(this.GetEquivalentType(type), variables, nodes);
            }
            /*Expression */ VisitGoto(/*GotoExpression*/ node)
            {
                /*Type*/ let type = node.Value.Type;
                if (!$.$sle.System.Linq.IQueryable.$type.IsAssignableFrom(type))
                {
                    return super.VisitGoto(node);
                }
                /*LabelTarget*/ let target = this.VisitLabelTarget(node.Target);
                /*Expression*/ let value = this.Visit$1(node.Value);
                return $.$sle.System.Linq.Expressions.Expression.MakeGoto(node.Kind, target, value, this.GetEquivalentType($.$slq.System.Linq.EnumerableQuery.$type.IsAssignableFrom(type) ? value.Type : type));
            }
            /*LabelTarget */ VisitLabelTarget(/*LabelTarget?*/ node)
            {
                /*LabelTarget?*/ let newTarget;
                if (this._targetCache === null)
                {
                    this._targetCache = new ($.$$.System.Collections.Generic.Dictionary$$$($.$sle.System.Linq.Expressions.LabelTarget, $.$sle.System.Linq.Expressions.LabelTarget))().$ctor$1();
                }
                else if (this._targetCache.TryGetValue(node, $.$ref(() => newTarget, ($v) => newTarget = $v, $.$sle.System.Linq.Expressions.LabelTarget)))
                {
                    return newTarget;
                }
                /*Type*/ let type = node.Type;
                if (!$.$sle.System.Linq.IQueryable.$type.IsAssignableFrom(type))
                {
                    newTarget = super.VisitLabelTarget(node);
                }
                else 
                {
                    newTarget = $.$sle.System.Linq.Expressions.Expression.Label$2(this.GetEquivalentType(type), node.Name);
                }
                this._targetCache.Add(node, newTarget);
                return newTarget;
            }
            static $h = 370052;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":11243381,"m":[{"r":8687477,"p":[{"n":"m","p":39292789}],"n":"VisitMethodCall","d":370052,"h":17180239236,"f":16809988},{"r":$.$$.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sle.System.Linq.Expressions.Expression).$h,"p":[{"n":"mi","p":79626241},{"n":"argList","p":$.$$.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sle.System.Linq.Expressions.Expression).$h}],"n":"FixupQuotedArgs","d":370052,"h":21475206532,"f":16777250},{"r":8687477,"p":[{"n":"type","p":142475265},{"n":"expression","p":8687477}],"n":"FixupQuotedExpression","d":370052,"h":25770173828,"f":16777250},{"r":8687477,"p":[{"n":"node","p":(T) => $.$sle.System.Linq.Expressions.Expression$$(T).$h}],"g":["T"],"n":"VisitLambda","d":370052,"h":30065141124,"f":16941060},{"r":142475265,"p":[{"n":"t","p":142475265}],"n":"GetPublicType","d":370052,"h":34360108420,"f":16777250},{"r":142475265,"p":[{"n":"type","p":142475265}],"n":"GetEquivalentType","d":370052,"h":38655075716,"f":16777218},{"r":8687477,"p":[{"n":"c","p":7769973}],"n":"VisitConstant","d":370052,"h":42950043012,"f":16809988},{"r":79626241,"p":[{"n":"name","p":1310721},{"n":"args","p":$.$$.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sle.System.Linq.Expressions.Expression).$h},{"n":"typeArgs","p":$.$typeArray($.$$.System.Type).$h,"f":16}],"n":"FindEnumerableMethodForQueryable","d":370052,"h":51539977604,"f":16777250},{"r":79626241,"p":[{"n":"type","p":142475265},{"n":"name","p":1310721},{"n":"args","p":$.$$.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sle.System.Linq.Expressions.Expression).$h},{"n":"typeArgs","p":$.$typeArray($.$$.System.Type).$h}],"n":"FindMethod","d":370052,"h":55834944900,"f":16777250},{"r":262145,"p":[{"n":"m","p":79626241},{"n":"args","p":$.$$.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sle.System.Linq.Expressions.Expression).$h},{"n":"typeArgs","p":$.$typeArray($.$$.System.Type).$h}],"n":"ArgsMatch","d":370052,"h":60129912196,"f":16777250},{"r":142475265,"p":[{"n":"type","p":142475265}],"n":"StripExpression","d":370052,"h":64424879492,"f":16777250},{"r":8687477,"p":[{"n":"c","p":7638901}],"n":"VisitConditional","d":370052,"h":68719846788,"f":16809988},{"r":8687477,"p":[{"n":"node","p":3903349}],"n":"VisitBlock","d":370052,"h":73014814084,"f":16809988},{"r":8687477,"p":[{"n":"node","p":11571061}],"n":"VisitGoto","d":370052,"h":77309781380,"f":16809988},{"r":38440821,"p":[{"n":"node","p":38440821}],"n":"VisitLabelTarget","d":370052,"h":81604748676,"f":16809988}],"l":[{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$sle.System.Linq.Expressions.LabelTarget, $.$sle.System.Linq.Expressions.LabelTarget).$h,"n":"_targetCache","d":370052,"h":4295337348,"f":4194306},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$$.System.Type, $.$$.System.Type).$h,"n":"_equivalentTypeCache","d":370052,"h":8590304644,"f":4194306},{"t":$.$sl.System.Linq.ILookup$$$($.$$.System.String, $.$$.System.Reflection.MethodInfo).$h,"n":"s_seqMethods","d":370052,"h":47245010308,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$2","d":370052,"h":12885271940,"f":16777217}],"h":370052}; }
            static get $b() { return $.$sle.System.Linq.Expressions.ExpressionVisitor; }
            static get $fullName() { return `System.Linq.EnumerableRewriter`; }
        });
        
        $asm.$cls("$slq.System.Linq.EnumerableQuery<>", (T) => $asm.$gt("$slq.System.Linq.EnumerableQuery<>", [T], ($self) => class EnumerableQuery$$ extends $.$slq.System.Linq.EnumerableQuery
        {
            /*Expression*/ _expression = null;
            /*IEnumerable<T>?*/ _enumerable = null;
            /*IQueryProvider */ get System$Linq$IQueryable$Provider()
            {
                return this;
            }
            $ctor$2(/*IEnumerable<T>*/ enumerable)
            {
                super.$ctor$1();
                {
                    this._enumerable = enumerable;
                    this._expression = $.$sle.System.Linq.Expressions.Expression.Constant$1(this);
                }
                return this;
            }
            $ctor$3(/*Expression*/ expression)
            {
                super.$ctor$1();
                {
                    this._expression = expression;
                }
                return this;
            }
            /*Expression */ get Expression()
            {
                return this._expression;
            }
            /*IEnumerable? */ get Enumerable()
            {
                return this._enumerable;
            }
            /*Expression */ get System$Linq$IQueryable$Expression()
            {
                return this._expression;
            }
            /*Type */ get System$Linq$IQueryable$ElementType()
            {
                return T.$type;
            }
            /*IQueryable */ System$Linq$IQueryProvider$CreateQuery(/*Expression*/ expression)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(expression, "expression");
                /*Type?*/ let iqType = $.$slq.System.Linq.TypeHelper.FindGenericType($.$sle.System.Linq.IQueryable$$().$type, expression.Type);
                if ($.$$.System.Type.op_Equality$1(iqType, null))
                {
                    throw $.$slq.System.Linq.Error.ArgumentNotValid("expression");
                }
                return $.$slq.System.Linq.EnumerableQuery.Create$1($.$$.System.Array.$ReadT1.call(iqType.GetGenericArguments(), 0), expression);
            }
            /*IQueryable<TElement> */ System$Linq$IQueryProvider$CreateQuery$1(TElement, /*Expression*/ expression)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(expression, "expression");
                if (!$.$sle.System.Linq.IQueryable$$(TElement).$type.IsAssignableFrom(expression.Type))
                {
                    throw $.$slq.System.Linq.Error.ArgumentNotValid("expression");
                }
                return new ($.$slq.System.Linq.EnumerableQuery$$(TElement))().$ctor$3(expression);
            }
            /*object? */ System$Linq$IQueryProvider$Execute(/*Expression*/ expression)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(expression, "expression");
                return $.$slq.System.Linq.EnumerableExecutor.Create(expression).ExecuteBoxed();
            }
            /*TElement */ System$Linq$IQueryProvider$Execute$1(TElement, /*Expression*/ expression)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(expression, "expression");
                if (!TElement.$type.IsAssignableFrom(expression.Type))
                {
                    throw $.$slq.System.Linq.Error.ArgumentNotValid("expression");
                }
                return new ($.$slq.System.Linq.EnumerableExecutor$$(TElement))().$ctor$2(expression).Execute();
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            /*IEnumerator<T> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            /*IEnumerator<T> */ GetEnumerator()
            {
                if (this._enumerable === null)
                {
                    /*EnumerableRewriter*/ let rewriter = new $.$slq.System.Linq.EnumerableRewriter().$ctor$2();
                    /*Expression*/ let body = rewriter.Visit$1(this._expression);
                    /*Expression<Func<IEnumerable<T>>>*/ let f = $.$sle.System.Linq.Expressions.Expression.Lambda$14($.$$.System.Func$$($.$$.System.Collections.Generic.IEnumerable$$(T)), body, null);
                    /*IEnumerable<T>*/ let enumerable = f.Compile$3().Invoke();
                    if (enumerable === this)
                    {
                        throw $.$slq.System.Linq.Error.EnumeratingNullEnumerableExpression();
                    }
                    this._enumerable = enumerable;
                }
                return this._enumerable.System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            static/*conventional*/ /*string? */ ToString()
            {
                let c;
                if ($.$is(this._expression, $.$sle.System.Linq.Expressions.ConstantExpression, { set $v(v){ c = v; } }) && c.Value === this)
                {
                    if (this._enumerable !== null)
                    {
                        return $.$$.System.Object.ToString.call(this._enumerable);
                    }
                    return "null";
                }
                return $.$sle.System.Linq.Expressions.Expression.ToString.call(this._expression);
            }
            //Static convention instance redirect
            /*string? */ ToString() { return $.$slq.System.Linq.EnumerableQuery$$(T).ToString.apply(this, arguments); }
            static $h = 304516;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":238980,"p":[{"p":42241909,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331650},"n":"{42110837}.Provider","o":"System$Linq$IQueryable$Provider","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097154},{"p":8687477,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":50364424},"n":"Expression","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2129928},{"p":31719425,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50364424},"n":"Enumerable","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2129928},{"p":8687477,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":50331650},"n":"{42110837}.Expression","o":"System$Linq$IQueryable$Expression","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2097154},{"p":142475265,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":50331650},"n":"{42110837}.ElementType","o":"System$Linq$IQueryable$ElementType","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2097154}],"m":[{"r":$.$$.System.Collections.Generic.IEnumerator$$(T).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16777218},{"r":1310721,"n":"ToString","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":16809985}],"l":[{"t":8687477,"n":"_expression","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$$.System.Collections.Generic.IEnumerable$$(T).$h,"n":"_enumerable","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306}],"c":[{"p":[{"n":"enumerable","p":$.$$.System.Collections.Generic.IEnumerable$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217},{"p":[{"n":"expression","p":8687477}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777217}],"i":[$.$sle.System.Linq.IOrderedQueryable$$(T).$h,$.$sle.System.Linq.IQueryable$$(T).$h,$.$$.System.Collections.Generic.IEnumerable$$(T).$h,41979765,42110837,31719425,42241909],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$slq.System.Linq.EnumerableQuery; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sle.System.Linq.IOrderedQueryable$$(T), $.$sle.System.Linq.IQueryable$$(T), $.$$.System.Collections.Generic.IEnumerable$$(T), $.$sle.System.Linq.IOrderedQueryable, $.$sle.System.Linq.IQueryable, $.$$.System.Collections.IEnumerable, $.$sle.System.Linq.IQueryProvider ]; }
            static get $fullName() { return `System.Linq.EnumerableQuery<${T?.$fullName}>`; }
        }));
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.ObjectModel", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions"))