
(function ($global, $, $spc, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $sic, $stt, $sim, $so, $stee, $srm, $sre, $srei, $srel, $srp, $sle) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Linq.Queryable", 
    {"h":44276,"f":"System.Linq.Queryable","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Linq.Queryable","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Linq.Queryable","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$slq.System.Linq.EnumerableQuery", ($self) => class EnumerableQuery extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*IQueryable */ Create(/*Type*/ elementType, /*IEnumerable*/ sequence)
            {
                /*Type*/ let seqType = $.$slq.System.Linq.EnumerableQuery$$().$type.MakeGenericType($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ elementType ], null, null));
                return $.$cast($.$spc.System.Activator.CreateInstance$1(seqType, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ sequence ], null, null)), $.$sle.System.Linq.IQueryable);
            }
            static /*IQueryable */ Create$1(/*Type*/ elementType, /*Expression*/ expression)
            {
                /*Type*/ let seqType = $.$slq.System.Linq.EnumerableQuery$$().$type.MakeGenericType($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ elementType ], null, null));
                return $.$cast($.$spc.System.Activator.CreateInstance$1(seqType, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ expression ], null, null)), $.$sle.System.Linq.IQueryable);
            }
            static $h = 240884;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":8687052,"g":{"r":0,"d":0,"h":8590175476,"f":264},"n":"Expression","d":240884,"h":4295208180,"f":264},{"p":31653889,"g":{"r":0,"d":0,"h":17180110068,"f":264},"n":"Enumerable","d":240884,"h":12885142772,"f":264}],"m":[{"r":42110412,"p":[{"n":"elementType","p":142606337},{"n":"sequence","p":31653889}],"n":"Create","d":240884,"h":25770044660,"f":40},{"r":42110412,"p":[{"n":"elementType","p":142606337},{"n":"expression","p":8687052}],"n":"Create","o":"@$1","d":240884,"h":30065011956,"f":40}],"c":[{"n":".ctor","o":"$ctor$1","d":240884,"h":21475077364,"f":8}],"h":240884}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Linq.EnumerableQuery`; }
        });
        
        $asm.$cls("$slq.System.Linq.EnumerableExecutor", ($self) => class EnumerableExecutor extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*EnumerableExecutor */ Create(/*Expression*/ expression)
            {
                /*Type*/ let execType = $.$slq.System.Linq.EnumerableExecutor$$().$type.MakeGenericType($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ expression.Type ], null, null));
                return $.$cast($.$spc.System.Activator.CreateInstance$1(execType, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Object), [ expression ], null, null)), $.$slq.System.Linq.EnumerableExecutor);
            }
            static $h = 109812;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":131073,"n":"ExecuteBoxed","d":109812,"h":4295077108,"f":264},{"r":109812,"p":[{"n":"expression","p":8687052}],"n":"Create","d":109812,"h":12885011700,"f":40}],"c":[{"n":".ctor","o":"$ctor$1","d":109812,"h":8590044404,"f":8}],"h":109812}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Linq.EnumerableExecutor`; }
        });
        
        $asm.$cls("$slq.System.Linq.Error", ($self) => class Error
        {
            static /*Exception */ ArgumentNotIEnumerableGeneric(/*string*/ message)
            {
                return new $.$spc.System.ArgumentException().$ctor$10($.$slq.System.Linq.Strings.ArgumentNotIEnumerableGeneric(message));
            }
            static /*Exception */ ArgumentNotValid(/*string*/ message)
            {
                return new $.$spc.System.ArgumentException().$ctor$10($.$slq.System.Linq.Strings.ArgumentNotValid(message));
            }
            static /*Exception */ ArgumentOutOfRange(/*string*/ message)
            {
                return new $.$spc.System.ArgumentOutOfRangeException().$ctor$16(message);
            }
            static /*Exception */ NoMethodOnType(/*string*/ name, /*object*/ type)
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$slq.System.Linq.Strings.NoMethodOnType(name, type));
            }
            static /*Exception */ NoMethodOnTypeMatchingArguments(/*string*/ name, /*object*/ type)
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$slq.System.Linq.Strings.NoMethodOnTypeMatchingArguments(name, type));
            }
            static /*Exception */ EnumeratingNullEnumerableExpression()
            {
                return new $.$spc.System.InvalidOperationException().$ctor$10($.$slq.System.Linq.Strings.EnumeratingNullEnumerableExpression());
            }
            static $h = 437492;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":47251457,"p":[{"n":"message","p":1310721}],"n":"ArgumentNotIEnumerableGeneric","d":437492,"h":4295404788,"f":40},{"r":47251457,"p":[{"n":"message","p":1310721}],"n":"ArgumentNotValid","d":437492,"h":8590372084,"f":40},{"r":47251457,"p":[{"n":"message","p":1310721}],"n":"ArgumentOutOfRange","d":437492,"h":12885339380,"f":40},{"r":47251457,"p":[{"n":"name","p":1310721},{"n":"type","p":131073}],"n":"NoMethodOnType","d":437492,"h":17180306676,"f":40},{"r":47251457,"p":[{"n":"name","p":1310721},{"n":"type","p":131073}],"n":"NoMethodOnTypeMatchingArguments","d":437492,"h":21475273972,"f":40},{"r":47251457,"n":"EnumeratingNullEnumerableExpression","d":437492,"h":25770241268,"f":40}],"h":437492}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Linq.Error`; }
        });
        
        $asm.$cls("$slq.System.SR", ($self) => class SR
        {
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$slq.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$slq.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$slq.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$slq.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$slq.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$slq.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$slq.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Linq.Queryable", $.$slq.System.SR.$type.Assembly);
                    $.$slq.System.SR.s_resourceManager = temp;
                }
                return $.$slq.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$slq.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$slq.System.SR.resourceCulture = value;
            }
            static /*string */ get ArgumentNotIEnumerableGeneric()
            {
                return "{0} is not IEnumerable<>";
            }
            static /*string */ FormatArgumentNotIEnumerableGeneric(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("{0} is not IEnumerable<>", arg1);
            }
            static /*string */ get ArgumentNotValid()
            {
                return "Argument {0} is not valid";
            }
            static /*string */ FormatArgumentNotValid(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Argument {0} is not valid", arg1);
            }
            static /*string */ get NoMethodOnType()
            {
                return "There is no method '{0}' on type '{1}'";
            }
            static /*string */ FormatNoMethodOnType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("There is no method '{0}' on type '{1}'", arg1, arg2);
            }
            static /*string */ get NoMethodOnTypeMatchingArguments()
            {
                return "There is no method '{0}' on type '{1}' that matches the specified arguments";
            }
            static /*string */ FormatNoMethodOnTypeMatchingArguments(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("There is no method '{0}' on type '{1}' that matches the specified arguments", arg1, arg2);
            }
            static /*string */ get EnumeratingNullEnumerableExpression()
            {
                return "Cannot enumerate a query created from a null IEnumerable<>";
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$slq.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 765172;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":765172}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$slq.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 699636;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":699636,"h":4295666932,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":699636,"h":8590634228,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":699636,"h":12885601524,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":699636,"h":17180568820,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":699636,"h":21475536116,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":699636,"h":25770503412,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":699636,"h":30065470708,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":699636,"h":34360438004,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":699636,"h":38655405300,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":699636,"h":42950372596,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":699636,"h":47245339892,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":699636,"h":51540307188,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":699636,"h":55835274484,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":699636,"h":60130241780,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":699636,"h":64425209076,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":699636,"h":68720176372,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":699636,"h":73015143668,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":699636,"h":77310110964,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":699636,"h":81605078260,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":699636,"h":85900045556,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":699636,"h":90195012852,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":699636,"h":94489980148,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":699636,"h":98784947444,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":699636,"h":103079914740,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":699636,"h":107374882036,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":699636,"h":111669849332,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":699636,"h":115964816628,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":699636,"h":120259783924,"f":40},{"t":1310721,"n":"WebRequestMessage","d":699636,"h":124554751220,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":699636,"h":128849718516,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":699636,"h":133144685812,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":699636,"h":137439653108,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":699636,"h":141734620404,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":699636,"h":146029587700,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":699636,"h":150324554996,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":699636,"h":154619522292,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":699636,"h":158914489588,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":699636,"h":163209456884,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":699636,"h":167504424180,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":699636,"h":171799391476,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":699636,"h":176094358772,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":699636,"h":180389326068,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":699636,"h":184684293364,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":699636,"h":188979260660,"f":40},{"t":1310721,"n":"RijndaelMessage","d":699636,"h":193274227956,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":699636,"h":197569195252,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":699636,"h":201864162548,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":699636,"h":206159129844,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":699636,"h":210454097140,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":699636,"h":214749064436,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":699636,"h":219044031732,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":699636,"h":223338999028,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":699636,"h":227633966324,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":699636,"h":231928933620,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":699636,"h":236223900916,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":699636,"h":240518868212,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":699636,"h":244813835508,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":699636,"h":249108802804,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":699636,"h":253403770100,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":699636,"h":257698737396,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":699636,"h":261993704692,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":699636,"h":266288671988,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":699636,"h":270583639284,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":699636,"h":274878606580,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":699636,"h":279173573876,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":699636,"h":283468541172,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":699636,"h":287763508468,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":699636,"h":292058475764,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":699636,"h":296353443060,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":699636,"h":300648410356,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":699636,"h":304943377652,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":699636,"h":309238344948,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":699636,"h":313533312244,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":699636,"h":317828279540,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":699636,"h":322123246836,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":699636,"h":326418214132,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":699636,"h":330713181428,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":699636,"h":335008148724,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":699636,"h":339303116020,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":699636,"h":343598083316,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":699636,"h":347893050612,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":699636,"h":352188017908,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":699636,"h":356482985204,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":699636,"h":360777952500,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":699636,"h":365072919796,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":699636,"h":369367887092,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":699636,"h":373662854388,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":699636,"h":377957821684,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":699636,"h":382252788980,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":699636,"h":386547756276,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":699636,"h":390842723572,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":699636,"h":395137690868,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":699636,"h":399432658164,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":699636,"h":403727625460,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":699636,"h":408022592756,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":699636,"h":412317560052,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":699636,"h":416612527348,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":699636,"h":420907494644,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":699636,"h":425202461940,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":699636,"h":429497429236,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":699636,"h":433792396532,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":699636,"h":438087363828,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":699636,"h":442382331124,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":699636,"h":446677298420,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":699636,"h":450972265716,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":699636,"h":455267233012,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":699636,"h":459562200308,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":699636,"h":463857167604,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":699636,"h":468152134900,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":699636,"h":472447102196,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":699636,"h":476742069492,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":699636,"h":481037036788,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":699636,"h":485332004084,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":699636,"h":489626971380,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":699636,"h":493921938676,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":699636,"h":498216905972,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":699636,"h":502511873268,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":699636,"h":506806840564,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":699636,"h":511101807860,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":699636,"h":515396775156,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":699636,"h":519691742452,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":699636,"h":523986709748,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":699636,"h":528281677044,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":699636,"h":532576644340,"f":40}],"h":699636}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$slq.System.Linq.TypeHelper", ($self) => class TypeHelper
        {
            static /*Type? */ FindGenericType(/*Type*/ definition, /*Type*/ type)
            {
                /*bool?*/ let definitionIsInterface = null;
                while($.$spc.System.Type.op_Inequality$1(type, null) && $.$spc.System.Type.op_Inequality$1(type, $.$spc.System.Object.$type))
                {
                    if (type.IsGenericType && $.$spc.System.Type.op_Equality$1(type.GetGenericTypeDefinition(), definition))
                    {
                        return type;
                    }
                    if (!$.$spc.System.Nullable$$($.$spc.System.Boolean).HasValue$get.call(definitionIsInterface))
                    {
                        definitionIsInterface = definition.IsInterface;
                    }
                    if ($.$spc.System.Nullable$$($.$spc.System.Boolean).GetValueOrDefault.call(definitionIsInterface))
                    {
                        let $i1 = 0;
                        let $arr1 = type.GetInterfaces();
                        while ($i1 < $arr1.length)
                        {
                            let itype = $arr1[$i1++];
                            /*Type?*/ let found = $.$slq.System.Linq.TypeHelper.FindGenericType(definition, itype);
                            if ($.$spc.System.Type.op_Inequality$1(found, null))
                            {
                                return found;
                            }
                        }
                    }
                    type = type.BaseType;
                }
                return null;
            }
            static $h = 634100;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":142606337,"p":[{"n":"definition","p":142606337},{"n":"type","p":142606337}],"n":"FindGenericType","d":634100,"h":4295601396,"f":40}],"h":634100}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Linq.TypeHelper`; }
        });
        
        $asm.$cls("$slq.System.Linq.Strings", ($self) => class Strings
        {
            static /*string */ ArgumentNotIEnumerableGeneric(/*string*/ message)
            {
                return $.$slq.System.SR.Format($.$slq.System.SR.ArgumentNotIEnumerableGeneric, message);
            }
            static /*string */ ArgumentNotValid(/*string*/ message)
            {
                return $.$slq.System.SR.Format($.$slq.System.SR.ArgumentNotValid, message);
            }
            static /*string */ NoMethodOnType(/*string*/ name, /*object*/ type)
            {
                return $.$slq.System.SR.Format$1($.$slq.System.SR.NoMethodOnType, name, type);
            }
            static /*string */ NoMethodOnTypeMatchingArguments(/*string*/ name, /*object*/ type)
            {
                return $.$slq.System.SR.Format$1($.$slq.System.SR.NoMethodOnTypeMatchingArguments, name, type);
            }
            static /*string */ EnumeratingNullEnumerableExpression()
            {
                return $.$slq.System.SR.EnumeratingNullEnumerableExpression;
            }
            static $h = 568564;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"p":[{"n":"message","p":1310721}],"n":"ArgumentNotIEnumerableGeneric","d":568564,"h":4295535860,"f":40},{"r":1310721,"p":[{"n":"message","p":1310721}],"n":"ArgumentNotValid","d":568564,"h":8590503156,"f":40},{"r":1310721,"p":[{"n":"name","p":1310721},{"n":"type","p":131073}],"n":"NoMethodOnType","d":568564,"h":12885470452,"f":40},{"r":1310721,"p":[{"n":"name","p":1310721},{"n":"type","p":131073}],"n":"NoMethodOnTypeMatchingArguments","d":568564,"h":17180437748,"f":40},{"r":1310721,"n":"EnumeratingNullEnumerableExpression","d":568564,"h":21475405044,"f":40}],"h":568564}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Linq.Strings`; }
        });
        
        $asm.$cls("$slq.System.Linq.Queryable", ($self) => class Queryable
        {
            /*string*/ static InMemoryQueryableExtensionMethodsRequiresUnreferencedCode = null;
            /*string*/ static InMemoryQueryableExtensionMethodsRequiresDynamicCode = null;
            static /*IQueryable<TElement> */ AsQueryable(TElement, /*this IEnumerable<TElement>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$as(source, $.$sle.System.Linq.IQueryable$$(TElement)) ?? new ($.$slq.System.Linq.EnumerableQuery$$(TElement))().$ctor$2(source);
            }
            static /*IQueryable */ AsQueryable$1(/*this IEnumerable*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                let queryable;
                if ($.$is(source, $.$sle.System.Linq.IQueryable, { set $v(v){ queryable = v; } }))
                {
                    return queryable;
                }
                /*Type?*/ let enumType = $.$slq.System.Linq.TypeHelper.FindGenericType($.$spc.System.Collections.Generic.IEnumerable$$().$type, $.$spc.System.Object.GetType.call(source));
                if ($.$spc.System.Type.op_Equality$1(enumType, null))
                {
                    throw $.$slq.System.Linq.Error.ArgumentNotIEnumerableGeneric("source");
                }
                return $.$slq.System.Linq.EnumerableQuery.Create($.$spc.System.Array.$ReadT1.call(enumType.GenericTypeArguments, 0), source);
            }
            static /*IQueryable<TSource> */ Where(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Where).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*IQueryable<TSource> */ Where$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, bool>>*/ predicate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, $.$spc.System.Int32, $.$spc.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Where$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*IQueryable<TResult> */ OfType(TResult, /*this IQueryable*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$9(null, $.$slq.System.Linq.Queryable.OfType.Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*IQueryable<TResult> */ Cast(TResult, /*this IQueryable*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$9(null, $.$slq.System.Linq.Queryable.Cast.Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*IQueryable<TResult> */ Select(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TResult>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Select).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*IQueryable<TResult> */ Select$1(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, TResult>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, $.$spc.System.Int32, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Select$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*IQueryable<TResult> */ SelectMany(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, IEnumerable<TResult>>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Collections.Generic.IEnumerable$$(TResult))), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SelectMany).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*IQueryable<TResult> */ SelectMany$1(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, IEnumerable<TResult>>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, $.$spc.System.Int32, $.$spc.System.Collections.Generic.IEnumerable$$(TResult))), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SelectMany$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*IQueryable<TResult> */ SelectMany$2(TSource, TCollection, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, IEnumerable<TCollection>>>*/ collectionSelector, /*Expression<Func<TSource, TCollection, TResult>>*/ resultSelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(collectionSelector, "collectionSelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, $.$spc.System.Int32, $.$spc.System.Collections.Generic.IEnumerable$$(TCollection))), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, TCollection, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SelectMany$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(collectionSelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector)));
            }
            static /*IQueryable<TResult> */ SelectMany$3(TSource, TCollection, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, IEnumerable<TCollection>>>*/ collectionSelector, /*Expression<Func<TSource, TCollection, TResult>>*/ resultSelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(collectionSelector, "collectionSelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Collections.Generic.IEnumerable$$(TCollection))), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, TCollection, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SelectMany$3).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(collectionSelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector)));
            }
            static /*Expression */ GetSourceExpression(TSource, /*IEnumerable<TSource>*/ source)
            {
                /*IQueryable<TSource>?*/ let q = $.$as(source, $.$sle.System.Linq.IQueryable$$(TSource));
                return q !== null ? q.System$Linq$IQueryable$Expression : $.$sle.System.Linq.Expressions.Expression.Constant$1(source, $.$spc.System.Collections.Generic.IEnumerable$$(TSource).$type);
            }
            static /*IQueryable<TResult> */ Join(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, TInner, TResult>>*/ resultSelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(outer, "outer");
                $.$spc.System.ArgumentNullException.ThrowIfNull(inner, "inner");
                $.$spc.System.ArgumentNullException.ThrowIfNull(outerKeySelector, "outerKeySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(innerKeySelector, "innerKeySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$spc.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TOuter, TInner, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Join).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector) ], null, null)));
            }
            static /*IQueryable<TResult> */ Join$1(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, TInner, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(outer, "outer");
                $.$spc.System.ArgumentNullException.ThrowIfNull(inner, "inner");
                $.$spc.System.ArgumentNullException.ThrowIfNull(outerKeySelector, "outerKeySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(innerKeySelector, "innerKeySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$spc.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TOuter, TInner, TResult)), $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Join$1).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<TResult> */ GroupJoin(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, IEnumerable<TInner>, TResult>>*/ resultSelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(outer, "outer");
                $.$spc.System.ArgumentNullException.ThrowIfNull(inner, "inner");
                $.$spc.System.ArgumentNullException.ThrowIfNull(outerKeySelector, "outerKeySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(innerKeySelector, "innerKeySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$spc.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TOuter, $.$spc.System.Collections.Generic.IEnumerable$$(TInner), TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupJoin).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector) ], null, null)));
            }
            static /*IQueryable<TResult> */ GroupJoin$1(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, IEnumerable<TInner>, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(outer, "outer");
                $.$spc.System.ArgumentNullException.ThrowIfNull(inner, "inner");
                $.$spc.System.ArgumentNullException.ThrowIfNull(outerKeySelector, "outerKeySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(innerKeySelector, "innerKeySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$spc.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TOuter, $.$spc.System.Collections.Generic.IEnumerable$$(TInner), TResult)), $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupJoin$1).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<TResult> */ LeftJoin(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, TInner?, TResult>>*/ resultSelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(outer, "outer");
                $.$spc.System.ArgumentNullException.ThrowIfNull(inner, "inner");
                $.$spc.System.ArgumentNullException.ThrowIfNull(outerKeySelector, "outerKeySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(innerKeySelector, "innerKeySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$spc.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TOuter, TInner, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LeftJoin).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector) ], null, null)));
            }
            static /*IQueryable<TResult> */ LeftJoin$1(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter, TInner?, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(outer, "outer");
                $.$spc.System.ArgumentNullException.ThrowIfNull(inner, "inner");
                $.$spc.System.ArgumentNullException.ThrowIfNull(outerKeySelector, "outerKeySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(innerKeySelector, "innerKeySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$spc.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TOuter, TInner, TResult)), $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LeftJoin$1).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IOrderedQueryable<T> */ Order(T, /*this IQueryable<T>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(T, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(T), $.$sle.System.Linq.IOrderedQueryable$$(T)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Order).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null))), $.$sle.System.Linq.IOrderedQueryable$$(T));
            }
            static /*IOrderedQueryable<T> */ Order$1(T, /*this IQueryable<T>*/ source, /*IComparer<T>*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(T, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(T), $.$spc.System.Collections.Generic.IComparer$$(T), $.$sle.System.Linq.IOrderedQueryable$$(T)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Order$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IComparer$$(T).$type))), $.$sle.System.Linq.IOrderedQueryable$$(T));
            }
            static /*IOrderedQueryable<TSource> */ OrderBy(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            static /*IOrderedQueryable<TSource> */ OrderBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$spc.System.Collections.Generic.IComparer$$(TKey), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderBy$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IComparer$$(TKey).$type))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            static /*IOrderedQueryable<T> */ OrderDescending(T, /*this IQueryable<T>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(T, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(T), $.$sle.System.Linq.IOrderedQueryable$$(T)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderDescending).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null))), $.$sle.System.Linq.IOrderedQueryable$$(T));
            }
            static /*IOrderedQueryable<T> */ OrderDescending$1(T, /*this IQueryable<T>*/ source, /*IComparer<T>*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(T, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(T), $.$spc.System.Collections.Generic.IComparer$$(T), $.$sle.System.Linq.IOrderedQueryable$$(T)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderDescending$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IComparer$$(T).$type))), $.$sle.System.Linq.IOrderedQueryable$$(T));
            }
            static /*IOrderedQueryable<TSource> */ OrderByDescending(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderByDescending).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            static /*IOrderedQueryable<TSource> */ OrderByDescending$1(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$spc.System.Collections.Generic.IComparer$$(TKey), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.OrderByDescending$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IComparer$$(TKey).$type))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            static /*IQueryable<TResult> */ RightJoin(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter?, TInner, TResult>>*/ resultSelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(outer, "outer");
                $.$spc.System.ArgumentNullException.ThrowIfNull(inner, "inner");
                $.$spc.System.ArgumentNullException.ThrowIfNull(outerKeySelector, "outerKeySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(innerKeySelector, "innerKeySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$spc.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TOuter, TInner, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.RightJoin).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector) ], null, null)));
            }
            static /*IQueryable<TResult> */ RightJoin$1(TOuter, TInner, TKey, TResult, /*this IQueryable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Expression<Func<TOuter, TKey>>*/ outerKeySelector, /*Expression<Func<TInner, TKey>>*/ innerKeySelector, /*Expression<Func<TOuter?, TInner, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(outer, "outer");
                $.$spc.System.ArgumentNullException.ThrowIfNull(inner, "inner");
                $.$spc.System.ArgumentNullException.ThrowIfNull(outerKeySelector, "outerKeySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(innerKeySelector, "innerKeySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(resultSelector, "resultSelector");
                return outer.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$$$($.$sle.System.Linq.IQueryable$$(TOuter), $.$spc.System.Collections.Generic.IEnumerable$$(TInner), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TOuter, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TInner, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TOuter, TInner, TResult)), $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.RightJoin$1).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ outer.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TInner, inner), $.$sle.System.Linq.Expressions.Expression.Quote(outerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(innerKeySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IOrderedQueryable<TSource> */ ThenBy(TSource, TKey, /*this IOrderedQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IOrderedQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ThenBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            static /*IOrderedQueryable<TSource> */ ThenBy$1(TSource, TKey, /*this IOrderedQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IOrderedQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$spc.System.Collections.Generic.IComparer$$(TKey), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ThenBy$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IComparer$$(TKey).$type))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            static /*IOrderedQueryable<TSource> */ ThenByDescending(TSource, TKey, /*this IOrderedQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IOrderedQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ThenByDescending).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            static /*IOrderedQueryable<TSource> */ ThenByDescending$1(TSource, TKey, /*this IOrderedQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return $.$cast(source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IOrderedQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$spc.System.Collections.Generic.IComparer$$(TKey), $.$sle.System.Linq.IOrderedQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ThenByDescending$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IComparer$$(TKey).$type))), $.$sle.System.Linq.IOrderedQueryable$$(TSource));
            }
            static /*IQueryable<TSource> */ Take(TSource, /*this IQueryable<TSource>*/ source, /*int*/ count)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Int32, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Take).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(count, $.$spc.System.Int32))));
            }
            static /*IQueryable<TSource> */ Take$1(TSource, /*this IQueryable<TSource>*/ source, /*Range*/ range)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Range, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Take$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant(range)));
            }
            static /*IQueryable<TSource> */ TakeWhile(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.TakeWhile).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*IQueryable<TSource> */ TakeWhile$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, bool>>*/ predicate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, $.$spc.System.Int32, $.$spc.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.TakeWhile$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*IQueryable<TSource> */ Skip(TSource, /*this IQueryable<TSource>*/ source, /*int*/ count)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Int32, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Skip).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(count, $.$spc.System.Int32))));
            }
            static /*IQueryable<TSource> */ SkipWhile(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SkipWhile).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*IQueryable<TSource> */ SkipWhile$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int, bool>>*/ predicate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, $.$spc.System.Int32, $.$spc.System.Boolean)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SkipWhile$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*IQueryable<IGrouping<TKey, TSource>> */ GroupBy(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$sl.System.Linq.IGrouping$$$(TKey, TSource), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TSource))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            static /*IQueryable<IGrouping<TKey, TElement>> */ GroupBy$1(TSource, TKey, TElement, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TSource, TElement>>*/ elementSelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(elementSelector, "elementSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$sl.System.Linq.IGrouping$$$(TKey, TElement), $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TElement)), $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(elementSelector)));
            }
            static /*IQueryable<IGrouping<TKey, TSource>> */ GroupBy$2(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$sl.System.Linq.IGrouping$$$(TKey, TSource), $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TSource))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$type)));
            }
            static /*IQueryable<IGrouping<TKey, TElement>> */ GroupBy$3(TSource, TKey, TElement, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TSource, TElement>>*/ elementSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(elementSelector, "elementSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$sl.System.Linq.IGrouping$$$(TKey, TElement), $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TElement)), $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$3).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(elementSelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<TResult> */ GroupBy$4(TSource, TKey, TElement, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TSource, TElement>>*/ elementSelector, /*Expression<Func<TKey, IEnumerable<TElement>, TResult>>*/ resultSelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(elementSelector, "elementSelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TElement)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TKey, $.$spc.System.Collections.Generic.IEnumerable$$(TElement), TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$4).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(elementSelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector) ], null, null)));
            }
            static /*IQueryable<TResult> */ GroupBy$5(TSource, TKey, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TKey, IEnumerable<TSource>, TResult>>*/ resultSelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TKey, $.$spc.System.Collections.Generic.IEnumerable$$(TSource), TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$5).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector)));
            }
            static /*IQueryable<TResult> */ GroupBy$6(TSource, TKey, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TKey, IEnumerable<TSource>, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TKey, $.$spc.System.Collections.Generic.IEnumerable$$(TSource), TResult)), $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$6).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<TResult> */ GroupBy$7(TSource, TKey, TElement, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TSource, TElement>>*/ elementSelector, /*Expression<Func<TKey, IEnumerable<TElement>, TResult>>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(elementSelector, "elementSelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(resultSelector, "resultSelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TElement)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TKey, $.$spc.System.Collections.Generic.IEnumerable$$(TElement), TResult)), $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.GroupBy$7).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(elementSelector), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<TSource> */ Distinct(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Distinct).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*IQueryable<TSource> */ Distinct$1(TSource, /*this IQueryable<TSource>*/ source, /*IEqualityComparer<TSource>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Distinct$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            static /*IQueryable<TSource> */ DistinctBy(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.DistinctBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            static /*IQueryable<TSource> */ DistinctBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.DistinctBy$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$type)));
            }
            static /*IQueryable<TSource[]> */ Chunk(TSource, /*this IQueryable<TSource>*/ source, /*int*/ size)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$typeArray(TSource), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Int32, $.$sle.System.Linq.IQueryable$$($.$typeArray(TSource))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Chunk).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(size, $.$spc.System.Int32))));
            }
            static /*IQueryable<TSource> */ Concat(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Concat).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2)));
            }
            static /*IQueryable<(TFirst First, TSecond Second)> */ Zip(TFirst, TSecond, /*this IQueryable<TFirst>*/ source1, /*IEnumerable<TSecond>*/ source2)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$spc.System.ValueTuple$$$(TFirst, TSecond), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TFirst), $.$spc.System.Collections.Generic.IEnumerable$$(TSecond), $.$sle.System.Linq.IQueryable$$($.$spc.System.ValueTuple$$$(TFirst, TSecond))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Zip).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSecond, source2)));
            }
            static /*IQueryable<TResult> */ Zip$1(TFirst, TSecond, TResult, /*this IQueryable<TFirst>*/ source1, /*IEnumerable<TSecond>*/ source2, /*Expression<Func<TFirst, TSecond, TResult>>*/ resultSelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                $.$spc.System.ArgumentNullException.ThrowIfNull(resultSelector, "resultSelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TFirst), $.$spc.System.Collections.Generic.IEnumerable$$(TSecond), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TFirst, TSecond, TResult)), $.$sle.System.Linq.IQueryable$$(TResult)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Zip$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSecond, source2), $.$sle.System.Linq.Expressions.Expression.Quote(resultSelector)));
            }
            static /*IQueryable<(TFirst First, TSecond Second, TThird Third)> */ Zip$2(TFirst, TSecond, TThird, /*this IQueryable<TFirst>*/ source1, /*IEnumerable<TSecond>*/ source2, /*IEnumerable<TThird>*/ source3)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source3, "source3");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$spc.System.ValueTuple$$$$(TFirst, TSecond, TThird), $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TFirst), $.$spc.System.Collections.Generic.IEnumerable$$(TSecond), $.$spc.System.Collections.Generic.IEnumerable$$(TThird), $.$sle.System.Linq.IQueryable$$($.$spc.System.ValueTuple$$$$(TFirst, TSecond, TThird))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Zip$2).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSecond, source2), $.$slq.System.Linq.Queryable.GetSourceExpression(TThird, source3)));
            }
            static /*IQueryable<TSource> */ Union(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Union).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2)));
            }
            static /*IQueryable<TSource> */ Union$1(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*IEqualityComparer<TSource>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Union$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            static /*IQueryable<TSource> */ UnionBy(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.UnionBy).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            static /*IQueryable<TSource> */ UnionBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.UnionBy$1).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<(int Index, TSource Item)> */ Index(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$spc.System.ValueTuple$$$($.$spc.System.Int32, TSource), $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.IQueryable$$($.$spc.System.ValueTuple$$$($.$spc.System.Int32, TSource))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Index).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*IQueryable<TSource> */ Intersect(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Intersect).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2)));
            }
            static /*IQueryable<TSource> */ Intersect$1(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*IEqualityComparer<TSource>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Intersect$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            static /*IQueryable<TSource> */ IntersectBy(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TKey>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IEnumerable$$(TKey), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.IntersectBy).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TKey, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            static /*IQueryable<TSource> */ IntersectBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TKey>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IEnumerable$$(TKey), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.IntersectBy$1).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TKey, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<TSource> */ Except(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Except).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2)));
            }
            static /*IQueryable<TSource> */ Except$1(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*IEqualityComparer<TSource>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Except$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            static /*IQueryable<TSource> */ ExceptBy(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TKey>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IEnumerable$$(TKey), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ExceptBy).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TKey, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            static /*IQueryable<TSource> */ ExceptBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TKey>*/ source2, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IEnumerable$$(TKey), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ExceptBy$1).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TKey, source2), $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*TSource */ First(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.First).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*TSource */ First$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.First$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*TSource? */ FirstOrDefault(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.FirstOrDefault).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*TSource */ FirstOrDefault$1(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ defaultValue)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.FirstOrDefault$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(defaultValue, TSource), TSource.$type)));
            }
            static /*TSource? */ FirstOrDefault$2(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.FirstOrDefault$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*TSource */ FirstOrDefault$3(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate, /*TSource*/ defaultValue)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.FirstOrDefault$3).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate), $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(defaultValue, TSource), TSource.$type)));
            }
            static /*TSource */ Last(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Last).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*TSource */ Last$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Last$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*TSource? */ LastOrDefault(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LastOrDefault).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*TSource */ LastOrDefault$1(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ defaultValue)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LastOrDefault$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(defaultValue, TSource), TSource.$type)));
            }
            static /*TSource? */ LastOrDefault$2(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LastOrDefault$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*TSource */ LastOrDefault$3(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate, /*TSource*/ defaultValue)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LastOrDefault$3).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate), $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(defaultValue, TSource), TSource.$type)));
            }
            static /*TSource */ Single(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Single).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*TSource */ Single$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Single$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*TSource? */ SingleOrDefault(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SingleOrDefault).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*TSource */ SingleOrDefault$1(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ defaultValue)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SingleOrDefault$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(defaultValue, TSource), TSource.$type)));
            }
            static /*TSource? */ SingleOrDefault$2(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SingleOrDefault$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*TSource */ SingleOrDefault$3(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate, /*TSource*/ defaultValue)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)), TSource, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SingleOrDefault$3).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate), $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(defaultValue, TSource), TSource.$type)));
            }
            static /*TSource */ ElementAt(TSource, /*this IQueryable<TSource>*/ source, /*int*/ index)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                if (index < 0)
                {
                    throw $.$slq.System.Linq.Error.ArgumentOutOfRange("index");
                }
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Int32, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ElementAt).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(index, $.$spc.System.Int32))));
            }
            static /*TSource */ ElementAt$1(TSource, /*this IQueryable<TSource>*/ source, /*Index*/ index)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                if (index.IsFromEnd && index.Value === 0)
                {
                    throw $.$slq.System.Linq.Error.ArgumentOutOfRange("index");
                }
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Index, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ElementAt$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant(index)));
            }
            static /*TSource? */ ElementAtOrDefault(TSource, /*this IQueryable<TSource>*/ source, /*int*/ index)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Int32, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ElementAtOrDefault).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(index, $.$spc.System.Int32))));
            }
            static /*TSource? */ ElementAtOrDefault$1(TSource, /*this IQueryable<TSource>*/ source, /*Index*/ index)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Index, TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.ElementAtOrDefault$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant(index)));
            }
            static /*IQueryable<TSource?> */ DefaultIfEmpty(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.DefaultIfEmpty).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*IQueryable<TSource> */ DefaultIfEmpty$1(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ defaultValue)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.DefaultIfEmpty$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(defaultValue, TSource), TSource.$type)));
            }
            static /*bool */ Contains(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ item)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, $.$spc.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Contains).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(item, TSource), TSource.$type)));
            }
            static /*bool */ Contains$1(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ item, /*IEqualityComparer<TSource>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource), $.$spc.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Contains$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1($.$box(item, TSource), TSource.$type), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            static /*IQueryable<TSource> */ Reverse(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Reverse).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*bool */ SequenceEqual(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SequenceEqual).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2)));
            }
            static /*bool */ SequenceEqual$1(TSource, /*this IQueryable<TSource>*/ source1, /*IEnumerable<TSource>*/ source2, /*IEqualityComparer<TSource>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source1, "source1");
                $.$spc.System.ArgumentNullException.ThrowIfNull(source2, "source2");
                return source1.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource), $.$spc.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SequenceEqual$1).Method, source1.System$Linq$IQueryable$Expression, $.$slq.System.Linq.Queryable.GetSourceExpression(TSource, source2), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource).$type)));
            }
            static /*IQueryable<TSource> */ Shuffle(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Shuffle).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*bool */ Any(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Any).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*bool */ Any$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)), $.$spc.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Any$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*bool */ All(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Boolean, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)), $.$spc.System.Boolean))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.All).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*int */ Count(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Int32, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Int32))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Count).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*int */ Count$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Int32, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)), $.$spc.System.Int32))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Count$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*IQueryable<KeyValuePair<TKey, int>> */ CountBy(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$spc.System.Collections.Generic.KeyValuePair$$$(TKey, $.$spc.System.Int32), $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$($.$spc.System.Collections.Generic.KeyValuePair$$$(TKey, $.$spc.System.Int32))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.CountBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$type)));
            }
            static /*long */ LongCount(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Int64, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Int64))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LongCount).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*long */ LongCount$1(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, bool>>*/ predicate)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(predicate, "predicate");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Int64, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)), $.$spc.System.Int64))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.LongCount$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(predicate)));
            }
            static /*TSource? */ Min(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Min).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*TSource? */ Min$1(TSource, /*this IQueryable<TSource>*/ source, /*IComparer<TSource>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IComparer$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Min$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IComparer$$(TSource).$type)));
            }
            static /*TResult? */ Min$2(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TResult>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TResult)), TResult))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Min$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*TSource? */ MinBy(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MinBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            static /*TSource? */ MinBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TSource>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$spc.System.Collections.Generic.IComparer$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MinBy$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IComparer$$(TSource).$type)));
            }
            static /*TSource? */ MinBy$2(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$spc.System.Collections.Generic.IComparer$$(TKey), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MinBy$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IComparer$$(TKey).$type)));
            }
            static /*TSource? */ Max(TSource, /*this IQueryable<TSource>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Max).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*TSource? */ Max$1(TSource, /*this IQueryable<TSource>*/ source, /*IComparer<TSource>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Collections.Generic.IComparer$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Max$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IComparer$$(TSource).$type)));
            }
            static /*TResult? */ Max$2(TSource, TResult, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TResult>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TResult)), TResult))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Max$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*TSource? */ MaxBy(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MaxBy).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector)));
            }
            static /*TSource? */ MaxBy$1(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TSource>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$spc.System.Collections.Generic.IComparer$$(TSource), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MaxBy$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IComparer$$(TSource).$type)));
            }
            static /*TSource? */ MaxBy$2(TSource, TKey, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$spc.System.Collections.Generic.IComparer$$(TKey), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.MaxBy$2).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant$1(comparer, $.$spc.System.Collections.Generic.IComparer$$(TKey).$type)));
            }
            static /*int */ Sum(/*this IQueryable<int>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Int32, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Int32), $.$spc.System.Int32))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*int? */ Sum$1(/*this IQueryable<int?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Int32), $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Int32)), $.$spc.System.Nullable$$($.$spc.System.Int32)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$1).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*long */ Sum$2(/*this IQueryable<long>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Int64, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Int64), $.$spc.System.Int64))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$2).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*long? */ Sum$3(/*this IQueryable<long?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Int64), $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Int64)), $.$spc.System.Nullable$$($.$spc.System.Int64)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$3).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*float */ Sum$4(/*this IQueryable<float>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Single, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Single), $.$spc.System.Single))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$4).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*float? */ Sum$5(/*this IQueryable<float?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Single), $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Single)), $.$spc.System.Nullable$$($.$spc.System.Single)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$5).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*double */ Sum$6(/*this IQueryable<double>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Double), $.$spc.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$6).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*double? */ Sum$7(/*this IQueryable<double?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Double)), $.$spc.System.Nullable$$($.$spc.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$7).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*decimal */ Sum$8(/*this IQueryable<decimal>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Decimal, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Decimal), $.$spc.System.Decimal))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$8).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*decimal? */ Sum$9(/*this IQueryable<decimal?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Decimal), $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Decimal)), $.$spc.System.Nullable$$($.$spc.System.Decimal)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$9)?.Clone() ?? null.Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*int */ Sum$10(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Int32, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Int32)), $.$spc.System.Int32))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$10).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*int? */ Sum$11(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int?>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Int32), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Int32))), $.$spc.System.Nullable$$($.$spc.System.Int32)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$11).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*long */ Sum$12(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, long>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Int64, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Int64)), $.$spc.System.Int64))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$12).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*long? */ Sum$13(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, long?>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Int64), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Int64))), $.$spc.System.Nullable$$($.$spc.System.Int64)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$13).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*float */ Sum$14(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, float>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Single, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Single)), $.$spc.System.Single))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$14).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*float? */ Sum$15(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, float?>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Single), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Single))), $.$spc.System.Nullable$$($.$spc.System.Single)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$15).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*double */ Sum$16(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, double>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Double)), $.$spc.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$16).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*double? */ Sum$17(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, double?>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Double))), $.$spc.System.Nullable$$($.$spc.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$17).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*decimal */ Sum$18(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, decimal>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Decimal, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Decimal)), $.$spc.System.Decimal))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$18).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*decimal? */ Sum$19(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, decimal?>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Decimal), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Decimal))), $.$spc.System.Nullable$$($.$spc.System.Decimal)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Sum$19)?.Clone() ?? null.Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*double */ Average(/*this IQueryable<int>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Int32), $.$spc.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*double? */ Average$1(/*this IQueryable<int?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Int32)), $.$spc.System.Nullable$$($.$spc.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$1).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*double */ Average$2(/*this IQueryable<long>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Int64), $.$spc.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$2).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*double? */ Average$3(/*this IQueryable<long?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Int64)), $.$spc.System.Nullable$$($.$spc.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$3).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*float */ Average$4(/*this IQueryable<float>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Single, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Single), $.$spc.System.Single))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$4).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*float? */ Average$5(/*this IQueryable<float?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Single), $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Single)), $.$spc.System.Nullable$$($.$spc.System.Single)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$5).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*double */ Average$6(/*this IQueryable<double>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Double), $.$spc.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$6).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*double? */ Average$7(/*this IQueryable<double?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Double)), $.$spc.System.Nullable$$($.$spc.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$7).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*decimal */ Average$8(/*this IQueryable<decimal>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Decimal, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Decimal), $.$spc.System.Decimal))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$8).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*decimal? */ Average$9(/*this IQueryable<decimal?>*/ source)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Decimal), $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$($.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Decimal)), $.$spc.System.Nullable$$($.$spc.System.Decimal)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$9)?.Clone() ?? null.Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression ], null, null)));
            }
            static /*double */ Average$10(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Int32)), $.$spc.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$10).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*double? */ Average$11(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, int?>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Int32))), $.$spc.System.Nullable$$($.$spc.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$11).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*float */ Average$12(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, float>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Single, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Single)), $.$spc.System.Single))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$12).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*float? */ Average$13(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, float?>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Single), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Single))), $.$spc.System.Nullable$$($.$spc.System.Single)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$13).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*double */ Average$14(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, long>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Int64)), $.$spc.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$14).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*double? */ Average$15(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, long?>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Int64))), $.$spc.System.Nullable$$($.$spc.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$15).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*double */ Average$16(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, double>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Double, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Double)), $.$spc.System.Double))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$16).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*double? */ Average$17(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, double?>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Double), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Double))), $.$spc.System.Nullable$$($.$spc.System.Double)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$17).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*decimal */ Average$18(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, decimal>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$spc.System.Decimal, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Decimal)), $.$spc.System.Decimal))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$18).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*decimal? */ Average$19(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, decimal?>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1($.$typeNullable($.$spc.System.Decimal), $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Decimal))), $.$spc.System.Nullable$$($.$spc.System.Decimal)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Average$19)?.Clone() ?? null.Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(selector)));
            }
            static /*TSource */ Aggregate(TSource, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TSource, TSource>>*/ func)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(func, "func");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, TSource, TSource)), TSource))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Aggregate).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(func)));
            }
            static /*TAccumulate */ Aggregate$1(TSource, TAccumulate, /*this IQueryable<TSource>*/ source, /*TAccumulate*/ seed, /*Expression<Func<TAccumulate, TSource, TAccumulate>>*/ func)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(func, "func");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TAccumulate, $.$sle.System.Linq.Expressions.Expression.Call$12(null, new ($.$spc.System.Func$$$$$($.$sle.System.Linq.IQueryable$$(TSource), TAccumulate, $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TAccumulate, TSource, TAccumulate)), TAccumulate))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Aggregate$1).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(seed, TAccumulate)), $.$sle.System.Linq.Expressions.Expression.Quote(func)));
            }
            static /*TResult */ Aggregate$2(TSource, TAccumulate, TResult, /*this IQueryable<TSource>*/ source, /*TAccumulate*/ seed, /*Expression<Func<TAccumulate, TSource, TAccumulate>>*/ func, /*Expression<Func<TAccumulate, TResult>>*/ selector)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(func, "func");
                $.$spc.System.ArgumentNullException.ThrowIfNull(selector, "selector");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$Execute$1(TResult, $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), TAccumulate, $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TAccumulate, TSource, TAccumulate)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TAccumulate, TResult)), TResult))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Aggregate$2).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(seed, TAccumulate)), $.$sle.System.Linq.Expressions.Expression.Quote(func), $.$sle.System.Linq.Expressions.Expression.Quote(selector) ], null, null)));
            }
            static /*IQueryable<KeyValuePair<TKey, TAccumulate>> */ AggregateBy(TSource, TKey, TAccumulate, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*TAccumulate*/ seed, /*Expression<Func<TAccumulate, TSource, TAccumulate>>*/ func, /*IEqualityComparer<TKey>?*/ keyComparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(func, "func");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$spc.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate), $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), TAccumulate, $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TAccumulate, TSource, TAccumulate)), $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$($.$spc.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.AggregateBy).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Constant($.$box(seed, TAccumulate)), $.$sle.System.Linq.Expressions.Expression.Quote(func), $.$sle.System.Linq.Expressions.Expression.Constant$1(keyComparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<KeyValuePair<TKey, TAccumulate>> */ AggregateBy$1(TSource, TKey, TAccumulate, /*this IQueryable<TSource>*/ source, /*Expression<Func<TSource, TKey>>*/ keySelector, /*Expression<Func<TKey, TAccumulate>>*/ seedSelector, /*Expression<Func<TAccumulate, TSource, TAccumulate>>*/ func, /*IEqualityComparer<TKey>?*/ keyComparer)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                $.$spc.System.ArgumentNullException.ThrowIfNull(keySelector, "keySelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(seedSelector, "seedSelector");
                $.$spc.System.ArgumentNullException.ThrowIfNull(func, "func");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1($.$spc.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate), $.$sle.System.Linq.Expressions.Expression.Call$9(null, new ($.$spc.System.Func$$$$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TKey, TAccumulate)), $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TAccumulate, TSource, TAccumulate)), $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey), $.$sle.System.Linq.IQueryable$$($.$spc.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate))))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.AggregateBy$1).Method, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sle.System.Linq.Expressions.Expression), [ source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Quote(keySelector), $.$sle.System.Linq.Expressions.Expression.Quote(seedSelector), $.$sle.System.Linq.Expressions.Expression.Quote(func), $.$sle.System.Linq.Expressions.Expression.Constant$1(keyComparer, $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$type) ], null, null)));
            }
            static /*IQueryable<TSource> */ SkipLast(TSource, /*this IQueryable<TSource>*/ source, /*int*/ count)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Int32, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.SkipLast).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(count, $.$spc.System.Int32))));
            }
            static /*IQueryable<TSource> */ TakeLast(TSource, /*this IQueryable<TSource>*/ source, /*int*/ count)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), $.$spc.System.Int32, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.TakeLast).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(count, $.$spc.System.Int32))));
            }
            static /*IQueryable<TSource> */ Append(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Append).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(element, TSource))));
            }
            static /*IQueryable<TSource> */ Prepend(TSource, /*this IQueryable<TSource>*/ source, /*TSource*/ element)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(source, "source");
                return source.System$Linq$IQueryable$Provider.System$Linq$IQueryProvider$CreateQuery$1(TSource, $.$sle.System.Linq.Expressions.Expression.Call$11(null, new ($.$spc.System.Func$$$$($.$sle.System.Linq.IQueryable$$(TSource), TSource, $.$sle.System.Linq.IQueryable$$(TSource)))().$ctor($.$slq.System.Linq.Queryable, $.$slq.System.Linq.Queryable.Prepend).Method, source.System$Linq$IQueryable$Expression, $.$sle.System.Linq.Expressions.Expression.Constant($.$box(element, TSource))));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.InMemoryQueryableExtensionMethodsRequiresUnreferencedCode = "Enumerating in-memory collections as IQueryable can require unreferenced code because expressions referencing IQueryable extension methods can get rebound to IEnumerable extension methods. The IEnumerable extension methods could be trimmed causing the application to fail at runtime.";
                }
                {
                    this.InMemoryQueryableExtensionMethodsRequiresDynamicCode = "Enumerating in-memory collections as IQueryable can require creating new generic types or methods, which requires creating code at runtime. This may not work when AOT compiling.";
                }
            }
            static $h = 503028;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":(TElement) => $.$sle.System.Linq.IQueryable$$(TElement).$h,"p":[{"n":"source","p":(TElement) => $.$spc.System.Collections.Generic.IEnumerable$$(TElement).$h}],"g":["TElement"],"n":"AsQueryable","d":503028,"h":12885404916,"f":131105},{"r":42110412,"p":[{"n":"source","p":31653889}],"n":"AsQueryable","o":"@$1","d":503028,"h":17180372212,"f":33},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)).$h}],"g":["TSource"],"n":"Where","d":503028,"h":21475339508,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, $.$spc.System.Int32, $.$spc.System.Boolean)).$h}],"g":["TSource"],"n":"Where","o":"@$1","d":503028,"h":25770306804,"f":131105},{"r":(TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":42110412}],"g":["TResult"],"n":"OfType","d":503028,"h":30065274100,"f":131105},{"r":(TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":42110412}],"g":["TResult"],"n":"Cast","d":503028,"h":34360241396,"f":131105},{"r":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TResult)).$h}],"g":["TSource","TResult"],"n":"Select","d":503028,"h":38655208692,"f":131105},{"r":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, $.$spc.System.Int32, TResult)).$h}],"g":["TSource","TResult"],"n":"Select","o":"@$1","d":503028,"h":42950175988,"f":131105},{"r":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Collections.Generic.IEnumerable$$(TResult))).$h}],"g":["TSource","TResult"],"n":"SelectMany","d":503028,"h":47245143284,"f":131105},{"r":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, $.$spc.System.Int32, $.$spc.System.Collections.Generic.IEnumerable$$(TResult))).$h}],"g":["TSource","TResult"],"n":"SelectMany","o":"@$1","d":503028,"h":51540110580,"f":131105},{"r":(TSource, TCollection, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TCollection, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"collectionSelector","p":(TSource, TCollection, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, $.$spc.System.Int32, $.$spc.System.Collections.Generic.IEnumerable$$(TCollection))).$h},{"n":"resultSelector","p":(TSource, TCollection, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, TCollection, TResult)).$h}],"g":["TSource","TCollection","TResult"],"n":"SelectMany","o":"@$2","d":503028,"h":55835077876,"f":131105},{"r":(TSource, TCollection, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TCollection, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"collectionSelector","p":(TSource, TCollection, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Collections.Generic.IEnumerable$$(TCollection))).$h},{"n":"resultSelector","p":(TSource, TCollection, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, TCollection, TResult)).$h}],"g":["TSource","TCollection","TResult"],"n":"SelectMany","o":"@$3","d":503028,"h":60130045172,"f":131105},{"r":8687052,"p":[{"n":"source","p":(TSource) => $.$spc.System.Collections.Generic.IEnumerable$$(TSource).$h}],"g":["TSource"],"n":"GetSourceExpression","d":503028,"h":64425012468,"f":131106},{"r":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"outer","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h},{"n":"inner","p":(TOuter, TInner, TKey, TResult) => $.$spc.System.Collections.Generic.IEnumerable$$(TInner).$h},{"n":"outerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TOuter, TKey)).$h},{"n":"innerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TInner, TKey)).$h},{"n":"resultSelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TOuter, TInner, TResult)).$h}],"g":["TOuter","TInner","TKey","TResult"],"n":"Join","d":503028,"h":68719979764,"f":131105},{"r":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"outer","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h},{"n":"inner","p":(TOuter, TInner, TKey, TResult) => $.$spc.System.Collections.Generic.IEnumerable$$(TInner).$h},{"n":"outerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TOuter, TKey)).$h},{"n":"innerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TInner, TKey)).$h},{"n":"resultSelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TOuter, TInner, TResult)).$h},{"n":"comparer","p":(TOuter, TInner, TKey, TResult) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TOuter","TInner","TKey","TResult"],"n":"Join","o":"@$1","d":503028,"h":73014947060,"f":131105},{"r":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"outer","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h},{"n":"inner","p":(TOuter, TInner, TKey, TResult) => $.$spc.System.Collections.Generic.IEnumerable$$(TInner).$h},{"n":"outerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TOuter, TKey)).$h},{"n":"innerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TInner, TKey)).$h},{"n":"resultSelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TOuter, $.$spc.System.Collections.Generic.IEnumerable$$(TInner), TResult)).$h}],"g":["TOuter","TInner","TKey","TResult"],"n":"GroupJoin","d":503028,"h":77309914356,"f":131105},{"r":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"outer","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h},{"n":"inner","p":(TOuter, TInner, TKey, TResult) => $.$spc.System.Collections.Generic.IEnumerable$$(TInner).$h},{"n":"outerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TOuter, TKey)).$h},{"n":"innerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TInner, TKey)).$h},{"n":"resultSelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TOuter, $.$spc.System.Collections.Generic.IEnumerable$$(TInner), TResult)).$h},{"n":"comparer","p":(TOuter, TInner, TKey, TResult) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TOuter","TInner","TKey","TResult"],"n":"GroupJoin","o":"@$1","d":503028,"h":81604881652,"f":131105},{"r":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"outer","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h},{"n":"inner","p":(TOuter, TInner, TKey, TResult) => $.$spc.System.Collections.Generic.IEnumerable$$(TInner).$h},{"n":"outerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TOuter, TKey)).$h},{"n":"innerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TInner, TKey)).$h},{"n":"resultSelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TOuter, TInner, TResult)).$h}],"g":["TOuter","TInner","TKey","TResult"],"n":"LeftJoin","d":503028,"h":85899848948,"f":131105},{"r":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"outer","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h},{"n":"inner","p":(TOuter, TInner, TKey, TResult) => $.$spc.System.Collections.Generic.IEnumerable$$(TInner).$h},{"n":"outerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TOuter, TKey)).$h},{"n":"innerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TInner, TKey)).$h},{"n":"resultSelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TOuter, TInner, TResult)).$h},{"n":"comparer","p":(TOuter, TInner, TKey, TResult) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TOuter","TInner","TKey","TResult"],"n":"LeftJoin","o":"@$1","d":503028,"h":90194816244,"f":131105},{"r":(T) => $.$sle.System.Linq.IOrderedQueryable$$(T).$h,"p":[{"n":"source","p":(T) => $.$sle.System.Linq.IQueryable$$(T).$h}],"g":["T"],"n":"Order","d":503028,"h":94489783540,"f":131105},{"r":(T) => $.$sle.System.Linq.IOrderedQueryable$$(T).$h,"p":[{"n":"source","p":(T) => $.$sle.System.Linq.IQueryable$$(T).$h},{"n":"comparer","p":(T) => $.$spc.System.Collections.Generic.IComparer$$(T).$h}],"g":["T"],"n":"Order","o":"@$1","d":503028,"h":98784750836,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"OrderBy","d":503028,"h":103079718132,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"OrderBy","o":"@$1","d":503028,"h":107374685428,"f":131105},{"r":(T) => $.$sle.System.Linq.IOrderedQueryable$$(T).$h,"p":[{"n":"source","p":(T) => $.$sle.System.Linq.IQueryable$$(T).$h}],"g":["T"],"n":"OrderDescending","d":503028,"h":111669652724,"f":131105},{"r":(T) => $.$sle.System.Linq.IOrderedQueryable$$(T).$h,"p":[{"n":"source","p":(T) => $.$sle.System.Linq.IQueryable$$(T).$h},{"n":"comparer","p":(T) => $.$spc.System.Collections.Generic.IComparer$$(T).$h}],"g":["T"],"n":"OrderDescending","o":"@$1","d":503028,"h":115964620020,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"OrderByDescending","d":503028,"h":120259587316,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"OrderByDescending","o":"@$1","d":503028,"h":124554554612,"f":131105},{"r":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"outer","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h},{"n":"inner","p":(TOuter, TInner, TKey, TResult) => $.$spc.System.Collections.Generic.IEnumerable$$(TInner).$h},{"n":"outerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TOuter, TKey)).$h},{"n":"innerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TInner, TKey)).$h},{"n":"resultSelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TOuter, TInner, TResult)).$h}],"g":["TOuter","TInner","TKey","TResult"],"n":"RightJoin","d":503028,"h":128849521908,"f":131105},{"r":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"outer","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TOuter).$h},{"n":"inner","p":(TOuter, TInner, TKey, TResult) => $.$spc.System.Collections.Generic.IEnumerable$$(TInner).$h},{"n":"outerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TOuter, TKey)).$h},{"n":"innerKeySelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TInner, TKey)).$h},{"n":"resultSelector","p":(TOuter, TInner, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TOuter, TInner, TResult)).$h},{"n":"comparer","p":(TOuter, TInner, TKey, TResult) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TOuter","TInner","TKey","TResult"],"n":"RightJoin","o":"@$1","d":503028,"h":133144489204,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"ThenBy","d":503028,"h":137439456500,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"ThenBy","o":"@$1","d":503028,"h":141734423796,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"ThenByDescending","d":503028,"h":146029391092,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IOrderedQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"ThenByDescending","o":"@$1","d":503028,"h":150324358388,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"count","p":655361}],"g":["TSource"],"n":"Take","d":503028,"h":154619325684,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"range","p":73072641}],"g":["TSource"],"n":"Take","o":"@$1","d":503028,"h":158914292980,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)).$h}],"g":["TSource"],"n":"TakeWhile","d":503028,"h":163209260276,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, $.$spc.System.Int32, $.$spc.System.Boolean)).$h}],"g":["TSource"],"n":"TakeWhile","o":"@$1","d":503028,"h":167504227572,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"count","p":655361}],"g":["TSource"],"n":"Skip","d":503028,"h":171799194868,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)).$h}],"g":["TSource"],"n":"SkipWhile","d":503028,"h":176094162164,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, $.$spc.System.Int32, $.$spc.System.Boolean)).$h}],"g":["TSource"],"n":"SkipWhile","o":"@$1","d":503028,"h":180389129460,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TSource)).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"GroupBy","d":503028,"h":184684096756,"f":131105},{"r":(TSource, TKey, TElement) => $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)).$h,"p":[{"n":"source","p":(TSource, TKey, TElement) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey, TElement) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"elementSelector","p":(TSource, TKey, TElement) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TElement)).$h}],"g":["TSource","TKey","TElement"],"n":"GroupBy","o":"@$1","d":503028,"h":188979064052,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TSource)).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"GroupBy","o":"@$2","d":503028,"h":193274031348,"f":131105},{"r":(TSource, TKey, TElement) => $.$sle.System.Linq.IQueryable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)).$h,"p":[{"n":"source","p":(TSource, TKey, TElement) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey, TElement) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"elementSelector","p":(TSource, TKey, TElement) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TElement)).$h},{"n":"comparer","p":(TSource, TKey, TElement) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TSource","TKey","TElement"],"n":"GroupBy","o":"@$3","d":503028,"h":197568998644,"f":131105},{"r":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"elementSelector","p":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TElement)).$h},{"n":"resultSelector","p":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TKey, $.$spc.System.Collections.Generic.IEnumerable$$(TElement), TResult)).$h}],"g":["TSource","TKey","TElement","TResult"],"n":"GroupBy","o":"@$4","d":503028,"h":201863965940,"f":131105},{"r":(TSource, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"resultSelector","p":(TSource, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TKey, $.$spc.System.Collections.Generic.IEnumerable$$(TSource), TResult)).$h}],"g":["TSource","TKey","TResult"],"n":"GroupBy","o":"@$5","d":503028,"h":206158933236,"f":131105},{"r":(TSource, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TKey, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"resultSelector","p":(TSource, TKey, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TKey, $.$spc.System.Collections.Generic.IEnumerable$$(TSource), TResult)).$h},{"n":"comparer","p":(TSource, TKey, TResult) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TSource","TKey","TResult"],"n":"GroupBy","o":"@$6","d":503028,"h":210453900532,"f":131105},{"r":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source","p":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"elementSelector","p":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TElement)).$h},{"n":"resultSelector","p":(TSource, TKey, TElement, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TKey, $.$spc.System.Collections.Generic.IEnumerable$$(TElement), TResult)).$h},{"n":"comparer","p":(TSource, TKey, TElement, TResult) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TSource","TKey","TElement","TResult"],"n":"GroupBy","o":"@$7","d":503028,"h":214748867828,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Distinct","d":503028,"h":219043835124,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"comparer","p":(TSource) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource).$h}],"g":["TSource"],"n":"Distinct","o":"@$1","d":503028,"h":223338802420,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"DistinctBy","d":503028,"h":227633769716,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"DistinctBy","o":"@$1","d":503028,"h":231928737012,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$($.$typeArray(TSource)).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"size","p":655361}],"g":["TSource"],"n":"Chunk","d":503028,"h":236223704308,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$spc.System.Collections.Generic.IEnumerable$$(TSource).$h}],"g":["TSource"],"n":"Concat","d":503028,"h":240518671604,"f":131105},{"r":(TFirst, TSecond) => $.$sle.System.Linq.IQueryable$$($.$spc.System.ValueTuple$$$(TFirst, TSecond)).$h,"p":[{"n":"source1","p":(TFirst, TSecond) => $.$sle.System.Linq.IQueryable$$(TFirst).$h},{"n":"source2","p":(TFirst, TSecond) => $.$spc.System.Collections.Generic.IEnumerable$$(TSecond).$h}],"g":["TFirst","TSecond"],"n":"Zip","d":503028,"h":244813638900,"f":131105},{"r":(TFirst, TSecond, TResult) => $.$sle.System.Linq.IQueryable$$(TResult).$h,"p":[{"n":"source1","p":(TFirst, TSecond, TResult) => $.$sle.System.Linq.IQueryable$$(TFirst).$h},{"n":"source2","p":(TFirst, TSecond, TResult) => $.$spc.System.Collections.Generic.IEnumerable$$(TSecond).$h},{"n":"resultSelector","p":(TFirst, TSecond, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TFirst, TSecond, TResult)).$h}],"g":["TFirst","TSecond","TResult"],"n":"Zip","o":"@$1","d":503028,"h":249108606196,"f":131105},{"r":(TFirst, TSecond, TThird) => $.$sle.System.Linq.IQueryable$$($.$spc.System.ValueTuple$$$$(TFirst, TSecond, TThird)).$h,"p":[{"n":"source1","p":(TFirst, TSecond, TThird) => $.$sle.System.Linq.IQueryable$$(TFirst).$h},{"n":"source2","p":(TFirst, TSecond, TThird) => $.$spc.System.Collections.Generic.IEnumerable$$(TSecond).$h},{"n":"source3","p":(TFirst, TSecond, TThird) => $.$spc.System.Collections.Generic.IEnumerable$$(TThird).$h}],"g":["TFirst","TSecond","TThird"],"n":"Zip","o":"@$2","d":503028,"h":253403573492,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$spc.System.Collections.Generic.IEnumerable$$(TSource).$h}],"g":["TSource"],"n":"Union","d":503028,"h":257698540788,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$spc.System.Collections.Generic.IEnumerable$$(TSource).$h},{"n":"comparer","p":(TSource) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource).$h}],"g":["TSource"],"n":"Union","o":"@$1","d":503028,"h":261993508084,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IEnumerable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"UnionBy","d":503028,"h":266288475380,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IEnumerable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"UnionBy","o":"@$1","d":503028,"h":270583442676,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$($.$spc.System.ValueTuple$$$($.$spc.System.Int32, TSource)).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Index","d":503028,"h":274878409972,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$spc.System.Collections.Generic.IEnumerable$$(TSource).$h}],"g":["TSource"],"n":"Intersect","d":503028,"h":279173377268,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$spc.System.Collections.Generic.IEnumerable$$(TSource).$h},{"n":"comparer","p":(TSource) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource).$h}],"g":["TSource"],"n":"Intersect","o":"@$1","d":503028,"h":283468344564,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IEnumerable$$(TKey).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"IntersectBy","d":503028,"h":287763311860,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IEnumerable$$(TKey).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"IntersectBy","o":"@$1","d":503028,"h":292058279156,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$spc.System.Collections.Generic.IEnumerable$$(TSource).$h}],"g":["TSource"],"n":"Except","d":503028,"h":296353246452,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$spc.System.Collections.Generic.IEnumerable$$(TSource).$h},{"n":"comparer","p":(TSource) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource).$h}],"g":["TSource"],"n":"Except","o":"@$1","d":503028,"h":300648213748,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IEnumerable$$(TKey).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"ExceptBy","d":503028,"h":304943181044,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source1","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IEnumerable$$(TKey).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"ExceptBy","o":"@$1","d":503028,"h":309238148340,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"First","d":503028,"h":313533115636,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)).$h}],"g":["TSource"],"n":"First","o":"@$1","d":503028,"h":317828082932,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"FirstOrDefault","d":503028,"h":322123050228,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"defaultValue","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"FirstOrDefault","o":"@$1","d":503028,"h":326418017524,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)).$h}],"g":["TSource"],"n":"FirstOrDefault","o":"@$2","d":503028,"h":330712984820,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)).$h},{"n":"defaultValue","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"FirstOrDefault","o":"@$3","d":503028,"h":335007952116,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Last","d":503028,"h":339302919412,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)).$h}],"g":["TSource"],"n":"Last","o":"@$1","d":503028,"h":343597886708,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"LastOrDefault","d":503028,"h":347892854004,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"defaultValue","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"LastOrDefault","o":"@$1","d":503028,"h":352187821300,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)).$h}],"g":["TSource"],"n":"LastOrDefault","o":"@$2","d":503028,"h":356482788596,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)).$h},{"n":"defaultValue","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"LastOrDefault","o":"@$3","d":503028,"h":360777755892,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Single","d":503028,"h":365072723188,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)).$h}],"g":["TSource"],"n":"Single","o":"@$1","d":503028,"h":369367690484,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"SingleOrDefault","d":503028,"h":373662657780,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"defaultValue","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"SingleOrDefault","o":"@$1","d":503028,"h":377957625076,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)).$h}],"g":["TSource"],"n":"SingleOrDefault","o":"@$2","d":503028,"h":382252592372,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)).$h},{"n":"defaultValue","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"SingleOrDefault","o":"@$3","d":503028,"h":386547559668,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"index","p":655361}],"g":["TSource"],"n":"ElementAt","d":503028,"h":390842526964,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"index","p":57868289}],"g":["TSource"],"n":"ElementAt","o":"@$1","d":503028,"h":395137494260,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"index","p":655361}],"g":["TSource"],"n":"ElementAtOrDefault","d":503028,"h":399432461556,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"index","p":57868289}],"g":["TSource"],"n":"ElementAtOrDefault","o":"@$1","d":503028,"h":403727428852,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"DefaultIfEmpty","d":503028,"h":408022396148,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"defaultValue","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"DefaultIfEmpty","o":"@$1","d":503028,"h":412317363444,"f":131105},{"r":262145,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"item","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"Contains","d":503028,"h":416612330740,"f":131105},{"r":262145,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"item","p":(TSource) => TSource.$h},{"n":"comparer","p":(TSource) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource).$h}],"g":["TSource"],"n":"Contains","o":"@$1","d":503028,"h":420907298036,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Reverse","d":503028,"h":425202265332,"f":131105},{"r":262145,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$spc.System.Collections.Generic.IEnumerable$$(TSource).$h}],"g":["TSource"],"n":"SequenceEqual","d":503028,"h":429497232628,"f":131105},{"r":262145,"p":[{"n":"source1","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"source2","p":(TSource) => $.$spc.System.Collections.Generic.IEnumerable$$(TSource).$h},{"n":"comparer","p":(TSource) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TSource).$h}],"g":["TSource"],"n":"SequenceEqual","o":"@$1","d":503028,"h":433792199924,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Shuffle","d":503028,"h":438087167220,"f":131105},{"r":262145,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Any","d":503028,"h":442382134516,"f":131105},{"r":262145,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)).$h}],"g":["TSource"],"n":"Any","o":"@$1","d":503028,"h":446677101812,"f":131105},{"r":262145,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)).$h}],"g":["TSource"],"n":"All","d":503028,"h":450972069108,"f":131105},{"r":655361,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Count","d":503028,"h":455267036404,"f":131105},{"r":655361,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)).$h}],"g":["TSource"],"n":"Count","o":"@$1","d":503028,"h":459562003700,"f":131105},{"r":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$($.$spc.System.Collections.Generic.KeyValuePair$$$(TKey, $.$spc.System.Int32)).$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h,"f":65}],"g":["TSource","TKey"],"n":"CountBy","d":503028,"h":463856970996,"f":131105},{"r":917505,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"LongCount","d":503028,"h":468151938292,"f":131105},{"r":917505,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"predicate","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean)).$h}],"g":["TSource"],"n":"LongCount","o":"@$1","d":503028,"h":472446905588,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Min","d":503028,"h":476741872884,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"comparer","p":(TSource) => $.$spc.System.Collections.Generic.IComparer$$(TSource).$h}],"g":["TSource"],"n":"Min","o":"@$1","d":503028,"h":481036840180,"f":131105},{"r":(TSource, TResult) => TResult.$h,"p":[{"n":"source","p":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TResult)).$h}],"g":["TSource","TResult"],"n":"Min","o":"@$2","d":503028,"h":485331807476,"f":131105},{"r":(TSource, TKey) => TSource.$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"MinBy","d":503028,"h":489626774772,"f":131105},{"r":(TSource, TKey) => TSource.$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IComparer$$(TSource).$h}],"g":["TSource","TKey"],"n":"MinBy","o":"@$1","d":503028,"h":493921742068,"f":131105,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"The Queryable MinBy and MaxBy taking an IComparer\u003CTSource\u003E are obsolete. Use the new ones that take an IComparer\u003CTKey\u003E.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0061","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]},{"t":93978625,"c":4388945921,"a":[{"v":-1,"t":655361}]}]},{"r":(TSource, TKey) => TSource.$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"MinBy","o":"@$2","d":503028,"h":498216709364,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h}],"g":["TSource"],"n":"Max","d":503028,"h":502511676660,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"comparer","p":(TSource) => $.$spc.System.Collections.Generic.IComparer$$(TSource).$h}],"g":["TSource"],"n":"Max","o":"@$1","d":503028,"h":506806643956,"f":131105},{"r":(TSource, TResult) => TResult.$h,"p":[{"n":"source","p":(TSource, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TResult)).$h}],"g":["TSource","TResult"],"n":"Max","o":"@$2","d":503028,"h":511101611252,"f":131105},{"r":(TSource, TKey) => TSource.$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h}],"g":["TSource","TKey"],"n":"MaxBy","d":503028,"h":515396578548,"f":131105},{"r":(TSource, TKey) => TSource.$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IComparer$$(TSource).$h}],"g":["TSource","TKey"],"n":"MaxBy","o":"@$1","d":503028,"h":519691545844,"f":131105,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"The Queryable MinBy and MaxBy taking an IComparer\u003CTSource\u003E are obsolete. Use the new ones that take an IComparer\u003CTKey\u003E.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0061","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]},{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]},{"t":93978625,"c":4388945921,"a":[{"v":-1,"t":655361}]}]},{"r":(TSource, TKey) => TSource.$h,"p":[{"n":"source","p":(TSource, TKey) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"comparer","p":(TSource, TKey) => $.$spc.System.Collections.Generic.IComparer$$(TKey).$h}],"g":["TSource","TKey"],"n":"MaxBy","o":"@$2","d":503028,"h":523986513140,"f":131105},{"r":655361,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Int32).$h}],"n":"Sum","d":503028,"h":528281480436,"f":33},{"r":$.$typeNullable($.$spc.System.Int32).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Int32)).$h}],"n":"Sum","o":"@$1","d":503028,"h":532576447732,"f":33},{"r":917505,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Int64).$h}],"n":"Sum","o":"@$2","d":503028,"h":536871415028,"f":33},{"r":$.$typeNullable($.$spc.System.Int64).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Int64)).$h}],"n":"Sum","o":"@$3","d":503028,"h":541166382324,"f":33},{"r":1114113,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Single).$h}],"n":"Sum","o":"@$4","d":503028,"h":545461349620,"f":33},{"r":$.$typeNullable($.$spc.System.Single).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Single)).$h}],"n":"Sum","o":"@$5","d":503028,"h":549756316916,"f":33},{"r":1179649,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Double).$h}],"n":"Sum","o":"@$6","d":503028,"h":554051284212,"f":33},{"r":$.$typeNullable($.$spc.System.Double).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Double)).$h}],"n":"Sum","o":"@$7","d":503028,"h":558346251508,"f":33},{"r":35061761,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Decimal).$h}],"n":"Sum","o":"@$8","d":503028,"h":562641218804,"f":33},{"r":$.$typeNullable($.$spc.System.Decimal).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Decimal)).$h}],"n":"Sum","o":"@$9","d":503028,"h":566936186100,"f":33},{"r":655361,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Int32)).$h}],"g":["TSource"],"n":"Sum","o":"@$10","d":503028,"h":571231153396,"f":131105},{"r":$.$typeNullable($.$spc.System.Int32).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Int32))).$h}],"g":["TSource"],"n":"Sum","o":"@$11","d":503028,"h":575526120692,"f":131105},{"r":917505,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Int64)).$h}],"g":["TSource"],"n":"Sum","o":"@$12","d":503028,"h":579821087988,"f":131105},{"r":$.$typeNullable($.$spc.System.Int64).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Int64))).$h}],"g":["TSource"],"n":"Sum","o":"@$13","d":503028,"h":584116055284,"f":131105},{"r":1114113,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Single)).$h}],"g":["TSource"],"n":"Sum","o":"@$14","d":503028,"h":588411022580,"f":131105},{"r":$.$typeNullable($.$spc.System.Single).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Single))).$h}],"g":["TSource"],"n":"Sum","o":"@$15","d":503028,"h":592705989876,"f":131105},{"r":1179649,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Double)).$h}],"g":["TSource"],"n":"Sum","o":"@$16","d":503028,"h":597000957172,"f":131105},{"r":$.$typeNullable($.$spc.System.Double).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Double))).$h}],"g":["TSource"],"n":"Sum","o":"@$17","d":503028,"h":601295924468,"f":131105},{"r":35061761,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Decimal)).$h}],"g":["TSource"],"n":"Sum","o":"@$18","d":503028,"h":605590891764,"f":131105},{"r":$.$typeNullable($.$spc.System.Decimal).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Decimal))).$h}],"g":["TSource"],"n":"Sum","o":"@$19","d":503028,"h":609885859060,"f":131105},{"r":1179649,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Int32).$h}],"n":"Average","d":503028,"h":614180826356,"f":33},{"r":$.$typeNullable($.$spc.System.Double).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Int32)).$h}],"n":"Average","o":"@$1","d":503028,"h":618475793652,"f":33},{"r":1179649,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Int64).$h}],"n":"Average","o":"@$2","d":503028,"h":622770760948,"f":33},{"r":$.$typeNullable($.$spc.System.Double).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Int64)).$h}],"n":"Average","o":"@$3","d":503028,"h":627065728244,"f":33},{"r":1114113,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Single).$h}],"n":"Average","o":"@$4","d":503028,"h":631360695540,"f":33},{"r":$.$typeNullable($.$spc.System.Single).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Single)).$h}],"n":"Average","o":"@$5","d":503028,"h":635655662836,"f":33},{"r":1179649,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Double).$h}],"n":"Average","o":"@$6","d":503028,"h":639950630132,"f":33},{"r":$.$typeNullable($.$spc.System.Double).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Double)).$h}],"n":"Average","o":"@$7","d":503028,"h":644245597428,"f":33},{"r":35061761,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Decimal).$h}],"n":"Average","o":"@$8","d":503028,"h":648540564724,"f":33},{"r":$.$typeNullable($.$spc.System.Decimal).$h,"p":[{"n":"source","p":$.$sle.System.Linq.IQueryable$$($.$spc.System.Nullable$$($.$spc.System.Decimal)).$h}],"n":"Average","o":"@$9","d":503028,"h":652835532020,"f":33},{"r":1179649,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Int32)).$h}],"g":["TSource"],"n":"Average","o":"@$10","d":503028,"h":657130499316,"f":131105},{"r":$.$typeNullable($.$spc.System.Double).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Int32))).$h}],"g":["TSource"],"n":"Average","o":"@$11","d":503028,"h":661425466612,"f":131105},{"r":1114113,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Single)).$h}],"g":["TSource"],"n":"Average","o":"@$12","d":503028,"h":665720433908,"f":131105},{"r":$.$typeNullable($.$spc.System.Single).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Single))).$h}],"g":["TSource"],"n":"Average","o":"@$13","d":503028,"h":670015401204,"f":131105},{"r":1179649,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Int64)).$h}],"g":["TSource"],"n":"Average","o":"@$14","d":503028,"h":674310368500,"f":131105},{"r":$.$typeNullable($.$spc.System.Double).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Int64))).$h}],"g":["TSource"],"n":"Average","o":"@$15","d":503028,"h":678605335796,"f":131105},{"r":1179649,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Double)).$h}],"g":["TSource"],"n":"Average","o":"@$16","d":503028,"h":682900303092,"f":131105},{"r":$.$typeNullable($.$spc.System.Double).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Double))).$h}],"g":["TSource"],"n":"Average","o":"@$17","d":503028,"h":687195270388,"f":131105},{"r":35061761,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Decimal)).$h}],"g":["TSource"],"n":"Average","o":"@$18","d":503028,"h":691490237684,"f":131105},{"r":$.$typeNullable($.$spc.System.Decimal).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"selector","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, $.$spc.System.Nullable$$($.$spc.System.Decimal))).$h}],"g":["TSource"],"n":"Average","o":"@$19","d":503028,"h":695785204980,"f":131105},{"r":(TSource) => TSource.$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"func","p":(TSource) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TSource, TSource, TSource)).$h}],"g":["TSource"],"n":"Aggregate","d":503028,"h":700080172276,"f":131105},{"r":(TSource, TAccumulate) => TAccumulate.$h,"p":[{"n":"source","p":(TSource, TAccumulate) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"seed","p":(TSource, TAccumulate) => TAccumulate.$h},{"n":"func","p":(TSource, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TAccumulate, TSource, TAccumulate)).$h}],"g":["TSource","TAccumulate"],"n":"Aggregate","o":"@$1","d":503028,"h":704375139572,"f":131105},{"r":(TSource, TAccumulate, TResult) => TResult.$h,"p":[{"n":"source","p":(TSource, TAccumulate, TResult) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"seed","p":(TSource, TAccumulate, TResult) => TAccumulate.$h},{"n":"func","p":(TSource, TAccumulate, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TAccumulate, TSource, TAccumulate)).$h},{"n":"selector","p":(TSource, TAccumulate, TResult) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TAccumulate, TResult)).$h}],"g":["TSource","TAccumulate","TResult"],"n":"Aggregate","o":"@$2","d":503028,"h":708670106868,"f":131105},{"r":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.IQueryable$$($.$spc.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate)).$h,"p":[{"n":"source","p":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"seed","p":(TSource, TKey, TAccumulate) => TAccumulate.$h},{"n":"func","p":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TAccumulate, TSource, TAccumulate)).$h},{"n":"keyComparer","p":(TSource, TKey, TAccumulate) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h,"f":65}],"g":["TSource","TKey","TAccumulate"],"n":"AggregateBy","d":503028,"h":712965074164,"f":131105},{"r":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.IQueryable$$($.$spc.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate)).$h,"p":[{"n":"source","p":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"keySelector","p":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TSource, TKey)).$h},{"n":"seedSelector","p":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$(TKey, TAccumulate)).$h},{"n":"func","p":(TSource, TKey, TAccumulate) => $.$sle.System.Linq.Expressions.Expression$$($.$spc.System.Func$$$$(TAccumulate, TSource, TAccumulate)).$h},{"n":"keyComparer","p":(TSource, TKey, TAccumulate) => $.$spc.System.Collections.Generic.IEqualityComparer$$(TKey).$h,"f":65}],"g":["TSource","TKey","TAccumulate"],"n":"AggregateBy","o":"@$1","d":503028,"h":717260041460,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"count","p":655361}],"g":["TSource"],"n":"SkipLast","d":503028,"h":721555008756,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"count","p":655361}],"g":["TSource"],"n":"TakeLast","d":503028,"h":725849976052,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"element","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"Append","d":503028,"h":730144943348,"f":131105},{"r":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h,"p":[{"n":"source","p":(TSource) => $.$sle.System.Linq.IQueryable$$(TSource).$h},{"n":"element","p":(TSource) => TSource.$h}],"g":["TSource"],"n":"Prepend","d":503028,"h":734439910644,"f":131105}],"l":[{"t":1310721,"n":"InMemoryQueryableExtensionMethodsRequiresUnreferencedCode","d":503028,"h":4295470324,"f":40},{"t":1310721,"n":"InMemoryQueryableExtensionMethodsRequiresDynamicCode","d":503028,"h":8590437620,"f":40}],"h":503028}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Linq.Queryable`; }
        });
        
        $asm.$cls("$slq.System.Linq.EnumerableRewriter", ($self) => class EnumerableRewriter extends $.$sle.System.Linq.Expressions.ExpressionVisitor
        {
            /*Dictionary<LabelTarget, LabelTarget>?*/ _targetCache = null;
            /*Dictionary<Type, Type>?*/ _equivalentTypeCache = null;
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*Expression */ VisitMethodCall(/*MethodCallExpression*/ m)
            {
                /*Expression?*/ let obj = this.Visit(m.Object);
                /*ReadOnlyCollection<Expression>*/ let args = this.Visit$1(m.Arguments);
                if (obj !== m.Object || args !== m.Arguments)
                {
                    /*MethodInfo*/ let mInfo = m.Method;
                    /*Type[]?*/ let typeArgs = (mInfo.IsGenericMethod) ? mInfo.GetGenericArguments() : null;
                    if ((mInfo.IsStatic$1 || mInfo.DeclaringType.IsAssignableFrom(obj.Type)) && $.$slq.System.Linq.EnumerableRewriter.ArgsMatch(mInfo, args, typeArgs))
                    {
                        return $.$sle.System.Linq.Expressions.Expression.Call$15(obj, mInfo, args);
                    }
                    else if ($.$spc.System.Type.op_Equality$1(mInfo.DeclaringType, $.$slq.System.Linq.Queryable.$type))
                    {
                        /*MethodInfo*/ let seqMethod = $.$slq.System.Linq.EnumerableRewriter.FindEnumerableMethodForQueryable(mInfo.Name, args, typeArgs);
                        args = $.$slq.System.Linq.EnumerableRewriter.FixupQuotedArgs(seqMethod, args);
                        return $.$sle.System.Linq.Expressions.Expression.Call$15(obj, seqMethod, args);
                    }
                    else 
                    {
                        /*MethodInfo*/ let method = $.$slq.System.Linq.EnumerableRewriter.FindMethod(mInfo.DeclaringType, mInfo.Name, args, typeArgs);
                        args = $.$slq.System.Linq.EnumerableRewriter.FixupQuotedArgs(method, args);
                        return $.$sle.System.Linq.Expressions.Expression.Call$15(obj, method, args);
                    }
                }
                return m;
            }
            static /*ReadOnlyCollection<Expression> */ FixupQuotedArgs(/*MethodInfo*/ mi, /*ReadOnlyCollection<Expression>*/ argList)
            {
                /*ParameterInfo[]*/ let pis = mi.GetParameters();
                if (pis.length > 0)
                {
                    /*List<Expression>?*/ let newArgs = null;
                    for(/*int*/ let i = 0, n = pis.length; i < n; i++)
                    {
                        /*Expression*/ let arg = argList.get_Item(i);
                        /*ParameterInfo*/ let pi = $.$spc.System.Array.$ReadT1.call(pis, i);
                        arg = $.$slq.System.Linq.EnumerableRewriter.FixupQuotedExpression(pi.ParameterType, arg);
                        if (newArgs === null && arg !== argList.get_Item(i))
                        {
                            newArgs = new ($.$spc.System.Collections.Generic.List$$($.$sle.System.Linq.Expressions.Expression))().$ctor$2(argList.Count);
                            for(/*int*/ let j = 0; j < i; j++)
                            {
                                newArgs.Add(argList.get_Item(j));
                            }
                        }
                        newArgs?.Add(arg);
                    }
                    if (newArgs !== null)
                    {
                        argList = newArgs.AsReadOnly();
                    }
                }
                return argList;
            }
            static /*Expression */ FixupQuotedExpression(/*Type*/ type, /*Expression*/ expression)
            {
                /*Expression*/ let expr = expression;
                while(true)
                {
                    if (type.IsAssignableFrom(expr.Type))
                    {
                        return expr;
                    }
                    if (expr.NodeType !== 40/*ExpressionType.Quote*/)
                    {
                        break;
                    }
                    expr = ($.$cast(expr, $.$sle.System.Linq.Expressions.UnaryExpression)).Operand;
                }
                if (!type.IsAssignableFrom(expr.Type) && type.IsArray && expr.NodeType === 32/*ExpressionType.NewArrayInit*/)
                {
                    /*Type*/ let strippedType = $.$slq.System.Linq.EnumerableRewriter.StripExpression(expr.Type);
                    if (type.IsAssignableFrom(strippedType))
                    {
                        /*Type*/ let elementType = type.GetElementType();
                        /*NewArrayExpression*/ let na = $.$cast(expr, $.$sle.System.Linq.Expressions.NewArrayExpression);
                        /*List<Expression>*/ let exprs = new ($.$spc.System.Collections.Generic.List$$($.$sle.System.Linq.Expressions.Expression))().$ctor$2(na.Expressions.Count);
                        for(/*int*/ let i = 0, n = na.Expressions.Count; i < n; i++)
                        {
                            exprs.Add($.$slq.System.Linq.EnumerableRewriter.FixupQuotedExpression(elementType, na.Expressions.get_Item(i)));
                        }
                        expression = $.$sle.System.Linq.Expressions.Expression.NewArrayInit$1(elementType, exprs);
                    }
                }
                return expression;
            }
            /*Expression */ VisitLambda(T, /*Expression<T>*/ node)
            {
                return node;
            }
            static /*Type */ GetPublicType(/*Type*/ t)
            {
                if (t.IsGenericType && $.$sl.System.Linq.Enumerable.Contains($.$spc.System.Type, t.GetGenericTypeDefinition().GetInterfaces(), $.$sl.System.Linq.IGrouping$$$().$type))
                {
                    return $.$sl.System.Linq.IGrouping$$$().$type.MakeGenericType(t.GetGenericArguments());
                }
                if (!t.IsNestedPrivate)
                {
                    return t;
                }
                let $i1 = 0;
                let $arr1 = t.GetInterfaces();
                while ($i1 < $arr1.length)
                {
                    let iType = $arr1[$i1++];
                    if (iType.IsGenericType && $.$spc.System.Type.op_Equality$1(iType.GetGenericTypeDefinition(), $.$spc.System.Collections.Generic.IEnumerable$$().$type))
                    {
                        return iType;
                    }
                }
                if ($.$spc.System.Collections.IEnumerable.$type.IsAssignableFrom(t))
                {
                    return $.$spc.System.Collections.IEnumerable.$type;
                }
                return t;
            }
            /*Type */ GetEquivalentType(/*Type*/ type)
            {
                /*Type?*/ let equiv;
                this._equivalentTypeCache ??= (() =>
                {
                    //new $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Type, $.$spc.System.Type)()
                    const $t1 = $.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Type, $.$spc.System.Type);
                    const $i1 = new $t1();
                    $i1.$ctor$1();
                    $i1.Add($.$sle.System.Linq.IQueryable.$type, $.$spc.System.Collections.IEnumerable.$type);
                    $i1.Add($.$spc.System.Collections.IEnumerable.$type, $.$spc.System.Collections.IEnumerable.$type);
                    return $i1;
                })();
                if (!this._equivalentTypeCache.TryGetValue(type, $.$ref(() => equiv, ($v) => equiv = $v, $.$spc.System.Type)))
                {
                    /*Type*/ let pubType = $.$slq.System.Linq.EnumerableRewriter.GetPublicType(type);
                    if (pubType.IsInterface && pubType.IsGenericType)
                    {
                        /*Type*/ let genericType = pubType.GetGenericTypeDefinition();
                        if ($.$spc.System.Type.op_Equality$1(genericType, $.$sl.System.Linq.IOrderedEnumerable$$().$type))
                        {
                            equiv = pubType;
                        }
                        else if ($.$spc.System.Type.op_Equality$1(genericType, $.$sle.System.Linq.IOrderedQueryable$$().$type))
                        {
                            equiv = $.$sl.System.Linq.IOrderedEnumerable$$().$type.MakeGenericType($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ $.$spc.System.Array.$ReadT1.call(pubType.GenericTypeArguments, 0) ], null, null));
                        }
                        else if ($.$spc.System.Type.op_Equality$1(genericType, $.$spc.System.Collections.Generic.IEnumerable$$().$type))
                        {
                            equiv = pubType;
                        }
                        else if ($.$spc.System.Type.op_Equality$1(genericType, $.$sle.System.Linq.IQueryable$$().$type))
                        {
                            equiv = $.$spc.System.Collections.Generic.IEnumerable$$().$type.MakeGenericType($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ $.$spc.System.Array.$ReadT1.call(pubType.GenericTypeArguments, 0) ], null, null));
                        }
                    }
                    if ($.$spc.System.Type.op_Equality$1(equiv, null))
                    {
                        /*var*/ let interfacesWithInfo = pubType.GetInterfaces();
                        /*var*/ let singleTypeGenInterfacesWithGetType = $.$sl.System.Linq.Enumerable.ToArray($.$spc.System.Object, $.$sl.System.Linq.Enumerable.Select($.$spc.System.Type, $.$spc.System.Object, $.$sl.System.Linq.Enumerable.Where($.$spc.System.Type, interfacesWithInfo, new ($.$spc.System.Func$$$($.$spc.System.Type, $.$spc.System.Boolean))().$ctor(this,  (/*i*/ i) =>
                        {
                            return i.IsGenericType && i.GenericTypeArguments.length === 1;
                        }, {"r":262145,"p":[{"n":"i","p":142606337}],"n":"","d":371956,"h":0,"f":1048578})), new ($.$spc.System.Func$$$($.$spc.System.Type, $.$spc.System.Object))().$ctor(this,  (/*i*/ i) =>
                        {
                            return { Info : i, GenType : i.GetGenericTypeDefinition() };
                        }, {"r":0,"p":[{"n":"i","p":142606337}],"n":"","d":371956,"h":0,"f":1048578})));
                        /*Type?*/ let typeArg = $.$sl.System.Linq.Enumerable.SingleOrDefault($.$spc.System.Type, $.$sl.System.Linq.Enumerable.Distinct($.$spc.System.Type, $.$sl.System.Linq.Enumerable.Select($.$spc.System.Object, $.$spc.System.Type, $.$sl.System.Linq.Enumerable.Where($.$spc.System.Object, singleTypeGenInterfacesWithGetType, new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Boolean))().$ctor(this,  (/*i*/ i) =>
                        {
                            return $.$spc.System.Type.op_Equality$1(i.GenType, $.$sle.System.Linq.IOrderedQueryable$$().$type) || $.$spc.System.Type.op_Equality$1(i.GenType, $.$sl.System.Linq.IOrderedEnumerable$$().$type);
                        }, {"r":262145,"p":[{"n":"i","p":0}],"n":"","d":371956,"h":0,"f":1048578})), new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Type))().$ctor(this,  (/*i*/ i) =>
                        {
                            return $.$spc.System.Array.$ReadT1.call(i.Info.GenericTypeArguments, 0);
                        }, {"r":142606337,"p":[{"n":"i","p":0}],"n":"","d":371956,"h":0,"f":1048578}))));
                        if ($.$spc.System.Type.op_Inequality$1(typeArg, null))
                        {
                            equiv = $.$sl.System.Linq.IOrderedEnumerable$$().$type.MakeGenericType($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ typeArg ], null, null));
                        }
                        else 
                        {
                            typeArg = $.$sl.System.Linq.Enumerable.Single($.$spc.System.Type, $.$sl.System.Linq.Enumerable.Distinct($.$spc.System.Type, $.$sl.System.Linq.Enumerable.Select($.$spc.System.Object, $.$spc.System.Type, $.$sl.System.Linq.Enumerable.Where($.$spc.System.Object, singleTypeGenInterfacesWithGetType, new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Boolean))().$ctor(this,  (/*i*/ i) =>
                            {
                                return $.$spc.System.Type.op_Equality$1(i.GenType, $.$sle.System.Linq.IQueryable$$().$type) || $.$spc.System.Type.op_Equality$1(i.GenType, $.$spc.System.Collections.Generic.IEnumerable$$().$type);
                            }, {"r":262145,"p":[{"n":"i","p":0}],"n":"","d":371956,"h":0,"f":1048578})), new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Type))().$ctor(this,  (/*i*/ i) =>
                            {
                                return $.$spc.System.Array.$ReadT1.call(i.Info.GenericTypeArguments, 0);
                            }, {"r":142606337,"p":[{"n":"i","p":0}],"n":"","d":371956,"h":0,"f":1048578}))));
                            equiv = $.$spc.System.Collections.Generic.IEnumerable$$().$type.MakeGenericType($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Type), [ typeArg ], null, null));
                        }
                    }
                    this._equivalentTypeCache.Add(type, equiv);
                }
                return equiv;
            }
            /*Expression */ VisitConstant(/*ConstantExpression*/ c)
            {
                let sq;
                if ($.$is(c.Value, $.$slq.System.Linq.EnumerableQuery, { set $v(v){ sq = v; } }))
                {
                    if (sq.Enumerable !== null)
                    {
                        /*Type*/ let t = $.$slq.System.Linq.EnumerableRewriter.GetPublicType($.$spc.System.Object.GetType.call(sq.Enumerable));
                        return $.$sle.System.Linq.Expressions.Expression.Constant$1(sq.Enumerable, t);
                    }
                    /*Expression*/ let exp = sq.Expression;
                    if (exp !== c)
                    {
                        return this.Visit(exp);
                    }
                }
                return c;
            }
            /*ILookup<string, MethodInfo>?*/ static s_seqMethods = null;
            static /*MethodInfo */ FindEnumerableMethodForQueryable(/*string*/ name, /*ReadOnlyCollection<Expression>*/ args, /*params Type[]?*/ typeArgs)
            {
                $.$slq.System.Linq.EnumerableRewriter.s_seqMethods ??= $.$sl.System.Linq.Enumerable.ToLookup($.$spc.System.Reflection.MethodInfo, $.$spc.System.String, GetEnumerableStaticMethods($.$sl.System.Linq.Enumerable.$type), new ($.$spc.System.Func$$$($.$spc.System.Reflection.MethodInfo, $.$spc.System.String))().$ctor(this,  (/*m*/ m) =>
                {
                    return m.Name;
                }, {"r":1310721,"p":[{"n":"m","p":79626241}],"n":"","d":371956,"h":0,"f":1048578}));
                /*MethodInfo[]*/ let matchingMethods = $.$sl.System.Linq.Enumerable.ToArray($.$spc.System.Reflection.MethodInfo, $.$sl.System.Linq.Enumerable.Select($.$spc.System.Reflection.MethodInfo, $.$spc.System.Reflection.MethodInfo, $.$sl.System.Linq.Enumerable.Where($.$spc.System.Reflection.MethodInfo, $.$slq.System.Linq.EnumerableRewriter.s_seqMethods.System$Linq$ILookup$$$$get_Item(name, [$.$spc.System.String, $.$spc.System.Reflection.MethodInfo]), new ($.$spc.System.Func$$$($.$spc.System.Reflection.MethodInfo, $.$spc.System.Boolean))().$ctor(this,  (/*m*/ m) =>
                {
                    return $.$slq.System.Linq.EnumerableRewriter.ArgsMatch(m, args, typeArgs);
                }, {"r":262145,"p":[{"n":"m","p":79626241}],"n":"","d":371956,"h":0,"f":1048578})), new ($.$spc.System.Func$$$($.$spc.System.Reflection.MethodInfo, $.$spc.System.Reflection.MethodInfo))().$ctor(this, ApplyTypeArgs)));
                $.$spc.System.Diagnostics.Debug.Assert$1(matchingMethods.length > 0, "All static methods with arguments on Queryable have equivalents on Enumerable.");
                if (matchingMethods.length > 1)
                {
                    return DisambiguateMatches(matchingMethods);
                }
                return $.$spc.System.Array.$ReadT1.call(matchingMethods, 0);
                /*static MethodInfo[]*/  function GetEnumerableStaticMethods(/*Type*/ type)
                {
                    return type.GetMethods$1(16/*BindingFlags.Public*/ | 8/*BindingFlags.Static*/);
                }
                /*MethodInfo*/  function ApplyTypeArgs(/*MethodInfo*/ methodInfo)
                {
                    return typeArgs === null ? methodInfo : methodInfo.MakeGenericMethod(typeArgs);
                }
                /*static MethodInfo*/  function DisambiguateMatches(/*MethodInfo[]*/ matchingMethods)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(matchingMethods.length > 1, "matchingMethods.Length > 1");
                    /*ParameterInfo[][]*/ let parameters = $.$sl.System.Linq.Enumerable.ToArray($.$typeArray($.$spc.System.Reflection.ParameterInfo), $.$sl.System.Linq.Enumerable.Select($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Reflection.ParameterInfo), matchingMethods, new ($.$spc.System.Func$$$($.$spc.System.Reflection.MethodInfo, $.$typeArray($.$spc.System.Reflection.ParameterInfo)))().$ctor(this,  (/*m*/ m) =>
                    {
                        return m.GetParameters();
                    }, {"r":0,"p":[{"n":"m","p":79626241}],"n":"","d":371956,"h":0,"f":1048578})));
                    for(/*int*/ let i = 0; i < matchingMethods.length; i++)
                    {
                        /*bool*/ let isMaximal = true;
                        for(/*int*/ let j = 0; j < matchingMethods.length; j++)
                        {
                            if (i !== j && AreAssignableFromStrict($.$spc.System.Array.$ReadT1.call(parameters, i), $.$spc.System.Array.$ReadT1.call(parameters, j)))
                            {
                                isMaximal = false;
                                break;
                            }
                        }
                        if (isMaximal)
                        {
                            return $.$spc.System.Array.$ReadT1.call(matchingMethods, i);
                        }
                    }
                    $.$spc.System.Diagnostics.Debug.Fail("Search should have found a maximal element");
                    throw new $.$spc.System.Exception().$ctor$1();
                    /*static bool*/  function AreAssignableFromStrict(/*ParameterInfo[]*/ left, /*ParameterInfo[]*/ right)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(left.length === right.length, "left.Length == right.Length");
                        /*bool*/ let areEqual = true;
                        /*bool*/ let areAssignableFrom = true;
                        for(/*int*/ let i = 0; i < left.length; i++)
                        {
                            /*Type*/ let leftParam = $.$spc.System.Array.$ReadT1.call(left, i).ParameterType;
                            /*Type*/ let rightParam = $.$spc.System.Array.$ReadT1.call(right, i).ParameterType;
                            areEqual = areEqual && $.$spc.System.Type.op_Equality$1(leftParam, rightParam);
                            areAssignableFrom = areAssignableFrom && leftParam.IsAssignableFrom(rightParam);
                        }
                        return !areEqual && areAssignableFrom;
                    }
                }
            }
            static /*MethodInfo */ FindMethod(/*Type*/ type, /*string*/ name, /*ReadOnlyCollection<Expression>*/ args, /*Type[]?*/ typeArgs)
            {
                let en = null;
                try
                {
                    en = $.$sl.System.Linq.Enumerable.Where($.$spc.System.Reflection.MethodInfo, type.GetMethods$1(16/*BindingFlags.Public*/ | 32/*BindingFlags.NonPublic*/ | 8/*BindingFlags.Static*/), new ($.$spc.System.Func$$$($.$spc.System.Reflection.MethodInfo, $.$spc.System.Boolean))().$ctor(this,  (/*m*/ m) =>
                    {
                        return $.$spc.System.String.op_Equality(m.Name, name);
                    }, {"r":262145,"p":[{"n":"m","p":79626241}],"n":"","d":371956,"h":0,"f":1048578})).System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$spc.System.Reflection.MethodInfo]);
                    if (!en.System$Collections$IEnumerator$MoveNext())
                    {
                        throw $.$slq.System.Linq.Error.NoMethodOnType(name, type);
                    }
                    do
                    {
                        /*MethodInfo*/ let mi = en.System$Collections$Generic$IEnumerator$$$Current;
                        if ($.$slq.System.Linq.EnumerableRewriter.ArgsMatch(mi, args, typeArgs))
                        {
                            return (typeArgs !== null) ? mi.MakeGenericMethod(typeArgs) : mi;
                        }
                    }
                    while(en.System$Collections$IEnumerator$MoveNext());
                }
                finally
                {
                    en?.System$IDisposable$Dispose();
                }
                throw $.$slq.System.Linq.Error.NoMethodOnTypeMatchingArguments(name, type);
            }
            static /*bool */ ArgsMatch(/*MethodInfo*/ m, /*ReadOnlyCollection<Expression>*/ args, /*Type[]?*/ typeArgs)
            {
                /*ParameterInfo[]*/ let mParams = m.GetParameters();
                if (mParams.length !== args.Count)
                {
                    return false;
                }
                if (!m.IsGenericMethod && typeArgs !== null && typeArgs.length > 0)
                {
                    return false;
                }
                if (!m.IsGenericMethodDefinition && m.IsGenericMethod && m.ContainsGenericParameters$1)
                {
                    m = m.GetGenericMethodDefinition();
                }
                if (m.IsGenericMethodDefinition)
                {
                    if (typeArgs === null || typeArgs.length === 0)
                    {
                        return false;
                    }
                    if (m.GetGenericArguments().length !== typeArgs.length)
                    {
                        return false;
                    }
                    mParams = GetConstrutedGenericParameters(m, typeArgs);
                    /*static ParameterInfo[]*/  function GetConstrutedGenericParameters(/*MethodInfo*/ method, /*Type[]*/ genericTypes)
                    {
                        return method.MakeGenericMethod(genericTypes).GetParameters();
                    }
                }
                for(/*int*/ let i = 0, n = args.Count; i < n; i++)
                {
                    /*Type*/ let parameterType = $.$spc.System.Array.$ReadT1.call(mParams, i).ParameterType;
                    if ($.$spc.System.Type.op_Equality$1(parameterType, null))
                    {
                        return false;
                    }
                    if (parameterType.IsByRef)
                    {
                        parameterType = parameterType.GetElementType();
                    }
                    /*Expression*/ let arg = args.get_Item(i);
                    if (!parameterType.IsAssignableFrom(arg.Type))
                    {
                        if (arg.NodeType === 40/*ExpressionType.Quote*/)
                        {
                            arg = ($.$cast(arg, $.$sle.System.Linq.Expressions.UnaryExpression)).Operand;
                        }
                        if (!parameterType.IsAssignableFrom(arg.Type) && !parameterType.IsAssignableFrom($.$slq.System.Linq.EnumerableRewriter.StripExpression(arg.Type)))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            static /*Type */ StripExpression(/*Type*/ type)
            {
                /*bool*/ let isArray = type.IsArray;
                /*Type*/ let tmp = isArray ? type.GetElementType() : type;
                /*Type?*/ let eType = $.$slq.System.Linq.TypeHelper.FindGenericType($.$sle.System.Linq.Expressions.Expression$$().$type, tmp);
                if ($.$spc.System.Type.op_Inequality$1(eType, null))
                {
                    tmp = $.$spc.System.Array.$ReadT1.call(eType.GetGenericArguments(), 0);
                }
                if (isArray)
                {
                    /*int*/ let rank = type.GetArrayRank();
                    return (rank === 1) ? tmp.MakeArrayType() : tmp.MakeArrayType$1(rank);
                }
                return type;
            }
            /*Expression */ VisitConditional(/*ConditionalExpression*/ c)
            {
                /*Type*/ let type = c.Type;
                if (!$.$sle.System.Linq.IQueryable.$type.IsAssignableFrom(type))
                {
                    return super.VisitConditional(c);
                }
                /*Expression*/ let test = this.Visit(c.Test);
                /*Expression*/ let ifTrue = this.Visit(c.IfTrue);
                /*Expression*/ let ifFalse = this.Visit(c.IfFalse);
                /*Type*/ let trueType = ifTrue.Type;
                /*Type*/ let falseType = ifFalse.Type;
                if (trueType.IsAssignableFrom(falseType))
                {
                    return $.$sle.System.Linq.Expressions.Expression.Condition$1(test, ifTrue, ifFalse, trueType);
                }
                if (falseType.IsAssignableFrom(trueType))
                {
                    return $.$sle.System.Linq.Expressions.Expression.Condition$1(test, ifTrue, ifFalse, falseType);
                }
                return $.$sle.System.Linq.Expressions.Expression.Condition$1(test, ifTrue, ifFalse, this.GetEquivalentType(type));
            }
            /*Expression */ VisitBlock(/*BlockExpression*/ node)
            {
                /*Type*/ let type = node.Type;
                if (!$.$sle.System.Linq.IQueryable.$type.IsAssignableFrom(type))
                {
                    return super.VisitBlock(node);
                }
                /*ReadOnlyCollection<Expression>*/ let nodes = this.Visit$1(node.Expressions);
                /*ReadOnlyCollection<ParameterExpression>*/ let variables = this.VisitAndConvert$1($.$sle.System.Linq.Expressions.ParameterExpression, node.Variables, "EnumerableRewriter.VisitBlock");
                if ($.$spc.System.Type.op_Equality$1(type, $.$sl.System.Linq.Enumerable.Last($.$sle.System.Linq.Expressions.Expression, node.Expressions).Type))
                {
                    return $.$sle.System.Linq.Expressions.Expression.Block$10(variables, nodes);
                }
                return $.$sle.System.Linq.Expressions.Expression.Block$11(this.GetEquivalentType(type), variables, nodes);
            }
            /*Expression */ VisitGoto(/*GotoExpression*/ node)
            {
                /*Type*/ let type = node.Value.Type;
                if (!$.$sle.System.Linq.IQueryable.$type.IsAssignableFrom(type))
                {
                    return super.VisitGoto(node);
                }
                /*LabelTarget*/ let target = this.VisitLabelTarget(node.Target);
                /*Expression*/ let value = this.Visit(node.Value);
                return $.$sle.System.Linq.Expressions.Expression.MakeGoto(node.Kind, target, value, this.GetEquivalentType($.$slq.System.Linq.EnumerableQuery.$type.IsAssignableFrom(type) ? value.Type : type));
            }
            /*LabelTarget */ VisitLabelTarget(/*LabelTarget?*/ node)
            {
                /*LabelTarget?*/ let newTarget;
                if (this._targetCache === null)
                {
                    this._targetCache = new ($.$spc.System.Collections.Generic.Dictionary$$$($.$sle.System.Linq.Expressions.LabelTarget, $.$sle.System.Linq.Expressions.LabelTarget))().$ctor$1();
                }
                else if (this._targetCache.TryGetValue(node, $.$ref(() => newTarget, ($v) => newTarget = $v, $.$sle.System.Linq.Expressions.LabelTarget)))
                {
                    return newTarget;
                }
                /*Type*/ let type = node.Type;
                if (!$.$sle.System.Linq.IQueryable.$type.IsAssignableFrom(type))
                {
                    newTarget = super.VisitLabelTarget(node);
                }
                else 
                {
                    newTarget = $.$sle.System.Linq.Expressions.Expression.Label$5(this.GetEquivalentType(type), node.Name);
                }
                this._targetCache.Add(node, newTarget);
                return newTarget;
            }
            static $h = 371956;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":11242956,"m":[{"r":8687052,"p":[{"n":"m","p":39292364}],"n":"VisitMethodCall","d":371956,"h":17180241140,"f":32772},{"r":$.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sle.System.Linq.Expressions.Expression).$h,"p":[{"n":"mi","p":79626241},{"n":"argList","p":$.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sle.System.Linq.Expressions.Expression).$h}],"n":"FixupQuotedArgs","d":371956,"h":21475208436,"f":34},{"r":8687052,"p":[{"n":"type","p":142606337},{"n":"expression","p":8687052}],"n":"FixupQuotedExpression","d":371956,"h":25770175732,"f":34},{"r":8687052,"p":[{"n":"node","p":(T) => $.$sle.System.Linq.Expressions.Expression$$(T).$h}],"g":["T"],"n":"VisitLambda","d":371956,"h":30065143028,"f":163844},{"r":142606337,"p":[{"n":"t","p":142606337}],"n":"GetPublicType","d":371956,"h":34360110324,"f":34},{"r":142606337,"p":[{"n":"type","p":142606337}],"n":"GetEquivalentType","d":371956,"h":38655077620,"f":2},{"r":8687052,"p":[{"n":"c","p":7769548}],"n":"VisitConstant","d":371956,"h":42950044916,"f":32772},{"r":79626241,"p":[{"n":"name","p":1310721},{"n":"args","p":$.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sle.System.Linq.Expressions.Expression).$h},{"n":"typeArgs","p":0,"f":16}],"n":"FindEnumerableMethodForQueryable","d":371956,"h":51539979508,"f":34},{"r":79626241,"p":[{"n":"type","p":142606337},{"n":"name","p":1310721},{"n":"args","p":$.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sle.System.Linq.Expressions.Expression).$h},{"n":"typeArgs","p":0}],"n":"FindMethod","d":371956,"h":55834946804,"f":34},{"r":262145,"p":[{"n":"m","p":79626241},{"n":"args","p":$.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sle.System.Linq.Expressions.Expression).$h},{"n":"typeArgs","p":0}],"n":"ArgsMatch","d":371956,"h":60129914100,"f":34},{"r":142606337,"p":[{"n":"type","p":142606337}],"n":"StripExpression","d":371956,"h":64424881396,"f":34},{"r":8687052,"p":[{"n":"c","p":7638476}],"n":"VisitConditional","d":371956,"h":68719848692,"f":32772},{"r":8687052,"p":[{"n":"node","p":3902924}],"n":"VisitBlock","d":371956,"h":73014815988,"f":32772},{"r":8687052,"p":[{"n":"node","p":11570636}],"n":"VisitGoto","d":371956,"h":77309783284,"f":32772},{"r":38440396,"p":[{"n":"node","p":38440396}],"n":"VisitLabelTarget","d":371956,"h":81604750580,"f":32772}],"l":[{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$sle.System.Linq.Expressions.LabelTarget, $.$sle.System.Linq.Expressions.LabelTarget).$h,"n":"_targetCache","d":371956,"h":4295339252,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$spc.System.Type, $.$spc.System.Type).$h,"n":"_equivalentTypeCache","d":371956,"h":8590306548,"f":2},{"t":$.$sl.System.Linq.ILookup$$$($.$spc.System.String, $.$spc.System.Reflection.MethodInfo).$h,"n":"s_seqMethods","d":371956,"h":47245012212,"f":34}],"c":[{"n":".ctor","o":"$ctor$2","d":371956,"h":12885273844,"f":1}],"h":371956}; }
            static get $b() { return $.$sle.System.Linq.Expressions.ExpressionVisitor; }
            static get $fullName() { return `System.Linq.EnumerableRewriter`; }
        });
        
        $asm.$cls("$slq.System.Linq.EnumerableExecutor<>", (T) => $asm.$gt("$slq.System.Linq.EnumerableExecutor<>", [T], ($self) => class EnumerableExecutor$$ extends $.$slq.System.Linq.EnumerableExecutor
        {
            /*Expression*/ _expression = null;
            $ctor$2(/*Expression*/ expression)
            {
                super.$ctor$1();
                {
                    this._expression = expression;
                }
                return this;
            }
            /*object? */ ExecuteBoxed()
            {
                return $.$box(this.Execute(), T);
            }
            /*T */ Execute()
            {
                /*EnumerableRewriter*/ let rewriter = new $.$slq.System.Linq.EnumerableRewriter().$ctor$2();
                /*Expression*/ let body = rewriter.Visit(this._expression);
                /*Expression<Func<T>>*/ let f = $.$sle.System.Linq.Expressions.Expression.Lambda$2($.$spc.System.Func$$(T), body, null);
                /*Func<T>*/ let func = f.Compile$3();
                return func.Invoke();
            }
            static $h = 175348;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":109812,"m":[{"r":131073,"n":"ExecuteBoxed","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":32776},{"r":T?.$h??1507328,"n":"Execute","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":8}],"l":[{"t":8687052,"n":"_expression","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2}],"c":[{"p":[{"n":"expression","p":8687052}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$slq.System.Linq.EnumerableExecutor; }
            static get $fullName() { return `System.Linq.EnumerableExecutor<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$slq.System.Linq.EnumerableQuery<>", (T) => $asm.$gt("$slq.System.Linq.EnumerableQuery<>", [T], ($self) => class EnumerableQuery$$ extends $.$slq.System.Linq.EnumerableQuery
        {
            /*Expression*/ _expression = null;
            /*IEnumerable<T>?*/ _enumerable = null;
            /*IQueryProvider */ get System$Linq$IQueryable$Provider()
            {
                return this;
            }
            $ctor$2(/*IEnumerable<T>*/ enumerable)
            {
                super.$ctor$1();
                {
                    this._enumerable = enumerable;
                    this._expression = $.$sle.System.Linq.Expressions.Expression.Constant(this);
                }
                return this;
            }
            $ctor$3(/*Expression*/ expression)
            {
                super.$ctor$1();
                {
                    this._expression = expression;
                }
                return this;
            }
            /*Expression */ get Expression()
            {
                return this._expression;
            }
            /*IEnumerable? */ get Enumerable()
            {
                return this._enumerable;
            }
            /*Expression */ get System$Linq$IQueryable$Expression()
            {
                return this._expression;
            }
            /*Type */ get System$Linq$IQueryable$ElementType()
            {
                return T.$type;
            }
            /*IQueryable */ System$Linq$IQueryProvider$CreateQuery(/*Expression*/ expression)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(expression, "expression");
                /*Type?*/ let iqType = $.$slq.System.Linq.TypeHelper.FindGenericType($.$sle.System.Linq.IQueryable$$().$type, expression.Type);
                if ($.$spc.System.Type.op_Equality$1(iqType, null))
                {
                    throw $.$slq.System.Linq.Error.ArgumentNotValid("expression");
                }
                return $.$slq.System.Linq.EnumerableQuery.Create$1($.$spc.System.Array.$ReadT1.call(iqType.GetGenericArguments(), 0), expression);
            }
            /*IQueryable<TElement> */ System$Linq$IQueryProvider$CreateQuery$1(TElement, /*Expression*/ expression)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(expression, "expression");
                if (!$.$sle.System.Linq.IQueryable$$(TElement).$type.IsAssignableFrom(expression.Type))
                {
                    throw $.$slq.System.Linq.Error.ArgumentNotValid("expression");
                }
                return new ($.$slq.System.Linq.EnumerableQuery$$(TElement))().$ctor$3(expression);
            }
            /*object? */ System$Linq$IQueryProvider$Execute(/*Expression*/ expression)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(expression, "expression");
                return $.$slq.System.Linq.EnumerableExecutor.Create(expression).ExecuteBoxed();
            }
            /*TElement */ System$Linq$IQueryProvider$Execute$1(TElement, /*Expression*/ expression)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(expression, "expression");
                if (!TElement.$type.IsAssignableFrom(expression.Type))
                {
                    throw $.$slq.System.Linq.Error.ArgumentNotValid("expression");
                }
                return new ($.$slq.System.Linq.EnumerableExecutor$$(TElement))().$ctor$2(expression).Execute();
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            /*IEnumerator<T> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            /*IEnumerator<T> */ GetEnumerator()
            {
                if (this._enumerable === null)
                {
                    /*EnumerableRewriter*/ let rewriter = new $.$slq.System.Linq.EnumerableRewriter().$ctor$2();
                    /*Expression*/ let body = rewriter.Visit(this._expression);
                    /*Expression<Func<IEnumerable<T>>>*/ let f = $.$sle.System.Linq.Expressions.Expression.Lambda$2($.$spc.System.Func$$($.$spc.System.Collections.Generic.IEnumerable$$(T)), body, null);
                    /*IEnumerable<T>*/ let enumerable = f.Compile$3().Invoke();
                    if (enumerable === this)
                    {
                        throw $.$slq.System.Linq.Error.EnumeratingNullEnumerableExpression();
                    }
                    this._enumerable = enumerable;
                }
                return this._enumerable.System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
            }
            static/*conventional*/ /*string? */ ToString()
            {
                let c;
                if ($.$is(this._expression, $.$sle.System.Linq.Expressions.ConstantExpression, { set $v(v){ c = v; } }) && c.Value === this)
                {
                    if (this._enumerable !== null)
                    {
                        return $.$spc.System.Object.ToString.call(this._enumerable);
                    }
                    return "null";
                }
                return $.$sle.System.Linq.Expressions.Expression.ToString.call(this._expression);
            }
            //Static convention instance redirect
            /*string? */ ToString() { return $.$slq.System.Linq.EnumerableQuery$$(T).ToString.apply(this, arguments); }
            static $h = 306420;
            static $g = 1;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":240884,"p":[{"p":42241484,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":2},"n":"{42110412}.Provider","o":"System$Linq$IQueryable$Provider","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2},{"p":8687052,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":32776},"n":"Expression","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":32776},{"p":31653889,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":32776},"n":"Enumerable","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":32776},{"p":8687052,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":2},"n":"{42110412}.Expression","o":"System$Linq$IQueryable$Expression","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2},{"p":142606337,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":2},"n":"{42110412}.ElementType","o":"System$Linq$IQueryable$ElementType","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2}],"m":[{"r":$.$spc.System.Collections.Generic.IEnumerator$$(T).$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":2},{"r":1310721,"n":"ToString","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":32769}],"l":[{"t":8687052,"n":"_expression","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2},{"t":$.$spc.System.Collections.Generic.IEnumerable$$(T).$h,"n":"_enumerable","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2}],"c":[{"p":[{"n":"enumerable","p":$.$spc.System.Collections.Generic.IEnumerable$$(T).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":1},{"p":[{"n":"expression","p":8687052}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":1}],"i":[$.$sle.System.Linq.IOrderedQueryable$$(T).$h,$.$sle.System.Linq.IQueryable$$(T).$h,$.$spc.System.Collections.Generic.IEnumerable$$(T).$h,41979340,42110412,31653889,42241484],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$slq.System.Linq.EnumerableQuery; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sle.System.Linq.IOrderedQueryable$$(T), $.$sle.System.Linq.IQueryable$$(T), $.$spc.System.Collections.Generic.IEnumerable$$(T), $.$sle.System.Linq.IOrderedQueryable, $.$sle.System.Linq.IQueryable, $.$spc.System.Collections.IEnumerable, $.$sle.System.Linq.IQueryProvider ]; }
            static get $fullName() { return `System.Linq.EnumerableQuery<${T?.$fullName}>`; }
        }));
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.IO.Compression", "NetJs.System.Threading.Thread", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.ObjectModel", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Reflection.Metadata", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Linq.Expressions"))