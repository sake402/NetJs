
(function ($global, $, $spc, $sc, $sdt, $sm, $snv, $spu, $sri, $st, $sr, $scc, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Linq", 
    {"h":7,"f":"System.Linq","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Linq","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Linq","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$typeProxy("$sl.System.Linq.IGrouping<,>");
        $asm.$cls("$sl.System.Linq.ILookup<,>", (TKey, TElement) => $asm.$gt("$sl.System.Linq.ILookup<,>", [TKey, TElement], ($self) => class ILookup$$$
        {
            static $h = 4128775;
            static $g = 2;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"r":2,"h":this.$h}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Linq.ILookup<${TKey?.$fullName},${TElement?.$fullName}>`; }
        }));
        
        $asm.$cls("$sl.System.Linq.IGrouping<,>", (/*out*/ TKey, /*out*/ TElement) => $asm.$gt("$sl.System.Linq.IGrouping<,>", [/*out*/ TKey, /*out*/ TElement], ($self) => class IGrouping$$$
        {
            static $h = 4063239;
            static $g = 2;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"r":2,"h":this.$h}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TElement), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Linq.IGrouping<${TKey?.$fullName},${TElement?.$fullName}>`; }
        }));
        
        $asm.$cls("$sl.System.Linq.IOrderedEnumerable<>", (/*out*/ TElement) => $asm.$gt("$sl.System.Linq.IOrderedEnumerable<>", [/*out*/ TElement], ($self) => class IOrderedEnumerable$$
        {
            static $h = 4194311;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"r":1,"h":this.$h}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TElement), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Linq.IOrderedEnumerable<${TElement?.$fullName}>`; }
        }));
        
        $asm.$cls("$sl.System.Linq.Enumerable", ($self) => class Enumerable
        {
            static /*TSource */ Aggregate(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TSource, TSource>*/ func)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (func === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(5/*ExceptionArgument.func*/);
                }
                /*TSource*/ let result;
                /*ReadOnlySpan<TSource>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan(TSource, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(TSource))))
                {
                    if (span.IsEmpty)
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    result = span.get_Item(0).$v;
                    for(/*int*/ let i = 1; i < span.Length; i++)
                    {
                        result = func.Invoke(result, span.get_Item(i).$v);
                    }
                }
                else 
                {
                    /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    try
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                        }
                        result = e.System$Collections$Generic$IEnumerator$$$Current;
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            result = func.Invoke(result, e.System$Collections$Generic$IEnumerator$$$Current);
                        }
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }
                return result;
            }
            static /*TAccumulate */ Aggregate$1(TSource, TAccumulate, /*this IEnumerable<TSource>*/ source, /*TAccumulate*/ seed, /*Func<TAccumulate, TSource, TAccumulate>*/ func)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (func === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(5/*ExceptionArgument.func*/);
                }
                /*TAccumulate*/ let result = seed;
                /*ReadOnlySpan<TSource>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan(TSource, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(TSource))))
                {
                    var $en3 = span.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var element = $en3.Current.$v;
                        {
                            result = func.Invoke(result, element);
                        }
                    }
                }
                else 
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            result = func.Invoke(result, element);
                        }
                    }
                }
                return result;
            }
            static /*TResult */ Aggregate$2(TSource, TAccumulate, TResult, /*this IEnumerable<TSource>*/ source, /*TAccumulate*/ seed, /*Func<TAccumulate, TSource, TAccumulate>*/ func, /*Func<TAccumulate, TResult>*/ resultSelector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (func === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(5/*ExceptionArgument.func*/);
                }
                if (resultSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(13/*ExceptionArgument.resultSelector*/);
                }
                /*TAccumulate*/ let result = seed;
                /*ReadOnlySpan<TSource>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan(TSource, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(TSource))))
                {
                    var $en3 = span.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var element = $en3.Current.$v;
                        {
                            result = func.Invoke(result, element);
                        }
                    }
                }
                else 
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            result = func.Invoke(result, element);
                        }
                    }
                }
                return resultSelector.Invoke(result);
            }
            static /*bool */ Any(TSource, /*this IEnumerable<TSource>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                let gc;
                if ($.$is(source, $.$spc.System.Collections.Generic.ICollection$$(TSource), { set $v(v){ gc = v; } }))
                {
                    return gc.System$Collections$Generic$ICollection$$$Count !== 0;
                }
                let iterator;
                if (!$.$sl.System.Linq.Enumerable.IsSizeOptimized && $.$is(source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }))
                {
                    /*int*/ let count = iterator.GetCount(true);
                    if (count >= 0)
                    {
                        return count !== 0;
                    }
                    /*bool*/ let found;
                    iterator.TryGetFirst($.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                    return found;
                }
                let ngc;
                if ($.$is(source, $.$spc.System.Collections.ICollection, { set $v(v){ ngc = v; } }))
                {
                    return ngc.System$Collections$ICollection$Count !== 0;
                }
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    return e.System$Collections$IEnumerator$MoveNext();
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*bool */ Any$1(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (predicate === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.predicate*/);
                }
                /*ReadOnlySpan<TSource>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan(TSource, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(TSource))))
                {
                    var $en3 = span.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var element = $en3.Current.$v;
                        {
                            if (predicate.Invoke(element))
                            {
                                return true;
                            }
                        }
                    }
                }
                else 
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (predicate.Invoke(element))
                            {
                                return true;
                            }
                        }
                    }
                }
                return false;
            }
            static /*bool */ All(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (predicate === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.predicate*/);
                }
                /*ReadOnlySpan<TSource>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan(TSource, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(TSource))))
                {
                    var $en3 = span.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var element = $en3.Current.$v;
                        {
                            if (!predicate.Invoke(element))
                            {
                                return false;
                            }
                        }
                    }
                }
                else 
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!predicate.Invoke(element))
                            {
                                return false;
                            }
                        }
                    }
                }
                return true;
            }
            static /*IEnumerable<TSource> */ Append(TSource, /*this IEnumerable<TSource>*/ source, /*TSource*/ element)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                let appendable;
                return $.$is(source, $.$sl.System.Linq.Enumerable.AppendPrependIterator$$(TSource), { set $v(v){ appendable = v; } }) ? appendable.Append(element) : new ($.$sl.System.Linq.Enumerable.AppendPrepend1Iterator$$(TSource))().$ctor$3(source, element, true);
            }
            static /*IEnumerable<TSource> */ Prepend(TSource, /*this IEnumerable<TSource>*/ source, /*TSource*/ element)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                let appendable;
                return $.$is(source, $.$sl.System.Linq.Enumerable.AppendPrependIterator$$(TSource), { set $v(v){ appendable = v; } }) ? appendable.Prepend(element) : new ($.$sl.System.Linq.Enumerable.AppendPrepend1Iterator$$(TSource))().$ctor$3(source, element, false);
            }
            static $_AppendPrependIterator$$;
            static AppendPrependIterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_AppendPrependIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.AppendPrependIterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.AppendPrependIterator<>", [TSource], ($self) => class AppendPrependIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TSource)
                {
                    /*IEnumerable<TSource>*/ _source = null;
                    /*IEnumerator<TSource>?*/ _enumerator = null;
                    $ctor$2(/*IEnumerable<TSource>*/ source)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            this._source = source;
                        }
                        return this;
                    }
                    /*void */ GetSourceEnumerator()
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._enumerator === null, "_enumerator is null");
                        this._enumerator = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    }
                    /*bool */ LoadFromEnumerator()
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(this._enumerator === null), "_enumerator is not null");
                        if (this._enumerator.System$Collections$IEnumerator$MoveNext())
                        {
                            this._current = this._enumerator.System$Collections$Generic$IEnumerator$$$Current;
                            return true;
                        }
                        this.Dispose();
                        return false;
                    }
                    /*void */ Dispose()
                    {
                        if (!(this._enumerator === null))
                        {
                            this._enumerator.System$IDisposable$Dispose();
                            this._enumerator = null;
                        }
                        super.Dispose();
                    }
                    static $h = 524295;
                    static $g = 1;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.AppendPrependIterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_AppendPrependIterator$$ = $v))(TSource);
            }
            static $_AppendPrepend1Iterator$$;
            static AppendPrepend1Iterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_AppendPrepend1Iterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.AppendPrepend1Iterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.AppendPrepend1Iterator<>", [TSource], ($self) => class AppendPrepend1Iterator$$ extends $.$sl.System.Linq.Enumerable.AppendPrependIterator$$(TSource)
                {
                    /*TSource*/ _item = $.$default(TSource);
                    /*bool*/ _appending = false;
                    $ctor$3(/*IEnumerable<TSource>*/ source, /*TSource*/ item, /*bool*/ appending)
                    {
                        super.$ctor$2(source);
                        {
                            this._item = item;
                            this._appending = appending;
                        }
                        return this;
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.AppendPrepend1Iterator$$(TSource))().$ctor$3(this._source, this._item, this._appending);
                    }
                    /*bool */ MoveNext()
                    {
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                this._state = 2;
                                if (!this._appending)
                                {
                                    this._current = this._item;
                                    return true;
                                }
                                $switchJumpState1 = 2; /*goto case 2*/
                                continue $switchJumpStart1;
                                case 2:
                                this.GetSourceEnumerator();
                                this._state = 3;
                                $switchJumpState1 = 3; /*goto case 3*/
                                continue $switchJumpStart1;
                                case 3:
                                if (this.LoadFromEnumerator())
                                {
                                    return true;
                                }
                                if (this._appending)
                                {
                                    this._current = this._item;
                                    return true;
                                }
                                break;
                            }
                            break;
                        }
                        this.Dispose();
                        return false;
                    }
                    /*AppendPrependIterator<TSource> */ Append(/*TSource*/ item)
                    {
                        if (this._appending)
                        {
                            return new ($.$sl.System.Linq.Enumerable.AppendPrependN$$(TSource))().$ctor$3(this._source, null, new ($.$sl.System.Linq.SingleLinkedNode$$(TSource))().$ctor$1(this._item).Add(item), 0, 2);
                        }
                        else 
                        {
                            return new ($.$sl.System.Linq.Enumerable.AppendPrependN$$(TSource))().$ctor$3(this._source, new ($.$sl.System.Linq.SingleLinkedNode$$(TSource))().$ctor$1(this._item), new ($.$sl.System.Linq.SingleLinkedNode$$(TSource))().$ctor$1(item), 1, 1);
                        }
                    }
                    /*AppendPrependIterator<TSource> */ Prepend(/*TSource*/ item)
                    {
                        if (this._appending)
                        {
                            return new ($.$sl.System.Linq.Enumerable.AppendPrependN$$(TSource))().$ctor$3(this._source, new ($.$sl.System.Linq.SingleLinkedNode$$(TSource))().$ctor$1(item), new ($.$sl.System.Linq.SingleLinkedNode$$(TSource))().$ctor$1(this._item), 1, 1);
                        }
                        else 
                        {
                            return new ($.$sl.System.Linq.Enumerable.AppendPrependN$$(TSource))().$ctor$3(this._source, new ($.$sl.System.Linq.SingleLinkedNode$$(TSource))().$ctor$1(this._item).Add(item), null, 2, 0);
                        }
                    }
                    /*TSource[] */ LazyToArray()
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this.GetCount(true) === -1, "GetCount(onlyIfCheap: true) == -1");
                        /*TSource[]*/ let result;
                        let c;
                        if ($.$is(this._source, $.$spc.System.Collections.Generic.ICollection$$(TSource), { set $v(v){ c = v; } }))
                        {
                            result = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TSource), null, [((c.System$Collections$Generic$ICollection$$$Count + 1) | 0)], null);
                            if (this._appending)
                            {
                                c.System$Collections$Generic$ICollection$$$CopyTo(result, 0, [TSource]);
                                $.$spc.System.Array.$WriteT1.call(result, this._item, result.length - 1);
                            }
                            else 
                            {
                                c.System$Collections$Generic$ICollection$$$CopyTo(result, 1, [TSource]);
                                $.$spc.System.Array.$WriteT1.call(result, this._item, 0);
                            }
                        }
                        else 
                        {
                            /*SegmentedArrayBuilder<TSource>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource).ScratchBuffer)();
                            /*SegmentedArrayBuilder<TSource>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource))().$ctor$2($.$spc.System.Span$$(TSource).op_Implicit(scratch.$fields));
                            if (this._appending)
                            {
                                builder.AddNonICollectionRange(this._source);
                                builder.Add(this._item);
                            }
                            else 
                            {
                                builder.Add(this._item);
                                builder.AddNonICollectionRange(this._source);
                            }
                            result = builder.ToArray();
                            builder.Dispose();
                        }
                        return result;
                    }
                    /*TSource[] */ ToArray()
                    {
                        /*int*/ let count = this.GetCount(true);
                        if (count === -1)
                        {
                            return this.LazyToArray();
                        }
                        /*TSource[]*/ let array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TSource), null, [count], null);
                        /*int*/ let index;
                        if (this._appending)
                        {
                            index = 0;
                        }
                        else 
                        {
                            $.$spc.System.Array.$WriteT1.call(array, this._item, 0);
                            index = 1;
                        }
                        let collection;
                        if ($.$is(this._source, $.$spc.System.Collections.Generic.ICollection$$(TSource), { set $v(v){ collection = v; } }))
                        {
                            collection.System$Collections$Generic$ICollection$$$CopyTo(array, index, [TSource]);
                        }
                        else 
                        {
                            var $en5 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var item = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    $.$spc.System.Array.$WriteT1.call(array, item, index++);
                                }
                            }
                        }
                        if (this._appending)
                        {
                            $.$spc.System.Array.$WriteT1.call(array, this._item, array.length - 1);
                        }
                        return array;
                    }
                    /*List<TSource> */ ToList()
                    {
                        /*int*/ let count = this.GetCount(true);
                        if (count === 1)
                        {
                            return (() =>
                            {
                                //new $.$spc.System.Collections.Generic.List$$(TSource)()
                                const $t1 = $.$spc.System.Collections.Generic.List$$(TSource);
                                const $i1 = new $t1();
                                $i1.$ctor$2(1);
                                $i1.Add(this._item);
                                return $i1;
                            })();
                        }
                        /*List<TSource>*/ let list = count === -1 ? (() =>
                        {
                            let $t1 = new ($.$spc.System.Collections.Generic.List$$(TSource))().$ctor$1();
                            return $t1;
                        })() : new ($.$spc.System.Collections.Generic.List$$(TSource))().$ctor$2(count);
                        if (!this._appending)
                        {
                            list.Add(this._item);
                        }
                        list.AddRange(this._source);
                        if (this._appending)
                        {
                            list.Add(this._item);
                        }
                        return list;
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        let iterator;
                        if ($.$is(this._source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }))
                        {
                            /*int*/ let count = iterator.GetCount(onlyIfCheap);
                            return count === -1 ? -1 : ((count + 1) | 0);
                        }
                        return !onlyIfCheap || $.$is(this._source, $.$spc.System.Collections.Generic.ICollection$$(TSource)) ? (($.$sl.System.Linq.Enumerable.Count(TSource, this._source) + 1) | 0) : -1;
                    }
                    /*TSource? */ TryGetFirst(/*out bool*/ found)
                    {
                        if (this._appending)
                        {
                            /*TSource?*/ let first = $.$sl.System.Linq.Enumerable.TryGetFirst(TSource, this._source, found);
                            if (found.$v)
                            {
                                return first;
                            }
                        }
                        found.$v = true;
                        return this._item;
                    }
                    /*TSource? */ TryGetLast(/*out bool*/ found)
                    {
                        if (!this._appending)
                        {
                            /*TSource?*/ let last = $.$sl.System.Linq.Enumerable.TryGetLast(TSource, this._source, found);
                            if (found.$v)
                            {
                                return last;
                            }
                        }
                        found.$v = true;
                        return this._item;
                    }
                    /*TSource? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if (!this._appending)
                        {
                            if (index === 0)
                            {
                                found.$v = true;
                                return this._item;
                            }
                            index--;
                            return $.$sl.System.Linq.Enumerable.TryGetElementAt(TSource, this._source, index, found);
                        }
                        return super.TryGetElementAt(index, found);
                    }
                    /*bool */ Contains(/*TSource*/ value)
                    {
                        return $.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default.Equals$2(this._item, value) || $.$sl.System.Linq.Enumerable.Contains(TSource, this._source, value);
                    }
                    static $h = 458759;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.AppendPrependIterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.AppendPrepend1Iterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_AppendPrepend1Iterator$$ = $v))(TSource);
            }
            static $_AppendPrependN$$;
            static AppendPrependN$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_AppendPrependN$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.AppendPrependN<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.AppendPrependN<>", [TSource], ($self) => class AppendPrependN$$ extends $.$sl.System.Linq.Enumerable.AppendPrependIterator$$(TSource)
                {
                    /*SingleLinkedNode<TSource>?*/ _prepended = null;
                    /*SingleLinkedNode<TSource>?*/ _appended = null;
                    /*int*/ _prependCount = 0;
                    /*int*/ _appendCount = 0;
                    /*SingleLinkedNode<TSource>?*/ _node = null;
                    $ctor$3(/*IEnumerable<TSource>*/ source, /*SingleLinkedNode<TSource>?*/ prepended, /*SingleLinkedNode<TSource>?*/ appended, /*int*/ prependCount, /*int*/ appendCount)
                    {
                        super.$ctor$2(source);
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(prepended === null) || !(appended === null), "prepended is not null || appended is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(prependCount > 0 || appendCount > 0, "prependCount > 0 || appendCount > 0");
                            $.$spc.System.Diagnostics.Debug.Assert$1(((prependCount + appendCount) | 0) >= 2, "prependCount + appendCount >= 2");
                            $.$spc.System.Diagnostics.Debug.Assert$1(((prepended?.GetCount() ?? null) ?? 0) === prependCount, "(prepended?.GetCount() ?? 0) == prependCount");
                            $.$spc.System.Diagnostics.Debug.Assert$1(((appended?.GetCount() ?? null) ?? 0) === appendCount, "(appended?.GetCount() ?? 0) == appendCount");
                            this._prepended = prepended;
                            this._appended = appended;
                            this._prependCount = prependCount;
                            this._appendCount = appendCount;
                        }
                        return this;
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.AppendPrependN$$(TSource))().$ctor$3(this._source, this._prepended, this._appended, this._prependCount, this._appendCount);
                    }
                    /*bool */ MoveNext()
                    {
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                this._node = this._prepended;
                                this._state = 2;
                                $switchJumpState1 = 2; /*goto case 2*/
                                continue $switchJumpStart1;
                                case 2:
                                if (!(this._node === null))
                                {
                                    this._current = this._node.Item$2;
                                    this._node = this._node.Linked;
                                    return true;
                                }
                                this.GetSourceEnumerator();
                                this._state = 3;
                                $switchJumpState1 = 3; /*goto case 3*/
                                continue $switchJumpStart1;
                                case 3:
                                if (this.LoadFromEnumerator())
                                {
                                    return true;
                                }
                                if (this._appended === null)
                                {
                                    return false;
                                }
                                this._enumerator = (this._appended.ToArray(this._appendCount)).System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                                this._state = 4;
                                $switchJumpState1 = 4; /*goto case 4*/
                                continue $switchJumpStart1;
                                case 4:
                                return this.LoadFromEnumerator();
                            }
                            break;
                        }
                        this.Dispose();
                        return false;
                    }
                    /*AppendPrependIterator<TSource> */ Append(/*TSource*/ item)
                    {
                        /*var*/ let appended = !(this._appended === null) ? this._appended.Add(item) : new ($.$sl.System.Linq.SingleLinkedNode$$(TSource))().$ctor$1(item);
                        return new ($.$sl.System.Linq.Enumerable.AppendPrependN$$(TSource))().$ctor$3(this._source, this._prepended, appended, this._prependCount, ((this._appendCount + 1) | 0));
                    }
                    /*AppendPrependIterator<TSource> */ Prepend(/*TSource*/ item)
                    {
                        /*var*/ let prepended = !(this._prepended === null) ? this._prepended.Add(item) : new ($.$sl.System.Linq.SingleLinkedNode$$(TSource))().$ctor$1(item);
                        return new ($.$sl.System.Linq.Enumerable.AppendPrependN$$(TSource))().$ctor$3(this._source, prepended, this._appended, ((this._prependCount + 1) | 0), this._appendCount);
                    }
                    /*TSource[] */ LazyToArray()
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this.GetCount(true) === -1, "GetCount(onlyIfCheap: true) == -1");
                        let c;
                        if ($.$is(this._source, $.$spc.System.Collections.Generic.ICollection$$(TSource), { set $v(v){ c = v; } }))
                        {
                            /*var*/ let result = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TSource), null, [$.$checked($.$checked(this._prependCount + c.System$Collections$Generic$ICollection$$$Count, 1) + this._appendCount, 1)], null);
                            this._prepended?.Fill($.$spc.System.Span$$(TSource).op_Implicit(result));
                            c.System$Collections$Generic$ICollection$$$CopyTo(result, this._prependCount, [TSource]);
                            this._appended?.FillReversed($.$spc.System.Span$$(TSource).op_Implicit(result));
                            return result;
                        }
                        else 
                        {
                            /*SegmentedArrayBuilder<TSource>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource).ScratchBuffer)();
                            /*SegmentedArrayBuilder<TSource>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource))().$ctor$2($.$spc.System.Span$$(TSource).op_Implicit(scratch.$fields));
                            for(/*SingleLinkedNode<TSource>?*/ let node = this._prepended; !(node === null); node = node.Linked)
                            {
                                builder.Add(node.Item$2);
                            }
                            builder.AddNonICollectionRange(this._source);
                            /*TSource[]*/ let result = builder.ToArray$1(this._appendCount);
                            builder.Dispose();
                            this._appended?.FillReversed($.$spc.System.Span$$(TSource).op_Implicit(result));
                            return result;
                        }
                    }
                    /*TSource[] */ ToArray()
                    {
                        /*int*/ let count = this.GetCount(true);
                        if (count === -1)
                        {
                            return this.LazyToArray();
                        }
                        /*TSource[]*/ let array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TSource), null, [count], null);
                        /*int*/ let index = 0;
                        for(/*SingleLinkedNode<TSource>?*/ let node = this._prepended; !(node === null); node = node.Linked)
                        {
                            $.$spc.System.Array.$WriteT1.call(array, node.Item$2, index);
                            ++index;
                        }
                        let sourceCollection;
                        if ($.$is(this._source, $.$spc.System.Collections.Generic.ICollection$$(TSource), { set $v(v){ sourceCollection = v; } }))
                        {
                            sourceCollection.System$Collections$Generic$ICollection$$$CopyTo(array, index, [TSource]);
                        }
                        else 
                        {
                            var $en5 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var item = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    $.$spc.System.Array.$WriteT1.call(array, item, index);
                                    ++index;
                                }
                            }
                        }
                        index = array.length;
                        for(/*SingleLinkedNode<TSource>?*/ let node = this._appended; !(node === null); node = node.Linked)
                        {
                            --index;
                            $.$spc.System.Array.$WriteT1.call(array, node.Item$2, index);
                        }
                        return array;
                    }
                    /*List<TSource> */ ToList()
                    {
                        /*int*/ let count = this.GetCount(true);
                        /*List<TSource>*/ let list = count === -1 ? (() =>
                        {
                            let $t1 = new ($.$spc.System.Collections.Generic.List$$(TSource))().$ctor$1();
                            return $t1;
                        })() : new ($.$spc.System.Collections.Generic.List$$(TSource))().$ctor$2(count);
                        this._prepended?.Fill($.$sl.System.Linq.Enumerable.SetCountAndGetSpan(TSource, list, this._prependCount));
                        list.AddRange(this._source);
                        this._appended?.FillReversed($.$sl.System.Linq.Enumerable.SetCountAndGetSpan(TSource, list, ((list.Count + this._appendCount) | 0)));
                        return list;
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        let iterator;
                        if ($.$is(this._source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }))
                        {
                            /*int*/ let count = iterator.GetCount(onlyIfCheap);
                            return count === -1 ? -1 : ((((count + this._appendCount) | 0) + this._prependCount) | 0);
                        }
                        return !onlyIfCheap || $.$is(this._source, $.$spc.System.Collections.Generic.ICollection$$(TSource)) ? (((($.$sl.System.Linq.Enumerable.Count(TSource, this._source) + this._appendCount) | 0) + this._prependCount) | 0) : -1;
                    }
                    /*bool */ Contains(/*TSource*/ value)
                    {
                        var $en4 = $.$spc.System.ReadOnlySpan$$($.$sl.System.Linq.SingleLinkedNode$$(TSource)).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$sl.System.Linq.SingleLinkedNode$$(TSource).$type, [ this._appended, this._prepended ], null, null)).GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var head = $en4.Current.$v;
                            {
                                for(/*SingleLinkedNode<TSource>?*/ let node = head; !(node === null); node = node.Linked)
                                {
                                    if ($.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default.Equals$2(node.Item$2, value))
                                    {
                                        return true;
                                    }
                                }
                            }
                        }
                        return $.$sl.System.Linq.Enumerable.Contains(TSource, this._source, value);
                    }
                    static $h = 589831;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.AppendPrependIterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.AppendPrependN<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_AppendPrependN$$ = $v))(TSource);
            }
            static /*double */ Average(/*this IEnumerable<int>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*ReadOnlySpan<int>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan($.$spc.System.Int32, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Int32))))
                {
                    if (span.IsEmpty)
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    /*long*/ let sum = 0n;
                    /*int*/ let i = 0;
                    //if (Vector.IsHardwareAccelerated && span.Length >= Vector<int>.Count) { ... }
                    for(; (i >>> 0) < (span.Length >>> 0); i++)
                    {
                        sum += BigInt(span.get_Item(i).$v);
                    }
                    return $.$cast(sum, $.$spc.System.Double) / span.Length;
                }
                else 
                {
                    /*IEnumerator<int>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$spc.System.Int32]);
                    try
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                        }
                        /*long*/ let sum = BigInt(e.System$Collections$Generic$IEnumerator$$$Current);
                        /*long*/ let count = 1n;
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            //checked
                            {
                                sum += BigInt(e.System$Collections$Generic$IEnumerator$$$Current);
                            }
                            count++;
                        }
                        return $.$cast(sum, $.$spc.System.Double) / Number(count);
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }
            }
            static /*double */ Average$1(/*this IEnumerable<long>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Average$5($.$spc.System.Int64, $.$spc.System.Int64, $.$spc.System.Double, source);
            }
            static /*float */ Average$2(/*this IEnumerable<float>*/ source)
            {
                return $.$cast($.$sl.System.Linq.Enumerable.Average$5($.$spc.System.Single, $.$spc.System.Double, $.$spc.System.Double, source), $.$spc.System.Single);
            }
            static /*double */ Average$3(/*this IEnumerable<double>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Average$5($.$spc.System.Double, $.$spc.System.Double, $.$spc.System.Double, source);
            }
            static /*decimal */ Average$4(/*this IEnumerable<decimal>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Average$5($.$spc.System.Decimal, $.$spc.System.Decimal, $.$spc.System.Decimal, source);
            }
            static /*TResult */ Average$5(TSource, TAccumulator, TResult, /*this IEnumerable<TSource>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*ReadOnlySpan<TSource>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan(TSource, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(TSource))))
                {
                    if (span.IsEmpty)
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    return TResult.System$Numerics$IDivisionOperators$$$$$op_Division(TResult.System$Numerics$INumberBase$$$CreateChecked(TAccumulator, $.$sl.System.Linq.Enumerable.Sum$6(TSource, TAccumulator, span)), TResult.System$Numerics$INumberBase$$$CreateChecked($.$spc.System.Int32, span.Length));
                }
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    if (!e.System$Collections$IEnumerator$MoveNext())
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    /*TAccumulator*/ let sum = TAccumulator.System$Numerics$INumberBase$$$CreateChecked(TSource, e.System$Collections$Generic$IEnumerator$$$Current);
                    /*long*/ let count = 1n;
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        //checked
                        {
                            sum = TAccumulator.System$Numerics$IAdditionOperators$$$$$op_CheckedAddition(sum, TAccumulator.System$Numerics$INumberBase$$$CreateChecked(TSource, e.System$Collections$Generic$IEnumerator$$$Current));
                        }
                        count++;
                    }
                    return TResult.System$Numerics$IDivisionOperators$$$$$op_Division(TResult.System$Numerics$INumberBase$$$CreateChecked(TAccumulator, sum), TResult.System$Numerics$INumberBase$$$CreateChecked($.$spc.System.Int64, count));
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*double? */ Average$6(/*this IEnumerable<int?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Average$11($.$spc.System.Int32, $.$spc.System.Int64, $.$spc.System.Double, source);
            }
            static /*double? */ Average$7(/*this IEnumerable<long?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Average$11($.$spc.System.Int64, $.$spc.System.Int64, $.$spc.System.Double, source);
            }
            static /*float? */ Average$8(/*this IEnumerable<float?>*/ source)
            {
                let result;
                return $.$is($.$sl.System.Linq.Enumerable.Average$11($.$spc.System.Single, $.$spc.System.Double, $.$spc.System.Double, source), $.$spc.System.Double, { set $v(v){ result = v; } }) ? $.$cast(result, $.$spc.System.Single) : null;
            }
            static /*double? */ Average$9(/*this IEnumerable<double?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Average$11($.$spc.System.Double, $.$spc.System.Double, $.$spc.System.Double, source);
            }
            static /*decimal? */ Average$10(/*this IEnumerable<decimal?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Average$11($.$spc.System.Decimal, $.$spc.System.Decimal, $.$spc.System.Decimal, source);
            }
            static /*TResult? */ Average$11(TSource, TAccumulator, TResult, /*this IEnumerable<TSource?>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*IEnumerator<TSource?>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$typeNullable(TSource)]);
                try
                {
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*TSource?*/ let value = e.System$Collections$Generic$IEnumerator$$$Current;
                        if ($.$spc.System.Nullable$$(TSource).HasValue$get.call(value))
                        {
                            /*TAccumulator*/ let sum = TAccumulator.System$Numerics$INumberBase$$$CreateChecked(TSource, $.$spc.System.Nullable$$(TSource).GetValueOrDefault.call(value));
                            /*long*/ let count = 1n;
                            while(e.System$Collections$IEnumerator$MoveNext())
                            {
                                value = e.System$Collections$Generic$IEnumerator$$$Current;
                                if ($.$spc.System.Nullable$$(TSource).HasValue$get.call(value))
                                {
                                    //checked
                                    {
                                        sum = TAccumulator.System$Numerics$IAdditionOperators$$$$$op_CheckedAddition(sum, TAccumulator.System$Numerics$INumberBase$$$CreateChecked(TSource, $.$spc.System.Nullable$$(TSource).GetValueOrDefault.call(value)));
                                    }
                                    count++;
                                }
                            }
                            return TResult.System$Numerics$IDivisionOperators$$$$$op_Division(TResult.System$Numerics$INumberBase$$$CreateChecked(TAccumulator, sum), TResult.System$Numerics$INumberBase$$$CreateChecked($.$spc.System.Int64, count));
                        }
                    }
                    return null;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*double */ Average$12(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, int>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Average$17(TSource, $.$spc.System.Int32, $.$spc.System.Int64, $.$spc.System.Double, source, selector);
            }
            static /*double */ Average$13(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, long>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Average$17(TSource, $.$spc.System.Int64, $.$spc.System.Int64, $.$spc.System.Double, source, selector);
            }
            static /*float */ Average$14(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, float>*/ selector)
            {
                return $.$cast($.$sl.System.Linq.Enumerable.Average$17(TSource, $.$spc.System.Single, $.$spc.System.Double, $.$spc.System.Double, source, selector), $.$spc.System.Single);
            }
            static /*double */ Average$15(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, double>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Average$17(TSource, $.$spc.System.Double, $.$spc.System.Double, $.$spc.System.Double, source, selector);
            }
            static /*decimal */ Average$16(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, decimal>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Average$17(TSource, $.$spc.System.Decimal, $.$spc.System.Decimal, $.$spc.System.Decimal, source, selector);
            }
            static /*TResult */ Average$17(TSource, TSelector, TAccumulator, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TSelector>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    if (!e.System$Collections$IEnumerator$MoveNext())
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    /*TAccumulator*/ let sum = TAccumulator.System$Numerics$INumberBase$$$CreateChecked(TSelector, selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current));
                    /*long*/ let count = 1n;
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        //checked
                        {
                            sum = TAccumulator.System$Numerics$IAdditionOperators$$$$$op_CheckedAddition(sum, TAccumulator.System$Numerics$INumberBase$$$CreateChecked(TSelector, selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current)));
                        }
                        count++;
                    }
                    return TResult.System$Numerics$IDivisionOperators$$$$$op_Division(TResult.System$Numerics$INumberBase$$$CreateChecked(TAccumulator, sum), TResult.System$Numerics$INumberBase$$$CreateChecked($.$spc.System.Int64, count));
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*double? */ Average$18(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, int?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Average$23(TSource, $.$spc.System.Int32, $.$spc.System.Int64, $.$spc.System.Double, source, selector);
            }
            static /*double? */ Average$19(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, long?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Average$23(TSource, $.$spc.System.Int64, $.$spc.System.Int64, $.$spc.System.Double, source, selector);
            }
            static /*float? */ Average$20(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, float?>*/ selector)
            {
                let result;
                return $.$is($.$sl.System.Linq.Enumerable.Average$23(TSource, $.$spc.System.Single, $.$spc.System.Double, $.$spc.System.Double, source, selector), $.$spc.System.Double, { set $v(v){ result = v; } }) ? $.$cast(result, $.$spc.System.Single) : null;
            }
            static /*double? */ Average$21(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, double?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Average$23(TSource, $.$spc.System.Double, $.$spc.System.Double, $.$spc.System.Double, source, selector);
            }
            static /*decimal? */ Average$22(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, decimal?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Average$23(TSource, $.$spc.System.Decimal, $.$spc.System.Decimal, $.$spc.System.Decimal, source, selector);
            }
            static /*TResult? */ Average$23(TSource, TSelector, TAccumulator, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TSelector?>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*TSelector?*/ let value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        if ($.$spc.System.Nullable$$(TSelector).HasValue$get.call(value))
                        {
                            /*TAccumulator*/ let sum = TAccumulator.System$Numerics$INumberBase$$$CreateChecked(TSelector, $.$spc.System.Nullable$$(TSelector).GetValueOrDefault.call(value));
                            /*long*/ let count = 1n;
                            while(e.System$Collections$IEnumerator$MoveNext())
                            {
                                value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                                if ($.$spc.System.Nullable$$(TSelector).HasValue$get.call(value))
                                {
                                    //checked
                                    {
                                        sum = TAccumulator.System$Numerics$IAdditionOperators$$$$$op_CheckedAddition(sum, TAccumulator.System$Numerics$INumberBase$$$CreateChecked(TSelector, $.$spc.System.Nullable$$(TSelector).GetValueOrDefault.call(value)));
                                    }
                                    count++;
                                }
                            }
                            return TResult.System$Numerics$IDivisionOperators$$$$$op_Division(TResult.System$Numerics$INumberBase$$$CreateChecked(TAccumulator, sum), TResult.System$Numerics$INumberBase$$$CreateChecked($.$spc.System.Int64, count));
                        }
                    }
                    return null;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*IEnumerable<
#nullable disable // there's no way to annotate the connection of the nullability of TResult to that of the source
                TResult
#nullable restore
                > */ Cast(TResult, /*this IEnumerable*/ source)
            {
                let typedSource;
                if ($.$is(source, $.$spc.System.Collections.Generic.IEnumerable$$(TResult), { set $v(v){ typedSource = v; } }))
                {
                    return typedSource;
                }
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                let collection;
                if ($.$is(source, $.$spc.System.Collections.ICollection, { set $v(v){ collection = v; } }))
                {
                    return new ($.$sl.System.Linq.Enumerable.CastICollectionIterator$$(TResult))().$ctor$2(collection);
                }
                return $.$sl.System.Linq.Enumerable.CastIterator(TResult, source);
            }
            static /*IEnumerable<TResult> */ CastIterator(TResult, /*IEnumerable*/ source)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var obj = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            yield $.$cast(obj, TResult);
                        }
                    }
                }.bind(this));
            }
            static $_CastICollectionIterator$$;
            static CastICollectionIterator$$(TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_CastICollectionIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.CastICollectionIterator<>", (TResult) => $asm.$gt("$sl.System.Linq.Enumerable.CastICollectionIterator<>", [TResult], ($self) => class CastICollectionIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*ICollection*/ _source = null;
                    /*IEnumerator?*/ _enumerator = null;
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.CastICollectionIterator$$(TResult))().$ctor$2(this._source);
                    }
                    /*bool */ MoveNext()
                    {
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                this._enumerator = this._source.System$Collections$IEnumerable$GetEnumerator();
                                this._state = 2;
                                $switchJumpState1 = 2; /*goto case 2*/
                                continue $switchJumpStart1;
                                case 2:
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._enumerator === null), "_enumerator is not null");
                                if (this._enumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    this._current = $.$cast(this._enumerator.System$Collections$IEnumerator$Current, TResult);
                                    return true;
                                }
                                this.Dispose();
                                break;
                            }
                            break;
                        }
                        return false;
                    }
                    /*void */ Dispose()
                    {
                        ($.$as(this._enumerator, $.$spc.System.IDisposable))?.System$IDisposable$Dispose();
                        this._enumerator = null;
                        super.Dispose();
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        return this._source.System$Collections$ICollection$Count;
                    }
                    /*TResult[] */ ToArray()
                    {
                        /*TResult[]*/ let array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TResult), null, [this._source.System$Collections$ICollection$Count], null);
                        /*int*/ let index = 0;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                $.$spc.System.Array.$WriteT1.call(array, item, index++);
                            }
                        }
                        return array;
                    }
                    /*List<TResult> */ ToList()
                    {
                        /*List<TResult>*/ let list = new ($.$spc.System.Collections.Generic.List$$(TResult))().$ctor$2(this._source.System$Collections$ICollection$Count);
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                list.Add(item);
                            }
                        }
                        return list;
                    }
                    /*TResult? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if (index >= 0)
                        {
                            /*IEnumerator*/ let e = this._source.System$Collections$IEnumerable$GetEnumerator();
                            try
                            {
                                while(e.System$Collections$IEnumerator$MoveNext())
                                {
                                    if (index === 0)
                                    {
                                        found.$v = true;
                                        return $.$cast(e.System$Collections$IEnumerator$Current, TResult);
                                    }
                                    index--;
                                }
                            }
                            finally
                            {
                                {
                                    ($.$as(e, $.$spc.System.IDisposable))?.System$IDisposable$Dispose();
                                }
                            }
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult? */ TryGetFirst(/*out bool*/ found)
                    {
                        /*IEnumerator*/ let e = this._source.System$Collections$IEnumerable$GetEnumerator();
                        try
                        {
                            if (e.System$Collections$IEnumerator$MoveNext())
                            {
                                found.$v = true;
                                return $.$cast(e.System$Collections$IEnumerator$Current, TResult);
                            }
                        }
                        finally
                        {
                            {
                                ($.$as(e, $.$spc.System.IDisposable))?.System$IDisposable$Dispose();
                            }
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult? */ TryGetLast(/*out bool*/ found)
                    {
                        /*IEnumerator*/ let e = this._source.System$Collections$IEnumerable$GetEnumerator();
                        try
                        {
                            if (e.System$Collections$IEnumerator$MoveNext())
                            {
                                /*TResult*/ let last = $.$cast(e.System$Collections$IEnumerator$Current, TResult);
                                while(e.System$Collections$IEnumerator$MoveNext())
                                {
                                    last = $.$cast(e.System$Collections$IEnumerator$Current, TResult);
                                }
                                found.$v = true;
                                return last;
                            }
                            found.$v = false;
                            return $.$default(TResult);
                        }
                        finally
                        {
                            {
                                ($.$as(e, $.$spc.System.IDisposable))?.System$IDisposable$Dispose();
                            }
                        }
                    }
                    /*bool */ Contains(/*TResult*/ value)
                    {
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if ($.$spc.System.Collections.Generic.EqualityComparer$$(TResult).Default.Equals$2(item, value))
                                {
                                    return true;
                                }
                            }
                        }
                        return false;
                    }
                    //Begin primary constructor
                    /*ICollection*/ source = null;
                    $ctor$2(/*ICollection*/$source)
                    {
                        this.source = $source;
                        //depends on primary constructor parameter
                        this._source = this.source;
                        return this
                    }
                    //End primary constructor
                    static $h = 1048583;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.CastICollectionIterator<${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_CastICollectionIterator$$ = $v))(TResult);
            }
            static /*IEnumerable<TSource[]> */ Chunk(TSource, /*this IEnumerable<TSource>*/ source, /*int*/ size)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (size < 1)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentOutOfRangeException(19/*ExceptionArgument.size*/);
                }
                let array;
                if ($.$is(source, $.$typeArray(TSource), { set $v(v){ array = v; } }))
                {
                    return array.length !== 0 ? $.$sl.System.Linq.Enumerable.ArrayChunkIterator(TSource, array, size) : $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeArray(TSource).$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.EnumerableChunkIterator(TSource, source, size);
            }
            static /*IEnumerable<TSource[]> */ ArrayChunkIterator(TSource, /*TSource[]*/ source, /*int*/ size)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*int*/ let index = 0;
                    while(index < source.length)
                    {
                        /*TSource[]*/ let chunk = new ($.$spc.System.ReadOnlySpan$$(TSource))().$ctor$3(source, index, $.$spc.System.Math.Min$4(size, ((source.length - index) | 0))).ToArray();
                        index += chunk.length;
                        yield chunk;
                    }
                }.bind(this));
            }
            static /*IEnumerable<TSource[]> */ EnumerableChunkIterator(TSource, /*IEnumerable<TSource>*/ source, /*int*/ size)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    try
                    {
                        if (e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*int*/ let arraySize = $.$spc.System.Math.Min$4(size, 4);
                            /*int*/ let i;
                            do
                            {
                                /*var*/ let array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TSource), null, [arraySize], null);
                                $.$spc.System.Array.$WriteT1.call(array, e.System$Collections$Generic$IEnumerator$$$Current, 0);
                                i = 1;
                                if (size !== array.length)
                                {
                                    for(; i < size && e.System$Collections$IEnumerator$MoveNext(); i++)
                                    {
                                        if (i >= array.length)
                                        {
                                            arraySize = ($.$spc.System.Math.Min$10((size >>> 0), ((2 * (array.length >>> 0)) >>> 0)) | 0);
                                            $.$spc.System.Array.Resize(TSource, $.$ref(() => array, ($v) => array = $v, $.$typeArray(TSource)), arraySize);
                                        }
                                        $.$spc.System.Array.$WriteT1.call(array, e.System$Collections$Generic$IEnumerator$$$Current, i);
                                    }
                                }
                                else 
                                {
                                    /*TSource[]*/ let local = array;
                                    $.$spc.System.Diagnostics.Debug.Assert$1(local.length === size, "local.Length == size");
                                    for(; (i >>> 0) < (local.length >>> 0) && e.System$Collections$IEnumerator$MoveNext(); i++)
                                    {
                                        $.$spc.System.Array.$WriteT1.call(local, e.System$Collections$Generic$IEnumerator$$$Current, i);
                                    }
                                }
                                if (i !== array.length)
                                {
                                    $.$spc.System.Array.Resize(TSource, $.$ref(() => array, ($v) => array = $v, $.$typeArray(TSource)), i);
                                }
                                yield array;
                            }
                            while(i >= size && e.System$Collections$IEnumerator$MoveNext());
                        }
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            static /*IEnumerable<TSource> */ Concat(TSource, /*this IEnumerable<TSource>*/ first, /*IEnumerable<TSource>*/ second)
            {
                if (first === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(4/*ExceptionArgument.first*/);
                }
                if (second === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(14/*ExceptionArgument.second*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, first))
                {
                    return second;
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, second))
                {
                    return first;
                }
                let firstConcat;
                return $.$is(first, $.$sl.System.Linq.Enumerable.ConcatIterator$$(TSource), { set $v(v){ firstConcat = v; } }) ? firstConcat.Concat(second) : new ($.$sl.System.Linq.Enumerable.Concat2Iterator$$(TSource))().$ctor$3(first, second);
            }
            static $_Concat2Iterator$$;
            static Concat2Iterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_Concat2Iterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.Concat2Iterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.Concat2Iterator<>", [TSource], ($self) => class Concat2Iterator$$ extends $.$sl.System.Linq.Enumerable.ConcatIterator$$(TSource)
                {
                    /*IEnumerable<TSource>*/ _first = null;
                    /*IEnumerable<TSource>*/ _second = null;
                    $ctor$3(/*IEnumerable<TSource>*/ first, /*IEnumerable<TSource>*/ second)
                    {
                        super.$ctor$2();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(first === null), "first is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(second === null), "second is not null");
                            this._first = first;
                            this._second = second;
                        }
                        return this;
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.Concat2Iterator$$(TSource))().$ctor$3(this._first, this._second);
                    }
                    /*ConcatIterator<TSource> */ Concat(/*IEnumerable<TSource>*/ next)
                    {
                        /*bool*/ let hasOnlyCollections = $.$is(next, $.$spc.System.Collections.Generic.ICollection$$(TSource)) && $.$is(this._first, $.$spc.System.Collections.Generic.ICollection$$(TSource)) && $.$is(this._second, $.$spc.System.Collections.Generic.ICollection$$(TSource));
                        return new ($.$sl.System.Linq.Enumerable.ConcatNIterator$$(TSource))().$ctor$3(this, next, 2, hasOnlyCollections);
                    }
                    /*IEnumerable<TSource>? */ GetEnumerable(/*int*/ index)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(index >= 0 && index <= 2, "index >= 0 && index <= 2");
                        return (() =>
                        {
                            if (index === 0)
                            {
                                return this._first;
                            }
                            if (index === 1)
                            {
                                return this._second;
                            }
                            return null;
                        })();
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        /*int*/ let firstCount, secondCount;
                        if (!$.$sl.System.Linq.Enumerable.TryGetNonEnumeratedCount(TSource, this._first, $.$ref(() => firstCount, ($v) => firstCount = $v, $.$spc.System.Int32)))
                        {
                            if (onlyIfCheap)
                            {
                                return -1;
                            }
                            firstCount = $.$sl.System.Linq.Enumerable.Count(TSource, this._first);
                        }
                        if (!$.$sl.System.Linq.Enumerable.TryGetNonEnumeratedCount(TSource, this._second, $.$ref(() => secondCount, ($v) => secondCount = $v, $.$spc.System.Int32)))
                        {
                            if (onlyIfCheap)
                            {
                                return -1;
                            }
                            secondCount = $.$sl.System.Linq.Enumerable.Count(TSource, this._second);
                        }
                        return $.$checked(firstCount + secondCount, 1);
                    }
                    /*TSource[] */ ToArray()
                    {
                        /*ICollection<TSource>?*/ let firstCollection = $.$as(this._first, $.$spc.System.Collections.Generic.ICollection$$(TSource));
                        /*ICollection<TSource>?*/ let secondCollection = $.$as(this._second, $.$spc.System.Collections.Generic.ICollection$$(TSource));
                        if (!(firstCollection === null) && !(secondCollection === null))
                        {
                            /*int*/ let firstCount = firstCollection.System$Collections$Generic$ICollection$$$Count;
                            /*TSource[]*/ let result = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TSource), null, [$.$checked(firstCount + secondCollection.System$Collections$Generic$ICollection$$$Count, 1)], null);
                            firstCollection.System$Collections$Generic$ICollection$$$CopyTo(result, 0, [TSource]);
                            secondCollection.System$Collections$Generic$ICollection$$$CopyTo(result, firstCount, [TSource]);
                            return result;
                        }
                        else 
                        {
                            /*SegmentedArrayBuilder<TSource>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource).ScratchBuffer)();
                            /*SegmentedArrayBuilder<TSource>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource))().$ctor$2($.$spc.System.Span$$(TSource).op_Implicit(scratch.$fields));
                            /*TSource[]*/ let result;
                            if (!(firstCollection === null))
                            {
                                /*int*/ let firstCount = firstCollection.System$Collections$Generic$ICollection$$$Count;
                                builder.AddNonICollectionRange(this._second);
                                result = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TSource), null, [$.$checked(firstCount + builder.Count, 1)], null);
                                firstCollection.System$Collections$Generic$ICollection$$$CopyTo(result, 0, [TSource]);
                                builder.ToSpan($.$spc.System.MemoryExtensions.AsSpan(TSource, result, firstCount));
                            }
                            else if (!(secondCollection === null))
                            {
                                /*int*/ let secondCount = secondCollection.System$Collections$Generic$ICollection$$$Count;
                                builder.AddNonICollectionRange(this._first);
                                result = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TSource), null, [$.$checked(builder.Count + secondCount, 1)], null);
                                builder.ToSpan($.$spc.System.Span$$(TSource).op_Implicit(result));
                                secondCollection.System$Collections$Generic$ICollection$$$CopyTo(result, ((result.length - secondCount) | 0), [TSource]);
                            }
                            else 
                            {
                                builder.AddNonICollectionRange(this._first);
                                builder.AddNonICollectionRange(this._second);
                                result = builder.ToArray();
                            }
                            builder.Dispose();
                            return result;
                        }
                    }
                    /*TSource? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if (index >= 0)
                        {
                            var $en5 = $.$spc.System.ReadOnlySpan$$($.$spc.System.Collections.Generic.IEnumerable$$(TSource)).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Collections.Generic.IEnumerable$$(TSource).$type, [ this._first, this._second ], null, null)).GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var source = $en5.Current.$v;
                                {
                                    /*int*/ let count;
                                    if ($.$sl.System.Linq.Enumerable.TryGetNonEnumeratedCount(TSource, source, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32)))
                                    {
                                        if (index < count)
                                        {
                                            found.$v = true;
                                            return $.$sl.System.Linq.Enumerable.ElementAt(TSource, source, index);
                                        }
                                        index -= count;
                                    }
                                    else 
                                    {
                                        /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                                        try
                                        {
                                            while(e.System$Collections$IEnumerator$MoveNext())
                                            {
                                                if (index === 0)
                                                {
                                                    found.$v = true;
                                                    return e.System$Collections$Generic$IEnumerator$$$Current;
                                                }
                                                index--;
                                            }
                                        }
                                        finally
                                        {
                                            e?.System$IDisposable$Dispose();
                                        }
                                    }
                                }
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*TSource? */ TryGetFirst(/*out bool*/ found)
                    {
                        /*TSource?*/ let result = $.$sl.System.Linq.Enumerable.TryGetFirst(TSource, this._first, found);
                        if (!found.$v)
                        {
                            result = $.$sl.System.Linq.Enumerable.TryGetFirst(TSource, this._second, found);
                        }
                        return result;
                    }
                    /*TSource? */ TryGetLast(/*out bool*/ found)
                    {
                        /*TSource?*/ let result = $.$sl.System.Linq.Enumerable.TryGetLast(TSource, this._second, found);
                        if (!found.$v)
                        {
                            result = $.$sl.System.Linq.Enumerable.TryGetLast(TSource, this._first, found);
                        }
                        return result;
                    }
                    /*bool */ Contains(/*TSource*/ value)
                    {
                        return $.$sl.System.Linq.Enumerable.Contains(TSource, this._first, value) || $.$sl.System.Linq.Enumerable.Contains(TSource, this._second, value);
                    }
                    static $h = 1114119;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.ConcatIterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.Concat2Iterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Concat2Iterator$$ = $v))(TSource);
            }
            static $_ConcatNIterator$$;
            static ConcatNIterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_ConcatNIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.ConcatNIterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.ConcatNIterator<>", [TSource], ($self) => class ConcatNIterator$$ extends $.$sl.System.Linq.Enumerable.ConcatIterator$$(TSource)
                {
                    /*ConcatIterator<TSource>*/ _tail = null;
                    /*IEnumerable<TSource>*/ _head = null;
                    /*int*/ _headIndex = 0;
                    /*bool*/ _hasOnlyCollections = false;
                    $ctor$3(/*ConcatIterator<TSource>*/ tail, /*IEnumerable<TSource>*/ head, /*int*/ headIndex, /*bool*/ hasOnlyCollections)
                    {
                        super.$ctor$2();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(tail === null), "tail is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(head === null), "head is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(headIndex >= 2, "headIndex >= 2");
                            this._tail = tail;
                            this._head = head;
                            this._headIndex = headIndex;
                            this._hasOnlyCollections = hasOnlyCollections;
                        }
                        return this;
                    }
                    /*ConcatNIterator<TSource>? */ get PreviousN()
                    {
                        return $.$as(this._tail, $.$sl.System.Linq.Enumerable.ConcatNIterator$$(TSource));
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.ConcatNIterator$$(TSource))().$ctor$3(this._tail, this._head, this._headIndex, this._hasOnlyCollections);
                    }
                    /*ConcatIterator<TSource> */ Concat(/*IEnumerable<TSource>*/ next)
                    {
                        if (this._headIndex === ((2147483647/*int.MaxValue*/ - 2) | 0))
                        {
                            return new ($.$sl.System.Linq.Enumerable.Concat2Iterator$$(TSource))().$ctor$3(this, next);
                        }
                        /*bool*/ let hasOnlyCollections = this._hasOnlyCollections && $.$is(next, $.$spc.System.Collections.Generic.ICollection$$(TSource));
                        return new ($.$sl.System.Linq.Enumerable.ConcatNIterator$$(TSource))().$ctor$3(this, next, ((this._headIndex + 1) | 0), hasOnlyCollections);
                    }
                    /*IEnumerable<TSource>? */ GetEnumerable(/*int*/ index)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(index >= 0, "index >= 0");
                        if (index > this._headIndex)
                        {
                            return null;
                        }
                        /*ConcatNIterator<TSource>?*/ let node, previousN = this;
                        do
                        {
                            node = previousN;
                            if (index === node._headIndex)
                            {
                                return node._head;
                            }
                        }
                        while(!((previousN = node.PreviousN) === null));
                        $.$spc.System.Diagnostics.Debug.Assert$1(index === 0 || index === 1, "index == 0 || index == 1");
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$is(node._tail, $.$sl.System.Linq.Enumerable.Concat2Iterator$$(TSource)), "node._tail is Concat2Iterator<TSource>");
                        return node._tail.GetEnumerable(index);
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        if (onlyIfCheap && !this._hasOnlyCollections)
                        {
                            return -1;
                        }
                        /*int*/ let count = 0;
                        /*ConcatNIterator<TSource>?*/ let node, previousN = this;
                        do
                        {
                            node = previousN;
                            /*IEnumerable<TSource>*/ let source = node._head;
                            /*var*/ let collection = $.$as(source, $.$spc.System.Collections.Generic.ICollection$$(TSource));
                            $.$spc.System.Diagnostics.Debug.Assert$1(!this._hasOnlyCollections || !(collection === null), "!_hasOnlyCollections || collection is not null");
                            /*int*/ let sourceCount = (collection?.System$Collections$Generic$ICollection$$$Count ?? null) ?? $.$sl.System.Linq.Enumerable.Count(TSource, source);
                            //checked
                            {
                                count += sourceCount;
                            }
                        }
                        while(!((previousN = node.PreviousN) === null));
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$is(node._tail, $.$sl.System.Linq.Enumerable.Concat2Iterator$$(TSource)), "node._tail is Concat2Iterator<TSource>");
                        return $.$checked(count + node._tail.GetCount(onlyIfCheap), 1);
                    }
                    /*TSource[] */ ToArray()
                    {
                        return this._hasOnlyCollections ? this.PreallocatingToArray() : this.LazyToArray();
                    }
                    /*TSource[] */ LazyToArray()
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(!this._hasOnlyCollections, "!_hasOnlyCollections");
                        /*SegmentedArrayBuilder<TSource>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TSource>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource))().$ctor$2($.$spc.System.Span$$(TSource).op_Implicit(scratch.$fields));
                        for(/*int*/ let i = 0; ; i++)
                        {
                            /*IEnumerable<TSource>?*/ let source = this.GetEnumerable(i);
                            if (source === null)
                            {
                                break;
                            }
                            builder.AddRange(source);
                        }
                        /*TSource[]*/ let result = builder.ToArray();
                        builder.Dispose();
                        return result;
                    }
                    /*TSource[] */ PreallocatingToArray()
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._hasOnlyCollections, "_hasOnlyCollections");
                        /*int*/ let count = this.GetCount(true);
                        $.$spc.System.Diagnostics.Debug.Assert$1(count >= 0, "count >= 0");
                        if (count === 0)
                        {
                            return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                        }
                        /*var*/ let array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TSource), null, [count], null);
                        /*int*/ let arrayIndex = array.length;
                        /*ConcatNIterator<TSource>?*/ let node, previousN = this;
                        do
                        {
                            node = previousN;
                            /*ICollection<TSource>*/ let source = $.$cast(node._head, $.$spc.System.Collections.Generic.ICollection$$(TSource));
                            /*int*/ let sourceCount = source.System$Collections$Generic$ICollection$$$Count;
                            if (sourceCount > 0)
                            {
                                //checked
                                {
                                    arrayIndex -= sourceCount;
                                }
                                source.System$Collections$Generic$ICollection$$$CopyTo(array, arrayIndex, [TSource]);
                            }
                        }
                        while(!((previousN = node.PreviousN) === null));
                        /*var*/ let previous2 = $.$cast(node._tail, $.$sl.System.Linq.Enumerable.Concat2Iterator$$(TSource));
                        /*var*/ let second = $.$cast(previous2._second, $.$spc.System.Collections.Generic.ICollection$$(TSource));
                        /*int*/ let secondCount = second.System$Collections$Generic$ICollection$$$Count;
                        if (secondCount > 0)
                        {
                            second.System$Collections$Generic$ICollection$$$CopyTo(array, $.$checked(arrayIndex - secondCount, 1), [TSource]);
                        }
                        if (arrayIndex > secondCount)
                        {
                            /*var*/ let first = $.$cast(previous2._first, $.$spc.System.Collections.Generic.ICollection$$(TSource));
                            first.System$Collections$Generic$ICollection$$$CopyTo(array, 0, [TSource]);
                        }
                        return array;
                    }
                    /*TSource? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if (index >= 0)
                        {
                            /*IEnumerable<TSource>?*/ let source;
                            for(/*int*/ let i = 0; !((source = this.GetEnumerable(i)) === null); i++)
                            {
                                /*int*/ let count;
                                if ($.$sl.System.Linq.Enumerable.TryGetNonEnumeratedCount(TSource, source, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32)))
                                {
                                    if (index < count)
                                    {
                                        found.$v = true;
                                        return $.$sl.System.Linq.Enumerable.ElementAt(TSource, source, index);
                                    }
                                    index -= count;
                                }
                                else 
                                {
                                    /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                                    try
                                    {
                                        while(e.System$Collections$IEnumerator$MoveNext())
                                        {
                                            if (index === 0)
                                            {
                                                found.$v = true;
                                                return e.System$Collections$Generic$IEnumerator$$$Current;
                                            }
                                            index--;
                                        }
                                    }
                                    finally
                                    {
                                        e?.System$IDisposable$Dispose();
                                    }
                                }
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*TSource? */ TryGetFirst(/*out bool*/ found)
                    {
                        /*IEnumerable<TSource>?*/ let source;
                        for(/*int*/ let i = 0; !((source = this.GetEnumerable(i)) === null); i++)
                        {
                            /*TSource?*/ let result = $.$sl.System.Linq.Enumerable.TryGetFirst(TSource, source, found);
                            if (found.$v)
                            {
                                return result;
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*TSource? */ TryGetLast(/*out bool*/ found)
                    {
                        /*ConcatNIterator<TSource>?*/ let node, previousN = this;
                        /*TSource?*/ let result;
                        do
                        {
                            node = previousN;
                            result = $.$sl.System.Linq.Enumerable.TryGetLast(TSource, node._head, found);
                            if (found.$v)
                            {
                                return result;
                            }
                        }
                        while(!((previousN = node.PreviousN) === null));
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$is(node._tail, $.$sl.System.Linq.Enumerable.Concat2Iterator$$(TSource)), "node._tail is Concat2Iterator<TSource>");
                        return node._tail.TryGetLast(found);
                    }
                    /*bool */ Contains(/*TSource*/ value)
                    {
                        /*ConcatNIterator<TSource>?*/ let node, previousN = this;
                        do
                        {
                            node = previousN;
                            if ($.$sl.System.Linq.Enumerable.Contains(TSource, node._head, value))
                            {
                                return true;
                            }
                        }
                        while(!((previousN = node.PreviousN) === null));
                        $.$spc.System.Diagnostics.Debug.Assert$1($.$is(node._tail, $.$sl.System.Linq.Enumerable.Concat2Iterator$$(TSource)), "node._tail is Concat2Iterator<TSource>");
                        return node._tail.Contains(value);
                    }
                    static $h = 1245191;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.ConcatIterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.ConcatNIterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ConcatNIterator$$ = $v))(TSource);
            }
            static $_ConcatIterator$$;
            static ConcatIterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_ConcatIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.ConcatIterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.ConcatIterator<>", [TSource], ($self) => class ConcatIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TSource)
                {
                    /*IEnumerator<TSource>?*/ _enumerator = null;
                    /*void */ Dispose()
                    {
                        if (!(this._enumerator === null))
                        {
                            this._enumerator.System$IDisposable$Dispose();
                            this._enumerator = null;
                        }
                        super.Dispose();
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._state === 1)
                        {
                            this._enumerator = this.GetEnumerable(0).System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                            this._state = 2;
                        }
                        if (this._state > 1)
                        {
                            while(true)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._enumerator === null), "_enumerator is not null");
                                if (this._enumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    this._current = this._enumerator.System$Collections$Generic$IEnumerator$$$Current;
                                    return true;
                                }
                                /*IEnumerable<TSource>?*/ let next = this.GetEnumerable(((this._state++ - 1) | 0));
                                if (!(next === null))
                                {
                                    this._enumerator.System$IDisposable$Dispose();
                                    this._enumerator = next.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                                    continue;
                                }
                                this.Dispose();
                                break;
                            }
                        }
                        return false;
                    }
                    /*List<TSource> */ ToList()
                    {
                        /*int*/ let count = this.GetCount(true);
                        /*var*/ let list = count !== -1 ? new ($.$spc.System.Collections.Generic.List$$(TSource))().$ctor$2(count) : new ($.$spc.System.Collections.Generic.List$$(TSource))().$ctor$1();
                        for(/*int*/ let i = 0; ; i++)
                        {
                            /*IEnumerable<TSource>?*/ let source = this.GetEnumerable(i);
                            if (source === null)
                            {
                                break;
                            }
                            list.AddRange(source);
                        }
                        return list;
                    }
                    //default reference type constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        return this;
                    }
                    static $h = 1179655;
                    static $g = 1;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.ConcatIterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ConcatIterator$$ = $v))(TSource);
            }
            static /*bool */ Contains(TSource, /*this IEnumerable<TSource>*/ source, /*TSource*/ value)
            {
                let collection;
                if ($.$is(source, $.$spc.System.Collections.Generic.ICollection$$(TSource), { set $v(v){ collection = v; } }))
                {
                    return collection.System$Collections$Generic$ICollection$$$Contains(value, [TSource]);
                }
                let iterator;
                if (!$.$sl.System.Linq.Enumerable.IsSizeOptimized && $.$is(source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }))
                {
                    return iterator.Contains(value);
                }
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                return $.$sl.System.Linq.Enumerable.ContainsIterate(TSource, source, value, null);
            }
            static /*bool */ Contains$1(TSource, /*this IEnumerable<TSource>*/ source, /*TSource*/ value, /*IEqualityComparer<TSource>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*ReadOnlySpan<TSource>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan(TSource, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(TSource))))
                {
                    return $.$spc.System.MemoryExtensions.Contains$2(TSource, span, value, comparer);
                }
                return $.$sl.System.Linq.Enumerable.ContainsIterate(TSource, source, value, comparer);
            }
            static /*bool */ ContainsIterate(TSource, /*IEnumerable<TSource>*/ source, /*TSource*/ value, /*IEqualityComparer<TSource>?*/ comparer)
            {
                if (comparer === null)
                {
                    if (TSource.$type.IsValueType)
                    {
                        var $en4 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var element = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if ($.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default.Equals$2(element, value))
                                {
                                    return true;
                                }
                            }
                        }
                        return false;
                    }
                    comparer = $.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default;
                }
                var $en2 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var element = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (comparer.System$Collections$Generic$IEqualityComparer$$$Equals(element, value, [TSource]))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
            static /*IEnumerable<KeyValuePair<TKey, TAccumulate>> */ AggregateBy(TSource, TKey, TAccumulate, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*TAccumulate*/ seed, /*Func<TAccumulate, TSource, TAccumulate>*/ func, /*IEqualityComparer<TKey>?*/ keyComparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                if (func === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(5/*ExceptionArgument.func*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate).$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.AggregateByIterator(TSource, TKey, TAccumulate, source, keySelector, seed, func, keyComparer);
            }
            static /*IEnumerable<KeyValuePair<TKey, TAccumulate>> */ AggregateBy$1(TSource, TKey, TAccumulate, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TKey, TAccumulate>*/ seedSelector, /*Func<TAccumulate, TSource, TAccumulate>*/ func, /*IEqualityComparer<TKey>?*/ keyComparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                if (seedSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(15/*ExceptionArgument.seedSelector*/);
                }
                if (func === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(5/*ExceptionArgument.func*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Collections.Generic.KeyValuePair$$$(TKey, TAccumulate).$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.AggregateByIterator$1(TSource, TKey, TAccumulate, source, keySelector, seedSelector, func, keyComparer);
            }
            static /*IEnumerable<KeyValuePair<TKey, TAccumulate>> */ AggregateByIterator(TSource, TKey, TAccumulate, /*IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*TAccumulate*/ seed, /*Func<TAccumulate, TSource, TAccumulate>*/ func, /*IEqualityComparer<TKey>?*/ keyComparer)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*IEnumerator<TSource>*/ let enumerator = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    try
                    {
                        if (!enumerator.System$Collections$IEnumerator$MoveNext())
                        {
                            return;
                        }
                        var $en4 = PopulateDictionary(enumerator, keySelector, seed, func, keyComparer).GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var countBy = $en4.Current;
                            {
                                yield countBy;
                            }
                        }
                        /*static Dictionary<TKey, TAccumulate>*/  function PopulateDictionary(/*IEnumerator<TSource>*/ enumerator, /*Func<TSource, TKey>*/ keySelector, /*TAccumulate*/ seed, /*Func<TAccumulate, TSource, TAccumulate>*/ func, /*IEqualityComparer<TKey>?*/ keyComparer)
                        {
                            /*Dictionary<TKey, TAccumulate>*/ let dict = new ($.$spc.System.Collections.Generic.Dictionary$$$(TKey, TAccumulate))().$ctor$3(keyComparer);
                            do
                            {
                                /*TSource*/ let value = enumerator.System$Collections$Generic$IEnumerator$$$Current;
                                /*TKey*/ let key = keySelector.Invoke(value);
                                /*bool*/ let exists;
                                /*ref TAccumulate?*/ let acc = $.$spc.System.Runtime.InteropServices.CollectionsMarshal.GetValueRefOrAddDefault(TKey, TAccumulate, dict, key, $.$ref(() => exists, ($v) => exists = $v, $.$spc.System.Boolean));
                                acc.$v = func.Invoke(exists ? acc.$v : seed, value);
                            }
                            while(enumerator.System$Collections$IEnumerator$MoveNext());
                            return dict;
                        }
                    }
                    finally
                    {
                        enumerator?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            static /*IEnumerable<KeyValuePair<TKey, TAccumulate>> */ AggregateByIterator$1(TSource, TKey, TAccumulate, /*IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TKey, TAccumulate>*/ seedSelector, /*Func<TAccumulate, TSource, TAccumulate>*/ func, /*IEqualityComparer<TKey>?*/ keyComparer)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*IEnumerator<TSource>*/ let enumerator = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    try
                    {
                        if (!enumerator.System$Collections$IEnumerator$MoveNext())
                        {
                            return;
                        }
                        var $en4 = PopulateDictionary(enumerator, keySelector, seedSelector, func, keyComparer).GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var countBy = $en4.Current;
                            {
                                yield countBy;
                            }
                        }
                        /*static Dictionary<TKey, TAccumulate>*/  function PopulateDictionary(/*IEnumerator<TSource>*/ enumerator, /*Func<TSource, TKey>*/ keySelector, /*Func<TKey, TAccumulate>*/ seedSelector, /*Func<TAccumulate, TSource, TAccumulate>*/ func, /*IEqualityComparer<TKey>?*/ keyComparer)
                        {
                            /*Dictionary<TKey, TAccumulate>*/ let dict = new ($.$spc.System.Collections.Generic.Dictionary$$$(TKey, TAccumulate))().$ctor$3(keyComparer);
                            do
                            {
                                /*TSource*/ let value = enumerator.System$Collections$Generic$IEnumerator$$$Current;
                                /*TKey*/ let key = keySelector.Invoke(value);
                                /*bool*/ let exists;
                                /*ref TAccumulate?*/ let acc = $.$spc.System.Runtime.InteropServices.CollectionsMarshal.GetValueRefOrAddDefault(TKey, TAccumulate, dict, key, $.$ref(() => exists, ($v) => exists = $v, $.$spc.System.Boolean));
                                acc.$v = func.Invoke(exists ? acc.$v : seedSelector.Invoke(key), value);
                            }
                            while(enumerator.System$Collections$IEnumerator$MoveNext());
                            return dict;
                        }
                    }
                    finally
                    {
                        enumerator?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            static /*IEnumerable<KeyValuePair<TKey, int>> */ CountBy(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ keyComparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Collections.Generic.KeyValuePair$$$(TKey, $.$spc.System.Int32).$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.CountByIterator(TSource, TKey, source, keySelector, keyComparer);
            }
            static /*IEnumerable<KeyValuePair<TKey, int>> */ CountByIterator(TSource, TKey, /*IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ keyComparer)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*IEnumerator<TSource>*/ let enumerator = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    try
                    {
                        if (!enumerator.System$Collections$IEnumerator$MoveNext())
                        {
                            return;
                        }
                        var $en4 = $.$sl.System.Linq.Enumerable.BuildCountDictionary(TSource, TKey, enumerator, keySelector, keyComparer).GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var countBy = $en4.Current;
                            {
                                yield countBy;
                            }
                        }
                    }
                    finally
                    {
                        enumerator?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            static /*Dictionary<TKey, int> */ BuildCountDictionary(TSource, TKey, /*IEnumerator<TSource>*/ enumerator, /*Func<TSource, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ keyComparer)
            {
                /*Dictionary<TKey, int>*/ let countsBy = new ($.$spc.System.Collections.Generic.Dictionary$$$(TKey, $.$spc.System.Int32))().$ctor$3(keyComparer);
                do
                {
                    /*TSource*/ let value = enumerator.System$Collections$Generic$IEnumerator$$$Current;
                    /*TKey*/ let key = keySelector.Invoke(value);
                    /*ref int*/ let currentCount = $.$spc.System.Runtime.InteropServices.CollectionsMarshal.GetValueRefOrAddDefault(TKey, $.$spc.System.Int32, countsBy, key, $.$discardRef());
                    //checked
                    {
                        currentCount.$v++;
                    }
                }
                while(enumerator.System$Collections$IEnumerator$MoveNext());
                return countsBy;
            }
            static /*int */ Count(TSource, /*this IEnumerable<TSource>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                let collectionoft;
                if ($.$is(source, $.$spc.System.Collections.Generic.ICollection$$(TSource), { set $v(v){ collectionoft = v; } }))
                {
                    return collectionoft.System$Collections$Generic$ICollection$$$Count;
                }
                let iterator;
                if ($.$is(source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }))
                {
                    return iterator.GetCount(false);
                }
                let collection;
                if ($.$is(source, $.$spc.System.Collections.ICollection, { set $v(v){ collection = v; } }))
                {
                    return collection.System$Collections$ICollection$Count;
                }
                /*int*/ let count = 0;
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    //checked
                    {
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            count++;
                        }
                    }
                    return count;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*int */ Count$1(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (predicate === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.predicate*/);
                }
                /*int*/ let count = 0;
                /*ReadOnlySpan<TSource>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan(TSource, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(TSource))))
                {
                    var $en3 = span.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var element = $en3.Current.$v;
                        {
                            if (predicate.Invoke(element))
                            {
                                count++;
                            }
                        }
                    }
                }
                else 
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (predicate.Invoke(element))
                            {
                                //checked
                                {
                                    count++;
                                }
                            }
                        }
                    }
                }
                return count;
            }
            static /*bool */ TryGetNonEnumeratedCount(TSource, /*this IEnumerable<TSource>*/ source, /*out int*/ count)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                let collectionoft;
                if ($.$is(source, $.$spc.System.Collections.Generic.ICollection$$(TSource), { set $v(v){ collectionoft = v; } }))
                {
                    count.$v = collectionoft.System$Collections$Generic$ICollection$$$Count;
                    return true;
                }
                let iterator;
                if ($.$is(source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }))
                {
                    /*int*/ let c = iterator.GetCount(true);
                    if (c >= 0)
                    {
                        count.$v = c;
                        return true;
                    }
                }
                let collection;
                if ($.$is(source, $.$spc.System.Collections.ICollection, { set $v(v){ collection = v; } }))
                {
                    count.$v = collection.System$Collections$ICollection$Count;
                    return true;
                }
                count.$v = 0;
                return false;
            }
            static /*long */ LongCount(TSource, /*this IEnumerable<TSource>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*long*/ let count = 0n;
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        //checked
                        {
                            count++;
                        }
                    }
                    return count;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*long */ LongCount$1(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (predicate === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.predicate*/);
                }
                /*long*/ let count = 0n;
                var $en2 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var element = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (predicate.Invoke(element))
                        {
                            //checked
                            {
                                count++;
                            }
                        }
                    }
                }
                return count;
            }
            static /*IEnumerable<TSource?> */ DefaultIfEmpty(TSource, /*this IEnumerable<TSource>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.DefaultIfEmpty$1(TSource, source, $.$default(TSource));
            }
            static /*IEnumerable<TSource> */ DefaultIfEmpty$1(TSource, /*this IEnumerable<TSource>*/ source, /*TSource*/ defaultValue)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (source !== null && ($.$is(source, $.$typeArray(TSource)) && source.length > 0))
                {
                    return source;
                }
                return new ($.$sl.System.Linq.Enumerable.DefaultIfEmptyIterator$$(TSource))().$ctor$2(source, defaultValue);
            }
            static $_DefaultIfEmptyIterator$$;
            static DefaultIfEmptyIterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_DefaultIfEmptyIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.DefaultIfEmptyIterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.DefaultIfEmptyIterator<>", [TSource], ($self) => class DefaultIfEmptyIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TSource)
                {
                    /*IEnumerable<TSource>*/ _source = null;
                    /*TSource*/ _default = $.$default(TSource);
                    /*IEnumerator<TSource>?*/ _enumerator = null;
                    $ctor$2(/*IEnumerable<TSource>*/ source, /*TSource*/ defaultValue)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            this._source = source;
                            this._default = defaultValue;
                        }
                        return this;
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.DefaultIfEmptyIterator$$(TSource))().$ctor$2(this._source, this._default);
                    }
                    /*bool */ MoveNext()
                    {
                        switch(this._state)
                        {
                            case 1:
                            this._enumerator = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                            if (this._enumerator.System$Collections$IEnumerator$MoveNext())
                            {
                                this._current = this._enumerator.System$Collections$Generic$IEnumerator$$$Current;
                                this._state = 2;
                            }
                            else 
                            {
                                this._current = this._default;
                                this._state = -1;
                            }
                            return true;
                            case 2:
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(this._enumerator === null), "_enumerator is not null");
                            if (this._enumerator.System$Collections$IEnumerator$MoveNext())
                            {
                                this._current = this._enumerator.System$Collections$Generic$IEnumerator$$$Current;
                                return true;
                            }
                            break;
                        }
                        this.Dispose();
                        return false;
                    }
                    /*void */ Dispose()
                    {
                        if (!(this._enumerator === null))
                        {
                            this._enumerator.System$IDisposable$Dispose();
                            this._enumerator = null;
                        }
                        super.Dispose();
                    }
                    /*TSource[] */ ToArray()
                    {
                        /*TSource[]*/ let array = $.$sl.System.Linq.Enumerable.ToArray(TSource, this._source);
                        return array.length === 0 ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [ this._default ], null, null) : array;
                    }
                    /*List<TSource> */ ToList()
                    {
                        /*List<TSource>*/ let list = $.$sl.System.Linq.Enumerable.ToList(TSource, this._source);
                        if (list.Count === 0)
                        {
                            list.Add(this._default);
                        }
                        return list;
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        /*int*/ let count;
                        if (!onlyIfCheap || $.$is(this._source, $.$spc.System.Collections.Generic.ICollection$$(TSource)) || $.$is(this._source, $.$spc.System.Collections.ICollection))
                        {
                            count = $.$sl.System.Linq.Enumerable.Count(TSource, this._source);
                        }
                        else 
                        {
                            let iterator;
                            count = $.$is(this._source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }) ? iterator.GetCount(true) : -1;
                        }
                        return count === 0 ? 1 : count;
                    }
                    /*TSource? */ TryGetFirst(/*out bool*/ found)
                    {
                        /*TSource?*/ let first = $.$sl.System.Linq.Enumerable.TryGetFirst(TSource, this._source, found);
                        if (found.$v)
                        {
                            return first;
                        }
                        found.$v = true;
                        return this._default;
                    }
                    /*TSource? */ TryGetLast(/*out bool*/ found)
                    {
                        /*TSource?*/ let last = $.$sl.System.Linq.Enumerable.TryGetLast(TSource, this._source, found);
                        if (found.$v)
                        {
                            return last;
                        }
                        found.$v = true;
                        return this._default;
                    }
                    /*TSource? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        /*TSource?*/ let item = $.$sl.System.Linq.Enumerable.TryGetElementAt(TSource, this._source, index, found);
                        if (found.$v)
                        {
                            return item;
                        }
                        if (index === 0)
                        {
                            found.$v = true;
                            return this._default;
                        }
                        return $.$default(TSource);
                    }
                    /*bool */ Contains(/*TSource*/ value)
                    {
                        /*int*/ let count;
                        if ($.$sl.System.Linq.Enumerable.TryGetNonEnumeratedCount(TSource, this._source, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32)))
                        {
                            return count > 0 ? $.$sl.System.Linq.Enumerable.Contains(TSource, this._source, value) : $.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default.Equals$2(value, this._default);
                        }
                        /*IEnumerator<TSource>*/ let enumerator = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                        try
                        {
                            if (!enumerator.System$Collections$IEnumerator$MoveNext())
                            {
                                return $.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default.Equals$2(value, this._default);
                            }
                            do
                            {
                                if ($.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default.Equals$2(enumerator.System$Collections$Generic$IEnumerator$$$Current, value))
                                {
                                    return true;
                                }
                            }
                            while(enumerator.System$Collections$IEnumerator$MoveNext());
                            return false;
                        }
                        finally
                        {
                            {
                                enumerator.System$IDisposable$Dispose();
                            }
                        }
                    }
                    static $h = 1310727;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.DefaultIfEmptyIterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_DefaultIfEmptyIterator$$ = $v))(TSource);
            }
            static /*IEnumerable<TSource> */ Distinct(TSource, /*this IEnumerable<TSource>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Distinct$1(TSource, source, null);
            }
            static /*IEnumerable<TSource> */ Distinct$1(TSource, /*this IEnumerable<TSource>*/ source, /*IEqualityComparer<TSource>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                }
                return new ($.$sl.System.Linq.Enumerable.DistinctIterator$$(TSource))().$ctor$2(source, comparer);
            }
            static /*IEnumerable<TSource> */ DistinctBy(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector)
            {
                return $.$sl.System.Linq.Enumerable.DistinctBy$1(TSource, TKey, source, keySelector, null);
            }
            static /*IEnumerable<TSource> */ DistinctBy$1(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.DistinctByIterator(TSource, TKey, source, keySelector, comparer);
            }
            static /*IEnumerable<TSource> */ DistinctByIterator(TSource, TKey, /*IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*IEnumerator<TSource>*/ let enumerator = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    try
                    {
                        if (enumerator.System$Collections$IEnumerator$MoveNext())
                        {
                            /*var*/ let set = new ($.$spc.System.Collections.Generic.HashSet$$(TKey))().$ctor$6(7/*DefaultInternalSetCapacity*/, comparer);
                            do
                            {
                                /*TSource*/ let element = enumerator.System$Collections$Generic$IEnumerator$$$Current;
                                if (set.Add(keySelector.Invoke(element)))
                                {
                                    yield element;
                                }
                            }
                            while(enumerator.System$Collections$IEnumerator$MoveNext());
                        }
                    }
                    finally
                    {
                        enumerator?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            static $_DistinctIterator$$;
            static DistinctIterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_DistinctIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.DistinctIterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.DistinctIterator<>", [TSource], ($self) => class DistinctIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TSource)
                {
                    /*IEnumerable<TSource>*/ _source = null;
                    /*IEqualityComparer<TSource>?*/ _comparer = null;
                    /*HashSet<TSource>?*/ _set = null;
                    /*IEnumerator<TSource>?*/ _enumerator = null;
                    $ctor$2(/*IEnumerable<TSource>*/ source, /*IEqualityComparer<TSource>?*/ comparer)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            this._source = source;
                            this._comparer = comparer;
                        }
                        return this;
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.DistinctIterator$$(TSource))().$ctor$2(this._source, this._comparer);
                    }
                    /*bool */ MoveNext()
                    {
                        switch(this._state)
                        {
                            case 1:
                            this._enumerator = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                            if (!this._enumerator.System$Collections$IEnumerator$MoveNext())
                            {
                                this.Dispose();
                                return false;
                            }
                            /*TSource*/ let element = this._enumerator.System$Collections$Generic$IEnumerator$$$Current;
                            this._set = new ($.$spc.System.Collections.Generic.HashSet$$(TSource))().$ctor$6(7/*DefaultInternalSetCapacity*/, this._comparer);
                            this._set.Add(element);
                            this._current = element;
                            this._state = 2;
                            return true;
                            case 2:
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(this._enumerator === null), "_enumerator is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(this._set === null), "_set is not null");
                            while(this._enumerator.System$Collections$IEnumerator$MoveNext())
                            {
                                element = this._enumerator.System$Collections$Generic$IEnumerator$$$Current;
                                if (this._set.Add(element))
                                {
                                    this._current = element;
                                    return true;
                                }
                            }
                            break;
                        }
                        this.Dispose();
                        return false;
                    }
                    /*void */ Dispose()
                    {
                        if (!(this._enumerator === null))
                        {
                            this._enumerator.System$IDisposable$Dispose();
                            this._enumerator = null;
                            this._set = null;
                        }
                        super.Dispose();
                    }
                    /*TSource[] */ ToArray()
                    {
                        return $.$sl.System.Linq.Enumerable.ICollectionToArray(TSource, new ($.$spc.System.Collections.Generic.HashSet$$(TSource))().$ctor$5(this._source, this._comparer));
                    }
                    /*List<TSource> */ ToList()
                    {
                        return new ($.$spc.System.Collections.Generic.List$$(TSource))().$ctor$3(new ($.$spc.System.Collections.Generic.HashSet$$(TSource))().$ctor$5(this._source, this._comparer));
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        return onlyIfCheap ? -1 : new ($.$spc.System.Collections.Generic.HashSet$$(TSource))().$ctor$5(this._source, this._comparer).Count;
                    }
                    /*TSource? */ TryGetFirst(/*out bool*/ found)
                    {
                        return $.$sl.System.Linq.Enumerable.TryGetFirst(TSource, this._source, found);
                    }
                    /*bool */ Contains(/*TSource*/ value)
                    {
                        return this._comparer === null ? $.$sl.System.Linq.Enumerable.Contains(TSource, this._source, value) : super.Contains(value);
                    }
                    static $h = 1376263;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.DistinctIterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_DistinctIterator$$ = $v))(TSource);
            }
            static /*TSource */ ElementAt(TSource, /*this IEnumerable<TSource>*/ source, /*int*/ index)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                let list;
                if ($.$is(source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ list = v; } }))
                {
                    return list.System$Collections$Generic$IList$$$get_Item(index, [TSource]);
                }
                /*bool*/ let found;
                let iterator;
                /*TSource?*/ let element = $.$is(source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }) ? iterator.TryGetElementAt(index, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean)) : $.$sl.System.Linq.Enumerable.TryGetElementAtNonIterator(TSource, source, index, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                if (!found)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.index*/);
                }
                return element;
            }
            static /*TSource */ ElementAt$1(TSource, /*this IEnumerable<TSource>*/ source, /*Index*/ index)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (!index.IsFromEnd)
                {
                    return $.$sl.System.Linq.Enumerable.ElementAt(TSource, source, index.Value);
                }
                /*int*/ let count;
                if ($.$sl.System.Linq.Enumerable.TryGetNonEnumeratedCount(TSource, source, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32)))
                {
                    return $.$sl.System.Linq.Enumerable.ElementAt(TSource, source, ((count - index.Value) | 0));
                }
                /*TSource?*/ let element;
                if (!$.$sl.System.Linq.Enumerable.TryGetElementFromEnd(TSource, source, index.Value, $.$ref(() => element, ($v) => element = $v, TSource)))
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.index*/);
                }
                return element;
            }
            static /*TSource? */ ElementAtOrDefault(TSource, /*this IEnumerable<TSource>*/ source, /*int*/ index)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                return $.$sl.System.Linq.Enumerable.TryGetElementAt(TSource, source, index, $.$discardRef());
            }
            static /*TSource? */ ElementAtOrDefault$1(TSource, /*this IEnumerable<TSource>*/ source, /*Index*/ index)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (!index.IsFromEnd)
                {
                    return $.$sl.System.Linq.Enumerable.ElementAtOrDefault(TSource, source, index.Value);
                }
                /*int*/ let count;
                if ($.$sl.System.Linq.Enumerable.TryGetNonEnumeratedCount(TSource, source, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32)))
                {
                    return $.$sl.System.Linq.Enumerable.ElementAtOrDefault(TSource, source, ((count - index.Value) | 0));
                }
                /*TSource?*/ let element;
                $.$sl.System.Linq.Enumerable.TryGetElementFromEnd(TSource, source, index.Value, $.$ref(() => element, ($v) => element = $v, TSource));
                return element;
            }
            static /*TSource? */ TryGetElementAt(TSource, /*this IEnumerable<TSource>*/ source, /*int*/ index, /*out bool*/ found)
            {
                let list;
                if ($.$is(source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ list = v; } }))
                {
                    return (found.$v = (index >>> 0) < (list.System$Collections$Generic$ICollection$$$Count >>> 0)).$v ? list.System$Collections$Generic$IList$$$get_Item(index, [TSource]) : $.$default(TSource);
                }
                let iterator;
                return $.$is(source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }) ? iterator.TryGetElementAt(index, found) : $.$sl.System.Linq.Enumerable.TryGetElementAtNonIterator(TSource, source, index, found);
            }
            static /*TSource? */ TryGetElementAtNonIterator(TSource, /*IEnumerable<TSource>*/ source, /*int*/ index, /*out bool*/ found)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                if (index >= 0)
                {
                    /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    try
                    {
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            if (index === 0)
                            {
                                found.$v = true;
                                return e.System$Collections$Generic$IEnumerator$$$Current;
                            }
                            index--;
                        }
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }
                found.$v = false;
                return $.$default(TSource);
            }
            static /*bool */ TryGetElementFromEnd(TSource, /*IEnumerable<TSource>*/ source, /*int*/ indexFromEnd, /*out TSource*/ element)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                if (indexFromEnd > 0)
                {
                    /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    try
                    {
                        if (e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*Queue<TSource>*/ let queue = new ($.$spc.System.Collections.Generic.Queue$$(TSource))().$ctor$1();
                            queue.Enqueue(e.System$Collections$Generic$IEnumerator$$$Current);
                            while(e.System$Collections$IEnumerator$MoveNext())
                            {
                                if (queue.Count === indexFromEnd)
                                {
                                    queue.Dequeue();
                                }
                                queue.Enqueue(e.System$Collections$Generic$IEnumerator$$$Current);
                            }
                            if (queue.Count === indexFromEnd)
                            {
                                element.$v = queue.Dequeue();
                                return true;
                            }
                        }
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }
                element.$v = $.$default(TSource);
                return false;
            }
            /*bool*/ static IsSizeOptimized = false;
            static /*IEnumerable<TSource> */ AsEnumerable(TSource, /*this IEnumerable<TSource>*/ source)
            {
                return source;
            }
            static /*IEnumerable<TResult> */ Empty(TResult, )
            {
                return $.$spc.System.Array.Empty(TResult);
            }
            static /*bool */ IsEmptyArray(TSource, /*IEnumerable<TSource>*/ source)
            {
                return source !== null && ($.$is(source, $.$typeArray(TSource)) && source.length === 0);
            }
            static /*Span<T> */ SetCountAndGetSpan(T, /*List<T>*/ list, /*int*/ count)
            {
                $.$spc.System.Runtime.InteropServices.CollectionsMarshal.SetCount(T, list, count);
                return $.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(T, list);
            }
            static /*bool */ TryGetSpan(TSource, /*this IEnumerable<TSource>*/ source, /*out ReadOnlySpan<TSource>*/ span)
            {
                /*bool*/ let result = true;
                if ($.$spc.System.Type.op_Equality$1($.$spc.System.Object.GetType.call(source), $.$typeArray(TSource).$type))
                {
                    span.$v = $.$spc.System.ReadOnlySpan$$(TSource).op_Implicit(source);
                }
                else if ($.$spc.System.Type.op_Equality$1($.$spc.System.Object.GetType.call(source), $.$spc.System.Collections.Generic.List$$(TSource).$type))
                {
                    span.$v = $.$spc.System.Span$$(TSource).op_Implicit$2($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, source));
                }
                else 
                {
                    span.$v = new ($.$spc.System.ReadOnlySpan$$(TSource))();
                    result = false;
                }
                return result;
            }
            static /*IEnumerable<TSource> */ Except(TSource, /*this IEnumerable<TSource>*/ first, /*IEnumerable<TSource>*/ second)
            {
                if (first === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(4/*ExceptionArgument.first*/);
                }
                if (second === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(14/*ExceptionArgument.second*/);
                }
                return $.$sl.System.Linq.Enumerable.ExceptIterator(TSource, first, second, null);
            }
            static /*IEnumerable<TSource> */ Except$1(TSource, /*this IEnumerable<TSource>*/ first, /*IEnumerable<TSource>*/ second, /*IEqualityComparer<TSource>?*/ comparer)
            {
                if (first === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(4/*ExceptionArgument.first*/);
                }
                if (second === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(14/*ExceptionArgument.second*/);
                }
                return $.$sl.System.Linq.Enumerable.ExceptIterator(TSource, first, second, comparer);
            }
            static /*IEnumerable<TSource> */ ExceptBy(TSource, TKey, /*this IEnumerable<TSource>*/ first, /*IEnumerable<TKey>*/ second, /*Func<TSource, TKey>*/ keySelector)
            {
                return $.$sl.System.Linq.Enumerable.ExceptBy$1(TSource, TKey, first, second, keySelector, null);
            }
            static /*IEnumerable<TSource> */ ExceptBy$1(TSource, TKey, /*this IEnumerable<TSource>*/ first, /*IEnumerable<TKey>*/ second, /*Func<TSource, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (first === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(4/*ExceptionArgument.first*/);
                }
                if (second === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(14/*ExceptionArgument.second*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                return $.$sl.System.Linq.Enumerable.ExceptByIterator(TSource, TKey, first, second, keySelector, comparer);
            }
            static /*IEnumerable<TSource> */ ExceptIterator(TSource, /*IEnumerable<TSource>*/ first, /*IEnumerable<TSource>*/ second, /*IEqualityComparer<TSource>?*/ comparer)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*var*/ let set = new ($.$spc.System.Collections.Generic.HashSet$$(TSource))().$ctor$5(second, comparer);
                    var $en3 = first.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (set.Add(element))
                            {
                                yield element;
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<TSource> */ ExceptByIterator(TSource, TKey, /*IEnumerable<TSource>*/ first, /*IEnumerable<TKey>*/ second, /*Func<TSource, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*var*/ let set = new ($.$spc.System.Collections.Generic.HashSet$$(TKey))().$ctor$5(second, comparer);
                    var $en3 = first.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (set.Add(keySelector.Invoke(element)))
                            {
                                yield element;
                            }
                        }
                    }
                }.bind(this));
            }
            static /*TSource */ First(TSource, /*this IEnumerable<TSource>*/ source)
            {
                /*bool*/ let found;
                /*TSource?*/ let first = $.$sl.System.Linq.Enumerable.TryGetFirst(TSource, source, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                if (!found)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                }
                return first;
            }
            static /*TSource */ First$1(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
            {
                /*bool*/ let found;
                /*TSource?*/ let first = $.$sl.System.Linq.Enumerable.TryGetFirst$1(TSource, source, predicate, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                if (!found)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowNoMatchException();
                }
                return first;
            }
            static /*TSource? */ FirstOrDefault(TSource, /*this IEnumerable<TSource>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.TryGetFirst(TSource, source, $.$discardRef());
            }
            static /*TSource */ FirstOrDefault$1(TSource, /*this IEnumerable<TSource>*/ source, /*TSource*/ defaultValue)
            {
                /*bool*/ let found;
                /*TSource?*/ let first = $.$sl.System.Linq.Enumerable.TryGetFirst(TSource, source, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                return found ? first : defaultValue;
            }
            static /*TSource? */ FirstOrDefault$2(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
            {
                return $.$sl.System.Linq.Enumerable.TryGetFirst$1(TSource, source, predicate, $.$discardRef());
            }
            static /*TSource */ FirstOrDefault$3(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate, /*TSource*/ defaultValue)
            {
                /*bool*/ let found;
                /*TSource?*/ let first = $.$sl.System.Linq.Enumerable.TryGetFirst$1(TSource, source, predicate, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                return found ? first : defaultValue;
            }
            static /*TSource? */ TryGetFirst(TSource, /*this IEnumerable<TSource>*/ source, /*out bool*/ found)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                let iterator;
                return !$.$sl.System.Linq.Enumerable.IsSizeOptimized && $.$is(source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }) ? iterator.TryGetFirst(found) : $.$sl.System.Linq.Enumerable.TryGetFirstNonIterator(TSource, source, found);
            }
            static /*TSource? */ TryGetFirstNonIterator(TSource, /*IEnumerable<TSource>*/ source, /*out bool*/ found)
            {
                let list;
                if ($.$is(source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ list = v; } }))
                {
                    if (list.System$Collections$Generic$ICollection$$$Count > 0)
                    {
                        found.$v = true;
                        return list.System$Collections$Generic$IList$$$get_Item(0, [TSource]);
                    }
                }
                else 
                {
                    /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    try
                    {
                        if (e.System$Collections$IEnumerator$MoveNext())
                        {
                            found.$v = true;
                            return e.System$Collections$Generic$IEnumerator$$$Current;
                        }
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }
                found.$v = false;
                return $.$default(TSource);
            }
            static /*TSource? */ TryGetFirst$1(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate, /*out bool*/ found)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (predicate === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.predicate*/);
                }
                /*ReadOnlySpan<TSource>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan(TSource, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(TSource))))
                {
                    var $en3 = span.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var element = $en3.Current.$v;
                        {
                            if (predicate.Invoke(element))
                            {
                                found.$v = true;
                                return element;
                            }
                        }
                    }
                }
                else 
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (predicate.Invoke(element))
                            {
                                found.$v = true;
                                return element;
                            }
                        }
                    }
                }
                found.$v = false;
                return $.$default(TSource);
            }
            static /*IEnumerable<IGrouping<TKey, TSource>> */ GroupBy(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector)
            {
                return $.$sl.System.Linq.Enumerable.GroupBy$1(TSource, TKey, source, keySelector, null);
            }
            static /*IEnumerable<IGrouping<TKey, TSource>> */ GroupBy$1(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$sl.System.Linq.IGrouping$$$(TKey, TSource).$type, [  ], null, null);
                }
                return new ($.$sl.System.Linq.Enumerable.GroupByIterator$$$(TSource, TKey))().$ctor$2(source, keySelector, comparer);
            }
            static /*IEnumerable<IGrouping<TKey, TElement>> */ GroupBy$2(TSource, TKey, TElement, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TSource, TElement>*/ elementSelector)
            {
                return $.$sl.System.Linq.Enumerable.GroupBy$3(TSource, TKey, TElement, source, keySelector, elementSelector, null);
            }
            static /*IEnumerable<IGrouping<TKey, TElement>> */ GroupBy$3(TSource, TKey, TElement, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TSource, TElement>*/ elementSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                if (elementSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.elementSelector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$sl.System.Linq.IGrouping$$$(TKey, TElement).$type, [  ], null, null);
                }
                return new ($.$sl.System.Linq.Enumerable.GroupByIterator$$$$(TSource, TKey, TElement))().$ctor$2(source, keySelector, elementSelector, comparer);
            }
            static /*IEnumerable<TResult> */ GroupBy$4(TSource, TKey, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TKey, IEnumerable<TSource>, TResult>*/ resultSelector)
            {
                return $.$sl.System.Linq.Enumerable.GroupBy$5(TSource, TKey, TResult, source, keySelector, resultSelector, null);
            }
            static /*IEnumerable<TResult> */ GroupBy$5(TSource, TKey, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TKey, IEnumerable<TSource>, TResult>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                if (resultSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(13/*ExceptionArgument.resultSelector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                }
                return new ($.$sl.System.Linq.Enumerable.GroupByResultIterator$$$$(TSource, TKey, TResult))().$ctor$2(source, keySelector, resultSelector, comparer);
            }
            static /*IEnumerable<TResult> */ GroupBy$6(TSource, TKey, TElement, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TSource, TElement>*/ elementSelector, /*Func<TKey, IEnumerable<TElement>, TResult>*/ resultSelector)
            {
                return $.$sl.System.Linq.Enumerable.GroupBy$7(TSource, TKey, TElement, TResult, source, keySelector, elementSelector, resultSelector, null);
            }
            static /*IEnumerable<TResult> */ GroupBy$7(TSource, TKey, TElement, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TSource, TElement>*/ elementSelector, /*Func<TKey, IEnumerable<TElement>, TResult>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                if (elementSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.elementSelector*/);
                }
                if (resultSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(13/*ExceptionArgument.resultSelector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                }
                return new ($.$sl.System.Linq.Enumerable.GroupByResultIterator$$$$$(TSource, TKey, TElement, TResult))().$ctor$2(source, keySelector, elementSelector, resultSelector, comparer);
            }
            static $_GroupByResultIterator$$$$$;
            static GroupByResultIterator$$$$$(TSource, TKey, TElement, TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_GroupByResultIterator$$$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.GroupByResultIterator<,,,>", (TSource, TKey, TElement, TResult) => $asm.$gt("$sl.System.Linq.Enumerable.GroupByResultIterator<,,,>", [TSource, TKey, TElement, TResult], ($self) => class GroupByResultIterator$$$$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*IEnumerable<TSource>*/ _source = null;
                    /*Func<TSource, TKey>*/ _keySelector = null;
                    /*Func<TSource, TElement>*/ _elementSelector = null;
                    /*IEqualityComparer<TKey>?*/ _comparer = null;
                    /*Func<TKey, IEnumerable<TElement>, TResult>*/ _resultSelector = null;
                    /*Lookup<TKey, TElement>?*/ _lookup = null;
                    /*Grouping<TKey, TElement>?*/ _g = null;
                    $ctor$2(/*IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TSource, TElement>*/ elementSelector, /*Func<TKey, IEnumerable<TElement>, TResult>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
                    {
                        super.$ctor$1();
                        {
                            this._source = source;
                            this._keySelector = keySelector;
                            this._elementSelector = elementSelector;
                            this._comparer = comparer;
                            this._resultSelector = resultSelector;
                        }
                        return this;
                    }
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.GroupByResultIterator$$$$$(TSource, TKey, TElement, TResult))().$ctor$2(this._source, this._keySelector, this._elementSelector, this._resultSelector, this._comparer);
                    }
                    /*bool */ MoveNext()
                    {
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    switch(this._state)
                                    {
                                        case 1:
                                        this._lookup = $.$sl.System.Linq.Lookup$$$(TKey, TElement).Create(TSource, this._source, this._keySelector, this._elementSelector, this._comparer);
                                        this._g = this._lookup._lastGrouping;
                                        if (!(this._g === null))
                                        {
                                            this._state = 2;
                                            $gotoJumpState1 = 1; /*goto ValidItem*/
                                            continue $gotoJumpStart1;
                                        }
                                        break;
                                        case 2:
                                        $.$spc.System.Diagnostics.Debug.Assert$1(!(this._g === null), "_g is not null");
                                        $.$spc.System.Diagnostics.Debug.Assert$1(!(this._lookup === null), "_lookup is not null");
                                        if (this._g !== this._lookup._lastGrouping)
                                        {
                                            $gotoJumpState1 = 1; /*goto ValidItem*/
                                            continue $gotoJumpStart1;
                                        }
                                        break;
                                    }
                                    this.Dispose();
                                    return false;
                                }
                                case 1: /*ValidItem*/
                                this._g = this._g._next;
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._g === null), "_g is not null");
                                this._g.Trim();
                                this._current = this._resultSelector.Invoke(this._g.Key, this._g._elements);
                                return true;
                            }
                            break;
                        }
                    }
                    /*TResult[] */ ToArray()
                    {
                        return $.$sl.System.Linq.Lookup$$$(TKey, TElement).Create(TSource, this._source, this._keySelector, this._elementSelector, this._comparer).ToArray(TResult, this._resultSelector);
                    }
                    /*List<TResult> */ ToList()
                    {
                        return $.$sl.System.Linq.Lookup$$$(TKey, TElement).Create(TSource, this._source, this._keySelector, this._elementSelector, this._comparer).ToList(TResult, this._resultSelector);
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        return onlyIfCheap ? -1 : $.$sl.System.Linq.Lookup$$$(TKey, TElement).Create(TSource, this._source, this._keySelector, this._elementSelector, this._comparer).Count;
                    }
                    static $h = 1703943;
                    static $g = 4;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":4,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.GroupByResultIterator<${TSource?.$fullName},${TKey?.$fullName},${TElement?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_GroupByResultIterator$$$$$ = $v))(TSource, TKey, TElement, TResult);
            }
            static $_GroupByResultIterator$$$$;
            static GroupByResultIterator$$$$(TSource, TKey, TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_GroupByResultIterator$$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.GroupByResultIterator<,,>", (TSource, TKey, TResult) => $asm.$gt("$sl.System.Linq.Enumerable.GroupByResultIterator<,,>", [TSource, TKey, TResult], ($self) => class GroupByResultIterator$$$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*IEnumerable<TSource>*/ _source = null;
                    /*Func<TSource, TKey>*/ _keySelector = null;
                    /*IEqualityComparer<TKey>?*/ _comparer = null;
                    /*Func<TKey, IEnumerable<TSource>, TResult>*/ _resultSelector = null;
                    /*Lookup<TKey, TSource>?*/ _lookup = null;
                    /*Grouping<TKey, TSource>?*/ _g = null;
                    $ctor$2(/*IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TKey, IEnumerable<TSource>, TResult>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
                    {
                        super.$ctor$1();
                        {
                            this._source = source;
                            this._keySelector = keySelector;
                            this._resultSelector = resultSelector;
                            this._comparer = comparer;
                        }
                        return this;
                    }
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.GroupByResultIterator$$$$(TSource, TKey, TResult))().$ctor$2(this._source, this._keySelector, this._resultSelector, this._comparer);
                    }
                    /*bool */ MoveNext()
                    {
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    switch(this._state)
                                    {
                                        case 1:
                                        this._lookup = $.$sl.System.Linq.Lookup$$$(TKey, TSource).Create$1(this._source, this._keySelector, this._comparer);
                                        this._g = this._lookup._lastGrouping;
                                        if (!(this._g === null))
                                        {
                                            this._state = 2;
                                            $gotoJumpState1 = 1; /*goto ValidItem*/
                                            continue $gotoJumpStart1;
                                        }
                                        break;
                                        case 2:
                                        $.$spc.System.Diagnostics.Debug.Assert$1(!(this._g === null), "_g is not null");
                                        $.$spc.System.Diagnostics.Debug.Assert$1(!(this._lookup === null), "_lookup is not null");
                                        if (this._g !== this._lookup._lastGrouping)
                                        {
                                            $gotoJumpState1 = 1; /*goto ValidItem*/
                                            continue $gotoJumpStart1;
                                        }
                                        break;
                                    }
                                    this.Dispose();
                                    return false;
                                }
                                case 1: /*ValidItem*/
                                this._g = this._g._next;
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._g === null), "_g is not null");
                                this._g.Trim();
                                this._current = this._resultSelector.Invoke(this._g.Key, this._g._elements);
                                return true;
                            }
                            break;
                        }
                    }
                    /*TResult[] */ ToArray()
                    {
                        return $.$sl.System.Linq.Lookup$$$(TKey, TSource).Create$1(this._source, this._keySelector, this._comparer).ToArray(TResult, this._resultSelector);
                    }
                    /*List<TResult> */ ToList()
                    {
                        return $.$sl.System.Linq.Lookup$$$(TKey, TSource).Create$1(this._source, this._keySelector, this._comparer).ToList(TResult, this._resultSelector);
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        return onlyIfCheap ? -1 : $.$sl.System.Linq.Lookup$$$(TKey, TSource).Create$1(this._source, this._keySelector, this._comparer).Count;
                    }
                    static $h = 1769479;
                    static $g = 3;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":3,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.GroupByResultIterator<${TSource?.$fullName},${TKey?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_GroupByResultIterator$$$$ = $v))(TSource, TKey, TResult);
            }
            static $_GroupByIterator$$$$;
            static GroupByIterator$$$$(TSource, TKey, TElement)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_GroupByIterator$$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.GroupByIterator<,,>", (TSource, TKey, TElement) => $asm.$gt("$sl.System.Linq.Enumerable.GroupByIterator<,,>", [TSource, TKey, TElement], ($self) => class GroupByIterator$$$$ extends $.$sl.System.Linq.Enumerable.Iterator$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement))
                {
                    /*IEnumerable<TSource>*/ _source = null;
                    /*Func<TSource, TKey>*/ _keySelector = null;
                    /*Func<TSource, TElement>*/ _elementSelector = null;
                    /*IEqualityComparer<TKey>?*/ _comparer = null;
                    /*Lookup<TKey, TElement>?*/ _lookup = null;
                    /*Grouping<TKey, TElement>?*/ _g = null;
                    $ctor$2(/*IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TSource, TElement>*/ elementSelector, /*IEqualityComparer<TKey>?*/ comparer)
                    {
                        super.$ctor$1();
                        {
                            this._source = source;
                            this._keySelector = keySelector;
                            this._elementSelector = elementSelector;
                            this._comparer = comparer;
                        }
                        return this;
                    }
                    /*Iterator<IGrouping<TKey, TElement>> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.GroupByIterator$$$$(TSource, TKey, TElement))().$ctor$2(this._source, this._keySelector, this._elementSelector, this._comparer);
                    }
                    /*bool */ MoveNext()
                    {
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    switch(this._state)
                                    {
                                        case 1:
                                        this._lookup = $.$sl.System.Linq.Lookup$$$(TKey, TElement).Create(TSource, this._source, this._keySelector, this._elementSelector, this._comparer);
                                        this._g = this._lookup._lastGrouping;
                                        if (!(this._g === null))
                                        {
                                            this._state = 2;
                                            $gotoJumpState1 = 1; /*goto ValidItem*/
                                            continue $gotoJumpStart1;
                                        }
                                        break;
                                        case 2:
                                        $.$spc.System.Diagnostics.Debug.Assert$1(!(this._g === null), "_g is not null");
                                        $.$spc.System.Diagnostics.Debug.Assert$1(!(this._lookup === null), "_lookup is not null");
                                        if (this._g !== this._lookup._lastGrouping)
                                        {
                                            $gotoJumpState1 = 1; /*goto ValidItem*/
                                            continue $gotoJumpStart1;
                                        }
                                        break;
                                    }
                                    this.Dispose();
                                    return false;
                                }
                                case 1: /*ValidItem*/
                                this._g = this._g._next;
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._g === null), "_g is not null");
                                this._current = this._g;
                                return true;
                            }
                            break;
                        }
                    }
                    /*IGrouping<TKey, TElement>[] */ ToArray()
                    {
                        return $.$sl.System.Linq.Enumerable.ToArray($.$sl.System.Linq.IGrouping$$$(TKey, TElement), $.$sl.System.Linq.Lookup$$$(TKey, TElement).Create(TSource, this._source, this._keySelector, this._elementSelector, this._comparer));
                    }
                    /*List<IGrouping<TKey, TElement>> */ ToList()
                    {
                        return $.$sl.System.Linq.Enumerable.ToList($.$sl.System.Linq.IGrouping$$$(TKey, TElement), $.$sl.System.Linq.Lookup$$$(TKey, TElement).Create(TSource, this._source, this._keySelector, this._elementSelector, this._comparer));
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        return onlyIfCheap ? -1 : $.$sl.System.Linq.Lookup$$$(TKey, TElement).Create(TSource, this._source, this._keySelector, this._elementSelector, this._comparer).Count;
                    }
                    static $h = 1572871;
                    static $g = 3;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424839,"r":3,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.GroupByIterator<${TSource?.$fullName},${TKey?.$fullName},${TElement?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_GroupByIterator$$$$ = $v))(TSource, TKey, TElement);
            }
            static $_GroupByIterator$$$;
            static GroupByIterator$$$(TSource, TKey)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_GroupByIterator$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.GroupByIterator<,>", (TSource, TKey) => $asm.$gt("$sl.System.Linq.Enumerable.GroupByIterator<,>", [TSource, TKey], ($self) => class GroupByIterator$$$ extends $.$sl.System.Linq.Enumerable.Iterator$$($.$sl.System.Linq.IGrouping$$$(TKey, TSource))
                {
                    /*IEnumerable<TSource>*/ _source = null;
                    /*Func<TSource, TKey>*/ _keySelector = null;
                    /*IEqualityComparer<TKey>?*/ _comparer = null;
                    /*Lookup<TKey, TSource>?*/ _lookup = null;
                    /*Grouping<TKey, TSource>?*/ _g = null;
                    $ctor$2(/*IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
                    {
                        super.$ctor$1();
                        {
                            this._source = source;
                            this._keySelector = keySelector;
                            this._comparer = comparer;
                        }
                        return this;
                    }
                    /*Iterator<IGrouping<TKey, TSource>> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.GroupByIterator$$$(TSource, TKey))().$ctor$2(this._source, this._keySelector, this._comparer);
                    }
                    /*bool */ MoveNext()
                    {
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    switch(this._state)
                                    {
                                        case 1:
                                        this._lookup = $.$sl.System.Linq.Lookup$$$(TKey, TSource).Create$1(this._source, this._keySelector, this._comparer);
                                        this._g = this._lookup._lastGrouping;
                                        if (!(this._g === null))
                                        {
                                            this._state = 2;
                                            $gotoJumpState1 = 1; /*goto ValidItem*/
                                            continue $gotoJumpStart1;
                                        }
                                        break;
                                        case 2:
                                        $.$spc.System.Diagnostics.Debug.Assert$1(!(this._g === null), "_g is not null");
                                        $.$spc.System.Diagnostics.Debug.Assert$1(!(this._lookup === null), "_lookup is not null");
                                        if (this._g !== this._lookup._lastGrouping)
                                        {
                                            $gotoJumpState1 = 1; /*goto ValidItem*/
                                            continue $gotoJumpStart1;
                                        }
                                        break;
                                    }
                                    this.Dispose();
                                    return false;
                                }
                                case 1: /*ValidItem*/
                                this._g = this._g._next;
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._g === null), "_g is not null");
                                this._current = this._g;
                                return true;
                            }
                            break;
                        }
                    }
                    /*IGrouping<TKey, TSource>[] */ ToArray()
                    {
                        return $.$sl.System.Linq.Enumerable.ToArray($.$sl.System.Linq.IGrouping$$$(TKey, TSource), $.$sl.System.Linq.Lookup$$$(TKey, TSource).Create$1(this._source, this._keySelector, this._comparer));
                    }
                    /*List<IGrouping<TKey, TSource>> */ ToList()
                    {
                        return $.$sl.System.Linq.Enumerable.ToList($.$sl.System.Linq.IGrouping$$$(TKey, TSource), $.$sl.System.Linq.Lookup$$$(TKey, TSource).Create$1(this._source, this._keySelector, this._comparer));
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        return onlyIfCheap ? -1 : $.$sl.System.Linq.Lookup$$$(TKey, TSource).Create$1(this._source, this._keySelector, this._comparer).Count;
                    }
                    static $h = 1638407;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":2424839,"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$($.$sl.System.Linq.IGrouping$$$(TKey, TSource)); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$($.$sl.System.Linq.IGrouping$$$(TKey, TSource)), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$($.$sl.System.Linq.IGrouping$$$(TKey, TSource)), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.GroupByIterator<${TSource?.$fullName},${TKey?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_GroupByIterator$$$ = $v))(TSource, TKey);
            }
            static /*IEnumerable<TResult> */ GroupJoin(TOuter, TInner, TKey, TResult, /*this IEnumerable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Func<TOuter, TKey>*/ outerKeySelector, /*Func<TInner, TKey>*/ innerKeySelector, /*Func<TOuter, IEnumerable<TInner>, TResult>*/ resultSelector)
            {
                return $.$sl.System.Linq.Enumerable.GroupJoin$1(TOuter, TInner, TKey, TResult, outer, inner, outerKeySelector, innerKeySelector, resultSelector, null);
            }
            static /*IEnumerable<TResult> */ GroupJoin$1(TOuter, TInner, TKey, TResult, /*this IEnumerable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Func<TOuter, TKey>*/ outerKeySelector, /*Func<TInner, TKey>*/ innerKeySelector, /*Func<TOuter, IEnumerable<TInner>, TResult>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (outer === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(10/*ExceptionArgument.outer*/);
                }
                if (inner === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.inner*/);
                }
                if (outerKeySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(11/*ExceptionArgument.outerKeySelector*/);
                }
                if (innerKeySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.innerKeySelector*/);
                }
                if (resultSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(13/*ExceptionArgument.resultSelector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TOuter, outer))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.GroupJoinIterator(TOuter, TInner, TKey, TResult, outer, inner, outerKeySelector, innerKeySelector, resultSelector, comparer);
            }
            static /*IEnumerable<TResult> */ GroupJoinIterator(TOuter, TInner, TKey, TResult, /*IEnumerable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Func<TOuter, TKey>*/ outerKeySelector, /*Func<TInner, TKey>*/ innerKeySelector, /*Func<TOuter, IEnumerable<TInner>, TResult>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*IEnumerator<TOuter>*/ let e = outer.System$Collections$Generic$IEnumerable$$$GetEnumerator([TOuter]);
                    try
                    {
                        if (e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*Lookup<TKey, TInner>*/ let lookup = $.$sl.System.Linq.Lookup$$$(TKey, TInner).CreateForJoin(inner, innerKeySelector, comparer);
                            do
                            {
                                /*TOuter*/ let item = e.System$Collections$Generic$IEnumerator$$$Current;
                                yield resultSelector.Invoke(item, lookup.get_Item(outerKeySelector.Invoke(item)));
                            }
                            while(e.System$Collections$IEnumerator$MoveNext());
                        }
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            static /*IEnumerable<(int Index, TSource Item)> */ Index(TSource, /*this IEnumerable<TSource>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.ValueTuple$$$($.$spc.System.Int32, TSource).$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.IndexIterator(TSource, source);
            }
            static /*IEnumerable<(int Index, TSource Item)> */ IndexIterator(TSource, /*IEnumerable<TSource>*/ source)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*int*/ let index = -1;
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            //checked
                            {
                                index++;
                            }
                            yield new ($.$spc.System.ValueTuple$$$($.$spc.System.Int32, TSource))().$ctor$2(index, element);
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<T> */ InfiniteSequence(T, /*T*/ start, /*T*/ step)
            {
                if (start === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(21/*ExceptionArgument.start*/);
                }
                if (step === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(22/*ExceptionArgument.step*/);
                }
                return Iterator(start, step);
                /*static IEnumerable<T>*/  function Iterator(/*T*/ start, /*T*/ step)
                {
                    return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                    {
                        while(true)
                        {
                            yield start;
                            start = T.System$Numerics$IAdditionOperators$$$$$op_Addition(start, step);
                        }
                    }.bind(this));
                }
            }
            static /*IEnumerable<TSource> */ Intersect(TSource, /*this IEnumerable<TSource>*/ first, /*IEnumerable<TSource>*/ second)
            {
                return $.$sl.System.Linq.Enumerable.Intersect$1(TSource, first, second, null);
            }
            static /*IEnumerable<TSource> */ Intersect$1(TSource, /*this IEnumerable<TSource>*/ first, /*IEnumerable<TSource>*/ second, /*IEqualityComparer<TSource>?*/ comparer)
            {
                if (first === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(4/*ExceptionArgument.first*/);
                }
                if (second === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(14/*ExceptionArgument.second*/);
                }
                return $.$sl.System.Linq.Enumerable.IntersectIterator(TSource, first, second, comparer);
            }
            static /*IEnumerable<TSource> */ IntersectBy(TSource, TKey, /*this IEnumerable<TSource>*/ first, /*IEnumerable<TKey>*/ second, /*Func<TSource, TKey>*/ keySelector)
            {
                return $.$sl.System.Linq.Enumerable.IntersectBy$1(TSource, TKey, first, second, keySelector, null);
            }
            static /*IEnumerable<TSource> */ IntersectBy$1(TSource, TKey, /*this IEnumerable<TSource>*/ first, /*IEnumerable<TKey>*/ second, /*Func<TSource, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (first === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(4/*ExceptionArgument.first*/);
                }
                if (second === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(14/*ExceptionArgument.second*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                return $.$sl.System.Linq.Enumerable.IntersectByIterator(TSource, TKey, first, second, keySelector, comparer);
            }
            static /*IEnumerable<TSource> */ IntersectIterator(TSource, /*IEnumerable<TSource>*/ first, /*IEnumerable<TSource>*/ second, /*IEqualityComparer<TSource>?*/ comparer)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*var*/ let set = new ($.$spc.System.Collections.Generic.HashSet$$(TSource))().$ctor$5(second, comparer);
                    var $en3 = first.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (set.Remove(element))
                            {
                                yield element;
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<TSource> */ IntersectByIterator(TSource, TKey, /*IEnumerable<TSource>*/ first, /*IEnumerable<TKey>*/ second, /*Func<TSource, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*var*/ let set = new ($.$spc.System.Collections.Generic.HashSet$$(TKey))().$ctor$5(second, comparer);
                    var $en3 = first.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (set.Remove(keySelector.Invoke(element)))
                            {
                                yield element;
                            }
                        }
                    }
                }.bind(this));
            }
            static $_Iterator$$;
            static Iterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_Iterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.Iterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.Iterator<>", [TSource], ($self) => class Iterator$$ extends $.$spc.System.Object
                {
                    /*int*/ _threadId = 0;
                    /*int*/ _state = 0;
                    /*TSource*/ _current = $.$default(TSource);
                    /*TSource */ get Current()
                    {
                        return this._current;
                    }
                    /*void */ Dispose()
                    {
                        this._current = $.$default(TSource);
                        this._state = -1;
                    }
                    /*Iterator<TSource> */ GetEnumerator()
                    {
                        /*Iterator<TSource>*/ let enumerator = this._state === 0 && this._threadId === $.$spc.System.Environment.CurrentManagedThreadId ? this : this.Clone();
                        enumerator._state = 1;
                        return enumerator;
                    }
                    /*IEnumerable<TResult> */ Select(TResult, /*Func<TSource, TResult>*/ selector)
                    {
                        return !$.$sl.System.Linq.Enumerable.IsSizeOptimized ? new ($.$sl.System.Linq.Enumerable.IteratorSelectIterator$$$(TSource, TResult))().$ctor$2(this, selector) : new ($.$sl.System.Linq.Enumerable.IEnumerableSelectIterator$$$(TSource, TResult))().$ctor$2(this, selector);
                    }
                    /*IEnumerable<TSource> */ Where(/*Func<TSource, bool>*/ predicate)
                    {
                        return new ($.$sl.System.Linq.Enumerable.IEnumerableWhereIterator$$(TSource))().$ctor$2(this, predicate);
                    }
                    /*object? */ get System$Collections$IEnumerator$Current()
                    {
                        return $.$box(this.Current, TSource);
                    }
                    /*IEnumerator<TSource> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
                    {
                        return this.GetEnumerator();
                    }
                    /*void */ System$Collections$IEnumerator$Reset()
                    {
                        return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
                    }
                    /*Iterator<TSource>? */ Skip(/*int*/ count)
                    {
                        return new ($.$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator$$(TSource))().$ctor$2(this, count, -1);
                    }
                    /*Iterator<TSource>? */ Take(/*int*/ count)
                    {
                        return new ($.$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator$$(TSource))().$ctor$2(this, 0, ((count - 1) | 0));
                    }
                    /*TSource? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        return index === 0 ? this.TryGetFirst(found) : $.$sl.System.Linq.Enumerable.TryGetElementAtNonIterator(TSource, this, index, found);
                    }
                    /*TSource? */ TryGetFirst(/*out bool*/ found)
                    {
                        return $.$sl.System.Linq.Enumerable.TryGetFirstNonIterator(TSource, this, found);
                    }
                    /*TSource? */ TryGetLast(/*out bool*/ found)
                    {
                        return $.$sl.System.Linq.Enumerable.TryGetLastNonIterator(TSource, this, found);
                    }
                    /*bool */ Contains(/*TSource*/ value)
                    {
                        return $.$sl.System.Linq.Enumerable.ContainsIterate(TSource, this, value, null);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IEnumerator<TSource>.Current.get
                    get System$Collections$Generic$IEnumerator$$$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._threadId = $.$spc.System.Environment.CurrentManagedThreadId;
                        this._current = $.$default(TSource);
                    }
                    static $h = 2424839;
                    static $g = 1;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.Iterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_Iterator$$ = $v))(TSource);
            }
            static /*IEnumerable<TResult> */ Join(TOuter, TInner, TKey, TResult, /*this IEnumerable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Func<TOuter, TKey>*/ outerKeySelector, /*Func<TInner, TKey>*/ innerKeySelector, /*Func<TOuter, TInner, TResult>*/ resultSelector)
            {
                return $.$sl.System.Linq.Enumerable.Join$1(TOuter, TInner, TKey, TResult, outer, inner, outerKeySelector, innerKeySelector, resultSelector, null);
            }
            static /*IEnumerable<TResult> */ Join$1(TOuter, TInner, TKey, TResult, /*this IEnumerable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Func<TOuter, TKey>*/ outerKeySelector, /*Func<TInner, TKey>*/ innerKeySelector, /*Func<TOuter, TInner, TResult>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (outer === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(10/*ExceptionArgument.outer*/);
                }
                if (inner === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.inner*/);
                }
                if (outerKeySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(11/*ExceptionArgument.outerKeySelector*/);
                }
                if (innerKeySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.innerKeySelector*/);
                }
                if (resultSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(13/*ExceptionArgument.resultSelector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TOuter, outer))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.JoinIterator(TOuter, TInner, TKey, TResult, outer, inner, outerKeySelector, innerKeySelector, resultSelector, comparer);
            }
            static /*IEnumerable<TResult> */ JoinIterator(TOuter, TInner, TKey, TResult, /*IEnumerable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Func<TOuter, TKey>*/ outerKeySelector, /*Func<TInner, TKey>*/ innerKeySelector, /*Func<TOuter, TInner, TResult>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*IEnumerator<TOuter>*/ let e = outer.System$Collections$Generic$IEnumerable$$$GetEnumerator([TOuter]);
                    try
                    {
                        if (e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*Lookup<TKey, TInner>*/ let lookup = $.$sl.System.Linq.Lookup$$$(TKey, TInner).CreateForJoin(inner, innerKeySelector, comparer);
                            if (lookup.Count !== 0)
                            {
                                do
                                {
                                    /*TOuter*/ let item = e.System$Collections$Generic$IEnumerator$$$Current;
                                    /*Grouping<TKey, TInner>?*/ let g = lookup.GetGrouping(outerKeySelector.Invoke(item), false);
                                    if (!(g === null))
                                    {
                                        /*int*/ let count = g._count;
                                        /*TInner[]*/ let elements = g._elements;
                                        for(/*int*/ let i = 0; i !== count; ++i)
                                        {
                                            yield resultSelector.Invoke(item, $.$spc.System.Array.$ReadT1.call(elements, i));
                                        }
                                    }
                                }
                                while(e.System$Collections$IEnumerator$MoveNext());
                            }
                        }
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            static /*TSource */ Last(TSource, /*this IEnumerable<TSource>*/ source)
            {
                /*bool*/ let found;
                /*TSource?*/ let last = $.$sl.System.Linq.Enumerable.TryGetLast(TSource, source, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                if (!found)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                }
                return last;
            }
            static /*TSource */ Last$1(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
            {
                /*bool*/ let found;
                /*TSource?*/ let last = $.$sl.System.Linq.Enumerable.TryGetLast$1(TSource, source, predicate, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                if (!found)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowNoMatchException();
                }
                return last;
            }
            static /*TSource? */ LastOrDefault(TSource, /*this IEnumerable<TSource>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.TryGetLast(TSource, source, $.$discardRef());
            }
            static /*TSource */ LastOrDefault$1(TSource, /*this IEnumerable<TSource>*/ source, /*TSource*/ defaultValue)
            {
                /*bool*/ let found;
                /*TSource?*/ let last = $.$sl.System.Linq.Enumerable.TryGetLast(TSource, source, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                return found ? last : defaultValue;
            }
            static /*TSource? */ LastOrDefault$2(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
            {
                return $.$sl.System.Linq.Enumerable.TryGetLast$1(TSource, source, predicate, $.$discardRef());
            }
            static /*TSource */ LastOrDefault$3(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate, /*TSource*/ defaultValue)
            {
                /*bool*/ let found;
                /*TSource?*/ let last = $.$sl.System.Linq.Enumerable.TryGetLast$1(TSource, source, predicate, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                return found ? last : defaultValue;
            }
            static /*TSource? */ TryGetLast(TSource, /*this IEnumerable<TSource>*/ source, /*out bool*/ found)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                let iterator;
                return $.$is(source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }) ? iterator.TryGetLast(found) : $.$sl.System.Linq.Enumerable.TryGetLastNonIterator(TSource, source, found);
            }
            static /*TSource? */ TryGetLastNonIterator(TSource, /*IEnumerable<TSource>*/ source, /*out bool*/ found)
            {
                let list;
                if ($.$is(source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ list = v; } }))
                {
                    /*int*/ let count = list.System$Collections$Generic$ICollection$$$Count;
                    if (count > 0)
                    {
                        found.$v = true;
                        return list.System$Collections$Generic$IList$$$get_Item(((count - 1) | 0), [TSource]);
                    }
                }
                else 
                {
                    /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    try
                    {
                        if (e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*TSource*/ let result;
                            do
                            {
                                result = e.System$Collections$Generic$IEnumerator$$$Current;
                            }
                            while(e.System$Collections$IEnumerator$MoveNext());
                            found.$v = true;
                            return result;
                        }
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }
                found.$v = false;
                return $.$default(TSource);
            }
            static /*TSource? */ TryGetLast$1(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate, /*out bool*/ found)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (predicate === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.predicate*/);
                }
                let ordered;
                if ($.$is(source, $.$sl.System.Linq.Enumerable.OrderedIterator$$(TSource), { set $v(v){ ordered = v; } }))
                {
                    return ordered.TryGetLast$1(predicate, found);
                }
                let list;
                if ($.$is(source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ list = v; } }))
                {
                    for(/*int*/ let i = ((list.System$Collections$Generic$ICollection$$$Count - 1) | 0); i >= 0; --i)
                    {
                        /*TSource*/ let result = list.System$Collections$Generic$IList$$$get_Item(i, [TSource]);
                        if (predicate.Invoke(result))
                        {
                            found.$v = true;
                            return result;
                        }
                    }
                }
                else 
                {
                    /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    try
                    {
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*TSource*/ let result = e.System$Collections$Generic$IEnumerator$$$Current;
                            if (predicate.Invoke(result))
                            {
                                while(e.System$Collections$IEnumerator$MoveNext())
                                {
                                    /*TSource*/ let element = e.System$Collections$Generic$IEnumerator$$$Current;
                                    if (predicate.Invoke(element))
                                    {
                                        result = element;
                                    }
                                }
                                found.$v = true;
                                return result;
                            }
                        }
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }
                found.$v = false;
                return $.$default(TSource);
            }
            static /*IEnumerable<TResult> */ LeftJoin(TOuter, TInner, TKey, TResult, /*this IEnumerable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Func<TOuter, TKey>*/ outerKeySelector, /*Func<TInner, TKey>*/ innerKeySelector, /*Func<TOuter, TInner?, TResult>*/ resultSelector)
            {
                return $.$sl.System.Linq.Enumerable.LeftJoin$1(TOuter, TInner, TKey, TResult, outer, inner, outerKeySelector, innerKeySelector, resultSelector, null);
            }
            static /*IEnumerable<TResult> */ LeftJoin$1(TOuter, TInner, TKey, TResult, /*this IEnumerable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Func<TOuter, TKey>*/ outerKeySelector, /*Func<TInner, TKey>*/ innerKeySelector, /*Func<TOuter, TInner?, TResult>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (outer === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(10/*ExceptionArgument.outer*/);
                }
                if (inner === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.inner*/);
                }
                if (outerKeySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(11/*ExceptionArgument.outerKeySelector*/);
                }
                if (innerKeySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.innerKeySelector*/);
                }
                if (resultSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(13/*ExceptionArgument.resultSelector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TOuter, outer))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.LeftJoinIterator(TOuter, TInner, TKey, TResult, outer, inner, outerKeySelector, innerKeySelector, resultSelector, comparer);
            }
            static /*IEnumerable<TResult> */ LeftJoinIterator(TOuter, TInner, TKey, TResult, /*IEnumerable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Func<TOuter, TKey>*/ outerKeySelector, /*Func<TInner, TKey>*/ innerKeySelector, /*Func<TOuter, TInner?, TResult>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*IEnumerator<TOuter>*/ let e = outer.System$Collections$Generic$IEnumerable$$$GetEnumerator([TOuter]);
                    try
                    {
                        if (e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*Lookup<TKey, TInner>*/ let innerLookup = $.$sl.System.Linq.Lookup$$$(TKey, TInner).CreateForJoin(inner, innerKeySelector, comparer);
                            do
                            {
                                /*TOuter*/ let item = e.System$Collections$Generic$IEnumerator$$$Current;
                                /*Grouping<TKey, TInner>?*/ let g = innerLookup.GetGrouping(outerKeySelector.Invoke(item), false);
                                if (g === null)
                                {
                                    yield resultSelector.Invoke(item, $.$default(TInner));
                                }
                                else 
                                {
                                    /*int*/ let count = g._count;
                                    /*TInner[]*/ let elements = g._elements;
                                    for(/*int*/ let i = 0; i !== count; ++i)
                                    {
                                        yield resultSelector.Invoke(item, $.$spc.System.Array.$ReadT1.call(elements, i));
                                    }
                                }
                            }
                            while(e.System$Collections$IEnumerator$MoveNext());
                        }
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            static /*ILookup<TKey, TSource> */ ToLookup(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector)
            {
                return $.$sl.System.Linq.Enumerable.ToLookup$1(TSource, TKey, source, keySelector, null);
            }
            static /*ILookup<TKey, TSource> */ ToLookup$1(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$sl.System.Linq.EmptyLookup$$$(TKey, TSource).Instance;
                }
                return $.$sl.System.Linq.Lookup$$$(TKey, TSource).Create$1(source, keySelector, comparer);
            }
            static /*ILookup<TKey, TElement> */ ToLookup$2(TSource, TKey, TElement, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TSource, TElement>*/ elementSelector)
            {
                return $.$sl.System.Linq.Enumerable.ToLookup$3(TSource, TKey, TElement, source, keySelector, elementSelector, null);
            }
            static /*ILookup<TKey, TElement> */ ToLookup$3(TSource, TKey, TElement, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TSource, TElement>*/ elementSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                if (elementSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.elementSelector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$sl.System.Linq.EmptyLookup$$$(TKey, TElement).Instance;
                }
                return $.$sl.System.Linq.Lookup$$$(TKey, TElement).Create(TSource, source, keySelector, elementSelector, comparer);
            }
            static /*int */ Max(/*this IEnumerable<int>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.Int32, $.$sl.System.Linq.Enumerable.MaxCalc$$($.$spc.System.Int32), source);
            }
            static /*long */ Max$1(/*this IEnumerable<long>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.Int64, $.$sl.System.Linq.Enumerable.MaxCalc$$($.$spc.System.Int64), source);
            }
            static $_MaxCalc$$;
            static MaxCalc$$(T)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_MaxCalc$$ ??= $asm.$nstr("$sl.System.Linq.Enumerable.MaxCalc<>", (T) => $asm.$gt("$sl.System.Linq.Enumerable.MaxCalc<>", [T], ($self) => class MaxCalc$$ extends $.$spc.System.ValueType
                {
                    static /*bool */ Compare(/*T*/ left, /*T*/ right)
                    {
                        return T.System$Numerics$IComparisonOperators$$$$$op_GreaterThan(left, right);
                    }
                    static /*Vector128<T> */ Compare$1(/*Vector128<T>*/ left, /*Vector128<T>*/ right)
                    {
                        return $.$spc.System.Runtime.Intrinsics.Vector128.Max(T, left, right);
                    }
                    static /*Vector256<T> */ Compare$2(/*Vector256<T>*/ left, /*Vector256<T>*/ right)
                    {
                        return $.$spc.System.Runtime.Intrinsics.Vector256.Max(T, left, right);
                    }
                    static /*Vector512<T> */ Compare$3(/*Vector512<T>*/ left, /*Vector512<T>*/ right)
                    {
                        return $.$spc.System.Runtime.Intrinsics.Vector512.Max(T, left, right);
                    }
                    //Generated interface implemetation for System.Linq.Enumerable.IMinMaxCalc<T>.Compare(T, T)
                    static System$Linq$Enumerable$IMinMaxCalc$$$Compare()
                    {
                        return $.$sl.System.Linq.Enumerable.MaxCalc$$(T).Compare(...arguments);
                    }
                    //Generated interface implemetation for System.Linq.Enumerable.IMinMaxCalc<T>.Compare(System.Runtime.Intrinsics.Vector128<T>, System.Runtime.Intrinsics.Vector128<T>)
                    static System$Linq$Enumerable$IMinMaxCalc$$$Compare$1()
                    {
                        return $.$sl.System.Linq.Enumerable.MaxCalc$$(T).Compare$1(...arguments);
                    }
                    //Generated interface implemetation for System.Linq.Enumerable.IMinMaxCalc<T>.Compare(System.Runtime.Intrinsics.Vector256<T>, System.Runtime.Intrinsics.Vector256<T>)
                    static System$Linq$Enumerable$IMinMaxCalc$$$Compare$2()
                    {
                        return $.$sl.System.Linq.Enumerable.MaxCalc$$(T).Compare$2(...arguments);
                    }
                    //Generated interface implemetation for System.Linq.Enumerable.IMinMaxCalc<T>.Compare(System.Runtime.Intrinsics.Vector512<T>, System.Runtime.Intrinsics.Vector512<T>)
                    static System$Linq$Enumerable$IMinMaxCalc$$$Compare$3()
                    {
                        return $.$sl.System.Linq.Enumerable.MaxCalc$$(T).Compare$3(...arguments);
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        return copy;
                    }
                    static $h = 2752519;
                    static $g = 1;
                    static $z = 0;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$sl.System.Linq.Enumerable.IMinMaxCalc$$(T) ]; }
                    static get $fullName() { return `System.Linq.Enumerable.MaxCalc<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_MaxCalc$$ = $v))(T);
            }
            static /*int? */ Max$2(/*this IEnumerable<int?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.MaxInteger($.$spc.System.Int32, source);
            }
            static /*long? */ Max$3(/*this IEnumerable<long?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.MaxInteger($.$spc.System.Int64, source);
            }
            static /*T? */ MaxInteger(T, /*this IEnumerable<T?>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*T?*/ let value = null;
                /*IEnumerator<T?>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$typeNullable(T)]);
                try
                {
                    do
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return value;
                        }
                        value = e.System$Collections$Generic$IEnumerator$$$Current;
                    }
                    while(!$.$spc.System.Nullable$$(T).HasValue$get.call(value));
                    /*T*/ let valueVal = $.$spc.System.Nullable$$(T).GetValueOrDefault.call(value);
                    if (T.System$Numerics$IComparisonOperators$$$$$op_GreaterThanOrEqual(valueVal, T.System$Numerics$INumberBase$$$Zero))
                    {
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*T?*/ let cur = e.System$Collections$Generic$IEnumerator$$$Current;
                            /*T*/ let x = $.$spc.System.Nullable$$(T).GetValueOrDefault.call(cur);
                            if (T.System$Numerics$IComparisonOperators$$$$$op_GreaterThan(x, valueVal))
                            {
                                valueVal = x;
                                value = cur?.Clone() ?? null;
                            }
                        }
                    }
                    else 
                    {
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*T?*/ let cur = e.System$Collections$Generic$IEnumerator$$$Current;
                            /*T*/ let x = $.$spc.System.Nullable$$(T).GetValueOrDefault.call(cur);
                            if ($.$spc.System.Boolean.op_BitwiseAnd($.$spc.System.Nullable$$(T).HasValue$get.call(cur), T.System$Numerics$IComparisonOperators$$$$$op_GreaterThan(x, valueVal)))
                            {
                                valueVal = x;
                                value = cur?.Clone() ?? null;
                            }
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*double */ Max$4(/*this IEnumerable<double>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.MaxFloat($.$spc.System.Double, source);
            }
            static /*double? */ Max$5(/*this IEnumerable<double?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.MaxFloat$1($.$spc.System.Double, source);
            }
            static /*float */ Max$6(/*this IEnumerable<float>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.MaxFloat($.$spc.System.Single, source);
            }
            static /*float? */ Max$7(/*this IEnumerable<float?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.MaxFloat$1($.$spc.System.Single, source);
            }
            static /*T */ MaxFloat(T, /*this IEnumerable<T>*/ source)
            {
                /*T*/ let value;
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*ReadOnlySpan<T>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan(T, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(T))))
                {
                    if (span.IsEmpty)
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    /*int*/ let i;
                    for(i = 0; i < span.Length && T.System$Numerics$INumberBase$$$IsNaN(span.get_Item(i).$v); i++)
                    {
                    }
                    if (i === span.Length)
                    {
                        return span.get_Item(span.Length - 1).$v;
                    }
                    for(value = span.get_Item(i).$v; (i >>> 0) < (span.Length >>> 0); i++)
                    {
                        if (T.System$Numerics$IComparisonOperators$$$$$op_GreaterThan(span.get_Item(i).$v, value))
                        {
                            value = span.get_Item(i).$v;
                        }
                    }
                    return value;
                }
                /*IEnumerator<T>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
                try
                {
                    if (!e.System$Collections$IEnumerator$MoveNext())
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    value = e.System$Collections$Generic$IEnumerator$$$Current;
                    while(T.System$Numerics$INumberBase$$$IsNaN(value))
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return value;
                        }
                        value = e.System$Collections$Generic$IEnumerator$$$Current;
                    }
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*T*/ let x = e.System$Collections$Generic$IEnumerator$$$Current;
                        if (T.System$Numerics$IComparisonOperators$$$$$op_GreaterThan(x, value))
                        {
                            value = x;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*T? */ MaxFloat$1(T, /*this IEnumerable<T?>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*T?*/ let value = null;
                /*IEnumerator<T?>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$typeNullable(T)]);
                try
                {
                    do
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return value;
                        }
                        value = e.System$Collections$Generic$IEnumerator$$$Current;
                    }
                    while(!$.$spc.System.Nullable$$(T).HasValue$get.call(value));
                    /*T*/ let valueVal = $.$spc.System.Nullable$$(T).GetValueOrDefault.call(value);
                    while(T.System$Numerics$INumberBase$$$IsNaN(valueVal))
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return value;
                        }
                        /*T?*/ let cur = e.System$Collections$Generic$IEnumerator$$$Current;
                        if ($.$spc.System.Nullable$$(T).HasValue$get.call(cur))
                        {
                            valueVal = $.$spc.System.Nullable$$(T).GetValueOrDefault.call((value = cur?.Clone() ?? null));
                        }
                    }
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*T?*/ let cur = e.System$Collections$Generic$IEnumerator$$$Current;
                        /*T*/ let x = $.$spc.System.Nullable$$(T).GetValueOrDefault.call(cur);
                        if ($.$spc.System.Boolean.op_BitwiseAnd($.$spc.System.Nullable$$(T).HasValue$get.call(cur), T.System$Numerics$IComparisonOperators$$$$$op_GreaterThan(x, valueVal)))
                        {
                            valueVal = x;
                            value = cur?.Clone() ?? null;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*decimal */ Max$8(/*this IEnumerable<decimal>*/ source)
            {
                /*decimal*/ let value;
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*ReadOnlySpan<decimal>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan($.$spc.System.Decimal, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Decimal))))
                {
                    if (span.IsEmpty)
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    value = span.get_Item(0).$v;
                    for(/*int*/ let i = 1; (i >>> 0) < (span.Length >>> 0); i++)
                    {
                        if ($.$spc.System.Decimal.op_GreaterThan(span.get_Item(i).$v, value))
                        {
                            value = span.get_Item(i).$v;
                        }
                    }
                    return value;
                }
                /*IEnumerator<decimal>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$spc.System.Decimal]);
                try
                {
                    if (!e.System$Collections$IEnumerator$MoveNext())
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    value = e.System$Collections$Generic$IEnumerator$$$Current;
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*decimal*/ let x = e.System$Collections$Generic$IEnumerator$$$Current;
                        if ($.$spc.System.Decimal.op_GreaterThan(x, value))
                        {
                            value = x;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*decimal? */ Max$9(/*this IEnumerable<decimal?>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*decimal?*/ let value = null;
                /*IEnumerator<decimal?>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$typeNullable($.$spc.System.Decimal)]);
                try
                {
                    do
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return value;
                        }
                        value = e.System$Collections$Generic$IEnumerator$$$Current;
                    }
                    while(!$.$spc.System.Nullable$$($.$spc.System.Decimal).HasValue$get.call(value));
                    /*decimal*/ let valueVal = $.$spc.System.Nullable$$($.$spc.System.Decimal).GetValueOrDefault.call(value);
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*decimal?*/ let cur = e.System$Collections$Generic$IEnumerator$$$Current;
                        /*decimal*/ let x = $.$spc.System.Nullable$$($.$spc.System.Decimal).GetValueOrDefault.call(cur);
                        if ($.$spc.System.Nullable$$($.$spc.System.Decimal).HasValue$get.call(cur) && $.$spc.System.Decimal.op_GreaterThan(x, valueVal))
                        {
                            valueVal = x;
                            value = cur?.Clone() ?? null;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*TSource? */ Max$10(TSource, /*this IEnumerable<TSource>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Max$11(TSource, source, null);
            }
            static /*TSource? */ Max$11(TSource, /*this IEnumerable<TSource>*/ source, /*IComparer<TSource>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                comparer ??= $.$spc.System.Collections.Generic.Comparer$$(TSource).Default;
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.Byte.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.Byte, $.$sl.System.Linq.Enumerable.MaxCalc$$($.$spc.System.Byte), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Byte))), $.$spc.System.Byte), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.SByte.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.SByte, $.$sl.System.Linq.Enumerable.MaxCalc$$($.$spc.System.SByte), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.SByte))), $.$spc.System.SByte), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.UInt16.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.UInt16, $.$sl.System.Linq.Enumerable.MaxCalc$$($.$spc.System.UInt16), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.UInt16))), $.$spc.System.UInt16), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.Int16.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.Int16, $.$sl.System.Linq.Enumerable.MaxCalc$$($.$spc.System.Int16), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Int16))), $.$spc.System.Int16), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.Char.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.Char, $.$sl.System.Linq.Enumerable.MaxCalc$$($.$spc.System.Char), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Char))), $.$spc.System.Char), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.UInt32.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.UInt32, $.$sl.System.Linq.Enumerable.MaxCalc$$($.$spc.System.UInt32), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.UInt32))), $.$spc.System.UInt32), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.Int32.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.Int32, $.$sl.System.Linq.Enumerable.MaxCalc$$($.$spc.System.Int32), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Int32))), $.$spc.System.Int32), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.UInt64.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.UInt64, $.$sl.System.Linq.Enumerable.MaxCalc$$($.$spc.System.UInt64), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.UInt64))), $.$spc.System.UInt64), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.Int64.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.Int64, $.$sl.System.Linq.Enumerable.MaxCalc$$($.$spc.System.Int64), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Int64))), $.$spc.System.Int64), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.UIntPtr.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.UIntPtr, $.$sl.System.Linq.Enumerable.MaxCalc$$($.$spc.System.UIntPtr), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.UIntPtr))), $.$spc.System.UIntPtr), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.IntPtr.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.IntPtr, $.$sl.System.Linq.Enumerable.MaxCalc$$($.$spc.System.IntPtr), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.IntPtr))), $.$spc.System.IntPtr), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.Int128.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$cast($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.Int128, $.$sl.System.Linq.Enumerable.MaxCalc$$($.$spc.System.Int128), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Int128))), $.$spc.System.Object), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.UInt128.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$cast($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.UInt128, $.$sl.System.Linq.Enumerable.MaxCalc$$($.$spc.System.UInt128), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.UInt128))), $.$spc.System.Object), TSource);
                }
                /*TSource?*/ let value = $.$default(TSource);
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    if (value === null)
                    {
                        do
                        {
                            if (!e.System$Collections$IEnumerator$MoveNext())
                            {
                                return value;
                            }
                            value = e.System$Collections$Generic$IEnumerator$$$Current;
                        }
                        while(value === null);
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*TSource*/ let next = e.System$Collections$Generic$IEnumerator$$$Current;
                            if (!(next === null) && comparer.System$Collections$Generic$IComparer$$$Compare(next, value, [TSource]) > 0)
                            {
                                value = next;
                            }
                        }
                    }
                    else 
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                        }
                        value = e.System$Collections$Generic$IEnumerator$$$Current;
                        if (comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                        {
                            while(e.System$Collections$IEnumerator$MoveNext())
                            {
                                /*TSource*/ let next = e.System$Collections$Generic$IEnumerator$$$Current;
                                if ($.$spc.System.Collections.Generic.Comparer$$(TSource).Default.Compare(next, value) > 0)
                                {
                                    value = next;
                                }
                            }
                        }
                        else 
                        {
                            while(e.System$Collections$IEnumerator$MoveNext())
                            {
                                /*TSource*/ let next = e.System$Collections$Generic$IEnumerator$$$Current;
                                if (comparer.System$Collections$Generic$IComparer$$$Compare(next, value, [TSource]) > 0)
                                {
                                    value = next;
                                }
                            }
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*TSource? */ MaxBy(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector)
            {
                return $.$sl.System.Linq.Enumerable.MaxBy$1(TSource, TKey, source, keySelector, null);
            }
            static /*TSource? */ MaxBy$1(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                comparer ??= $.$spc.System.Collections.Generic.Comparer$$(TKey).Default;
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    if (!e.System$Collections$IEnumerator$MoveNext())
                    {
                        if ($.$default(TSource) === null)
                        {
                            return $.$default(TSource);
                        }
                        else 
                        {
                            $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                        }
                    }
                    /*TSource*/ let value = e.System$Collections$Generic$IEnumerator$$$Current;
                    /*TKey*/ let key = keySelector.Invoke(value);
                    if ($.$default(TKey) === null)
                    {
                        if (key === null)
                        {
                            /*TSource*/ let firstValue = value;
                            do
                            {
                                if (!e.System$Collections$IEnumerator$MoveNext())
                                {
                                    return firstValue;
                                }
                                value = e.System$Collections$Generic$IEnumerator$$$Current;
                                key = keySelector.Invoke(value);
                            }
                            while(key === null);
                        }
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*TSource*/ let nextValue = e.System$Collections$Generic$IEnumerator$$$Current;
                            /*TKey*/ let nextKey = keySelector.Invoke(nextValue);
                            if (!(nextKey === null) && comparer.System$Collections$Generic$IComparer$$$Compare(nextKey, key, [TKey]) > 0)
                            {
                                key = nextKey;
                                value = nextValue;
                            }
                        }
                    }
                    else 
                    {
                        if (comparer === $.$spc.System.Collections.Generic.Comparer$$(TKey).Default)
                        {
                            while(e.System$Collections$IEnumerator$MoveNext())
                            {
                                /*TSource*/ let nextValue = e.System$Collections$Generic$IEnumerator$$$Current;
                                /*TKey*/ let nextKey = keySelector.Invoke(nextValue);
                                if ($.$spc.System.Collections.Generic.Comparer$$(TKey).Default.Compare(nextKey, key) > 0)
                                {
                                    key = nextKey;
                                    value = nextValue;
                                }
                            }
                        }
                        else 
                        {
                            while(e.System$Collections$IEnumerator$MoveNext())
                            {
                                /*TSource*/ let nextValue = e.System$Collections$Generic$IEnumerator$$$Current;
                                /*TKey*/ let nextKey = keySelector.Invoke(nextValue);
                                if (comparer.System$Collections$Generic$IComparer$$$Compare(nextKey, key, [TKey]) > 0)
                                {
                                    key = nextKey;
                                    value = nextValue;
                                }
                            }
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*int */ Max$12(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, int>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.MaxInteger$1(TSource, $.$spc.System.Int32, source, selector);
            }
            static /*int? */ Max$13(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, int?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.MaxInteger$2(TSource, $.$spc.System.Int32, source, selector);
            }
            static /*long */ Max$14(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, long>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.MaxInteger$1(TSource, $.$spc.System.Int64, source, selector);
            }
            static /*long? */ Max$15(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, long?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.MaxInteger$2(TSource, $.$spc.System.Int64, source, selector);
            }
            static /*TResult */ MaxInteger$1(TSource, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TResult>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*TResult*/ let value;
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    if (!e.System$Collections$IEnumerator$MoveNext())
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*TResult*/ let x = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        if (TResult.System$Numerics$IComparisonOperators$$$$$op_GreaterThan(x, value))
                        {
                            value = x;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*TResult? */ MaxInteger$2(TSource, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TResult?>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*TResult?*/ let value = null;
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    do
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return value;
                        }
                        value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                    }
                    while(!$.$spc.System.Nullable$$(TResult).HasValue$get.call(value));
                    /*TResult*/ let valueVal = $.$spc.System.Nullable$$(TResult).GetValueOrDefault.call(value);
                    if (TResult.System$Numerics$IComparisonOperators$$$$$op_GreaterThanOrEqual(valueVal, TResult.System$Numerics$INumberBase$$$Zero))
                    {
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*TResult?*/ let cur = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                            /*TResult*/ let x = $.$spc.System.Nullable$$(TResult).GetValueOrDefault.call(cur);
                            if (TResult.System$Numerics$IComparisonOperators$$$$$op_GreaterThan(x, valueVal))
                            {
                                valueVal = x;
                                value = cur?.Clone() ?? null;
                            }
                        }
                    }
                    else 
                    {
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*TResult?*/ let cur = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                            /*TResult*/ let x = $.$spc.System.Nullable$$(TResult).GetValueOrDefault.call(cur);
                            if ($.$spc.System.Boolean.op_BitwiseAnd($.$spc.System.Nullable$$(TResult).HasValue$get.call(cur), TResult.System$Numerics$IComparisonOperators$$$$$op_GreaterThan(x, valueVal)))
                            {
                                valueVal = x;
                                value = cur?.Clone() ?? null;
                            }
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*float */ Max$16(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, float>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.MaxFloat$2(TSource, $.$spc.System.Single, source, selector);
            }
            static /*float? */ Max$17(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, float?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.MaxFloat$3(TSource, $.$spc.System.Single, source, selector);
            }
            static /*double */ Max$18(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, double>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.MaxFloat$2(TSource, $.$spc.System.Double, source, selector);
            }
            static /*double? */ Max$19(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, double?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.MaxFloat$3(TSource, $.$spc.System.Double, source, selector);
            }
            static /*TResult */ MaxFloat$2(TSource, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TResult>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*TResult*/ let value;
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    if (!e.System$Collections$IEnumerator$MoveNext())
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                    while(TResult.System$Numerics$INumberBase$$$IsNaN(value))
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return value;
                        }
                        value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                    }
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*TResult*/ let x = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        if (TResult.System$Numerics$IComparisonOperators$$$$$op_GreaterThan(x, value))
                        {
                            value = x;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*TResult? */ MaxFloat$3(TSource, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TResult?>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*TResult?*/ let value = null;
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    do
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return value;
                        }
                        value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                    }
                    while(!$.$spc.System.Nullable$$(TResult).HasValue$get.call(value));
                    /*TResult*/ let valueVal = $.$spc.System.Nullable$$(TResult).GetValueOrDefault.call(value);
                    while(TResult.System$Numerics$INumberBase$$$IsNaN(valueVal))
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return value;
                        }
                        /*TResult?*/ let cur = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        if ($.$spc.System.Nullable$$(TResult).HasValue$get.call(cur))
                        {
                            valueVal = $.$spc.System.Nullable$$(TResult).GetValueOrDefault.call((value = cur?.Clone() ?? null));
                        }
                    }
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*TResult?*/ let cur = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        /*TResult*/ let x = $.$spc.System.Nullable$$(TResult).GetValueOrDefault.call(cur);
                        if ($.$spc.System.Boolean.op_BitwiseAnd($.$spc.System.Nullable$$(TResult).HasValue$get.call(cur), TResult.System$Numerics$IComparisonOperators$$$$$op_GreaterThan(x, valueVal)))
                        {
                            valueVal = x;
                            value = cur?.Clone() ?? null;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*decimal */ Max$20(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, decimal>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*decimal*/ let value;
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    if (!e.System$Collections$IEnumerator$MoveNext())
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*decimal*/ let x = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        if ($.$spc.System.Decimal.op_GreaterThan(x, value))
                        {
                            value = x;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*decimal? */ Max$21(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, decimal?>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*decimal?*/ let value = null;
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    do
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return value;
                        }
                        value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                    }
                    while(!$.$spc.System.Nullable$$($.$spc.System.Decimal).HasValue$get.call(value));
                    /*decimal*/ let valueVal = $.$spc.System.Nullable$$($.$spc.System.Decimal).GetValueOrDefault.call(value);
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*decimal?*/ let cur = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        /*decimal*/ let x = $.$spc.System.Nullable$$($.$spc.System.Decimal).GetValueOrDefault.call(cur);
                        if ($.$spc.System.Nullable$$($.$spc.System.Decimal).HasValue$get.call(cur) && $.$spc.System.Decimal.op_GreaterThan(x, valueVal))
                        {
                            valueVal = x;
                            value = cur?.Clone() ?? null;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*TResult? */ Max$22(TSource, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TResult>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*TResult?*/ let value = $.$default(TResult);
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    if (value === null)
                    {
                        do
                        {
                            if (!e.System$Collections$IEnumerator$MoveNext())
                            {
                                return value;
                            }
                            value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        }
                        while(value === null);
                        /*Comparer<TResult>*/ let comparer = $.$spc.System.Collections.Generic.Comparer$$(TResult).Default;
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*TResult*/ let x = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                            if (!(x === null) && comparer.Compare(x, value) > 0)
                            {
                                value = x;
                            }
                        }
                    }
                    else 
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                        }
                        value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*TResult*/ let x = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                            if ($.$spc.System.Collections.Generic.Comparer$$(TResult).Default.Compare(x, value) > 0)
                            {
                                value = x;
                            }
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static $_IMinMaxCalc$$;
            static IMinMaxCalc$$(T)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_IMinMaxCalc$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.IMinMaxCalc<>", (T) => $asm.$gt("$sl.System.Linq.Enumerable.IMinMaxCalc<>", [T], ($self) => class IMinMaxCalc$$
                {
                    static $h = 2293767;
                    static $g = 1;
                    static $f = 0b10000000001100100;
                    static $k = 3;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $fullName() { return `System.Linq.Enumerable.IMinMaxCalc<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_IMinMaxCalc$$ = $v))(T);
            }
            static /*T */ MinMaxInteger(T, TMinMax, /*this IEnumerable<T>*/ source)
            {
                /*T*/ let value;
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*ReadOnlySpan<T>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan(T, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(T))))
                {
                    if (span.IsEmpty)
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    //if (!Vector128.IsHardwareAccelerated || !Vector128<T>.IsSupported || span.Length < Vector128<T>.Count)
                    {
                        value = span.get_Item(0).$v;
                        for(/*int*/ let i = 1; i < span.Length; i++)
                        {
                            if (TMinMax.System$Linq$Enumerable$IMinMaxCalc$$$Compare(span.get_Item(i).$v, value))
                            {
                                value = span.get_Item(i).$v;
                            }
                        }
                    }
                    //else { ... }
                }
                else 
                {
                    /*IEnumerator<T>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
                    try
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                        }
                        value = e.System$Collections$Generic$IEnumerator$$$Current;
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*T*/ let x = e.System$Collections$Generic$IEnumerator$$$Current;
                            if (TMinMax.System$Linq$Enumerable$IMinMaxCalc$$$Compare(x, value))
                            {
                                value = x;
                            }
                        }
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }
                return value;
            }
            static /*int */ Min(/*this IEnumerable<int>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.Int32, $.$sl.System.Linq.Enumerable.MinCalc$$($.$spc.System.Int32), source);
            }
            static /*long */ Min$1(/*this IEnumerable<long>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.Int64, $.$sl.System.Linq.Enumerable.MinCalc$$($.$spc.System.Int64), source);
            }
            static $_MinCalc$$;
            static MinCalc$$(T)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_MinCalc$$ ??= $asm.$nstr("$sl.System.Linq.Enumerable.MinCalc<>", (T) => $asm.$gt("$sl.System.Linq.Enumerable.MinCalc<>", [T], ($self) => class MinCalc$$ extends $.$spc.System.ValueType
                {
                    static /*bool */ Compare(/*T*/ left, /*T*/ right)
                    {
                        return T.System$Numerics$IComparisonOperators$$$$$op_LessThan(left, right);
                    }
                    static /*Vector128<T> */ Compare$1(/*Vector128<T>*/ left, /*Vector128<T>*/ right)
                    {
                        return $.$spc.System.Runtime.Intrinsics.Vector128.Min(T, left, right);
                    }
                    static /*Vector256<T> */ Compare$2(/*Vector256<T>*/ left, /*Vector256<T>*/ right)
                    {
                        return $.$spc.System.Runtime.Intrinsics.Vector256.Min(T, left, right);
                    }
                    static /*Vector512<T> */ Compare$3(/*Vector512<T>*/ left, /*Vector512<T>*/ right)
                    {
                        return $.$spc.System.Runtime.Intrinsics.Vector512.Min(T, left, right);
                    }
                    //Generated interface implemetation for System.Linq.Enumerable.IMinMaxCalc<T>.Compare(T, T)
                    static System$Linq$Enumerable$IMinMaxCalc$$$Compare()
                    {
                        return $.$sl.System.Linq.Enumerable.MinCalc$$(T).Compare(...arguments);
                    }
                    //Generated interface implemetation for System.Linq.Enumerable.IMinMaxCalc<T>.Compare(System.Runtime.Intrinsics.Vector128<T>, System.Runtime.Intrinsics.Vector128<T>)
                    static System$Linq$Enumerable$IMinMaxCalc$$$Compare$1()
                    {
                        return $.$sl.System.Linq.Enumerable.MinCalc$$(T).Compare$1(...arguments);
                    }
                    //Generated interface implemetation for System.Linq.Enumerable.IMinMaxCalc<T>.Compare(System.Runtime.Intrinsics.Vector256<T>, System.Runtime.Intrinsics.Vector256<T>)
                    static System$Linq$Enumerable$IMinMaxCalc$$$Compare$2()
                    {
                        return $.$sl.System.Linq.Enumerable.MinCalc$$(T).Compare$2(...arguments);
                    }
                    //Generated interface implemetation for System.Linq.Enumerable.IMinMaxCalc<T>.Compare(System.Runtime.Intrinsics.Vector512<T>, System.Runtime.Intrinsics.Vector512<T>)
                    static System$Linq$Enumerable$IMinMaxCalc$$$Compare$3()
                    {
                        return $.$sl.System.Linq.Enumerable.MinCalc$$(T).Compare$3(...arguments);
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        return copy;
                    }
                    static $h = 2818055;
                    static $g = 1;
                    static $z = 0;
                    static $f = 0b10000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$sl.System.Linq.Enumerable.IMinMaxCalc$$(T) ]; }
                    static get $fullName() { return `System.Linq.Enumerable.MinCalc<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_MinCalc$$ = $v))(T);
            }
            static /*int? */ Min$2(/*this IEnumerable<int?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.MinInteger($.$spc.System.Int32, source);
            }
            static /*long? */ Min$3(/*this IEnumerable<long?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.MinInteger($.$spc.System.Int64, source);
            }
            static /*T? */ MinInteger(T, /*this IEnumerable<T?>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*T?*/ let value = null;
                /*IEnumerator<T?>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$typeNullable(T)]);
                try
                {
                    do
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return value;
                        }
                        value = e.System$Collections$Generic$IEnumerator$$$Current;
                    }
                    while(!$.$spc.System.Nullable$$(T).HasValue$get.call(value));
                    /*T*/ let valueVal = $.$spc.System.Nullable$$(T).GetValueOrDefault.call(value);
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*T?*/ let cur = e.System$Collections$Generic$IEnumerator$$$Current;
                        /*T*/ let x = $.$spc.System.Nullable$$(T).GetValueOrDefault.call(cur);
                        if ($.$spc.System.Boolean.op_BitwiseAnd($.$spc.System.Nullable$$(T).HasValue$get.call(cur), T.System$Numerics$IComparisonOperators$$$$$op_LessThan(x, valueVal)))
                        {
                            valueVal = x;
                            value = cur?.Clone() ?? null;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*float */ Min$4(/*this IEnumerable<float>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.MinFloat($.$spc.System.Single, source);
            }
            static /*float? */ Min$5(/*this IEnumerable<float?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.MinFloat$1($.$spc.System.Single, source);
            }
            static /*double */ Min$6(/*this IEnumerable<double>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.MinFloat($.$spc.System.Double, source);
            }
            static /*double? */ Min$7(/*this IEnumerable<double?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.MinFloat$1($.$spc.System.Double, source);
            }
            static /*T */ MinFloat(T, /*this IEnumerable<T>*/ source)
            {
                /*T*/ let value;
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*ReadOnlySpan<T>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan(T, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(T))))
                {
                    if (span.IsEmpty)
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    value = span.get_Item(0).$v;
                    for(/*int*/ let i = 1; (i >>> 0) < (span.Length >>> 0); i++)
                    {
                        /*T*/ let current = span.get_Item(i).$v;
                        if (T.System$Numerics$IComparisonOperators$$$$$op_LessThan(current, value))
                        {
                            value = current;
                        }
                        else if (T.System$Numerics$INumberBase$$$IsNaN(current))
                        {
                            return current;
                        }
                    }
                    return value;
                }
                /*IEnumerator<T>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([T]);
                try
                {
                    if (!e.System$Collections$IEnumerator$MoveNext())
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    value = e.System$Collections$Generic$IEnumerator$$$Current;
                    if (T.System$Numerics$INumberBase$$$IsNaN(value))
                    {
                        return value;
                    }
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*T*/ let x = e.System$Collections$Generic$IEnumerator$$$Current;
                        if (T.System$Numerics$IComparisonOperators$$$$$op_LessThan(x, value))
                        {
                            value = x;
                        }
                        else if (T.System$Numerics$INumberBase$$$IsNaN(x))
                        {
                            return x;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*T? */ MinFloat$1(T, /*this IEnumerable<T?>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*T?*/ let value = null;
                /*IEnumerator<T?>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$typeNullable(T)]);
                try
                {
                    do
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return value;
                        }
                        value = e.System$Collections$Generic$IEnumerator$$$Current;
                    }
                    while(!$.$spc.System.Nullable$$(T).HasValue$get.call(value));
                    /*T*/ let valueVal = $.$spc.System.Nullable$$(T).GetValueOrDefault.call(value);
                    if (T.System$Numerics$INumberBase$$$IsNaN(valueVal))
                    {
                        return value;
                    }
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*T?*/ let cur = e.System$Collections$Generic$IEnumerator$$$Current;
                        if ($.$spc.System.Nullable$$(T).HasValue$get.call(cur))
                        {
                            /*T*/ let x = $.$spc.System.Nullable$$(T).GetValueOrDefault.call(cur);
                            if (T.System$Numerics$IComparisonOperators$$$$$op_LessThan(x, valueVal))
                            {
                                valueVal = x;
                                value = cur?.Clone() ?? null;
                            }
                            else if (T.System$Numerics$INumberBase$$$IsNaN(x))
                            {
                                return cur;
                            }
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*decimal */ Min$8(/*this IEnumerable<decimal>*/ source)
            {
                /*decimal*/ let value;
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*ReadOnlySpan<decimal>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan($.$spc.System.Decimal, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$($.$spc.System.Decimal))))
                {
                    if (span.IsEmpty)
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    value = span.get_Item(0).$v;
                    for(/*int*/ let i = 1; (i >>> 0) < (span.Length >>> 0); i++)
                    {
                        if ($.$spc.System.Decimal.op_LessThan(span.get_Item(i).$v, value))
                        {
                            value = span.get_Item(i).$v;
                        }
                    }
                    return value;
                }
                /*IEnumerator<decimal>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$spc.System.Decimal]);
                try
                {
                    if (!e.System$Collections$IEnumerator$MoveNext())
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    value = e.System$Collections$Generic$IEnumerator$$$Current;
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*decimal*/ let x = e.System$Collections$Generic$IEnumerator$$$Current;
                        if ($.$spc.System.Decimal.op_LessThan(x, value))
                        {
                            value = x;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*decimal? */ Min$9(/*this IEnumerable<decimal?>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*decimal?*/ let value = null;
                /*IEnumerator<decimal?>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$typeNullable($.$spc.System.Decimal)]);
                try
                {
                    do
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return value;
                        }
                        value = e.System$Collections$Generic$IEnumerator$$$Current;
                    }
                    while(!$.$spc.System.Nullable$$($.$spc.System.Decimal).HasValue$get.call(value));
                    /*decimal*/ let valueVal = $.$spc.System.Nullable$$($.$spc.System.Decimal).GetValueOrDefault.call(value);
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*decimal?*/ let cur = e.System$Collections$Generic$IEnumerator$$$Current;
                        /*decimal*/ let x = $.$spc.System.Nullable$$($.$spc.System.Decimal).GetValueOrDefault.call(cur);
                        if ($.$spc.System.Nullable$$($.$spc.System.Decimal).HasValue$get.call(cur) && $.$spc.System.Decimal.op_LessThan(x, valueVal))
                        {
                            valueVal = x;
                            value = cur?.Clone() ?? null;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*TSource? */ Min$10(TSource, /*this IEnumerable<TSource>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Min$11(TSource, source, null);
            }
            static /*TSource? */ Min$11(TSource, /*this IEnumerable<TSource>*/ source, /*IComparer<TSource>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                comparer ??= $.$spc.System.Collections.Generic.Comparer$$(TSource).Default;
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.Byte.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.Byte, $.$sl.System.Linq.Enumerable.MinCalc$$($.$spc.System.Byte), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Byte))), $.$spc.System.Byte), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.SByte.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.SByte, $.$sl.System.Linq.Enumerable.MinCalc$$($.$spc.System.SByte), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.SByte))), $.$spc.System.SByte), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.UInt16.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.UInt16, $.$sl.System.Linq.Enumerable.MinCalc$$($.$spc.System.UInt16), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.UInt16))), $.$spc.System.UInt16), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.Int16.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.Int16, $.$sl.System.Linq.Enumerable.MinCalc$$($.$spc.System.Int16), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Int16))), $.$spc.System.Int16), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.Char.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.Char, $.$sl.System.Linq.Enumerable.MinCalc$$($.$spc.System.Char), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Char))), $.$spc.System.Char), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.UInt32.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.UInt32, $.$sl.System.Linq.Enumerable.MinCalc$$($.$spc.System.UInt32), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.UInt32))), $.$spc.System.UInt32), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.Int32.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.Int32, $.$sl.System.Linq.Enumerable.MinCalc$$($.$spc.System.Int32), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Int32))), $.$spc.System.Int32), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.UInt64.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.UInt64, $.$sl.System.Linq.Enumerable.MinCalc$$($.$spc.System.UInt64), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.UInt64))), $.$spc.System.UInt64), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.Int64.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.Int64, $.$sl.System.Linq.Enumerable.MinCalc$$($.$spc.System.Int64), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Int64))), $.$spc.System.Int64), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.UIntPtr.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.UIntPtr, $.$sl.System.Linq.Enumerable.MinCalc$$($.$spc.System.UIntPtr), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.UIntPtr))), $.$spc.System.UIntPtr), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.IntPtr.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$box($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.IntPtr, $.$sl.System.Linq.Enumerable.MinCalc$$($.$spc.System.IntPtr), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.IntPtr))), $.$spc.System.IntPtr), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.Int128.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$cast($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.Int128, $.$sl.System.Linq.Enumerable.MinCalc$$($.$spc.System.Int128), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Int128))), $.$spc.System.Object), TSource);
                }
                if ($.$spc.System.Type.op_Equality$1(TSource.$type, $.$spc.System.UInt128.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                {
                    return $.$cast($.$cast($.$sl.System.Linq.Enumerable.MinMaxInteger($.$spc.System.UInt128, $.$sl.System.Linq.Enumerable.MinCalc$$($.$spc.System.UInt128), $.$cast(source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.UInt128))), $.$spc.System.Object), TSource);
                }
                /*TSource?*/ let value = $.$default(TSource);
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    if (value === null)
                    {
                        do
                        {
                            if (!e.System$Collections$IEnumerator$MoveNext())
                            {
                                return value;
                            }
                            value = e.System$Collections$Generic$IEnumerator$$$Current;
                        }
                        while(value === null);
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*TSource*/ let next = e.System$Collections$Generic$IEnumerator$$$Current;
                            if (!(next === null) && comparer.System$Collections$Generic$IComparer$$$Compare(next, value, [TSource]) < 0)
                            {
                                value = next;
                            }
                        }
                    }
                    else 
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                        }
                        value = e.System$Collections$Generic$IEnumerator$$$Current;
                        if (comparer === $.$spc.System.Collections.Generic.Comparer$$(TSource).Default)
                        {
                            while(e.System$Collections$IEnumerator$MoveNext())
                            {
                                /*TSource*/ let next = e.System$Collections$Generic$IEnumerator$$$Current;
                                if ($.$spc.System.Collections.Generic.Comparer$$(TSource).Default.Compare(next, value) < 0)
                                {
                                    value = next;
                                }
                            }
                        }
                        else 
                        {
                            while(e.System$Collections$IEnumerator$MoveNext())
                            {
                                /*TSource*/ let next = e.System$Collections$Generic$IEnumerator$$$Current;
                                if (comparer.System$Collections$Generic$IComparer$$$Compare(next, value, [TSource]) < 0)
                                {
                                    value = next;
                                }
                            }
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*TSource? */ MinBy(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector)
            {
                return $.$sl.System.Linq.Enumerable.MinBy$1(TSource, TKey, source, keySelector, null);
            }
            static /*TSource? */ MinBy$1(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                comparer ??= $.$spc.System.Collections.Generic.Comparer$$(TKey).Default;
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    if (!e.System$Collections$IEnumerator$MoveNext())
                    {
                        if ($.$default(TSource) === null)
                        {
                            return $.$default(TSource);
                        }
                        else 
                        {
                            $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                        }
                    }
                    /*TSource*/ let value = e.System$Collections$Generic$IEnumerator$$$Current;
                    /*TKey*/ let key = keySelector.Invoke(value);
                    if ($.$default(TKey) === null)
                    {
                        if (key === null)
                        {
                            /*TSource*/ let firstValue = value;
                            do
                            {
                                if (!e.System$Collections$IEnumerator$MoveNext())
                                {
                                    return firstValue;
                                }
                                value = e.System$Collections$Generic$IEnumerator$$$Current;
                                key = keySelector.Invoke(value);
                            }
                            while(key === null);
                        }
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*TSource*/ let nextValue = e.System$Collections$Generic$IEnumerator$$$Current;
                            /*TKey*/ let nextKey = keySelector.Invoke(nextValue);
                            if (!(nextKey === null) && comparer.System$Collections$Generic$IComparer$$$Compare(nextKey, key, [TKey]) < 0)
                            {
                                key = nextKey;
                                value = nextValue;
                            }
                        }
                    }
                    else 
                    {
                        if (comparer === $.$spc.System.Collections.Generic.Comparer$$(TKey).Default)
                        {
                            while(e.System$Collections$IEnumerator$MoveNext())
                            {
                                /*TSource*/ let nextValue = e.System$Collections$Generic$IEnumerator$$$Current;
                                /*TKey*/ let nextKey = keySelector.Invoke(nextValue);
                                if ($.$spc.System.Collections.Generic.Comparer$$(TKey).Default.Compare(nextKey, key) < 0)
                                {
                                    key = nextKey;
                                    value = nextValue;
                                }
                            }
                        }
                        else 
                        {
                            while(e.System$Collections$IEnumerator$MoveNext())
                            {
                                /*TSource*/ let nextValue = e.System$Collections$Generic$IEnumerator$$$Current;
                                /*TKey*/ let nextKey = keySelector.Invoke(nextValue);
                                if (comparer.System$Collections$Generic$IComparer$$$Compare(nextKey, key, [TKey]) < 0)
                                {
                                    key = nextKey;
                                    value = nextValue;
                                }
                            }
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*int */ Min$12(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, int>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.MinInteger$1(TSource, $.$spc.System.Int32, source, selector);
            }
            static /*int? */ Min$13(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, int?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.MinInteger$2(TSource, $.$spc.System.Int32, source, selector);
            }
            static /*long */ Min$14(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, long>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.MinInteger$1(TSource, $.$spc.System.Int64, source, selector);
            }
            static /*long? */ Min$15(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, long?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.MinInteger$2(TSource, $.$spc.System.Int64, source, selector);
            }
            static /*TResult */ MinInteger$1(TSource, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TResult>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*TResult*/ let value;
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    if (!e.System$Collections$IEnumerator$MoveNext())
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*TResult*/ let x = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        if (TResult.System$Numerics$IComparisonOperators$$$$$op_LessThan(x, value))
                        {
                            value = x;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*TResult? */ MinInteger$2(TSource, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TResult?>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*TResult?*/ let value = null;
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    do
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return value;
                        }
                        value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                    }
                    while(!$.$spc.System.Nullable$$(TResult).HasValue$get.call(value));
                    /*TResult*/ let valueVal = $.$spc.System.Nullable$$(TResult).GetValueOrDefault.call(value);
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*TResult?*/ let cur = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        /*TResult*/ let x = $.$spc.System.Nullable$$(TResult).GetValueOrDefault.call(cur);
                        if ($.$spc.System.Boolean.op_BitwiseAnd($.$spc.System.Nullable$$(TResult).HasValue$get.call(cur), TResult.System$Numerics$IComparisonOperators$$$$$op_LessThan(x, valueVal)))
                        {
                            valueVal = x;
                            value = cur?.Clone() ?? null;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*float */ Min$16(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, float>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.MinFloat$2(TSource, $.$spc.System.Single, source, selector);
            }
            static /*float? */ Min$17(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, float?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.MinFloat$3(TSource, $.$spc.System.Single, source, selector);
            }
            static /*double */ Min$18(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, double>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.MinFloat$2(TSource, $.$spc.System.Double, source, selector);
            }
            static /*double? */ Min$19(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, double?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.MinFloat$3(TSource, $.$spc.System.Double, source, selector);
            }
            static /*TResult */ MinFloat$2(TSource, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TResult>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*TResult*/ let value;
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    if (!e.System$Collections$IEnumerator$MoveNext())
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                    if (TResult.System$Numerics$INumberBase$$$IsNaN(value))
                    {
                        return value;
                    }
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*TResult*/ let x = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        if (TResult.System$Numerics$IComparisonOperators$$$$$op_LessThan(x, value))
                        {
                            value = x;
                        }
                        else if (TResult.System$Numerics$INumberBase$$$IsNaN(x))
                        {
                            return x;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*TResult? */ MinFloat$3(TSource, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TResult?>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*TResult?*/ let value = null;
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    do
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return value;
                        }
                        value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                    }
                    while(!$.$spc.System.Nullable$$(TResult).HasValue$get.call(value));
                    /*TResult*/ let valueVal = $.$spc.System.Nullable$$(TResult).GetValueOrDefault.call(value);
                    if (TResult.System$Numerics$INumberBase$$$IsNaN(valueVal))
                    {
                        return value;
                    }
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*TResult?*/ let cur = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        if ($.$spc.System.Nullable$$(TResult).HasValue$get.call(cur))
                        {
                            /*TResult*/ let x = $.$spc.System.Nullable$$(TResult).GetValueOrDefault.call(cur);
                            if (TResult.System$Numerics$IComparisonOperators$$$$$op_LessThan(x, valueVal))
                            {
                                valueVal = x;
                                value = cur?.Clone() ?? null;
                            }
                            else if (TResult.System$Numerics$INumberBase$$$IsNaN(x))
                            {
                                return cur;
                            }
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*decimal */ Min$20(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, decimal>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*decimal*/ let value;
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    if (!e.System$Collections$IEnumerator$MoveNext())
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                    }
                    value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*decimal*/ let x = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        if ($.$spc.System.Decimal.op_LessThan(x, value))
                        {
                            value = x;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*decimal? */ Min$21(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, decimal?>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*decimal?*/ let value = null;
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    do
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            return value;
                        }
                        value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                    }
                    while(!$.$spc.System.Nullable$$($.$spc.System.Decimal).HasValue$get.call(value));
                    /*decimal*/ let valueVal = $.$spc.System.Nullable$$($.$spc.System.Decimal).GetValueOrDefault.call(value);
                    while(e.System$Collections$IEnumerator$MoveNext())
                    {
                        /*decimal?*/ let cur = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        /*decimal*/ let x = $.$spc.System.Nullable$$($.$spc.System.Decimal).GetValueOrDefault.call(cur);
                        if ($.$spc.System.Nullable$$($.$spc.System.Decimal).HasValue$get.call(cur) && $.$spc.System.Decimal.op_LessThan(x, valueVal))
                        {
                            valueVal = x;
                            value = cur?.Clone() ?? null;
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*TResult? */ Min$22(TSource, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TResult>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*TResult?*/ let value = $.$default(TResult);
                /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    if (value === null)
                    {
                        do
                        {
                            if (!e.System$Collections$IEnumerator$MoveNext())
                            {
                                return value;
                            }
                            value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        }
                        while(value === null);
                        /*Comparer<TResult>*/ let comparer = $.$spc.System.Collections.Generic.Comparer$$(TResult).Default;
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*TResult*/ let x = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                            if (!(x === null) && comparer.Compare(x, value) < 0)
                            {
                                value = x;
                            }
                        }
                    }
                    else 
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                        }
                        value = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*TResult*/ let x = selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                            if ($.$spc.System.Collections.Generic.Comparer$$(TResult).Default.Compare(x, value) < 0)
                            {
                                value = x;
                            }
                        }
                    }
                    return value;
                }
                finally
                {
                    e?.System$IDisposable$Dispose();
                }
            }
            static /*IEnumerable<TResult> */ OfType(TResult, /*this IEnumerable*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                let typedSource;
                if (!($.$default(TResult) === null) && $.$is(source, $.$spc.System.Collections.Generic.IEnumerable$$(TResult), { set $v(v){ typedSource = v; } }))
                {
                    return typedSource;
                }
                return new ($.$sl.System.Linq.Enumerable.OfTypeIterator$$(TResult))().$ctor$2(source);
            }
            static $_OfTypeIterator$$;
            static OfTypeIterator$$(TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_OfTypeIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.OfTypeIterator<>", (TResult) => $asm.$gt("$sl.System.Linq.Enumerable.OfTypeIterator<>", [TResult], ($self) => class OfTypeIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*IEnumerable*/ _source = null;
                    /*IEnumerator?*/ _enumerator = null;
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.OfTypeIterator$$(TResult))().$ctor$2(this._source);
                    }
                    /*bool */ MoveNext()
                    {
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                this._enumerator = this._source.System$Collections$IEnumerable$GetEnumerator();
                                this._state = 2;
                                $switchJumpState1 = 2; /*goto case 2*/
                                continue $switchJumpStart1;
                                case 2:
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._enumerator === null), "_enumerator is not null");
                                while(this._enumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    let result;
                                    if ($.$is(this._enumerator.System$Collections$IEnumerator$Current, TResult, { set $v(v){ result = v; } }))
                                    {
                                        this._current = result;
                                        return true;
                                    }
                                }
                                this.Dispose();
                                break;
                            }
                            break;
                        }
                        return false;
                    }
                    /*void */ Dispose()
                    {
                        ($.$as(this._enumerator, $.$spc.System.IDisposable))?.System$IDisposable$Dispose();
                        this._enumerator = null;
                        super.Dispose();
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        if (onlyIfCheap)
                        {
                            return -1;
                        }
                        /*int*/ let count = 0;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if ($.$is(item, TResult))
                                {
                                    //checked
                                    {
                                        count++;
                                    }
                                }
                            }
                        }
                        return count;
                    }
                    /*TResult[] */ ToArray()
                    {
                        /*SegmentedArrayBuilder<TResult>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TResult>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult))().$ctor$2($.$spc.System.Span$$(TResult).op_Implicit(scratch.$fields));
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                let castItem;
                                if ($.$is(item, TResult, { set $v(v){ castItem = v; } }))
                                {
                                    builder.Add(castItem);
                                }
                            }
                        }
                        /*TResult[]*/ let result = builder.ToArray();
                        builder.Dispose();
                        return result;
                    }
                    /*List<TResult> */ ToList()
                    {
                        /*SegmentedArrayBuilder<TResult>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TResult>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult))().$ctor$2($.$spc.System.Span$$(TResult).op_Implicit(scratch.$fields));
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                let castItem;
                                if ($.$is(item, TResult, { set $v(v){ castItem = v; } }))
                                {
                                    builder.Add(castItem);
                                }
                            }
                        }
                        /*List<TResult>*/ let result = builder.ToList();
                        builder.Dispose();
                        return result;
                    }
                    /*TResult? */ TryGetFirst(/*out bool*/ found)
                    {
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                let castItem;
                                if ($.$is(item, TResult, { set $v(v){ castItem = v; } }))
                                {
                                    found.$v = true;
                                    return castItem;
                                }
                            }
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult? */ TryGetLast(/*out bool*/ found)
                    {
                        /*IEnumerator*/ let e = this._source.System$Collections$IEnumerable$GetEnumerator();
                        try
                        {
                            if (e.System$Collections$IEnumerator$MoveNext())
                            {
                                do
                                {
                                    let last;
                                    if ($.$is(e.System$Collections$IEnumerator$Current, TResult, { set $v(v){ last = v; } }))
                                    {
                                        found.$v = true;
                                        while(e.System$Collections$IEnumerator$MoveNext())
                                        {
                                            let castCurrent;
                                            if ($.$is(e.System$Collections$IEnumerator$Current, TResult, { set $v(v){ castCurrent = v; } }))
                                            {
                                                last = castCurrent;
                                            }
                                        }
                                        return last;
                                    }
                                }
                                while(e.System$Collections$IEnumerator$MoveNext());
                            }
                        }
                        finally
                        {
                            {
                                ($.$as(e, $.$spc.System.IDisposable))?.System$IDisposable$Dispose();
                            }
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if (index >= 0)
                        {
                            var $en5 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var item = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    let castItem;
                                    if ($.$is(item, TResult, { set $v(v){ castItem = v; } }))
                                    {
                                        if (index === 0)
                                        {
                                            found.$v = true;
                                            return castItem;
                                        }
                                        index--;
                                    }
                                }
                            }
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*IEnumerable<TResult2> */ Select(TResult2, /*Func<TResult, TResult2>*/ selector)
                    {
                        let objectSource;
                        if (!TResult.$type.IsValueType && $.$is(this._source, $.$spc.System.Collections.Generic.IEnumerable$$($.$spc.System.Object), { set $v(v){ objectSource = v; } }))
                        {
                            /*Func<object, TResult2>*/ let localSelector = new ($.$spc.System.Func$$$($.$spc.System.Object, TResult2))().$ctor(this,  (/*o*/ o) =>
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1($.$is(o, TResult), "o is TResult");
                                return $.$box(selector.Invoke($.$cast(o, TResult)), TResult2);
                            });
                            /*Func<object, bool>*/ let isTResult = new ($.$spc.System.Func$$$($.$spc.System.Object, $.$spc.System.Boolean))().$ctor(null, /*static*/ (/*o*/ o) =>
                            {
                                return $.$is(o, TResult);
                            });
                            let array;
                            return !$.$sl.System.Linq.Enumerable.IsSizeOptimized && $.$is(objectSource, $.$typeArray($.$spc.System.Object), { set $v(v){ array = v; } }) ? new ($.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$($.$spc.System.Object, TResult2))().$ctor$2(array, isTResult, localSelector) : new ($.$sl.System.Linq.Enumerable.IEnumerableWhereSelectIterator$$$($.$spc.System.Object, TResult2))().$ctor$2(objectSource, isTResult, localSelector);
                        }
                        return super.Select(TResult2, selector);
                    }
                    /*bool */ Contains(/*TResult*/ value)
                    {
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                let castItem;
                                if ($.$is(item, TResult, { set $v(v){ castItem = v; } }) && $.$spc.System.Collections.Generic.EqualityComparer$$(TResult).Default.Equals$2(castItem, value))
                                {
                                    return true;
                                }
                            }
                        }
                        return false;
                    }
                    //Begin primary constructor
                    /*IEnumerable*/ source = null;
                    $ctor$2(/*IEnumerable*/$source)
                    {
                        this.source = $source;
                        //depends on primary constructor parameter
                        this._source = this.source;
                        return this
                    }
                    //End primary constructor
                    static $h = 2883591;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.OfTypeIterator<${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_OfTypeIterator$$ = $v))(TResult);
            }
            static /*IOrderedEnumerable<T> */ Order(T, /*this IEnumerable<T>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Order$1(T, source, null);
            }
            static /*IOrderedEnumerable<T> */ Order$1(T, /*this IEnumerable<T>*/ source, /*IComparer<T>?*/ comparer)
            {
                return $.$sl.System.Linq.Enumerable.TypeIsImplicitlyStable(T) && (comparer === null || comparer === $.$spc.System.Collections.Generic.Comparer$$(T).Default) ? new ($.$sl.System.Linq.Enumerable.ImplicitlyStableOrderedIterator$$(T))().$ctor$3(source, false) : $.$sl.System.Linq.Enumerable.OrderBy$1(T, T, source, $.$sl.System.Linq.Enumerable.EnumerableSorter$$(T).IdentityFunc, comparer);
            }
            static /*IOrderedEnumerable<TSource> */ OrderBy(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector)
            {
                return new ($.$sl.System.Linq.Enumerable.OrderedIterator$$$(TSource, TKey))().$ctor$3(source, keySelector, null, false, null);
            }
            static /*IOrderedEnumerable<TSource> */ OrderBy$1(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                return new ($.$sl.System.Linq.Enumerable.OrderedIterator$$$(TSource, TKey))().$ctor$3(source, keySelector, comparer, false, null);
            }
            static /*IOrderedEnumerable<T> */ OrderDescending(T, /*this IEnumerable<T>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.OrderDescending$1(T, source, null);
            }
            static /*IOrderedEnumerable<T> */ OrderDescending$1(T, /*this IEnumerable<T>*/ source, /*IComparer<T>?*/ comparer)
            {
                return $.$sl.System.Linq.Enumerable.TypeIsImplicitlyStable(T) && (comparer === null || comparer === $.$spc.System.Collections.Generic.Comparer$$(T).Default) ? new ($.$sl.System.Linq.Enumerable.ImplicitlyStableOrderedIterator$$(T))().$ctor$3(source, true) : $.$sl.System.Linq.Enumerable.OrderByDescending$1(T, T, source, $.$sl.System.Linq.Enumerable.EnumerableSorter$$(T).IdentityFunc, comparer);
            }
            static /*IOrderedEnumerable<TSource> */ OrderByDescending(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector)
            {
                return new ($.$sl.System.Linq.Enumerable.OrderedIterator$$$(TSource, TKey))().$ctor$3(source, keySelector, null, true, null);
            }
            static /*IOrderedEnumerable<TSource> */ OrderByDescending$1(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                return new ($.$sl.System.Linq.Enumerable.OrderedIterator$$$(TSource, TKey))().$ctor$3(source, keySelector, comparer, true, null);
            }
            static /*IOrderedEnumerable<TSource> */ ThenBy(TSource, TKey, /*this IOrderedEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                return source.System$Linq$IOrderedEnumerable$$$CreateOrderedEnumerable(TKey, keySelector, null, false, [TSource]);
            }
            static /*IOrderedEnumerable<TSource> */ ThenBy$1(TSource, TKey, /*this IOrderedEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                return source.System$Linq$IOrderedEnumerable$$$CreateOrderedEnumerable(TKey, keySelector, comparer, false, [TSource]);
            }
            static /*IOrderedEnumerable<TSource> */ ThenByDescending(TSource, TKey, /*this IOrderedEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                return source.System$Linq$IOrderedEnumerable$$$CreateOrderedEnumerable(TKey, keySelector, null, true, [TSource]);
            }
            static /*IOrderedEnumerable<TSource> */ ThenByDescending$1(TSource, TKey, /*this IOrderedEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*IComparer<TKey>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                return source.System$Linq$IOrderedEnumerable$$$CreateOrderedEnumerable(TKey, keySelector, comparer, true, [TSource]);
            }
            static /*bool */ TypeIsImplicitlyStable(T, )
            {
                /*Type*/ let t = T.$type;
                if (T.$type.IsEnum)
                {
                    t = T.$type.GetEnumUnderlyingType();
                }
                return $.$spc.System.Type.op_Equality$1(t, $.$spc.System.SByte.$type) || $.$spc.System.Type.op_Equality$1(t, $.$spc.System.Byte.$type) || $.$spc.System.Type.op_Equality$1(t, $.$spc.System.Boolean.$type) || $.$spc.System.Type.op_Equality$1(t, $.$spc.System.Int16.$type) || $.$spc.System.Type.op_Equality$1(t, $.$spc.System.UInt16.$type) || $.$spc.System.Type.op_Equality$1(t, $.$spc.System.Char.$type) || $.$spc.System.Type.op_Equality$1(t, $.$spc.System.Int32.$type) || $.$spc.System.Type.op_Equality$1(t, $.$spc.System.UInt32.$type) || $.$spc.System.Type.op_Equality$1(t, $.$spc.System.Int64.$type) || $.$spc.System.Type.op_Equality$1(t, $.$spc.System.UInt64.$type) || $.$spc.System.Type.op_Equality$1(t, $.$spc.System.Int128.$type) || $.$spc.System.Type.op_Equality$1(t, $.$spc.System.UInt128.$type) || $.$spc.System.Type.op_Equality$1(t, $.$spc.System.IntPtr.$type) || $.$spc.System.Type.op_Equality$1(t, $.$spc.System.UIntPtr.$type);
            }
            static $_OrderedIterator$$;
            static OrderedIterator$$(TElement)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_OrderedIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.OrderedIterator<>", (TElement) => $asm.$gt("$sl.System.Linq.Enumerable.OrderedIterator<>", [TElement], ($self) => class OrderedIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TElement)
                {
                    /*IEnumerable<TElement>*/ _source = null;
                    $ctor$2(/*IEnumerable<TElement>*/ source)
                    {
                        super.$ctor$1();
                        this._source = source;
                        return this;
                    }
                    /*int[] */ SortedMap(/*TElement[]*/ buffer)
                    {
                        return this.GetEnumerableSorter(null).Sort(buffer, buffer.length);
                    }
                    /*int[] */ SortedMap$1(/*TElement[]*/ buffer, /*int*/ minIdx, /*int*/ maxIdx)
                    {
                        return this.GetEnumerableSorter(null).Sort$1(buffer, buffer.length, minIdx, maxIdx);
                    }
                    /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator$1()
                    {
                        return this.GetEnumerator();
                    }
                    /*IOrderedEnumerable<TElement> */ System$Linq$IOrderedEnumerable$$$CreateOrderedEnumerable(TKey, /*Func<TElement, TKey>*/ keySelector, /*IComparer<TKey>?*/ comparer, /*bool*/ descending)
                    {
                        return new ($.$sl.System.Linq.Enumerable.OrderedIterator$$$(TElement, TKey))().$ctor$3(this._source, keySelector, comparer, descending, this);
                    }
                    /*TElement? */ TryGetLast$1(/*Func<TElement, bool>*/ predicate, /*out bool*/ found)
                    {
                        /*CachingComparer<TElement>*/ let comparer = this.GetComparer(null);
                        /*IEnumerator<TElement>*/ let e = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TElement]);
                        try
                        {
                            /*TElement*/ let value;
                            do
                            {
                                if (!e.System$Collections$IEnumerator$MoveNext())
                                {
                                    found.$v = false;
                                    return $.$default(TElement);
                                }
                                value = e.System$Collections$Generic$IEnumerator$$$Current;
                            }
                            while(!predicate.Invoke(value));
                            comparer.SetElement(value);
                            while(e.System$Collections$IEnumerator$MoveNext())
                            {
                                /*TElement*/ let x = e.System$Collections$Generic$IEnumerator$$$Current;
                                if (predicate.Invoke(x) && comparer.Compare(x, false) >= 0)
                                {
                                    value = x;
                                }
                            }
                            found.$v = true;
                            return value;
                        }
                        finally
                        {
                            e?.System$IDisposable$Dispose();
                        }
                    }
                    /*TElement[] */ ToArray()
                    {
                        /*TElement[]*/ let buffer = $.$sl.System.Linq.Enumerable.ToArray(TElement, this._source);
                        if (buffer.length <= 1)
                        {
                            return buffer;
                        }
                        /*TElement[]*/ let array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TElement), null, [buffer.length], null);
                        this.Fill(buffer, $.$spc.System.Span$$(TElement).op_Implicit(array));
                        return array;
                    }
                    /*List<TElement> */ ToList()
                    {
                        /*TElement[]*/ let buffer = $.$sl.System.Linq.Enumerable.ToArray(TElement, this._source);
                        /*List<TElement>*/ let list = new ($.$spc.System.Collections.Generic.List$$(TElement))().$ctor$2(buffer.length);
                        if (buffer.length >= 2)
                        {
                            this.Fill(buffer, $.$sl.System.Linq.Enumerable.SetCountAndGetSpan(TElement, list, buffer.length));
                        }
                        else if (buffer.length === 1)
                        {
                            list.Add($.$spc.System.Array.$ReadT1.call(buffer, 0));
                        }
                        return list;
                    }
                    /*void */ Fill(/*TElement[]*/ buffer, /*Span<TElement>*/ destination)
                    {
                        /*int[]*/ let map = this.SortedMap(buffer);
                        for(/*int*/ let i = 0; i < destination.Length; i++)
                        {
                            destination.get_Item(i).$v = $.$spc.System.Array.$ReadT1.call(buffer, $.$spc.System.Array.$ReadT1.call(map, i));
                        }
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        let iterator;
                        if ($.$is(this._source, $.$sl.System.Linq.Enumerable.Iterator$$(TElement), { set $v(v){ iterator = v; } }))
                        {
                            return iterator.GetCount(onlyIfCheap);
                        }
                        return !onlyIfCheap || $.$is(this._source, $.$spc.System.Collections.Generic.ICollection$$(TElement)) || $.$is(this._source, $.$spc.System.Collections.ICollection) ? $.$sl.System.Linq.Enumerable.Count(TElement, this._source) : -1;
                    }
                    /*TElement[] */ ToArray$1(/*int*/ minIdx, /*int*/ maxIdx)
                    {
                        /*TElement[]*/ let buffer = $.$sl.System.Linq.Enumerable.ToArray(TElement, this._source);
                        if (buffer.length <= minIdx)
                        {
                            return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TElement.$type, [  ], null, null);
                        }
                        if (buffer.length <= maxIdx)
                        {
                            maxIdx = ((buffer.length - 1) | 0);
                        }
                        if (minIdx === maxIdx)
                        {
                            return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TElement.$type, [ this.GetEnumerableSorter(null).ElementAt(buffer, buffer.length, minIdx) ], null, null);
                        }
                        /*TElement[]*/ let array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TElement), null, [((((maxIdx - minIdx) | 0) + 1) | 0)], null);
                        this.Fill$1(minIdx, maxIdx, buffer, $.$spc.System.Span$$(TElement).op_Implicit(array));
                        return array;
                    }
                    /*List<TElement> */ ToList$1(/*int*/ minIdx, /*int*/ maxIdx)
                    {
                        /*TElement[]*/ let buffer = $.$sl.System.Linq.Enumerable.ToArray(TElement, this._source);
                        if (buffer.length <= minIdx)
                        {
                            return (() =>
                            {
                                let $t1 = new ($.$spc.System.Collections.Generic.List$$(TElement))().$ctor$1();
                                return $t1;
                            })();
                        }
                        if (buffer.length <= maxIdx)
                        {
                            maxIdx = ((buffer.length - 1) | 0);
                        }
                        if (minIdx === maxIdx)
                        {
                            return (() =>
                            {
                                //new $.$spc.System.Collections.Generic.List$$(TElement)()
                                const $t1 = $.$spc.System.Collections.Generic.List$$(TElement);
                                const $i1 = new $t1();
                                $i1.$ctor$2(1);
                                $i1.Add(this.GetEnumerableSorter(null).ElementAt(buffer, buffer.length, minIdx));
                                return $i1;
                            })();
                        }
                        /*List<TElement>*/ let list = (() =>
                        {
                            let $t1 = new ($.$spc.System.Collections.Generic.List$$(TElement))().$ctor$1();
                            return $t1;
                        })();
                        this.Fill$1(minIdx, maxIdx, buffer, $.$sl.System.Linq.Enumerable.SetCountAndGetSpan(TElement, list, ((((maxIdx - minIdx) | 0) + 1) | 0)));
                        return list;
                    }
                    /*void */ Fill$1(/*int*/ minIdx, /*int*/ maxIdx, /*TElement[]*/ buffer, /*Span<TElement>*/ destination)
                    {
                        /*int[]*/ let map = this.SortedMap$1(buffer, minIdx, maxIdx);
                        /*int*/ let idx = 0;
                        while(minIdx <= maxIdx)
                        {
                            destination.get_Item(idx).$v = $.$spc.System.Array.$ReadT1.call(buffer, $.$spc.System.Array.$ReadT1.call(map, minIdx));
                            ++idx;
                            ++minIdx;
                        }
                    }
                    /*int */ GetCount$1(/*int*/ minIdx, /*int*/ maxIdx, /*bool*/ onlyIfCheap)
                    {
                        /*int*/ let count = this.GetCount(onlyIfCheap);
                        if (count <= 0)
                        {
                            return count;
                        }
                        if (count <= minIdx)
                        {
                            return 0;
                        }
                        return (((count <= maxIdx ? count : ((maxIdx + 1) | 0)) - minIdx) | 0);
                    }
                    /*Iterator<TElement> */ Skip(/*int*/ count)
                    {
                        return new ($.$sl.System.Linq.Enumerable.SkipTakeOrderedIterator$$(TElement))().$ctor$2(this, count, 2147483647/*int.MaxValue*/);
                    }
                    /*Iterator<TElement> */ Take(/*int*/ count)
                    {
                        return new ($.$sl.System.Linq.Enumerable.SkipTakeOrderedIterator$$(TElement))().$ctor$2(this, 0, ((count - 1) | 0));
                    }
                    /*TElement? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if (index === 0)
                        {
                            return this.TryGetFirst(found);
                        }
                        if (index > 0)
                        {
                            /*TElement[]*/ let buffer = $.$sl.System.Linq.Enumerable.ToArray(TElement, this._source);
                            if (index < buffer.length)
                            {
                                found.$v = true;
                                return this.GetEnumerableSorter(null).ElementAt(buffer, buffer.length, index);
                            }
                        }
                        found.$v = false;
                        return $.$default(TElement);
                    }
                    /*TElement? */ TryGetFirst(/*out bool*/ found)
                    {
                        /*CachingComparer<TElement>*/ let comparer = this.GetComparer(null);
                        /*IEnumerator<TElement>*/ let e = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TElement]);
                        try
                        {
                            if (!e.System$Collections$IEnumerator$MoveNext())
                            {
                                found.$v = false;
                                return $.$default(TElement);
                            }
                            /*TElement*/ let value = e.System$Collections$Generic$IEnumerator$$$Current;
                            comparer.SetElement(value);
                            while(e.System$Collections$IEnumerator$MoveNext())
                            {
                                /*TElement*/ let x = e.System$Collections$Generic$IEnumerator$$$Current;
                                if (comparer.Compare(x, true) < 0)
                                {
                                    value = x;
                                }
                            }
                            found.$v = true;
                            return value;
                        }
                        finally
                        {
                            e?.System$IDisposable$Dispose();
                        }
                    }
                    /*TElement? */ TryGetLast(/*out bool*/ found)
                    {
                        /*IEnumerator<TElement>*/ let e = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TElement]);
                        try
                        {
                            if (!e.System$Collections$IEnumerator$MoveNext())
                            {
                                found.$v = false;
                                return $.$default(TElement);
                            }
                            /*CachingComparer<TElement>*/ let comparer = this.GetComparer(null);
                            /*TElement*/ let value = e.System$Collections$Generic$IEnumerator$$$Current;
                            comparer.SetElement(value);
                            while(e.System$Collections$IEnumerator$MoveNext())
                            {
                                /*TElement*/ let current = e.System$Collections$Generic$IEnumerator$$$Current;
                                if (comparer.Compare(current, false) >= 0)
                                {
                                    value = current;
                                }
                            }
                            found.$v = true;
                            return value;
                        }
                        finally
                        {
                            e?.System$IDisposable$Dispose();
                        }
                    }
                    /*TElement? */ TryGetLast$2(/*int*/ minIdx, /*int*/ maxIdx, /*out bool*/ found)
                    {
                        /*TElement[]*/ let buffer = $.$sl.System.Linq.Enumerable.ToArray(TElement, this._source);
                        if (minIdx < buffer.length)
                        {
                            found.$v = true;
                            return (maxIdx < ((buffer.length - 1) | 0)) ? this.GetEnumerableSorter(null).ElementAt(buffer, buffer.length, maxIdx) : this.Last(buffer);
                        }
                        found.$v = false;
                        return $.$default(TElement);
                    }
                    /*bool */ Contains(/*TElement*/ value)
                    {
                        return $.$sl.System.Linq.Enumerable.Contains(TElement, this._source, value);
                    }
                    /*TElement */ Last(/*TElement[]*/ items)
                    {
                        /*CachingComparer<TElement>*/ let comparer = this.GetComparer(null);
                        /*TElement*/ let value = $.$spc.System.Array.$ReadT1.call(items, 0);
                        comparer.SetElement(value);
                        for(/*int*/ let i = 1; i < items.length; ++i)
                        {
                            /*TElement*/ let x = $.$spc.System.Array.$ReadT1.call(items, i);
                            if (comparer.Compare(x, false) >= 0)
                            {
                                value = x;
                            }
                        }
                        return value;
                    }
                    static $h = 3014663;
                    static $g = 1;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TElement); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerator$$(TElement), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator, $.$sl.System.Linq.IOrderedEnumerable$$(TElement), $.$spc.System.Collections.Generic.IEnumerable$$(TElement), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Linq.Enumerable.OrderedIterator<${TElement?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_OrderedIterator$$ = $v))(TElement);
            }
            static $_OrderedIterator$$$;
            static OrderedIterator$$$(TElement, TKey)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_OrderedIterator$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.OrderedIterator<,>", (TElement, TKey) => $asm.$gt("$sl.System.Linq.Enumerable.OrderedIterator<,>", [TElement, TKey], ($self) => class OrderedIterator$$$ extends $.$sl.System.Linq.Enumerable.OrderedIterator$$(TElement)
                {
                    /*OrderedIterator<TElement>?*/ _parent = null;
                    /*Func<TElement, TKey>*/ _keySelector = null;
                    /*IComparer<TKey>*/ _comparer = null;
                    /*bool*/ _descending = false;
                    /*TElement[]?*/ _buffer = null;
                    /*int[]?*/ _map = null;
                    $ctor$3(/*IEnumerable<TElement>*/ source, /*Func<TElement, TKey>*/ keySelector, /*IComparer<TKey>?*/ comparer, /*bool*/ descending, /*OrderedIterator<TElement>?*/ parent)
                    {
                        super.$ctor$2(source);
                        {
                            if (source === null)
                            {
                                $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                            }
                            if (keySelector === null)
                            {
                                $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                            }
                            this._parent = parent;
                            this._keySelector = keySelector;
                            this._comparer = comparer ?? $.$spc.System.Collections.Generic.Comparer$$(TKey).Default;
                            this._descending = descending;
                        }
                        return this;
                    }
                    /*Iterator<TElement> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.OrderedIterator$$$(TElement, TKey))().$ctor$3(this._source, this._keySelector, this._comparer, this._descending, this._parent);
                    }
                    /*EnumerableSorter<TElement> */ GetEnumerableSorter(/*EnumerableSorter<TElement>?*/ next)
                    {
                        /*IComparer<TKey>*/ let comparer = this._comparer;
                        if ($.$spc.System.Type.op_Equality$1(TKey.$type, $.$spc.System.String.$type) && comparer === $.$spc.System.Collections.Generic.Comparer$$($.$spc.System.String).Default)
                        {
                            comparer = $.$cast($.$spc.System.StringComparer.CurrentCulture, $.$spc.System.Collections.Generic.IComparer$$(TKey));
                        }
                        /*EnumerableSorter<TElement>*/ let sorter = new ($.$sl.System.Linq.Enumerable.EnumerableSorter$$$(TElement, TKey))().$ctor$2(this._keySelector, comparer, this._descending, next);
                        if (!(this._parent === null))
                        {
                            sorter = this._parent.GetEnumerableSorter(sorter);
                        }
                        return sorter;
                    }
                    /*CachingComparer<TElement> */ GetComparer(/*CachingComparer<TElement>?*/ childComparer)
                    {
                        /*CachingComparer<TElement>*/ let cmp = childComparer === null ? new ($.$sl.System.Linq.Enumerable.CachingComparer$$$(TElement, TKey))().$ctor$2(this._keySelector, this._comparer, this._descending) : new ($.$sl.System.Linq.Enumerable.CachingComparerWithChild$$$(TElement, TKey))().$ctor$3(this._keySelector, this._comparer, this._descending, childComparer);
                        return !(this._parent === null) ? this._parent.GetComparer(cmp) : cmp;
                    }
                    /*bool */ MoveNext()
                    {
                        /*int*/ let state;
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    state = this._state;
                                }
                                case 1: /*Initialized*/
                                if (state > 1)
                                {
                                    $.$spc.System.Diagnostics.Debug.Assert$1(!(this._buffer === null), "_buffer is not null");
                                    $.$spc.System.Diagnostics.Debug.Assert$1(!(this._map === null), "_map is not null");
                                    $.$spc.System.Diagnostics.Debug.Assert$1(this._map.length === this._buffer.length, "_map.Length == _buffer.Length");
                                    /*int[]*/ let map = this._map;
                                    /*int*/ let i = ((state - 2) | 0);
                                    if ((i >>> 0) < (map.length >>> 0))
                                    {
                                        this._current = $.$spc.System.Array.$ReadT1.call(this._buffer, $.$spc.System.Array.$ReadT1.call(map, i));
                                        this._state++;
                                        return true;
                                    }
                                }
                                else if (state === 1)
                                {
                                    /*TElement[]*/ let buffer = $.$sl.System.Linq.Enumerable.ToArray(TElement, this._source);
                                    if (buffer.length !== 0)
                                    {
                                        this._map = this.SortedMap(buffer);
                                        this._buffer = buffer;
                                        this._state = state = 2;
                                        $gotoJumpState1 = 1; /*goto Initialized*/
                                        continue $gotoJumpStart1;
                                    }
                                }
                                this.Dispose();
                                return false;
                            }
                            break;
                        }
                    }
                    /*void */ Dispose()
                    {
                        this._buffer = null;
                        this._map = null;
                        super.Dispose();
                    }
                    /*TElement? */ TryGetFirst(/*out bool*/ found)
                    {
                        if (!(this._parent === null))
                        {
                            return super.TryGetFirst(found);
                        }
                        /*IEnumerator<TElement>*/ let e = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TElement]);
                        try
                        {
                            if (e.System$Collections$IEnumerator$MoveNext())
                            {
                                /*IComparer<TKey>*/ let comparer = this._comparer;
                                /*Func<TElement, TKey>*/ let keySelector = this._keySelector;
                                /*TElement*/ let resultValue = e.System$Collections$Generic$IEnumerator$$$Current;
                                /*TKey*/ let resultKey = keySelector.Invoke(resultValue);
                                if (this._descending)
                                {
                                    while(e.System$Collections$IEnumerator$MoveNext())
                                    {
                                        /*TElement*/ let nextValue = e.System$Collections$Generic$IEnumerator$$$Current;
                                        /*TKey*/ let nextKey = keySelector.Invoke(nextValue);
                                        if (comparer.System$Collections$Generic$IComparer$$$Compare(nextKey, resultKey, [TKey]) > 0)
                                        {
                                            resultKey = nextKey;
                                            resultValue = nextValue;
                                        }
                                    }
                                }
                                else 
                                {
                                    while(e.System$Collections$IEnumerator$MoveNext())
                                    {
                                        /*TElement*/ let nextValue = e.System$Collections$Generic$IEnumerator$$$Current;
                                        /*TKey*/ let nextKey = keySelector.Invoke(nextValue);
                                        if (comparer.System$Collections$Generic$IComparer$$$Compare(nextKey, resultKey, [TKey]) < 0)
                                        {
                                            resultKey = nextKey;
                                            resultValue = nextValue;
                                        }
                                    }
                                }
                                found.$v = true;
                                return resultValue;
                            }
                            found.$v = false;
                            return $.$default(TElement);
                        }
                        finally
                        {
                            e?.System$IDisposable$Dispose();
                        }
                    }
                    /*TElement? */ TryGetLast(/*out bool*/ found)
                    {
                        if (!(this._parent === null))
                        {
                            return super.TryGetLast(found);
                        }
                        /*IEnumerator<TElement>*/ let e = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TElement]);
                        try
                        {
                            if (e.System$Collections$IEnumerator$MoveNext())
                            {
                                /*IComparer<TKey>*/ let comparer = this._comparer;
                                /*Func<TElement, TKey>*/ let keySelector = this._keySelector;
                                /*TElement*/ let resultValue = e.System$Collections$Generic$IEnumerator$$$Current;
                                /*TKey*/ let resultKey = keySelector.Invoke(resultValue);
                                if (this._descending)
                                {
                                    while(e.System$Collections$IEnumerator$MoveNext())
                                    {
                                        /*TElement*/ let nextValue = e.System$Collections$Generic$IEnumerator$$$Current;
                                        /*TKey*/ let nextKey = keySelector.Invoke(nextValue);
                                        if (comparer.System$Collections$Generic$IComparer$$$Compare(nextKey, resultKey, [TKey]) <= 0)
                                        {
                                            resultKey = nextKey;
                                            resultValue = nextValue;
                                        }
                                    }
                                }
                                else 
                                {
                                    while(e.System$Collections$IEnumerator$MoveNext())
                                    {
                                        /*TElement*/ let nextValue = e.System$Collections$Generic$IEnumerator$$$Current;
                                        /*TKey*/ let nextKey = keySelector.Invoke(nextValue);
                                        if (comparer.System$Collections$Generic$IComparer$$$Compare(nextKey, resultKey, [TKey]) >= 0)
                                        {
                                            resultKey = nextKey;
                                            resultValue = nextValue;
                                        }
                                    }
                                }
                                found.$v = true;
                                return resultValue;
                            }
                            found.$v = false;
                            return $.$default(TElement);
                        }
                        finally
                        {
                            e?.System$IDisposable$Dispose();
                        }
                    }
                    static $h = 2949127;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.OrderedIterator$$(TElement); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerator$$(TElement), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator, $.$sl.System.Linq.IOrderedEnumerable$$(TElement), $.$spc.System.Collections.Generic.IEnumerable$$(TElement), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Linq.Enumerable.OrderedIterator<${TElement?.$fullName},${TKey?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_OrderedIterator$$$ = $v))(TElement, TKey);
            }
            static $_ImplicitlyStableOrderedIterator$$;
            static ImplicitlyStableOrderedIterator$$(TElement)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_ImplicitlyStableOrderedIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.ImplicitlyStableOrderedIterator<>", (TElement) => $asm.$gt("$sl.System.Linq.Enumerable.ImplicitlyStableOrderedIterator<>", [TElement], ($self) => class ImplicitlyStableOrderedIterator$$ extends $.$sl.System.Linq.Enumerable.OrderedIterator$$(TElement)
                {
                    /*bool*/ _descending = false;
                    /*TElement[]?*/ _buffer = null;
                    $ctor$3(/*IEnumerable<TElement>*/ source, /*bool*/ descending)
                    {
                        super.$ctor$2(source);
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$sl.System.Linq.Enumerable.TypeIsImplicitlyStable(TElement), "TypeIsImplicitlyStable<TElement>()");
                            if (source === null)
                            {
                                $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                            }
                            this._descending = descending;
                        }
                        return this;
                    }
                    /*Iterator<TElement> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.ImplicitlyStableOrderedIterator$$(TElement))().$ctor$3(this._source, this._descending);
                    }
                    /*CachingComparer<TElement> */ GetComparer(/*CachingComparer<TElement>?*/ childComparer)
                    {
                        return childComparer === null ? new ($.$sl.System.Linq.Enumerable.CachingComparer$$$(TElement, TElement))().$ctor$2($.$sl.System.Linq.Enumerable.EnumerableSorter$$(TElement).IdentityFunc, $.$spc.System.Collections.Generic.Comparer$$(TElement).Default, this._descending) : new ($.$sl.System.Linq.Enumerable.CachingComparerWithChild$$$(TElement, TElement))().$ctor$3($.$sl.System.Linq.Enumerable.EnumerableSorter$$(TElement).IdentityFunc, $.$spc.System.Collections.Generic.Comparer$$(TElement).Default, this._descending, childComparer);
                    }
                    /*EnumerableSorter<TElement> */ GetEnumerableSorter(/*EnumerableSorter<TElement>?*/ next)
                    {
                        return new ($.$sl.System.Linq.Enumerable.EnumerableSorter$$$(TElement, TElement))().$ctor$2($.$sl.System.Linq.Enumerable.EnumerableSorter$$(TElement).IdentityFunc, $.$spc.System.Collections.Generic.Comparer$$(TElement).Default, this._descending, next);
                    }
                    /*bool */ MoveNext()
                    {
                        /*int*/ let state;
                        /*TElement[]?*/ let buffer;
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    state = this._state;
                                }
                                case 1: /*Initialized*/
                                if (state > 1)
                                {
                                    buffer = this._buffer;
                                    $.$spc.System.Diagnostics.Debug.Assert$1(!(buffer === null), "buffer is not null");
                                    /*int*/ let i = ((state - 2) | 0);
                                    if ((i >>> 0) < (buffer.length >>> 0))
                                    {
                                        this._current = $.$spc.System.Array.$ReadT1.call(buffer, i);
                                        this._state++;
                                        return true;
                                    }
                                }
                                else if (state === 1)
                                {
                                    buffer = $.$sl.System.Linq.Enumerable.ToArray(TElement, this._source);
                                    if (buffer.length !== 0)
                                    {
                                        $.$sl.System.Linq.Enumerable.ImplicitlyStableOrderedIterator$$(TElement).Sort($.$spc.System.Span$$(TElement).op_Implicit(buffer), this._descending);
                                        this._buffer = buffer;
                                        this._state = state = 2;
                                        $gotoJumpState1 = 1; /*goto Initialized*/
                                        continue $gotoJumpStart1;
                                    }
                                }
                                this.Dispose();
                                return false;
                            }
                            break;
                        }
                    }
                    /*void */ Dispose()
                    {
                        this._buffer = null;
                        super.Dispose();
                    }
                    static /*void */ Sort(/*Span<TElement>*/ span, /*bool*/ descending)
                    {
                        if (descending)
                        {
                            $.$spc.System.MemoryExtensions.Sort$2(TElement, span, new ($.$spc.System.Comparison$$(TElement))().$ctor(null, /*static*/ (/*a*/ a, /*b*/ b) =>
                            {
                                return $.$spc.System.Collections.Generic.Comparer$$(TElement).Default.Compare(b, a);
                            }));
                        }
                        else 
                        {
                            $.$spc.System.MemoryExtensions.Sort(TElement, span);
                        }
                    }
                    /*TElement[] */ ToArray()
                    {
                        /*TElement[]*/ let array = $.$sl.System.Linq.Enumerable.ToArray(TElement, this._source);
                        $.$sl.System.Linq.Enumerable.ImplicitlyStableOrderedIterator$$(TElement).Sort($.$spc.System.Span$$(TElement).op_Implicit(array), this._descending);
                        return array;
                    }
                    /*List<TElement> */ ToList()
                    {
                        /*List<TElement>*/ let list = $.$sl.System.Linq.Enumerable.ToList(TElement, this._source);
                        $.$sl.System.Linq.Enumerable.ImplicitlyStableOrderedIterator$$(TElement).Sort($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TElement, list), this._descending);
                        return list;
                    }
                    /*TElement? */ TryGetFirst(/*out bool*/ found)
                    {
                        return this.TryGetFirstOrLast(found, !this._descending);
                    }
                    /*TElement? */ TryGetLast(/*out bool*/ found)
                    {
                        return this.TryGetFirstOrLast(found, this._descending);
                    }
                    /*TElement? */ TryGetFirstOrLast(/*out bool*/ found, /*bool*/ first)
                    {
                        /*ReadOnlySpan<TElement>*/ let span;
                        if ($.$sl.System.Linq.Enumerable.TryGetSpan(TElement, this._source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(TElement))))
                        {
                            if (span.Length !== 0)
                            {
                                $.$spc.System.Diagnostics.Debug.Assert$1($.$sl.System.Linq.Enumerable.TypeIsImplicitlyStable(TElement), "Using Min/Max has different semantics for floating-point values.");
                                found.$v = true;
                                return first ? $.$sl.System.Linq.Enumerable.Min$10(TElement, this._source) : $.$sl.System.Linq.Enumerable.Max$10(TElement, this._source);
                            }
                        }
                        else 
                        {
                            /*IEnumerator<TElement>*/ let e = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TElement]);
                            try
                            {
                                if (e.System$Collections$IEnumerator$MoveNext())
                                {
                                    /*TElement*/ let resultValue = e.System$Collections$Generic$IEnumerator$$$Current;
                                    if (first)
                                    {
                                        while(e.System$Collections$IEnumerator$MoveNext())
                                        {
                                            /*TElement*/ let nextValue = e.System$Collections$Generic$IEnumerator$$$Current;
                                            if ($.$spc.System.Collections.Generic.Comparer$$(TElement).Default.Compare(nextValue, resultValue) < 0)
                                            {
                                                resultValue = nextValue;
                                            }
                                        }
                                    }
                                    else 
                                    {
                                        while(e.System$Collections$IEnumerator$MoveNext())
                                        {
                                            /*TElement*/ let nextValue = e.System$Collections$Generic$IEnumerator$$$Current;
                                            if ($.$spc.System.Collections.Generic.Comparer$$(TElement).Default.Compare(nextValue, resultValue) >= 0)
                                            {
                                                resultValue = nextValue;
                                            }
                                        }
                                    }
                                    found.$v = true;
                                    return resultValue;
                                }
                            }
                            finally
                            {
                                e?.System$IDisposable$Dispose();
                            }
                        }
                        found.$v = false;
                        return $.$default(TElement);
                    }
                    static $h = 2359303;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.OrderedIterator$$(TElement); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerator$$(TElement), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator, $.$sl.System.Linq.IOrderedEnumerable$$(TElement), $.$spc.System.Collections.Generic.IEnumerable$$(TElement), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Linq.Enumerable.ImplicitlyStableOrderedIterator<${TElement?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ImplicitlyStableOrderedIterator$$ = $v))(TElement);
            }
            static $_CachingComparer$$;
            static CachingComparer$$(TElement)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_CachingComparer$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.CachingComparer<>", (TElement) => $asm.$gt("$sl.System.Linq.Enumerable.CachingComparer<>", [TElement], ($self) => class CachingComparer$$ extends $.$spc.System.Object
                {
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    static $h = 917511;
                    static $g = 1;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Linq.Enumerable.CachingComparer<${TElement?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_CachingComparer$$ = $v))(TElement);
            }
            static $_CachingComparer$$$;
            static CachingComparer$$$(TElement, TKey)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_CachingComparer$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.CachingComparer<,>", (TElement, TKey) => $asm.$gt("$sl.System.Linq.Enumerable.CachingComparer<,>", [TElement, TKey], ($self) => class CachingComparer$$$ extends $.$sl.System.Linq.Enumerable.CachingComparer$$(TElement)
                {
                    /*Func<TElement, TKey>*/ _keySelector = null;
                    /*IComparer<TKey>*/ _comparer = null;
                    /*bool*/ _descending = false;
                    /*TKey?*/ _lastKey = null;
                    $ctor$2(/*Func<TElement, TKey>*/ keySelector, /*IComparer<TKey>*/ comparer, /*bool*/ descending)
                    {
                        super.$ctor$1();
                        {
                            this._keySelector = keySelector;
                            this._comparer = comparer;
                            this._descending = descending;
                        }
                        return this;
                    }
                    /*int */ Compare(/*TElement*/ element, /*bool*/ cacheLower)
                    {
                        /*TKey*/ let newKey = this._keySelector.Invoke(element);
                        /*int*/ let cmp = this._descending ? this._comparer.System$Collections$Generic$IComparer$$$Compare(this._lastKey, newKey, [TKey]) : this._comparer.System$Collections$Generic$IComparer$$$Compare(newKey, this._lastKey, [TKey]);
                        if (cacheLower === cmp < 0)
                        {
                            this._lastKey = newKey;
                        }
                        return cmp;
                    }
                    /*void */ SetElement(/*TElement*/ element)
                    {
                        this._lastKey = this._keySelector.Invoke(element);
                    }
                    static $h = 851975;
                    static $g = 2;
                    static $f = 0b10000000001010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.CachingComparer$$(TElement); }
                    static get $fullName() { return `System.Linq.Enumerable.CachingComparer<${TElement?.$fullName},${TKey?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_CachingComparer$$$ = $v))(TElement, TKey);
            }
            static $_CachingComparerWithChild$$$;
            static CachingComparerWithChild$$$(TElement, TKey)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_CachingComparerWithChild$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.CachingComparerWithChild<,>", (TElement, TKey) => $asm.$gt("$sl.System.Linq.Enumerable.CachingComparerWithChild<,>", [TElement, TKey], ($self) => class CachingComparerWithChild$$$ extends $.$sl.System.Linq.Enumerable.CachingComparer$$$(TElement, TKey)
                {
                    /*CachingComparer<TElement>*/ _child = null;
                    $ctor$3(/*Func<TElement, TKey>*/ keySelector, /*IComparer<TKey>*/ comparer, /*bool*/ descending, /*CachingComparer<TElement>*/ child)
                    {
                        super.$ctor$2(keySelector, comparer, descending);
                        {
                            this._child = child;
                        }
                        return this;
                    }
                    /*int */ Compare(/*TElement*/ element, /*bool*/ cacheLower)
                    {
                        /*TKey*/ let newKey = this._keySelector.Invoke(element);
                        /*int*/ let cmp = this._descending ? this._comparer.System$Collections$Generic$IComparer$$$Compare(this._lastKey, newKey, [TKey]) : this._comparer.System$Collections$Generic$IComparer$$$Compare(newKey, this._lastKey, [TKey]);
                        if (cmp === 0)
                        {
                            return this._child.Compare(element, cacheLower);
                        }
                        if (cacheLower === cmp < 0)
                        {
                            this._lastKey = newKey;
                            this._child.SetElement(element);
                        }
                        return cmp;
                    }
                    /*void */ SetElement(/*TElement*/ element)
                    {
                        super.SetElement(element);
                        this._child.SetElement(element);
                    }
                    static $h = 983047;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.CachingComparer$$$(TElement, TKey); }
                    static get $fullName() { return `System.Linq.Enumerable.CachingComparerWithChild<${TElement?.$fullName},${TKey?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_CachingComparerWithChild$$$ = $v))(TElement, TKey);
            }
            static $_EnumerableSorter$$;
            static EnumerableSorter$$(TElement)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_EnumerableSorter$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.EnumerableSorter<>", (TElement) => $asm.$gt("$sl.System.Linq.Enumerable.EnumerableSorter<>", [TElement], ($self) => class EnumerableSorter$$ extends $.$spc.System.Object
                {
                    /*Func<TElement, TElement>*/ static IdentityFunc = null;
                    /*int[] */ ComputeMap(/*TElement[]*/ elements, /*int*/ count)
                    {
                        this.ComputeKeys(elements, count);
                        /*int[]*/ let map = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), null, [count], null);
                        $.$sl.System.Linq.Enumerable.FillIncrementing($.$spc.System.Int32, $.$spc.System.Span$$($.$spc.System.Int32).op_Implicit(map), 0);
                        return map;
                    }
                    /*int[] */ Sort(/*TElement[]*/ elements, /*int*/ count)
                    {
                        /*int[]*/ let map = this.ComputeMap(elements, count);
                        this.QuickSort(map, 0, ((count - 1) | 0));
                        return map;
                    }
                    /*int[] */ Sort$1(/*TElement[]*/ elements, /*int*/ count, /*int*/ minIdx, /*int*/ maxIdx)
                    {
                        /*int[]*/ let map = this.ComputeMap(elements, count);
                        this.PartialQuickSort(map, 0, ((count - 1) | 0), minIdx, maxIdx);
                        return map;
                    }
                    /*TElement */ ElementAt(/*TElement[]*/ elements, /*int*/ count, /*int*/ idx)
                    {
                        /*int[]*/ let map = this.ComputeMap(elements, count);
                        return idx === 0 ? $.$spc.System.Array.$ReadT1.call(elements, this.Min(map, count)) : $.$spc.System.Array.$ReadT1.call(elements, this.QuickSelect(map, ((count - 1) | 0), idx));
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.IdentityFunc = new ($.$spc.System.Func$$$(TElement, TElement))().$ctor(this,  (/*e*/ e) =>
                            {
                                return e;
                            });
                        }
                    }
                    static $h = 1507335;
                    static $g = 1;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Linq.Enumerable.EnumerableSorter<${TElement?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_EnumerableSorter$$ = $v))(TElement);
            }
            static $_EnumerableSorter$$$;
            static EnumerableSorter$$$(TElement, TKey)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_EnumerableSorter$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.EnumerableSorter<,>", (TElement, TKey) => $asm.$gt("$sl.System.Linq.Enumerable.EnumerableSorter<,>", [TElement, TKey], ($self) => class EnumerableSorter$$$ extends $.$sl.System.Linq.Enumerable.EnumerableSorter$$(TElement)
                {
                    /*Func<TElement, TKey>*/ _keySelector = null;
                    /*IComparer<TKey>*/ _comparer = null;
                    /*bool*/ _descending = false;
                    /*EnumerableSorter<TElement>?*/ _next = null;
                    /*TKey[]?*/ _keys = null;
                    $ctor$2(/*Func<TElement, TKey>*/ keySelector, /*IComparer<TKey>*/ comparer, /*bool*/ descending, /*EnumerableSorter<TElement>?*/ next)
                    {
                        super.$ctor$1();
                        {
                            this._keySelector = keySelector;
                            this._comparer = comparer;
                            this._descending = descending;
                            this._next = next;
                        }
                        return this;
                    }
                    /*void */ ComputeKeys(/*TElement[]*/ elements, /*int*/ count)
                    {
                        /*Func<TElement, TKey>*/ let keySelector = this._keySelector;
                        if (!$.$spc.System.Object.ReferenceEquals(keySelector, $.$sl.System.Linq.Enumerable.EnumerableSorter$$(TElement).IdentityFunc))
                        {
                            /*var*/ let keys = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TKey), null, [count], null);
                            for(/*int*/ let i = 0; i < keys.length; i++)
                            {
                                $.$spc.System.Array.$WriteT1.call(keys, keySelector.Invoke($.$spc.System.Array.$ReadT1.call(elements, i)), i);
                            }
                            this._keys = keys;
                        }
                        else 
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TKey.$type, TElement.$type), "typeof(TKey) == typeof(TElement)");
                            this._keys = $.$cast($.$cast(elements, $.$spc.System.Object), $.$typeArray(TKey));
                        }
                        this._next?.ComputeKeys(elements, count);
                    }
                    /*int */ CompareAnyKeys(/*int*/ index1, /*int*/ index2)
                    {
                        /*TKey[]?*/ let keys = this._keys;
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(keys === null), "keys is not null");
                        /*int*/ let c = this._comparer.System$Collections$Generic$IComparer$$$Compare($.$spc.System.Array.$ReadT1.call(keys, index1), $.$spc.System.Array.$ReadT1.call(keys, index2), [TKey]);
                        if (c === 0)
                        {
                            if (this._next === null)
                            {
                                return ((index1 - index2) | 0);
                            }
                            return this._next.CompareAnyKeys(index1, index2);
                        }
                        return (this._descending !== (c > 0)) ? 1 : -1;
                    }
                    /*int */ CompareAnyKeys_DefaultComparer_NoNext_Ascending(/*int*/ index1, /*int*/ index2)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(TKey.$type.IsValueType, "typeof(TKey).IsValueType");
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._comparer === $.$spc.System.Collections.Generic.Comparer$$(TKey).Default, "_comparer == Comparer<TKey>.Default");
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._next === null, "_next is null");
                        $.$spc.System.Diagnostics.Debug.Assert$1(!this._descending, "!_descending");
                        /*TKey[]?*/ let keys = this._keys;
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(keys === null), "keys is not null");
                        /*int*/ let c = $.$spc.System.Collections.Generic.Comparer$$(TKey).Default.Compare($.$spc.System.Array.$ReadT1.call(keys, index1), $.$spc.System.Array.$ReadT1.call(keys, index2));
                        return c === 0 ? ((index1 - index2) | 0) : c;
                    }
                    /*int */ CompareAnyKeys_DefaultComparer_NoNext_Descending(/*int*/ index1, /*int*/ index2)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(TKey.$type.IsValueType, "typeof(TKey).IsValueType");
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._comparer === $.$spc.System.Collections.Generic.Comparer$$(TKey).Default, "_comparer == Comparer<TKey>.Default");
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._next === null, "_next is null");
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._descending, "_descending");
                        /*TKey[]?*/ let keys = this._keys;
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(keys === null), "keys is not null");
                        /*int*/ let c = $.$spc.System.Collections.Generic.Comparer$$(TKey).Default.Compare($.$spc.System.Array.$ReadT1.call(keys, index2), $.$spc.System.Array.$ReadT1.call(keys, index1));
                        return c === 0 ? ((index1 - index2) | 0) : c;
                    }
                    /*int */ CompareKeys(/*int*/ index1, /*int*/ index2)
                    {
                        return index1 === index2 ? 0 : this.CompareAnyKeys(index1, index2);
                    }
                    /*void */ QuickSort(/*int[]*/ keys, /*int*/ lo, /*int*/ hi)
                    {
                        /*Comparison<int>*/ let comparison;
                        if (TKey.$type.IsValueType && this._next === null && this._comparer === $.$spc.System.Collections.Generic.Comparer$$(TKey).Default)
                        {
                            if (!this._descending)
                            {
                                comparison = new ($.$spc.System.Comparison$$($.$spc.System.Int32))().$ctor(this, this.CompareAnyKeys_DefaultComparer_NoNext_Ascending);
                            }
                            else 
                            {
                                comparison = new ($.$spc.System.Comparison$$($.$spc.System.Int32))().$ctor(this, this.CompareAnyKeys_DefaultComparer_NoNext_Descending);
                            }
                        }
                        else 
                        {
                            comparison = new ($.$spc.System.Comparison$$($.$spc.System.Int32))().$ctor(this, this.CompareAnyKeys);
                        }
                        $.$spc.System.MemoryExtensions.Sort$2($.$spc.System.Int32, new ($.$spc.System.Span$$($.$spc.System.Int32))().$ctor$3(keys, lo, ((((hi - lo) | 0) + 1) | 0)), comparison);
                    }
                    /*void */ PartialQuickSort(/*int[]*/ map, /*int*/ left, /*int*/ right, /*int*/ minIdx, /*int*/ maxIdx)
                    {
                        do
                        {
                            /*int*/ let i = left;
                            /*int*/ let j = right;
                            /*int*/ let x = $.$spc.System.Array.$ReadT1.call(map, ((i + ((((j - i) | 0)) >> 1)) | 0));
                            do
                            {
                                while(i < map.length && this.CompareKeys(x, $.$spc.System.Array.$ReadT1.call(map, i)) > 0)
                                {
                                    i++;
                                }
                                while(j >= 0 && this.CompareKeys(x, $.$spc.System.Array.$ReadT1.call(map, j)) < 0)
                                {
                                    j--;
                                }
                                if (i > j)
                                {
                                    break;
                                }
                                if (i < j)
                                {
                                    /*int*/ let temp = $.$spc.System.Array.$ReadT1.call(map, i);
                                    $.$spc.System.Array.$WriteT1.call(map, $.$spc.System.Array.$ReadT1.call(map, j), i);
                                    $.$spc.System.Array.$WriteT1.call(map, temp, j);
                                }
                                i++;
                                j--;
                            }
                            while(i <= j);
                            if (minIdx >= i)
                            {
                                left = ((i + 1) | 0);
                            }
                            else if (maxIdx <= j)
                            {
                                right = ((j - 1) | 0);
                            }
                            if (((j - left) | 0) <= ((right - i) | 0))
                            {
                                if (left < j)
                                {
                                    this.PartialQuickSort(map, left, j, minIdx, maxIdx);
                                }
                                left = i;
                            }
                            else 
                            {
                                if (i < right)
                                {
                                    this.PartialQuickSort(map, i, right, minIdx, maxIdx);
                                }
                                right = j;
                            }
                        }
                        while(left < right);
                    }
                    /*int */ QuickSelect(/*int[]*/ map, /*int*/ right, /*int*/ idx)
                    {
                        /*int*/ let left = 0;
                        do
                        {
                            /*int*/ let i = left;
                            /*int*/ let j = right;
                            /*int*/ let x = $.$spc.System.Array.$ReadT1.call(map, ((i + ((((j - i) | 0)) >> 1)) | 0));
                            do
                            {
                                while(i < map.length && this.CompareKeys(x, $.$spc.System.Array.$ReadT1.call(map, i)) > 0)
                                {
                                    i++;
                                }
                                while(j >= 0 && this.CompareKeys(x, $.$spc.System.Array.$ReadT1.call(map, j)) < 0)
                                {
                                    j--;
                                }
                                if (i > j)
                                {
                                    break;
                                }
                                if (i < j)
                                {
                                    /*int*/ let temp = $.$spc.System.Array.$ReadT1.call(map, i);
                                    $.$spc.System.Array.$WriteT1.call(map, $.$spc.System.Array.$ReadT1.call(map, j), i);
                                    $.$spc.System.Array.$WriteT1.call(map, temp, j);
                                }
                                i++;
                                j--;
                            }
                            while(i <= j);
                            if (i <= idx)
                            {
                                left = ((i + 1) | 0);
                            }
                            else 
                            {
                                right = ((j - 1) | 0);
                            }
                            if (((j - left) | 0) <= ((right - i) | 0))
                            {
                                if (left < j)
                                {
                                    right = j;
                                }
                                left = i;
                            }
                            else 
                            {
                                if (i < right)
                                {
                                    left = i;
                                }
                                right = j;
                            }
                        }
                        while(left < right);
                        return $.$spc.System.Array.$ReadT1.call(map, idx);
                    }
                    /*int */ Min(/*int[]*/ map, /*int*/ count)
                    {
                        /*int*/ let index = 0;
                        for(/*int*/ let i = 1; i < count; i++)
                        {
                            if (this.CompareKeys($.$spc.System.Array.$ReadT1.call(map, i), $.$spc.System.Array.$ReadT1.call(map, index)) < 0)
                            {
                                index = i;
                            }
                        }
                        return $.$spc.System.Array.$ReadT1.call(map, index);
                    }
                    static $h = 1441799;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.EnumerableSorter$$(TElement); }
                    static get $fullName() { return `System.Linq.Enumerable.EnumerableSorter<${TElement?.$fullName},${TKey?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_EnumerableSorter$$$ = $v))(TElement, TKey);
            }
            static $_SkipTakeOrderedIterator$$;
            static SkipTakeOrderedIterator$$(TElement)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_SkipTakeOrderedIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.SkipTakeOrderedIterator<>", (TElement) => $asm.$gt("$sl.System.Linq.Enumerable.SkipTakeOrderedIterator<>", [TElement], ($self) => class SkipTakeOrderedIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TElement)
                {
                    /*OrderedIterator<TElement>*/ _source = null;
                    /*int*/ _minIndexInclusive = 0;
                    /*int*/ _maxIndexInclusive = 0;
                    /*TElement[]?*/ _buffer = null;
                    /*int[]?*/ _map = null;
                    /*int*/ _maxIdx = 0;
                    $ctor$2(/*OrderedIterator<TElement>*/ source, /*int*/ minIdxInclusive, /*int*/ maxIdxInclusive)
                    {
                        super.$ctor$1();
                        {
                            this._source = source;
                            this._minIndexInclusive = minIdxInclusive;
                            this._maxIndexInclusive = maxIdxInclusive;
                        }
                        return this;
                    }
                    /*Iterator<TElement> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.SkipTakeOrderedIterator$$(TElement))().$ctor$2(this._source, this._minIndexInclusive, this._maxIndexInclusive);
                    }
                    /*bool */ MoveNext()
                    {
                        /*int*/ let state;
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    state = this._state;
                                }
                                case 1: /*Initialized*/
                                if (state > 1)
                                {
                                    $.$spc.System.Diagnostics.Debug.Assert$1(!(this._buffer === null), "_buffer is not null");
                                    $.$spc.System.Diagnostics.Debug.Assert$1(!(this._map === null), "_map is not null");
                                    /*int[]*/ let map = this._map;
                                    /*int*/ let i = ((((state - 2) | 0) + this._minIndexInclusive) | 0);
                                    if (i <= this._maxIdx)
                                    {
                                        this._current = $.$spc.System.Array.$ReadT1.call(this._buffer, $.$spc.System.Array.$ReadT1.call(map, i));
                                        this._state++;
                                        return true;
                                    }
                                }
                                else if (state === 1)
                                {
                                    /*TElement[]*/ let buffer = $.$sl.System.Linq.Enumerable.ToArray(TElement, this._source._source);
                                    /*int*/ let count = buffer.length;
                                    if (count > this._minIndexInclusive)
                                    {
                                        this._maxIdx = this._maxIndexInclusive;
                                        if (count <= this._maxIdx)
                                        {
                                            this._maxIdx = ((count - 1) | 0);
                                        }
                                        if (this._minIndexInclusive === this._maxIdx)
                                        {
                                            this._current = this._source.GetEnumerableSorter(null).ElementAt(buffer, count, this._minIndexInclusive);
                                            this._state = -1;
                                            return true;
                                        }
                                        this._map = this._source.SortedMap$1(buffer, this._minIndexInclusive, this._maxIdx);
                                        this._buffer = buffer;
                                        this._state = state = 2;
                                        $gotoJumpState1 = 1; /*goto Initialized*/
                                        continue $gotoJumpStart1;
                                    }
                                }
                                this.Dispose();
                                return false;
                            }
                            break;
                        }
                    }
                    /*Iterator<TElement>? */ Skip(/*int*/ count)
                    {
                        /*int*/ let minIndex = ((this._minIndexInclusive + count) | 0);
                        return (minIndex >>> 0) > (this._maxIndexInclusive >>> 0) ? null : new ($.$sl.System.Linq.Enumerable.SkipTakeOrderedIterator$$(TElement))().$ctor$2(this._source, minIndex, this._maxIndexInclusive);
                    }
                    /*Iterator<TElement> */ Take(/*int*/ count)
                    {
                        /*int*/ let maxIndex = ((((this._minIndexInclusive + count) | 0) - 1) | 0);
                        if ((maxIndex >>> 0) >= (this._maxIndexInclusive >>> 0))
                        {
                            return this;
                        }
                        return new ($.$sl.System.Linq.Enumerable.SkipTakeOrderedIterator$$(TElement))().$ctor$2(this._source, this._minIndexInclusive, maxIndex);
                    }
                    /*TElement? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if ((index >>> 0) <= ((((this._maxIndexInclusive - this._minIndexInclusive) | 0)) >>> 0))
                        {
                            return this._source.TryGetElementAt(((index + this._minIndexInclusive) | 0), found);
                        }
                        found.$v = false;
                        return $.$default(TElement);
                    }
                    /*TElement? */ TryGetFirst(/*out bool*/ found)
                    {
                        return this._source.TryGetElementAt(this._minIndexInclusive, found);
                    }
                    /*TElement? */ TryGetLast(/*out bool*/ found)
                    {
                        return this._source.TryGetLast$2(this._minIndexInclusive, this._maxIndexInclusive, found);
                    }
                    /*TElement[] */ ToArray()
                    {
                        return this._source.ToArray$1(this._minIndexInclusive, this._maxIndexInclusive);
                    }
                    /*List<TElement> */ ToList()
                    {
                        return this._source.ToList$1(this._minIndexInclusive, this._maxIndexInclusive);
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        return this._source.GetCount$1(this._minIndexInclusive, this._maxIndexInclusive, onlyIfCheap);
                    }
                    static $h = 3670023;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TElement); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TElement), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TElement), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.SkipTakeOrderedIterator<${TElement?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_SkipTakeOrderedIterator$$ = $v))(TElement);
            }
            static /*IEnumerable<int> */ Range(/*int*/ start, /*int*/ count)
            {
                /*long*/ let max = ($.$cast(start, $.$spc.System.Int64)) + BigInt(count) - 1n;
                if (count < 0 || max > BigInt(2147483647/*int.MaxValue*/))
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.count*/);
                }
                if (count === 0)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.Int32.$type, [  ], null, null);
                }
                return new ($.$sl.System.Linq.Enumerable.RangeIterator$$($.$spc.System.Int32))().$ctor$2(start, ((start + count) | 0));
            }
            static $_RangeIterator$$;
            static RangeIterator$$(T)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_RangeIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.RangeIterator<>", (T) => $asm.$gt("$sl.System.Linq.Enumerable.RangeIterator<>", [T], ($self) => class RangeIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(T)
                {
                    /*T*/ _start = $.$default(T);
                    /*T*/ _endExclusive = $.$default(T);
                    $ctor$2(/*T*/ start, /*T*/ endExclusive)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Int32.CreateChecked(T, T.System$Numerics$ISubtractionOperators$$$$$op_Subtraction(endExclusive, start)) >= 0, "int.CreateChecked(endExclusive - start) >= 0");
                            this._start = start;
                            this._endExclusive = endExclusive;
                        }
                        return this;
                    }
                    /*int */ get CountForDebugger()
                    {
                        return $.$spc.System.Int32.CreateTruncating(T, T.System$Numerics$ISubtractionOperators$$$$$op_Subtraction(this._endExclusive, this._start));
                    }
                    /*Iterator<T> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.RangeIterator$$(T))().$ctor$2(this._start, this._endExclusive);
                    }
                    /*bool */ MoveNext()
                    {
                        switch(this._state)
                        {
                            case 1:
                            $.$spc.System.Diagnostics.Debug.Assert$1(T.System$Numerics$IEqualityOperators$$$$$op_Inequality(this._start, this._endExclusive), "_start != _endExclusive");
                            this._current = this._start;
                            this._state = 2;
                            return true;
                            case 2:
                            if (T.System$Numerics$IEqualityOperators$$$$$op_Equality(this._current = T.System$Numerics$IIncrementOperators$$$op_Increment(this._current), this._endExclusive))
                            {
                                break;
                            }
                            return true;
                        }
                        this._state = -1;
                        return false;
                    }
                    /*void */ Dispose()
                    {
                        this._state = -1;
                    }
                    /*IEnumerable<TResult> */ Select(TResult, /*Func<T, TResult>*/ selector)
                    {
                        return new ($.$sl.System.Linq.Enumerable.RangeSelectIterator$$$(T, TResult))().$ctor$2(this._start, this._endExclusive, selector);
                    }
                    /*T[] */ ToArray()
                    {
                        /*T*/ let start = this._start;
                        /*T[]*/ let array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [this.Count], null);
                        $.$sl.System.Linq.Enumerable.FillIncrementing(T, $.$spc.System.Span$$(T).op_Implicit(array), start);
                        return array;
                    }
                    /*List<T> */ ToList()
                    {
                        const { Item1: start, Item2: end } = { Item1: this._start, Item2: this._endExclusive };
                        /*int*/ let count = $.$spc.System.Int32.CreateTruncating(T, T.System$Numerics$ISubtractionOperators$$$$$op_Subtraction(end, start));
                        /*List<T>*/ let list = new ($.$spc.System.Collections.Generic.List$$(T))().$ctor$2(count);
                        $.$sl.System.Linq.Enumerable.FillIncrementing(T, $.$sl.System.Linq.Enumerable.SetCountAndGetSpan(T, list, count), start);
                        return list;
                    }
                    /*void */ CopyTo(/*T[]*/ array, /*int*/ arrayIndex)
                    {
                        return $.$sl.System.Linq.Enumerable.FillIncrementing(T, $.$spc.System.MemoryExtensions.AsSpan$9(T, array, arrayIndex, this.Count), this._start);
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        return this.Count;
                    }
                    /*int */ get Count()
                    {
                        return $.$spc.System.Int32.CreateTruncating(T, T.System$Numerics$ISubtractionOperators$$$$$op_Subtraction(this._endExclusive, this._start));
                    }
                    /*Iterator<T>? */ Skip(/*int*/ count)
                    {
                        return count >= this.Count ? null : new ($.$sl.System.Linq.Enumerable.RangeIterator$$(T))().$ctor$2(T.System$Numerics$IAdditionOperators$$$$$op_Addition(this._start, T.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Int32, count)), this._endExclusive);
                    }
                    /*Iterator<T> */ Take(/*int*/ count)
                    {
                        return count >= this.Count ? this : new ($.$sl.System.Linq.Enumerable.RangeIterator$$(T))().$ctor$2(this._start, T.System$Numerics$IAdditionOperators$$$$$op_Addition(this._start, T.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Int32, count)));
                    }
                    /*T */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if ((index >>> 0) < (this.Count >>> 0))
                        {
                            found.$v = true;
                            return T.System$Numerics$IAdditionOperators$$$$$op_Addition(this._start, T.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Int32, index));
                        }
                        found.$v = false;
                        return T.System$Numerics$INumberBase$$$Zero;
                    }
                    /*T */ TryGetFirst(/*out bool*/ found)
                    {
                        found.$v = true;
                        return this._start;
                    }
                    /*T */ TryGetLast(/*out bool*/ found)
                    {
                        found.$v = true;
                        return T.System$Numerics$ISubtractionOperators$$$$$op_Subtraction(this._endExclusive, T.System$Numerics$INumberBase$$$One);
                    }
                    /*bool */ Contains(/*T*/ item)
                    {
                        return $.$spc.System.UInt32.CreateTruncating(T, T.System$Numerics$ISubtractionOperators$$$$$op_Subtraction(item, this._start)) < (this.Count >>> 0);
                    }
                    /*int */ IndexOf(/*T*/ item)
                    {
                        /*uint*/ let index = $.$spc.System.UInt32.CreateTruncating(T, T.System$Numerics$ISubtractionOperators$$$$$op_Subtraction(item, this._start));
                        if (index < (this.Count >>> 0))
                        {
                            return (index | 0);
                        }
                        return -1;
                    }
                    /*T*/ get_Item(/*int*/ index)
                    {
                        if ((index >>> 0) >= (this.Count >>> 0))
                        {
                            $.$sl.System.Linq.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.index*/);
                        }
                        return T.System$Numerics$IAdditionOperators$$$$$op_Addition(this._start, T.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Int32, index));
                    }
                    /*void*/ set_Item(/*int*/ index, /*T*/ value)
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
                    }
                    /*bool */ get IsReadOnly()
                    {
                        return true;
                    }
                    /*void */ System$Collections$Generic$ICollection$$$Add(/*T*/ item)
                    {
                        return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
                    }
                    /*void */ System$Collections$Generic$ICollection$$$Clear()
                    {
                        return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
                    }
                    /*void */ System$Collections$Generic$IList$$$Insert(/*int*/ index, /*T*/ item)
                    {
                        return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
                    }
                    /*bool */ System$Collections$Generic$ICollection$$$Remove(/*T*/ item)
                    {
                        return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException_Boolean();
                    }
                    /*void */ System$Collections$Generic$IList$$$RemoveAt(/*int*/ index)
                    {
                        return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<T>.this[int].get
                    System$Collections$Generic$IList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<T>.this[int].set
                    System$Collections$Generic$IList$$$set_Item()
                    {
                        return this.set_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<T>.IndexOf(T)
                    System$Collections$Generic$IList$$$IndexOf()
                    {
                        return this.IndexOf(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<T>.IsReadOnly.get
                    get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        return this.IsReadOnly;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<T>.Contains(T)
                    System$Collections$Generic$ICollection$$$Contains()
                    {
                        return this.Contains(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<T>.CopyTo(T[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        return this.CopyTo(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<T>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<T>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        return this.Count;
                    }
                    static $h = 3080199;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(T); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerator$$(T), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator, $.$spc.System.Collections.Generic.IList$$(T), $.$spc.System.Collections.Generic.ICollection$$(T), $.$spc.System.Collections.Generic.IReadOnlyList$$(T), $.$spc.System.Collections.Generic.IReadOnlyCollection$$(T), $.$spc.System.Collections.Generic.IEnumerable$$(T), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Linq.Enumerable.RangeIterator<${T?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_RangeIterator$$ = $v))(T);
            }
            static /*void */ FillIncrementing(T, /*Span<T>*/ destination, /*T*/ value)
            {
                /*ref T*/ let pos = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference(T, destination);
                /*ref T*/ let end = $.$spc.System.Runtime.CompilerServices.Unsafe.Add(T, pos, destination.Length);
                //if (Vector.IsHardwareAccelerated &&                Vector<T>.IsSupported &&                destination.Length >= Vector<T>.Count) { ... }
                while($.$spc.System.Runtime.CompilerServices.Unsafe.IsAddressLessThan(T, pos, end))
                {
                    pos.$v = (() => //value++
                    {
                        const $old = value;
                        value = T.System$Numerics$IIncrementOperators$$$op_Increment(value);
                        return $old;
                    })();
                    pos = $.$spc.System.Runtime.CompilerServices.Unsafe.Add(T, pos, 1);
                }
            }
            static /*IEnumerable<TResult> */ Repeat(TResult, /*TResult*/ element, /*int*/ count)
            {
                if (count < 0)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.count*/);
                }
                if (count === 0)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                }
                return new ($.$sl.System.Linq.Enumerable.RepeatIterator$$(TResult))().$ctor$2(element, count);
            }
            static $_RepeatIterator$$;
            static RepeatIterator$$(TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_RepeatIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.RepeatIterator<>", (TResult) => $asm.$gt("$sl.System.Linq.Enumerable.RepeatIterator<>", [TResult], ($self) => class RepeatIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*int*/ _count = 0;
                    $ctor$2(/*TResult*/ element, /*int*/ count)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                            this._current = element;
                            this._count = count;
                        }
                        return this;
                    }
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.RepeatIterator$$(TResult))().$ctor$2(this._current, this._count);
                    }
                    /*void */ Dispose()
                    {
                        this._state = -1;
                    }
                    /*bool */ MoveNext()
                    {
                        /*int*/ let sent = ((this._state - 1) | 0);
                        if (sent >= 0 && sent !== this._count)
                        {
                            ++this._state;
                            return true;
                        }
                        this.Dispose();
                        return false;
                    }
                    /*TResult[] */ ToArray()
                    {
                        /*TResult[]*/ let array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TResult), null, [this._count], null);
                        if (!(this._current === null))
                        {
                            $.$spc.System.Array.Fill(TResult, array, this._current);
                        }
                        return array;
                    }
                    /*List<TResult> */ ToList()
                    {
                        /*List<TResult>*/ let list = new ($.$spc.System.Collections.Generic.List$$(TResult))().$ctor$2(this._count);
                        $.$sl.System.Linq.Enumerable.SetCountAndGetSpan(TResult, list, this._count).Fill(this._current);
                        return list;
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        return this._count;
                    }
                    /*int */ get Count()
                    {
                        return this._count;
                    }
                    /*Iterator<TResult>? */ Skip(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        if (count >= this._count)
                        {
                            return null;
                        }
                        return new ($.$sl.System.Linq.Enumerable.RepeatIterator$$(TResult))().$ctor$2(this._current, ((this._count - count) | 0));
                    }
                    /*Iterator<TResult> */ Take(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        if (count >= this._count)
                        {
                            return this;
                        }
                        return new ($.$sl.System.Linq.Enumerable.RepeatIterator$$(TResult))().$ctor$2(this._current, count);
                    }
                    /*TResult? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if ((index >>> 0) < (this._count >>> 0))
                        {
                            found.$v = true;
                            return this._current;
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult */ TryGetFirst(/*out bool*/ found)
                    {
                        found.$v = true;
                        return this._current;
                    }
                    /*TResult */ TryGetLast(/*out bool*/ found)
                    {
                        found.$v = true;
                        return this._current;
                    }
                    /*bool */ Contains(/*TResult*/ item)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._count > 0, "_count > 0");
                        return $.$spc.System.Collections.Generic.EqualityComparer$$(TResult).Default.Equals$2(this._current, item);
                    }
                    /*int */ IndexOf(/*TResult*/ item)
                    {
                        return this.Contains(item) ? 0 : -1;
                    }
                    /*void */ CopyTo(/*TResult[]*/ array, /*int*/ arrayIndex)
                    {
                        return $.$spc.System.MemoryExtensions.AsSpan$9(TResult, array, arrayIndex, this._count).Fill(this._current);
                    }
                    /*TResult*/ get_Item(/*int*/ index)
                    {
                        if ((index >>> 0) >= (this._count >>> 0))
                        {
                            $.$sl.System.Linq.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.index*/);
                        }
                        return this._current;
                    }
                    /*void*/ set_Item(/*int*/ index, /*TResult*/ value)
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
                    }
                    /*bool */ get IsReadOnly()
                    {
                        return true;
                    }
                    /*void */ System$Collections$Generic$ICollection$$$Add(/*TResult*/ item)
                    {
                        return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
                    }
                    /*void */ System$Collections$Generic$ICollection$$$Clear()
                    {
                        return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
                    }
                    /*void */ System$Collections$Generic$IList$$$Insert(/*int*/ index, /*TResult*/ item)
                    {
                        return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
                    }
                    /*bool */ System$Collections$Generic$ICollection$$$Remove(/*TResult*/ item)
                    {
                        return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException_Boolean();
                    }
                    /*void */ System$Collections$Generic$IList$$$RemoveAt(/*int*/ index)
                    {
                        return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<TResult>.this[int].get
                    System$Collections$Generic$IList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<TResult>.this[int].set
                    System$Collections$Generic$IList$$$set_Item()
                    {
                        return this.set_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<TResult>.IndexOf(TResult)
                    System$Collections$Generic$IList$$$IndexOf()
                    {
                        return this.IndexOf(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TResult>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TResult>.IsReadOnly.get
                    get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        return this.IsReadOnly;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TResult>.Contains(TResult)
                    System$Collections$Generic$ICollection$$$Contains()
                    {
                        return this.Contains(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TResult>.CopyTo(TResult[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        return this.CopyTo(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<TResult>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<TResult>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        return this.Count;
                    }
                    static $h = 3211271;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator, $.$spc.System.Collections.Generic.IList$$(TResult), $.$spc.System.Collections.Generic.ICollection$$(TResult), $.$spc.System.Collections.Generic.IReadOnlyList$$(TResult), $.$spc.System.Collections.Generic.IReadOnlyCollection$$(TResult), $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Linq.Enumerable.RepeatIterator<${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_RepeatIterator$$ = $v))(TResult);
            }
            static $_ShuffleIterator$$;
            static ShuffleIterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_ShuffleIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.ShuffleIterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.ShuffleIterator<>", [TSource], ($self) => class ShuffleIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TSource)
                {
                    /*TSource[] */ ToArray()
                    {
                        /*TSource[]*/ let array = $.$sl.System.Linq.Enumerable.ToArray(TSource, this._source);
                        $.$spc.System.Random.Shared.Shuffle(TSource, array);
                        return array;
                    }
                    /*List<TSource> */ ToList()
                    {
                        /*List<TSource>*/ let list = $.$sl.System.Linq.Enumerable.ToList(TSource, this._source);
                        $.$spc.System.Random.Shared.Shuffle$1(TSource, $.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, list));
                        return list;
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        /*int*/ let count;
                        return !onlyIfCheap ? $.$sl.System.Linq.Enumerable.Count(TSource, this._source) : $.$sl.System.Linq.Enumerable.TryGetNonEnumeratedCount(TSource, this._source, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32)) ? count : -1;
                    }
                    /*TSource? */ TryGetFirst(/*out bool*/ found)
                    {
                        return this.TryGetElementAt(0, found);
                    }
                    /*TSource? */ TryGetLast(/*out bool*/ found)
                    {
                        return this.TryGetElementAt(0, found);
                    }
                    /*TSource? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        let iterator;
                        let iteratorCount;
                        let list;
                        if ($.$is(this._source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }) && $.$is(iterator.GetCount(true), $.$spc.System.Int32, { set $v(v){ iteratorCount = v; } }) && iteratorCount >= 0)
                        {
                            if ((index >>> 0) < (iteratorCount >>> 0))
                            {
                                return iterator.TryGetElementAt($.$spc.System.Random.Shared.Next$2(0, iteratorCount), found);
                            }
                        }
                        else if ($.$is(this._source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ list = v; } }))
                        {
                            /*int*/ let listCount = list.System$Collections$Generic$ICollection$$$Count;
                            if ((index >>> 0) < (listCount >>> 0))
                            {
                                found.$v = true;
                                return list.System$Collections$Generic$IList$$$get_Item($.$spc.System.Random.Shared.Next$2(0, listCount), [TSource]);
                            }
                        }
                        else if (index >= 0)
                        {
                            /*long*/ let totalElementCount;
                            /*List<TSource>?*/ let sample = $.$sl.System.Linq.Enumerable.ShuffleTakeIterator$$(TSource).SampleToList(this._source, 1, $.$ref(() => totalElementCount, ($v) => totalElementCount = $v, $.$spc.System.Int64));
                            if (!(sample === null) && BigInt(index) < totalElementCount)
                            {
                                found.$v = true;
                                return sample.get_Item(0);
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*Iterator<TSource>? */ Take(/*int*/ count)
                    {
                        /*int*/ let sourceCount;
                        if ($.$sl.System.Linq.Enumerable.TryGetNonEnumeratedCount(TSource, this._source, $.$ref(() => sourceCount, ($v) => sourceCount = $v, $.$spc.System.Int32)) && sourceCount <= count)
                        {
                            return super.Take(count);
                        }
                        return new ($.$sl.System.Linq.Enumerable.ShuffleTakeIterator$$(TSource))().$ctor$2(this._source, count);
                    }
                    /*bool */ Contains(/*TSource*/ value)
                    {
                        return $.$sl.System.Linq.Enumerable.Contains(TSource, this._source, value);
                    }
                    /*IEnumerable<TSource>*/ _source = null;
                    /*TSource[]?*/ _buffer = null;
                    $ctor$2(/*IEnumerable<TSource>*/ source)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            this._source = source;
                        }
                        return this;
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.ShuffleIterator$$(TSource))().$ctor$2(this._source);
                    }
                    /*bool */ MoveNext()
                    {
                        /*int*/ let state;
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    state = this._state;
                                }
                                case 1: /*Initialized*/
                                if (state > 1)
                                {
                                    /*TSource[]?*/ let buffer = this._buffer;
                                    $.$spc.System.Diagnostics.Debug.Assert$1(!(buffer === null), "buffer is not null");
                                    /*int*/ let i = ((state - 2) | 0);
                                    if ((i >>> 0) < (buffer.length >>> 0))
                                    {
                                        this._current = $.$spc.System.Array.$ReadT1.call(buffer, i);
                                        this._state++;
                                        return true;
                                    }
                                }
                                else if (state === 1)
                                {
                                    /*TSource[]*/ let buffer = $.$sl.System.Linq.Enumerable.ToArray(TSource, this._source);
                                    if (buffer.length !== 0)
                                    {
                                        $.$spc.System.Random.Shared.Shuffle(TSource, buffer);
                                        this._buffer = buffer;
                                        this._state = state = 2;
                                        $gotoJumpState1 = 1; /*goto Initialized*/
                                        continue $gotoJumpStart1;
                                    }
                                }
                                this.Dispose();
                                return false;
                            }
                            break;
                        }
                    }
                    /*void */ Dispose()
                    {
                        this._buffer = null;
                        super.Dispose();
                    }
                    static $h = 3407879;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.ShuffleIterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ShuffleIterator$$ = $v))(TSource);
            }
            static $_ShuffleTakeIterator$$;
            static ShuffleTakeIterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_ShuffleTakeIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.ShuffleTakeIterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.ShuffleTakeIterator<>", [TSource], ($self) => class ShuffleTakeIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TSource)
                {
                    /*IEnumerable<TSource>*/ _source = null;
                    /*int*/ _takeCount = 0;
                    /*List<TSource>?*/ _buffer = null;
                    $ctor$2(/*IEnumerable<TSource>*/ source, /*int*/ takeCount)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(takeCount > 0, "takeCount > 0");
                            this._source = source;
                            this._takeCount = takeCount;
                        }
                        return this;
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.ShuffleTakeIterator$$(TSource))().$ctor$2(this._source, this._takeCount);
                    }
                    /*bool */ MoveNext()
                    {
                        /*int*/ let state;
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    state = this._state;
                                }
                                case 1: /*Initialized*/
                                if (state > 1)
                                {
                                    /*List<TSource>?*/ let buffer = this._buffer;
                                    $.$spc.System.Diagnostics.Debug.Assert$1(!(buffer === null), "buffer is not null");
                                    /*int*/ let i = ((state - 2) | 0);
                                    if (i < buffer.Count)
                                    {
                                        this._current = buffer.get_Item(i);
                                        this._state++;
                                        return true;
                                    }
                                }
                                else if (state === 1)
                                {
                                    /*List<TSource>?*/ let buffer = $.$sl.System.Linq.Enumerable.ShuffleTakeIterator$$(TSource).SampleToList(this._source, this._takeCount, $.$discardRef());
                                    if (!(buffer === null))
                                    {
                                        this._buffer = buffer;
                                        this._state = state = 2;
                                        $gotoJumpState1 = 1; /*goto Initialized*/
                                        continue $gotoJumpStart1;
                                    }
                                }
                                this.Dispose();
                                return false;
                            }
                            break;
                        }
                    }
                    /*void */ Dispose()
                    {
                        this._buffer = null;
                        super.Dispose();
                    }
                    /*TSource[] */ ToArray()
                    {
                        return ($.$sl.System.Linq.Enumerable.ShuffleTakeIterator$$(TSource).SampleToList(this._source, this._takeCount, $.$discardRef())?.ToArray() ?? null) ?? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                    }
                    /*List<TSource> */ ToList()
                    {
                        return $.$sl.System.Linq.Enumerable.ShuffleTakeIterator$$(TSource).SampleToList(this._source, this._takeCount, $.$discardRef()) ?? (() =>
                        {
                            let $t1 = new ($.$spc.System.Collections.Generic.List$$(TSource))().$ctor$1();
                            return $t1;
                        })();
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        /*int*/ let count;
                        return $.$sl.System.Linq.Enumerable.TryGetNonEnumeratedCount(TSource, this._source, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32)) ? $.$spc.System.Math.Min$4(this._takeCount, count) : !onlyIfCheap ? $.$sl.System.Linq.Enumerable.Count(TSource, $.$sl.System.Linq.Enumerable.Take(TSource, this._source, this._takeCount)) : -1;
                    }
                    /*TSource? */ TryGetFirst(/*out bool*/ found)
                    {
                        return this.TryGetElementAt(0, found);
                    }
                    /*TSource? */ TryGetLast(/*out bool*/ found)
                    {
                        return this.TryGetElementAt(0, found);
                    }
                    /*TSource? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        let iterator;
                        let iteratorCount;
                        let list;
                        if ($.$is(this._source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }) && $.$is(iterator.GetCount(true), $.$spc.System.Int32, { set $v(v){ iteratorCount = v; } }) && iteratorCount >= 0)
                        {
                            if ((index >>> 0) < ($.$spc.System.Math.Min$4(this._takeCount, iteratorCount) >>> 0))
                            {
                                return iterator.TryGetElementAt($.$spc.System.Random.Shared.Next$2(0, iteratorCount), found);
                            }
                        }
                        else if ($.$is(this._source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ list = v; } }))
                        {
                            /*int*/ let count = list.System$Collections$Generic$ICollection$$$Count;
                            if ((index >>> 0) < ($.$spc.System.Math.Min$4(this._takeCount, count) >>> 0))
                            {
                                found.$v = true;
                                return list.System$Collections$Generic$IList$$$get_Item($.$spc.System.Random.Shared.Next$2(0, count), [TSource]);
                            }
                        }
                        else if (index >= 0)
                        {
                            /*long*/ let totalElementCount;
                            /*List<TSource>?*/ let sample = $.$sl.System.Linq.Enumerable.ShuffleTakeIterator$$(TSource).SampleToList(this._source, 1, $.$ref(() => totalElementCount, ($v) => totalElementCount = $v, $.$spc.System.Int64));
                            if (!(sample === null) && BigInt(index) < $.$spc.System.Math.Min$5(BigInt(this._takeCount), totalElementCount))
                            {
                                found.$v = true;
                                return sample.get_Item(0);
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*Iterator<TSource>? */ Take(/*int*/ count)
                    {
                        return this._takeCount <= count ? this : new ($.$sl.System.Linq.Enumerable.ShuffleTakeIterator$$(TSource))().$ctor$2(this._source, count);
                    }
                    static /*List<TSource>? */ SampleToList(/*IEnumerable<TSource>*/ source, /*int*/ takeCount, /*out long*/ totalElementCount)
                    {
                        /*List<TSource>?*/ let reservoir;
                        let $gotoJumpState1 = 0;
                        $gotoJumpStart1: while(true)
                        {
                            switch($gotoJumpState1)
                            {
                                case 0:
                                {
                                    reservoir = null;
                                    let list;
                                    if ($.$is(source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ list = v; } }))
                                    {
                                        /*int*/ let listCount = list.System$Collections$Generic$ICollection$$$Count;
                                        $.$spc.System.Diagnostics.Debug.Assert$1(listCount > takeCount, "Known listCount <= takeCount should have been handled by Iterator.Take override");
                                        reservoir = new ($.$spc.System.Collections.Generic.List$$(TSource))().$ctor$2(takeCount);
                                        for(/*int*/ let i = 0; i < takeCount; i++)
                                        {
                                            reservoir.Add(list.System$Collections$Generic$IList$$$get_Item(i, [TSource]));
                                        }
                                        for(/*int*/ let i = takeCount; i < listCount; i++)
                                        {
                                            /*int*/ let r = $.$spc.System.Random.Shared.Next$1(((i + 1) | 0));
                                            if (r < takeCount)
                                            {
                                                reservoir.set_Item(r, list.System$Collections$Generic$IList$$$get_Item(i, [TSource]));
                                            }
                                        }
                                        totalElementCount.$v = BigInt(listCount);
                                    }
                                    else 
                                    {
                                        /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                                        try
                                        {
                                            if (e.System$Collections$IEnumerator$MoveNext())
                                            {
                                                reservoir = (() =>
                                                {
                                                    //new $.$spc.System.Collections.Generic.List$$(TSource)()
                                                    const $t2 = $.$spc.System.Collections.Generic.List$$(TSource);
                                                    const $i2 = new $t2();
                                                    $i2.$ctor$2($.$spc.System.Math.Min$4(takeCount, 4));
                                                    $i2.Add(e.System$Collections$Generic$IEnumerator$$$Current);
                                                    return $i2;
                                                })();
                                                while(reservoir.Count < takeCount)
                                                {
                                                    if (!e.System$Collections$IEnumerator$MoveNext())
                                                    {
                                                        totalElementCount.$v = BigInt(reservoir.Count);
                                                        $gotoJumpState1 = 1; /*goto ReturnReservoir*/
                                                        continue $gotoJumpStart1;
                                                    }
                                                    reservoir.Add(e.System$Collections$Generic$IEnumerator$$$Current);
                                                }
                                                /*long*/ let i = BigInt(takeCount);
                                                while(e.System$Collections$IEnumerator$MoveNext())
                                                {
                                                    i++;
                                                    /*long*/ let r = $.$spc.System.Random.Shared.NextInt64$1(i);
                                                    if (r < BigInt(takeCount))
                                                    {
                                                        reservoir.set_Item($.$cast(r, $.$spc.System.Int32), e.System$Collections$Generic$IEnumerator$$$Current);
                                                    }
                                                }
                                                totalElementCount.$v = i;
                                            }
                                            else 
                                            {
                                                totalElementCount.$v = 0n;
                                            }
                                        }
                                        finally
                                        {
                                            e?.System$IDisposable$Dispose();
                                        }
                                    }
                                }
                                case 1: /*ReturnReservoir*/
                                if (!(reservoir === null))
                                {
                                    $.$spc.System.Random.Shared.Shuffle$1(TSource, $.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, reservoir));
                                }
                                return reservoir;
                            }
                            break;
                        }
                    }
                    /*bool */ Contains(/*TSource*/ value)
                    {
                        /*long*/ let totalCount, equalCount = 0n;
                        let list;
                        let iterator;
                        let iteratorCount;
                        if ($.$is(this._source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ list = v; } }))
                        {
                            if (list.System$Collections$Generic$ICollection$$$Count <= this._takeCount)
                            {
                                return list.System$Collections$Generic$ICollection$$$Contains(value, [TSource]);
                            }
                            totalCount = BigInt(list.System$Collections$Generic$ICollection$$$Count);
                            /*ReadOnlySpan<TSource>*/ let span;
                            if ($.$sl.System.Linq.Enumerable.TryGetSpan(TSource, list, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(TSource))))
                            {
                                equalCount = BigInt($.$spc.System.MemoryExtensions.Count$2(TSource, span, value, null));
                            }
                            else 
                            {
                                for(/*int*/ let i = 0; BigInt(i) < totalCount; i++)
                                {
                                    if ($.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default.Equals$2(list.System$Collections$Generic$IList$$$get_Item(i, [TSource]), value))
                                    {
                                        equalCount++;
                                    }
                                }
                            }
                        }
                        else if ($.$is(this._source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }) && $.$is(iterator.GetCount(true), $.$spc.System.Int32, { set $v(v){ iteratorCount = v; } }) && iteratorCount >= 0)
                        {
                            if (iteratorCount <= this._takeCount)
                            {
                                return iterator.Contains(value);
                            }
                            totalCount = BigInt(iteratorCount);
                            var $en5 = iterator.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var item = $en5.Current;
                                {
                                    if ($.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default.Equals$2(item, value))
                                    {
                                        equalCount++;
                                    }
                                }
                            }
                        }
                        else 
                        {
                            totalCount = 0n;
                            var $en5 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var item = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    totalCount++;
                                    if ($.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default.Equals$2(item, value))
                                    {
                                        equalCount++;
                                    }
                                }
                            }
                        }
                        if (equalCount === 0n)
                        {
                            return false;
                        }
                        if (equalCount === totalCount)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._takeCount > 0, `Expected positive ${"_takeCount"}.`);
                            return true;
                        }
                        if (totalCount <= BigInt(this._takeCount))
                        {
                            return equalCount > 0n;
                        }
                        /*double*/ let probOfDrawingZeroMatches = 1;
                        for(/*long*/ let i = 0n; i < BigInt(this._takeCount); i++)
                        {
                            probOfDrawingZeroMatches *= $.$cast((totalCount - equalCount - i), $.$spc.System.Double) / (Number(totalCount - i));
                        }
                        return $.$spc.System.Random.Shared.NextDouble() > probOfDrawingZeroMatches;
                    }
                    static $h = 3473415;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.ShuffleTakeIterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ShuffleTakeIterator$$ = $v))(TSource);
            }
            static /*IEnumerable<TSource> */ Shuffle(TSource, /*this IEnumerable<TSource>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                }
                return new ($.$sl.System.Linq.Enumerable.ShuffleIterator$$(TSource))().$ctor$2(source);
            }
            static /*IEnumerable<TSource> */ Reverse(TSource, /*this IEnumerable<TSource>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                }
                return new ($.$sl.System.Linq.Enumerable.ReverseIterator$$(TSource))().$ctor$2(source);
            }
            static /*IEnumerable<TSource> */ Reverse$1(TSource, /*this TSource[]*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (source.length === 0)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                }
                return new ($.$sl.System.Linq.Enumerable.ReverseIterator$$(TSource))().$ctor$2(source);
            }
            static $_ReverseIterator$$;
            static ReverseIterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_ReverseIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.ReverseIterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.ReverseIterator<>", [TSource], ($self) => class ReverseIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TSource)
                {
                    /*IEnumerable<TSource>*/ _source = null;
                    /*TSource[]?*/ _buffer = null;
                    $ctor$2(/*IEnumerable<TSource>*/ source)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            this._source = source;
                        }
                        return this;
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.ReverseIterator$$(TSource))().$ctor$2(this._source);
                    }
                    /*bool */ MoveNext()
                    {
                        if (((this._state - 2) | 0) <= -2)
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(this._state === -1 || this._state === 0, "_state == -1 || _state == 0");
                            this.Dispose();
                            return false;
                        }
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                /*TSource[]*/ let buffer = $.$sl.System.Linq.Enumerable.ToArray(TSource, this._source);
                                this._buffer = buffer;
                                this._state = ((buffer.length + 2) | 0);
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                                default:
                                /*int*/ let index = ((this._state - 3) | 0);
                                if (index !== -1)
                                {
                                    $.$spc.System.Diagnostics.Debug.Assert$1(!(this._buffer === null), "_buffer is not null");
                                    this._current = $.$spc.System.Array.$ReadT1.call(this._buffer, index);
                                    --this._state;
                                    return true;
                                }
                                break;
                            }
                            break;
                        }
                        this.Dispose();
                        return false;
                    }
                    /*void */ Dispose()
                    {
                        this._buffer = null;
                        super.Dispose();
                    }
                    /*TSource[] */ ToArray()
                    {
                        /*TSource[]*/ let array = $.$sl.System.Linq.Enumerable.ToArray(TSource, this._source);
                        $.$spc.System.Array.Reverse$2(TSource, array);
                        return array;
                    }
                    /*List<TSource> */ ToList()
                    {
                        /*List<TSource>*/ let list = $.$sl.System.Linq.Enumerable.ToList(TSource, this._source);
                        list.Reverse();
                        return list;
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        /*int*/ let count;
                        return !onlyIfCheap ? $.$sl.System.Linq.Enumerable.Count(TSource, this._source) : $.$sl.System.Linq.Enumerable.TryGetNonEnumeratedCount(TSource, this._source, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32)) ? count : -1;
                    }
                    /*TSource? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        let list;
                        if ($.$is(this._source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ list = v; } }))
                        {
                            /*int*/ let count = list.System$Collections$Generic$ICollection$$$Count;
                            if ((index >>> 0) < (count >>> 0))
                            {
                                found.$v = true;
                                return list.System$Collections$Generic$IList$$$get_Item(((((count - index) | 0) - 1) | 0), [TSource]);
                            }
                        }
                        else if (index >= 0)
                        {
                            /*TSource[]*/ let array = $.$sl.System.Linq.Enumerable.ToArray(TSource, this._source);
                            if (index < array.length)
                            {
                                found.$v = true;
                                return $.$spc.System.Array.$ReadT1.call(array, ((((array.length - index) | 0) - 1) | 0));
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*TSource? */ TryGetFirst(/*out bool*/ found)
                    {
                        let iterator;
                        let list;
                        if ($.$is(this._source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }))
                        {
                            return iterator.TryGetLast(found);
                        }
                        else if ($.$is(this._source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ list = v; } }))
                        {
                            /*int*/ let count = list.System$Collections$Generic$ICollection$$$Count;
                            if (count > 0)
                            {
                                found.$v = true;
                                return list.System$Collections$Generic$IList$$$get_Item(((count - 1) | 0), [TSource]);
                            }
                        }
                        else 
                        {
                            /*IEnumerator<TSource>*/ let e = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                            try
                            {
                                if (e.System$Collections$IEnumerator$MoveNext())
                                {
                                    /*TSource*/ let result;
                                    do
                                    {
                                        result = e.System$Collections$Generic$IEnumerator$$$Current;
                                    }
                                    while(e.System$Collections$IEnumerator$MoveNext());
                                    found.$v = true;
                                    return result;
                                }
                            }
                            finally
                            {
                                e?.System$IDisposable$Dispose();
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*TSource? */ TryGetLast(/*out bool*/ found)
                    {
                        let iterator;
                        let list;
                        if ($.$is(this._source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }))
                        {
                            return iterator.TryGetFirst(found);
                        }
                        else if ($.$is(this._source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ list = v; } }))
                        {
                            if (list.System$Collections$Generic$ICollection$$$Count > 0)
                            {
                                found.$v = true;
                                return list.System$Collections$Generic$IList$$$get_Item(0, [TSource]);
                            }
                        }
                        else 
                        {
                            /*IEnumerator<TSource>*/ let e = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                            try
                            {
                                if (e.System$Collections$IEnumerator$MoveNext())
                                {
                                    found.$v = true;
                                    return e.System$Collections$Generic$IEnumerator$$$Current;
                                }
                            }
                            finally
                            {
                                e?.System$IDisposable$Dispose();
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*bool */ Contains(/*TSource*/ value)
                    {
                        return $.$sl.System.Linq.Enumerable.Contains(TSource, this._source, value);
                    }
                    static $h = 3276807;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.ReverseIterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ReverseIterator$$ = $v))(TSource);
            }
            static /*IEnumerable<TResult> */ RightJoin(TOuter, TInner, TKey, TResult, /*this IEnumerable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Func<TOuter, TKey>*/ outerKeySelector, /*Func<TInner, TKey>*/ innerKeySelector, /*Func<TOuter?, TInner, TResult>*/ resultSelector)
            {
                return $.$sl.System.Linq.Enumerable.RightJoin$1(TOuter, TInner, TKey, TResult, outer, inner, outerKeySelector, innerKeySelector, resultSelector, null);
            }
            static /*IEnumerable<TResult> */ RightJoin$1(TOuter, TInner, TKey, TResult, /*this IEnumerable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Func<TOuter, TKey>*/ outerKeySelector, /*Func<TInner, TKey>*/ innerKeySelector, /*Func<TOuter?, TInner, TResult>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (outer === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(10/*ExceptionArgument.outer*/);
                }
                if (inner === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(7/*ExceptionArgument.inner*/);
                }
                if (outerKeySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(11/*ExceptionArgument.outerKeySelector*/);
                }
                if (innerKeySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(8/*ExceptionArgument.innerKeySelector*/);
                }
                if (resultSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(13/*ExceptionArgument.resultSelector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TInner, inner))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.RightJoinIterator(TOuter, TInner, TKey, TResult, outer, inner, outerKeySelector, innerKeySelector, resultSelector, comparer);
            }
            static /*IEnumerable<TResult> */ RightJoinIterator(TOuter, TInner, TKey, TResult, /*IEnumerable<TOuter>*/ outer, /*IEnumerable<TInner>*/ inner, /*Func<TOuter, TKey>*/ outerKeySelector, /*Func<TInner, TKey>*/ innerKeySelector, /*Func<TOuter?, TInner, TResult>*/ resultSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*IEnumerator<TInner>*/ let e = inner.System$Collections$Generic$IEnumerable$$$GetEnumerator([TInner]);
                    try
                    {
                        if (e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*Lookup<TKey, TOuter>*/ let outerLookup = $.$sl.System.Linq.Lookup$$$(TKey, TOuter).CreateForJoin(outer, outerKeySelector, comparer);
                            do
                            {
                                /*TInner*/ let item = e.System$Collections$Generic$IEnumerator$$$Current;
                                /*Grouping<TKey, TOuter>?*/ let g = outerLookup.GetGrouping(innerKeySelector.Invoke(item), false);
                                if (g === null)
                                {
                                    yield resultSelector.Invoke($.$default(TOuter), item);
                                }
                                else 
                                {
                                    /*int*/ let count = g._count;
                                    /*TOuter[]*/ let elements = g._elements;
                                    for(/*int*/ let i = 0; i !== count; ++i)
                                    {
                                        yield resultSelector.Invoke($.$spc.System.Array.$ReadT1.call(elements, i), item);
                                    }
                                }
                            }
                            while(e.System$Collections$IEnumerator$MoveNext());
                        }
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            static /*IEnumerable<TResult> */ Select(TSource, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TResult>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                let iterator;
                if ($.$is(source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }))
                {
                    if ($.$sl.System.Linq.Enumerable.IsSizeOptimized && TResult.$type.IsValueType)
                    {
                        let il;
                        return $.$is(source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ il = v; } }) ? new ($.$sl.System.Linq.Enumerable.SizeOptIListSelectIterator$$$(TSource, TResult))().$ctor$2(il, selector) : new ($.$sl.System.Linq.Enumerable.IEnumerableSelectIterator$$$(TSource, TResult))().$ctor$2(iterator, selector);
                    }
                    else 
                    {
                        return iterator.Select(TResult, selector);
                    }
                }
                let ilist;
                if ($.$is(source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ ilist = v; } }))
                {
                    if ($.$sl.System.Linq.Enumerable.IsSizeOptimized)
                    {
                        return new ($.$sl.System.Linq.Enumerable.SizeOptIListSelectIterator$$$(TSource, TResult))().$ctor$2(ilist, selector);
                    }
                    let array;
                    if ($.$is(source, $.$typeArray(TSource), { set $v(v){ array = v; } }))
                    {
                        if (array.length === 0)
                        {
                            return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                        }
                        return new ($.$sl.System.Linq.Enumerable.ArraySelectIterator$$$(TSource, TResult))().$ctor$2(array, selector);
                    }
                    let list;
                    if ($.$is(source, $.$spc.System.Collections.Generic.List$$(TSource), { set $v(v){ list = v; } }))
                    {
                        return new ($.$sl.System.Linq.Enumerable.ListSelectIterator$$$(TSource, TResult))().$ctor$2(list, selector);
                    }
                    return new ($.$sl.System.Linq.Enumerable.IListSelectIterator$$$(TSource, TResult))().$ctor$2(ilist, selector);
                }
                return new ($.$sl.System.Linq.Enumerable.IEnumerableSelectIterator$$$(TSource, TResult))().$ctor$2(source, selector);
            }
            static /*IEnumerable<TResult> */ Select$1(TSource, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, int, TResult>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.SelectIterator(TSource, TResult, source, selector);
            }
            static /*IEnumerable<TResult> */ SelectIterator(TSource, TResult, /*IEnumerable<TSource>*/ source, /*Func<TSource, int, TResult>*/ selector)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*int*/ let index = -1;
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            //checked
                            {
                                index++;
                            }
                            yield selector.Invoke(element, index);
                        }
                    }
                }.bind(this));
            }
            static $_IEnumerableSelectIterator$$$;
            static IEnumerableSelectIterator$$$(TSource, TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_IEnumerableSelectIterator$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.IEnumerableSelectIterator<,>", (TSource, TResult) => $asm.$gt("$sl.System.Linq.Enumerable.IEnumerableSelectIterator<,>", [TSource, TResult], ($self) => class IEnumerableSelectIterator$$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*IEnumerable<TSource>*/ _source = null;
                    /*Func<TSource, TResult>*/ _selector = null;
                    /*IEnumerator<TSource>?*/ _enumerator = null;
                    $ctor$2(/*IEnumerable<TSource>*/ source, /*Func<TSource, TResult>*/ selector)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(selector === null), "selector is not null");
                            this._source = source;
                            this._selector = selector;
                        }
                        return this;
                    }
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.IEnumerableSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector);
                    }
                    /*void */ Dispose()
                    {
                        if (!(this._enumerator === null))
                        {
                            this._enumerator.System$IDisposable$Dispose();
                            this._enumerator = null;
                        }
                        super.Dispose();
                    }
                    /*bool */ MoveNext()
                    {
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                this._enumerator = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                                this._state = 2;
                                $switchJumpState1 = 2; /*goto case 2*/
                                continue $switchJumpStart1;
                                case 2:
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._enumerator === null), "_enumerator is not null");
                                if (this._enumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    this._current = this._selector.Invoke(this._enumerator.System$Collections$Generic$IEnumerator$$$Current);
                                    return true;
                                }
                                this.Dispose();
                                break;
                            }
                            break;
                        }
                        return false;
                    }
                    /*IEnumerable<TResult2> */ Select(TResult2, /*Func<TResult, TResult2>*/ selector)
                    {
                        return new ($.$sl.System.Linq.Enumerable.IEnumerableSelectIterator$$$(TSource, TResult2))().$ctor$2(this._source, $.$sl.System.Linq.Utilities.CombineSelectors(TSource, TResult, TResult2, this._selector, selector));
                    }
                    /*TResult[] */ ToArray()
                    {
                        /*SegmentedArrayBuilder<TResult>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TResult>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult))().$ctor$2($.$spc.System.Span$$(TResult).op_Implicit(scratch.$fields));
                        /*Func<TSource, TResult>*/ let selector = this._selector;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                builder.Add(selector.Invoke(item));
                            }
                        }
                        /*TResult[]*/ let result = builder.ToArray();
                        builder.Dispose();
                        return result;
                    }
                    /*List<TResult> */ ToList()
                    {
                        /*SegmentedArrayBuilder<TResult>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TResult>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult))().$ctor$2($.$spc.System.Span$$(TResult).op_Implicit(scratch.$fields));
                        /*Func<TSource, TResult>*/ let selector = this._selector;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                builder.Add(selector.Invoke(item));
                            }
                        }
                        /*List<TResult>*/ let result = builder.ToList();
                        builder.Dispose();
                        return result;
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        if (onlyIfCheap)
                        {
                            return -1;
                        }
                        /*int*/ let count = 0;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                this._selector.Invoke(item);
                                //checked
                                {
                                    count++;
                                }
                            }
                        }
                        return count;
                    }
                    /*TResult? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if (index >= 0)
                        {
                            /*IEnumerator<TSource>*/ let e = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                            try
                            {
                                while(e.System$Collections$IEnumerator$MoveNext())
                                {
                                    if (index === 0)
                                    {
                                        found.$v = true;
                                        return this._selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                                    }
                                    index--;
                                }
                            }
                            finally
                            {
                                {
                                    ($.$as(e, $.$spc.System.IDisposable))?.System$IDisposable$Dispose();
                                }
                            }
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult? */ TryGetFirst(/*out bool*/ found)
                    {
                        /*IEnumerator<TSource>*/ let e = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                        try
                        {
                            if (e.System$Collections$IEnumerator$MoveNext())
                            {
                                found.$v = true;
                                return this._selector.Invoke(e.System$Collections$Generic$IEnumerator$$$Current);
                            }
                            found.$v = false;
                            return $.$default(TResult);
                        }
                        finally
                        {
                            e?.System$IDisposable$Dispose();
                        }
                    }
                    /*TResult? */ TryGetLast(/*out bool*/ found)
                    {
                        /*IEnumerator<TSource>*/ let e = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                        try
                        {
                            if (e.System$Collections$IEnumerator$MoveNext())
                            {
                                found.$v = true;
                                /*TSource*/ let last = e.System$Collections$Generic$IEnumerator$$$Current;
                                while(e.System$Collections$IEnumerator$MoveNext())
                                {
                                    last = e.System$Collections$Generic$IEnumerator$$$Current;
                                }
                                return this._selector.Invoke(last);
                            }
                            found.$v = false;
                            return $.$default(TResult);
                        }
                        finally
                        {
                            e?.System$IDisposable$Dispose();
                        }
                    }
                    static $h = 1835015;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.IEnumerableSelectIterator<${TSource?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_IEnumerableSelectIterator$$$ = $v))(TSource, TResult);
            }
            static $_ArraySelectIterator$$$;
            static ArraySelectIterator$$$(TSource, TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_ArraySelectIterator$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.ArraySelectIterator<,>", (TSource, TResult) => $asm.$gt("$sl.System.Linq.Enumerable.ArraySelectIterator<,>", [TSource, TResult], ($self) => class ArraySelectIterator$$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*TSource[]*/ _source = null;
                    /*Func<TSource, TResult>*/ _selector = null;
                    $ctor$2(/*TSource[]*/ source, /*Func<TSource, TResult>*/ selector)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(selector === null), "selector is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(source.length > 0, "source.Length > 0");
                            this._source = source;
                            this._selector = selector;
                        }
                        return this;
                    }
                    /*int */ get CountForDebugger()
                    {
                        return this._source.length;
                    }
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.ArraySelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector);
                    }
                    /*bool */ MoveNext()
                    {
                        /*TSource[]*/ let source = this._source;
                        /*int*/ let index = ((this._state - 1) | 0);
                        if ((index >>> 0) < (source.length >>> 0))
                        {
                            this._state++;
                            this._current = this._selector.Invoke($.$spc.System.Array.$ReadT1.call(source, index));
                            return true;
                        }
                        this.Dispose();
                        return false;
                    }
                    /*IEnumerable<TResult2> */ Select(TResult2, /*Func<TResult, TResult2>*/ selector)
                    {
                        return new ($.$sl.System.Linq.Enumerable.ArraySelectIterator$$$(TSource, TResult2))().$ctor$2(this._source, $.$sl.System.Linq.Utilities.CombineSelectors(TSource, TResult, TResult2, this._selector, selector));
                    }
                    /*TResult[] */ ToArray()
                    {
                        /*TSource[]*/ let source = this._source;
                        $.$spc.System.Diagnostics.Debug.Assert$1(source.length > 0, "source.Length > 0");
                        /*var*/ let results = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TResult), null, [source.length], null);
                        $.$sl.System.Linq.Enumerable.ArraySelectIterator$$$(TSource, TResult).Fill($.$spc.System.ReadOnlySpan$$(TSource).op_Implicit(source), $.$spc.System.Span$$(TResult).op_Implicit(results), this._selector);
                        return results;
                    }
                    /*List<TResult> */ ToList()
                    {
                        /*TSource[]*/ let source = this._source;
                        $.$spc.System.Diagnostics.Debug.Assert$1(source.length > 0, "source.Length > 0");
                        /*var*/ let results = new ($.$spc.System.Collections.Generic.List$$(TResult))().$ctor$2(source.length);
                        $.$sl.System.Linq.Enumerable.ArraySelectIterator$$$(TSource, TResult).Fill($.$spc.System.ReadOnlySpan$$(TSource).op_Implicit(source), $.$sl.System.Linq.Enumerable.SetCountAndGetSpan(TResult, results, source.length), this._selector);
                        return results;
                    }
                    static /*void */ Fill(/*ReadOnlySpan<TSource>*/ source, /*Span<TResult>*/ destination, /*Func<TSource, TResult>*/ func)
                    {
                        for(/*int*/ let i = 0; i < destination.Length; i++)
                        {
                            destination.get_Item(i).$v = func.Invoke(source.get_Item(i).$v);
                        }
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        if (!onlyIfCheap)
                        {
                            let $i1 = 0;
                            let $arr1 = this._source;
                            while ($i1 < $arr1.length)
                            {
                                let item = $arr1[$i1++];
                                this._selector.Invoke(item);
                            }
                        }
                        return this._source.length;
                    }
                    /*Iterator<TResult>? */ Skip(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        if (count >= this._source.length)
                        {
                            return null;
                        }
                        return new ($.$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector, count, 2147483647/*int.MaxValue*/);
                    }
                    /*Iterator<TResult> */ Take(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        return count >= this._source.length ? this : new ($.$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector, 0, ((count - 1) | 0));
                    }
                    /*TResult? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        /*TSource[]*/ let source = this._source;
                        if ((index >>> 0) < (source.length >>> 0))
                        {
                            found.$v = true;
                            return this._selector.Invoke($.$spc.System.Array.$ReadT1.call(source, index));
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult */ TryGetFirst(/*out bool*/ found)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._source.length > 0, "_source.Length > 0");
                        found.$v = true;
                        return this._selector.Invoke($.$spc.System.Array.$ReadT1.call(this._source, 0));
                    }
                    /*TResult */ TryGetLast(/*out bool*/ found)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._source.length > 0, "_source.Length > 0");
                        found.$v = true;
                        return this._selector.Invoke($.$spc.System.Array.$ReadT1.call(this._source, this._source.length - 1));
                    }
                    /*bool */ Contains(/*TResult*/ value)
                    {
                        let $i1 = 0;
                        let $arr1 = this._source;
                        while ($i1 < $arr1.length)
                        {
                            let item = $arr1[$i1++];
                            if ($.$spc.System.Collections.Generic.EqualityComparer$$(TResult).Default.Equals$2(this._selector.Invoke(item), value))
                            {
                                return true;
                            }
                        }
                        return false;
                    }
                    static $h = 655367;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.ArraySelectIterator<${TSource?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ArraySelectIterator$$$ = $v))(TSource, TResult);
            }
            static $_ListSelectIterator$$$;
            static ListSelectIterator$$$(TSource, TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_ListSelectIterator$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.ListSelectIterator<,>", (TSource, TResult) => $asm.$gt("$sl.System.Linq.Enumerable.ListSelectIterator<,>", [TSource, TResult], ($self) => class ListSelectIterator$$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*List<TSource>*/ _source = null;
                    /*Func<TSource, TResult>*/ _selector = null;
                    /*List<TSource>.Enumerator*/ _enumerator;
                    $ctor$2(/*List<TSource>*/ source, /*Func<TSource, TResult>*/ selector)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(selector === null), "selector is not null");
                            this._source = source;
                            this._selector = selector;
                        }
                        return this;
                    }
                    /*int */ get CountForDebugger()
                    {
                        return this._source.Count;
                    }
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.ListSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector);
                    }
                    /*bool */ MoveNext()
                    {
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                this._enumerator = this._source.GetEnumerator();
                                this._state = 2;
                                $switchJumpState1 = 2; /*goto case 2*/
                                continue $switchJumpStart1;
                                case 2:
                                if (this._enumerator.MoveNext())
                                {
                                    this._current = this._selector.Invoke(this._enumerator.Current);
                                    return true;
                                }
                                this.Dispose();
                                break;
                            }
                            break;
                        }
                        return false;
                    }
                    /*IEnumerable<TResult2> */ Select(TResult2, /*Func<TResult, TResult2>*/ selector)
                    {
                        return new ($.$sl.System.Linq.Enumerable.ListSelectIterator$$$(TSource, TResult2))().$ctor$2(this._source, $.$sl.System.Linq.Utilities.CombineSelectors(TSource, TResult, TResult2, this._selector, selector));
                    }
                    /*TResult[] */ ToArray()
                    {
                        /*ReadOnlySpan<TSource>*/ let source = $.$spc.System.Span$$(TSource).op_Implicit$2($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, this._source));
                        if (source.Length === 0)
                        {
                            return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                        }
                        /*var*/ let results = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TResult), null, [source.Length], null);
                        $.$sl.System.Linq.Enumerable.ListSelectIterator$$$(TSource, TResult).Fill(source, $.$spc.System.Span$$(TResult).op_Implicit(results), this._selector);
                        return results;
                    }
                    /*List<TResult> */ ToList()
                    {
                        /*ReadOnlySpan<TSource>*/ let source = $.$spc.System.Span$$(TSource).op_Implicit$2($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, this._source));
                        /*var*/ let results = new ($.$spc.System.Collections.Generic.List$$(TResult))().$ctor$2(source.Length);
                        $.$sl.System.Linq.Enumerable.ListSelectIterator$$$(TSource, TResult).Fill(source, $.$sl.System.Linq.Enumerable.SetCountAndGetSpan(TResult, results, source.Length), this._selector);
                        return results;
                    }
                    static /*void */ Fill(/*ReadOnlySpan<TSource>*/ source, /*Span<TResult>*/ destination, /*Func<TSource, TResult>*/ func)
                    {
                        for(/*int*/ let i = 0; i < destination.Length; i++)
                        {
                            destination.get_Item(i).$v = func.Invoke(source.get_Item(i).$v);
                        }
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        /*int*/ let count = this._source.Count;
                        if (!onlyIfCheap)
                        {
                            for(/*int*/ let i = 0; i < count; i++)
                            {
                                this._selector.Invoke(this._source.get_Item(i));
                            }
                        }
                        return count;
                    }
                    /*Iterator<TResult> */ Skip(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        return new ($.$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector, count, 2147483647/*int.MaxValue*/);
                    }
                    /*Iterator<TResult> */ Take(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        return new ($.$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector, 0, ((count - 1) | 0));
                    }
                    /*TResult? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if ((index >>> 0) < (this._source.Count >>> 0))
                        {
                            found.$v = true;
                            return this._selector.Invoke(this._source.get_Item(index));
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult? */ TryGetFirst(/*out bool*/ found)
                    {
                        if (this._source.Count !== 0)
                        {
                            found.$v = true;
                            return this._selector.Invoke(this._source.get_Item(0));
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult? */ TryGetLast(/*out bool*/ found)
                    {
                        /*int*/ let len = this._source.Count;
                        if (len !== 0)
                        {
                            found.$v = true;
                            return this._selector.Invoke(this._source.get_Item(((len - 1) | 0)));
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*bool */ Contains(/*TResult*/ value)
                    {
                        /*int*/ let count = this._source.Count;
                        for(/*int*/ let i = 0; i < count; i++)
                        {
                            if ($.$spc.System.Collections.Generic.EqualityComparer$$(TResult).Default.Equals$2(this._selector.Invoke(this._source.get_Item(i)), value))
                            {
                                return true;
                            }
                        }
                        return false;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._enumerator = $.$default($.$spc.System.Collections.Generic.List$$(TSource).Enumerator);
                    }
                    static $h = 2555911;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.ListSelectIterator<${TSource?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ListSelectIterator$$$ = $v))(TSource, TResult);
            }
            static $_IListSelectIterator$$$;
            static IListSelectIterator$$$(TSource, TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_IListSelectIterator$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.IListSelectIterator<,>", (TSource, TResult) => $asm.$gt("$sl.System.Linq.Enumerable.IListSelectIterator<,>", [TSource, TResult], ($self) => class IListSelectIterator$$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*IList<TSource>*/ _source = null;
                    /*Func<TSource, TResult>*/ _selector = null;
                    /*IEnumerator<TSource>?*/ _enumerator = null;
                    $ctor$2(/*IList<TSource>*/ source, /*Func<TSource, TResult>*/ selector)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(selector === null), "selector is not null");
                            this._source = source;
                            this._selector = selector;
                        }
                        return this;
                    }
                    /*int */ get CountForDebugger()
                    {
                        return this._source.System$Collections$Generic$ICollection$$$Count;
                    }
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.IListSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector);
                    }
                    /*bool */ MoveNext()
                    {
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                this._enumerator = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                                this._state = 2;
                                $switchJumpState1 = 2; /*goto case 2*/
                                continue $switchJumpStart1;
                                case 2:
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._enumerator === null), "_enumerator is not null");
                                if (this._enumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    this._current = this._selector.Invoke(this._enumerator.System$Collections$Generic$IEnumerator$$$Current);
                                    return true;
                                }
                                this.Dispose();
                                break;
                            }
                            break;
                        }
                        return false;
                    }
                    /*void */ Dispose()
                    {
                        if (!(this._enumerator === null))
                        {
                            this._enumerator.System$IDisposable$Dispose();
                            this._enumerator = null;
                        }
                        super.Dispose();
                    }
                    /*IEnumerable<TResult2> */ Select(TResult2, /*Func<TResult, TResult2>*/ selector)
                    {
                        return new ($.$sl.System.Linq.Enumerable.IListSelectIterator$$$(TSource, TResult2))().$ctor$2(this._source, $.$sl.System.Linq.Utilities.CombineSelectors(TSource, TResult, TResult2, this._selector, selector));
                    }
                    /*TResult[] */ ToArray()
                    {
                        /*int*/ let count = this._source.System$Collections$Generic$ICollection$$$Count;
                        if (count === 0)
                        {
                            return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                        }
                        /*var*/ let results = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TResult), null, [count], null);
                        $.$sl.System.Linq.Enumerable.IListSelectIterator$$$(TSource, TResult).Fill(this._source, $.$spc.System.Span$$(TResult).op_Implicit(results), this._selector);
                        return results;
                    }
                    /*List<TResult> */ ToList()
                    {
                        /*IList<TSource>*/ let source = this._source;
                        /*int*/ let count = this._source.System$Collections$Generic$ICollection$$$Count;
                        /*var*/ let results = new ($.$spc.System.Collections.Generic.List$$(TResult))().$ctor$2(count);
                        $.$sl.System.Linq.Enumerable.IListSelectIterator$$$(TSource, TResult).Fill(source, $.$sl.System.Linq.Enumerable.SetCountAndGetSpan(TResult, results, count), this._selector);
                        return results;
                    }
                    static /*void */ Fill(/*IList<TSource>*/ source, /*Span<TResult>*/ results, /*Func<TSource, TResult>*/ func)
                    {
                        for(/*int*/ let i = 0; i < results.Length; i++)
                        {
                            results.get_Item(i).$v = func.Invoke(source.System$Collections$Generic$IList$$$get_Item(i, [TSource]));
                        }
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        /*int*/ let count = this._source.System$Collections$Generic$ICollection$$$Count;
                        if (!onlyIfCheap)
                        {
                            for(/*int*/ let i = 0; i < count; i++)
                            {
                                this._selector.Invoke(this._source.System$Collections$Generic$IList$$$get_Item(i, [TSource]));
                            }
                        }
                        return count;
                    }
                    /*Iterator<TResult> */ Skip(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        return new ($.$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector, count, 2147483647/*int.MaxValue*/);
                    }
                    /*Iterator<TResult> */ Take(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        return new ($.$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector, 0, ((count - 1) | 0));
                    }
                    /*TResult? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if ((index >>> 0) < (this._source.System$Collections$Generic$ICollection$$$Count >>> 0))
                        {
                            found.$v = true;
                            return this._selector.Invoke(this._source.System$Collections$Generic$IList$$$get_Item(index, [TSource]));
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult? */ TryGetFirst(/*out bool*/ found)
                    {
                        if (this._source.System$Collections$Generic$ICollection$$$Count !== 0)
                        {
                            found.$v = true;
                            return this._selector.Invoke(this._source.System$Collections$Generic$IList$$$get_Item(0, [TSource]));
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult? */ TryGetLast(/*out bool*/ found)
                    {
                        /*int*/ let len = this._source.System$Collections$Generic$ICollection$$$Count;
                        if (len !== 0)
                        {
                            found.$v = true;
                            return this._selector.Invoke(this._source.System$Collections$Generic$IList$$$get_Item(((len - 1) | 0), [TSource]));
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*bool */ Contains(/*TResult*/ value)
                    {
                        /*int*/ let count = this._source.System$Collections$Generic$ICollection$$$Count;
                        for(/*int*/ let i = 0; i < count; i++)
                        {
                            if ($.$spc.System.Collections.Generic.EqualityComparer$$(TResult).Default.Equals$2(this._selector.Invoke(this._source.System$Collections$Generic$IList$$$get_Item(i, [TSource])), value))
                            {
                                return true;
                            }
                        }
                        return false;
                    }
                    static $h = 2097159;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.IListSelectIterator<${TSource?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_IListSelectIterator$$$ = $v))(TSource, TResult);
            }
            static $_SizeOptIListSelectIterator$$$;
            static SizeOptIListSelectIterator$$$(TSource, TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_SizeOptIListSelectIterator$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.SizeOptIListSelectIterator<,>", (TSource, TResult) => $asm.$gt("$sl.System.Linq.Enumerable.SizeOptIListSelectIterator<,>", [TSource, TResult], ($self) => class SizeOptIListSelectIterator$$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*IEnumerator<TSource>?*/ _enumerator = null;
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        if (onlyIfCheap)
                        {
                            return -1;
                        }
                        /*int*/ let count = 0;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                this._selector.Invoke(item);
                                //checked
                                {
                                    count++;
                                }
                            }
                        }
                        return count;
                    }
                    /*Iterator<TResult> */ Skip(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        return new ($.$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector, count, 2147483647/*int.MaxValue*/);
                    }
                    /*Iterator<TResult> */ Take(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        return new ($.$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector, 0, ((count - 1) | 0));
                    }
                    /*bool */ MoveNext()
                    {
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                this._enumerator = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                                this._state = 2;
                                $switchJumpState1 = 2; /*goto case 2*/
                                continue $switchJumpStart1;
                                case 2:
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._enumerator === null), "_enumerator is not null");
                                if (this._enumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    this._current = this._selector.Invoke(this._enumerator.System$Collections$Generic$IEnumerator$$$Current);
                                    return true;
                                }
                                this.Dispose();
                                break;
                            }
                            break;
                        }
                        return false;
                    }
                    /*TResult[] */ ToArray()
                    {
                        /*TResult[]*/ let array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TResult), null, [this._source.System$Collections$Generic$ICollection$$$Count], null);
                        for(/*int*/ let i = 0; i < array.length; i++)
                        {
                            $.$spc.System.Array.$WriteT1.call(array, this._selector.Invoke(this._source.System$Collections$Generic$IList$$$get_Item(i, [TSource])), i);
                        }
                        return array;
                    }
                    /*List<TResult> */ ToList()
                    {
                        /*List<TResult>*/ let list = new ($.$spc.System.Collections.Generic.List$$(TResult))().$ctor$2(this._source.System$Collections$Generic$ICollection$$$Count);
                        for(/*int*/ let i = 0; i < list.Count; i++)
                        {
                            list.Add(this._selector.Invoke(this._source.System$Collections$Generic$IList$$$get_Item(i, [TSource])));
                        }
                        return list;
                    }
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.SizeOptIListSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector);
                    }
                    //Begin primary constructor
                    /*IList<TSource>*/ _source = null;
                    /*Func<TSource, TResult>*/ _selector = null;
                    $ctor$2(/*IList<TSource>*/$_source, /*Func<TSource, TResult>*/$_selector)
                    {
                        this._source = $_source;
                        this._selector = $_selector;
                        return this
                    }
                    //End primary constructor
                    static $h = 3538951;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.SizeOptIListSelectIterator<${TSource?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_SizeOptIListSelectIterator$$$ = $v))(TSource, TResult);
            }
            static $_RangeSelectIterator$$$;
            static RangeSelectIterator$$$(T, TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_RangeSelectIterator$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.RangeSelectIterator<,>", (T, TResult) => $asm.$gt("$sl.System.Linq.Enumerable.RangeSelectIterator<,>", [T, TResult], ($self) => class RangeSelectIterator$$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*T*/ _start = $.$default(T);
                    /*T*/ _end = $.$default(T);
                    /*Func<T, TResult>*/ _selector = null;
                    $ctor$2(/*T*/ start, /*T*/ end, /*Func<T, TResult>*/ selector)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(start === null), "start is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(end === null), "end is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(selector === null), "selector is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.UInt32.CreateTruncating(T, T.System$Numerics$ISubtractionOperators$$$$$op_Subtraction(end, start)) <= 2147483647/*int.MaxValue*/, "uint.CreateTruncating(end - start) <= (uint)int.MaxValue");
                            this._start = start;
                            this._end = end;
                            this._selector = selector;
                        }
                        return this;
                    }
                    /*int */ get Count()
                    {
                        return $.$spc.System.Int32.CreateTruncating(T, T.System$Numerics$ISubtractionOperators$$$$$op_Subtraction(this._end, this._start));
                    }
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.RangeSelectIterator$$$(T, TResult))().$ctor$2(this._start, this._end, this._selector);
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._state < 1 || this._state === (((this.Count + 1) | 0)))
                        {
                            this.Dispose();
                            return false;
                        }
                        /*int*/ let index = ((this._state++ - 1) | 0);
                        $.$spc.System.Diagnostics.Debug.Assert$1(T.System$Numerics$IComparisonOperators$$$$$op_LessThan(this._start, T.System$Numerics$ISubtractionOperators$$$$$op_Subtraction(this._end, T.System$Numerics$INumberBase$$$CreateChecked($.$spc.System.Int32, index))), "_start < _end - T.CreateChecked(index)");
                        this._current = this._selector.Invoke(T.System$Numerics$IAdditionOperators$$$$$op_Addition(this._start, T.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Int32, index)));
                        return true;
                    }
                    /*IEnumerable<TResult2> */ Select(TResult2, /*Func<TResult, TResult2>*/ selector)
                    {
                        return new ($.$sl.System.Linq.Enumerable.RangeSelectIterator$$$(T, TResult2))().$ctor$2(this._start, this._end, $.$sl.System.Linq.Utilities.CombineSelectors(T, TResult, TResult2, this._selector, selector));
                    }
                    /*TResult[] */ ToArray()
                    {
                        /*var*/ let results = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TResult), null, [this.Count], null);
                        $.$sl.System.Linq.Enumerable.RangeSelectIterator$$$(T, TResult).Fill($.$spc.System.Span$$(TResult).op_Implicit(results), this._start, this._selector);
                        return results;
                    }
                    /*List<TResult> */ ToList()
                    {
                        /*int*/ let count = this.Count;
                        /*var*/ let results = new ($.$spc.System.Collections.Generic.List$$(TResult))().$ctor$2(count);
                        $.$sl.System.Linq.Enumerable.RangeSelectIterator$$$(T, TResult).Fill($.$sl.System.Linq.Enumerable.SetCountAndGetSpan(TResult, results, count), this._start, this._selector);
                        return results;
                    }
                    static /*void */ Fill(/*Span<TResult>*/ results, /*T*/ start, /*Func<T, TResult>*/ func)
                    {
                        for(/*int*/ let i = 0; i < results.Length; i++, (() => //start++
                        {
                            const $old = start;
                            start = T.System$Numerics$IIncrementOperators$$$op_Increment(start);
                            return $old;
                        })())
                        {
                            results.get_Item(i).$v = func.Invoke(start);
                        }
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        if (!onlyIfCheap)
                        {
                            for(/*T*/ let i = this._start; T.System$Numerics$IEqualityOperators$$$$$op_Inequality(i, this._end); (() => //i++
                            {
                                const $old = i;
                                i = T.System$Numerics$IIncrementOperators$$$op_Increment(i);
                                return $old;
                            })())
                            {
                                this._selector.Invoke(i);
                            }
                        }
                        return this.Count;
                    }
                    /*Iterator<TResult>? */ Skip(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        if (count >= this.Count)
                        {
                            return null;
                        }
                        return new ($.$sl.System.Linq.Enumerable.RangeSelectIterator$$$(T, TResult))().$ctor$2(T.System$Numerics$IAdditionOperators$$$$$op_Addition(this._start, T.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Int32, count)), this._end, this._selector);
                    }
                    /*Iterator<TResult> */ Take(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        if (count >= this.Count)
                        {
                            return this;
                        }
                        return new ($.$sl.System.Linq.Enumerable.RangeSelectIterator$$$(T, TResult))().$ctor$2(this._start, T.System$Numerics$IAdditionOperators$$$$$op_Addition(this._start, T.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Int32, count)), this._selector);
                    }
                    /*TResult? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if ((index >>> 0) < (this.Count >>> 0))
                        {
                            found.$v = true;
                            return this._selector.Invoke(T.System$Numerics$IAdditionOperators$$$$$op_Addition(this._start, T.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Int32, index)));
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult */ TryGetFirst(/*out bool*/ found)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(T.System$Numerics$IComparisonOperators$$$$$op_GreaterThan(this._end, this._start), "_end > _start");
                        found.$v = true;
                        return this._selector.Invoke(this._start);
                    }
                    /*TResult */ TryGetLast(/*out bool*/ found)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(T.System$Numerics$IComparisonOperators$$$$$op_GreaterThan(this._end, this._start), "_end > _start");
                        found.$v = true;
                        return this._selector.Invoke(T.System$Numerics$ISubtractionOperators$$$$$op_Subtraction(this._end, T.System$Numerics$INumberBase$$$One));
                    }
                    /*bool */ Contains(/*TResult*/ value)
                    {
                        for(/*T*/ let i = this._start; T.System$Numerics$IEqualityOperators$$$$$op_Inequality(i, this._end); (() => //i++
                        {
                            const $old = i;
                            i = T.System$Numerics$IIncrementOperators$$$op_Increment(i);
                            return $old;
                        })())
                        {
                            if ($.$spc.System.Collections.Generic.EqualityComparer$$(TResult).Default.Equals$2(this._selector.Invoke(i), value))
                            {
                                return true;
                            }
                        }
                        return false;
                    }
                    static $h = 3145735;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.RangeSelectIterator<${T?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_RangeSelectIterator$$$ = $v))(T, TResult);
            }
            static $_IteratorSelectIterator$$$;
            static IteratorSelectIterator$$$(TSource, TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_IteratorSelectIterator$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.IteratorSelectIterator<,>", (TSource, TResult) => $asm.$gt("$sl.System.Linq.Enumerable.IteratorSelectIterator<,>", [TSource, TResult], ($self) => class IteratorSelectIterator$$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*Iterator<TSource>*/ _source = null;
                    /*Func<TSource, TResult>*/ _selector = null;
                    /*Iterator<TSource>?*/ _enumerator = null;
                    $ctor$2(/*Iterator<TSource>*/ source, /*Func<TSource, TResult>*/ selector)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(selector === null), "selector is not null");
                            this._source = source;
                            this._selector = selector;
                        }
                        return this;
                    }
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.IteratorSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector);
                    }
                    /*bool */ MoveNext()
                    {
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                this._enumerator = this._source.GetEnumerator();
                                this._state = 2;
                                $switchJumpState1 = 2; /*goto case 2*/
                                continue $switchJumpStart1;
                                case 2:
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._enumerator === null), "_enumerator is not null");
                                if (this._enumerator.MoveNext())
                                {
                                    this._current = this._selector.Invoke(this._enumerator.Current);
                                    return true;
                                }
                                this.Dispose();
                                break;
                            }
                            break;
                        }
                        return false;
                    }
                    /*void */ Dispose()
                    {
                        if (!(this._enumerator === null))
                        {
                            this._enumerator.Dispose();
                            this._enumerator = null;
                        }
                        super.Dispose();
                    }
                    /*IEnumerable<TResult2> */ Select(TResult2, /*Func<TResult, TResult2>*/ selector)
                    {
                        return new ($.$sl.System.Linq.Enumerable.IteratorSelectIterator$$$(TSource, TResult2))().$ctor$2(this._source, $.$sl.System.Linq.Utilities.CombineSelectors(TSource, TResult, TResult2, this._selector, selector));
                    }
                    /*Iterator<TResult>? */ Skip(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        /*Iterator<TSource>?*/ let source = this._source.Skip(count);
                        return source === null ? null : new ($.$sl.System.Linq.Enumerable.IteratorSelectIterator$$$(TSource, TResult))().$ctor$2(source, this._selector);
                    }
                    /*Iterator<TResult>? */ Take(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        /*Iterator<TSource>?*/ let source = this._source.Take(count);
                        return source === null ? null : new ($.$sl.System.Linq.Enumerable.IteratorSelectIterator$$$(TSource, TResult))().$ctor$2(source, this._selector);
                    }
                    /*TResult? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        /*bool*/ let sourceFound;
                        /*TSource?*/ let input = this._source.TryGetElementAt(index, $.$ref(() => sourceFound, ($v) => sourceFound = $v, $.$spc.System.Boolean));
                        found.$v = sourceFound;
                        return sourceFound ? this._selector.Invoke(input) : $.$default(TResult);
                    }
                    /*TResult? */ TryGetFirst(/*out bool*/ found)
                    {
                        /*bool*/ let sourceFound;
                        /*TSource?*/ let input = this._source.TryGetFirst($.$ref(() => sourceFound, ($v) => sourceFound = $v, $.$spc.System.Boolean));
                        found.$v = sourceFound;
                        return sourceFound ? this._selector.Invoke(input) : $.$default(TResult);
                    }
                    /*TResult? */ TryGetLast(/*out bool*/ found)
                    {
                        /*bool*/ let sourceFound;
                        /*TSource?*/ let input = this._source.TryGetLast($.$ref(() => sourceFound, ($v) => sourceFound = $v, $.$spc.System.Boolean));
                        found.$v = sourceFound;
                        return sourceFound ? this._selector.Invoke(input) : $.$default(TResult);
                    }
                    /*TResult[] */ ToArrayNoPresizing()
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._source.GetCount(true) === -1, "_source.GetCount(onlyIfCheap: true) == -1");
                        /*SegmentedArrayBuilder<TResult>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TResult>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult))().$ctor$2($.$spc.System.Span$$(TResult).op_Implicit(scratch.$fields));
                        /*Func<TSource, TResult>*/ let selector = this._selector;
                        var $en4 = this._source.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var input = $en4.Current;
                            {
                                builder.Add(selector.Invoke(input));
                            }
                        }
                        /*TResult[]*/ let result = builder.ToArray();
                        builder.Dispose();
                        return result;
                    }
                    /*TResult[] */ PreallocatingToArray(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        $.$spc.System.Diagnostics.Debug.Assert$1(count === this._source.GetCount(true), "count == _source.GetCount(onlyIfCheap: true)");
                        /*TResult[]*/ let array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TResult), null, [count], null);
                        $.$sl.System.Linq.Enumerable.IteratorSelectIterator$$$(TSource, TResult).Fill(this._source, $.$spc.System.Span$$(TResult).op_Implicit(array), this._selector);
                        return array;
                    }
                    /*TResult[] */ ToArray()
                    {
                        /*int*/ let count = this._source.GetCount(true);
                        return (() =>
                        {
                            if (count === -1)
                            {
                                return this.ToArrayNoPresizing();
                            }
                            if (count === 0)
                            {
                                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                            }
                            return this.PreallocatingToArray(count);
                        })();
                    }
                    /*List<TResult> */ ToListNoPresizing()
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(this._source.GetCount(true) === -1, "_source.GetCount(onlyIfCheap: true) == -1");
                        /*SegmentedArrayBuilder<TResult>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TResult>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult))().$ctor$2($.$spc.System.Span$$(TResult).op_Implicit(scratch.$fields));
                        /*Func<TSource, TResult>*/ let selector = this._selector;
                        var $en4 = this._source.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var input = $en4.Current;
                            {
                                builder.Add(selector.Invoke(input));
                            }
                        }
                        /*List<TResult>*/ let result = builder.ToList();
                        builder.Dispose();
                        return result;
                    }
                    /*List<TResult> */ ToList()
                    {
                        /*int*/ let count = this._source.GetCount(true);
                        /*List<TResult>*/ let list;
                        switch(count)
                        {
                            case -1:
                            list = this.ToListNoPresizing();
                            break;
                            case 0:
                            list = (() =>
                            {
                                let $t2 = new ($.$spc.System.Collections.Generic.List$$(TResult))().$ctor$1();
                                return $t2;
                            })();
                            break;
                            default:
                            list = new ($.$spc.System.Collections.Generic.List$$(TResult))().$ctor$2(count);
                            $.$sl.System.Linq.Enumerable.IteratorSelectIterator$$$(TSource, TResult).Fill(this._source, $.$sl.System.Linq.Enumerable.SetCountAndGetSpan(TResult, list, count), this._selector);
                            break;
                        }
                        return list;
                    }
                    static /*void */ Fill(/*Iterator<TSource>*/ source, /*Span<TResult>*/ results, /*Func<TSource, TResult>*/ func)
                    {
                        /*int*/ let index = 0;
                        var $en4 = source.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var item = $en4.Current;
                            {
                                results.get_Item(index).$v = func.Invoke(item);
                                ++index;
                            }
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(index === results.Length, "All list elements were not initialized.");
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        if (!onlyIfCheap)
                        {
                            /*int*/ let count = 0;
                            var $en5 = this._source.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var item = $en5.Current;
                                {
                                    this._selector.Invoke(item);
                                    //checked
                                    {
                                        count++;
                                    }
                                }
                            }
                            return count;
                        }
                        return this._source.GetCount(onlyIfCheap);
                    }
                    static $h = 2490375;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.IteratorSelectIterator<${TSource?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_IteratorSelectIterator$$$ = $v))(TSource, TResult);
            }
            static $_IListSkipTakeSelectIterator$$$;
            static IListSkipTakeSelectIterator$$$(TSource, TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_IListSkipTakeSelectIterator$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator<,>", (TSource, TResult) => $asm.$gt("$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator<,>", [TSource, TResult], ($self) => class IListSkipTakeSelectIterator$$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*IList<TSource>*/ _source = null;
                    /*Func<TSource, TResult>*/ _selector = null;
                    /*int*/ _minIndexInclusive = 0;
                    /*int*/ _maxIndexInclusive = 0;
                    $ctor$2(/*IList<TSource>*/ source, /*Func<TSource, TResult>*/ selector, /*int*/ minIndexInclusive, /*int*/ maxIndexInclusive)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(selector === null), "selector is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(minIndexInclusive >= 0, "minIndexInclusive >= 0");
                            $.$spc.System.Diagnostics.Debug.Assert$1(minIndexInclusive <= maxIndexInclusive, "minIndexInclusive <= maxIndexInclusive");
                            this._source = source;
                            this._selector = selector;
                            this._minIndexInclusive = minIndexInclusive;
                            this._maxIndexInclusive = maxIndexInclusive;
                        }
                        return this;
                    }
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector, this._minIndexInclusive, this._maxIndexInclusive);
                    }
                    /*bool */ MoveNext()
                    {
                        /*int*/ let index = ((this._state - 1) | 0);
                        if ((index >>> 0) <= ((((this._maxIndexInclusive - this._minIndexInclusive) | 0)) >>> 0) && index < ((this._source.System$Collections$Generic$ICollection$$$Count - this._minIndexInclusive) | 0))
                        {
                            this._current = this._selector.Invoke(this._source.System$Collections$Generic$IList$$$get_Item(((this._minIndexInclusive + index) | 0), [TSource]));
                            ++this._state;
                            return true;
                        }
                        this.Dispose();
                        return false;
                    }
                    /*IEnumerable<TResult2> */ Select(TResult2, /*Func<TResult, TResult2>*/ selector)
                    {
                        return new ($.$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator$$$(TSource, TResult2))().$ctor$2(this._source, $.$sl.System.Linq.Utilities.CombineSelectors(TSource, TResult, TResult2, this._selector, selector), this._minIndexInclusive, this._maxIndexInclusive);
                    }
                    /*Iterator<TResult>? */ Skip(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        /*int*/ let minIndex = ((this._minIndexInclusive + count) | 0);
                        return (minIndex >>> 0) > (this._maxIndexInclusive >>> 0) ? null : new ($.$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector, minIndex, this._maxIndexInclusive);
                    }
                    /*Iterator<TResult> */ Take(/*int*/ count)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                        /*int*/ let maxIndex = ((((this._minIndexInclusive + count) | 0) - 1) | 0);
                        return (maxIndex >>> 0) >= (this._maxIndexInclusive >>> 0) ? this : new ($.$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector, this._minIndexInclusive, maxIndex);
                    }
                    /*TResult? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if ((index >>> 0) <= ((((this._maxIndexInclusive - this._minIndexInclusive) | 0)) >>> 0) && index < ((this._source.System$Collections$Generic$ICollection$$$Count - this._minIndexInclusive) | 0))
                        {
                            found.$v = true;
                            return this._selector.Invoke(this._source.System$Collections$Generic$IList$$$get_Item(((this._minIndexInclusive + index) | 0), [TSource]));
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult? */ TryGetFirst(/*out bool*/ found)
                    {
                        if (this._source.System$Collections$Generic$ICollection$$$Count > this._minIndexInclusive)
                        {
                            found.$v = true;
                            return this._selector.Invoke(this._source.System$Collections$Generic$IList$$$get_Item(this._minIndexInclusive, [TSource]));
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult? */ TryGetLast(/*out bool*/ found)
                    {
                        /*int*/ let lastIndex = ((this._source.System$Collections$Generic$ICollection$$$Count - 1) | 0);
                        if (lastIndex >= this._minIndexInclusive)
                        {
                            found.$v = true;
                            return this._selector.Invoke(this._source.System$Collections$Generic$IList$$$get_Item($.$spc.System.Math.Min$4(lastIndex, this._maxIndexInclusive), [TSource]));
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*int */ get Count()
                    {
                        /*int*/ let count = this._source.System$Collections$Generic$ICollection$$$Count;
                        if (count <= this._minIndexInclusive)
                        {
                            return 0;
                        }
                        return (((($.$spc.System.Math.Min$4(((count - 1) | 0), this._maxIndexInclusive) - this._minIndexInclusive) | 0) + 1) | 0);
                    }
                    /*TResult[] */ ToArray()
                    {
                        /*int*/ let count = this.Count;
                        if (count === 0)
                        {
                            return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                        }
                        /*TResult[]*/ let array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TResult), null, [count], null);
                        $.$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator$$$(TSource, TResult).Fill(this._source, $.$spc.System.Span$$(TResult).op_Implicit(array), this._selector, this._minIndexInclusive);
                        return array;
                    }
                    /*List<TResult> */ ToList()
                    {
                        /*int*/ let count = this.Count;
                        if (count === 0)
                        {
                            return (() =>
                            {
                                let $t1 = new ($.$spc.System.Collections.Generic.List$$(TResult))().$ctor$1();
                                return $t1;
                            })();
                        }
                        /*List<TResult>*/ let list = new ($.$spc.System.Collections.Generic.List$$(TResult))().$ctor$2(count);
                        $.$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator$$$(TSource, TResult).Fill(this._source, $.$sl.System.Linq.Enumerable.SetCountAndGetSpan(TResult, list, count), this._selector, this._minIndexInclusive);
                        return list;
                    }
                    static /*void */ Fill(/*IList<TSource>*/ source, /*Span<TResult>*/ destination, /*Func<TSource, TResult>*/ func, /*int*/ sourceIndex)
                    {
                        for(/*int*/ let i = 0; i < destination.Length; i++, sourceIndex++)
                        {
                            destination.get_Item(i).$v = func.Invoke(source.System$Collections$Generic$IList$$$get_Item(sourceIndex, [TSource]));
                        }
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        /*int*/ let count = this.Count;
                        if (!onlyIfCheap)
                        {
                            /*int*/ let end = ((this._minIndexInclusive + count) | 0);
                            for(/*int*/ let i = this._minIndexInclusive; i !== end; ++i)
                            {
                                this._selector.Invoke(this._source.System$Collections$Generic$IList$$$get_Item(i, [TSource]));
                            }
                        }
                        return count;
                    }
                    /*bool */ Contains(/*TResult*/ value)
                    {
                        /*int*/ let count = this.Count;
                        /*int*/ let end = ((this._minIndexInclusive + count) | 0);
                        for(/*int*/ let i = this._minIndexInclusive; i !== end; ++i)
                        {
                            if ($.$spc.System.Collections.Generic.EqualityComparer$$(TResult).Default.Equals$2(this._selector.Invoke(this._source.System$Collections$Generic$IList$$$get_Item(i, [TSource])), value))
                            {
                                return true;
                            }
                        }
                        return false;
                    }
                    static $h = 2228231;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.IListSkipTakeSelectIterator<${TSource?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_IListSkipTakeSelectIterator$$$ = $v))(TSource, TResult);
            }
            static /*IEnumerable<TResult> */ SelectMany(TSource, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, IEnumerable<TResult>>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                }
                return new ($.$sl.System.Linq.Enumerable.SelectManySingleSelectorIterator$$$(TSource, TResult))().$ctor$2(source, selector);
            }
            static /*IEnumerable<TResult> */ SelectMany$1(TSource, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, int, IEnumerable<TResult>>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.SelectManyIterator(TSource, TResult, source, selector);
            }
            static /*IEnumerable<TResult> */ SelectManyIterator(TSource, TResult, /*IEnumerable<TSource>*/ source, /*Func<TSource, int, IEnumerable<TResult>>*/ selector)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*int*/ let index = -1;
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            //checked
                            {
                                index++;
                            }
                            var $en5 = selector.Invoke(element, index).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var subElement = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    yield subElement;
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<TResult> */ SelectMany$2(TSource, TCollection, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, int, IEnumerable<TCollection>>*/ collectionSelector, /*Func<TSource, TCollection, TResult>*/ resultSelector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (collectionSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(0/*ExceptionArgument.collectionSelector*/);
                }
                if (resultSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(13/*ExceptionArgument.resultSelector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.SelectManyIterator$1(TSource, TCollection, TResult, source, collectionSelector, resultSelector);
            }
            static /*IEnumerable<TResult> */ SelectManyIterator$1(TSource, TCollection, TResult, /*IEnumerable<TSource>*/ source, /*Func<TSource, int, IEnumerable<TCollection>>*/ collectionSelector, /*Func<TSource, TCollection, TResult>*/ resultSelector)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*int*/ let index = -1;
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            //checked
                            {
                                index++;
                            }
                            var $en5 = collectionSelector.Invoke(element, index).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var subElement = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    yield resultSelector.Invoke(element, subElement);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<TResult> */ SelectMany$3(TSource, TCollection, TResult, /*this IEnumerable<TSource>*/ source, /*Func<TSource, IEnumerable<TCollection>>*/ collectionSelector, /*Func<TSource, TCollection, TResult>*/ resultSelector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (collectionSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(0/*ExceptionArgument.collectionSelector*/);
                }
                if (resultSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(13/*ExceptionArgument.resultSelector*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TResult.$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.SelectManyIterator$2(TSource, TCollection, TResult, source, collectionSelector, resultSelector);
            }
            static /*IEnumerable<TResult> */ SelectManyIterator$2(TSource, TCollection, TResult, /*IEnumerable<TSource>*/ source, /*Func<TSource, IEnumerable<TCollection>>*/ collectionSelector, /*Func<TSource, TCollection, TResult>*/ resultSelector)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            var $en5 = collectionSelector.Invoke(element).System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var subElement = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    yield resultSelector.Invoke(element, subElement);
                                }
                            }
                        }
                    }
                }.bind(this));
            }
            static $_SelectManySingleSelectorIterator$$$;
            static SelectManySingleSelectorIterator$$$(TSource, TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_SelectManySingleSelectorIterator$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.SelectManySingleSelectorIterator<,>", (TSource, TResult) => $asm.$gt("$sl.System.Linq.Enumerable.SelectManySingleSelectorIterator<,>", [TSource, TResult], ($self) => class SelectManySingleSelectorIterator$$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*IEnumerable<TSource>*/ _source = null;
                    /*Func<TSource, IEnumerable<TResult>>*/ _selector = null;
                    /*IEnumerator<TSource>?*/ _sourceEnumerator = null;
                    /*IEnumerator<TResult>?*/ _subEnumerator = null;
                    $ctor$2(/*IEnumerable<TSource>*/ source, /*Func<TSource, IEnumerable<TResult>>*/ selector)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(selector === null), "selector is not null");
                            this._source = source;
                            this._selector = selector;
                        }
                        return this;
                    }
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.SelectManySingleSelectorIterator$$$(TSource, TResult))().$ctor$2(this._source, this._selector);
                    }
                    /*void */ Dispose()
                    {
                        if (!(this._subEnumerator === null))
                        {
                            this._subEnumerator.System$IDisposable$Dispose();
                            this._subEnumerator = null;
                        }
                        if (!(this._sourceEnumerator === null))
                        {
                            this._sourceEnumerator.System$IDisposable$Dispose();
                            this._sourceEnumerator = null;
                        }
                        super.Dispose();
                    }
                    /*bool */ MoveNext()
                    {
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                this._sourceEnumerator = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                                this._state = 2;
                                $switchJumpState1 = 2; /*goto case 2*/
                                continue $switchJumpStart1;
                                case 2:
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._sourceEnumerator === null), "_sourceEnumerator is not null");
                                if (!this._sourceEnumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    break;
                                }
                                /*TSource*/ let element = this._sourceEnumerator.System$Collections$Generic$IEnumerator$$$Current;
                                this._subEnumerator = this._selector.Invoke(element).System$Collections$Generic$IEnumerable$$$GetEnumerator([TResult]);
                                this._state = 3;
                                $switchJumpState1 = 3; /*goto case 3*/
                                continue $switchJumpStart1;
                                case 3:
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._subEnumerator === null), "_subEnumerator is not null");
                                if (!this._subEnumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    this._subEnumerator.System$IDisposable$Dispose();
                                    this._subEnumerator = null;
                                    this._state = 2;
                                    $switchJumpState1 = 2; /*goto case 2*/
                                    continue $switchJumpStart1;
                                }
                                this._current = this._subEnumerator.System$Collections$Generic$IEnumerator$$$Current;
                                return true;
                            }
                            break;
                        }
                        this.Dispose();
                        return false;
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        if (onlyIfCheap)
                        {
                            return -1;
                        }
                        /*int*/ let count = 0;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var element = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                //checked
                                {
                                    count += $.$sl.System.Linq.Enumerable.Count(TResult, this._selector.Invoke(element));
                                }
                            }
                        }
                        return count;
                    }
                    /*TResult[] */ ToArray()
                    {
                        /*SegmentedArrayBuilder<TResult>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TResult>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult))().$ctor$2($.$spc.System.Span$$(TResult).op_Implicit(scratch.$fields));
                        /*Func<TSource, IEnumerable<TResult>>*/ let selector = this._selector;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                builder.AddRange(selector.Invoke(item));
                            }
                        }
                        /*TResult[]*/ let result = builder.ToArray();
                        builder.Dispose();
                        return result;
                    }
                    /*List<TResult> */ ToList()
                    {
                        /*SegmentedArrayBuilder<TResult>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TResult>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult))().$ctor$2($.$spc.System.Span$$(TResult).op_Implicit(scratch.$fields));
                        /*Func<TSource, IEnumerable<TResult>>*/ let selector = this._selector;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                builder.AddRange(selector.Invoke(item));
                            }
                        }
                        /*List<TResult>*/ let result = builder.ToList();
                        builder.Dispose();
                        return result;
                    }
                    /*bool */ Contains(/*TResult*/ value)
                    {
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var element = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if ($.$sl.System.Linq.Enumerable.Contains(TResult, this._selector.Invoke(element), value))
                                {
                                    return true;
                                }
                            }
                        }
                        return false;
                    }
                    static $h = 3342343;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.SelectManySingleSelectorIterator<${TSource?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_SelectManySingleSelectorIterator$$$ = $v))(TSource, TResult);
            }
            static /*IEnumerable<T> */ Sequence(T, /*T*/ start, /*T*/ endInclusive, /*T*/ step)
            {
                if (start === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(21/*ExceptionArgument.start*/);
                }
                if (T.System$Numerics$INumberBase$$$IsNaN(start))
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentOutOfRangeException(21/*ExceptionArgument.start*/);
                }
                if (endInclusive === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(23/*ExceptionArgument.endInclusive*/);
                }
                if (T.System$Numerics$INumberBase$$$IsNaN(endInclusive))
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentOutOfRangeException(23/*ExceptionArgument.endInclusive*/);
                }
                if (step === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(22/*ExceptionArgument.step*/);
                }
                if (T.System$Numerics$INumberBase$$$IsNaN(step))
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentOutOfRangeException(22/*ExceptionArgument.step*/);
                }
                if (T.System$Numerics$INumberBase$$$IsZero(step))
                {
                    if (T.System$Numerics$IEqualityOperators$$$$$op_Inequality(start, endInclusive))
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowArgumentOutOfRangeException(22/*ExceptionArgument.step*/);
                    }
                    return $.$sl.System.Linq.Enumerable.Repeat(T, start, 1);
                }
                else if (T.System$Numerics$INumberBase$$$IsPositive(step))
                {
                    if (T.System$Numerics$IComparisonOperators$$$$$op_LessThan(endInclusive, start))
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowArgumentOutOfRangeException(23/*ExceptionArgument.endInclusive*/);
                    }
                    /*RangeIterator<T>?*/ let range;
                    if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Byte.$type) && !((range = TryUseRange($.$spc.System.UInt16, start, endInclusive, step, 255/*byte.MaxValue*/)) === null))
                    {
                        return range;
                    }
                    if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.SByte.$type) && !((range = TryUseRange($.$spc.System.Int16, start, endInclusive, step, 127/*sbyte.MaxValue*/)) === null))
                    {
                        return range;
                    }
                    if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.UInt16.$type) && !((range = TryUseRange($.$spc.System.UInt32, start, endInclusive, step, 65535/*ushort.MaxValue*/)) === null))
                    {
                        return range;
                    }
                    if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Char.$type) && !((range = TryUseRange($.$spc.System.UInt32, start, endInclusive, step, /*\uFFFF*/ 65535)) === null))
                    {
                        return range;
                    }
                    if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Int16.$type) && !((range = TryUseRange($.$spc.System.Int32, start, endInclusive, step, 32767/*short.MaxValue*/)) === null))
                    {
                        return range;
                    }
                    if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.UInt32.$type) && !((range = TryUseRange($.$spc.System.UInt64, start, endInclusive, step, BigInt(4294967295/*uint.MaxValue*/))) === null))
                    {
                        return range;
                    }
                    if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Int32.$type) && !((range = TryUseRange($.$spc.System.Int64, start, endInclusive, step, BigInt(2147483647/*int.MaxValue*/))) === null))
                    {
                        return range;
                    }
                    if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.UInt64.$type) && !((range = TryUseRange($.$spc.System.UInt128, start, endInclusive, step, $.$spc.System.UInt128.op_Implicit$4(18446744073709551615n))) === null))
                    {
                        return range;
                    }
                    if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.Int64.$type) && !((range = TryUseRange($.$spc.System.Int128, start, endInclusive, step, $.$spc.System.Int128.op_Implicit$4(9223372036854775807n))) === null))
                    {
                        return range;
                    }
                    if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.UIntPtr.$type) && !((range = TryUseRange($.$spc.System.UInt128, start, endInclusive, step, $.$spc.System.UInt128.op_Implicit$5($.$spc.System.UIntPtr.MaxValue))) === null))
                    {
                        return range;
                    }
                    if ($.$spc.System.Type.op_Equality$1(T.$type, $.$spc.System.IntPtr.$type) && !((range = TryUseRange($.$spc.System.Int128, start, endInclusive, step, $.$spc.System.Int128.op_Implicit$5($.$spc.System.IntPtr.MaxValue))) === null))
                    {
                        return range;
                    }
                    return IncrementingIterator(start, endInclusive, step);
                }
                else 
                {
                    if (T.System$Numerics$IComparisonOperators$$$$$op_GreaterThan(endInclusive, start))
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowArgumentOutOfRangeException(23/*ExceptionArgument.endInclusive*/);
                    }
                    return DecrementingIterator(start, endInclusive, step);
                }
                /*static RangeIterator<T>?*/  function TryUseRange(TLarger, /*T*/ start, /*T*/ endInclusive, /*T*/ step, /*TLarger*/ maxValue)
                {
                    if (T.System$Numerics$IEqualityOperators$$$$$op_Equality(step, T.System$Numerics$INumberBase$$$One) && TLarger.System$Numerics$IComparisonOperators$$$$$op_LessThanOrEqual(TLarger.System$Numerics$IAdditionOperators$$$$$op_Addition(TLarger.System$Numerics$ISubtractionOperators$$$$$op_Subtraction(TLarger.System$Numerics$INumberBase$$$CreateTruncating(T, endInclusive), TLarger.System$Numerics$INumberBase$$$CreateTruncating(T, start)), TLarger.System$Numerics$INumberBase$$$One), maxValue))
                    {
                        return new ($.$sl.System.Linq.Enumerable.RangeIterator$$(T))().$ctor$2(start, T.System$Numerics$IAdditionOperators$$$$$op_Addition(endInclusive, T.System$Numerics$INumberBase$$$One));
                    }
                    return null;
                }
                /*static IEnumerable<T>*/  function IncrementingIterator(/*T*/ current, /*T*/ endInclusive, /*T*/ step)
                {
                    return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(T.System$Numerics$IComparisonOperators$$$$$op_GreaterThan(step, T.System$Numerics$INumberBase$$$Zero), "step > T.Zero");
                        yield current;
                        while(true)
                        {
                            /*T*/ let next = T.System$Numerics$IAdditionOperators$$$$$op_Addition(current, step);
                            if (T.System$Numerics$IComparisonOperators$$$$$op_GreaterThanOrEqual(next, endInclusive) || T.System$Numerics$IComparisonOperators$$$$$op_LessThanOrEqual(next, current))
                            {
                                if (T.System$Numerics$IEqualityOperators$$$$$op_Equality(next, endInclusive) && T.System$Numerics$IEqualityOperators$$$$$op_Inequality(current, next))
                                {
                                    yield next;
                                }
                                return;
                            }
                            yield next;
                            current = next;
                        }
                    }.bind(this));
                }
                /*static IEnumerable<T>*/  function DecrementingIterator(/*T*/ current, /*T*/ endInclusive, /*T*/ step)
                {
                    return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(T.System$Numerics$IComparisonOperators$$$$$op_LessThan(step, T.System$Numerics$INumberBase$$$Zero), "step < T.Zero");
                        yield current;
                        while(true)
                        {
                            /*T*/ let next = T.System$Numerics$IAdditionOperators$$$$$op_Addition(current, step);
                            if (T.System$Numerics$IComparisonOperators$$$$$op_LessThanOrEqual(next, endInclusive) || T.System$Numerics$IComparisonOperators$$$$$op_GreaterThanOrEqual(next, current))
                            {
                                if (T.System$Numerics$IEqualityOperators$$$$$op_Equality(next, endInclusive) && T.System$Numerics$IEqualityOperators$$$$$op_Inequality(current, next))
                                {
                                    yield next;
                                }
                                return;
                            }
                            yield next;
                            current = next;
                        }
                    }.bind(this));
                }
            }
            static /*bool */ SequenceEqual(TSource, /*this IEnumerable<TSource>*/ first, /*IEnumerable<TSource>*/ second)
            {
                return $.$sl.System.Linq.Enumerable.SequenceEqual$1(TSource, first, second, null);
            }
            static /*bool */ SequenceEqual$1(TSource, /*this IEnumerable<TSource>*/ first, /*IEnumerable<TSource>*/ second, /*IEqualityComparer<TSource>?*/ comparer)
            {
                if (first === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(4/*ExceptionArgument.first*/);
                }
                if (second === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(14/*ExceptionArgument.second*/);
                }
                let firstCol;
                let secondCol;
                if ($.$is(first, $.$spc.System.Collections.Generic.ICollection$$(TSource), { set $v(v){ firstCol = v; } }) && $.$is(second, $.$spc.System.Collections.Generic.ICollection$$(TSource), { set $v(v){ secondCol = v; } }))
                {
                    /*ReadOnlySpan<TSource>*/ let firstSpan;
                    /*ReadOnlySpan<TSource>*/ let secondSpan;
                    if ($.$sl.System.Linq.Enumerable.TryGetSpan(TSource, first, $.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$spc.System.ReadOnlySpan$$(TSource))) && $.$sl.System.Linq.Enumerable.TryGetSpan(TSource, second, $.$ref(() => secondSpan, ($v) => secondSpan = $v, $.$spc.System.ReadOnlySpan$$(TSource))))
                    {
                        return $.$spc.System.MemoryExtensions.SequenceEqual$3(TSource, firstSpan, secondSpan, comparer);
                    }
                    if (firstCol.System$Collections$Generic$ICollection$$$Count !== secondCol.System$Collections$Generic$ICollection$$$Count)
                    {
                        return false;
                    }
                    let firstList;
                    let secondList;
                    if ($.$is(firstCol, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ firstList = v; } }) && $.$is(secondCol, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ secondList = v; } }))
                    {
                        comparer ??= $.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default;
                        /*int*/ let count = firstCol.System$Collections$Generic$ICollection$$$Count;
                        for(/*int*/ let i = 0; i < count; i++)
                        {
                            if (!comparer.System$Collections$Generic$IEqualityComparer$$$Equals(firstList.System$Collections$Generic$IList$$$get_Item(i, [TSource]), secondList.System$Collections$Generic$IList$$$get_Item(i, [TSource]), [TSource]))
                            {
                                return false;
                            }
                        }
                        return true;
                    }
                }
                /*IEnumerator<TSource>*/ let e1 = first.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                try
                {
                    /*IEnumerator<TSource>*/ let e2 = second.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    try
                    {
                        comparer ??= $.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default;
                        while(e1.System$Collections$IEnumerator$MoveNext())
                        {
                            if (!(e2.System$Collections$IEnumerator$MoveNext() && comparer.System$Collections$Generic$IEqualityComparer$$$Equals(e1.System$Collections$Generic$IEnumerator$$$Current, e2.System$Collections$Generic$IEnumerator$$$Current, [TSource])))
                            {
                                return false;
                            }
                        }
                        return !e2.System$Collections$IEnumerator$MoveNext();
                    }
                    finally
                    {
                        e2?.System$IDisposable$Dispose();
                    }
                }
                finally
                {
                    e1?.System$IDisposable$Dispose();
                }
            }
            static /*TSource */ Single(TSource, /*this IEnumerable<TSource>*/ source)
            {
                /*bool*/ let found;
                /*TSource?*/ let single = $.$sl.System.Linq.Enumerable.TryGetSingle(TSource, source, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                if (!found)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowNoElementsException();
                }
                return single;
            }
            static /*TSource */ Single$1(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
            {
                /*bool*/ let found;
                /*TSource?*/ let single = $.$sl.System.Linq.Enumerable.TryGetSingle$1(TSource, source, predicate, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                if (!found)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowNoMatchException();
                }
                return single;
            }
            static /*TSource? */ SingleOrDefault(TSource, /*this IEnumerable<TSource>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.TryGetSingle(TSource, source, $.$discardRef());
            }
            static /*TSource */ SingleOrDefault$1(TSource, /*this IEnumerable<TSource>*/ source, /*TSource*/ defaultValue)
            {
                /*bool*/ let found;
                /*var*/ let single = $.$sl.System.Linq.Enumerable.TryGetSingle(TSource, source, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                return found ? single : defaultValue;
            }
            static /*TSource? */ SingleOrDefault$2(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
            {
                return $.$sl.System.Linq.Enumerable.TryGetSingle$1(TSource, source, predicate, $.$discardRef());
            }
            static /*TSource */ SingleOrDefault$3(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate, /*TSource*/ defaultValue)
            {
                /*bool*/ let found;
                /*var*/ let single = $.$sl.System.Linq.Enumerable.TryGetSingle$1(TSource, source, predicate, $.$ref(() => found, ($v) => found = $v, $.$spc.System.Boolean));
                return found ? single : defaultValue;
            }
            static /*TSource? */ TryGetSingle(TSource, /*this IEnumerable<TSource>*/ source, /*out bool*/ found)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                let list;
                if ($.$is(source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ list = v; } }))
                {
                    let $switch1 = list.System$Collections$Generic$ICollection$$$Count;
                    switch($switch1)
                    {
                        case 0:
                        found.$v = false;
                        return $.$default(TSource);
                        case 1:
                        found.$v = true;
                        return list.System$Collections$Generic$IList$$$get_Item(0, [TSource]);
                    }
                }
                else 
                {
                    /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    try
                    {
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            found.$v = false;
                            return $.$default(TSource);
                        }
                        /*TSource*/ let result = e.System$Collections$Generic$IEnumerator$$$Current;
                        if (!e.System$Collections$IEnumerator$MoveNext())
                        {
                            found.$v = true;
                            return result;
                        }
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }
                found.$v = false;
                $.$sl.System.Linq.ThrowHelper.ThrowMoreThanOneElementException();
                return $.$default(TSource);
            }
            static /*TSource? */ TryGetSingle$1(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate, /*out bool*/ found)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (predicate === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.predicate*/);
                }
                /*ReadOnlySpan<TSource>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan(TSource, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(TSource))))
                {
                    for(/*int*/ let i = 0; i < span.Length; i++)
                    {
                        /*TSource*/ let result = span.get_Item(i).$v;
                        if (predicate.Invoke(result))
                        {
                            for(i++; (i >>> 0) < (span.Length >>> 0); i++)
                            {
                                if (predicate.Invoke(span.get_Item(i).$v))
                                {
                                    $.$sl.System.Linq.ThrowHelper.ThrowMoreThanOneMatchException();
                                }
                            }
                            found.$v = true;
                            return result;
                        }
                    }
                }
                else 
                {
                    /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    try
                    {
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*TSource*/ let result = e.System$Collections$Generic$IEnumerator$$$Current;
                            if (predicate.Invoke(result))
                            {
                                while(e.System$Collections$IEnumerator$MoveNext())
                                {
                                    if (predicate.Invoke(e.System$Collections$Generic$IEnumerator$$$Current))
                                    {
                                        $.$sl.System.Linq.ThrowHelper.ThrowMoreThanOneMatchException();
                                    }
                                }
                                found.$v = true;
                                return result;
                            }
                        }
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }
                found.$v = false;
                return $.$default(TSource);
            }
            static /*IEnumerable<TSource> */ Skip(TSource, /*this IEnumerable<TSource>*/ source, /*int*/ count)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                }
                let iterator;
                if (count <= 0)
                {
                    if ($.$is(source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource)))
                    {
                        return source;
                    }
                    count = 0;
                }
                else if ($.$is(source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }))
                {
                    return iterator.Skip(count) ?? $.$sl.System.Linq.Enumerable.Empty(TSource);
                }
                return $.$sl.System.Linq.Enumerable.SpeedOptimizedSkipIterator(TSource, source, count);
            }
            static /*IEnumerable<TSource> */ SkipWhile(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (predicate === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.predicate*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.SkipWhileIterator(TSource, source, predicate);
            }
            static /*IEnumerable<TSource> */ SkipWhileIterator(TSource, /*IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    try
                    {
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            /*TSource*/ let element = e.System$Collections$Generic$IEnumerator$$$Current;
                            if (!predicate.Invoke(element))
                            {
                                yield element;
                                while(e.System$Collections$IEnumerator$MoveNext())
                                {
                                    yield e.System$Collections$Generic$IEnumerator$$$Current;
                                }
                                return;
                            }
                        }
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            static /*IEnumerable<TSource> */ SkipWhile$1(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, int, bool>*/ predicate)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (predicate === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.predicate*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.SkipWhileIterator$1(TSource, source, predicate);
            }
            static /*IEnumerable<TSource> */ SkipWhileIterator$1(TSource, /*IEnumerable<TSource>*/ source, /*Func<TSource, int, bool>*/ predicate)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                    try
                    {
                        /*int*/ let index = -1;
                        while(e.System$Collections$IEnumerator$MoveNext())
                        {
                            //checked
                            {
                                index++;
                            }
                            /*TSource*/ let element = e.System$Collections$Generic$IEnumerator$$$Current;
                            if (!predicate.Invoke(element, index))
                            {
                                yield element;
                                while(e.System$Collections$IEnumerator$MoveNext())
                                {
                                    yield e.System$Collections$Generic$IEnumerator$$$Current;
                                }
                                return;
                            }
                        }
                    }
                    finally
                    {
                        e?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            static /*IEnumerable<TSource> */ SkipLast(TSource, /*this IEnumerable<TSource>*/ source, /*int*/ count)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                return $.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null) : count <= 0 ? $.$sl.System.Linq.Enumerable.Skip(TSource, source, 0) : $.$sl.System.Linq.Enumerable.TakeRangeFromEndIterator(TSource, source, false, 0, true, count);
            }
            static /*IEnumerable<TSource> */ SpeedOptimizedSkipIterator(TSource, /*IEnumerable<TSource>*/ source, /*int*/ count)
            {
                let sourceList;
                return $.$is(source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ sourceList = v; } }) ? new ($.$sl.System.Linq.Enumerable.IListSkipTakeIterator$$(TSource))().$ctor$2(sourceList, count, 2147483647/*int.MaxValue*/) : new ($.$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator$$(TSource))().$ctor$2(source, count, -1);
            }
            static $_IListSkipTakeIterator$$;
            static IListSkipTakeIterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_IListSkipTakeIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.IListSkipTakeIterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.IListSkipTakeIterator<>", [TSource], ($self) => class IListSkipTakeIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TSource)
                {
                    /*IList<TSource>*/ _source = null;
                    /*int*/ _minIndexInclusive = 0;
                    /*int*/ _maxIndexInclusive = 0;
                    $ctor$2(/*IList<TSource>*/ source, /*int*/ minIndexInclusive, /*int*/ maxIndexInclusive)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(minIndexInclusive >= 0, "minIndexInclusive >= 0");
                            $.$spc.System.Diagnostics.Debug.Assert$1(minIndexInclusive <= maxIndexInclusive, "minIndexInclusive <= maxIndexInclusive");
                            this._source = source;
                            this._minIndexInclusive = minIndexInclusive;
                            this._maxIndexInclusive = maxIndexInclusive;
                        }
                        return this;
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.IListSkipTakeIterator$$(TSource))().$ctor$2(this._source, this._minIndexInclusive, this._maxIndexInclusive);
                    }
                    /*bool */ MoveNext()
                    {
                        /*int*/ let index = ((this._state - 1) | 0);
                        if ((index >>> 0) <= ((((this._maxIndexInclusive - this._minIndexInclusive) | 0)) >>> 0) && index < ((this._source.System$Collections$Generic$ICollection$$$Count - this._minIndexInclusive) | 0))
                        {
                            this._current = this._source.System$Collections$Generic$IList$$$get_Item(((this._minIndexInclusive + index) | 0), [TSource]);
                            ++this._state;
                            return true;
                        }
                        this.Dispose();
                        return false;
                    }
                    /*IEnumerable<TResult> */ Select(TResult, /*Func<TSource, TResult>*/ selector)
                    {
                        return new ($.$sl.System.Linq.Enumerable.IListSkipTakeSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, selector, this._minIndexInclusive, this._maxIndexInclusive);
                    }
                    /*Iterator<TSource>? */ Skip(/*int*/ count)
                    {
                        /*int*/ let minIndex = ((this._minIndexInclusive + count) | 0);
                        return (minIndex >>> 0) > (this._maxIndexInclusive >>> 0) ? null : new ($.$sl.System.Linq.Enumerable.IListSkipTakeIterator$$(TSource))().$ctor$2(this._source, minIndex, this._maxIndexInclusive);
                    }
                    /*Iterator<TSource> */ Take(/*int*/ count)
                    {
                        /*int*/ let maxIndex = ((((this._minIndexInclusive + count) | 0) - 1) | 0);
                        return (maxIndex >>> 0) >= (this._maxIndexInclusive >>> 0) ? this : new ($.$sl.System.Linq.Enumerable.IListSkipTakeIterator$$(TSource))().$ctor$2(this._source, this._minIndexInclusive, maxIndex);
                    }
                    /*TSource? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if ((index >>> 0) <= ((((this._maxIndexInclusive - this._minIndexInclusive) | 0)) >>> 0) && index < ((this._source.System$Collections$Generic$ICollection$$$Count - this._minIndexInclusive) | 0))
                        {
                            found.$v = true;
                            return this._source.System$Collections$Generic$IList$$$get_Item(((this._minIndexInclusive + index) | 0), [TSource]);
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*TSource? */ TryGetFirst(/*out bool*/ found)
                    {
                        if (this._source.System$Collections$Generic$ICollection$$$Count > this._minIndexInclusive)
                        {
                            found.$v = true;
                            return this._source.System$Collections$Generic$IList$$$get_Item(this._minIndexInclusive, [TSource]);
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*TSource? */ TryGetLast(/*out bool*/ found)
                    {
                        /*int*/ let lastIndex = ((this._source.System$Collections$Generic$ICollection$$$Count - 1) | 0);
                        if (lastIndex >= this._minIndexInclusive)
                        {
                            found.$v = true;
                            return this._source.System$Collections$Generic$IList$$$get_Item($.$spc.System.Math.Min$4(lastIndex, this._maxIndexInclusive), [TSource]);
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*int */ get Count()
                    {
                        return $.$sl.System.Linq.Enumerable.IListSkipTakeIterator$$(TSource).GetAdjustedCount(this._minIndexInclusive, this._maxIndexInclusive, this._source.System$Collections$Generic$ICollection$$$Count);
                    }
                    static /*int */ GetAdjustedCount(/*int*/ minIndexInclusive, /*int*/ maxIndexInclusive, /*int*/ sourceCount)
                    {
                        if (sourceCount <= minIndexInclusive)
                        {
                            return 0;
                        }
                        return (((($.$spc.System.Math.Min$4(((sourceCount - 1) | 0), maxIndexInclusive) - minIndexInclusive) | 0) + 1) | 0);
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        return this.Count;
                    }
                    /*TSource[] */ ToArray()
                    {
                        /*int*/ let count = this.Count;
                        if (count === 0)
                        {
                            return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                        }
                        /*TSource[]*/ let array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TSource), null, [count], null);
                        $.$sl.System.Linq.Enumerable.IListSkipTakeIterator$$(TSource).Fill(this._source, $.$spc.System.Span$$(TSource).op_Implicit(array), this._minIndexInclusive);
                        return array;
                    }
                    /*List<TSource> */ ToList()
                    {
                        /*int*/ let count = this.Count;
                        /*List<TSource>*/ let list = (() =>
                        {
                            let $t1 = new ($.$spc.System.Collections.Generic.List$$(TSource))().$ctor$1();
                            return $t1;
                        })();
                        if (count !== 0)
                        {
                            $.$sl.System.Linq.Enumerable.IListSkipTakeIterator$$(TSource).Fill(this._source, $.$sl.System.Linq.Enumerable.SetCountAndGetSpan(TSource, list, count), this._minIndexInclusive);
                        }
                        return list;
                    }
                    /*void */ CopyTo(/*TSource[]*/ array, /*int*/ arrayIndex)
                    {
                        return $.$sl.System.Linq.Enumerable.IListSkipTakeIterator$$(TSource).Fill(this._source, $.$spc.System.MemoryExtensions.AsSpan$9(TSource, array, arrayIndex, this.Count), this._minIndexInclusive);
                    }
                    static /*void */ Fill(/*IList<TSource>*/ source, /*Span<TSource>*/ destination, /*int*/ sourceIndex)
                    {
                        /*ReadOnlySpan<TSource>*/ let sourceSpan;
                        if ($.$sl.System.Linq.Enumerable.TryGetSpan(TSource, source, $.$ref(() => sourceSpan, ($v) => sourceSpan = $v, $.$spc.System.ReadOnlySpan$$(TSource))))
                        {
                            sourceSpan.Slice$1(sourceIndex, destination.Length).CopyTo(destination);
                            return;
                        }
                        for(/*int*/ let i = 0; i < destination.Length; i++, sourceIndex++)
                        {
                            destination.get_Item(i).$v = source.System$Collections$Generic$IList$$$get_Item(sourceIndex, [TSource]);
                        }
                    }
                    /*bool */ Contains(/*TSource*/ item)
                    {
                        return this.IndexOf(item) >= 0;
                    }
                    /*int */ IndexOf(/*TSource*/ item)
                    {
                        /*IList<TSource>*/ let source = this._source;
                        /*ReadOnlySpan<TSource>*/ let span;
                        if ($.$sl.System.Linq.Enumerable.TryGetSpan(TSource, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(TSource))))
                        {
                            /*int*/ let minInclusive = this._minIndexInclusive;
                            if (minInclusive < span.Length)
                            {
                                return $.$spc.System.MemoryExtensions.IndexOf$3(TSource, span.Slice$1(minInclusive, $.$sl.System.Linq.Enumerable.IListSkipTakeIterator$$(TSource).GetAdjustedCount(minInclusive, this._maxIndexInclusive, span.Length)), item, null);
                            }
                        }
                        else 
                        {
                            /*int*/ let end = ((this._minIndexInclusive + this.Count) | 0);
                            for(/*int*/ let i = this._minIndexInclusive; i < end; i++)
                            {
                                if ($.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default.Equals$2(source.System$Collections$Generic$IList$$$get_Item(i, [TSource]), item))
                                {
                                    return ((i - this._minIndexInclusive) | 0);
                                }
                            }
                        }
                        return -1;
                    }
                    /*TSource*/ get_Item(/*int*/ index)
                    {
                        if ((index >>> 0) >= (this.Count >>> 0))
                        {
                            $.$sl.System.Linq.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.index*/);
                        }
                        return this._source.System$Collections$Generic$IList$$$get_Item(((this._minIndexInclusive + index) | 0), [TSource]);
                    }
                    /*void*/ set_Item(/*int*/ index, /*TSource*/ value)
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
                    }
                    /*bool */ get IsReadOnly()
                    {
                        return true;
                    }
                    /*void */ System$Collections$Generic$ICollection$$$Add(/*TSource*/ item)
                    {
                        return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
                    }
                    /*void */ System$Collections$Generic$ICollection$$$Clear()
                    {
                        return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
                    }
                    /*void */ System$Collections$Generic$IList$$$Insert(/*int*/ index, /*TSource*/ item)
                    {
                        return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
                    }
                    /*bool */ System$Collections$Generic$ICollection$$$Remove(/*TSource*/ item)
                    {
                        return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException_Boolean();
                    }
                    /*void */ System$Collections$Generic$IList$$$RemoveAt(/*int*/ index)
                    {
                        return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<TSource>.this[int].get
                    System$Collections$Generic$IList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<TSource>.this[int].set
                    System$Collections$Generic$IList$$$set_Item()
                    {
                        return this.set_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IList<TSource>.IndexOf(TSource)
                    System$Collections$Generic$IList$$$IndexOf()
                    {
                        return this.IndexOf(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TSource>.Count.get
                    get System$Collections$Generic$ICollection$$$Count()
                    {
                        return this.Count;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TSource>.IsReadOnly.get
                    get System$Collections$Generic$ICollection$$$IsReadOnly()
                    {
                        return this.IsReadOnly;
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TSource>.Contains(TSource)
                    System$Collections$Generic$ICollection$$$Contains()
                    {
                        return this.Contains(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.ICollection<TSource>.CopyTo(TSource[], int)
                    System$Collections$Generic$ICollection$$$CopyTo()
                    {
                        return this.CopyTo(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyList<TSource>.this[int].get
                    System$Collections$Generic$IReadOnlyList$$$get_Item()
                    {
                        return this.get_Item(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<TSource>.Count.get
                    get System$Collections$Generic$IReadOnlyCollection$$$Count()
                    {
                        return this.Count;
                    }
                    static $h = 2162695;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator, $.$spc.System.Collections.Generic.IList$$(TSource), $.$spc.System.Collections.Generic.ICollection$$(TSource), $.$spc.System.Collections.Generic.IReadOnlyList$$(TSource), $.$spc.System.Collections.Generic.IReadOnlyCollection$$(TSource), $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable ]; }
                    static get $fullName() { return `System.Linq.Enumerable.IListSkipTakeIterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_IListSkipTakeIterator$$ = $v))(TSource);
            }
            static $_IEnumerableSkipTakeIterator$$;
            static IEnumerableSkipTakeIterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_IEnumerableSkipTakeIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator<>", [TSource], ($self) => class IEnumerableSkipTakeIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TSource)
                {
                    /*IEnumerable<TSource>*/ _source = null;
                    /*int*/ _minIndexInclusive = 0;
                    /*int*/ _maxIndexInclusive = 0;
                    /*IEnumerator<TSource>?*/ _enumerator = null;
                    $ctor$2(/*IEnumerable<TSource>*/ source, /*int*/ minIndexInclusive, /*int*/ maxIndexInclusive)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!($.$is(source, $.$spc.System.Collections.Generic.IList$$(TSource))), `The caller needs to check for ${"IList"}.`);
                            $.$spc.System.Diagnostics.Debug.Assert$1(minIndexInclusive >= 0, "minIndexInclusive >= 0");
                            $.$spc.System.Diagnostics.Debug.Assert$1(maxIndexInclusive >= -1, "maxIndexInclusive >= -1");
                            $.$spc.System.Diagnostics.Debug.Assert$1(maxIndexInclusive === -1 || (((maxIndexInclusive - minIndexInclusive) | 0) < 2147483647/*int.MaxValue*/), `${"Limit"} will overflow!`);
                            $.$spc.System.Diagnostics.Debug.Assert$1(maxIndexInclusive === -1 || minIndexInclusive <= maxIndexInclusive, "maxIndexInclusive == -1 || minIndexInclusive <= maxIndexInclusive");
                            this._source = source;
                            this._minIndexInclusive = minIndexInclusive;
                            this._maxIndexInclusive = maxIndexInclusive;
                        }
                        return this;
                    }
                    /*bool */ get HasLimit()
                    {
                        return this._maxIndexInclusive !== -1;
                    }
                    /*int */ get Limit()
                    {
                        return ((((this._maxIndexInclusive + 1) | 0) - this._minIndexInclusive) | 0);
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator$$(TSource))().$ctor$2(this._source, this._minIndexInclusive, this._maxIndexInclusive);
                    }
                    /*void */ Dispose()
                    {
                        if (!(this._enumerator === null))
                        {
                            this._enumerator.System$IDisposable$Dispose();
                            this._enumerator = null;
                        }
                        super.Dispose();
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        if (onlyIfCheap)
                        {
                            return -1;
                        }
                        if (!this.HasLimit)
                        {
                            return $.$spc.System.Math.Max$4((($.$sl.System.Linq.Enumerable.Count(TSource, this._source) - this._minIndexInclusive) | 0), 0);
                        }
                        /*IEnumerator<TSource>*/ let en = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                        try
                        {
                            /*uint*/ let count = $.$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator$$(TSource).SkipAndCount$1((((this._maxIndexInclusive >>> 0) + 1) >>> 0), en);
                            $.$spc.System.Diagnostics.Debug.Assert$1(count !== ((2147483647/*int.MaxValue*/ + 1) >>> 0) || this._minIndexInclusive > 0, "Our return value will be incorrect.");
                            return $.$spc.System.Math.Max$4((((count | 0) - this._minIndexInclusive) | 0), 0);
                        }
                        finally
                        {
                            en?.System$IDisposable$Dispose();
                        }
                    }
                    /*bool */ MoveNext()
                    {
                        /*int*/ let taken = ((this._state - 3) | 0);
                        if (taken < -2)
                        {
                            this.Dispose();
                            return false;
                        }
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                this._enumerator = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                                this._state = 2;
                                $switchJumpState1 = 2; /*goto case 2*/
                                continue $switchJumpStart1;
                                case 2:
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._enumerator === null), "_enumerator is not null");
                                if (!this.SkipBeforeFirst(this._enumerator))
                                {
                                    break;
                                }
                                this._state = 3;
                                $switchJumpState1 = "$_$_CaseDefault_$_$"; /*goto case default*/
                                continue $switchJumpStart1;
                                default:
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._enumerator === null), "_enumerator is not null");
                                if ((!this.HasLimit || taken < this.Limit) && this._enumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    if (this.HasLimit)
                                    {
                                        this._state++;
                                    }
                                    this._current = this._enumerator.System$Collections$Generic$IEnumerator$$$Current;
                                    return true;
                                }
                                break;
                            }
                            break;
                        }
                        this.Dispose();
                        return false;
                    }
                    /*Iterator<TSource>? */ Skip(/*int*/ count)
                    {
                        /*int*/ let minIndex = ((this._minIndexInclusive + count) | 0);
                        if (!this.HasLimit)
                        {
                            if (minIndex < 0)
                            {
                                return new ($.$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator$$(TSource))().$ctor$2(this, count, -1);
                            }
                        }
                        else if ((minIndex >>> 0) > (this._maxIndexInclusive >>> 0))
                        {
                            return null;
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(minIndex >= 0, `We should have taken care of all cases when ${"minIndex"} overflows.`);
                        return new ($.$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator$$(TSource))().$ctor$2(this._source, minIndex, this._maxIndexInclusive);
                    }
                    /*Iterator<TSource> */ Take(/*int*/ count)
                    {
                        /*int*/ let maxIndex = ((((this._minIndexInclusive + count) | 0) - 1) | 0);
                        if (!this.HasLimit)
                        {
                            if (maxIndex < 0)
                            {
                                return new ($.$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator$$(TSource))().$ctor$2(this, 0, ((count - 1) | 0));
                            }
                        }
                        else if ((maxIndex >>> 0) >= (this._maxIndexInclusive >>> 0))
                        {
                            return this;
                        }
                        $.$spc.System.Diagnostics.Debug.Assert$1(maxIndex >= 0, `We should have taken care of all cases when ${"maxIndex"} overflows.`);
                        return new ($.$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator$$(TSource))().$ctor$2(this._source, this._minIndexInclusive, maxIndex);
                    }
                    /*TSource? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if (index >= 0 && (!this.HasLimit || index < this.Limit))
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(((this._minIndexInclusive + index) | 0) >= 0, `Adding ${"index"} caused ${"_minIndexInclusive"} to overflow.`);
                            let iterator;
                            if ($.$is(this._source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }))
                            {
                                return iterator.TryGetElementAt(((this._minIndexInclusive + index) | 0), found);
                            }
                            /*IEnumerator<TSource>*/ let en = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                            try
                            {
                                if ($.$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator$$(TSource).SkipBefore(((this._minIndexInclusive + index) | 0), en) && en.System$Collections$IEnumerator$MoveNext())
                                {
                                    found.$v = true;
                                    return en.System$Collections$Generic$IEnumerator$$$Current;
                                }
                            }
                            finally
                            {
                                en?.System$IDisposable$Dispose();
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*TSource? */ TryGetFirst(/*out bool*/ found)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(!this.HasLimit || this.Limit > 0, "!HasLimit || Limit > 0");
                        let iterator;
                        if ($.$is(this._source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }))
                        {
                            return iterator.TryGetElementAt(this._minIndexInclusive, found);
                        }
                        let en = null;
                        try
                        {
                            en = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                            if (this.SkipBeforeFirst(en) && en.System$Collections$IEnumerator$MoveNext())
                            {
                                found.$v = true;
                                return en.System$Collections$Generic$IEnumerator$$$Current;
                            }
                        }
                        finally
                        {
                            en?.System$IDisposable$Dispose();
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*TSource? */ TryGetLast(/*out bool*/ found)
                    {
                        let iterator;
                        let count;
                        if ($.$is(this._source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }) && $.$is(iterator.GetCount(true), $.$spc.System.Int32, { set $v(v){ count = v; } }) && count > this._minIndexInclusive)
                        {
                            return (count >>> 0) <= (this._maxIndexInclusive >>> 0) ? iterator.TryGetLast(found) : iterator.TryGetElementAt(this._maxIndexInclusive, found);
                        }
                        let en = null;
                        try
                        {
                            en = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                            if (this.SkipBeforeFirst(en) && en.System$Collections$IEnumerator$MoveNext())
                            {
                                /*int*/ let remaining = ((this.Limit - 1) | 0);
                                /*int*/ let comparand = this.HasLimit ? 0 : -2147483648/*int.MinValue*/;
                                /*TSource*/ let result;
                                do
                                {
                                    remaining--;
                                    result = en.System$Collections$Generic$IEnumerator$$$Current;
                                }
                                while(remaining >= comparand && en.System$Collections$IEnumerator$MoveNext());
                                found.$v = true;
                                return result;
                            }
                        }
                        finally
                        {
                            en?.System$IDisposable$Dispose();
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*TSource[] */ ToArray()
                    {
                        let en = null;
                        try
                        {
                            en = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                            if (this.SkipBeforeFirst(en) && en.System$Collections$IEnumerator$MoveNext())
                            {
                                /*int*/ let remaining = ((this.Limit - 1) | 0);
                                /*int*/ let comparand = this.HasLimit ? 0 : -2147483648/*int.MinValue*/;
                                /*SegmentedArrayBuilder<TSource>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource).ScratchBuffer)();
                                /*SegmentedArrayBuilder<TSource>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource))().$ctor$2($.$spc.System.Span$$(TSource).op_Implicit(scratch.$fields));
                                do
                                {
                                    remaining--;
                                    builder.Add(en.System$Collections$Generic$IEnumerator$$$Current);
                                }
                                while(remaining >= comparand && en.System$Collections$IEnumerator$MoveNext());
                                /*TSource[]*/ let result = builder.ToArray();
                                builder.Dispose();
                                return result;
                            }
                        }
                        finally
                        {
                            en?.System$IDisposable$Dispose();
                        }
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                    }
                    /*List<TSource> */ ToList()
                    {
                        let en = null;
                        try
                        {
                            en = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                            if (this.SkipBeforeFirst(en) && en.System$Collections$IEnumerator$MoveNext())
                            {
                                /*int*/ let remaining = ((this.Limit - 1) | 0);
                                /*int*/ let comparand = this.HasLimit ? 0 : -2147483648/*int.MinValue*/;
                                /*SegmentedArrayBuilder<TSource>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource).ScratchBuffer)();
                                /*SegmentedArrayBuilder<TSource>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource))().$ctor$2($.$spc.System.Span$$(TSource).op_Implicit(scratch.$fields));
                                do
                                {
                                    remaining--;
                                    builder.Add(en.System$Collections$Generic$IEnumerator$$$Current);
                                }
                                while(remaining >= comparand && en.System$Collections$IEnumerator$MoveNext());
                                /*List<TSource>*/ let result = builder.ToList();
                                builder.Dispose();
                                return result;
                            }
                        }
                        finally
                        {
                            en?.System$IDisposable$Dispose();
                        }
                        return (() =>
                        {
                            let $t1 = new ($.$spc.System.Collections.Generic.List$$(TSource))().$ctor$1();
                            return $t1;
                        })();
                    }
                    /*bool */ SkipBeforeFirst(/*IEnumerator<TSource>*/ en)
                    {
                        return $.$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator$$(TSource).SkipBefore(this._minIndexInclusive, en);
                    }
                    static /*bool */ SkipBefore(/*int*/ index, /*IEnumerator<TSource>*/ en)
                    {
                        return $.$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator$$(TSource).SkipAndCount(index, en) === index;
                    }
                    static /*int */ SkipAndCount(/*int*/ index, /*IEnumerator<TSource>*/ en)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(index >= 0, "index >= 0");
                        return ($.$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator$$(TSource).SkipAndCount$1((index >>> 0), en) | 0);
                    }
                    static /*uint */ SkipAndCount$1(/*uint*/ index, /*IEnumerator<TSource>*/ en)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(en === null), "en is not null");
                        for(/*uint*/ let i = 0; i < index; i++)
                        {
                            if (!en.System$Collections$IEnumerator$MoveNext())
                            {
                                return i;
                            }
                        }
                        return index;
                    }
                    static $h = 1900551;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.IEnumerableSkipTakeIterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_IEnumerableSkipTakeIterator$$ = $v))(TSource);
            }
            static /*int */ Sum(/*this IEnumerable<int>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Sum$5($.$spc.System.Int32, $.$spc.System.Int32, source);
            }
            static /*long */ Sum$1(/*this IEnumerable<long>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Sum$5($.$spc.System.Int64, $.$spc.System.Int64, source);
            }
            static /*float */ Sum$2(/*this IEnumerable<float>*/ source)
            {
                return $.$cast($.$sl.System.Linq.Enumerable.Sum$5($.$spc.System.Single, $.$spc.System.Double, source), $.$spc.System.Single);
            }
            static /*double */ Sum$3(/*this IEnumerable<double>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Sum$5($.$spc.System.Double, $.$spc.System.Double, source);
            }
            static /*decimal */ Sum$4(/*this IEnumerable<decimal>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Sum$5($.$spc.System.Decimal, $.$spc.System.Decimal, source);
            }
            static /*TResult */ Sum$5(TSource, TResult, /*this IEnumerable<TSource>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*ReadOnlySpan<TSource>*/ let span;
                if ($.$sl.System.Linq.Enumerable.TryGetSpan(TSource, source, $.$ref(() => span, ($v) => span = $v, $.$spc.System.ReadOnlySpan$$(TSource))))
                {
                    return $.$sl.System.Linq.Enumerable.Sum$6(TSource, TResult, span);
                }
                /*TResult*/ let sum = TResult.System$Numerics$INumberBase$$$Zero;
                var $en2 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var value = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        //checked
                        {
                            sum = TResult.System$Numerics$IAdditionOperators$$$$$op_CheckedAddition(sum, TResult.System$Numerics$INumberBase$$$CreateChecked(TSource, value));
                        }
                    }
                }
                return sum;
            }
            static /*TResult */ Sum$6(T, TResult, /*ReadOnlySpan<T>*/ span)
            {
                //if (typeof(T) == typeof(TResult)                && Vector<T>.IsSupported                && Vector.IsHardwareAccelerated                && Vector<T>.Count > 2                && span.Length >= Vector<T>.Count * 4) { ... }
                /*TResult*/ let sum = TResult.System$Numerics$INumberBase$$$Zero;
                var $en2 = span.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var value = $en2.Current.$v;
                    {
                        //checked
                        {
                            sum = TResult.System$Numerics$IAdditionOperators$$$$$op_CheckedAddition(sum, TResult.System$Numerics$INumberBase$$$CreateChecked(T, value));
                        }
                    }
                }
                return sum;
            }
            static /*T */ SumSignedIntegersVectorized(T, /*ReadOnlySpan<T>*/ span)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(span.Length >= (($.$spc.System.Numerics.Vector$$(T).Count * 4) | 0), "span.Length >= Vector<T>.Count * 4");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Numerics.Vector$$(T).Count > 2, "Vector<T>.Count > 2");
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Numerics.Vector.IsHardwareAccelerated, "Vector.IsHardwareAccelerated");
                /*ref T*/ let ptr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1(T, span);
                /*nuint*/ let length = (span.Length >>> 0);
                /*Vector<T>*/ let accumulator = $.$spc.System.Numerics.Vector$$(T).Zero;
                /*Vector<T>*/ let overflowTestVector = new ($.$spc.System.Numerics.Vector$$(T))().$ctor$2(T.System$Numerics$IMinMaxValue$$$MinValue);
                /*nuint*/ let index = 0;
                /*nuint*/ let limit = ((length - ((($.$spc.System.Numerics.Vector$$(T).Count >>> 0) * 4) >>> 0)) >>> 0);
                do
                {
                    /*Vector<T>*/ let data = $.$spc.System.Numerics.Vector.LoadUnsafe$1(T, ptr, index);
                    /*Vector<T>*/ let accumulator2 = $.$spc.System.Numerics.Vector$$(T).op_Addition(accumulator, data);
                    /*Vector<T>*/ let overflowTracking = $.$spc.System.Numerics.Vector$$(T).op_BitwiseAnd(($.$spc.System.Numerics.Vector$$(T).op_ExclusiveOr(accumulator2, accumulator)), ($.$spc.System.Numerics.Vector$$(T).op_ExclusiveOr(accumulator2, data)));
                    data = $.$spc.System.Numerics.Vector.LoadUnsafe$1(T, ptr, ((index + ($.$spc.System.Numerics.Vector$$(T).Count >>> 0)) >>> 0));
                    accumulator = $.$spc.System.Numerics.Vector$$(T).op_Addition(accumulator2, data);
                    overflowTracking = $.$spc.System.Numerics.Vector$$(T).op_BitwiseOr(overflowTracking, $.$spc.System.Numerics.Vector$$(T).op_BitwiseAnd(($.$spc.System.Numerics.Vector$$(T).op_ExclusiveOr(accumulator, accumulator2)), ($.$spc.System.Numerics.Vector$$(T).op_ExclusiveOr(accumulator, data))));
                    data = $.$spc.System.Numerics.Vector.LoadUnsafe$1(T, ptr, ((index + ((($.$spc.System.Numerics.Vector$$(T).Count >>> 0) * 2) >>> 0)) >>> 0));
                    accumulator2 = $.$spc.System.Numerics.Vector$$(T).op_Addition(accumulator, data);
                    overflowTracking = $.$spc.System.Numerics.Vector$$(T).op_BitwiseOr(overflowTracking, $.$spc.System.Numerics.Vector$$(T).op_BitwiseAnd(($.$spc.System.Numerics.Vector$$(T).op_ExclusiveOr(accumulator2, accumulator)), ($.$spc.System.Numerics.Vector$$(T).op_ExclusiveOr(accumulator2, data))));
                    data = $.$spc.System.Numerics.Vector.LoadUnsafe$1(T, ptr, ((index + ((($.$spc.System.Numerics.Vector$$(T).Count >>> 0) * 3) >>> 0)) >>> 0));
                    accumulator = $.$spc.System.Numerics.Vector$$(T).op_Addition(accumulator2, data);
                    overflowTracking = $.$spc.System.Numerics.Vector$$(T).op_BitwiseOr(overflowTracking, $.$spc.System.Numerics.Vector$$(T).op_BitwiseAnd(($.$spc.System.Numerics.Vector$$(T).op_ExclusiveOr(accumulator, accumulator2)), ($.$spc.System.Numerics.Vector$$(T).op_ExclusiveOr(accumulator, data))));
                    if ($.$spc.System.Numerics.Vector$$(T).op_Inequality(($.$spc.System.Numerics.Vector$$(T).op_BitwiseAnd(overflowTracking, overflowTestVector)), $.$spc.System.Numerics.Vector$$(T).Zero))
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowOverflowException();
                    }
                    index += ((($.$spc.System.Numerics.Vector$$(T).Count >>> 0) * 4) >>> 0);
                }
                while(index < limit);
                limit = ((length - ($.$spc.System.Numerics.Vector$$(T).Count >>> 0)) >>> 0);
                if (index < limit)
                {
                    /*Vector<T>*/ let overflowTracking = $.$spc.System.Numerics.Vector$$(T).Zero;
                    do
                    {
                        /*Vector<T>*/ let data = $.$spc.System.Numerics.Vector.LoadUnsafe$1(T, ptr, index);
                        /*Vector<T>*/ let accumulator2 = $.$spc.System.Numerics.Vector$$(T).op_Addition(accumulator, data);
                        overflowTracking = $.$spc.System.Numerics.Vector$$(T).op_BitwiseOr(overflowTracking, $.$spc.System.Numerics.Vector$$(T).op_BitwiseAnd(($.$spc.System.Numerics.Vector$$(T).op_ExclusiveOr(accumulator2, accumulator)), ($.$spc.System.Numerics.Vector$$(T).op_ExclusiveOr(accumulator2, data))));
                        accumulator = accumulator2;
                        index += ($.$spc.System.Numerics.Vector$$(T).Count >>> 0);
                    }
                    while(index < limit);
                    if ($.$spc.System.Numerics.Vector$$(T).op_Inequality(($.$spc.System.Numerics.Vector$$(T).op_BitwiseAnd(overflowTracking, overflowTestVector)), $.$spc.System.Numerics.Vector$$(T).Zero))
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowOverflowException();
                    }
                }
                /*T*/ let result = T.System$Numerics$INumberBase$$$Zero;
                for(/*int*/ let i = 0; i < $.$spc.System.Numerics.Vector$$(T).Count; i++)
                {
                    //checked
                    {
                        result = T.System$Numerics$IAdditionOperators$$$$$op_CheckedAddition(result, accumulator.get_Item(i));
                    }
                }
                while(index < length)
                {
                    //checked
                    {
                        result = T.System$Numerics$IAdditionOperators$$$$$op_CheckedAddition(result, $.$spc.System.Runtime.CompilerServices.Unsafe.Add$3(T, ptr, index).$v);
                    }
                    index++;
                }
                return result;
            }
            static /*int? */ Sum$7(/*this IEnumerable<int?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Sum$12($.$spc.System.Int32, $.$spc.System.Int32, source);
            }
            static /*long? */ Sum$8(/*this IEnumerable<long?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Sum$12($.$spc.System.Int64, $.$spc.System.Int64, source);
            }
            static /*float? */ Sum$9(/*this IEnumerable<float?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Sum$12($.$spc.System.Single, $.$spc.System.Double, source);
            }
            static /*double? */ Sum$10(/*this IEnumerable<double?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Sum$12($.$spc.System.Double, $.$spc.System.Double, source);
            }
            static /*decimal? */ Sum$11(/*this IEnumerable<decimal?>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.Sum$12($.$spc.System.Decimal, $.$spc.System.Decimal, source);
            }
            static /*TSource? */ Sum$12(TSource, TAccumulator, /*this IEnumerable<TSource?>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                /*TAccumulator*/ let sum = TAccumulator.System$Numerics$INumberBase$$$Zero;
                var $en2 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var value = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if (!(value === null))
                        {
                            //checked
                            {
                                sum = TAccumulator.System$Numerics$IAdditionOperators$$$$$op_CheckedAddition(sum, TAccumulator.System$Numerics$INumberBase$$$CreateChecked(TSource, $.$spc.System.Nullable$$(TSource).GetValueOrDefault.call(value)));
                            }
                        }
                    }
                }
                return TSource.System$Numerics$INumberBase$$$CreateTruncating(TAccumulator, sum);
            }
            static /*int */ Sum$13(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, int>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Sum$18(TSource, $.$spc.System.Int32, $.$spc.System.Int32, source, selector);
            }
            static /*long */ Sum$14(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, long>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Sum$18(TSource, $.$spc.System.Int64, $.$spc.System.Int64, source, selector);
            }
            static /*float */ Sum$15(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, float>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Sum$18(TSource, $.$spc.System.Single, $.$spc.System.Double, source, selector);
            }
            static /*double */ Sum$16(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, double>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Sum$18(TSource, $.$spc.System.Double, $.$spc.System.Double, source, selector);
            }
            static /*decimal */ Sum$17(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, decimal>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Sum$18(TSource, $.$spc.System.Decimal, $.$spc.System.Decimal, source, selector);
            }
            static /*TResult */ Sum$18(TSource, TResult, TAccumulator, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TResult>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*TAccumulator*/ let sum = TAccumulator.System$Numerics$INumberBase$$$Zero;
                var $en2 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var value = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        //checked
                        {
                            sum = TAccumulator.System$Numerics$IAdditionOperators$$$$$op_CheckedAddition(sum, TAccumulator.System$Numerics$INumberBase$$$CreateChecked(TResult, selector.Invoke(value)));
                        }
                    }
                }
                return TResult.System$Numerics$INumberBase$$$CreateTruncating(TAccumulator, sum);
            }
            static /*int? */ Sum$19(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, int?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Sum$24(TSource, $.$spc.System.Int32, $.$spc.System.Int32, source, selector);
            }
            static /*long? */ Sum$20(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, long?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Sum$24(TSource, $.$spc.System.Int64, $.$spc.System.Int64, source, selector);
            }
            static /*float? */ Sum$21(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, float?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Sum$24(TSource, $.$spc.System.Single, $.$spc.System.Double, source, selector);
            }
            static /*double? */ Sum$22(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, double?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Sum$24(TSource, $.$spc.System.Double, $.$spc.System.Double, source, selector);
            }
            static /*decimal? */ Sum$23(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, decimal?>*/ selector)
            {
                return $.$sl.System.Linq.Enumerable.Sum$24(TSource, $.$spc.System.Decimal, $.$spc.System.Decimal, source, selector);
            }
            static /*TResult? */ Sum$24(TSource, TResult, TAccumulator, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TResult?>*/ selector)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (selector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(16/*ExceptionArgument.selector*/);
                }
                /*TAccumulator*/ let sum = TAccumulator.System$Numerics$INumberBase$$$Zero;
                var $en2 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        let selectedValue;
                        if ($.$is(selector.Invoke(item), TResult, { set $v(v){ selectedValue = v; } }))
                        {
                            //checked
                            {
                                sum = TAccumulator.System$Numerics$IAdditionOperators$$$$$op_CheckedAddition(sum, TAccumulator.System$Numerics$INumberBase$$$CreateChecked(TResult, selectedValue));
                            }
                        }
                    }
                }
                return TResult.System$Numerics$INumberBase$$$CreateTruncating(TAccumulator, sum);
            }
            static /*IEnumerable<TSource> */ Take(TSource, /*this IEnumerable<TSource>*/ source, /*int*/ count)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (count <= 0 || $.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.SpeedOptimizedTakeIterator(TSource, source, count);
            }
            static /*IEnumerable<TSource> */ Take$1(TSource, /*this IEnumerable<TSource>*/ source, /*Range*/ range)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                }
                /*Index*/ let start = range.Start;
                /*Index*/ let end = range.End;
                /*bool*/ let isStartIndexFromEnd = start.IsFromEnd;
                /*bool*/ let isEndIndexFromEnd = end.IsFromEnd;
                /*int*/ let startIndex = start.Value;
                /*int*/ let endIndex = end.Value;
                $.$spc.System.Diagnostics.Debug.Assert$1(startIndex >= 0, "startIndex >= 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(endIndex >= 0, "endIndex >= 0");
                if (isStartIndexFromEnd)
                {
                    if (startIndex === 0 || (isEndIndexFromEnd && endIndex >= startIndex))
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                    }
                }
                else if (!isEndIndexFromEnd)
                {
                    if (startIndex >= endIndex)
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                    }
                    return $.$sl.System.Linq.Enumerable.SpeedOptimizedTakeRangeIterator(TSource, source, startIndex, endIndex);
                }
                return $.$sl.System.Linq.Enumerable.TakeRangeFromEndIterator(TSource, source, isStartIndexFromEnd, startIndex, isEndIndexFromEnd, endIndex);
            }
            static /*IEnumerable<TSource> */ TakeRangeFromEndIterator(TSource, /*IEnumerable<TSource>*/ source, /*bool*/ isStartIndexFromEnd, /*int*/ startIndex, /*bool*/ isEndIndexFromEnd, /*int*/ endIndex)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                    $.$spc.System.Diagnostics.Debug.Assert$1(isStartIndexFromEnd || isEndIndexFromEnd, "isStartIndexFromEnd || isEndIndexFromEnd");
                    $.$spc.System.Diagnostics.Debug.Assert$1(isStartIndexFromEnd ? startIndex > 0 && (!isEndIndexFromEnd || startIndex > endIndex) : startIndex >= 0 && (isEndIndexFromEnd || startIndex < endIndex), "isStartIndexFromEnd\r\n                ? startIndex > 0 && (!isEndIndexFromEnd || startIndex > endIndex)\r\n                : startIndex >= 0 && (isEndIndexFromEnd || startIndex < endIndex)");
                    /*int*/ let count;
                    if ($.$sl.System.Linq.Enumerable.TryGetNonEnumeratedCount(TSource, source, $.$ref(() => count, ($v) => count = $v, $.$spc.System.Int32)))
                    {
                        startIndex = CalculateStartIndex(isStartIndexFromEnd, startIndex, count);
                        endIndex = CalculateEndIndex(isEndIndexFromEnd, endIndex, count);
                        if (startIndex < endIndex)
                        {
                            /*IEnumerable<TSource>*/ let rangeIterator = $.$sl.System.Linq.Enumerable.SpeedOptimizedTakeRangeIterator(TSource, source, startIndex, endIndex);
                            var $en5 = rangeIterator.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var element = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    yield element;
                                }
                            }
                        }
                        return;
                    }
                    /*Queue<TSource>*/ let queue;
                    if (isStartIndexFromEnd)
                    {
                        let e = null;
                        try
                        {
                            e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                            if (!e.System$Collections$IEnumerator$MoveNext())
                            {
                                return;
                            }
                            queue = new ($.$spc.System.Collections.Generic.Queue$$(TSource))().$ctor$1();
                            queue.Enqueue(e.System$Collections$Generic$IEnumerator$$$Current);
                            count = 1;
                            while(e.System$Collections$IEnumerator$MoveNext())
                            {
                                if (count < startIndex)
                                {
                                    queue.Enqueue(e.System$Collections$Generic$IEnumerator$$$Current);
                                    ++count;
                                }
                                else 
                                {
                                    do
                                    {
                                        queue.Dequeue();
                                        queue.Enqueue(e.System$Collections$Generic$IEnumerator$$$Current);
                                        //checked
                                        {
                                            ++count;
                                        }
                                    }
                                    while(e.System$Collections$IEnumerator$MoveNext());
                                    break;
                                }
                            }
                            $.$spc.System.Diagnostics.Debug.Assert$1(queue.Count === $.$spc.System.Math.Min$4(count, startIndex), "queue.Count == Math.Min(count, startIndex)");
                        }
                        finally
                        {
                            e?.System$IDisposable$Dispose();
                        }
                        startIndex = CalculateStartIndex(true, startIndex, count);
                        endIndex = CalculateEndIndex(isEndIndexFromEnd, endIndex, count);
                        $.$spc.System.Diagnostics.Debug.Assert$1(((endIndex - startIndex) | 0) <= queue.Count, "endIndex - startIndex <= queue.Count");
                        for(/*int*/ let rangeIndex = startIndex; rangeIndex < endIndex; rangeIndex++)
                        {
                            yield queue.Dequeue();
                        }
                    }
                    else 
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(!isStartIndexFromEnd && isEndIndexFromEnd, "!isStartIndexFromEnd && isEndIndexFromEnd");
                        /*IEnumerator<TSource>*/ let e = source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                        try
                        {
                            count = 0;
                            while(count < startIndex && e.System$Collections$IEnumerator$MoveNext())
                            {
                                ++count;
                            }
                            if (count === startIndex)
                            {
                                queue = new ($.$spc.System.Collections.Generic.Queue$$(TSource))().$ctor$1();
                                while(e.System$Collections$IEnumerator$MoveNext())
                                {
                                    if (queue.Count === endIndex)
                                    {
                                        do
                                        {
                                            queue.Enqueue(e.System$Collections$Generic$IEnumerator$$$Current);
                                            yield queue.Dequeue();
                                        }
                                        while(e.System$Collections$IEnumerator$MoveNext());
                                        break;
                                    }
                                    else 
                                    {
                                        queue.Enqueue(e.System$Collections$Generic$IEnumerator$$$Current);
                                    }
                                }
                            }
                        }
                        finally
                        {
                            e?.System$IDisposable$Dispose();
                        }
                    }
                    /*static int*/  function CalculateStartIndex(/*bool*/ isStartIndexFromEnd, /*int*/ startIndex, /*int*/ count)
                    {
                        return $.$spc.System.Math.Max$4(0, isStartIndexFromEnd ? ((count - startIndex) | 0) : startIndex);
                    }
                    /*static int*/  function CalculateEndIndex(/*bool*/ isEndIndexFromEnd, /*int*/ endIndex, /*int*/ count)
                    {
                        return $.$spc.System.Math.Min$4(count, isEndIndexFromEnd ? ((count - endIndex) | 0) : endIndex);
                    }
                }.bind(this));
            }
            static /*IEnumerable<TSource> */ TakeWhile(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (predicate === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.predicate*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.TakeWhileIterator(TSource, source, predicate);
            }
            static /*IEnumerable<TSource> */ TakeWhileIterator(TSource, /*IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (!predicate.Invoke(element))
                            {
                                break;
                            }
                            yield element;
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<TSource> */ TakeWhile$1(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, int, bool>*/ predicate)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (predicate === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.predicate*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.TakeWhileIterator$1(TSource, source, predicate);
            }
            static /*IEnumerable<TSource> */ TakeWhileIterator$1(TSource, /*IEnumerable<TSource>*/ source, /*Func<TSource, int, bool>*/ predicate)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*int*/ let index = -1;
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            //checked
                            {
                                index++;
                            }
                            if (!predicate.Invoke(element, index))
                            {
                                break;
                            }
                            yield element;
                        }
                    }
                }.bind(this));
            }
            static /*IEnumerable<TSource> */ TakeLast(TSource, /*this IEnumerable<TSource>*/ source, /*int*/ count)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                return count <= 0 || $.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source) ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null) : $.$sl.System.Linq.Enumerable.TakeRangeFromEndIterator(TSource, source, true, count, true, 0);
            }
            static /*IEnumerable<TSource> */ SpeedOptimizedTakeIterator(TSource, /*IEnumerable<TSource>*/ source, /*int*/ count)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null) && !$.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source), "source is not null && !IsEmptyArray(source)");
                $.$spc.System.Diagnostics.Debug.Assert$1(count > 0, "count > 0");
                let iterator;
                let sourceList;
                return $.$is(source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }) ? (iterator.Take(count) ?? $.$sl.System.Linq.Enumerable.Empty(TSource)) : $.$is(source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ sourceList = v; } }) ? new ($.$sl.System.Linq.Enumerable.IListSkipTakeIterator$$(TSource))().$ctor$2(sourceList, 0, ((count - 1) | 0)) : new ($.$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator$$(TSource))().$ctor$2(source, 0, ((count - 1) | 0));
            }
            static /*IEnumerable<TSource> */ SpeedOptimizedTakeRangeIterator(TSource, /*IEnumerable<TSource>*/ source, /*int*/ startIndex, /*int*/ endIndex)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null) && !$.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source), "source is not null && !IsEmptyArray(source)");
                $.$spc.System.Diagnostics.Debug.Assert$1(startIndex >= 0 && startIndex < endIndex, "startIndex >= 0 && startIndex < endIndex");
                let iterator;
                let sourceList;
                return $.$is(source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }) ? TakeIteratorRange(iterator, startIndex, endIndex) : $.$is(source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ sourceList = v; } }) ? new ($.$sl.System.Linq.Enumerable.IListSkipTakeIterator$$(TSource))().$ctor$2(sourceList, startIndex, ((endIndex - 1) | 0)) : new ($.$sl.System.Linq.Enumerable.IEnumerableSkipTakeIterator$$(TSource))().$ctor$2(source, startIndex, ((endIndex - 1) | 0));
                /*static IEnumerable<TSource>*/  function TakeIteratorRange(/*Iterator<TSource>*/ iterator, /*int*/ startIndex, /*int*/ endIndex)
                {
                    /*Iterator<TSource>?*/ let source;
                    if (endIndex !== 0 && !((source = iterator.Take(endIndex)) === null) && (startIndex === 0 || !((source = source.Skip(startIndex)) === null)))
                    {
                        return source;
                    }
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                }
            }
            static /*TSource[] */ ToArray(TSource, /*this IEnumerable<TSource>*/ source)
            {
                let iterator;
                if (!$.$sl.System.Linq.Enumerable.IsSizeOptimized && $.$is(source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }))
                {
                    return iterator.ToArray();
                }
                let collection;
                if ($.$is(source, $.$spc.System.Collections.Generic.ICollection$$(TSource), { set $v(v){ collection = v; } }))
                {
                    return $.$sl.System.Linq.Enumerable.ICollectionToArray(TSource, collection);
                }
                return EnumerableToArray(source);
                /*static TSource[]*/  function EnumerableToArray(/*IEnumerable<TSource>*/ source)
                {
                    if (source === null)
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                    }
                    /*SegmentedArrayBuilder<TSource>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource).ScratchBuffer)();
                    /*SegmentedArrayBuilder<TSource>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource))().$ctor$2($.$spc.System.Span$$(TSource).op_Implicit(scratch.$fields));
                    builder.AddNonICollectionRangeInlined(source);
                    /*TSource[]*/ let result = builder.ToArray();
                    builder.Dispose();
                    return result;
                }
            }
            static /*TSource[] */ ICollectionToArray(TSource, /*ICollection<TSource>*/ collection)
            {
                /*int*/ let count = collection.System$Collections$Generic$ICollection$$$Count;
                if (count !== 0)
                {
                    /*var*/ let result = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TSource), null, [count], null);
                    collection.System$Collections$Generic$ICollection$$$CopyTo(result, 0, [TSource]);
                    return result;
                }
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
            }
            static /*List<TSource> */ ToList(TSource, /*this IEnumerable<TSource>*/ source)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                let iterator;
                if (!$.$sl.System.Linq.Enumerable.IsSizeOptimized && $.$is(source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }))
                {
                    return iterator.ToList();
                }
                return new ($.$spc.System.Collections.Generic.List$$(TSource))().$ctor$3(source);
            }
            static /*Dictionary<TKey, TValue> */ ToDictionary(TKey, TValue, /*this IEnumerable<KeyValuePair<TKey, TValue>>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.ToDictionary$1(TKey, TValue, source, null);
            }
            static /*Dictionary<TKey, TValue> */ ToDictionary$1(TKey, TValue, /*this IEnumerable<KeyValuePair<TKey, TValue>>*/ source, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                return new ($.$spc.System.Collections.Generic.Dictionary$$$(TKey, TValue))().$ctor$8(source, comparer);
            }
            static /*Dictionary<TKey, TValue> */ ToDictionary$2(TKey, TValue, /*this IEnumerable<(TKey Key, TValue Value)>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.ToDictionary$3(TKey, TValue, source, null);
            }
            static /*Dictionary<TKey, TValue> */ ToDictionary$3(TKey, TValue, /*this IEnumerable<(TKey Key, TValue Value)>*/ source, /*IEqualityComparer<TKey>?*/ comparer)
            {
                return $.$sl.System.Linq.Enumerable.ToDictionary$7($.$spc.System.ValueTuple$$$(TKey, TValue), TKey, TValue, source, new ($.$spc.System.Func$$$($.$spc.System.ValueTuple$$$(TKey, TValue), TKey))().$ctor(this,  (/*vt*/ vt) =>
                {
                    return vt.Item1;
                }), new ($.$spc.System.Func$$$($.$spc.System.ValueTuple$$$(TKey, TValue), TValue))().$ctor(this,  (/*vt*/ vt) =>
                {
                    return vt.Item2;
                }), comparer);
            }
            static /*Dictionary<TKey, TSource> */ ToDictionary$4(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector)
            {
                return $.$sl.System.Linq.Enumerable.ToDictionary$5(TSource, TKey, source, keySelector, null);
            }
            static /*Dictionary<TKey, TSource> */ ToDictionary$5(TSource, TKey, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                /*int*/ let capacity;
                if ($.$sl.System.Linq.Enumerable.TryGetNonEnumeratedCount(TSource, source, $.$ref(() => capacity, ($v) => capacity = $v, $.$spc.System.Int32)))
                {
                    if (capacity === 0)
                    {
                        return new ($.$spc.System.Collections.Generic.Dictionary$$$(TKey, TSource))().$ctor$3(comparer);
                    }
                    let array;
                    if ($.$is(source, $.$typeArray(TSource), { set $v(v){ array = v; } }))
                    {
                        return $.$sl.System.Linq.Enumerable.SpanToDictionary(TSource, TKey, $.$spc.System.ReadOnlySpan$$(TSource).op_Implicit(array), keySelector, comparer);
                    }
                    let list;
                    if ($.$is(source, $.$spc.System.Collections.Generic.List$$(TSource), { set $v(v){ list = v; } }))
                    {
                        /*ReadOnlySpan<TSource>*/ let span = $.$spc.System.Span$$(TSource).op_Implicit$2($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, list));
                        return $.$sl.System.Linq.Enumerable.SpanToDictionary(TSource, TKey, span, keySelector, comparer);
                    }
                }
                /*Dictionary<TKey, TSource>*/ let d = new ($.$spc.System.Collections.Generic.Dictionary$$$(TKey, TSource))().$ctor$4(capacity, comparer);
                var $en2 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var element = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        d.Add(keySelector.Invoke(element), element);
                    }
                }
                return d;
            }
            static /*Dictionary<TKey, TSource> */ SpanToDictionary(TSource, TKey, /*ReadOnlySpan<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                /*Dictionary<TKey, TSource>*/ let d = new ($.$spc.System.Collections.Generic.Dictionary$$$(TKey, TSource))().$ctor$4(source.Length, comparer);
                var $en2 = source.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var element = $en2.Current.$v;
                    {
                        d.Add(keySelector.Invoke(element), element);
                    }
                }
                return d;
            }
            static /*Dictionary<TKey, TElement> */ ToDictionary$6(TSource, TKey, TElement, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TSource, TElement>*/ elementSelector)
            {
                return $.$sl.System.Linq.Enumerable.ToDictionary$7(TSource, TKey, TElement, source, keySelector, elementSelector, null);
            }
            static /*Dictionary<TKey, TElement> */ ToDictionary$7(TSource, TKey, TElement, /*this IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TSource, TElement>*/ elementSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                if (elementSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(2/*ExceptionArgument.elementSelector*/);
                }
                /*int*/ let capacity;
                if ($.$sl.System.Linq.Enumerable.TryGetNonEnumeratedCount(TSource, source, $.$ref(() => capacity, ($v) => capacity = $v, $.$spc.System.Int32)))
                {
                    if (capacity === 0)
                    {
                        return new ($.$spc.System.Collections.Generic.Dictionary$$$(TKey, TElement))().$ctor$3(comparer);
                    }
                    let array;
                    if ($.$is(source, $.$typeArray(TSource), { set $v(v){ array = v; } }))
                    {
                        return $.$sl.System.Linq.Enumerable.SpanToDictionary$1(TSource, TKey, TElement, $.$spc.System.ReadOnlySpan$$(TSource).op_Implicit(array), keySelector, elementSelector, comparer);
                    }
                    let list;
                    if ($.$is(source, $.$spc.System.Collections.Generic.List$$(TSource), { set $v(v){ list = v; } }))
                    {
                        /*ReadOnlySpan<TSource>*/ let span = $.$spc.System.Span$$(TSource).op_Implicit$2($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, list));
                        return $.$sl.System.Linq.Enumerable.SpanToDictionary$1(TSource, TKey, TElement, span, keySelector, elementSelector, comparer);
                    }
                }
                /*Dictionary<TKey, TElement>*/ let d = new ($.$spc.System.Collections.Generic.Dictionary$$$(TKey, TElement))().$ctor$4(capacity, comparer);
                var $en2 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var element = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        d.Add(keySelector.Invoke(element), elementSelector.Invoke(element));
                    }
                }
                return d;
            }
            static /*Dictionary<TKey, TElement> */ SpanToDictionary$1(TSource, TKey, TElement, /*ReadOnlySpan<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TSource, TElement>*/ elementSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                /*Dictionary<TKey, TElement>*/ let d = new ($.$spc.System.Collections.Generic.Dictionary$$$(TKey, TElement))().$ctor$4(source.Length, comparer);
                var $en2 = source.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var element = $en2.Current.$v;
                    {
                        d.Add(keySelector.Invoke(element), elementSelector.Invoke(element));
                    }
                }
                return d;
            }
            static /*HashSet<TSource> */ ToHashSet(TSource, /*this IEnumerable<TSource>*/ source)
            {
                return $.$sl.System.Linq.Enumerable.ToHashSet$1(TSource, source, null);
            }
            static /*HashSet<TSource> */ ToHashSet$1(TSource, /*this IEnumerable<TSource>*/ source, /*IEqualityComparer<TSource>?*/ comparer)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                return new ($.$spc.System.Collections.Generic.HashSet$$(TSource))().$ctor$5(source, comparer);
            }
            /*int*/ static DefaultInternalSetCapacity = 7;
            static /*IEnumerable<TSource> */ Union(TSource, /*this IEnumerable<TSource>*/ first, /*IEnumerable<TSource>*/ second)
            {
                return $.$sl.System.Linq.Enumerable.Union$1(TSource, first, second, null);
            }
            static /*IEnumerable<TSource> */ Union$1(TSource, /*this IEnumerable<TSource>*/ first, /*IEnumerable<TSource>*/ second, /*IEqualityComparer<TSource>?*/ comparer)
            {
                if (first === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(4/*ExceptionArgument.first*/);
                }
                if (second === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(14/*ExceptionArgument.second*/);
                }
                let union;
                return $.$is(first, $.$sl.System.Linq.Enumerable.UnionIterator$$(TSource), { set $v(v){ union = v; } }) && $.$sl.System.Linq.Utilities.AreEqualityComparersEqual(TSource, comparer, union._comparer) ? union.Union(second) : new ($.$sl.System.Linq.Enumerable.UnionIterator2$$(TSource))().$ctor$3(first, second, comparer);
            }
            static /*IEnumerable<TSource> */ UnionBy(TSource, TKey, /*this IEnumerable<TSource>*/ first, /*IEnumerable<TSource>*/ second, /*Func<TSource, TKey>*/ keySelector)
            {
                return $.$sl.System.Linq.Enumerable.UnionBy$1(TSource, TKey, first, second, keySelector, null);
            }
            static /*IEnumerable<TSource> */ UnionBy$1(TSource, TKey, /*this IEnumerable<TSource>*/ first, /*IEnumerable<TSource>*/ second, /*Func<TSource, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                if (first === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(4/*ExceptionArgument.first*/);
                }
                if (second === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(14/*ExceptionArgument.second*/);
                }
                if (keySelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(9/*ExceptionArgument.keySelector*/);
                }
                return $.$sl.System.Linq.Enumerable.UnionByIterator(TSource, TKey, first, second, keySelector, comparer);
            }
            static /*IEnumerable<TSource> */ UnionByIterator(TSource, TKey, /*IEnumerable<TSource>*/ first, /*IEnumerable<TSource>*/ second, /*Func<TSource, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*var*/ let set = new ($.$spc.System.Collections.Generic.HashSet$$(TKey))().$ctor$6(7/*DefaultInternalSetCapacity*/, comparer);
                    var $en3 = first.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (set.Add(keySelector.Invoke(element)))
                            {
                                yield element;
                            }
                        }
                    }
                    var $en3 = second.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            if (set.Add(keySelector.Invoke(element)))
                            {
                                yield element;
                            }
                        }
                    }
                }.bind(this));
            }
            static $_UnionIterator$$;
            static UnionIterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_UnionIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.UnionIterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.UnionIterator<>", [TSource], ($self) => class UnionIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TSource)
                {
                    /*IEqualityComparer<TSource>?*/ _comparer = null;
                    /*IEnumerator<TSource>?*/ _enumerator = null;
                    /*HashSet<TSource>?*/ _set = null;
                    $ctor$2(/*IEqualityComparer<TSource>?*/ comparer)
                    {
                        super.$ctor$1();
                        {
                            this._comparer = comparer;
                        }
                        return this;
                    }
                    /*void */ Dispose()
                    {
                        if (!(this._enumerator === null))
                        {
                            this._enumerator.System$IDisposable$Dispose();
                            this._enumerator = null;
                            this._set = null;
                        }
                        super.Dispose();
                    }
                    /*void */ SetEnumerator(/*IEnumerator<TSource>*/ enumerator)
                    {
                        this._enumerator?.System$IDisposable$Dispose();
                        this._enumerator = enumerator;
                    }
                    /*void */ StoreFirst()
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(this._enumerator === null), "_enumerator is not null");
                        /*var*/ let set = new ($.$spc.System.Collections.Generic.HashSet$$(TSource))().$ctor$6(7/*DefaultInternalSetCapacity*/, this._comparer);
                        /*TSource*/ let element = this._enumerator.System$Collections$Generic$IEnumerator$$$Current;
                        set.Add(element);
                        this._current = element;
                        this._set = set;
                    }
                    /*bool */ GetNext()
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(this._enumerator === null), "_enumerator is not null");
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(this._set === null), "_set is not null");
                        /*HashSet<TSource>*/ let set = this._set;
                        while(this._enumerator.System$Collections$IEnumerator$MoveNext())
                        {
                            /*TSource*/ let element = this._enumerator.System$Collections$Generic$IEnumerator$$$Current;
                            if (set.Add(element))
                            {
                                this._current = element;
                                return true;
                            }
                        }
                        return false;
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._state === 1)
                        {
                            for(/*IEnumerable<TSource>?*/ let enumerable = this.GetEnumerable(0); !(enumerable === null); enumerable = this.GetEnumerable(((this._state - 1) | 0)))
                            {
                                /*IEnumerator<TSource>*/ let enumerator = enumerable.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                                this.SetEnumerator(enumerator);
                                ++this._state;
                                if (enumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    this.StoreFirst();
                                    return true;
                                }
                            }
                        }
                        else if (this._state > 0)
                        {
                            while(true)
                            {
                                if (this.GetNext())
                                {
                                    return true;
                                }
                                /*IEnumerable<TSource>?*/ let enumerable = this.GetEnumerable(((this._state - 1) | 0));
                                if (enumerable === null)
                                {
                                    break;
                                }
                                this.SetEnumerator(enumerable.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]));
                                ++this._state;
                            }
                        }
                        this.Dispose();
                        return false;
                    }
                    /*HashSet<TSource> */ FillSet()
                    {
                        /*var*/ let set = new ($.$spc.System.Collections.Generic.HashSet$$(TSource))().$ctor$2(this._comparer);
                        for(/*int*/ let index = 0; ; ++index)
                        {
                            /*IEnumerable<TSource>?*/ let enumerable = this.GetEnumerable(index);
                            if (enumerable === null)
                            {
                                return set;
                            }
                            set.UnionWith(enumerable);
                        }
                    }
                    /*TSource[] */ ToArray()
                    {
                        return $.$sl.System.Linq.Enumerable.ICollectionToArray(TSource, this.FillSet());
                    }
                    /*List<TSource> */ ToList()
                    {
                        return new ($.$spc.System.Collections.Generic.List$$(TSource))().$ctor$3(this.FillSet());
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        return onlyIfCheap ? -1 : this.FillSet().Count;
                    }
                    /*TSource? */ TryGetFirst(/*out bool*/ found)
                    {
                        /*IEnumerable<TSource>?*/ let source;
                        for(/*int*/ let i = 0; !((source = this.GetEnumerable(i)) === null); i++)
                        {
                            /*TSource?*/ let result = $.$sl.System.Linq.Enumerable.TryGetFirst(TSource, source, found);
                            if (found.$v)
                            {
                                return result;
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*bool */ Contains(/*TSource*/ value)
                    {
                        if (this._comparer === null)
                        {
                            /*IEnumerable<TSource>?*/ let source;
                            for(/*int*/ let i = 0; !((source = this.GetEnumerable(i)) === null); i++)
                            {
                                if ($.$sl.System.Linq.Enumerable.Contains(TSource, source, value))
                                {
                                    return true;
                                }
                            }
                            return false;
                        }
                        return super.Contains(value);
                    }
                    static $h = 3735559;
                    static $g = 1;
                    static $f = 0b10000000001110000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.UnionIterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_UnionIterator$$ = $v))(TSource);
            }
            static $_UnionIterator2$$;
            static UnionIterator2$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_UnionIterator2$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.UnionIterator2<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.UnionIterator2<>", [TSource], ($self) => class UnionIterator2$$ extends $.$sl.System.Linq.Enumerable.UnionIterator$$(TSource)
                {
                    /*IEnumerable<TSource>*/ _first = null;
                    /*IEnumerable<TSource>*/ _second = null;
                    $ctor$3(/*IEnumerable<TSource>*/ first, /*IEnumerable<TSource>*/ second, /*IEqualityComparer<TSource>?*/ comparer)
                    {
                        super.$ctor$2(comparer);
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(first === null), "first is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(second === null), "second is not null");
                            this._first = first;
                            this._second = second;
                        }
                        return this;
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.UnionIterator2$$(TSource))().$ctor$3(this._first, this._second, this._comparer);
                    }
                    /*IEnumerable<TSource>? */ GetEnumerable(/*int*/ index)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(index >= 0 && index <= 2, "index >= 0 && index <= 2");
                        return (() =>
                        {
                            if (index === 0)
                            {
                                return this._first;
                            }
                            if (index === 1)
                            {
                                return this._second;
                            }
                            return null;
                        })();
                    }
                    /*UnionIterator<TSource> */ Union(/*IEnumerable<TSource>*/ next)
                    {
                        /*var*/ let sources = new ($.$sl.System.Linq.SingleLinkedNode$$($.$spc.System.Collections.Generic.IEnumerable$$(TSource)))().$ctor$1(this._first).Add(this._second).Add(next);
                        return new ($.$sl.System.Linq.Enumerable.UnionIteratorN$$(TSource))().$ctor$3(sources, 2, this._comparer);
                    }
                    static $h = 3801095;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.UnionIterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.UnionIterator2<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_UnionIterator2$$ = $v))(TSource);
            }
            static $_UnionIteratorN$$;
            static UnionIteratorN$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_UnionIteratorN$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.UnionIteratorN<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.UnionIteratorN<>", [TSource], ($self) => class UnionIteratorN$$ extends $.$sl.System.Linq.Enumerable.UnionIterator$$(TSource)
                {
                    /*SingleLinkedNode<IEnumerable<TSource>>*/ _sources = null;
                    /*int*/ _headIndex = 0;
                    $ctor$3(/*SingleLinkedNode<IEnumerable<TSource>>*/ sources, /*int*/ headIndex, /*IEqualityComparer<TSource>?*/ comparer)
                    {
                        super.$ctor$2(comparer);
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(headIndex >= 2, "headIndex >= 2");
                            $.$spc.System.Diagnostics.Debug.Assert$1((sources?.GetCount() ?? null) === ((headIndex + 1) | 0), "sources?.GetCount() == headIndex + 1");
                            this._sources = sources;
                            this._headIndex = headIndex;
                        }
                        return this;
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.UnionIteratorN$$(TSource))().$ctor$3(this._sources, this._headIndex, this._comparer);
                    }
                    /*IEnumerable<TSource>? */ GetEnumerable(/*int*/ index)
                    {
                        return index > this._headIndex ? null : this._sources.GetNode(((this._headIndex - index) | 0)).Item$2;
                    }
                    /*UnionIterator<TSource> */ Union(/*IEnumerable<TSource>*/ next)
                    {
                        if (this._headIndex === ((2147483647/*int.MaxValue*/ - 2) | 0))
                        {
                            return new ($.$sl.System.Linq.Enumerable.UnionIterator2$$(TSource))().$ctor$3(this, next, this._comparer);
                        }
                        return new ($.$sl.System.Linq.Enumerable.UnionIteratorN$$(TSource))().$ctor$3(this._sources.Add(next), ((this._headIndex + 1) | 0), this._comparer);
                    }
                    static $h = 3866631;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.UnionIterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.UnionIteratorN<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_UnionIteratorN$$ = $v))(TSource);
            }
            static /*IEnumerable<TSource> */ Where(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (predicate === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.predicate*/);
                }
                let iterator;
                if ($.$is(source, $.$sl.System.Linq.Enumerable.Iterator$$(TSource), { set $v(v){ iterator = v; } }))
                {
                    return iterator.Where(predicate);
                }
                let sourceList;
                if ($.$sl.System.Linq.Enumerable.IsSizeOptimized && $.$is(source, $.$spc.System.Collections.Generic.IList$$(TSource), { set $v(v){ sourceList = v; } }))
                {
                    return new ($.$sl.System.Linq.Enumerable.SizeOptIListWhereIterator$$(TSource))().$ctor$2(sourceList, predicate);
                }
                let array;
                if ($.$is(source, $.$typeArray(TSource), { set $v(v){ array = v; } }))
                {
                    if (array.length === 0)
                    {
                        return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                    }
                    return new ($.$sl.System.Linq.Enumerable.ArrayWhereIterator$$(TSource))().$ctor$2(array, predicate);
                }
                let list;
                if ($.$is(source, $.$spc.System.Collections.Generic.List$$(TSource), { set $v(v){ list = v; } }))
                {
                    return new ($.$sl.System.Linq.Enumerable.ListWhereIterator$$(TSource))().$ctor$2(list, predicate);
                }
                return new ($.$sl.System.Linq.Enumerable.IEnumerableWhereIterator$$(TSource))().$ctor$2(source, predicate);
            }
            static /*IEnumerable<TSource> */ Where$1(TSource, /*this IEnumerable<TSource>*/ source, /*Func<TSource, int, bool>*/ predicate)
            {
                if (source === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(17/*ExceptionArgument.source*/);
                }
                if (predicate === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.predicate*/);
                }
                if ($.$sl.System.Linq.Enumerable.IsEmptyArray(TSource, source))
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TSource.$type, [  ], null, null);
                }
                return $.$sl.System.Linq.Enumerable.WhereIterator(TSource, source, predicate);
            }
            static /*IEnumerable<TSource> */ WhereIterator(TSource, /*IEnumerable<TSource>*/ source, /*Func<TSource, int, bool>*/ predicate)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*int*/ let index = -1;
                    var $en3 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var element = $en3.System$Collections$Generic$IEnumerator$$$Current;
                        {
                            //checked
                            {
                                index++;
                            }
                            if (predicate.Invoke(element, index))
                            {
                                yield element;
                            }
                        }
                    }
                }.bind(this));
            }
            static $_IEnumerableWhereIterator$$;
            static IEnumerableWhereIterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_IEnumerableWhereIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.IEnumerableWhereIterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.IEnumerableWhereIterator<>", [TSource], ($self) => class IEnumerableWhereIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TSource)
                {
                    /*IEnumerable<TSource>*/ _source = null;
                    /*Func<TSource, bool>*/ _predicate = null;
                    /*IEnumerator<TSource>?*/ _enumerator = null;
                    $ctor$2(/*IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(predicate === null), "predicate is not null");
                            this._source = source;
                            this._predicate = predicate;
                        }
                        return this;
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.IEnumerableWhereIterator$$(TSource))().$ctor$2(this._source, this._predicate);
                    }
                    /*void */ Dispose()
                    {
                        if (!(this._enumerator === null))
                        {
                            this._enumerator.System$IDisposable$Dispose();
                            this._enumerator = null;
                        }
                        super.Dispose();
                    }
                    /*bool */ MoveNext()
                    {
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                this._enumerator = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                                this._state = 2;
                                $switchJumpState1 = 2; /*goto case 2*/
                                continue $switchJumpStart1;
                                case 2:
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._enumerator === null), "_enumerator is not null");
                                while(this._enumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    /*TSource*/ let item = this._enumerator.System$Collections$Generic$IEnumerator$$$Current;
                                    if (this._predicate.Invoke(item))
                                    {
                                        this._current = item;
                                        return true;
                                    }
                                }
                                this.Dispose();
                                break;
                            }
                            break;
                        }
                        return false;
                    }
                    /*IEnumerable<TResult> */ Select(TResult, /*Func<TSource, TResult>*/ selector)
                    {
                        return new ($.$sl.System.Linq.Enumerable.IEnumerableWhereSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._predicate, selector);
                    }
                    /*IEnumerable<TSource> */ Where(/*Func<TSource, bool>*/ predicate)
                    {
                        return new ($.$sl.System.Linq.Enumerable.IEnumerableWhereIterator$$(TSource))().$ctor$2(this._source, $.$sl.System.Linq.Utilities.CombinePredicates(TSource, this._predicate, predicate));
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        if (onlyIfCheap)
                        {
                            return -1;
                        }
                        /*int*/ let count = 0;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (this._predicate.Invoke(item))
                                {
                                    //checked
                                    {
                                        count++;
                                    }
                                }
                            }
                        }
                        return count;
                    }
                    /*TSource[] */ ToArray()
                    {
                        /*SegmentedArrayBuilder<TSource>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TSource>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource))().$ctor$2($.$spc.System.Span$$(TSource).op_Implicit(scratch.$fields));
                        /*Func<TSource, bool>*/ let predicate = this._predicate;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (predicate.Invoke(item))
                                {
                                    builder.Add(item);
                                }
                            }
                        }
                        /*TSource[]*/ let result = builder.ToArray();
                        builder.Dispose();
                        return result;
                    }
                    /*List<TSource> */ ToList()
                    {
                        /*SegmentedArrayBuilder<TSource>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TSource>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource))().$ctor$2($.$spc.System.Span$$(TSource).op_Implicit(scratch.$fields));
                        /*Func<TSource, bool>*/ let predicate = this._predicate;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (predicate.Invoke(item))
                                {
                                    builder.Add(item);
                                }
                            }
                        }
                        /*List<TSource>*/ let result = builder.ToList();
                        builder.Dispose();
                        return result;
                    }
                    /*TSource? */ TryGetFirst(/*out bool*/ found)
                    {
                        /*Func<TSource, bool>*/ let predicate = this._predicate;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (predicate.Invoke(item))
                                {
                                    found.$v = true;
                                    return item;
                                }
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*TSource? */ TryGetLast(/*out bool*/ found)
                    {
                        /*IEnumerator<TSource>*/ let e = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                        try
                        {
                            if (e.System$Collections$IEnumerator$MoveNext())
                            {
                                /*Func<TSource, bool>*/ let predicate = this._predicate;
                                /*TSource?*/ let last = $.$default(TSource);
                                do
                                {
                                    /*TSource*/ let current = e.System$Collections$Generic$IEnumerator$$$Current;
                                    if (predicate.Invoke(current))
                                    {
                                        last = current;
                                        found.$v = true;
                                        while(e.System$Collections$IEnumerator$MoveNext())
                                        {
                                            current = e.System$Collections$Generic$IEnumerator$$$Current;
                                            if (predicate.Invoke(current))
                                            {
                                                last = current;
                                            }
                                        }
                                        return last;
                                    }
                                }
                                while(e.System$Collections$IEnumerator$MoveNext());
                            }
                            found.$v = false;
                            return $.$default(TSource);
                        }
                        finally
                        {
                            e?.System$IDisposable$Dispose();
                        }
                    }
                    /*TSource? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if (index >= 0)
                        {
                            /*Func<TSource, bool>*/ let predicate = this._predicate;
                            var $en5 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var item = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    if (predicate.Invoke(item))
                                    {
                                        if (index === 0)
                                        {
                                            found.$v = true;
                                            return item;
                                        }
                                        index--;
                                    }
                                }
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*bool */ Contains(/*TSource*/ value)
                    {
                        /*Func<TSource, bool>*/ let predicate = this._predicate;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (predicate.Invoke(item) && $.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default.Equals$2(item, value))
                                {
                                    return true;
                                }
                            }
                        }
                        return false;
                    }
                    static $h = 1966087;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.IEnumerableWhereIterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_IEnumerableWhereIterator$$ = $v))(TSource);
            }
            static $_ArrayWhereIterator$$;
            static ArrayWhereIterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_ArrayWhereIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.ArrayWhereIterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.ArrayWhereIterator<>", [TSource], ($self) => class ArrayWhereIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TSource)
                {
                    /*TSource[]*/ _source = null;
                    /*Func<TSource, bool>*/ _predicate = null;
                    $ctor$2(/*TSource[]*/ source, /*Func<TSource, bool>*/ predicate)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null) && source.length > 0, "source is not null && source.Length > 0");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(predicate === null), "predicate is not null");
                            this._source = source;
                            this._predicate = predicate;
                        }
                        return this;
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.ArrayWhereIterator$$(TSource))().$ctor$2(this._source, this._predicate);
                    }
                    /*bool */ MoveNext()
                    {
                        /*int*/ let index = ((this._state - 1) | 0);
                        /*TSource[]*/ let source = this._source;
                        while((index >>> 0) < (source.length >>> 0))
                        {
                            /*TSource*/ let item = $.$spc.System.Array.$ReadT1.call(source, index);
                            index = this._state++;
                            if (this._predicate.Invoke(item))
                            {
                                this._current = item;
                                return true;
                            }
                        }
                        this.Dispose();
                        return false;
                    }
                    /*IEnumerable<TResult> */ Select(TResult, /*Func<TSource, TResult>*/ selector)
                    {
                        return new ($.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._predicate, selector);
                    }
                    /*IEnumerable<TSource> */ Where(/*Func<TSource, bool>*/ predicate)
                    {
                        return new ($.$sl.System.Linq.Enumerable.ArrayWhereIterator$$(TSource))().$ctor$2(this._source, $.$sl.System.Linq.Utilities.CombinePredicates(TSource, this._predicate, predicate));
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereIterator$$(TSource).GetCount$1(onlyIfCheap, $.$spc.System.ReadOnlySpan$$(TSource).op_Implicit(this._source), this._predicate);
                    }
                    static /*int */ GetCount$1(/*bool*/ onlyIfCheap, /*ReadOnlySpan<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
                    {
                        if (onlyIfCheap)
                        {
                            return -1;
                        }
                        /*int*/ let count = 0;
                        var $en4 = source.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var item = $en4.Current.$v;
                            {
                                if (predicate.Invoke(item))
                                {
                                    //checked
                                    {
                                        count++;
                                    }
                                }
                            }
                        }
                        return count;
                    }
                    /*TSource[] */ ToArray()
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereIterator$$(TSource).ToArray$1($.$spc.System.ReadOnlySpan$$(TSource).op_Implicit(this._source), this._predicate);
                    }
                    static /*TSource[] */ ToArray$1(/*ReadOnlySpan<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
                    {
                        /*SegmentedArrayBuilder<TSource>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TSource>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource))().$ctor$2($.$spc.System.Span$$(TSource).op_Implicit(scratch.$fields));
                        var $en4 = source.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var item = $en4.Current.$v;
                            {
                                if (predicate.Invoke(item))
                                {
                                    builder.Add(item);
                                }
                            }
                        }
                        /*TSource[]*/ let result = builder.ToArray();
                        builder.Dispose();
                        return result;
                    }
                    /*List<TSource> */ ToList()
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereIterator$$(TSource).ToList$1($.$spc.System.ReadOnlySpan$$(TSource).op_Implicit(this._source), this._predicate);
                    }
                    static /*List<TSource> */ ToList$1(/*ReadOnlySpan<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
                    {
                        /*SegmentedArrayBuilder<TSource>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TSource>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource))().$ctor$2($.$spc.System.Span$$(TSource).op_Implicit(scratch.$fields));
                        var $en4 = source.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var item = $en4.Current.$v;
                            {
                                if (predicate.Invoke(item))
                                {
                                    builder.Add(item);
                                }
                            }
                        }
                        /*List<TSource>*/ let result = builder.ToList();
                        builder.Dispose();
                        return result;
                    }
                    /*TSource? */ TryGetFirst(/*out bool*/ found)
                    {
                        /*Func<TSource, bool>*/ let predicate = this._predicate;
                        let $i1 = 0;
                        let $arr1 = this._source;
                        while ($i1 < $arr1.length)
                        {
                            let item = $arr1[$i1++];
                            if (predicate.Invoke(item))
                            {
                                found.$v = true;
                                return item;
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*TSource? */ TryGetLast(/*out bool*/ found)
                    {
                        /*TSource[]*/ let source = this._source;
                        /*Func<TSource, bool>*/ let predicate = this._predicate;
                        for(/*int*/ let i = ((source.length - 1) | 0); i >= 0; i--)
                        {
                            if (predicate.Invoke($.$spc.System.Array.$ReadT1.call(source, i)))
                            {
                                found.$v = true;
                                return $.$spc.System.Array.$ReadT1.call(source, i);
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*TSource? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if (index >= 0)
                        {
                            /*Func<TSource, bool>*/ let predicate = this._predicate;
                            let $i1 = 0;
                            let $arr1 = this._source;
                            while ($i1 < $arr1.length)
                            {
                                let item = $arr1[$i1++];
                                if (predicate.Invoke(item))
                                {
                                    if (index === 0)
                                    {
                                        found.$v = true;
                                        return item;
                                    }
                                    index--;
                                }
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*bool */ Contains(/*TSource*/ value)
                    {
                        /*Func<TSource, bool>*/ let predicate = this._predicate;
                        let $i1 = 0;
                        let $arr1 = this._source;
                        while ($i1 < $arr1.length)
                        {
                            let item = $arr1[$i1++];
                            if (predicate.Invoke(item) && $.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default.Equals$2(item, value))
                            {
                                return true;
                            }
                        }
                        return false;
                    }
                    static $h = 720903;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.ArrayWhereIterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ArrayWhereIterator$$ = $v))(TSource);
            }
            static $_ListWhereIterator$$;
            static ListWhereIterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_ListWhereIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.ListWhereIterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.ListWhereIterator<>", [TSource], ($self) => class ListWhereIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TSource)
                {
                    /*List<TSource>*/ _source = null;
                    /*Func<TSource, bool>*/ _predicate = null;
                    /*List<TSource>.Enumerator*/ _enumerator;
                    $ctor$2(/*List<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(predicate === null), "predicate is not null");
                            this._source = source;
                            this._predicate = predicate;
                        }
                        return this;
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.ListWhereIterator$$(TSource))().$ctor$2(this._source, this._predicate);
                    }
                    /*bool */ MoveNext()
                    {
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                this._enumerator = this._source.GetEnumerator();
                                this._state = 2;
                                $switchJumpState1 = 2; /*goto case 2*/
                                continue $switchJumpStart1;
                                case 2:
                                while(this._enumerator.MoveNext())
                                {
                                    /*TSource*/ let item = this._enumerator.Current;
                                    if (this._predicate.Invoke(item))
                                    {
                                        this._current = item;
                                        return true;
                                    }
                                }
                                this.Dispose();
                                break;
                            }
                            break;
                        }
                        return false;
                    }
                    /*IEnumerable<TResult> */ Select(TResult, /*Func<TSource, TResult>*/ selector)
                    {
                        return new ($.$sl.System.Linq.Enumerable.ListWhereSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._predicate, selector);
                    }
                    /*IEnumerable<TSource> */ Where(/*Func<TSource, bool>*/ predicate)
                    {
                        return new ($.$sl.System.Linq.Enumerable.ListWhereIterator$$(TSource))().$ctor$2(this._source, $.$sl.System.Linq.Utilities.CombinePredicates(TSource, this._predicate, predicate));
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereIterator$$(TSource).GetCount$1(onlyIfCheap, $.$spc.System.Span$$(TSource).op_Implicit$2($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, this._source)), this._predicate);
                    }
                    /*TSource[] */ ToArray()
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereIterator$$(TSource).ToArray$1($.$spc.System.Span$$(TSource).op_Implicit$2($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, this._source)), this._predicate);
                    }
                    /*List<TSource> */ ToList()
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereIterator$$(TSource).ToList$1($.$spc.System.Span$$(TSource).op_Implicit$2($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, this._source)), this._predicate);
                    }
                    /*TSource? */ TryGetFirst(/*out bool*/ found)
                    {
                        /*Func<TSource, bool>*/ let predicate = this._predicate;
                        var $en4 = $.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, this._source).GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var item = $en4.Current.$v;
                            {
                                if (predicate.Invoke(item))
                                {
                                    found.$v = true;
                                    return item;
                                }
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*TSource? */ TryGetLast(/*out bool*/ found)
                    {
                        /*ReadOnlySpan<TSource>*/ let source = $.$spc.System.Span$$(TSource).op_Implicit$2($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, this._source));
                        /*Func<TSource, bool>*/ let predicate = this._predicate;
                        for(/*int*/ let i = ((source.Length - 1) | 0); i >= 0; i--)
                        {
                            if (predicate.Invoke(source.get_Item(i).$v))
                            {
                                found.$v = true;
                                return source.get_Item(i).$v;
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*TSource? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if (index >= 0)
                        {
                            /*Func<TSource, bool>*/ let predicate = this._predicate;
                            var $en5 = $.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, this._source).GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var item = $en5.Current.$v;
                                {
                                    if (predicate.Invoke(item))
                                    {
                                        if (index === 0)
                                        {
                                            found.$v = true;
                                            return item;
                                        }
                                        index--;
                                    }
                                }
                            }
                        }
                        found.$v = false;
                        return $.$default(TSource);
                    }
                    /*bool */ Contains(/*TSource*/ value)
                    {
                        /*Func<TSource, bool>*/ let predicate = this._predicate;
                        var $en4 = this._source.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var item = $en4.Current;
                            {
                                if (predicate.Invoke(item) && $.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default.Equals$2(item, value))
                                {
                                    return true;
                                }
                            }
                        }
                        return false;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._enumerator = $.$default($.$spc.System.Collections.Generic.List$$(TSource).Enumerator);
                    }
                    static $h = 2621447;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.ListWhereIterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ListWhereIterator$$ = $v))(TSource);
            }
            static $_ArrayWhereSelectIterator$$$;
            static ArrayWhereSelectIterator$$$(TSource, TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_ArrayWhereSelectIterator$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.ArrayWhereSelectIterator<,>", (TSource, TResult) => $asm.$gt("$sl.System.Linq.Enumerable.ArrayWhereSelectIterator<,>", [TSource, TResult], ($self) => class ArrayWhereSelectIterator$$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*TSource[]*/ _source = null;
                    /*Func<TSource, bool>*/ _predicate = null;
                    /*Func<TSource, TResult>*/ _selector = null;
                    $ctor$2(/*TSource[]*/ source, /*Func<TSource, bool>*/ predicate, /*Func<TSource, TResult>*/ selector)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null) && source.length > 0, "source is not null && source.Length > 0");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(predicate === null), "predicate is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(selector === null), "selector is not null");
                            this._source = source;
                            this._predicate = predicate;
                            this._selector = selector;
                        }
                        return this;
                    }
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._predicate, this._selector);
                    }
                    /*bool */ MoveNext()
                    {
                        /*int*/ let index = ((this._state - 1) | 0);
                        /*TSource[]*/ let source = this._source;
                        while((index >>> 0) < (source.length >>> 0))
                        {
                            /*TSource*/ let item = $.$spc.System.Array.$ReadT1.call(source, index);
                            index = this._state++;
                            if (this._predicate.Invoke(item))
                            {
                                this._current = this._selector.Invoke(item);
                                return true;
                            }
                        }
                        this.Dispose();
                        return false;
                    }
                    /*IEnumerable<TResult2> */ Select(TResult2, /*Func<TResult, TResult2>*/ selector)
                    {
                        return new ($.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult2))().$ctor$2(this._source, this._predicate, $.$sl.System.Linq.Utilities.CombineSelectors(TSource, TResult, TResult2, this._selector, selector));
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult).GetCount$1(onlyIfCheap, $.$spc.System.ReadOnlySpan$$(TSource).op_Implicit(this._source), this._predicate, this._selector);
                    }
                    static /*int */ GetCount$1(/*bool*/ onlyIfCheap, /*ReadOnlySpan<TSource>*/ source, /*Func<TSource, bool>*/ predicate, /*Func<TSource, TResult>*/ selector)
                    {
                        if (onlyIfCheap)
                        {
                            return -1;
                        }
                        /*int*/ let count = 0;
                        var $en4 = source.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var item = $en4.Current.$v;
                            {
                                if (predicate.Invoke(item))
                                {
                                    selector.Invoke(item);
                                    //checked
                                    {
                                        count++;
                                    }
                                }
                            }
                        }
                        return count;
                    }
                    /*TResult[] */ ToArray()
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult).ToArray$1($.$spc.System.ReadOnlySpan$$(TSource).op_Implicit(this._source), this._predicate, this._selector);
                    }
                    static /*TResult[] */ ToArray$1(/*ReadOnlySpan<TSource>*/ source, /*Func<TSource, bool>*/ predicate, /*Func<TSource, TResult>*/ selector)
                    {
                        /*SegmentedArrayBuilder<TResult>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TResult>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult))().$ctor$2($.$spc.System.Span$$(TResult).op_Implicit(scratch.$fields));
                        var $en4 = source.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var item = $en4.Current.$v;
                            {
                                if (predicate.Invoke(item))
                                {
                                    builder.Add(selector.Invoke(item));
                                }
                            }
                        }
                        /*TResult[]*/ let result = builder.ToArray();
                        builder.Dispose();
                        return result;
                    }
                    /*List<TResult> */ ToList()
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult).ToList$1($.$spc.System.ReadOnlySpan$$(TSource).op_Implicit(this._source), this._predicate, this._selector);
                    }
                    static /*List<TResult> */ ToList$1(/*ReadOnlySpan<TSource>*/ source, /*Func<TSource, bool>*/ predicate, /*Func<TSource, TResult>*/ selector)
                    {
                        /*SegmentedArrayBuilder<TResult>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TResult>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult))().$ctor$2($.$spc.System.Span$$(TResult).op_Implicit(scratch.$fields));
                        var $en4 = source.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var item = $en4.Current.$v;
                            {
                                if (predicate.Invoke(item))
                                {
                                    builder.Add(selector.Invoke(item));
                                }
                            }
                        }
                        /*List<TResult>*/ let result = builder.ToList();
                        builder.Dispose();
                        return result;
                    }
                    /*TResult? */ TryGetFirst(/*out bool*/ found)
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult).TryGetFirst$1($.$spc.System.ReadOnlySpan$$(TSource).op_Implicit(this._source), this._predicate, this._selector, found);
                    }
                    static /*TResult? */ TryGetFirst$1(/*ReadOnlySpan<TSource>*/ source, /*Func<TSource, bool>*/ predicate, /*Func<TSource, TResult>*/ selector, /*out bool*/ found)
                    {
                        var $en4 = source.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var item = $en4.Current.$v;
                            {
                                if (predicate.Invoke(item))
                                {
                                    found.$v = true;
                                    return selector.Invoke(item);
                                }
                            }
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult? */ TryGetLast(/*out bool*/ found)
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult).TryGetLast$1($.$spc.System.ReadOnlySpan$$(TSource).op_Implicit(this._source), this._predicate, this._selector, found);
                    }
                    static /*TResult? */ TryGetLast$1(/*ReadOnlySpan<TSource>*/ source, /*Func<TSource, bool>*/ predicate, /*Func<TSource, TResult>*/ selector, /*out bool*/ found)
                    {
                        for(/*int*/ let i = ((source.Length - 1) | 0); i >= 0; i--)
                        {
                            if (predicate.Invoke(source.get_Item(i).$v))
                            {
                                found.$v = true;
                                return selector.Invoke(source.get_Item(i).$v);
                            }
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult).TryGetElementAt$1($.$spc.System.ReadOnlySpan$$(TSource).op_Implicit(this._source), this._predicate, this._selector, index, found);
                    }
                    static /*TResult? */ TryGetElementAt$1(/*ReadOnlySpan<TSource>*/ source, /*Func<TSource, bool>*/ predicate, /*Func<TSource, TResult>*/ selector, /*int*/ index, /*out bool*/ found)
                    {
                        if (index >= 0)
                        {
                            var $en5 = source.GetEnumerator();
                            while ($en5.MoveNext())
                            {
                                var item = $en5.Current.$v;
                                {
                                    if (predicate.Invoke(item))
                                    {
                                        if (index === 0)
                                        {
                                            found.$v = true;
                                            return selector.Invoke(item);
                                        }
                                        index--;
                                    }
                                }
                            }
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*bool */ Contains(/*TResult*/ value)
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult).Contains$1($.$spc.System.ReadOnlySpan$$(TSource).op_Implicit(this._source), this._predicate, this._selector, value);
                    }
                    static /*bool */ Contains$1(/*ReadOnlySpan<TSource>*/ source, /*Func<TSource, bool>*/ predicate, /*Func<TSource, TResult>*/ selector, /*TResult*/ value)
                    {
                        var $en4 = source.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var item = $en4.Current.$v;
                            {
                                if (predicate.Invoke(item) && $.$spc.System.Collections.Generic.EqualityComparer$$(TResult).Default.Equals$2(selector.Invoke(item), value))
                                {
                                    return true;
                                }
                            }
                        }
                        return false;
                    }
                    static $h = 786439;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.ArrayWhereSelectIterator<${TSource?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ArrayWhereSelectIterator$$$ = $v))(TSource, TResult);
            }
            static $_ListWhereSelectIterator$$$;
            static ListWhereSelectIterator$$$(TSource, TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_ListWhereSelectIterator$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.ListWhereSelectIterator<,>", (TSource, TResult) => $asm.$gt("$sl.System.Linq.Enumerable.ListWhereSelectIterator<,>", [TSource, TResult], ($self) => class ListWhereSelectIterator$$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*List<TSource>*/ _source = null;
                    /*Func<TSource, bool>*/ _predicate = null;
                    /*Func<TSource, TResult>*/ _selector = null;
                    /*List<TSource>.Enumerator*/ _enumerator;
                    $ctor$2(/*List<TSource>*/ source, /*Func<TSource, bool>*/ predicate, /*Func<TSource, TResult>*/ selector)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(predicate === null), "predicate is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(selector === null), "selector is not null");
                            this._source = source;
                            this._predicate = predicate;
                            this._selector = selector;
                        }
                        return this;
                    }
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.ListWhereSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._predicate, this._selector);
                    }
                    /*bool */ MoveNext()
                    {
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                this._enumerator = this._source.GetEnumerator();
                                this._state = 2;
                                $switchJumpState1 = 2; /*goto case 2*/
                                continue $switchJumpStart1;
                                case 2:
                                while(this._enumerator.MoveNext())
                                {
                                    /*TSource*/ let item = this._enumerator.Current;
                                    if (this._predicate.Invoke(item))
                                    {
                                        this._current = this._selector.Invoke(item);
                                        return true;
                                    }
                                }
                                this.Dispose();
                                break;
                            }
                            break;
                        }
                        return false;
                    }
                    /*IEnumerable<TResult2> */ Select(TResult2, /*Func<TResult, TResult2>*/ selector)
                    {
                        return new ($.$sl.System.Linq.Enumerable.ListWhereSelectIterator$$$(TSource, TResult2))().$ctor$2(this._source, this._predicate, $.$sl.System.Linq.Utilities.CombineSelectors(TSource, TResult, TResult2, this._selector, selector));
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult).GetCount$1(onlyIfCheap, $.$spc.System.Span$$(TSource).op_Implicit$2($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, this._source)), this._predicate, this._selector);
                    }
                    /*TResult[] */ ToArray()
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult).ToArray$1($.$spc.System.Span$$(TSource).op_Implicit$2($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, this._source)), this._predicate, this._selector);
                    }
                    /*List<TResult> */ ToList()
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult).ToList$1($.$spc.System.Span$$(TSource).op_Implicit$2($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, this._source)), this._predicate, this._selector);
                    }
                    /*TResult? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult).TryGetElementAt$1($.$spc.System.Span$$(TSource).op_Implicit$2($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, this._source)), this._predicate, this._selector, index, found);
                    }
                    /*TResult? */ TryGetFirst(/*out bool*/ found)
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult).TryGetFirst$1($.$spc.System.Span$$(TSource).op_Implicit$2($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, this._source)), this._predicate, this._selector, found);
                    }
                    /*TResult? */ TryGetLast(/*out bool*/ found)
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult).TryGetLast$1($.$spc.System.Span$$(TSource).op_Implicit$2($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, this._source)), this._predicate, this._selector, found);
                    }
                    /*bool */ Contains(/*TResult*/ value)
                    {
                        return $.$sl.System.Linq.Enumerable.ArrayWhereSelectIterator$$$(TSource, TResult).Contains$1($.$spc.System.Span$$(TSource).op_Implicit$2($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(TSource, this._source)), this._predicate, this._selector, value);
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._enumerator = $.$default($.$spc.System.Collections.Generic.List$$(TSource).Enumerator);
                    }
                    static $h = 2686983;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.ListWhereSelectIterator<${TSource?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_ListWhereSelectIterator$$$ = $v))(TSource, TResult);
            }
            static $_IEnumerableWhereSelectIterator$$$;
            static IEnumerableWhereSelectIterator$$$(TSource, TResult)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_IEnumerableWhereSelectIterator$$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.IEnumerableWhereSelectIterator<,>", (TSource, TResult) => $asm.$gt("$sl.System.Linq.Enumerable.IEnumerableWhereSelectIterator<,>", [TSource, TResult], ($self) => class IEnumerableWhereSelectIterator$$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TResult)
                {
                    /*IEnumerable<TSource>*/ _source = null;
                    /*Func<TSource, bool>*/ _predicate = null;
                    /*Func<TSource, TResult>*/ _selector = null;
                    /*IEnumerator<TSource>?*/ _enumerator = null;
                    $ctor$2(/*IEnumerable<TSource>*/ source, /*Func<TSource, bool>*/ predicate, /*Func<TSource, TResult>*/ selector)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(predicate === null), "predicate is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(selector === null), "selector is not null");
                            this._source = source;
                            this._predicate = predicate;
                            this._selector = selector;
                        }
                        return this;
                    }
                    /*Iterator<TResult> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.IEnumerableWhereSelectIterator$$$(TSource, TResult))().$ctor$2(this._source, this._predicate, this._selector);
                    }
                    /*void */ Dispose()
                    {
                        if (!(this._enumerator === null))
                        {
                            this._enumerator.System$IDisposable$Dispose();
                            this._enumerator = null;
                        }
                        super.Dispose();
                    }
                    /*bool */ MoveNext()
                    {
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                this._enumerator = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                                this._state = 2;
                                $switchJumpState1 = 2; /*goto case 2*/
                                continue $switchJumpStart1;
                                case 2:
                                $.$spc.System.Diagnostics.Debug.Assert$1(!(this._enumerator === null), "_enumerator is not null");
                                while(this._enumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    /*TSource*/ let item = this._enumerator.System$Collections$Generic$IEnumerator$$$Current;
                                    if (this._predicate.Invoke(item))
                                    {
                                        this._current = this._selector.Invoke(item);
                                        return true;
                                    }
                                }
                                this.Dispose();
                                break;
                            }
                            break;
                        }
                        return false;
                    }
                    /*IEnumerable<TResult2> */ Select(TResult2, /*Func<TResult, TResult2>*/ selector)
                    {
                        return new ($.$sl.System.Linq.Enumerable.IEnumerableWhereSelectIterator$$$(TSource, TResult2))().$ctor$2(this._source, this._predicate, $.$sl.System.Linq.Utilities.CombineSelectors(TSource, TResult, TResult2, this._selector, selector));
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        if (onlyIfCheap)
                        {
                            return -1;
                        }
                        /*int*/ let count = 0;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (this._predicate.Invoke(item))
                                {
                                    this._selector.Invoke(item);
                                    //checked
                                    {
                                        count++;
                                    }
                                }
                            }
                        }
                        return count;
                    }
                    /*TResult[] */ ToArray()
                    {
                        /*SegmentedArrayBuilder<TResult>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TResult>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult))().$ctor$2($.$spc.System.Span$$(TResult).op_Implicit(scratch.$fields));
                        /*Func<TSource, bool>*/ let predicate = this._predicate;
                        /*Func<TSource, TResult>*/ let selector = this._selector;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (predicate.Invoke(item))
                                {
                                    builder.Add(selector.Invoke(item));
                                }
                            }
                        }
                        /*TResult[]*/ let result = builder.ToArray();
                        builder.Dispose();
                        return result;
                    }
                    /*List<TResult> */ ToList()
                    {
                        /*SegmentedArrayBuilder<TResult>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TResult>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TResult))().$ctor$2($.$spc.System.Span$$(TResult).op_Implicit(scratch.$fields));
                        /*Func<TSource, bool>*/ let predicate = this._predicate;
                        /*Func<TSource, TResult>*/ let selector = this._selector;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (predicate.Invoke(item))
                                {
                                    builder.Add(selector.Invoke(item));
                                }
                            }
                        }
                        /*List<TResult>*/ let result = builder.ToList();
                        builder.Dispose();
                        return result;
                    }
                    /*TResult? */ TryGetFirst(/*out bool*/ found)
                    {
                        /*Func<TSource, bool>*/ let predicate = this._predicate;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (predicate.Invoke(item))
                                {
                                    found.$v = true;
                                    return this._selector.Invoke(item);
                                }
                            }
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*TResult? */ TryGetLast(/*out bool*/ found)
                    {
                        /*IEnumerator<TSource>*/ let e = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                        try
                        {
                            if (e.System$Collections$IEnumerator$MoveNext())
                            {
                                /*Func<TSource, bool>*/ let predicate = this._predicate;
                                /*TSource?*/ let last = $.$default(TSource);
                                do
                                {
                                    /*TSource*/ let current = e.System$Collections$Generic$IEnumerator$$$Current;
                                    if (predicate.Invoke(current))
                                    {
                                        last = current;
                                        found.$v = true;
                                        while(e.System$Collections$IEnumerator$MoveNext())
                                        {
                                            current = e.System$Collections$Generic$IEnumerator$$$Current;
                                            if (predicate.Invoke(current))
                                            {
                                                last = current;
                                            }
                                        }
                                        return this._selector.Invoke(last);
                                    }
                                }
                                while(e.System$Collections$IEnumerator$MoveNext());
                            }
                            found.$v = false;
                            return $.$default(TResult);
                        }
                        finally
                        {
                            e?.System$IDisposable$Dispose();
                        }
                    }
                    /*TResult? */ TryGetElementAt(/*int*/ index, /*out bool*/ found)
                    {
                        if (index >= 0)
                        {
                            /*Func<TSource, bool>*/ let predicate = this._predicate;
                            var $en5 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                            while ($en5.System$Collections$IEnumerator$MoveNext())
                            {
                                var item = $en5.System$Collections$Generic$IEnumerator$$$Current;
                                {
                                    if (predicate.Invoke(item))
                                    {
                                        if (index === 0)
                                        {
                                            found.$v = true;
                                            return this._selector.Invoke(item);
                                        }
                                        index--;
                                    }
                                }
                            }
                        }
                        found.$v = false;
                        return $.$default(TResult);
                    }
                    /*bool */ Contains(/*TResult*/ value)
                    {
                        /*Func<TSource, bool>*/ let predicate = this._predicate;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (predicate.Invoke(item) && $.$spc.System.Collections.Generic.EqualityComparer$$(TResult).Default.Equals$2(this._selector.Invoke(item), value))
                                {
                                    return true;
                                }
                            }
                        }
                        return false;
                    }
                    static $h = 2031623;
                    static $g = 2;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":2,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TResult); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TResult), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TResult), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.IEnumerableWhereSelectIterator<${TSource?.$fullName},${TResult?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_IEnumerableWhereSelectIterator$$$ = $v))(TSource, TResult);
            }
            static $_SizeOptIListWhereIterator$$;
            static SizeOptIListWhereIterator$$(TSource)
            {
                let $cls = $.$sl.System.Linq.Enumerable;
                return ($cls.$_SizeOptIListWhereIterator$$ ??= $asm.$ncls("$sl.System.Linq.Enumerable.SizeOptIListWhereIterator<>", (TSource) => $asm.$gt("$sl.System.Linq.Enumerable.SizeOptIListWhereIterator<>", [TSource], ($self) => class SizeOptIListWhereIterator$$ extends $.$sl.System.Linq.Enumerable.Iterator$$(TSource)
                {
                    /*IList<TSource>*/ _source = null;
                    /*Func<TSource, bool>*/ _predicate = null;
                    /*IEnumerator<TSource>?*/ _enumerator = null;
                    $ctor$2(/*IList<TSource>*/ source, /*Func<TSource, bool>*/ predicate)
                    {
                        super.$ctor$1();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(predicate === null), "predicate is not null");
                            this._source = source;
                            this._predicate = predicate;
                        }
                        return this;
                    }
                    /*Iterator<TSource> */ Clone()
                    {
                        return new ($.$sl.System.Linq.Enumerable.SizeOptIListWhereIterator$$(TSource))().$ctor$2(this._source, this._predicate);
                    }
                    /*bool */ MoveNext()
                    {
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? this._state)
                            {
                                case 1:
                                this._enumerator = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSource]);
                                this._state = 2;
                                $switchJumpState1 = 2; /*goto case 2*/
                                continue $switchJumpStart1;
                                case 2:
                                while(this._enumerator.System$Collections$IEnumerator$MoveNext())
                                {
                                    /*TSource*/ let item = this._enumerator.System$Collections$Generic$IEnumerator$$$Current;
                                    if (this._predicate.Invoke(item))
                                    {
                                        this._current = item;
                                        return true;
                                    }
                                }
                                this.Dispose();
                                break;
                            }
                            break;
                        }
                        return false;
                    }
                    /*IEnumerable<TSource> */ Where(/*Func<TSource, bool>*/ predicate)
                    {
                        return new ($.$sl.System.Linq.Enumerable.SizeOptIListWhereIterator$$(TSource))().$ctor$2(this._source, $.$sl.System.Linq.Utilities.CombinePredicates(TSource, this._predicate, predicate));
                    }
                    /*TSource[] */ ToArray()
                    {
                        /*SegmentedArrayBuilder<TSource>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TSource>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource))().$ctor$2($.$spc.System.Span$$(TSource).op_Implicit(scratch.$fields));
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (this._predicate.Invoke(item))
                                {
                                    builder.Add(item);
                                }
                            }
                        }
                        /*TSource[]*/ let result = builder.ToArray();
                        builder.Dispose();
                        return result;
                    }
                    /*List<TSource> */ ToList()
                    {
                        /*SegmentedArrayBuilder<TSource>.ScratchBuffer*/ let scratch = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource).ScratchBuffer)();
                        /*SegmentedArrayBuilder<TSource>*/ let builder = new ($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(TSource))().$ctor$2($.$spc.System.Span$$(TSource).op_Implicit(scratch.$fields));
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (this._predicate.Invoke(item))
                                {
                                    builder.Add(item);
                                }
                            }
                        }
                        /*List<TSource>*/ let result = builder.ToList();
                        builder.Dispose();
                        return result;
                    }
                    /*int */ GetCount(/*bool*/ onlyIfCheap)
                    {
                        if (onlyIfCheap)
                        {
                            return -1;
                        }
                        /*int*/ let count = 0;
                        var $en4 = this._source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$Generic$IEnumerator$$$Current;
                            {
                                if (this._predicate.Invoke(item))
                                {
                                    //checked
                                    {
                                        count++;
                                    }
                                }
                            }
                        }
                        return count;
                    }
                    static $h = 3604487;
                    static $g = 1;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"r":1,"d":393223,"h":this.$h}; }
                    static get $b() { return $.$sl.System.Linq.Enumerable.Iterator$$(TSource); }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerable$$(TSource), $.$spc.System.Collections.IEnumerable, $.$spc.System.Collections.Generic.IEnumerator$$(TSource), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Linq.Enumerable.SizeOptIListWhereIterator<${TSource?.$fullName}>`; }
                }), $cls, ($v) => $cls.$_SizeOptIListWhereIterator$$ = $v))(TSource);
            }
            static /*IEnumerable<TResult> */ Zip(TFirst, TSecond, TResult, /*this IEnumerable<TFirst>*/ first, /*IEnumerable<TSecond>*/ second, /*Func<TFirst, TSecond, TResult>*/ resultSelector)
            {
                if (first === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(4/*ExceptionArgument.first*/);
                }
                if (second === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(14/*ExceptionArgument.second*/);
                }
                if (resultSelector === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(13/*ExceptionArgument.resultSelector*/);
                }
                return $.$sl.System.Linq.Enumerable.ZipIterator$1(TFirst, TSecond, TResult, first, second, resultSelector);
            }
            static /*IEnumerable<(TFirst First, TSecond Second)> */ Zip$1(TFirst, TSecond, /*this IEnumerable<TFirst>*/ first, /*IEnumerable<TSecond>*/ second)
            {
                if (first === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(4/*ExceptionArgument.first*/);
                }
                if (second === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(14/*ExceptionArgument.second*/);
                }
                return $.$sl.System.Linq.Enumerable.ZipIterator(TFirst, TSecond, first, second);
            }
            static /*IEnumerable<(TFirst First, TSecond Second, TThird Third)> */ Zip$2(TFirst, TSecond, TThird, /*this IEnumerable<TFirst>*/ first, /*IEnumerable<TSecond>*/ second, /*IEnumerable<TThird>*/ third)
            {
                if (first === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(4/*ExceptionArgument.first*/);
                }
                if (second === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(14/*ExceptionArgument.second*/);
                }
                if (third === null)
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(18/*ExceptionArgument.third*/);
                }
                return $.$sl.System.Linq.Enumerable.ZipIterator$2(TFirst, TSecond, TThird, first, second, third);
            }
            static /*IEnumerable<(TFirst First, TSecond Second)> */ ZipIterator(TFirst, TSecond, /*IEnumerable<TFirst>*/ first, /*IEnumerable<TSecond>*/ second)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*IEnumerator<TFirst>*/ let e1 = first.System$Collections$Generic$IEnumerable$$$GetEnumerator([TFirst]);
                    try
                    {
                        /*IEnumerator<TSecond>*/ let e2 = second.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSecond]);
                        try
                        {
                            while(e1.System$Collections$IEnumerator$MoveNext() && e2.System$Collections$IEnumerator$MoveNext())
                            {
                                yield new ($.$spc.System.ValueTuple$$$(TFirst, TSecond))().$ctor$2(e1.System$Collections$Generic$IEnumerator$$$Current, e2.System$Collections$Generic$IEnumerator$$$Current);
                            }
                        }
                        finally
                        {
                            e2?.System$IDisposable$Dispose();
                        }
                    }
                    finally
                    {
                        e1?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            static /*IEnumerable<TResult> */ ZipIterator$1(TFirst, TSecond, TResult, /*IEnumerable<TFirst>*/ first, /*IEnumerable<TSecond>*/ second, /*Func<TFirst, TSecond, TResult>*/ resultSelector)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*IEnumerator<TFirst>*/ let e1 = first.System$Collections$Generic$IEnumerable$$$GetEnumerator([TFirst]);
                    try
                    {
                        /*IEnumerator<TSecond>*/ let e2 = second.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSecond]);
                        try
                        {
                            while(e1.System$Collections$IEnumerator$MoveNext() && e2.System$Collections$IEnumerator$MoveNext())
                            {
                                yield resultSelector.Invoke(e1.System$Collections$Generic$IEnumerator$$$Current, e2.System$Collections$Generic$IEnumerator$$$Current);
                            }
                        }
                        finally
                        {
                            e2?.System$IDisposable$Dispose();
                        }
                    }
                    finally
                    {
                        e1?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            static /*IEnumerable<(TFirst First, TSecond Second, TThird Third)> */ ZipIterator$2(TFirst, TSecond, TThird, /*IEnumerable<TFirst>*/ first, /*IEnumerable<TSecond>*/ second, /*IEnumerable<TThird>*/ third)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*IEnumerator<TFirst>*/ let e1 = first.System$Collections$Generic$IEnumerable$$$GetEnumerator([TFirst]);
                    try
                    {
                        /*IEnumerator<TSecond>*/ let e2 = second.System$Collections$Generic$IEnumerable$$$GetEnumerator([TSecond]);
                        try
                        {
                            /*IEnumerator<TThird>*/ let e3 = third.System$Collections$Generic$IEnumerable$$$GetEnumerator([TThird]);
                            try
                            {
                                while(e1.System$Collections$IEnumerator$MoveNext() && e2.System$Collections$IEnumerator$MoveNext() && e3.System$Collections$IEnumerator$MoveNext())
                                {
                                    yield new ($.$spc.System.ValueTuple$$$$(TFirst, TSecond, TThird))().$ctor$2(e1.System$Collections$Generic$IEnumerator$$$Current, e2.System$Collections$Generic$IEnumerator$$$Current, e3.System$Collections$Generic$IEnumerator$$$Current);
                                }
                            }
                            finally
                            {
                                e3?.System$IDisposable$Dispose();
                            }
                        }
                        finally
                        {
                            e2?.System$IDisposable$Dispose();
                        }
                    }
                    finally
                    {
                        e1?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            //Static Initializer
            static $sinit()
            {
                {
                    /*bool*/ let isEnabled;
                    this.IsSizeOptimized = $.$spc.System.AppContext.TryGetSwitch("System.Linq.Enumerable.IsSizeOptimized", $.$ref(() => isEnabled, ($v) => isEnabled = $v, $.$spc.System.Boolean)) ? isEnabled : false;
                }
            }
            static $h = 393223;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":393223}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Linq.Enumerable`; }
        });
        
        $asm.$cls("$sl.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$sl.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Linq", $.$sl.System.SR.$type.Assembly);
                    $.$sl.System.SR.s_resourceManager = temp;
                }
                return $.$sl.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sl.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sl.System.SR.resourceCulture = value;
            }
            static /*string */ get EmptyEnumerable()
            {
                return "Enumeration yielded no results";
            }
            static /*string */ get MoreThanOneElement()
            {
                return "Sequence contains more than one element";
            }
            static /*string */ get MoreThanOneMatch()
            {
                return "Sequence contains more than one matching element";
            }
            static /*string */ get NoElements()
            {
                return "Sequence contains no elements";
            }
            static /*string */ get NoMatch()
            {
                return "Sequence contains no matching element";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sl.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$sl.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sl.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sl.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sl.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sl.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sl.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 4849671;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":4849671}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sl.System.Linq.SystemCore_EnumerableDebugView<>", (T) => $asm.$gt("$sl.System.Linq.SystemCore_EnumerableDebugView<>", [T], ($self) => class SystemCore_EnumerableDebugView$$ extends $.$spc.System.Object
        {
            $ctor$1(/*IEnumerable<T>*/ enumerable)
            {
                super.$ctor();
                {
                    if (enumerable === null)
                    {
                        $.$sl.System.Linq.ThrowHelper.ThrowArgumentNullException(3/*ExceptionArgument.enumerable*/);
                    }
                    this._enumerable = enumerable;
                }
                return this;
            }
            /*T[] */ get Items()
            {
                /*T[]*/ let array = $.$sl.System.Linq.Enumerable.ToArray(T, this._enumerable);
                if (array.length === 0)
                {
                    throw new $.$sl.System.Linq.SystemCore_EnumerableDebugViewEmptyException().$ctor$5();
                }
                return array;
            }
            /*IEnumerable<T>*/ _enumerable = null;
            static $h = 4456455;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Linq.SystemCore_EnumerableDebugView<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sl.System.Linq.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                throw new $.$spc.System.ArgumentNullException().$ctor$16($.$sl.System.Linq.ThrowHelper.GetArgumentString(argument));
            }
            static /*void */ ThrowArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16($.$sl.System.Linq.ThrowHelper.GetArgumentString(argument));
            }
            static /*void */ ThrowMoreThanOneElementException()
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sl.System.SR.MoreThanOneElement);
            }
            static /*void */ ThrowMoreThanOneMatchException()
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sl.System.SR.MoreThanOneMatch);
            }
            static /*void */ ThrowNoElementsException()
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sl.System.SR.NoElements);
            }
            static /*void */ ThrowNoMatchException()
            {
                throw new $.$spc.System.InvalidOperationException().$ctor$10($.$sl.System.SR.NoMatch);
            }
            static /*void */ ThrowNotSupportedException()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            static /*bool */ ThrowNotSupportedException_Boolean()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            static /*void */ ThrowOverflowException()
            {
                throw new $.$spc.System.OverflowException().$ctor$13();
            }
            static /*string */ GetArgumentString(/*ExceptionArgument*/ argument)
            {
                switch(argument)
                {
                    case 0/*ExceptionArgument.collectionSelector*/:
                    return "collectionSelector";
                    case 1/*ExceptionArgument.count*/:
                    return "count";
                    case 2/*ExceptionArgument.elementSelector*/:
                    return "elementSelector";
                    case 3/*ExceptionArgument.enumerable*/:
                    return "enumerable";
                    case 4/*ExceptionArgument.first*/:
                    return "first";
                    case 5/*ExceptionArgument.func*/:
                    return "func";
                    case 6/*ExceptionArgument.index*/:
                    return "index";
                    case 7/*ExceptionArgument.inner*/:
                    return "inner";
                    case 8/*ExceptionArgument.innerKeySelector*/:
                    return "innerKeySelector";
                    case 9/*ExceptionArgument.keySelector*/:
                    return "keySelector";
                    case 10/*ExceptionArgument.outer*/:
                    return "outer";
                    case 11/*ExceptionArgument.outerKeySelector*/:
                    return "outerKeySelector";
                    case 12/*ExceptionArgument.predicate*/:
                    return "predicate";
                    case 13/*ExceptionArgument.resultSelector*/:
                    return "resultSelector";
                    case 14/*ExceptionArgument.second*/:
                    return "second";
                    case 15/*ExceptionArgument.seedSelector*/:
                    return "seedSelector";
                    case 16/*ExceptionArgument.selector*/:
                    return "selector";
                    case 17/*ExceptionArgument.source*/:
                    return "source";
                    case 18/*ExceptionArgument.third*/:
                    return "third";
                    case 19/*ExceptionArgument.size*/:
                    return "size";
                    case 20/*ExceptionArgument.other*/:
                    return "other";
                    case 21/*ExceptionArgument.start*/:
                    return "start";
                    case 22/*ExceptionArgument.step*/:
                    return "step";
                    case 23/*ExceptionArgument.endInclusive*/:
                    return "endInclusive";
                    default:
                    $.$spc.System.Diagnostics.Debug.Fail("The ExceptionArgument value is not defined.");
                    return $.$spc.System.String.Empty;
                }
            }
            static $h = 4718599;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":4718599}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Linq.ThrowHelper`; }
        });
        
        $asm.$cls("$sl.System.Linq.Utilities", ($self) => class Utilities
        {
            static /*bool */ AreEqualityComparersEqual(TSource, /*IEqualityComparer<TSource>?*/ left, /*IEqualityComparer<TSource>?*/ right)
            {
                if (left === right)
                {
                    return true;
                }
                /*var*/ let defaultComparer = $.$spc.System.Collections.Generic.EqualityComparer$$(TSource).Default;
                if (left === null)
                {
                    return right === defaultComparer || $.$spc.System.Object.Equals.call(right, defaultComparer);
                }
                if (right === null)
                {
                    return left === defaultComparer || $.$spc.System.Object.Equals.call(left, defaultComparer);
                }
                return $.$spc.System.Object.Equals.call(left, right);
            }
            static /*Func<TSource, bool> */ CombinePredicates(TSource, /*Func<TSource, bool>*/ predicate1, /*Func<TSource, bool>*/ predicate2)
            {
                return new ($.$spc.System.Func$$$(TSource, $.$spc.System.Boolean))().$ctor(this,  (/*x*/ x) =>
                {
                    return predicate1.Invoke(x) && predicate2.Invoke(x);
                });
            }
            static /*Func<TSource, TResult> */ CombineSelectors(TSource, TMiddle, TResult, /*Func<TSource, TMiddle>*/ selector1, /*Func<TMiddle, TResult>*/ selector2)
            {
                return new ($.$spc.System.Func$$$(TSource, TResult))().$ctor(this,  (/*x*/ x) =>
                {
                    return selector2.Invoke(selector1.Invoke(x));
                });
            }
            static $h = 4784135;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":4784135}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Linq.Utilities`; }
        });
        
        $asm.$cls("$sl.System.Linq.SingleLinkedNode<>", (TSource) => $asm.$gt("$sl.System.Linq.SingleLinkedNode<>", [TSource], ($self) => class SingleLinkedNode$$ extends $.$spc.System.Object
        {
            $ctor$1(/*TSource*/ item)
            {
                super.$ctor();
                {
                    this.Item$2 = item;
                }
                return this;
            }
            $ctor$2(/*SingleLinkedNode<TSource>*/ linked, /*TSource*/ item)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(linked === null), "linked is not null");
                    this.Linked = linked;
                    this.Item$2 = item;
                }
                return this;
            }
            /*TSource*/ Item$2 = $.$default(TSource);
            /*SingleLinkedNode<TSource>?*/ Linked = null;
            /*SingleLinkedNode<TSource> */ Add(/*TSource*/ item)
            {
                return new ($.$sl.System.Linq.SingleLinkedNode$$(TSource))().$ctor$2(this, item);
            }
            /*int */ GetCount()
            {
                /*int*/ let count = 0;
                for(/*SingleLinkedNode<TSource>?*/ let node = this; !(node === null); node = node.Linked)
                {
                    count++;
                }
                return count;
            }
            /*SingleLinkedNode<TSource> */ GetNode(/*int*/ index)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(index >= 0 && index < this.GetCount(), "index >= 0 && index < GetCount()");
                /*SingleLinkedNode<TSource>*/ let node = this;
                for(; index > 0; index--)
                {
                    node = node.Linked;
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(node === null), "node is not null");
                }
                return node;
            }
            /*TSource[] */ ToArray(/*int*/ count)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(count === this.GetCount(), "count == GetCount()");
                /*TSource[]*/ let array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TSource), null, [count], null);
                this.FillReversed($.$spc.System.Span$$(TSource).op_Implicit(array));
                return array;
            }
            /*void */ Fill(/*Span<TSource>*/ span)
            {
                /*int*/ let index = 0;
                for(/*SingleLinkedNode<TSource>?*/ let node = this; !(node === null); node = node.Linked)
                {
                    span.get_Item(index).$v = node.Item$2;
                    index++;
                }
            }
            /*void */ FillReversed(/*Span<TSource>*/ span)
            {
                /*int*/ let index = span.Length;
                for(/*SingleLinkedNode<TSource>?*/ let node = this; !(node === null); node = node.Linked)
                {
                    --index;
                    span.get_Item(index).$v = node.Item$2;
                }
            }
            static $h = 4390919;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Linq.SingleLinkedNode<${TSource?.$fullName}>`; }
        }));
        
        $asm.$cls("$sl.System.Linq.SystemLinq_GroupingDebugView<,>", (TKey, TElement) => $asm.$gt("$sl.System.Linq.SystemLinq_GroupingDebugView<,>", [TKey, TElement], ($self) => class SystemLinq_GroupingDebugView$$$ extends $.$spc.System.Object
        {
            /*Grouping<TKey, TElement>*/ _grouping = null;
            $ctor$1(/*Grouping<TKey, TElement>*/ grouping)
            {
                super.$ctor();
                {
                    this._grouping = grouping;
                }
                return this;
            }
            /*TKey */ get Key()
            {
                return this._grouping.Key;
            }
            /*TElement[]*/ Values$ = null;
            /*TElement[] */ get Values()
            {
                return this.Values$ ??= $.$sl.System.Linq.Enumerable.ToArray(TElement, this._grouping);
            }
            static $h = 4587527;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":2,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Linq.SystemLinq_GroupingDebugView<${TKey?.$fullName},${TElement?.$fullName}>`; }
        }));
        
        $asm.$cls("$sl.System.Linq.SystemLinq_LookupDebugView<,>", (TKey, TElement) => $asm.$gt("$sl.System.Linq.SystemLinq_LookupDebugView<,>", [TKey, TElement], ($self) => class SystemLinq_LookupDebugView$$$ extends $.$spc.System.Object
        {
            /*ILookup<TKey, TElement>*/ _lookup = null;
            $ctor$1(/*ILookup<TKey, TElement>*/ lookup)
            {
                super.$ctor();
                {
                    this._lookup = lookup;
                }
                return this;
            }
            /*IGrouping<TKey, TElement>[]*/ Groupings$ = null;
            /*IGrouping<TKey, TElement>[] */ get Groupings()
            {
                return this.Groupings$ ??= $.$sl.System.Linq.Enumerable.ToArray($.$sl.System.Linq.IGrouping$$$(TKey, TElement), this._lookup);
            }
            static $h = 4653063;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":2,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Linq.SystemLinq_LookupDebugView<${TKey?.$fullName},${TElement?.$fullName}>`; }
        }));
        
        $asm.$cls("$sl.System.Linq.Lookup<,>", (TKey, TElement) => $asm.$gt("$sl.System.Linq.Lookup<,>", [TKey, TElement], ($self) => class Lookup$$$ extends $.$spc.System.Object
        {
            /*IEqualityComparer<TKey>*/ _comparer = null;
            /*Grouping<TKey, TElement>[]*/ _groupings = null;
            /*Grouping<TKey, TElement>?*/ _lastGrouping = null;
            /*int*/ _count = 0;
            static /*Lookup<TKey, TElement> */ Create(TSource, /*IEnumerable<TSource>*/ source, /*Func<TSource, TKey>*/ keySelector, /*Func<TSource, TElement>*/ elementSelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                $.$spc.System.Diagnostics.Debug.Assert$1(!(keySelector === null), "keySelector is not null");
                $.$spc.System.Diagnostics.Debug.Assert$1(!(elementSelector === null), "elementSelector is not null");
                /*var*/ let lookup = new ($.$sl.System.Linq.CollectionLookup$$$(TKey, TElement))().$ctor$2(comparer);
                var $en2 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        lookup.GetGrouping(keySelector.Invoke(item), true).Add(elementSelector.Invoke(item));
                    }
                }
                return lookup;
            }
            static /*Lookup<TKey, TElement> */ Create$1(/*IEnumerable<TElement>*/ source, /*Func<TElement, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(source === null), "source is not null");
                $.$spc.System.Diagnostics.Debug.Assert$1(!(keySelector === null), "keySelector is not null");
                /*var*/ let lookup = new ($.$sl.System.Linq.CollectionLookup$$$(TKey, TElement))().$ctor$2(comparer);
                var $en2 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        lookup.GetGrouping(keySelector.Invoke(item), true).Add(item);
                    }
                }
                return lookup;
            }
            static /*Lookup<TKey, TElement> */ CreateForJoin(/*IEnumerable<TElement>*/ source, /*Func<TElement, TKey>*/ keySelector, /*IEqualityComparer<TKey>?*/ comparer)
            {
                /*var*/ let lookup = new ($.$sl.System.Linq.CollectionLookup$$$(TKey, TElement))().$ctor$2(comparer);
                var $en2 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        /*TKey*/ let key = keySelector.Invoke(item);
                        if (!(key === null))
                        {
                            lookup.GetGrouping(key, true).Add(item);
                        }
                    }
                }
                return lookup;
            }
            $ctor$1(/*IEqualityComparer<TKey>?*/ comparer)
            {
                super.$ctor();
                {
                    this._comparer = comparer ?? $.$spc.System.Collections.Generic.EqualityComparer$$(TKey).Default;
                    this._groupings = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sl.System.Linq.Grouping$$$(TKey, TElement)), null, [7], null);
                }
                return this;
            }
            /*int */ get Count()
            {
                return this._count;
            }
            /*IEnumerable<TElement>*/ get_Item(/*TKey*/ key)
            {
                return this.GetGrouping(key, false) ?? $.$sl.System.Linq.Enumerable.Empty(TElement);
        ;
            }
            /*bool */ Contains(/*TKey*/ key)
            {
                return !(this.GetGrouping(key, false) === null);
            }
            /*IEnumerator<IGrouping<TKey, TElement>> */ GetEnumerator()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)))().$ctor$1(function*()
                {
                    /*Grouping<TKey, TElement>?*/ let g = this._lastGrouping;
                    if (!(g === null))
                    {
                        do
                        {
                            g = g._next;
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(g === null), "g is not null");
                            yield g;
                        }
                        while(g !== this._lastGrouping);
                    }
                }.bind(this)).GetEnumerator();
            }
            /*List<TResult> */ ToList(TResult, /*Func<TKey, IEnumerable<TElement>, TResult>*/ resultSelector)
            {
                /*List<TResult>*/ let list = new ($.$spc.System.Collections.Generic.List$$(TResult))().$ctor$2(this._count);
                /*Grouping<TKey, TElement>?*/ let g = this._lastGrouping;
                if (!(g === null))
                {
                    /*Span<TResult>*/ let span = $.$sl.System.Linq.Enumerable.SetCountAndGetSpan(TResult, list, this._count);
                    /*int*/ let index = 0;
                    do
                    {
                        g = g._next;
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(g === null), "g is not null");
                        g.Trim();
                        span.get_Item(index).$v = resultSelector.Invoke(g._key, g._elements);
                        ++index;
                    }
                    while(g !== this._lastGrouping);
                    $.$spc.System.Diagnostics.Debug.Assert$1(index === this._count, "All list elements were not initialized.");
                }
                return list;
            }
            /*IEnumerable<TResult> */ ApplyResultSelector(TResult, /*Func<TKey, IEnumerable<TElement>, TResult>*/ resultSelector)
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$spc.System.Object))().$ctor$1(function*()
                {
                    /*Grouping<TKey, TElement>?*/ let g = this._lastGrouping;
                    if (!(g === null))
                    {
                        do
                        {
                            g = g._next;
                            $.$spc.System.Diagnostics.Debug.Assert$1(!(g === null), "g is not null");
                            g.Trim();
                            yield resultSelector.Invoke(g._key, g._elements);
                        }
                        while(g !== this._lastGrouping);
                    }
                }.bind(this));
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            /*int */ InternalGetHashCode(/*TKey*/ key)
            {
                return (key === null) ? 0 : this._comparer.System$Collections$Generic$IEqualityComparer$$$GetHashCode(key, [TKey]) & 2147483647;
            }
            /*Grouping<TKey, TElement>? */ GetGrouping(/*TKey*/ key, /*bool*/ create)
            {
                /*int*/ let hashCode = this.InternalGetHashCode(key);
                for(/*Grouping<TKey, TElement>?*/ let g = this._groupings[(hashCode >>> 0) % this._groupings.length]; !(g === null); g = g._hashNext)
                {
                    if (g._hashCode === hashCode && this._comparer.System$Collections$Generic$IEqualityComparer$$$Equals(g._key, key, [TKey]))
                    {
                        return g;
                    }
                }
                if (create)
                {
                    if (this._count === this._groupings.length)
                    {
                        this.Resize();
                    }
                    /*int*/ let index = hashCode % this._groupings.length;
                    /*Grouping<TKey, TElement>*/ let g = new ($.$sl.System.Linq.Grouping$$$(TKey, TElement))().$ctor$1(key, hashCode);
                    g._hashNext = $.$spc.System.Array.$ReadT1.call(this._groupings, index);
                    $.$spc.System.Array.$WriteT1.call(this._groupings, g, index);
                    if (this._lastGrouping === null)
                    {
                        g._next = g;
                    }
                    else 
                    {
                        g._next = this._lastGrouping._next;
                        this._lastGrouping._next = g;
                    }
                    this._lastGrouping = g;
                    this._count++;
                    return g;
                }
                return null;
            }
            /*void */ Resize()
            {
                /*int*/ let newSize = $.$checked(($.$checked(this._count * 2, 1)) + 1, 1);
                /*Grouping<TKey, TElement>[]*/ let newGroupings = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$sl.System.Linq.Grouping$$$(TKey, TElement)), null, [newSize], null);
                /*Grouping<TKey, TElement>*/ let g = this._lastGrouping;
                do
                {
                    g = g._next;
                    /*int*/ let index = g._hashCode % newSize;
                    g._hashNext = $.$spc.System.Array.$ReadT1.call(newGroupings, index);
                    $.$spc.System.Array.$WriteT1.call(newGroupings, g, index);
                }
                while(g !== this._lastGrouping);
                this._groupings = newGroupings;
            }
            /*TResult[] */ ToArray(TResult, /*Func<TKey, IEnumerable<TElement>, TResult>*/ resultSelector)
            {
                /*TResult[]*/ let array = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TResult), null, [this._count], null);
                /*int*/ let index = 0;
                /*Grouping<TKey, TElement>?*/ let g = this._lastGrouping;
                if (!(g === null))
                {
                    do
                    {
                        g = g._next;
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(g === null), "g is not null");
                        g.Trim();
                        $.$spc.System.Array.$WriteT1.call(array, resultSelector.Invoke(g._key, g._elements), index);
                        ++index;
                    }
                    while(g !== this._lastGrouping);
                }
                return array;
            }
            //Generated interface implemetation for System.Linq.ILookup<TKey, TElement>.Count.get
            get System$Linq$ILookup$$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Linq.ILookup<TKey, TElement>.this[TKey].get
            System$Linq$ILookup$$$$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Linq.ILookup<TKey, TElement>.Contains(TKey)
            System$Linq$ILookup$$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Linq.IGrouping<TKey, TElement>>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 4259847;
            static $g = 2;
            static $f = 0b1010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":2,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sl.System.Linq.ILookup$$$(TKey, TElement), $.$spc.System.Collections.Generic.IEnumerable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Linq.Lookup<${TKey?.$fullName},${TElement?.$fullName}>`; }
        }));
        
        $asm.$cls("$sl.System.Linq.PartialArrayEnumerator<>", (T) => $asm.$gt("$sl.System.Linq.PartialArrayEnumerator<>", [T], ($self) => class PartialArrayEnumerator$$ extends $.$spc.System.Object
        {
            /*T[]*/ _array = null;
            /*int*/ _count = 0;
            /*int*/ _index = -1;
            $ctor$1(/*T[]*/ array, /*int*/ count)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(array === null), "array is not null");
                    this._array = array;
                    this._count = count;
                }
                return this;
            }
            /*bool */ MoveNext()
            {
                if (((this._index + 1) | 0) < this._count)
                {
                    this._index++;
                    return true;
                }
                return false;
            }
            /*T */ get Current()
            {
                return $.$spc.System.Array.$ReadT1.call(this._array, this._index);
            }
            /*object? */ get System$Collections$IEnumerator$Current()
            {
                return $.$box(this.Current, T);
            }
            /*void */ Dispose()
            {
            }
            /*void */ Reset()
            {
                return this._index = -1;
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerator<T>.Current.get
            get System$Collections$Generic$IEnumerator$$$Current()
            {
                return this.Current;
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
            System$Collections$IEnumerator$MoveNext()
            {
                return this.MoveNext(...arguments);
            }
            //Generated interface implemetation for System.Collections.IEnumerator.Reset()
            System$Collections$IEnumerator$Reset()
            {
                return this.Reset(...arguments);
            }
            static $h = 4325383;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.IEnumerator$$(T), $.$spc.System.IDisposable, $.$spc.System.Collections.IEnumerator ]; }
            static get $fullName() { return `System.Linq.PartialArrayEnumerator<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sl.System.Linq.EmptyLookup<,>", (TKey, TElement) => $asm.$gt("$sl.System.Linq.EmptyLookup<,>", [TKey, TElement], ($self) => class EmptyLookup$$$ extends $.$spc.System.Object
        {
            /*EmptyLookup<TKey, TElement>*/ static Instance = null;
            /*IEnumerable<TElement>*/ get_Item(/*TKey*/ key)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(TElement.$type, [  ], null, null);
        ;
            }
            /*int */ get Count()
            {
                return 0;
            }
            /*IEnumerator<IGrouping<TKey, TElement>> */ GetEnumerator()
            {
                return $.$sl.System.Linq.Enumerable.Empty($.$sl.System.Linq.IGrouping$$$(TKey, TElement)).System$Collections$Generic$IEnumerable$$$GetEnumerator([$.$sl.System.Linq.IGrouping$$$(TKey, TElement)]);
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            /*bool */ Contains(/*TKey*/ key)
            {
                return false;
            }
            /*bool */ Contains$1(/*IGrouping<TKey, TElement>*/ item)
            {
                return false;
            }
            /*void */ CopyTo(/*IGrouping<TKey, TElement>[]*/ array, /*int*/ arrayIndex)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(array, "array");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, arrayIndex, "arrayIndex");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, arrayIndex, array.length, "arrayIndex");
            }
            /*bool */ get IsReadOnly()
            {
                return true;
            }
            /*void */ Add(/*IGrouping<TKey, TElement>*/ item)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ Clear()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*bool */ Remove(/*IGrouping<TKey, TElement>*/ item)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            //Generated interface implemetation for System.Linq.ILookup<TKey, TElement>.Count.get
            get System$Linq$ILookup$$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Linq.ILookup<TKey, TElement>.this[TKey].get
            System$Linq$ILookup$$$$get_Item()
            {
                return this.get_Item(...arguments);
            }
            //Generated interface implemetation for System.Linq.ILookup<TKey, TElement>.Contains(TKey)
            System$Linq$ILookup$$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Linq.IGrouping<TKey, TElement>>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Linq.IGrouping<TKey, TElement>>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Linq.IGrouping<TKey, TElement>>.Add(System.Linq.IGrouping<TKey, TElement>)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Linq.IGrouping<TKey, TElement>>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Linq.IGrouping<TKey, TElement>>.Contains(System.Linq.IGrouping<TKey, TElement>)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains$1(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Linq.IGrouping<TKey, TElement>>.CopyTo(System.Linq.IGrouping<TKey, TElement>[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Linq.IGrouping<TKey, TElement>>.Remove(System.Linq.IGrouping<TKey, TElement>)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Linq.IGrouping<TKey, TElement>>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Linq.IGrouping<TKey, TElement>>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Instance = new ($.$sl.System.Linq.EmptyLookup$$$(TKey, TElement))().$ctor$1();
                }
            }
            static $h = 327687;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":2,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sl.System.Linq.ILookup$$$(TKey, TElement), $.$spc.System.Collections.Generic.ICollection$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)), $.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)), $.$spc.System.Collections.Generic.IEnumerable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Linq.EmptyLookup<${TKey?.$fullName},${TElement?.$fullName}>`; }
        }));
        
        $asm.$cls("$sl.System.Linq.Grouping<,>", (TKey, TElement) => $asm.$gt("$sl.System.Linq.Grouping<,>", [TKey, TElement], ($self) => class Grouping$$$ extends $.$spc.System.Object
        {
            /*TKey*/ _key = $.$default(TKey);
            /*int*/ _hashCode = 0;
            /*TElement[]*/ _elements = null;
            /*int*/ _count = 0;
            /*Grouping<TKey, TElement>?*/ _hashNext = null;
            /*Grouping<TKey, TElement>?*/ _next = null;
            $ctor$1(/*TKey*/ key, /*int*/ hashCode)
            {
                super.$ctor();
                {
                    this._key = key;
                    this._hashCode = hashCode;
                    this._elements = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(TElement), null, [1], null);
                }
                return this;
            }
            /*void */ Add(/*TElement*/ element)
            {
                if (this._elements.length === this._count)
                {
                    $.$spc.System.Array.Resize(TElement, $.$ref(() => this._elements, ($v) => this._elements = $v, $.$typeArray(TElement)), $.$checked(this._count * 2, 1));
                }
                $.$spc.System.Array.$WriteT1.call(this._elements, element, this._count);
                this._count++;
            }
            /*void */ Trim()
            {
                if (this._elements.length !== this._count)
                {
                    $.$spc.System.Array.Resize(TElement, $.$ref(() => this._elements, ($v) => this._elements = $v, $.$typeArray(TElement)), this._count);
                }
            }
            /*IEnumerator<TElement> */ GetEnumerator()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this._count > 0, "A grouping should only have been created if an element was being added to it.");
                return new ($.$sl.System.Linq.PartialArrayEnumerator$$(TElement))().$ctor$1(this._elements, this._count);
            }
            /*IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            /*TKey */ get Key()
            {
                return this._key;
            }
            /*int */ get System$Collections$Generic$ICollection$$$Count()
            {
                return this._count;
            }
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return true;
            }
            /*void */ System$Collections$Generic$ICollection$$$Add(/*TElement*/ item)
            {
                return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
            }
            /*void */ System$Collections$Generic$ICollection$$$Clear()
            {
                return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
            }
            /*bool */ System$Collections$Generic$ICollection$$$Contains(/*TElement*/ item)
            {
                return $.$spc.System.Array.IndexOf$5(TElement, this._elements, item, 0, this._count) >= 0;
            }
            /*void */ System$Collections$Generic$ICollection$$$CopyTo(/*TElement[]*/ array, /*int*/ arrayIndex)
            {
                return $.$spc.System.Array.Copy$1(this._elements, 0, array, arrayIndex, this._count);
            }
            /*bool */ System$Collections$Generic$ICollection$$$Remove(/*TElement*/ item)
            {
                return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException_Boolean();
            }
            /*int */ System$Collections$Generic$IList$$$IndexOf(/*TElement*/ item)
            {
                return $.$spc.System.Array.IndexOf$5(TElement, this._elements, item, 0, this._count);
            }
            /*void */ System$Collections$Generic$IList$$$Insert(/*int*/ index, /*TElement*/ item)
            {
                return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
            }
            /*void */ System$Collections$Generic$IList$$$RemoveAt(/*int*/ index)
            {
                return $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
            }
            /*TElement*/ System$Collections$Generic$IList$$$get_Item(/*int*/ index)
            {
                if ((index >>> 0) >= (this._count >>> 0))
                {
                    $.$sl.System.Linq.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.index*/);
                }
                return $.$spc.System.Array.$ReadT1.call(this._elements, index);
            }
            /*void*/ System$Collections$Generic$IList$$$set_Item(/*int*/ index, /*TElement*/ value)
            {
                $.$sl.System.Linq.ThrowHelper.ThrowNotSupportedException();
            }
            //Generated interface implemetation for System.Linq.IGrouping<TKey, TElement>.Key.get
            get System$Linq$IGrouping$$$$Key()
            {
                return this.Key;
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<TElement>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 3997703;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"r":2,"h":this.$h}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sl.System.Linq.IGrouping$$$(TKey, TElement), $.$spc.System.Collections.Generic.IList$$(TElement), $.$spc.System.Collections.Generic.ICollection$$(TElement), $.$spc.System.Collections.Generic.IEnumerable$$(TElement), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Linq.Grouping<${TKey?.$fullName},${TElement?.$fullName}>`; }
        }));
        
        $asm.$str("$sl.System.Collections.Generic.SegmentedArrayBuilder<>", (T) => $asm.$gt("$sl.System.Collections.Generic.SegmentedArrayBuilder<>", [T], ($self) => class SegmentedArrayBuilder$$ extends $.$spc.System.ValueType
        {
            /*int*/ static ScratchBufferSize = 8;
            /*int*/ static MinimumRentSize = 16;
            /*Arrays*/  get _segments() { return this.$getField(0, $.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(T).Arrays); }
            /*Arrays*/  set _segments(value) { this.$setField(0, $.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(T).Arrays, value); }
            /*Span<T>*/  get _firstSegment() { return this.$getField(27, 8); }
            /*Span<T>*/  set _firstSegment(value) { this.$setField(27, 8, value); }
            /*Span<T>*/  get _currentSegment() { return this.$getField(35, 8); }
            /*Span<T>*/  set _currentSegment(value) { this.$setField(35, 8, value); }
            /*int*/  get _segmentsCount() { return this.$getField(43, 4); }
            /*int*/  set _segmentsCount(value) { this.$setField(43, 4, value); }
            /*int*/  get _countInFinishedSegments() { return this.$getField(47, 4); }
            /*int*/  set _countInFinishedSegments(value) { this.$setField(47, 4, value); }
            /*int*/  get _countInCurrentSegment() { return this.$getField(51, 4); }
            /*int*/  set _countInCurrentSegment(value) { this.$setField(51, 4, value); }
            $ctor$2(/*Span<T>*/ scratchBuffer)
            {
                super.$ctor$1();
                {
                    this._currentSegment = this._firstSegment = scratchBuffer;
                }
                return this;
            }
            /*void */ Dispose()
            {
                /*int*/ let segmentsCount = this._segmentsCount;
                if (segmentsCount !== 0)
                {
                    this.ReturnArrays(segmentsCount);
                }
            }
            /*void */ ReturnArrays(/*int*/ segmentsCount)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(segmentsCount > 0, "segmentsCount > 0");
                /*ReadOnlySpan<T[]>*/ let segments = $.$spc.System.ReadOnlySpan$$($.$typeArray(T)).op_Implicit(this._segments.$fields);
                //if (RuntimeHelpers.IsReferenceOrContainsReferences<T>()) { ... }
                //else 
                {
                    for(/*int*/ let i = 0; i < segments.Length; i++)
                    {
                        /*T[]*/ let segment = segments.get_Item(i).$v;
                        if (segment === null)
                        {
                            break;
                        }
                        $.$spc.System.Buffers.ArrayPool$$(T).Shared.Return(segment, false);
                    }
                }
            }
            /*int */ get Count()
            {
                return $.$checked(this._countInFinishedSegments + this._countInCurrentSegment, 1);
            }
            /*void */ Add(/*T*/ item)
            {
                /*Span<T>*/ let currentSegment = this._currentSegment;
                /*int*/ let countInCurrentSegment = this._countInCurrentSegment;
                if ((countInCurrentSegment >>> 0) < (currentSegment.Length >>> 0))
                {
                    currentSegment.get_Item(countInCurrentSegment).$v = item;
                    this._countInCurrentSegment++;
                }
                else 
                {
                    this.AddSlow(item);
                }
            }
            /*void */ AddSlow(/*T*/ item)
            {
                this.Expand(16);
                this._currentSegment.get_Item(0).$v = item;
                this._countInCurrentSegment = 1;
            }
            /*void */ AddRange(/*IEnumerable<T>*/ source)
            {
                let collection;
                if ($.$is(source, $.$spc.System.Collections.Generic.ICollection$$(T), { set $v(v){ collection = v; } }))
                {
                    /*int*/ let collectionCount = collection.System$Collections$Generic$ICollection$$$Count;
                    if (collectionCount === 0)
                    {
                        return;
                    }
                    /*ReadOnlySpan<T>*/ let sourceSpan;
                    if ($.$sl.System.Linq.Enumerable.TryGetSpan(T, source, $.$ref(() => sourceSpan, ($v) => sourceSpan = $v, $.$spc.System.ReadOnlySpan$$(T))))
                    {
                        /*int*/ let availableSpaceInCurrentSpan = ((this._currentSegment.Length - this._countInCurrentSegment) | 0);
                        /*ReadOnlySpan<T>*/ let sourceSlice = sourceSpan.Slice$1(0, $.$spc.System.Math.Min$4(availableSpaceInCurrentSpan, sourceSpan.Length));
                        sourceSlice.CopyTo(this._currentSegment.Slice(this._countInCurrentSegment));
                        this._countInCurrentSegment += sourceSlice.Length;
                        sourceSlice = sourceSpan.Slice(sourceSlice.Length);
                        if (!sourceSlice.IsEmpty)
                        {
                            this.Expand(sourceSlice.Length);
                            sourceSlice.CopyTo(this._currentSegment);
                            this._countInCurrentSegment = sourceSlice.Length;
                        }
                        return;
                    }
                    /*bool*/ let currentSegmentIsScratchBufferWithRemainingSpace = this._segmentsCount === 0 && this._countInCurrentSegment < this._currentSegment.Length;
                    if (!currentSegmentIsScratchBufferWithRemainingSpace)
                    {
                        /*int*/ let remainingSpaceInCurrentSegment = ((this._currentSegment.Length - this._countInCurrentSegment) | 0);
                        if (remainingSpaceInCurrentSegment === 0)
                        {
                            this.Expand(collectionCount);
                            collection.System$Collections$Generic$ICollection$$$CopyTo(this._segments.$fields[((this._segmentsCount - 1) | 0)], 0, [T]);
                            this._countInCurrentSegment = collectionCount;
                            return;
                        }
                        if (collectionCount <= remainingSpaceInCurrentSegment)
                        {
                            collection.System$Collections$Generic$ICollection$$$CopyTo(this._segments.$fields[((this._segmentsCount - 1) | 0)], this._countInCurrentSegment, [T]);
                            this._countInCurrentSegment += collectionCount;
                            return;
                        }
                    }
                }
                this.AddNonICollectionRangeInlined(source);
            }
            /*void */ AddNonICollectionRange(/*IEnumerable<T>*/ source)
            {
                return this.AddNonICollectionRangeInlined(source);
            }
            /*void */ AddNonICollectionRangeInlined(/*IEnumerable<T>*/ source)
            {
                /*Span<T>*/ let currentSegment = this._currentSegment;
                /*int*/ let countInCurrentSegment = this._countInCurrentSegment;
                var $en2 = source.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var item = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        if ((countInCurrentSegment >>> 0) < (currentSegment.Length >>> 0))
                        {
                            currentSegment.get_Item(countInCurrentSegment).$v = item;
                            countInCurrentSegment++;
                        }
                        else 
                        {
                            this.Expand(16);
                            currentSegment = this._currentSegment;
                            currentSegment.get_Item(0).$v = item;
                            countInCurrentSegment = 1;
                        }
                    }
                }
                this._countInCurrentSegment = countInCurrentSegment;
            }
            /*T[] */ ToArray()
            {
                /*T[]*/ let result;
                /*int*/ let count = this.Count;
                if (count !== 0)
                {
                    result = $.$spc.System.GC.AllocateUninitializedArray(T, count, false);
                    this.ToSpanInlined($.$spc.System.Span$$(T).op_Implicit(result));
                }
                else 
                {
                    result = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(T.$type, [  ], null, null);
                }
                return result;
            }
            /*List<T> */ ToList()
            {
                /*List<T>*/ let result;
                /*int*/ let count = this.Count;
                if (count !== 0)
                {
                    result = new ($.$spc.System.Collections.Generic.List$$(T))().$ctor$2(count);
                    $.$spc.System.Runtime.InteropServices.CollectionsMarshal.SetCount(T, result, count);
                    this.ToSpanInlined($.$spc.System.Runtime.InteropServices.CollectionsMarshal.AsSpan(T, result));
                }
                else 
                {
                    result = (() =>
                    {
                        let $t1 = new ($.$spc.System.Collections.Generic.List$$(T))().$ctor$1();
                        return $t1;
                    })();
                }
                return result;
            }
            /*T[] */ ToArray$1(/*int*/ additionalLength)
            {
                /*T[]*/ let result;
                /*int*/ let count = $.$checked(this.Count + additionalLength, 1);
                if (count !== 0)
                {
                    result = $.$spc.System.GC.AllocateUninitializedArray(T, count, false);
                    this.ToSpanInlined($.$spc.System.Span$$(T).op_Implicit(result));
                }
                else 
                {
                    result = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray(T.$type, [  ], null, null);
                }
                return result;
            }
            /*void */ ToSpan(/*Span<T>*/ destination)
            {
                return this.ToSpanInlined(destination);
            }
            /*void */ ToSpanInlined(/*Span<T>*/ destination)
            {
                /*int*/ let segmentsCount = this._segmentsCount;
                if (segmentsCount !== 0)
                {
                    /*ReadOnlySpan<T>*/ let firstSegment = $.$spc.System.Span$$(T).op_Implicit$2(this._firstSegment);
                    firstSegment.CopyTo(destination);
                    destination = destination.Slice(firstSegment.Length);
                    segmentsCount--;
                    if (segmentsCount !== 0)
                    {
                        var $en4 = ($.$spc.System.ReadOnlySpan$$($.$typeArray(T)).op_Implicit(this._segments.$fields)).Slice$1(0, segmentsCount).GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var arr = $en4.Current.$v;
                            {
                                /*ReadOnlySpan<T>*/ let segment = $.$spc.System.ReadOnlySpan$$(T).op_Implicit(arr);
                                segment.CopyTo(destination);
                                destination = destination.Slice(segment.Length);
                            }
                        }
                    }
                }
                this._currentSegment.Slice$1(0, this._countInCurrentSegment).CopyTo(destination);
            }
            /*void */ Expand(/*int*/ minimumRequired)
            {
                if (minimumRequired < 16/*MinimumRentSize*/)
                {
                    minimumRequired = 16/*MinimumRentSize*/;
                }
                /*int*/ let currentSegmentLength = this._currentSegment.Length;
                //checked
                {
                    this._countInFinishedSegments += currentSegmentLength;
                }
                if (this._countInFinishedSegments > $.$spc.System.Array.MaxLength)
                {
                    throw new $.$spc.System.OutOfMemoryException().$ctor$9();
                }
                /*int*/ let newSegmentLength = $.$cast($.$spc.System.Math.Min$5($.$spc.System.Math.Max$5(BigInt(minimumRequired), BigInt(currentSegmentLength) * 2n), BigInt($.$spc.System.Array.MaxLength)), $.$spc.System.Int32);
                this._currentSegment = $.$spc.System.Span$$(T).op_Implicit(this._segments.$fields[this._segmentsCount] = $.$spc.System.Buffers.ArrayPool$$(T).Shared.Rent(newSegmentLength));
                this._segmentsCount++;
            }
            static $_Arrays;
            static get Arrays()
            {
                let $cls = $.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(T);
                return $cls.$_Arrays ??= $asm.$nstr("$sl.System.Collections.Generic.SegmentedArrayBuilder$$.Arrays", ($self) => class Arrays extends $.$spc.System.ValueType
                {
                    /*T[]*/  get _values() { return this.$getField(0, 4); }
                    /*T[]*/  set _values(value) { this.$setField(0, 4, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        //InlineArray(27)
                        copy.$fields = [...this.$fields];
                        $.$spc.System.Array.CopyMetadata(copy.$fields, this.$fields)
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //InlineArray(T[], 27)
                        for (let $i = 26; $i >= 0; $i--)
                        {
                            this.$setField($i, 1, null);
                        }
                        $.$spc.System.Array.AddMetadata(this.$fields, $.$typeOf($.$typeArray(T)), null, null)
                    }
                    static $h = 131079;
                    static $z = 108;
                    static $f = 0b1000010000001011000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":$.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(T).$h,"h":this.$h}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Collections.Generic.SegmentedArrayBuilder<${T?.$fullName}>.Arrays`; }
                }, $cls, ($v) => $cls.$_Arrays = $v);
            }
            static $_ScratchBuffer;
            static get ScratchBuffer()
            {
                let $cls = $.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(T);
                return $cls.$_ScratchBuffer ??= $asm.$nstr("$sl.System.Collections.Generic.SegmentedArrayBuilder$$.ScratchBuffer", ($self) => class ScratchBuffer extends $.$spc.System.ValueType
                {
                    /*T*/  get _item() { return this.$getField(0, 4); }
                    /*T*/  set _item(value) { this.$setField(0, 4, value); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        //InlineArray(8)
                        copy.$fields = [...this.$fields];
                        $.$spc.System.Array.CopyMetadata(copy.$fields, this.$fields)
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //InlineArray(T, 8)
                        for (let $i = 7; $i >= 0; $i--)
                        {
                            this.$setField($i, 1, $.$default(T));
                        }
                        $.$spc.System.Array.AddMetadata(this.$fields, $.$typeOf(T), null, null)
                    }
                    static $h = 196615;
                    static $z = 32;
                    static $f = 0b1000010000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"d":$.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(T).$h,"h":this.$h}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Collections.Generic.SegmentedArrayBuilder<${T?.$fullName}>.ScratchBuffer`; }
                }, $cls, ($v) => $cls.$_ScratchBuffer = $v);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                //InlineArray(27)
                copy.$fields = [...this.$fields];
                $.$spc.System.Array.CopyMetadata(copy.$fields, this.$fields)
                copy._firstSegment = this._firstSegment.Clone();
                copy._currentSegment = this._currentSegment.Clone();
                copy._segmentsCount = this._segmentsCount;
                copy._countInFinishedSegments = this._countInFinishedSegments;
                copy._countInCurrentSegment = this._countInCurrentSegment;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._segments = $.$default($.$sl.System.Collections.Generic.SegmentedArrayBuilder$$(T).Arrays);
                this._firstSegment = $.$default($.$spc.System.Span$$(T));
                this._currentSegment = $.$default($.$spc.System.Span$$(T));
                this._segmentsCount = 0;
                this._countInFinishedSegments = 0;
                this._countInCurrentSegment = 0;
            }
            static $h = 65543;
            static $g = 1;
            static $z = 55;
            static $f = 0b1011000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"r":1,"h":this.$h}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Collections.Generic.SegmentedArrayBuilder<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$sl.System.Linq.ExceptionArgument", ($self) => class ExceptionArgument extends $.$spc.System.Enum
        {
            static collectionSelector = 0;
            static count = 1;
            static elementSelector = 2;
            static enumerable = 3;
            static first = 4;
            static func = 5;
            static index = 6;
            static inner = 7;
            static innerKeySelector = 8;
            static keySelector = 9;
            static outer = 10;
            static outerKeySelector = 11;
            static predicate = 12;
            static resultSelector = 13;
            static second = 14;
            static seedSelector = 15;
            static selector = 16;
            static source = 17;
            static third = 18;
            static size = 19;
            static other = 20;
            static start = 21;
            static step = 22;
            static endInclusive = 23;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "collectionSelector": 0n,
                    "count": 1n,
                    "elementSelector": 2n,
                    "enumerable": 3n,
                    "first": 4n,
                    "func": 5n,
                    "index": 6n,
                    "inner": 7n,
                    "innerKeySelector": 8n,
                    "keySelector": 9n,
                    "outer": 10n,
                    "outerKeySelector": 11n,
                    "predicate": 12n,
                    "resultSelector": 13n,
                    "second": 14n,
                    "seedSelector": 15n,
                    "selector": 16n,
                    "source": 17n,
                    "third": 18n,
                    "size": 19n,
                    "other": 20n,
                    "start": 21n,
                    "step": 22n,
                    "endInclusive": 23n
                };
            }
            static $h = 3932167;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"h":3932167}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Linq.ExceptionArgument`; }
        });
        
        $asm.$cls("$sl.System.Linq.CollectionLookup<,>", (TKey, TElement) => $asm.$gt("$sl.System.Linq.CollectionLookup<,>", [TKey, TElement], ($self) => class CollectionLookup$$$ extends $.$sl.System.Linq.Lookup$$$(TKey, TElement)
        {
            $ctor$2(/*IEqualityComparer<TKey>?*/ comparer)
            {
                super.$ctor$1(comparer);
                {
                }
                return this;
            }
            /*void */ System$Collections$Generic$ICollection$$$CopyTo(/*IGrouping<TKey, TElement>[]*/ array, /*int*/ arrayIndex)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(array, "array");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, arrayIndex, "arrayIndex");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, arrayIndex, array.length, "arrayIndex");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, ((array.length - arrayIndex) | 0), this.Count, "arrayIndex");
                /*Grouping<TKey, TElement>?*/ let g = this._lastGrouping;
                if (!(g === null))
                {
                    do
                    {
                        g = g._next;
                        $.$spc.System.Diagnostics.Debug.Assert$1(!(g === null), "g is not null");
                        $.$spc.System.Array.$WriteT1.call(array, g, arrayIndex);
                        ++arrayIndex;
                    }
                    while(g !== this._lastGrouping);
                }
            }
            /*bool */ System$Collections$Generic$ICollection$$$Contains(/*IGrouping<TKey, TElement>*/ item)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(item, "item");
                let grouping;
                return this.GetGrouping(item.System$Linq$IGrouping$$$$Key, false) !== null && ((grouping = this.GetGrouping(item.System$Linq$IGrouping$$$$Key, false), grouping != null && true)) && grouping === item;
            }
            /*bool */ get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return true;
            }
            /*void */ System$Collections$Generic$ICollection$$$Add(/*IGrouping<TKey, TElement>*/ item)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*void */ System$Collections$Generic$ICollection$$$Clear()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            /*bool */ System$Collections$Generic$ICollection$$$Remove(/*IGrouping<TKey, TElement>*/ item)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Linq.IGrouping<TKey, TElement>>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Linq.IGrouping<TKey, TElement>>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            static $h = 262151;
            static $g = 2;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"r":2,"h":this.$h}; }
            static get $b() { return $.$sl.System.Linq.Lookup$$$(TKey, TElement); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sl.System.Linq.ILookup$$$(TKey, TElement), $.$spc.System.Collections.Generic.ICollection$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)), $.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)), $.$spc.System.Collections.Generic.IEnumerable$$($.$sl.System.Linq.IGrouping$$$(TKey, TElement)), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Linq.CollectionLookup<${TKey?.$fullName},${TElement?.$fullName}>`; }
        }));
        
        $asm.$cls("$sl.System.Linq.SystemCore_EnumerableDebugViewEmptyException", ($self) => class SystemCore_EnumerableDebugViewEmptyException extends $.$spc.System.Exception
        {
            /*string */ get Empty()
            {
                return $.$sl.System.SR.EmptyEnumerable;
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 4521991;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47185921,"h":4521991}; }
            static get $b() { return $.$spc.System.Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Linq.SystemCore_EnumerableDebugViewEmptyException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Runtime.InteropServices"))