
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Memory", 
    {"h":40455,"f":"System.Memory","v":"1.0.35.0","a":[{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Memory","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Memory","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]},{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sm.System.Buffers.IBufferWriter<>", (T) => $asm.$gt("$sm.System.Buffers.IBufferWriter<>", [T], ($self) => class IBufferWriter$$
        {
            static $h = 368135;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":65537,"p":[{"n":"count","p":655361}],"n":"Advance","o":"System$Buffers$IBufferWriter$$$Advance","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777473},{"r":$.$$.System.Memory$$(T).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","o":"System$Buffers$IBufferWriter$$$GetMemory","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777473},{"r":$.$$.System.Span$$(T).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","o":"System$Buffers$IBufferWriter$$$GetSpan","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777473}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $fullName() { return `System.Buffers.IBufferWriter<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sm.System.Buffers.ReadOnlySequenceSegment<>", (T) => $asm.$gt("$sm.System.Buffers.ReadOnlySequenceSegment<>", [T], ($self) => class ReadOnlySequenceSegment$$ extends $.$$.System.Object
        {
            /*ReadOnlyMemory<T>*/ Memory;
            /*ReadOnlySequenceSegment<T>?*/ Next = null;
            /*long*/ RunningIndex = 0n;
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Memory = $.$default($.$$.System.ReadOnlyMemory$$(T));
            }
            static $h = 892423;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.ReadOnlyMemory$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":83886084},"n":"Memory","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2097153},{"p":this.$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":83886084},"n":"Next","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xB00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":83886084},"n":"RunningIndex","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16777220}],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Buffers.ReadOnlySequenceSegment<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sm.System.Buffers.MemoryPool<>", (T) => $asm.$gt("$sm.System.Buffers.MemoryPool<>", [T], ($self) => class MemoryPool$$ extends $.$$.System.Object
        {
            /*ArrayMemoryPool<T>*/ static s_shared = null;
            static /*MemoryPool<T> */ get Shared()
            {
                return $.$sm.System.Buffers.MemoryPool$$(T).s_shared;
            }
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*void */ Dispose()
            {
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_shared = new ($.$sm.System.Buffers.ArrayMemoryPool$$(T))().$ctor$2();
                }
            }
            static $h = 433671;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":this.$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":50331681},"n":"Shared","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2097185},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":50331905},"n":"MaxBufferSize","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2097409}],"m":[{"r":$.$$.System.Buffers.IMemoryOwner$$(T).$h,"p":[{"n":"minBufferSize","p":655361,"f":65,"v":-1}],"n":"Rent","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777473},{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":16777476}],"l":[{"t":$.$sm.System.Buffers.ArrayMemoryPool$$(T).$h,"n":"s_shared","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194338}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777220}],"i":[57540609],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Buffers.MemoryPool<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sm.System.ThrowHelper", ($self) => class ThrowHelper
        {
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                throw $.$sm.System.ThrowHelper.CreateArgumentNullException(argument);
            }
            static /*ArgumentNullException */ CreateArgumentNullException(/*ExceptionArgument*/ argument)
            {
                return new $.$$.System.ArgumentNullException().$ctor$19($.$$.System.Enum.ToStringT($.$sm.System.ExceptionArgument, $.$$.System.UInt32, argument));
            }
            static /*void */ ThrowArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                throw $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException(argument);
            }
            static /*ArgumentOutOfRangeException */ CreateArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                return new $.$$.System.ArgumentOutOfRangeException().$ctor$20($.$$.System.Enum.ToStringT($.$sm.System.ExceptionArgument, $.$$.System.UInt32, argument));
            }
            static /*void */ ThrowInvalidOperationException()
            {
                throw $.$sm.System.ThrowHelper.CreateInvalidOperationException();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException()
            {
                return new $.$$.System.InvalidOperationException().$ctor$9();
            }
            static /*void */ ThrowInvalidOperationException_EndPositionNotReached()
            {
                throw $.$sm.System.ThrowHelper.CreateInvalidOperationException_EndPositionNotReached();
            }
            static /*InvalidOperationException */ CreateInvalidOperationException_EndPositionNotReached()
            {
                return new $.$$.System.InvalidOperationException().$ctor$12($.$sm.System.SR.EndPositionNotReached);
            }
            static /*void */ ThrowArgumentOutOfRangeException_PositionOutOfRange()
            {
                throw $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException_PositionOutOfRange();
            }
            static /*ArgumentOutOfRangeException */ CreateArgumentOutOfRangeException_PositionOutOfRange()
            {
                return new $.$$.System.ArgumentOutOfRangeException().$ctor$20("position");
            }
            static /*void */ ThrowArgumentOutOfRangeException_OffsetOutOfRange()
            {
                throw $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException_OffsetOutOfRange();
            }
            static /*ArgumentOutOfRangeException */ CreateArgumentOutOfRangeException_OffsetOutOfRange()
            {
                return new $.$$.System.ArgumentOutOfRangeException().$ctor$20("offset");
            }
            static /*void */ ThrowArgumentValidationException$1(T, /*ReadOnlySequenceSegment<T>?*/ startSegment, /*int*/ startIndex, /*ReadOnlySequenceSegment<T>?*/ endSegment)
            {
                throw $.$sm.System.ThrowHelper.CreateArgumentValidationException$1(T, startSegment, startIndex, endSegment);
            }
            static /*Exception */ CreateArgumentValidationException$1(T, /*ReadOnlySequenceSegment<T>?*/ startSegment, /*int*/ startIndex, /*ReadOnlySequenceSegment<T>?*/ endSegment)
            {
                if (startSegment === null)
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentNullException(8/*ExceptionArgument.startSegment*/);
                }
                else if (endSegment === null)
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentNullException(9/*ExceptionArgument.endSegment*/);
                }
                else if (startSegment !== endSegment && startSegment.RunningIndex > endSegment.RunningIndex)
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException(9/*ExceptionArgument.endSegment*/);
                }
                else if ((startSegment.Memory.Length >>> 0) < (startIndex >>> 0))
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException(10/*ExceptionArgument.startIndex*/);
                }
                else 
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException(11/*ExceptionArgument.endIndex*/);
                }
            }
            static /*void */ ThrowArgumentValidationException(/*Array?*/ array, /*int*/ start)
            {
                throw $.$sm.System.ThrowHelper.CreateArgumentValidationException(array, start);
            }
            static /*Exception */ CreateArgumentValidationException(/*Array?*/ array, /*int*/ start)
            {
                if (array === null)
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentNullException(12/*ExceptionArgument.array*/);
                }
                else if ((start >>> 0) > (array.length >>> 0))
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException(1/*ExceptionArgument.start*/);
                }
                else 
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException(0/*ExceptionArgument.length*/);
                }
            }
            static /*void */ ThrowStartOrEndArgumentValidationException(/*long*/ start)
            {
                throw $.$sm.System.ThrowHelper.CreateStartOrEndArgumentValidationException(start);
            }
            static /*ArgumentOutOfRangeException */ CreateStartOrEndArgumentValidationException(/*long*/ start)
            {
                if (start < 0n)
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException(1/*ExceptionArgument.start*/);
                }
                return $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException(0/*ExceptionArgument.length*/);
            }
            static $h = 1416711;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"argument","p":1089031}],"n":"ThrowArgumentNullException","d":1416711,"h":4296384007,"f":16777256},{"r":13565953,"p":[{"n":"argument","p":1089031}],"n":"CreateArgumentNullException","d":1416711,"h":8591351303,"f":16777250},{"r":65537,"p":[{"n":"argument","p":1089031}],"n":"ThrowArgumentOutOfRangeException","d":1416711,"h":12886318599,"f":16777256},{"r":13631489,"p":[{"n":"argument","p":1089031}],"n":"CreateArgumentOutOfRangeException","d":1416711,"h":17181285895,"f":16777250},{"r":65537,"n":"ThrowInvalidOperationException","d":1416711,"h":21476253191,"f":16777256},{"r":58261505,"n":"CreateInvalidOperationException","d":1416711,"h":25771220487,"f":16777250},{"r":65537,"n":"ThrowInvalidOperationException_EndPositionNotReached","d":1416711,"h":30066187783,"f":16777256},{"r":58261505,"n":"CreateInvalidOperationException_EndPositionNotReached","d":1416711,"h":34361155079,"f":16777250},{"r":65537,"n":"ThrowArgumentOutOfRangeException_PositionOutOfRange","d":1416711,"h":38656122375,"f":16777256},{"r":13631489,"n":"CreateArgumentOutOfRangeException_PositionOutOfRange","d":1416711,"h":42951089671,"f":16777250},{"r":65537,"n":"ThrowArgumentOutOfRangeException_OffsetOutOfRange","d":1416711,"h":47246056967,"f":16777256},{"r":13631489,"n":"CreateArgumentOutOfRangeException_OffsetOutOfRange","d":1416711,"h":51541024263,"f":16777250},{"r":65537,"p":[{"n":"startSegment","p":(T) => $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h},{"n":"startIndex","p":655361},{"n":"endSegment","p":(T) => $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h}],"g":["T"],"n":"ThrowArgumentValidationException","o":"@$1","d":1416711,"h":55835991559,"f":16908321},{"r":47251457,"p":[{"n":"startSegment","p":(T) => $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h},{"n":"startIndex","p":655361},{"n":"endSegment","p":(T) => $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h}],"g":["T"],"n":"CreateArgumentValidationException","o":"@$1","d":1416711,"h":60130958855,"f":16908322},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"start","p":655361}],"n":"ThrowArgumentValidationException","d":1416711,"h":64425926151,"f":16777249},{"r":47251457,"p":[{"n":"array","p":1245185},{"n":"start","p":655361}],"n":"CreateArgumentValidationException","d":1416711,"h":68720893447,"f":16777250},{"r":65537,"p":[{"n":"start","p":917505}],"n":"ThrowStartOrEndArgumentValidationException","d":1416711,"h":73015860743,"f":16777249},{"r":13631489,"p":[{"n":"start","p":917505}],"n":"CreateStartOrEndArgumentValidationException","d":1416711,"h":77310828039,"f":16777250}],"h":1416711}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.ThrowHelper`; }
        });
        
        $asm.$cls("$sm.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$sm.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Memory", $.$sm.System.SR.$type.Assembly);
                    $.$sm.System.SR.s_resourceManager = temp;
                }
                return $.$sm.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$sm.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$sm.System.SR.resourceCulture = value;
            }
            static /*string */ get NotSupported_CannotCallEqualsOnSpan()
            {
                return "Equals() on Span and ReadOnlySpan is not supported. Use operator== instead.";
            }
            static /*string */ get NotSupported_CannotCallGetHashCodeOnSpan()
            {
                return "GetHashCode() on Span and ReadOnlySpan is not supported.";
            }
            static /*string */ get Argument_InvalidTypeWithPointersNotSupported()
            {
                return "Cannot use type '{0}'. Only value types without pointers or references are supported.";
            }
            static /*string */ FormatArgument_InvalidTypeWithPointersNotSupported(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Cannot use type '{0}'. Only value types without pointers or references are supported.", arg1);
            }
            static /*string */ get Argument_DestinationTooShort()
            {
                return "Destination is too short.";
            }
            static /*string */ get OutstandingReferences()
            {
                return "Release all references before disposing this instance.";
            }
            static /*string */ get Argument_BadFormatSpecifier()
            {
                return "Format specifier was invalid.";
            }
            static /*string */ get Argument_OverlapAlignmentMismatch()
            {
                return "Overlapping spans have mismatching alignment.";
            }
            static /*string */ get EndPositionNotReached()
            {
                return "End position was not reached during enumeration.";
            }
            static /*string */ get BufferWriterAdvancedTooFar()
            {
                return "Cannot advance past the end of the buffer, which has a size of {0}.";
            }
            static /*string */ FormatBufferWriterAdvancedTooFar(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Cannot advance past the end of the buffer, which has a size of {0}.", arg1);
            }
            static /*string */ get BufferMaximumSizeExceeded()
            {
                return "Cannot allocate a buffer of size {0}.";
            }
            static /*string */ FormatBufferMaximumSizeExceeded(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Cannot allocate a buffer of size {0}.", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$sm.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$sm.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sm.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$sm.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sm.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sm.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sm.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sm.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$sm.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$sm.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$sm.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$sm.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$sm.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 1285639;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":1285639}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$sm.System.Buffers.ReadOnlySequenceDebugView<>", (T) => $asm.$gt("$sm.System.Buffers.ReadOnlySequenceDebugView<>", [T], ($self) => class ReadOnlySequenceDebugView$$ extends $.$$.System.Object
        {
            /*T[]*/ _array = null;
            /*ReadOnlySequenceDebugViewSegments*/ _segments;
            $ctor$1(/*ReadOnlySequence<T>*/ sequence)
            {
                super.$ctor();
                {
                    this._array = $.$sm.System.Buffers.BuffersExtensions.ToArray(T, $.$ref(() => sequence, ));
                    /*var*/ let segmentCount = 0;
                    var $en3 = sequence.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var _ = $en3.Current;
                        {
                            segmentCount++;
                        }
                    }
                    /*var*/ let segments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.ReadOnlyMemory$$(T)), null, [segmentCount], null);
                    /*int*/ let i = 0;
                    var $en3 = sequence.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var readOnlyMemory = $en3.Current;
                        {
                            $.$$.System.Array.$WriteT1.call(segments, readOnlyMemory, i);
                            i++;
                        }
                    }
                    this._segments = (() =>
                    {
                        //new $.$sm.System.Buffers.ReadOnlySequenceDebugView$$(T).ReadOnlySequenceDebugViewSegments()
                        const $t1 = $.$sm.System.Buffers.ReadOnlySequenceDebugView$$(T).ReadOnlySequenceDebugViewSegments;
                        const $i1 = new $t1();
                        $i1.Segments = segments;
                        return $i1;
                    })();
                }
                return this;
            }
            /*ReadOnlySequenceDebugViewSegments */ get BufferSegments()
            {
                return this._segments;
            }
            /*T[] */ get Items()
            {
                return this._array;
            }
            static $_ReadOnlySequenceDebugViewSegments;
            static get ReadOnlySequenceDebugViewSegments()
            {
                let $cls = $.$sm.System.Buffers.ReadOnlySequenceDebugView$$(T);
                return $cls.$_ReadOnlySequenceDebugViewSegments ??= $asm.$nstr("$sm.System.Buffers.ReadOnlySequenceDebugView$$.ReadOnlySequenceDebugViewSegments", ($self) => class ReadOnlySequenceDebugViewSegments extends $.$$.System.ValueType
                {
                    /*ReadOnlyMemory<T>[]*/ Segments = null;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Segments = this.Segments;
                        return copy;
                    }
                    static $h = 826887;
                    static $z = 4;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$typeArray($.$$.System.ReadOnlyMemory$$(T)).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":83886081},"n":"Segments","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2097153,"a":[{"t":37421057,"c":4332388353,"a":[{"v":3,"t":37486593}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"d":$.$sm.System.Buffers.ReadOnlySequenceDebugView$$(T).$h,"h":this.$h,"a":[{"t":37617665,"c":8627552257,"a":[{"v":"Count = {Segments.Length}","t":1310721}],"n":[{"n":"Name","v":"Segments","t":1310721}]}]}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Buffers.ReadOnlySequenceDebugView<${T?.$fullName}>.ReadOnlySequenceDebugViewSegments`; }
                }, $cls, ($v) => $cls.$_ReadOnlySequenceDebugViewSegments = $v);
            }
            //default member initializer
            constructor()
            {
                super();
                this._segments = $.$default($.$sm.System.Buffers.ReadOnlySequenceDebugView$$(T).ReadOnlySequenceDebugViewSegments);
            }
            static $h = 761351;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$sm.System.Buffers.ReadOnlySequenceDebugView$$(T).ReadOnlySequenceDebugViewSegments.$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x500000000n),"f":50331649},"n":"BufferSegments","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":2097153},{"p":$.$typeArray(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x700000000n),"f":50331649},"n":"Items","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":2097153,"a":[{"t":37421057,"c":4332388353,"a":[{"v":3,"t":37486593}]}]}],"l":[{"t":$.$typeArray(T).$h,"n":"_array","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":$.$sm.System.Buffers.ReadOnlySequenceDebugView$$(T).ReadOnlySequenceDebugViewSegments.$h,"n":"_segments","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306}],"c":[{"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$(T).$h}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777217}],"g":[T?.$h??1507328],"j":[$.$sm.System.Buffers.ReadOnlySequenceDebugView$$(T).ReadOnlySequenceDebugViewSegments.$h],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Buffers.ReadOnlySequenceDebugView<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sm.System.Buffers.BuffersExtensions", ($self) => class BuffersExtensions
        {
            static /*SequencePosition? */ PositionOf(T, /*in this ReadOnlySequence<T>*/ source, /*T*/ value)
            {
                if (source.$v.IsSingleSegment)
                {
                    /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$4(T, source.$v.First.Span, value);
                    if (index !== -1)
                    {
                        return source.$v.Seek(BigInt(index), 7);
                    }
                    return null;
                }
                else 
                {
                    return $.$sm.System.Buffers.BuffersExtensions.PositionOfMultiSegment(T, source, value);
                }
            }
            static /*SequencePosition? */ PositionOfMultiSegment(T, /*in ReadOnlySequence<T>*/ source, /*T*/ value)
            {
                /*SequencePosition*/ let position = source.$v.Start;
                /*SequencePosition*/ let result = position;
                /*ReadOnlyMemory<T>*/ let memory;
                while(source.$v.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => position, ($v) => position = $v, null), $.$ref(() => memory, ($v) => memory = $v, $.$$.System.ReadOnlyMemory$$(T)), true))
                {
                    /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$4(T, memory.Span, value);
                    if (index !== -1)
                    {
                        return source.$v.GetPosition(BigInt(index), result);
                    }
                    else if (position.GetObject() === null)
                    {
                        break;
                    }
                    result = position;
                }
                return null;
            }
            static /*void */ CopyTo(T, /*in this ReadOnlySequence<T>*/ source, /*Span<T>*/ destination)
            {
                if (source.$v.IsSingleSegment)
                {
                    /*ReadOnlySpan<T>*/ let span = source.$v.First.Span;
                    if (span.Length > destination.Length)
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.destination*/);
                    }
                    span.CopyTo(destination);
                }
                else 
                {
                    $.$sm.System.Buffers.BuffersExtensions.CopyToMultiSegment(T, source, destination);
                }
            }
            static /*void */ CopyToMultiSegment(T, /*in ReadOnlySequence<T>*/ sequence, /*Span<T>*/ destination)
            {
                if (sequence.$v.Length > BigInt(destination.Length))
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.destination*/);
                }
                /*SequencePosition*/ let position = sequence.$v.Start;
                /*ReadOnlyMemory<T>*/ let memory;
                while(sequence.$v.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => position, ($v) => position = $v, null), $.$ref(() => memory, ($v) => memory = $v, $.$$.System.ReadOnlyMemory$$(T)), true))
                {
                    /*ReadOnlySpan<T>*/ let span = memory.Span;
                    span.CopyTo(destination);
                    if (position.GetObject() !== null)
                    {
                        destination = destination.Slice$1(span.Length);
                    }
                    else 
                    {
                        break;
                    }
                }
            }
            static /*T[] */ ToArray(T, /*in this ReadOnlySequence<T>*/ sequence)
            {
                /*var*/ let array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [sequence.$v.Length], null);
                $.$sm.System.Buffers.BuffersExtensions.CopyTo(T, $.$ref(() => sequence, ), $.$$.System.Span$$(T).op_Implicit$2(array));
                return array;
            }
            static /*void */ Write(T, /*this IBufferWriter<T>*/ writer, /*ReadOnlySpan<T>*/ value)
            {
                /*Span<T>*/ let destination = writer.System$Buffers$IBufferWriter$$$GetSpan(0, [T]);
                if (value.Length <= destination.Length)
                {
                    value.CopyTo(destination);
                    writer.System$Buffers$IBufferWriter$$$Advance(value.Length, [T]);
                }
                else 
                {
                    $.$sm.System.Buffers.BuffersExtensions.WriteMultiSegment(T, writer, $.$ref(() => value, ), destination);
                }
            }
            static /*void */ WriteMultiSegment(T, /*IBufferWriter<T>*/ writer, /*in ReadOnlySpan<T>*/ source, /*Span<T>*/ destination)
            {
                /*ReadOnlySpan<T>*/ let input = source.$v;
                while(true)
                {
                    /*int*/ let writeSize = $.$$.System.Math.Min$4(destination.Length, input.Length);
                    input.Slice(0, writeSize).CopyTo(destination);
                    writer.System$Buffers$IBufferWriter$$$Advance(writeSize, [T]);
                    input = input.Slice$1(writeSize);
                    if (input.Length > 0)
                    {
                        destination = writer.System$Buffers$IBufferWriter$$$GetSpan(0, [T]);
                        if (destination.IsEmpty)
                        {
                            $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(16/*ExceptionArgument.writer*/);
                        }
                        continue;
                    }
                    return;
                }
            }
            static $h = 302599;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$typeNullable($.$sm.System.SequencePosition).$h,"p":[{"n":"source","p":(T) => $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"f":8},{"n":"value","p":(T) => T.$h}],"g":["T"],"n":"PositionOf","d":302599,"h":4295269895,"f":16908321},{"r":$.$typeNullable($.$sm.System.SequencePosition).$h,"p":[{"n":"source","p":(T) => $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"f":8},{"n":"value","p":(T) => T.$h}],"g":["T"],"n":"PositionOfMultiSegment","d":302599,"h":8590237191,"f":16908322},{"r":65537,"p":[{"n":"source","p":(T) => $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"f":8},{"n":"destination","p":(T) => $.$$.System.Span$$(T).$h}],"g":["T"],"n":"CopyTo","d":302599,"h":12885204487,"f":16908321},{"r":65537,"p":[{"n":"sequence","p":(T) => $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"f":8},{"n":"destination","p":(T) => $.$$.System.Span$$(T).$h}],"g":["T"],"n":"CopyToMultiSegment","d":302599,"h":17180171783,"f":16908322},{"r":(T) => $.$typeArray(T).$h,"p":[{"n":"sequence","p":(T) => $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"f":8}],"g":["T"],"n":"ToArray","d":302599,"h":21475139079,"f":16908321},{"r":65537,"p":[{"n":"writer","p":(T) => $.$sm.System.Buffers.IBufferWriter$$(T).$h},{"n":"value","p":(T) => $.$$.System.ReadOnlySpan$$(T).$h}],"g":["T"],"n":"Write","d":302599,"h":25770106375,"f":16908321},{"r":65537,"p":[{"n":"writer","p":(T) => $.$sm.System.Buffers.IBufferWriter$$(T).$h},{"n":"source","p":(T) => $.$$.System.ReadOnlySpan$$(T).$h,"f":8},{"n":"destination","p":(T) => $.$$.System.Span$$(T).$h}],"g":["T"],"n":"WriteMultiSegment","d":302599,"h":30065073671,"f":16908322}],"h":302599}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Buffers.BuffersExtensions`; }
        });
        
        $asm.$cls("$sm.System.Runtime.InteropServices.SequenceMarshal", ($self) => class SequenceMarshal
        {
            static /*bool */ TryGetReadOnlySequenceSegment(T, /*ReadOnlySequence<T>*/ sequence, /*out ReadOnlySequenceSegment<T>?*/ startSegment, /*out int*/ startIndex, /*out ReadOnlySequenceSegment<T>?*/ endSegment, /*out int*/ endIndex)
            {
                return sequence.TryGetReadOnlySequenceSegment(startSegment, startIndex, endSegment, endIndex);
            }
            static /*bool */ TryGetArray(T, /*ReadOnlySequence<T>*/ sequence, /*out ArraySegment<T>*/ segment)
            {
                return sequence.TryGetArray(segment);
            }
            static /*bool */ TryGetReadOnlyMemory(T, /*ReadOnlySequence<T>*/ sequence, /*out ReadOnlyMemory<T>*/ memory)
            {
                if (!sequence.IsSingleSegment)
                {
                    memory.$v = new ($.$$.System.ReadOnlyMemory$$(T))();
                    return false;
                }
                memory.$v = sequence.First;
                return true;
            }
            static /*bool */ TryGetString(/*ReadOnlySequence<char>*/ sequence, /*out string?*/ text, /*out int*/ start, /*out int*/ length)
            {
                return sequence.TryGetString(text, start, length);
            }
            static /*bool */ TryRead(T, /*ref SequenceReader<byte>*/ reader, /*out T*/ value)
            {
                return $.$sm.System.Buffers.SequenceReaderExtensions.TryRead(T, $.$ref(() => reader, ($v) => reader = $v), value);
            }
            static $h = 1154567;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"sequence","p":(T) => $.$sm.System.Buffers.ReadOnlySequence$$(T).$h},{"n":"startSegment","p":(T) => $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h,"f":2},{"n":"startIndex","p":655361,"f":2},{"n":"endSegment","p":(T) => $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h,"f":2},{"n":"endIndex","p":655361,"f":2}],"g":["T"],"n":"TryGetReadOnlySequenceSegment","d":1154567,"h":4296121863,"f":16908321},{"r":262145,"p":[{"n":"sequence","p":(T) => $.$sm.System.Buffers.ReadOnlySequence$$(T).$h},{"n":"segment","p":(T) => $.$$.System.ArraySegment$$(T).$h,"f":2}],"g":["T"],"n":"TryGetArray","d":1154567,"h":8591089159,"f":16908321},{"r":262145,"p":[{"n":"sequence","p":(T) => $.$sm.System.Buffers.ReadOnlySequence$$(T).$h},{"n":"memory","p":(T) => $.$$.System.ReadOnlyMemory$$(T).$h,"f":2}],"g":["T"],"n":"TryGetReadOnlyMemory","d":1154567,"h":12886056455,"f":16908321},{"r":262145,"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char).$h},{"n":"text","p":1310721,"f":2},{"n":"start","p":655361,"f":2},{"n":"length","p":655361,"f":2}],"n":"TryGetString","d":1154567,"h":17181023751,"f":16777256},{"r":262145,"p":[{"n":"reader","p":$.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,"f":4},{"n":"value","p":(T) => T.$h,"f":2}],"g":["T"],"n":"TryRead","d":1154567,"h":21475991047,"f":16908321}],"h":1154567}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.SequenceMarshal`; }
        });
        
        $asm.$cls("$sm.System.Buffers.SequenceReaderExtensions", ($self) => class SequenceReaderExtensions
        {
            static /*bool */ TryRead(T, /*ref this SequenceReader<byte>*/ reader, /*out T*/ value)
            {
                /*ReadOnlySpan<byte>*/ let span = reader.$v.UnreadSpan;
                if (span.Length < (T.$z??4))
                {
                    return $.$sm.System.Buffers.SequenceReaderExtensions.TryReadMultisegment(T, reader, value);
                }
                value.$v = $.$$.System.Runtime.InteropServices.MemoryMarshal.Read(T, span);
                reader.$v.Advance(BigInt((T.$z??4)));
                return true;
            }
            static /*bool */ TryReadMultisegment(T, /*ref SequenceReader<byte>*/ reader, /*out T*/ value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(reader.$v.UnreadSpan.Length < (T.$z??4), "reader.UnreadSpan.Length < sizeof(T)");
                /*T*/ let buffer = $.$default(T);
                /*Span<byte>*/ let tempSpan = new ($.$$.System.Span$$($.$$.System.Byte))().$ctor$5($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT(T, () => buffer, ($v) => buffer = $v, null), (T.$z??4));
                if (!reader.$v.TryCopyTo(tempSpan))
                {
                    value.$v = $.$default(T);
                    return false;
                }
                value.$v = $.$$.System.Runtime.InteropServices.MemoryMarshal.Read(T, $.$$.System.Span$$($.$$.System.Byte).op_Implicit(tempSpan));
                reader.$v.Advance(BigInt((T.$z??4)));
                return true;
            }
            static /*bool */ TryReadLittleEndian(/*ref this SequenceReader<byte>*/ reader, /*out short*/ value)
            {
                if ($.$$.System.BitConverter.IsLittleEndian)
                {
                    return $.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int16, $.$ref(() => reader, ($v) => reader = $v), value);
                }
                return $.$sm.System.Buffers.SequenceReaderExtensions.TryReadReverseEndianness(reader, value);
            }
            static /*bool */ TryReadBigEndian(/*ref this SequenceReader<byte>*/ reader, /*out short*/ value)
            {
                if (!$.$$.System.BitConverter.IsLittleEndian)
                {
                    return $.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int16, $.$ref(() => reader, ($v) => reader = $v), value);
                }
                return $.$sm.System.Buffers.SequenceReaderExtensions.TryReadReverseEndianness(reader, value);
            }
            static /*bool */ TryReadReverseEndianness(/*ref SequenceReader<byte>*/ reader, /*out short*/ value)
            {
                if ($.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int16, $.$ref(() => reader, ($v) => reader = $v), value))
                {
                    value.$v = $.$$.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$3(value.$v);
                    return true;
                }
                return false;
            }
            static /*bool */ TryReadLittleEndian$1(/*ref this SequenceReader<byte>*/ reader, /*out int*/ value)
            {
                if ($.$$.System.BitConverter.IsLittleEndian)
                {
                    return $.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int32, $.$ref(() => reader, ($v) => reader = $v), value);
                }
                return $.$sm.System.Buffers.SequenceReaderExtensions.TryReadReverseEndianness$1(reader, value);
            }
            static /*bool */ TryReadBigEndian$1(/*ref this SequenceReader<byte>*/ reader, /*out int*/ value)
            {
                if (!$.$$.System.BitConverter.IsLittleEndian)
                {
                    return $.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int32, $.$ref(() => reader, ($v) => reader = $v), value);
                }
                return $.$sm.System.Buffers.SequenceReaderExtensions.TryReadReverseEndianness$1(reader, value);
            }
            static /*bool */ TryReadReverseEndianness$1(/*ref SequenceReader<byte>*/ reader, /*out int*/ value)
            {
                if ($.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int32, $.$ref(() => reader, ($v) => reader = $v), value))
                {
                    value.$v = $.$$.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$4(value.$v);
                    return true;
                }
                return false;
            }
            static /*bool */ TryReadLittleEndian$2(/*ref this SequenceReader<byte>*/ reader, /*out long*/ value)
            {
                if ($.$$.System.BitConverter.IsLittleEndian)
                {
                    return $.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int64, $.$ref(() => reader, ($v) => reader = $v), value);
                }
                return $.$sm.System.Buffers.SequenceReaderExtensions.TryReadReverseEndianness$2(reader, value);
            }
            static /*bool */ TryReadBigEndian$2(/*ref this SequenceReader<byte>*/ reader, /*out long*/ value)
            {
                if (!$.$$.System.BitConverter.IsLittleEndian)
                {
                    return $.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int64, $.$ref(() => reader, ($v) => reader = $v), value);
                }
                return $.$sm.System.Buffers.SequenceReaderExtensions.TryReadReverseEndianness$2(reader, value);
            }
            static /*bool */ TryReadReverseEndianness$2(/*ref SequenceReader<byte>*/ reader, /*out long*/ value)
            {
                if ($.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int64, $.$ref(() => reader, ($v) => reader = $v), value))
                {
                    value.$v = $.$$.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$5(value.$v);
                    return true;
                }
                return false;
            }
            static $h = 1023495;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"reader","p":$.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,"f":4},{"n":"value","p":(T) => T.$h,"f":2}],"g":["T"],"n":"TryRead","d":1023495,"h":4295990791,"f":16908328},{"r":262145,"p":[{"n":"reader","p":$.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,"f":4},{"n":"value","p":(T) => T.$h,"f":2}],"g":["T"],"n":"TryReadMultisegment","d":1023495,"h":8590958087,"f":16908322},{"r":262145,"p":[{"n":"reader","p":$.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,"f":4},{"n":"value","p":524289,"f":2}],"n":"TryReadLittleEndian","d":1023495,"h":12885925383,"f":16777249},{"r":262145,"p":[{"n":"reader","p":$.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,"f":4},{"n":"value","p":524289,"f":2}],"n":"TryReadBigEndian","d":1023495,"h":17180892679,"f":16777249},{"r":262145,"p":[{"n":"reader","p":$.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,"f":4},{"n":"value","p":524289,"f":2}],"n":"TryReadReverseEndianness","d":1023495,"h":21475859975,"f":16777250},{"r":262145,"p":[{"n":"reader","p":$.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,"f":4},{"n":"value","p":655361,"f":2}],"n":"TryReadLittleEndian","o":"@$1","d":1023495,"h":25770827271,"f":16777249},{"r":262145,"p":[{"n":"reader","p":$.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,"f":4},{"n":"value","p":655361,"f":2}],"n":"TryReadBigEndian","o":"@$1","d":1023495,"h":30065794567,"f":16777249},{"r":262145,"p":[{"n":"reader","p":$.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,"f":4},{"n":"value","p":655361,"f":2}],"n":"TryReadReverseEndianness","o":"@$1","d":1023495,"h":34360761863,"f":16777250},{"r":262145,"p":[{"n":"reader","p":$.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,"f":4},{"n":"value","p":917505,"f":2}],"n":"TryReadLittleEndian","o":"@$2","d":1023495,"h":38655729159,"f":16777249},{"r":262145,"p":[{"n":"reader","p":$.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,"f":4},{"n":"value","p":917505,"f":2}],"n":"TryReadBigEndian","o":"@$2","d":1023495,"h":42950696455,"f":16777249},{"r":262145,"p":[{"n":"reader","p":$.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,"f":4},{"n":"value","p":917505,"f":2}],"n":"TryReadReverseEndianness","o":"@$2","d":1023495,"h":47245663751,"f":16777250}],"h":1023495}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Buffers.SequenceReaderExtensions`; }
        });
        
        $asm.$cls("$sm.System.Text.EncodingExtensions", ($self) => class EncodingExtensions
        {
            /*int*/ static MaxInputElementsPerIteration = 1048576;
            static /*long */ GetBytes(/*this Encoding*/ encoding, /*ReadOnlySpan<char>*/ chars, /*IBufferWriter<byte>*/ writer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (chars.Length <= 1048576/*MaxInputElementsPerIteration*/)
                {
                    /*int*/ let byteCount = encoding.GetByteCount$4(chars);
                    /*Span<byte>*/ let scratchBuffer = writer.System$Buffers$IBufferWriter$$$GetSpan(byteCount, [$.$$.System.Byte]);
                    /*int*/ let actualBytesWritten = encoding.GetBytes$5(chars, scratchBuffer);
                    writer.System$Buffers$IBufferWriter$$$Advance(actualBytesWritten, [$.$$.System.Byte]);
                    return BigInt(actualBytesWritten);
                }
                else 
                {
                    /*long*/ let totalBytesWritten;
                    $.$sm.System.Text.EncodingExtensions.Convert$2(encoding.GetEncoder(), chars, writer, true, $.$ref(() => totalBytesWritten, ($v) => totalBytesWritten = $v, $.$$.System.Int64), $.$discardRef());
                    return totalBytesWritten;
                }
            }
            static /*long */ GetBytes$2(/*this Encoding*/ encoding, /*in ReadOnlySequence<char>*/ chars, /*IBufferWriter<byte>*/ writer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (chars.$v.IsSingleSegment)
                {
                    return $.$sm.System.Text.EncodingExtensions.GetBytes(encoding, chars.$v.FirstSpan, writer);
                }
                else 
                {
                    /*long*/ let bytesWritten;
                    $.$sm.System.Text.EncodingExtensions.Convert$3(encoding.GetEncoder(), chars, writer, true, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int64), $.$discardRef());
                    return bytesWritten;
                }
            }
            static /*int */ GetBytes$1(/*this Encoding*/ encoding, /*in ReadOnlySequence<char>*/ chars, /*Span<byte>*/ bytes)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                if (chars.$v.IsSingleSegment)
                {
                    return encoding.GetBytes$5(chars.$v.FirstSpan, bytes);
                }
                else 
                {
                    /*ReadOnlySequence<char>*/ let remainingChars = chars.$v;
                    /*int*/ let originalBytesLength = bytes.Length;
                    /*Encoder*/ let encoder = encoding.GetEncoder();
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<char>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        remainingChars.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Char)), $.$ref(() => next, ($v) => next = $v, $.$sm.System.SequencePosition));
                        isFinalSegment = remainingChars.IsSingleSegment;
                        /*int*/ let bytesWrittenJustNow = encoder.GetBytes$2(firstSpan, bytes, isFinalSegment);
                        bytes = bytes.Slice$1(bytesWrittenJustNow);
                        remainingChars = remainingChars.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    return ((originalBytesLength - bytes.Length) | 0);
                }
            }
            static /*byte[] */ GetBytes$3(/*this Encoding*/ encoding, /*in ReadOnlySequence<char>*/ chars)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                if (chars.$v.IsSingleSegment)
                {
                    /*ReadOnlySpan<char>*/ let span = chars.$v.FirstSpan;
                    /*byte[]*/ let retVal = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [encoding.GetByteCount$4(span)], null);
                    encoding.GetBytes$5(span, $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(retVal));
                    return retVal;
                }
                else 
                {
                    /*Encoder*/ let encoder = encoding.GetEncoder();
                    /*List<(byte[], int)>*/ let listOfSegments = new ($.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$typeArray($.$$.System.Byte), $.$$.System.Int32)))().$ctor$1();
                    /*int*/ let totalByteCount = 0;
                    /*ReadOnlySequence<char>*/ let remainingChars = chars.$v;
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<char>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        remainingChars.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Char)), $.$ref(() => next, ($v) => next = $v, $.$sm.System.SequencePosition));
                        isFinalSegment = remainingChars.IsSingleSegment;
                        /*int*/ let byteCountThisIteration = encoder.GetByteCount$2(firstSpan, isFinalSegment);
                        /*byte[]*/ let rentedArray = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(byteCountThisIteration);
                        /*int*/ let actualBytesWrittenThisIteration = encoder.GetBytes$2(firstSpan, $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rentedArray), isFinalSegment);
                        listOfSegments.Add(new ($.$$.System.ValueTuple$$$($.$typeArray($.$$.System.Byte), $.$$.System.Int32))().$ctor$3(rentedArray, actualBytesWrittenThisIteration));
                        totalByteCount += actualBytesWrittenThisIteration;
                        if (totalByteCount < 0)
                        {
                            totalByteCount = 2147483647/*int.MaxValue*/;
                            break;
                        }
                        remainingChars = remainingChars.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    /*byte[]*/ let retVal = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [totalByteCount], null);
                    /*Span<byte>*/ let remainingBytes = $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(retVal);
                    var $en3 = listOfSegments.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var $t1 = $en3.Current;
                        /*byte[]*/ let array = $t1.Item1;
                        /*int*/ let length = $t1.Item2;
                        {
                            $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, array, 0, length).CopyTo(remainingBytes);
                            $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(array, false);
                            remainingBytes = remainingBytes.Slice$1(length);
                        }
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(remainingBytes.IsEmpty, "Over-allocated the byte[] instance?");
                    return retVal;
                }
            }
            static /*long */ GetChars(/*this Encoding*/ encoding, /*ReadOnlySpan<byte>*/ bytes, /*IBufferWriter<char>*/ writer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (bytes.Length <= 1048576/*MaxInputElementsPerIteration*/)
                {
                    /*int*/ let charCount = encoding.GetCharCount$4(bytes);
                    /*Span<char>*/ let scratchBuffer = writer.System$Buffers$IBufferWriter$$$GetSpan(charCount, [$.$$.System.Char]);
                    /*int*/ let actualCharsWritten = encoding.GetChars$5(bytes, scratchBuffer);
                    writer.System$Buffers$IBufferWriter$$$Advance(actualCharsWritten, [$.$$.System.Char]);
                    return BigInt(actualCharsWritten);
                }
                else 
                {
                    /*long*/ let totalCharsWritten;
                    $.$sm.System.Text.EncodingExtensions.Convert(encoding.GetDecoder(), bytes, writer, true, $.$ref(() => totalCharsWritten, ($v) => totalCharsWritten = $v, $.$$.System.Int64), $.$discardRef());
                    return totalCharsWritten;
                }
            }
            static /*long */ GetChars$2(/*this Encoding*/ encoding, /*in ReadOnlySequence<byte>*/ bytes, /*IBufferWriter<char>*/ writer)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (bytes.$v.IsSingleSegment)
                {
                    return $.$sm.System.Text.EncodingExtensions.GetChars(encoding, bytes.$v.FirstSpan, writer);
                }
                else 
                {
                    /*long*/ let charsWritten;
                    $.$sm.System.Text.EncodingExtensions.Convert$1(encoding.GetDecoder(), bytes, writer, true, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int64), $.$discardRef());
                    return charsWritten;
                }
            }
            static /*int */ GetChars$1(/*this Encoding*/ encoding, /*in ReadOnlySequence<byte>*/ bytes, /*Span<char>*/ chars)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                if (bytes.$v.IsSingleSegment)
                {
                    return encoding.GetChars$5(bytes.$v.FirstSpan, chars);
                }
                else 
                {
                    /*ReadOnlySequence<byte>*/ let remainingBytes = bytes.$v;
                    /*int*/ let originalCharsLength = chars.Length;
                    /*Decoder*/ let decoder = encoding.GetDecoder();
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<byte>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        remainingBytes.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => next, ($v) => next = $v, $.$sm.System.SequencePosition));
                        isFinalSegment = remainingBytes.IsSingleSegment;
                        /*int*/ let charsWrittenJustNow = decoder.GetChars$3(firstSpan, chars, isFinalSegment);
                        chars = chars.Slice$1(charsWrittenJustNow);
                        remainingBytes = remainingBytes.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    return ((originalCharsLength - chars.Length) | 0);
                }
            }
            static /*string */ GetString(/*this Encoding*/ encoding, /*in ReadOnlySequence<byte>*/ bytes)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                if (bytes.$v.IsSingleSegment)
                {
                    return encoding.GetString$3(bytes.$v.FirstSpan);
                }
                else 
                {
                    /*Decoder*/ let decoder = encoding.GetDecoder();
                    /*List<(char[], int)>*/ let listOfSegments = new ($.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$typeArray($.$$.System.Char), $.$$.System.Int32)))().$ctor$1();
                    /*int*/ let totalCharCount = 0;
                    /*ReadOnlySequence<byte>*/ let remainingBytes = bytes.$v;
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<byte>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        remainingBytes.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => next, ($v) => next = $v, $.$sm.System.SequencePosition));
                        isFinalSegment = remainingBytes.IsSingleSegment;
                        /*int*/ let charCountThisIteration = decoder.GetCharCount$3(firstSpan, isFinalSegment);
                        /*char[]*/ let rentedArray = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(charCountThisIteration);
                        /*int*/ let actualCharsWrittenThisIteration = decoder.GetChars$3(firstSpan, $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(rentedArray), isFinalSegment);
                        listOfSegments.Add(new ($.$$.System.ValueTuple$$$($.$typeArray($.$$.System.Char), $.$$.System.Int32))().$ctor$3(rentedArray, actualCharsWrittenThisIteration));
                        totalCharCount += actualCharsWrittenThisIteration;
                        if (totalCharCount < 0)
                        {
                            totalCharCount = 2147483647/*int.MaxValue*/;
                            break;
                        }
                        remainingBytes = remainingBytes.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    return $.$$.System.String.Create$10($.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$typeArray($.$$.System.Char), $.$$.System.Int32)), totalCharCount, listOfSegments, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$typeArray($.$$.System.Char), $.$$.System.Int32))))().$ctor(this,  (/*span*/ span, /*listOfSegments*/ listOfSegments) =>
                    {
                        var $en4 = listOfSegments.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var $t1 = $en4.Current;
                            /*char[]*/ let array = $t1.Item1;
                            /*int*/ let length = $t1.Item2;
                            {
                                $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, array, 0, length).CopyTo(span);
                                $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(array, false);
                                span = span.Slice$1(length);
                            }
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(span.IsEmpty, "Over-allocated the string instance?");
                    }, {"r":65537,"p":[{"n":"span","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"listOfSegments","p":$.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$typeArray($.$$.System.Char), $.$$.System.Int32)).$h}],"n":"","d":1351175,"h":0,"f":17825794}));
                }
            }
            static /*void */ Convert$2(/*this Encoder*/ encoder, /*ReadOnlySpan<char>*/ chars, /*IBufferWriter<byte>*/ writer, /*bool*/ flush, /*out long*/ bytesUsed, /*out bool*/ completed)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoder, "encoder");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                /*long*/ let totalBytesWritten = 0n;
                do
                {
                    /*int*/ let byteCountForThisSlice = (chars.Length <= 1048576/*MaxInputElementsPerIteration*/) ? encoder.GetByteCount$2(chars, flush) : encoder.GetByteCount$2(chars.Slice(0, 1048576/*MaxInputElementsPerIteration*/), false);
                    /*Span<byte>*/ let scratchBuffer = writer.System$Buffers$IBufferWriter$$$GetSpan(byteCountForThisSlice, [$.$$.System.Byte]);
                    /*int*/ let charsUsedJustNow;
                    /*int*/ let bytesWrittenJustNow;
                    encoder.Convert$2(chars, scratchBuffer, flush, $.$ref(() => charsUsedJustNow, ($v) => charsUsedJustNow = $v, $.$$.System.Int32), $.$ref(() => bytesWrittenJustNow, ($v) => bytesWrittenJustNow = $v, $.$$.System.Int32), completed);
                    chars = chars.Slice$1(charsUsedJustNow);
                    writer.System$Buffers$IBufferWriter$$$Advance(bytesWrittenJustNow, [$.$$.System.Byte]);
                    totalBytesWritten += BigInt(bytesWrittenJustNow);
                }
                while(!chars.IsEmpty);
                bytesUsed.$v = totalBytesWritten;
            }
            static /*void */ Convert$3(/*this Encoder*/ encoder, /*in ReadOnlySequence<char>*/ chars, /*IBufferWriter<byte>*/ writer, /*bool*/ flush, /*out long*/ bytesUsed, /*out bool*/ completed)
            {
                if (chars.$v.IsSingleSegment)
                {
                    $.$sm.System.Text.EncodingExtensions.Convert$2(encoder, chars.$v.FirstSpan, writer, flush, bytesUsed, completed);
                }
                else 
                {
                    /*ReadOnlySequence<char>*/ let remainingChars = chars.$v;
                    /*long*/ let totalBytesWritten = 0n;
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<char>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        remainingChars.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Char)), $.$ref(() => next, ($v) => next = $v, $.$sm.System.SequencePosition));
                        isFinalSegment = remainingChars.IsSingleSegment;
                        /*long*/ let bytesWrittenThisIteration;
                        $.$sm.System.Text.EncodingExtensions.Convert$2(encoder, firstSpan, writer, flush && isFinalSegment, $.$ref(() => bytesWrittenThisIteration, ($v) => bytesWrittenThisIteration = $v, $.$$.System.Int64), completed);
                        totalBytesWritten += bytesWrittenThisIteration;
                        remainingChars = remainingChars.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    bytesUsed.$v = totalBytesWritten;
                }
            }
            static /*void */ Convert(/*this Decoder*/ decoder, /*ReadOnlySpan<byte>*/ bytes, /*IBufferWriter<char>*/ writer, /*bool*/ flush, /*out long*/ charsUsed, /*out bool*/ completed)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(decoder, "decoder");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                /*long*/ let totalCharsWritten = 0n;
                do
                {
                    /*int*/ let charCountForThisSlice = (bytes.Length <= 1048576/*MaxInputElementsPerIteration*/) ? decoder.GetCharCount$3(bytes, flush) : decoder.GetCharCount$3(bytes.Slice(0, 1048576/*MaxInputElementsPerIteration*/), false);
                    /*Span<char>*/ let scratchBuffer = writer.System$Buffers$IBufferWriter$$$GetSpan(charCountForThisSlice, [$.$$.System.Char]);
                    /*int*/ let bytesUsedJustNow;
                    /*int*/ let charsWrittenJustNow;
                    decoder.Convert$2(bytes, scratchBuffer, flush, $.$ref(() => bytesUsedJustNow, ($v) => bytesUsedJustNow = $v, $.$$.System.Int32), $.$ref(() => charsWrittenJustNow, ($v) => charsWrittenJustNow = $v, $.$$.System.Int32), completed);
                    bytes = bytes.Slice$1(bytesUsedJustNow);
                    writer.System$Buffers$IBufferWriter$$$Advance(charsWrittenJustNow, [$.$$.System.Char]);
                    totalCharsWritten += BigInt(charsWrittenJustNow);
                }
                while(!bytes.IsEmpty);
                charsUsed.$v = totalCharsWritten;
            }
            static /*void */ Convert$1(/*this Decoder*/ decoder, /*in ReadOnlySequence<byte>*/ bytes, /*IBufferWriter<char>*/ writer, /*bool*/ flush, /*out long*/ charsUsed, /*out bool*/ completed)
            {
                if (bytes.$v.IsSingleSegment)
                {
                    $.$sm.System.Text.EncodingExtensions.Convert(decoder, bytes.$v.FirstSpan, writer, flush, charsUsed, completed);
                }
                else 
                {
                    /*ReadOnlySequence<byte>*/ let remainingBytes = bytes.$v;
                    /*long*/ let totalCharsWritten = 0n;
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<byte>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        remainingBytes.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => next, ($v) => next = $v, $.$sm.System.SequencePosition));
                        isFinalSegment = remainingBytes.IsSingleSegment;
                        /*long*/ let charsWrittenThisIteration;
                        $.$sm.System.Text.EncodingExtensions.Convert(decoder, firstSpan, writer, flush && isFinalSegment, $.$ref(() => charsWrittenThisIteration, ($v) => charsWrittenThisIteration = $v, $.$$.System.Int64), completed);
                        totalCharsWritten += charsWrittenThisIteration;
                        remainingBytes = remainingBytes.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    charsUsed.$v = totalCharsWritten;
                }
            }
            static $h = 1351175;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":917505,"p":[{"n":"encoding","p":121700353},{"n":"chars","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"writer","p":$.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte).$h}],"n":"GetBytes","d":1351175,"h":8591285767,"f":16777249},{"r":917505,"p":[{"n":"encoding","p":121700353},{"n":"chars","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char).$h,"f":8},{"n":"writer","p":$.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte).$h}],"n":"GetBytes","o":"@$2","d":1351175,"h":12886253063,"f":16777249},{"r":655361,"p":[{"n":"encoding","p":121700353},{"n":"chars","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char).$h,"f":8},{"n":"bytes","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"GetBytes","o":"@$1","d":1351175,"h":17181220359,"f":16777249},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"encoding","p":121700353},{"n":"chars","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char).$h,"f":8}],"n":"GetBytes","o":"@$3","d":1351175,"h":21476187655,"f":16777249},{"r":917505,"p":[{"n":"encoding","p":121700353},{"n":"bytes","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"writer","p":$.$sm.System.Buffers.IBufferWriter$$($.$$.System.Char).$h}],"n":"GetChars","d":1351175,"h":25771154951,"f":16777249},{"r":917505,"p":[{"n":"encoding","p":121700353},{"n":"bytes","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,"f":8},{"n":"writer","p":$.$sm.System.Buffers.IBufferWriter$$($.$$.System.Char).$h}],"n":"GetChars","o":"@$2","d":1351175,"h":30066122247,"f":16777249},{"r":655361,"p":[{"n":"encoding","p":121700353},{"n":"bytes","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,"f":8},{"n":"chars","p":$.$$.System.Span$$($.$$.System.Char).$h}],"n":"GetChars","o":"@$1","d":1351175,"h":34361089543,"f":16777249},{"r":1310721,"p":[{"n":"encoding","p":121700353},{"n":"bytes","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,"f":8}],"n":"GetString","d":1351175,"h":38656056839,"f":16777249},{"r":65537,"p":[{"n":"encoder","p":120979457},{"n":"chars","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"writer","p":$.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte).$h},{"n":"flush","p":262145},{"n":"bytesUsed","p":917505,"f":2},{"n":"completed","p":262145,"f":2}],"n":"Convert","o":"@$2","d":1351175,"h":42951024135,"f":16777249},{"r":65537,"p":[{"n":"encoder","p":120979457},{"n":"chars","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char).$h,"f":8},{"n":"writer","p":$.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte).$h},{"n":"flush","p":262145},{"n":"bytesUsed","p":917505,"f":2},{"n":"completed","p":262145,"f":2}],"n":"Convert","o":"@$3","d":1351175,"h":47245991431,"f":16777249},{"r":65537,"p":[{"n":"decoder","p":120389633},{"n":"bytes","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"writer","p":$.$sm.System.Buffers.IBufferWriter$$($.$$.System.Char).$h},{"n":"flush","p":262145},{"n":"charsUsed","p":917505,"f":2},{"n":"completed","p":262145,"f":2}],"n":"Convert","d":1351175,"h":51540958727,"f":16777249},{"r":65537,"p":[{"n":"decoder","p":120389633},{"n":"bytes","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,"f":8},{"n":"writer","p":$.$sm.System.Buffers.IBufferWriter$$($.$$.System.Char).$h},{"n":"flush","p":262145},{"n":"charsUsed","p":917505,"f":2},{"n":"completed","p":262145,"f":2}],"n":"Convert","o":"@$1","d":1351175,"h":55835926023,"f":16777249}],"l":[{"t":655361,"n":"MaxInputElementsPerIteration","d":1351175,"h":4296318471,"f":4194338}],"h":1351175}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.EncodingExtensions`; }
        });
        
        $asm.$cls("$sm.System.Buffers.ReadOnlySequence", ($self) => class ReadOnlySequence
        {
            /*int*/ static FlagBitMask = -2147483648;
            /*int*/ static IndexBitMask = 2147483647;
            /*int*/ static ArrayEndMask = -2147483648;
            /*int*/ static MemoryManagerStartMask = -2147483648;
            /*int*/ static StringStartMask = -2147483648;
            /*int*/ static StringEndMask = -2147483648;
            static /*int */ ArrayToSequenceEnd(/*int*/ endIndex)
            {
                return endIndex | -2147483648/*ArrayEndMask*/;
            }
            static /*int */ MemoryManagerToSequenceStart(/*int*/ startIndex)
            {
                return startIndex | -2147483648/*MemoryManagerStartMask*/;
            }
            static /*int */ StringToSequenceStart(/*int*/ startIndex)
            {
                return startIndex | -2147483648/*StringStartMask*/;
            }
            static /*int */ StringToSequenceEnd(/*int*/ endIndex)
            {
                return endIndex | -2147483648/*StringEndMask*/;
            }
            static $h = 499207;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":655361,"p":[{"n":"endIndex","p":655361}],"n":"ArrayToSequenceEnd","d":499207,"h":30065270279,"f":16777249},{"r":655361,"p":[{"n":"startIndex","p":655361}],"n":"MemoryManagerToSequenceStart","d":499207,"h":34360237575,"f":16777249},{"r":655361,"p":[{"n":"startIndex","p":655361}],"n":"StringToSequenceStart","d":499207,"h":38655204871,"f":16777249},{"r":655361,"p":[{"n":"endIndex","p":655361}],"n":"StringToSequenceEnd","d":499207,"h":42950172167,"f":16777249}],"l":[{"t":655361,"n":"FlagBitMask","d":499207,"h":4295466503,"f":4194337},{"t":655361,"n":"IndexBitMask","d":499207,"h":8590433799,"f":4194337},{"t":655361,"n":"ArrayEndMask","d":499207,"h":12885401095,"f":4194337},{"t":655361,"n":"MemoryManagerStartMask","d":499207,"h":17180368391,"f":4194337},{"t":655361,"n":"StringStartMask","d":499207,"h":21475335687,"f":4194337},{"t":655361,"n":"StringEndMask","d":499207,"h":25770302983,"f":4194337}],"h":499207}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Buffers.ReadOnlySequence`; }
        });
        
        $asm.$cls("$sm.System.Buffers.ArrayBufferWriter<>", (T) => $asm.$gt("$sm.System.Buffers.ArrayBufferWriter<>", [T], ($self) => class ArrayBufferWriter$$ extends $.$$.System.Object
        {
            /*int*/ static ArrayMaxLength = 2147483591;
            /*int*/ static DefaultInitialBufferSize = 256;
            /*T[]*/ _buffer = null;
            /*int*/ _index = 0;
            $ctor$1()
            {
                super.$ctor();
                {
                    this._buffer = $.$$.System.Array.Empty(T);
                    this._index = 0;
                }
                return this;
            }
            $ctor$2(/*int*/ initialCapacity)
            {
                super.$ctor();
                {
                    if (initialCapacity <= 0)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13(null, "initialCapacity");
                    }
                    this._buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [initialCapacity], null);
                    this._index = 0;
                }
                return this;
            }
            /*ReadOnlyMemory<T> */ get WrittenMemory()
            {
                return $.$$.System.Memory$$(T).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9(T, this._buffer, 0, this._index));
            }
            /*ReadOnlySpan<T> */ get WrittenSpan()
            {
                return $.$$.System.Span$$(T).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11(T, this._buffer, 0, this._index));
            }
            /*int */ get WrittenCount()
            {
                return this._index;
            }
            /*int */ get Capacity()
            {
                return this._buffer.length;
            }
            /*int */ get FreeCapacity()
            {
                return ((this._buffer.length - this._index) | 0);
            }
            /*void */ Clear()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this._buffer.length >= this._index, "_buffer.Length >= _index");
                $.$$.System.MemoryExtensions.AsSpan$11(T, this._buffer, 0, this._index).Clear();
                this._index = 0;
            }
            /*void */ ResetWrittenCount()
            {
                return this._index = 0;
            }
            /*void */ Advance(/*int*/ count)
            {
                if (count < 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13(null, "count");
                }
                if (this._index > ((this._buffer.length - count) | 0))
                {
                    $.$sm.System.Buffers.ArrayBufferWriter$$(T).ThrowInvalidOperationException_AdvancedTooFar(this._buffer.length);
                }
                this._index += count;
            }
            /*Memory<T> */ GetMemory(/*int*/ sizeHint)
            {
                this.CheckAndResizeBuffer(sizeHint);
                $.$$.System.Diagnostics.Debug.Assert$2(this._buffer.length > this._index, "_buffer.Length > _index");
                return $.$$.System.MemoryExtensions.AsMemory$10(T, this._buffer, this._index);
            }
            /*Span<T> */ GetSpan(/*int*/ sizeHint)
            {
                this.CheckAndResizeBuffer(sizeHint);
                $.$$.System.Diagnostics.Debug.Assert$2(this._buffer.length > this._index, "_buffer.Length > _index");
                return $.$$.System.MemoryExtensions.AsSpan$12(T, this._buffer, this._index);
            }
            /*void */ CheckAndResizeBuffer(/*int*/ sizeHint)
            {
                if (sizeHint < 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14("sizeHint");
                }
                if (sizeHint === 0)
                {
                    sizeHint = 1;
                }
                if (sizeHint > this.FreeCapacity)
                {
                    /*int*/ let currentLength = this._buffer.length;
                    /*int*/ let growBy = $.$$.System.Math.Max$4(sizeHint, currentLength);
                    if (currentLength === 0)
                    {
                        growBy = $.$$.System.Math.Max$4(growBy, 256/*DefaultInitialBufferSize*/);
                    }
                    /*int*/ let newSize = ((currentLength + growBy) | 0);
                    if ((newSize >>> 0) > 2147483647/*int.MaxValue*/)
                    {
                        /*uint*/ let needed = ((((((currentLength - this.FreeCapacity) | 0) + sizeHint) | 0)) >>> 0);
                        $.$$.System.Diagnostics.Debug.Assert$2(BigInt(needed) > BigInt(currentLength), "needed > currentLength");
                        if (needed > 2147483591/*ArrayMaxLength*/)
                        {
                            $.$sm.System.Buffers.ArrayBufferWriter$$(T).ThrowOutOfMemoryException(needed);
                        }
                        newSize = 2147483591/*ArrayMaxLength*/;
                    }
                    $.$$.System.Array.Resize(T, $.$ref(() => this._buffer, ($v) => this._buffer = $v, $.$typeArray(T)), newSize);
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this.FreeCapacity > 0 && this.FreeCapacity >= sizeHint, "FreeCapacity > 0 && FreeCapacity >= sizeHint");
            }
            static /*void */ ThrowInvalidOperationException_AdvancedTooFar(/*int*/ capacity)
            {
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$sm.System.SR.Format$6($.$sm.System.SR.BufferWriterAdvancedTooFar, $.$box(capacity, $.$$.System.Int32)));
            }
            static /*void */ ThrowOutOfMemoryException(/*uint*/ capacity)
            {
                throw new $.$$.System.OutOfMemoryException().$ctor$12($.$sm.System.SR.Format$6($.$sm.System.SR.BufferMaximumSizeExceeded, $.$box(capacity, $.$$.System.UInt32)));
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<T>.Advance(int)
            System$Buffers$IBufferWriter$$$Advance()
            {
                return this.Advance(...arguments);
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<T>.GetMemory(int)
            System$Buffers$IBufferWriter$$$GetMemory()
            {
                return this.GetMemory(...arguments);
            }
            //Generated interface implemetation for System.Buffers.IBufferWriter<T>.GetSpan(int)
            System$Buffers$IBufferWriter$$$GetSpan()
            {
                return this.GetSpan(...arguments);
            }
            static $h = 105991;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.ReadOnlyMemory$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x800000000n),"f":50331649},"n":"WrittenMemory","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":2097153},{"p":$.$$.System.ReadOnlySpan$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xA00000000n),"f":50331649},"n":"WrittenSpan","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xC00000000n),"f":50331649},"n":"WrittenCount","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0xE00000000n),"f":50331649},"n":"Capacity","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1000000000n),"f":50331649},"n":"FreeCapacity","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":2097153}],"m":[{"r":65537,"n":"Clear","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16777217},{"r":65537,"n":"ResetWrittenCount","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16777217},{"r":65537,"p":[{"n":"count","p":655361}],"n":"Advance","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":16777217},{"r":$.$$.System.Memory$$(T).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetMemory","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777217},{"r":$.$$.System.Span$$(T).$h,"p":[{"n":"sizeHint","p":655361,"f":65,"v":0}],"n":"GetSpan","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16777217},{"r":65537,"p":[{"n":"sizeHint","p":655361}],"n":"CheckAndResizeBuffer","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":16777218},{"r":65537,"p":[{"n":"capacity","p":655361}],"n":"ThrowInvalidOperationException_AdvancedTooFar","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":16777250},{"r":65537,"p":[{"n":"capacity","p":720897}],"n":"ThrowOutOfMemoryException","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":16777250}],"l":[{"t":655361,"n":"ArrayMaxLength","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194338},{"t":655361,"n":"DefaultInitialBufferSize","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194338},{"t":$.$typeArray(T).$h,"n":"_buffer","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306},{"t":655361,"n":"_index","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217},{"p":[{"n":"initialCapacity","p":655361}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777217}],"i":[$.$sm.System.Buffers.IBufferWriter$$(T).$h],"g":[T?.$h??1507328],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$(T) ]; }
            static get $fullName() { return `System.Buffers.ArrayBufferWriter<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$sm.System.Buffers.ReadOnlySequence<>", (T) => $asm.$gt("$sm.System.Buffers.ReadOnlySequence<>", [T], ($self) => class ReadOnlySequence$$ extends $.$$.System.ValueType
        {
            /*bool */ TryGetBuffer(/*in SequencePosition*/ position, /*out ReadOnlyMemory<T>*/ memory, /*out SequencePosition*/ next)
            {
                /*object?*/ let positionObject = position.$v.GetObject();
                next.$v = new $.$sm.System.SequencePosition();
                if (positionObject === null)
                {
                    memory.$v = new ($.$$.System.ReadOnlyMemory$$(T))();
                    return false;
                }
                /*SequenceType*/ let type = this.GetSequenceType();
                /*object?*/ let endObject = this._endObject;
                /*int*/ let startIndex = position.$v.GetInteger();
                /*int*/ let endIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                if (type === 0/*SequenceType.MultiSegment*/)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$is(positionObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T)), "positionObject is ReadOnlySequenceSegment<T>");
                    /*ReadOnlySequenceSegment<T>*/ let startSegment = $.$cast(positionObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                    if (startSegment !== endObject)
                    {
                        /*ReadOnlySequenceSegment<T>?*/ let nextSegment = startSegment.Next;
                        if (nextSegment === null)
                        {
                            $.$sm.System.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                        }
                        next.$v = new $.$sm.System.SequencePosition().$ctor$3(nextSegment, 0);
                        memory.$v = startSegment.Memory.Slice$1(startIndex);
                    }
                    else 
                    {
                        memory.$v = startSegment.Memory.Slice(startIndex, ((endIndex - startIndex) | 0));
                    }
                }
                else 
                {
                    if (positionObject !== endObject)
                    {
                        $.$sm.System.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                    }
                    if (type === 1/*SequenceType.Array*/)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$is(positionObject, $.$typeArray(T)), "positionObject is T[]");
                        memory.$v = new ($.$$.System.ReadOnlyMemory$$(T))().$ctor$4($.$cast(positionObject, $.$typeArray(T)), startIndex, ((endIndex - startIndex) | 0));
                    }
                    else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Char.$type) && type === 3/*SequenceType.String*/)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$is(positionObject, $.$$.System.String), "positionObject is string");
                        memory.$v = $.$cast($.$cast($.$$.System.MemoryExtensions.AsMemory$1(($.$cast(positionObject, $.$$.System.String)), startIndex, ((endIndex - startIndex) | 0)), $.$$.System.Object), $.$$.System.ReadOnlyMemory$$(T));
                    }
                    else 
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(type === 2/*SequenceType.MemoryManager*/, "type == SequenceType.MemoryManager");
                        $.$$.System.Diagnostics.Debug.Assert$2($.$is(positionObject, $.$$.System.Buffers.MemoryManager$$(T)), "positionObject is MemoryManager<T>");
                        memory.$v = $.$$.System.Memory$$(T).op_Implicit$2(($.$cast(positionObject, $.$$.System.Buffers.MemoryManager$$(T))).Memory.Slice(startIndex, ((endIndex - startIndex) | 0)));
                    }
                }
                return true;
            }
            /*ReadOnlyMemory<T> */ GetFirstBuffer()
            {
                /*object?*/ let startObject = this._startObject;
                if (startObject === null)
                {
                    return new ($.$$.System.ReadOnlyMemory$$(T))();
                }
                /*int*/ let startIndex = this._startInteger;
                /*int*/ let endIndex = this._endInteger;
                /*bool*/ let isMultiSegment = startObject !== this._endObject;
                if ((startIndex | endIndex) >= 0)
                {
                    /*ReadOnlyMemory<T>*/ let memory = ($.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).Memory;
                    if (isMultiSegment)
                    {
                        return memory.Slice$1(startIndex);
                    }
                    return memory.Slice(startIndex, ((endIndex - startIndex) | 0));
                }
                else 
                {
                    return this.GetFirstBufferSlow(startObject, isMultiSegment);
                }
            }
            /*ReadOnlyMemory<T> */ GetFirstBufferSlow(/*object*/ startObject, /*bool*/ isMultiSegment)
            {
                if (isMultiSegment)
                {
                    $.$sm.System.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                }
                /*int*/ let startIndex = this._startInteger;
                /*int*/ let endIndex = this._endInteger;
                $.$$.System.Diagnostics.Debug.Assert$2(startIndex < 0 || endIndex < 0, "startIndex < 0 || endIndex < 0");
                if (startIndex >= 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(endIndex < 0, "endIndex < 0");
                    return new ($.$$.System.ReadOnlyMemory$$(T))().$ctor$4($.$cast(startObject, $.$typeArray(T)), startIndex, (((endIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/) - startIndex) | 0));
                }
                else 
                {
                    if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Char.$type) && endIndex < 0)
                    {
                        return $.$cast($.$cast($.$$.System.MemoryExtensions.AsMemory$1(($.$cast(startObject, $.$$.System.String)), startIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/, ((endIndex - startIndex) | 0)), $.$$.System.Object), $.$$.System.ReadOnlyMemory$$(T));
                    }
                    else 
                    {
                        startIndex &= 2147483647/*ReadOnlySequence.IndexBitMask*/;
                        return $.$$.System.Memory$$(T).op_Implicit$2(($.$cast(startObject, $.$$.System.Buffers.MemoryManager$$(T))).Memory.Slice(startIndex, ((endIndex - startIndex) | 0)));
                    }
                }
            }
            /*ReadOnlySpan<T> */ GetFirstSpan()
            {
                /*object?*/ let startObject = this._startObject;
                if (startObject === null)
                {
                    return new ($.$$.System.ReadOnlySpan$$(T))();
                }
                /*int*/ let startIndex = this._startInteger;
                /*int*/ let endIndex = this._endInteger;
                /*bool*/ let isMultiSegment = startObject !== this._endObject;
                if ((startIndex | endIndex) >= 0)
                {
                    /*ReadOnlySpan<T>*/ let span = ($.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).Memory.Span;
                    if (isMultiSegment)
                    {
                        return span.Slice$1(startIndex);
                    }
                    return span.Slice(startIndex, ((endIndex - startIndex) | 0));
                }
                else 
                {
                    return this.GetFirstSpanSlow(startObject, isMultiSegment);
                }
            }
            /*ReadOnlySpan<T> */ GetFirstSpanSlow(/*object*/ startObject, /*bool*/ isMultiSegment)
            {
                if (isMultiSegment)
                {
                    $.$sm.System.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                }
                /*int*/ let startIndex = this._startInteger;
                /*int*/ let endIndex = this._endInteger;
                $.$$.System.Diagnostics.Debug.Assert$2(startIndex < 0 || endIndex < 0, "startIndex < 0 || endIndex < 0");
                if (startIndex >= 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(endIndex < 0, "endIndex < 0");
                    /*ReadOnlySpan<T>*/ let span = $.$$.System.ReadOnlySpan$$(T).op_Implicit$1($.$cast(startObject, $.$typeArray(T)));
                    return span.Slice(startIndex, (((endIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/) - startIndex) | 0));
                }
                else 
                {
                    if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Char.$type) && endIndex < 0)
                    {
                        /*var*/ let memory = $.$cast($.$cast($.$$.System.MemoryExtensions.AsMemory$4(($.$cast(startObject, $.$$.System.String))), $.$$.System.Object), $.$$.System.ReadOnlyMemory$$(T));
                        return memory.Span.Slice(startIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/, ((endIndex - startIndex) | 0));
                    }
                    else 
                    {
                        startIndex &= 2147483647/*ReadOnlySequence.IndexBitMask*/;
                        return $.$$.System.Span$$(T).op_Implicit(($.$cast(startObject, $.$$.System.Buffers.MemoryManager$$(T))).Memory.Span.Slice(startIndex, ((endIndex - startIndex) | 0)));
                    }
                }
            }
            /*SequencePosition */ Seek(/*long*/ offset, /*ExceptionArgument*/ exceptionArgument)
            {
                /*object?*/ let startObject;
                /*object?*/ let endObject;
                /*int*/ let startIndex;
                /*int*/ let endIndex;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            startObject = this._startObject;
                            endObject = this._endObject;
                            startIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                            endIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                            if (startObject !== endObject)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(startObject !== null, "startObject != null");
                                /*var*/ let startSegment = $.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                                /*int*/ let currentLength = ((startSegment.Memory.Length - startIndex) | 0);
                                if (BigInt(currentLength) > offset || offset === 0n)
                                {
                                    $gotoJumpState1 = 1; /*goto IsSingleSegment*/
                                    continue $gotoJumpStart1;
                                }
                                if (currentLength < 0)
                                {
                                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                return $.$sm.System.Buffers.ReadOnlySequence$$(T).SeekMultiSegment(startSegment.Next, endObject, endIndex, offset - BigInt(currentLength), exceptionArgument);
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2(startObject === endObject, "startObject == endObject");
                            if (BigInt(endIndex - startIndex) < offset)
                            {
                                $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(exceptionArgument);
                            }
                        }
                        case 1: /*IsSingleSegment*/
                        return new $.$sm.System.SequencePosition().$ctor$3(startObject, ((startIndex + $.$cast(offset, $.$$.System.Int32)) | 0));
                    }
                    break;
                }
            }
            /*SequencePosition */ Seek$1(/*in SequencePosition*/ start, /*long*/ offset)
            {
                /*object?*/ let startObject;
                /*object?*/ let endObject;
                /*int*/ let startIndex;
                /*int*/ let endIndex;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            startObject = start.$v.GetObject();
                            endObject = this._endObject;
                            startIndex = start.$v.GetInteger();
                            endIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                            if (startObject !== endObject)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(startObject !== null, "startObject != null");
                                /*var*/ let startSegment = $.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                                /*int*/ let currentLength = ((startSegment.Memory.Length - startIndex) | 0);
                                if (BigInt(currentLength) > offset)
                                {
                                    $gotoJumpState1 = 1; /*goto IsSingleSegment*/
                                    continue $gotoJumpStart1;
                                }
                                if (currentLength < 0)
                                {
                                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                return $.$sm.System.Buffers.ReadOnlySequence$$(T).SeekMultiSegment(startSegment.Next, endObject, endIndex, offset - BigInt(currentLength), 7/*ExceptionArgument.offset*/);
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2(startObject === endObject, "startObject == endObject");
                            if (BigInt(endIndex - startIndex) < offset)
                            {
                                $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(7/*ExceptionArgument.offset*/);
                            }
                        }
                        case 1: /*IsSingleSegment*/
                        return new $.$sm.System.SequencePosition().$ctor$3(startObject, ((startIndex + $.$cast(offset, $.$$.System.Int32)) | 0));
                    }
                    break;
                }
            }
            static /*SequencePosition */ SeekMultiSegment(/*ReadOnlySequenceSegment<T>?*/ currentSegment, /*object*/ endObject, /*int*/ endIndex, /*long*/ offset, /*ExceptionArgument*/ argument)
            {
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(currentSegment !== null, "currentSegment != null");
                            $.$$.System.Diagnostics.Debug.Assert$2(offset >= 0n, "offset >= 0");
                            while(currentSegment !== null && currentSegment !== endObject)
                            {
                                /*int*/ let memoryLength = currentSegment.Memory.Length;
                                if (BigInt(memoryLength) > offset)
                                {
                                    $gotoJumpState1 = 1; /*goto FoundSegment*/
                                    continue $gotoJumpStart1;
                                }
                                offset -= BigInt(memoryLength);
                                currentSegment = currentSegment.Next;
                            }
                            if (currentSegment === null || BigInt(endIndex) < offset)
                            {
                                $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(argument);
                            }
                        }
                        case 1: /*FoundSegment*/
                        return new $.$sm.System.SequencePosition().$ctor$3(currentSegment, $.$cast(offset, $.$$.System.Int32));
                    }
                    break;
                }
            }
            /*void */ BoundsCheck$1(/*in SequencePosition*/ position, /*bool*/ positionIsNotNull)
            {
                /*uint*/ let sliceStartIndex = (position.$v.GetInteger() >>> 0);
                /*object?*/ let startObject = this._startObject;
                /*object?*/ let endObject = this._endObject;
                /*uint*/ let startIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger) >>> 0);
                /*uint*/ let endIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger) >>> 0);
                if (startObject === endObject)
                {
                    if (!$.$sm.System.Buffers.ReadOnlySequence$$(T).InRange(sliceStartIndex, startIndex, endIndex))
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                }
                else 
                {
                    /*ulong*/ let startRange = $.$cast((($.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(startIndex)), $.$$.System.UInt64);
                    /*long*/ let runningIndex = 0n;
                    if (positionIsNotNull)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(position.$v.GetObject() !== null, "position.GetObject() != null");
                        runningIndex = ($.$cast(position.$v.GetObject(), $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex;
                    }
                    if (!$.$sm.System.Buffers.ReadOnlySequence$$(T).InRange$1($.$cast((runningIndex + BigInt(sliceStartIndex)), $.$$.System.UInt64), startRange, $.$cast((($.$cast(endObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(endIndex)), $.$$.System.UInt64)))
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                }
            }
            /*void */ BoundsCheck(/*uint*/ sliceStartIndex, /*object?*/ sliceStartObject, /*uint*/ sliceEndIndex, /*object?*/ sliceEndObject)
            {
                /*object?*/ let startObject = this._startObject;
                /*object?*/ let endObject = this._endObject;
                /*uint*/ let startIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger) >>> 0);
                /*uint*/ let endIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger) >>> 0);
                if (startObject === endObject)
                {
                    if (sliceStartObject !== sliceEndObject || sliceStartObject !== startObject || sliceStartIndex > sliceEndIndex || sliceStartIndex < startIndex || sliceEndIndex > endIndex)
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(sliceStartIndex >= 0 && startIndex >= 0 && endIndex >= 0, "sliceStartIndex >= 0 && startIndex >= 0 && endIndex >= 0");
                    /*ulong*/ let sliceStartRange = BigInt(sliceStartIndex);
                    /*ulong*/ let sliceEndRange = BigInt(sliceEndIndex);
                    if (sliceStartObject !== null)
                    {
                        sliceStartRange += $.$cast(($.$cast(sliceStartObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex, $.$$.System.UInt64);
                    }
                    if (sliceEndObject !== null)
                    {
                        sliceEndRange += $.$cast(($.$cast(sliceEndObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex, $.$$.System.UInt64);
                    }
                    if (sliceStartRange > sliceEndRange)
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                    if (sliceStartRange < $.$cast((($.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(startIndex)), $.$$.System.UInt64) || sliceEndRange > $.$cast((($.$cast(endObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(endIndex)), $.$$.System.UInt64))
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                }
            }
            static /*SequencePosition */ GetEndPosition(/*ReadOnlySequenceSegment<T>*/ startSegment, /*object*/ startObject, /*int*/ startIndex, /*object*/ endObject, /*int*/ endIndex, /*long*/ length)
            {
                /*int*/ let currentLength = ((startSegment.Memory.Length - startIndex) | 0);
                if (BigInt(currentLength) > length)
                {
                    return new $.$sm.System.SequencePosition().$ctor$3(startObject, ((startIndex + $.$cast(length, $.$$.System.Int32)) | 0));
                }
                if (currentLength < 0)
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                }
                return $.$sm.System.Buffers.ReadOnlySequence$$(T).SeekMultiSegment(startSegment.Next, endObject, endIndex, length - BigInt(currentLength), 0/*ExceptionArgument.length*/);
            }
            /*SequenceType */ GetSequenceType()
            {
                return $.$cast((-(((((2 * (this._startInteger >> 31)) | 0) + (this._endInteger >> 31)) | 0))), $.$sm.System.Buffers.ReadOnlySequence$$(T).SequenceType);
            }
            static /*int */ GetIndex(/*int*/ Integer)
            {
                return Integer & 2147483647/*ReadOnlySequence.IndexBitMask*/;
            }
            /*ReadOnlySequence<T> */ SliceImpl(/*in SequencePosition*/ start, /*in SequencePosition*/ end)
            {
                return new ($.$sm.System.Buffers.ReadOnlySequence$$(T))().$ctor$3(start.$v.GetObject(), start.$v.GetInteger() | (this._startInteger & -2147483648/*ReadOnlySequence.FlagBitMask*/), end.$v.GetObject(), end.$v.GetInteger() | (this._endInteger & -2147483648/*ReadOnlySequence.FlagBitMask*/));
            }
            /*ReadOnlySequence<T> */ SliceImpl$1(/*in SequencePosition*/ start)
            {
                return new ($.$sm.System.Buffers.ReadOnlySequence$$(T))().$ctor$3(start.$v.GetObject(), start.$v.GetInteger() | (this._startInteger & -2147483648/*ReadOnlySequence.FlagBitMask*/), this._endObject, this._endInteger);
            }
            /*long */ GetLength()
            {
                /*object?*/ let startObject = this._startObject;
                /*object?*/ let endObject = this._endObject;
                /*int*/ let startIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                /*int*/ let endIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                if (startObject !== endObject)
                {
                    /*var*/ let startSegment = $.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                    /*var*/ let endSegment = $.$cast(endObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                    return (endSegment.RunningIndex + BigInt(endIndex)) - (startSegment.RunningIndex + BigInt(startIndex));
                }
                return BigInt(endIndex - startIndex);
            }
            /*bool */ TryGetReadOnlySequenceSegment(/*out ReadOnlySequenceSegment<T>?*/ startSegment, /*out int*/ startIndex, /*out ReadOnlySequenceSegment<T>?*/ endSegment, /*out int*/ endIndex)
            {
                /*object?*/ let startObject = this._startObject;
                if (startObject === null || this.GetSequenceType() !== 0/*SequenceType.MultiSegment*/)
                {
                    startSegment.$v = null;
                    startIndex.$v = 0;
                    endSegment.$v = null;
                    endIndex.$v = 0;
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this._endObject !== null, "_endObject != null");
                startSegment.$v = $.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                startIndex.$v = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                endSegment.$v = $.$cast(this._endObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                endIndex.$v = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                return true;
            }
            /*bool */ TryGetArray(/*out ArraySegment<T>*/ segment)
            {
                if (this.GetSequenceType() !== 1/*SequenceType.Array*/)
                {
                    segment.$v = new ($.$$.System.ArraySegment$$(T))();
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this._startObject !== null, "_startObject != null");
                /*int*/ let startIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                segment.$v = new ($.$$.System.ArraySegment$$(T))().$ctor$3($.$cast(this._startObject, $.$typeArray(T)), startIndex, (($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger) - startIndex) | 0));
                return true;
            }
            /*bool */ TryGetString(/*out string?*/ text, /*out int*/ start, /*out int*/ length)
            {
                if ($.$$.System.Type.op_Inequality$1(T.$type, $.$$.System.Char.$type) || this.GetSequenceType() !== 3/*SequenceType.String*/)
                {
                    start.$v = 0;
                    length.$v = 0;
                    text.$v = null;
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this._startObject !== null, "_startObject != null");
                start.$v = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                length.$v = (($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger) - start.$v) | 0);
                text.$v = $.$cast(this._startObject, $.$$.System.String);
                return true;
            }
            static /*bool */ InRange(/*uint*/ value, /*uint*/ start, /*uint*/ end)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(start <= 2147483647/*int.MaxValue*/, "start <= int.MaxValue");
                $.$$.System.Diagnostics.Debug.Assert$2(end <= 2147483647/*int.MaxValue*/, "end <= int.MaxValue");
                $.$$.System.Diagnostics.Debug.Assert$2(start <= end, "start <= end");
                return ((((value - start) >>> 0)) >>> 0) <= ((((end - start) >>> 0)) >>> 0);
            }
            static /*bool */ InRange$1(/*ulong*/ value, /*ulong*/ start, /*ulong*/ end)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(start <= 9223372036854775807n, "start <= long.MaxValue");
                $.$$.System.Diagnostics.Debug.Assert$2(end <= 9223372036854775807n, "end <= long.MaxValue");
                $.$$.System.Diagnostics.Debug.Assert$2(start <= end, "start <= end");
                return (value - start) <= (end - start);
            }
            /*void */ GetFirstSpan$1(/*out ReadOnlySpan<T>*/ first, /*out SequencePosition*/ next)
            {
                first.$v = new ($.$$.System.ReadOnlySpan$$(T))();
                next.$v = new $.$sm.System.SequencePosition();
                /*object?*/ let startObject = this._startObject;
                /*int*/ let startIndex = this._startInteger;
                if (startObject !== null)
                {
                    /*bool*/ let hasMultipleSegments = startObject !== this._endObject;
                    /*int*/ let endIndex = this._endInteger;
                    if (startIndex >= 0)
                    {
                        if (endIndex >= 0)
                        {
                            /*ReadOnlySequenceSegment<T>*/ let segment = $.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                            first.$v = segment.Memory.Span;
                            if (hasMultipleSegments)
                            {
                                first.$v = first.$v.Slice$1(startIndex);
                                next.$v = new $.$sm.System.SequencePosition().$ctor$3(segment.Next, 0);
                            }
                            else 
                            {
                                first.$v = first.$v.Slice(startIndex, ((endIndex - startIndex) | 0));
                            }
                        }
                        else 
                        {
                            if (hasMultipleSegments)
                            {
                                $.$sm.System.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                            }
                            first.$v = new ($.$$.System.ReadOnlySpan$$(T))().$ctor$3($.$cast(startObject, $.$typeArray(T)), startIndex, (((endIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/) - startIndex) | 0));
                        }
                    }
                    else 
                    {
                        first.$v = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetFirstSpanSlow$1(startObject, startIndex, endIndex, hasMultipleSegments);
                    }
                }
            }
            static /*ReadOnlySpan<T> */ GetFirstSpanSlow$1(/*object*/ startObject, /*int*/ startIndex, /*int*/ endIndex, /*bool*/ hasMultipleSegments)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(startIndex < 0, "startIndex < 0");
                if (hasMultipleSegments)
                {
                    $.$sm.System.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                }
                if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Char.$type) && endIndex < 0)
                {
                    /*ReadOnlySpan<char>*/ let spanOfChar = $.$$.System.MemoryExtensions.AsSpan$1(($.$cast(startObject, $.$$.System.String)), startIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/, ((endIndex - startIndex) | 0));
                    return $.$$.System.Runtime.InteropServices.MemoryMarshal.CreateReadOnlySpan(T, $.$$.System.Runtime.CompilerServices.Unsafe.As($.$$.System.Char, T, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Char, spanOfChar)), spanOfChar.Length);
                }
                else 
                {
                    startIndex &= 2147483647/*ReadOnlySequence.IndexBitMask*/;
                    return $.$$.System.Span$$(T).op_Implicit(($.$cast(startObject, $.$$.System.Buffers.MemoryManager$$(T))).Memory.Span.Slice(startIndex, ((endIndex - startIndex) | 0)));
                }
            }
            /*object?*/  get _startObject() { return this.$getField(0, 4); }
            /*object?*/  set _startObject(value) { this.$setField(0, 4, value); }
            /*object?*/  get _endObject() { return this.$getField(4, 4); }
            /*object?*/  set _endObject(value) { this.$setField(4, 4, value); }
            /*int*/  get _startInteger() { return this.$getField(8, 4); }
            /*int*/  set _startInteger(value) { this.$setField(8, 4, value); }
            /*int*/  get _endInteger() { return this.$getField(12, 4); }
            /*int*/  set _endInteger(value) { this.$setField(12, 4, value); }
            /*ReadOnlySequence<T>*/ static Empty;
            /*long */ get Length()
            {
                return this.GetLength();
            }
            /*bool */ get IsEmpty()
            {
                return this.Length === 0n;
            }
            /*bool */ get IsSingleSegment()
            {
                return this._startObject === this._endObject;
            }
            /*ReadOnlyMemory<T> */ get First()
            {
                return this.GetFirstBuffer();
            }
            /*ReadOnlySpan<T> */ get FirstSpan()
            {
                return this.GetFirstSpan();
            }
            /*SequencePosition */ get Start()
            {
                return new $.$sm.System.SequencePosition().$ctor$3(this._startObject, $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger));
            }
            /*SequencePosition */ get End()
            {
                return new $.$sm.System.SequencePosition().$ctor$3(this._endObject, $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger));
            }
            $ctor$3(/*object?*/ startSegment, /*int*/ startIndexAndFlags, /*object?*/ endSegment, /*int*/ endIndexAndFlags)
            {
                super.$ctor$1();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2((startSegment !== null && endSegment !== null) || (startSegment === null && endSegment === null && startIndexAndFlags === 0 && endIndexAndFlags === 0), "(startSegment != null && endSegment != null) ||\r\n                (startSegment == null && endSegment == null && startIndexAndFlags == 0 && endIndexAndFlags == 0)");
                    this._startObject = startSegment;
                    this._endObject = endSegment;
                    this._startInteger = startIndexAndFlags;
                    this._endInteger = endIndexAndFlags;
                }
                return this;
            }
            $ctor$7(/*ReadOnlySequenceSegment<T>*/ startSegment, /*int*/ startIndex, /*ReadOnlySequenceSegment<T>*/ endSegment, /*int*/ endIndex)
            {
                super.$ctor$1();
                {
                    if (startSegment === null || endSegment === null || (startSegment !== endSegment && startSegment.RunningIndex > endSegment.RunningIndex) || (startSegment.Memory.Length >>> 0) < (startIndex >>> 0) || (endSegment.Memory.Length >>> 0) < (endIndex >>> 0) || (startSegment === endSegment && endIndex < startIndex))
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentValidationException$1(T, startSegment, startIndex, endSegment);
                    }
                    this._startObject = startSegment;
                    this._endObject = endSegment;
                    this._startInteger = startIndex;
                    this._endInteger = endIndex;
                }
                return this;
            }
            $ctor$6(/*T[]*/ array)
            {
                super.$ctor$1();
                {
                    if (array === null)
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.array*/);
                    }
                    this._startObject = array;
                    this._endObject = array;
                    this._startInteger = 0;
                    this._endInteger = $.$sm.System.Buffers.ReadOnlySequence.ArrayToSequenceEnd(array.length);
                }
                return this;
            }
            $ctor$5(/*T[]*/ array, /*int*/ start, /*int*/ length)
            {
                super.$ctor$1();
                {
                    if (array === null || (start >>> 0) > (array.length >>> 0) || (length >>> 0) > ((((array.length - start) | 0)) >>> 0))
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentValidationException(array, start);
                    }
                    this._startObject = array;
                    this._endObject = array;
                    this._startInteger = start;
                    this._endInteger = $.$sm.System.Buffers.ReadOnlySequence.ArrayToSequenceEnd(((start + length) | 0));
                }
                return this;
            }
            $ctor$4(/*ReadOnlyMemory<T>*/ memory)
            {
                super.$ctor$1();
                {
                    /*MemoryManager<T>?*/ let manager;
                    /*int*/ let index;
                    /*int*/ let length;
                    /*ArraySegment<T>*/ let segment;
                    if ($.$$.System.Runtime.InteropServices.MemoryMarshal.TryGetMemoryManager(T, $.$$.System.Buffers.MemoryManager$$(T), memory, $.$ref(() => manager, ($v) => manager = $v, $.$$.System.Buffers.MemoryManager$$(T)), $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32)))
                    {
                        this._startObject = manager;
                        this._endObject = manager;
                        this._startInteger = $.$sm.System.Buffers.ReadOnlySequence.MemoryManagerToSequenceStart(index);
                        this._endInteger = ((index + length) | 0);
                    }
                    else if ($.$$.System.Runtime.InteropServices.MemoryMarshal.TryGetArray(T, memory, $.$ref(() => segment, ($v) => segment = $v, $.$$.System.ArraySegment$$(T))))
                    {
                        /*T[]?*/ let array = segment.Array;
                        /*int*/ let start = segment.Offset;
                        this._startObject = array;
                        this._endObject = array;
                        this._startInteger = start;
                        this._endInteger = $.$sm.System.Buffers.ReadOnlySequence.ArrayToSequenceEnd(((start + segment.Count) | 0));
                    }
                    else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Char.$type))
                    {
                        /*string?*/ let text;
                        /*int*/ let start;
                        if (!$.$$.System.Runtime.InteropServices.MemoryMarshal.TryGetString($.$cast($.$cast(memory, $.$$.System.Object), $.$$.System.ReadOnlyMemory$$($.$$.System.Char)), $.$ref(() => text, ($v) => text = $v, $.$$.System.String), $.$ref(() => start, ($v) => start = $v, $.$$.System.Int32), $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32)))
                        {
                            $.$sm.System.ThrowHelper.ThrowInvalidOperationException();
                        }
                        this._startObject = text;
                        this._endObject = text;
                        this._startInteger = $.$sm.System.Buffers.ReadOnlySequence.StringToSequenceStart(start);
                        this._endInteger = $.$sm.System.Buffers.ReadOnlySequence.StringToSequenceEnd(((start + length) | 0));
                    }
                    else 
                    {
                        $.$sm.System.ThrowHelper.ThrowInvalidOperationException();
                        this._startObject = null;
                        this._endObject = null;
                        this._startInteger = 0;
                        this._endInteger = 0;
                    }
                }
                return this;
            }
            /*ReadOnlySequence<T> */ Slice$2(/*long*/ start, /*long*/ length)
            {
                if (start < 0n || length < 0n)
                {
                    $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(start);
                }
                /*SequencePosition*/ let begin;
                /*SequencePosition*/ let end;
                /*int*/ let startIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                /*int*/ let endIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                /*object?*/ let startObject = this._startObject;
                /*object?*/ let endObject = this._endObject;
                if (startObject !== endObject)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(startObject !== null, "startObject != null");
                    /*var*/ let startSegment = $.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                    /*int*/ let currentLength = ((startSegment.Memory.Length - startIndex) | 0);
                    if (BigInt(currentLength) > start)
                    {
                        startIndex += $.$cast(start, $.$$.System.Int32);
                        begin = new $.$sm.System.SequencePosition().$ctor$3(startObject, startIndex);
                        end = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetEndPosition(startSegment, startObject, startIndex, endObject, endIndex, length);
                    }
                    else 
                    {
                        if (currentLength < 0)
                        {
                            $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                        }
                        begin = $.$sm.System.Buffers.ReadOnlySequence$$(T).SeekMultiSegment(startSegment.Next, endObject, endIndex, start - BigInt(currentLength), 1/*ExceptionArgument.start*/);
                        /*int*/ let beginIndex = begin.GetInteger();
                        /*object*/ let beginObject = begin.GetObject();
                        if (beginObject !== endObject)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(beginObject !== null, "beginObject != null");
                            end = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetEndPosition($.$cast(beginObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T)), beginObject, beginIndex, endObject, endIndex, length);
                        }
                        else 
                        {
                            if (BigInt(endIndex - beginIndex) < length)
                            {
                                $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(0n);
                            }
                            end = new $.$sm.System.SequencePosition().$ctor$3(beginObject, ((beginIndex + $.$cast(length, $.$$.System.Int32)) | 0));
                        }
                    }
                }
                else 
                {
                    if (BigInt(endIndex - startIndex) < start)
                    {
                        $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(BigInt(-1));
                    }
                    startIndex += $.$cast(start, $.$$.System.Int32);
                    begin = new $.$sm.System.SequencePosition().$ctor$3(startObject, startIndex);
                    if (BigInt(endIndex - startIndex) < length)
                    {
                        $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(0n);
                    }
                    end = new $.$sm.System.SequencePosition().$ctor$3(startObject, ((startIndex + $.$cast(length, $.$$.System.Int32)) | 0));
                }
                return this.SliceImpl($.$ref(() => begin, ), $.$ref(() => end, ));
            }
            /*ReadOnlySequence<T> */ Slice$3(/*long*/ start, /*SequencePosition*/ end)
            {
                /*uint*/ let startIndex;
                /*object?*/ let startObject;
                /*uint*/ let endIndex;
                /*object?*/ let endObject;
                /*uint*/ let sliceEndIndex;
                /*object?*/ let sliceEndObject;
                /*var*/ let startSegment;
                /*ulong*/ let startRange;
                /*ulong*/ let sliceRange;
                /*int*/ let currentLength;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            if (start < 0n)
                            {
                                $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(start);
                            }
                            startIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger) >>> 0);
                            startObject = this._startObject;
                            endIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger) >>> 0);
                            endObject = this._endObject;
                            sliceEndIndex = (end.GetInteger() >>> 0);
                            sliceEndObject = end.GetObject();
                            if (sliceEndObject === null)
                            {
                                sliceEndObject = this._startObject;
                                sliceEndIndex = startIndex;
                            }
                            if (startObject === endObject)
                            {
                                if (!$.$sm.System.Buffers.ReadOnlySequence$$(T).InRange(sliceEndIndex, startIndex, endIndex))
                                {
                                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                if (BigInt(sliceEndIndex - startIndex) < start)
                                {
                                    $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(BigInt(-1));
                                }
                                $gotoJumpState1 = 1; /*goto FoundInFirstSegment*/
                                continue $gotoJumpStart1;
                            }
                            startSegment = $.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                            startRange = $.$cast((startSegment.RunningIndex + BigInt(startIndex)), $.$$.System.UInt64);
                            sliceRange = $.$cast((($.$cast(sliceEndObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(sliceEndIndex)), $.$$.System.UInt64);
                            $.$$.System.Diagnostics.Debug.Assert$2(sliceEndIndex >= 0 && startIndex >= 0 && endIndex >= 0, "sliceEndIndex >= 0 && startIndex >= 0 && endIndex >= 0");
                            if (!$.$sm.System.Buffers.ReadOnlySequence$$(T).InRange$1(sliceRange, startRange, $.$cast((($.$cast(endObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(endIndex)), $.$$.System.UInt64)))
                            {
                                $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                            }
                            if (startRange + $.$cast(start, $.$$.System.UInt64) > sliceRange)
                            {
                                $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.start*/);
                            }
                            currentLength = ((startSegment.Memory.Length - (startIndex | 0)) | 0);
                            if (BigInt(currentLength) <= start)
                            {
                                if (currentLength < 0)
                                {
                                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                /*SequencePosition*/ let begin = $.$sm.System.Buffers.ReadOnlySequence$$(T).SeekMultiSegment(startSegment.Next, sliceEndObject, (sliceEndIndex | 0), start - BigInt(currentLength), 1/*ExceptionArgument.start*/);
                                return this.SliceImpl($.$ref(() => begin, ), $.$ref(() => end, ));
                            }
                        }
                        case 1: /*FoundInFirstSegment*/
                        $.$$.System.Diagnostics.Debug.Assert$2(start <= BigInt(2147483647/*int.MaxValue*/ - startIndex), "start <= int.MaxValue - startIndex");
                        return this.SliceImpl($.$ref(() => new $.$sm.System.SequencePosition().$ctor$3(startObject, (((startIndex | 0) + $.$cast(start, $.$$.System.Int32)) | 0)), ), $.$ref(() => new $.$sm.System.SequencePosition().$ctor$3(sliceEndObject, (sliceEndIndex | 0)), ));
                    }
                    break;
                }
            }
            /*ReadOnlySequence<T> */ Slice$6(/*SequencePosition*/ start, /*long*/ length)
            {
                /*uint*/ let startIndex;
                /*object?*/ let startObject;
                /*uint*/ let endIndex;
                /*object?*/ let endObject;
                /*uint*/ let sliceStartIndex;
                /*object?*/ let sliceStartObject;
                /*var*/ let sliceStartSegment;
                /*ulong*/ let sliceRange;
                /*ulong*/ let startRange;
                /*ulong*/ let endRange;
                /*int*/ let currentLength;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            startIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger) >>> 0);
                            startObject = this._startObject;
                            endIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger) >>> 0);
                            endObject = this._endObject;
                            sliceStartIndex = (start.GetInteger() >>> 0);
                            sliceStartObject = start.GetObject();
                            if (sliceStartObject === null)
                            {
                                sliceStartIndex = startIndex;
                                sliceStartObject = this._startObject;
                            }
                            if (startObject === endObject)
                            {
                                if (!$.$sm.System.Buffers.ReadOnlySequence$$(T).InRange(sliceStartIndex, startIndex, endIndex))
                                {
                                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                if (length < 0n)
                                {
                                    $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(0n);
                                }
                                if (BigInt(endIndex - sliceStartIndex) < length)
                                {
                                    $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(0n);
                                }
                                $gotoJumpState1 = 1; /*goto FoundInFirstSegment*/
                                continue $gotoJumpStart1;
                            }
                            sliceStartSegment = $.$cast(sliceStartObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                            sliceRange = $.$cast(((sliceStartSegment.RunningIndex + BigInt(sliceStartIndex))), $.$$.System.UInt64);
                            startRange = $.$cast((($.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(startIndex)), $.$$.System.UInt64);
                            endRange = $.$cast((($.$cast(endObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(endIndex)), $.$$.System.UInt64);
                            $.$$.System.Diagnostics.Debug.Assert$2(sliceStartIndex >= 0 && startIndex >= 0 && endIndex >= 0, "sliceStartIndex >= 0 && startIndex >= 0 && endIndex >= 0");
                            if (!$.$sm.System.Buffers.ReadOnlySequence$$(T).InRange$1(sliceRange, startRange, endRange))
                            {
                                $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                            }
                            if (length < 0n)
                            {
                                $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(0n);
                            }
                            if (sliceRange + $.$cast(length, $.$$.System.UInt64) > endRange)
                            {
                                $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(0/*ExceptionArgument.length*/);
                            }
                            currentLength = ((sliceStartSegment.Memory.Length - (sliceStartIndex | 0)) | 0);
                            if (BigInt(currentLength) < length)
                            {
                                if (currentLength < 0)
                                {
                                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                /*SequencePosition*/ let end = $.$sm.System.Buffers.ReadOnlySequence$$(T).SeekMultiSegment(sliceStartSegment.Next, endObject, (endIndex | 0), length - BigInt(currentLength), 0/*ExceptionArgument.length*/);
                                return this.SliceImpl($.$ref(() => start, ), $.$ref(() => end, ));
                            }
                        }
                        case 1: /*FoundInFirstSegment*/
                        $.$$.System.Diagnostics.Debug.Assert$2(length <= BigInt(2147483647/*int.MaxValue*/ - sliceStartIndex), "length <= int.MaxValue - sliceStartIndex");
                        return this.SliceImpl($.$ref(() => new $.$sm.System.SequencePosition().$ctor$3(sliceStartObject, (sliceStartIndex | 0)), ), $.$ref(() => new $.$sm.System.SequencePosition().$ctor$3(sliceStartObject, (((sliceStartIndex | 0) + $.$cast(length, $.$$.System.Int32)) | 0)), ));
                    }
                    break;
                }
            }
            /*ReadOnlySequence<T> */ Slice(/*int*/ start, /*int*/ length)
            {
                return this.Slice$2($.$cast(start, $.$$.System.Int64), BigInt(length));
            }
            /*ReadOnlySequence<T> */ Slice$1(/*int*/ start, /*SequencePosition*/ end)
            {
                return this.Slice$3($.$cast(start, $.$$.System.Int64), end);
            }
            /*ReadOnlySequence<T> */ Slice$5(/*SequencePosition*/ start, /*int*/ length)
            {
                return this.Slice$6(start, $.$cast(length, $.$$.System.Int64));
            }
            /*ReadOnlySequence<T> */ Slice$7(/*SequencePosition*/ start, /*SequencePosition*/ end)
            {
                this.BoundsCheck((start.GetInteger() >>> 0), start.GetObject(), (end.GetInteger() >>> 0), end.GetObject());
                return this.SliceImpl($.$ref(() => start, ), $.$ref(() => end, ));
            }
            /*ReadOnlySequence<T> */ Slice$8(/*SequencePosition*/ start)
            {
                /*bool*/ let positionIsNotNull = start.GetObject() !== null;
                this.BoundsCheck$1($.$ref(() => start, ), positionIsNotNull);
                return this.SliceImpl$1($.$ref(() => positionIsNotNull ? start : this.Start, ));
            }
            /*ReadOnlySequence<T> */ Slice$4(/*long*/ start)
            {
                if (start < 0n)
                {
                    $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(start);
                }
                if (start === 0n)
                {
                    return this;
                }
                /*SequencePosition*/ let begin = this.Seek(start, 1/*ExceptionArgument.start*/);
                return this.SliceImpl$1($.$ref(() => begin, ));
            }
            static/*conventional*/ /*string */ ToString()
            {
                if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Char.$type))
                {
                    /*ReadOnlySequence<T>*/ let localThis = this;
                    /*ReadOnlySequence<char>*/ let charSequence = $.$$.System.Runtime.CompilerServices.Unsafe.As($.$sm.System.Buffers.ReadOnlySequence$$(T), $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.Buffers.ReadOnlySequence$$(T), () => localThis, ($v) => localThis = $v, null)).$v;
                    /*string?*/ let text;
                    /*int*/ let start;
                    /*int*/ let length;
                    if (charSequence.TryGetString($.$ref(() => text, ($v) => text = $v, $.$$.System.String), $.$ref(() => start, ($v) => start = $v, $.$$.System.Int32), $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32)))
                    {
                        return $.$$.System.String.Substring.call(text, start, length);
                    }
                    if (this.Length < BigInt(2147483647/*int.MaxValue*/))
                    {
                        return $.$$.System.String.Create$10($.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char), $.$cast(this.Length, $.$$.System.Int32), charSequence, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char)))().$ctor(this,  (/*span*/ span, /*sequence*/ sequence) =>
                        {
                            return $.$sm.System.Buffers.BuffersExtensions.CopyTo($.$$.System.Char, $.$ref(() => sequence, ), span);
                        }, {"r":65537,"p":[{"n":"span","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char).$h}],"n":"","d":this.$h,"h":0,"f":17825794}));
                    }
                }
                return `System.Buffers.ReadOnlySequence<${T.$type.Name}>[${this.Length}]`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sm.System.Buffers.ReadOnlySequence$$(T).ToString.apply(this, arguments); }
            /*Enumerator */ GetEnumerator()
            {
                return new ($.$sm.System.Buffers.ReadOnlySequence$$(T).Enumerator)().$ctor$3(this);
            }
            /*SequencePosition */ GetPosition$1(/*long*/ offset)
            {
                if (offset < 0n)
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_OffsetOutOfRange();
                }
                return this.Seek(offset, 7);
            }
            /*long */ GetOffset(/*SequencePosition*/ position)
            {
                /*object?*/ let positionSequenceObject = position.GetObject();
                /*bool*/ let positionIsNull = positionSequenceObject === null;
                this.BoundsCheck$1($.$ref(() => position, ), !positionIsNull);
                /*object?*/ let startObject = this._startObject;
                /*object?*/ let endObject = this._endObject;
                /*uint*/ let positionIndex = (position.GetInteger() >>> 0);
                if (positionIsNull)
                {
                    positionSequenceObject = this._startObject;
                    positionIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger) >>> 0);
                }
                if (startObject === endObject)
                {
                    return BigInt(positionIndex);
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(positionSequenceObject !== null, "positionSequenceObject != null");
                    if (BigInt(($.$cast(positionSequenceObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).Memory.Length) - BigInt(positionIndex) < 0n)
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                    /*ReadOnlySequenceSegment<T>?*/ let currentSegment = $.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                    while(currentSegment !== null && currentSegment !== positionSequenceObject)
                    {
                        currentSegment = currentSegment.Next;
                    }
                    if (currentSegment === null)
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(currentSegment.RunningIndex + BigInt(positionIndex) >= 0n, "currentSegment!.RunningIndex + positionIndex >= 0");
                    return currentSegment.RunningIndex + BigInt(positionIndex);
                }
            }
            /*SequencePosition */ GetPosition(/*long*/ offset, /*SequencePosition*/ origin)
            {
                if (offset < 0n)
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_OffsetOutOfRange();
                }
                return this.Seek$1($.$ref(() => origin, ), offset);
            }
            /*bool */ TryGet(/*ref SequencePosition*/ position, /*out ReadOnlyMemory<T>*/ memory, /*bool*/ advance)
            {
                /*SequencePosition*/ let next;
                /*bool*/ let result = this.TryGetBuffer(position, memory, $.$ref(() => next, ($v) => next = $v, $.$sm.System.SequencePosition));
                if (advance)
                {
                    position.$v = next;
                }
                return result;
            }
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$sm.System.Buffers.ReadOnlySequence$$(T);
                return $cls.$_Enumerator ??= $asm.$nstr("$sm.System.Buffers.ReadOnlySequence$$.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                {
                    /*ReadOnlySequence<T>*/  get _sequence() { return this.$getField(0, 16); }
                    /*ReadOnlySequence<T>*/  set _sequence(value) { this.$setField(0, 16, value); }
                    /*SequencePosition*/  get _next() { return this.$getField(16, 8); }
                    /*SequencePosition*/  set _next(value) { this.$setField(16, 8, value); }
                    /*ReadOnlyMemory<T>*/  get _currentMemory() { return this.$getField(24, 12); }
                    /*ReadOnlyMemory<T>*/  set _currentMemory(value) { this.$setField(24, 12, value); }
                    $ctor$3(/*in ReadOnlySequence<T>*/ sequence)
                    {
                        super.$ctor$1();
                        {
                            this._currentMemory = new ($.$$.System.ReadOnlyMemory$$(T))();
                            this._next = sequence.$v.Start;
                            this._sequence = sequence.$v;
                        }
                        return this;
                    }
                    /*ReadOnlyMemory<T> */ get Current()
                    {
                        return this._currentMemory;
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._next.GetObject() === null)
                        {
                            return false;
                        }
                        return this._sequence.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => this._next, ($v) => this._next = $v, null), $.$ref(() => this._currentMemory, ($v) => this._currentMemory = $v, $.$$.System.ReadOnlyMemory$$(T)), true);
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._sequence = this._sequence.Clone();
                        copy._next = this._next.Clone();
                        copy._currentMemory = this._currentMemory.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._sequence = $.$default($.$sm.System.Buffers.ReadOnlySequence$$(T));
                        this._next = $.$default($.$sm.System.SequencePosition);
                        this._currentMemory = $.$default($.$$.System.ReadOnlyMemory$$(T));
                    }
                    static $h = 630279;
                    static $z = 36;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$$.System.ReadOnlyMemory$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x600000000n),"f":50331649},"n":"Current","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":2097153}],"m":[{"r":262145,"n":"MoveNext","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777217}],"l":[{"t":$.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"n":"_sequence","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306},{"t":1220103,"n":"_next","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194306},{"t":$.$$.System.ReadOnlyMemory$$(T).$h,"n":"_currentMemory","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194306}],"c":[{"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"f":8}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777217},{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777217}],"d":$.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Buffers.ReadOnlySequence<${T?.$fullName}>.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            static $_SequenceType;
            static get SequenceType()
            {
                let $cls = $.$sm.System.Buffers.ReadOnlySequence$$(T);
                return $cls.$_SequenceType ??= $asm.$nstr("$sm.System.Buffers.ReadOnlySequence$$.SequenceType", ($self) => class SequenceType extends $.$$.System.Enum
                {
                    static MultiSegment = 0;
                    static Array = 1;
                    static MemoryManager = 2;
                    static String = 3;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "MultiSegment": 0n,
                            "Array": 1n,
                            "MemoryManager": 2n,
                            "String": 3n
                        };
                    }
                    static $h = 695815;
                    static $z = 4;
                    static $f = 0b110000011011001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":this.$h,"n":"MultiSegment","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194337},{"t":this.$h,"n":"Array","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":4194337},{"t":this.$h,"n":"MemoryManager","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":4194337},{"t":this.$h,"n":"String","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":$.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Buffers.ReadOnlySequence<${T?.$fullName}>.SequenceType`; }
                }, $cls, ($v) => $cls.$_SequenceType = $v);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._startObject = this._startObject;
                copy._endObject = this._endObject;
                copy._startInteger = this._startInteger;
                copy._endInteger = this._endInteger;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._startObject = null;
                this._endObject = null;
                this._startInteger = 0;
                this._endInteger = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Empty = new ($.$sm.System.Buffers.ReadOnlySequence$$(T))().$ctor$6($.$$.System.Array.Empty(T));
                }
            }
            static $h = 564743;
            static $g = 1;
            static $z = 16;
            static $f = 0b1011000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":917505,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x1E00000000n),"f":50331649},"n":"Length","d":this.$h,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2000000000n),"f":50331649},"n":"IsEmpty","d":this.$h,"h":Number(BigInt(this.$h)|0x1F00000000n),"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2200000000n),"f":50331649},"n":"IsSingleSegment","d":this.$h,"h":Number(BigInt(this.$h)|0x2100000000n),"f":2097153},{"p":$.$$.System.ReadOnlyMemory$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2400000000n),"f":50331649},"n":"First","d":this.$h,"h":Number(BigInt(this.$h)|0x2300000000n),"f":2097153},{"p":$.$$.System.ReadOnlySpan$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2600000000n),"f":50331649},"n":"FirstSpan","d":this.$h,"h":Number(BigInt(this.$h)|0x2500000000n),"f":2097153},{"p":1220103,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2800000000n),"f":50331649},"n":"Start","d":this.$h,"h":Number(BigInt(this.$h)|0x2700000000n),"f":2097153},{"p":1220103,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2A00000000n),"f":50331649},"n":"End","d":this.$h,"h":Number(BigInt(this.$h)|0x2900000000n),"f":2097153}],"m":[{"r":262145,"p":[{"n":"position","p":1220103,"f":8},{"n":"memory","p":$.$$.System.ReadOnlyMemory$$(T).$h,"f":2},{"n":"next","p":1220103,"f":2}],"n":"TryGetBuffer","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777224},{"r":$.$$.System.ReadOnlyMemory$$(T).$h,"n":"GetFirstBuffer","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777218},{"r":$.$$.System.ReadOnlyMemory$$(T).$h,"p":[{"n":"startObject","p":131073},{"n":"isMultiSegment","p":262145}],"n":"GetFirstBufferSlow","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777218},{"r":$.$$.System.ReadOnlySpan$$(T).$h,"n":"GetFirstSpan","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777218},{"r":$.$$.System.ReadOnlySpan$$(T).$h,"p":[{"n":"startObject","p":131073},{"n":"isMultiSegment","p":262145}],"n":"GetFirstSpanSlow","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777218},{"r":1220103,"p":[{"n":"offset","p":917505},{"n":"exceptionArgument","p":1089031,"f":65,"v":7}],"n":"Seek","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777224},{"r":1220103,"p":[{"n":"start","p":1220103,"f":8},{"n":"offset","p":917505}],"n":"Seek","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777218},{"r":1220103,"p":[{"n":"currentSegment","p":$.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h},{"n":"endObject","p":131073},{"n":"endIndex","p":655361},{"n":"offset","p":917505},{"n":"argument","p":1089031}],"n":"SeekMultiSegment","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777250},{"r":65537,"p":[{"n":"position","p":1220103,"f":8},{"n":"positionIsNotNull","p":262145}],"n":"BoundsCheck","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":16777218},{"r":65537,"p":[{"n":"sliceStartIndex","p":720897},{"n":"sliceStartObject","p":131073},{"n":"sliceEndIndex","p":720897},{"n":"sliceEndObject","p":131073}],"n":"BoundsCheck","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":16777218},{"r":1220103,"p":[{"n":"startSegment","p":$.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h},{"n":"startObject","p":131073},{"n":"startIndex","p":655361},{"n":"endObject","p":131073},{"n":"endIndex","p":655361},{"n":"length","p":917505}],"n":"GetEndPosition","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16777250},{"r":$.$sm.System.Buffers.ReadOnlySequence$$(T).SequenceType.$h,"n":"GetSequenceType","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16777218},{"r":655361,"p":[{"n":"Integer","p":655361}],"n":"GetIndex","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16777250},{"r":this.$h,"p":[{"n":"start","p":1220103,"f":8},{"n":"end","p":1220103,"f":8}],"n":"SliceImpl","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16777218},{"r":this.$h,"p":[{"n":"start","p":1220103,"f":8}],"n":"SliceImpl","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":16777218},{"r":917505,"n":"GetLength","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16777218},{"r":262145,"p":[{"n":"startSegment","p":$.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h,"f":2},{"n":"startIndex","p":655361,"f":2},{"n":"endSegment","p":$.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h,"f":2},{"n":"endIndex","p":655361,"f":2}],"n":"TryGetReadOnlySequenceSegment","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16777224},{"r":262145,"p":[{"n":"segment","p":$.$$.System.ArraySegment$$(T).$h,"f":2}],"n":"TryGetArray","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16777224},{"r":262145,"p":[{"n":"text","p":1310721,"f":2},{"n":"start","p":655361,"f":2},{"n":"length","p":655361,"f":2}],"n":"TryGetString","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":16777224},{"r":262145,"p":[{"n":"value","p":720897},{"n":"start","p":720897},{"n":"end","p":720897}],"n":"InRange","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777250},{"r":262145,"p":[{"n":"value","p":983041},{"n":"start","p":983041},{"n":"end","p":983041}],"n":"InRange","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16777250},{"r":65537,"p":[{"n":"first","p":$.$$.System.ReadOnlySpan$$(T).$h,"f":2},{"n":"next","p":1220103,"f":2}],"n":"GetFirstSpan","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":16777224},{"r":$.$$.System.ReadOnlySpan$$(T).$h,"p":[{"n":"startObject","p":131073},{"n":"startIndex","p":655361},{"n":"endIndex","p":655361},{"n":"hasMultipleSegments","p":262145}],"n":"GetFirstSpanSlow","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":16777250},{"r":this.$h,"p":[{"n":"start","p":917505},{"n":"length","p":917505}],"n":"Slice","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x3000000000n),"f":16777217},{"r":this.$h,"p":[{"n":"start","p":917505},{"n":"end","p":1220103}],"n":"Slice","o":"@$3","d":this.$h,"h":Number(BigInt(this.$h)|0x3100000000n),"f":16777217},{"r":this.$h,"p":[{"n":"start","p":1220103},{"n":"length","p":917505}],"n":"Slice","o":"@$6","d":this.$h,"h":Number(BigInt(this.$h)|0x3200000000n),"f":16777217},{"r":this.$h,"p":[{"n":"start","p":655361},{"n":"length","p":655361}],"n":"Slice","d":this.$h,"h":Number(BigInt(this.$h)|0x3300000000n),"f":16777217},{"r":this.$h,"p":[{"n":"start","p":655361},{"n":"end","p":1220103}],"n":"Slice","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x3400000000n),"f":16777217},{"r":this.$h,"p":[{"n":"start","p":1220103},{"n":"length","p":655361}],"n":"Slice","o":"@$5","d":this.$h,"h":Number(BigInt(this.$h)|0x3500000000n),"f":16777217},{"r":this.$h,"p":[{"n":"start","p":1220103},{"n":"end","p":1220103}],"n":"Slice","o":"@$7","d":this.$h,"h":Number(BigInt(this.$h)|0x3600000000n),"f":16777217},{"r":this.$h,"p":[{"n":"start","p":1220103}],"n":"Slice","o":"@$8","d":this.$h,"h":Number(BigInt(this.$h)|0x3700000000n),"f":16777217},{"r":this.$h,"p":[{"n":"start","p":917505}],"n":"Slice","o":"@$4","d":this.$h,"h":Number(BigInt(this.$h)|0x3800000000n),"f":16777217},{"r":1310721,"n":"ToString","d":this.$h,"h":Number(BigInt(this.$h)|0x3900000000n),"f":16809985},{"r":$.$sm.System.Buffers.ReadOnlySequence$$(T).Enumerator.$h,"n":"GetEnumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x3A00000000n),"f":16777217},{"r":1220103,"p":[{"n":"offset","p":917505}],"n":"GetPosition","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x3B00000000n),"f":16777217},{"r":917505,"p":[{"n":"position","p":1220103}],"n":"GetOffset","d":this.$h,"h":Number(BigInt(this.$h)|0x3C00000000n),"f":16777217},{"r":1220103,"p":[{"n":"offset","p":917505},{"n":"origin","p":1220103}],"n":"GetPosition","d":this.$h,"h":Number(BigInt(this.$h)|0x3D00000000n),"f":16777217},{"r":262145,"p":[{"n":"position","p":1220103,"f":4},{"n":"memory","p":$.$$.System.ReadOnlyMemory$$(T).$h,"f":2},{"n":"advance","p":262145,"f":65,"v":true}],"n":"TryGet","d":this.$h,"h":Number(BigInt(this.$h)|0x3E00000000n),"f":16777217}],"l":[{"t":131073,"n":"_startObject","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":4194306},{"t":131073,"n":"_endObject","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":4194306},{"t":655361,"n":"_startInteger","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":4194306},{"t":655361,"n":"_endInteger","d":this.$h,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":4194306},{"t":this.$h,"n":"Empty","d":this.$h,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":4194337}],"c":[{"p":[{"n":"startSegment","p":131073},{"n":"startIndexAndFlags","p":655361},{"n":"endSegment","p":131073},{"n":"endIndexAndFlags","p":655361}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x2B00000000n),"f":16777218},{"p":[{"n":"startSegment","p":$.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h},{"n":"startIndex","p":655361},{"n":"endSegment","p":$.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h},{"n":"endIndex","p":655361}],"n":".ctor","o":"$ctor$7","d":this.$h,"h":Number(BigInt(this.$h)|0x2C00000000n),"f":16777217},{"p":[{"n":"array","p":$.$typeArray(T).$h}],"n":".ctor","o":"$ctor$6","d":this.$h,"h":Number(BigInt(this.$h)|0x2D00000000n),"f":16777217},{"p":[{"n":"array","p":$.$typeArray(T).$h},{"n":"start","p":655361},{"n":"length","p":655361}],"n":".ctor","o":"$ctor$5","d":this.$h,"h":Number(BigInt(this.$h)|0x2E00000000n),"f":16777217},{"p":[{"n":"memory","p":$.$$.System.ReadOnlyMemory$$(T).$h}],"n":".ctor","o":"$ctor$4","d":this.$h,"h":Number(BigInt(this.$h)|0x2F00000000n),"f":16777217},{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x4100000000n),"f":16777217}],"g":[T?.$h??1507328],"j":[$.$sm.System.Buffers.ReadOnlySequence$$(T).Enumerator.$h,$.$sm.System.Buffers.ReadOnlySequence$$(T).SequenceType.$h],"r":1,"h":this.$h,"a":[{"t":37945345,"c":8627879937,"a":[{"v":$.$sm.System.Buffers.ReadOnlySequenceDebugView$$().$h,"t":142475265}]},{"t":37617665,"c":8627552257,"a":[{"v":"{ToString(),raw}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Buffers.ReadOnlySequence<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$sm.System.Buffers.SequenceReader<>", (T) => $asm.$gt("$sm.System.Buffers.SequenceReader<>", [T], ($self) => class SequenceReader$$ extends $.$$.System.ValueType
        {
            /*bool */ TryReadTo$1(/*out ReadOnlySpan<T>*/ span, /*T*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                if (index !== -1)
                {
                    span.$v = index === 0 ? new ($.$$.System.ReadOnlySpan$$(T))() : remaining.Slice(0, index);
                    this.AdvanceCurrentSpan(BigInt(index + (advancePastDelimiter ? 1 : 0)));
                    return true;
                }
                return this.TryReadToSlow$1(span, delimiter, advancePastDelimiter);
            }
            /*bool */ TryReadToSlow$1(/*out ReadOnlySpan<T>*/ span, /*T*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                /*ReadOnlySequence<T>*/ let sequence;
                if (!this.TryReadToInternal($.$ref(() => sequence, ($v) => sequence = $v, $.$sm.System.Buffers.ReadOnlySequence$$(T)), delimiter, advancePastDelimiter, ((this.CurrentSpan.Length - this.CurrentSpanIndex) | 0)))
                {
                    span.$v = new ($.$$.System.ReadOnlySpan$$(T))();
                    return false;
                }
                span.$v = sequence.IsSingleSegment ? sequence.First.Span : $.$$.System.ReadOnlySpan$$(T).op_Implicit$1($.$sm.System.Buffers.BuffersExtensions.ToArray(T, $.$ref(() => sequence, )));
                return true;
            }
            /*bool */ TryReadTo$2(/*out ReadOnlySpan<T>*/ span, /*T*/ delimiter, /*T*/ delimiterEscape, /*bool*/ advancePastDelimiter)
            {
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                if ((index > 0 && !$.$dsp(remaining.get_Item(((index - 1) | 0)).$v, T, ($t) => $t.System$IEquatable$$$Equals, delimiterEscape, [T])) || index === 0)
                {
                    span.$v = remaining.Slice(0, index);
                    this.AdvanceCurrentSpan(BigInt(index + (advancePastDelimiter ? 1 : 0)));
                    return true;
                }
                return this.TryReadToSlow$2(span, delimiter, delimiterEscape, index, advancePastDelimiter);
            }
            /*bool */ TryReadToSlow$2(/*out ReadOnlySpan<T>*/ span, /*T*/ delimiter, /*T*/ delimiterEscape, /*int*/ index, /*bool*/ advancePastDelimiter)
            {
                /*ReadOnlySequence<T>*/ let sequence;
                if (!this.TryReadToSlow$3($.$ref(() => sequence, ($v) => sequence = $v, $.$sm.System.Buffers.ReadOnlySequence$$(T)), delimiter, delimiterEscape, index, advancePastDelimiter))
                {
                    span.$v = new ($.$$.System.ReadOnlySpan$$(T))();
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(sequence.Length > 0n, "sequence.Length > 0");
                span.$v = sequence.IsSingleSegment ? sequence.First.Span : $.$$.System.ReadOnlySpan$$(T).op_Implicit$1($.$sm.System.Buffers.BuffersExtensions.ToArray(T, $.$ref(() => sequence, )));
                return true;
            }
            /*bool */ TryReadToSlow$3(/*out ReadOnlySequence<T>*/ sequence, /*T*/ delimiter, /*T*/ delimiterEscape, /*int*/ index, /*bool*/ advancePastDelimiter)
            {
                /*SequenceReader<T>*/ let copy = this;
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*bool*/ let priorEscape = false;
                $doJumpStart1: do
                {
                    let $gotoJumpState2 = 0;
                    $gotoJumpStart2: while(true)
                    {
                        switch($gotoJumpState2)
                        {
                            case 0:
                            {
                                if (index >= 0)
                                {
                                    if (index === 0 && priorEscape)
                                    {
                                        priorEscape = false;
                                        this.Advance(BigInt(index + 1));
                                        remaining = this.UnreadSpan;
                                        $gotoJumpState2 = 1; /*goto Continue*/
                                        continue $gotoJumpStart2;
                                    }
                                    else if (index > 0 && $.$dsp(remaining.get_Item(((index - 1) | 0)).$v, T, ($t) => $t.System$IEquatable$$$Equals, delimiterEscape, [T]))
                                    {
                                        /*int*/ let escapeCount = 1;
                                        /*int*/ let i = ((index - 2) | 0);
                                        for(; i >= 0; i--)
                                        {
                                            if (!$.$dsp(remaining.get_Item(i).$v, T, ($t) => $t.System$IEquatable$$$Equals, delimiterEscape, [T]))
                                            {
                                                break;
                                            }
                                        }
                                        if (i < 0 && priorEscape)
                                        {
                                            escapeCount++;
                                        }
                                        escapeCount += ((((index - 2) | 0) - i) | 0);
                                        if ((escapeCount & 1) !== 0)
                                        {
                                            this.Advance(BigInt(index + 1));
                                            priorEscape = false;
                                            remaining = this.UnreadSpan;
                                            $gotoJumpState2 = 1; /*goto Continue*/
                                            continue $gotoJumpStart2;
                                        }
                                    }
                                    this.AdvanceCurrentSpan(BigInt(index));
                                    sequence.$v = this.Sequence.Slice$7(copy.Position, this.Position);
                                    if (advancePastDelimiter)
                                    {
                                        this.Advance(1n);
                                    }
                                    return true;
                                }
                                else 
                                {
                                    if ($.$$.System.MemoryExtensions.EndsWith$4(T, remaining, delimiterEscape))
                                    {
                                        /*int*/ let escapeCount = 1;
                                        /*int*/ let i = ((remaining.Length - 2) | 0);
                                        for(; i >= 0; i--)
                                        {
                                            if (!$.$dsp(remaining.get_Item(i).$v, T, ($t) => $t.System$IEquatable$$$Equals, delimiterEscape, [T]))
                                            {
                                                break;
                                            }
                                        }
                                        escapeCount += ((((remaining.Length - 2) | 0) - i) | 0);
                                        if (i < 0 && priorEscape)
                                        {
                                            priorEscape = (escapeCount & 1) === 0;
                                        }
                                        else 
                                        {
                                            priorEscape = (escapeCount & 1) !== 0;
                                        }
                                    }
                                    else 
                                    {
                                        priorEscape = false;
                                    }
                                }
                                this.AdvanceCurrentSpan(BigInt(remaining.Length));
                                remaining = this.CurrentSpan;
                            }
                            case 1: /*Continue*/
                            index = $.$$.System.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                        }
                        break;
                    }
                }
                while(!this.End);
                copy.Clone(this);
                sequence.$v = new ($.$sm.System.Buffers.ReadOnlySequence$$(T))();
                return false;
            }
            /*bool */ TryReadTo$4(/*out ReadOnlySequence<T>*/ sequence, /*T*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                return this.TryReadToInternal(sequence, delimiter, advancePastDelimiter, 0);
            }
            /*bool */ TryReadToInternal(/*out ReadOnlySequence<T>*/ sequence, /*T*/ delimiter, /*bool*/ advancePastDelimiter, /*int*/ skip)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(skip >= 0, "skip >= 0");
                /*SequenceReader<T>*/ let copy = this;
                if (skip > 0)
                {
                    this.Advance(BigInt(skip));
                }
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                while(this._moreData)
                {
                    /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                    if (index !== -1)
                    {
                        if (index > 0)
                        {
                            this.AdvanceCurrentSpan(BigInt(index));
                        }
                        sequence.$v = this.Sequence.Slice$7(copy.Position, this.Position);
                        if (advancePastDelimiter)
                        {
                            this.Advance(1n);
                        }
                        return true;
                    }
                    this.AdvanceCurrentSpan(BigInt(remaining.Length));
                    remaining = this.CurrentSpan;
                }
                copy.Clone(this);
                sequence.$v = new ($.$sm.System.Buffers.ReadOnlySequence$$(T))();
                return false;
            }
            /*bool */ TryReadTo$5(/*out ReadOnlySequence<T>*/ sequence, /*T*/ delimiter, /*T*/ delimiterEscape, /*bool*/ advancePastDelimiter)
            {
                /*SequenceReader<T>*/ let copy = this;
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*bool*/ let priorEscape = false;
                while(this._moreData)
                {
                    /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                    if (index !== -1)
                    {
                        if (index === 0 && priorEscape)
                        {
                            priorEscape = false;
                            this.Advance(BigInt(index + 1));
                            remaining = this.UnreadSpan;
                            continue;
                        }
                        else if (index > 0 && $.$dsp(remaining.get_Item(((index - 1) | 0)).$v, T, ($t) => $t.System$IEquatable$$$Equals, delimiterEscape, [T]))
                        {
                            /*int*/ let escapeCount = 0;
                            for(/*int*/ let i = index; i > 0 && $.$dsp(remaining.get_Item(((i - 1) | 0)).$v, T, ($t) => $t.System$IEquatable$$$Equals, delimiterEscape, [T]); i--, escapeCount++)
                            {
                            }
                            if (escapeCount === index && priorEscape)
                            {
                                escapeCount++;
                            }
                            priorEscape = false;
                            if ((escapeCount & 1) !== 0)
                            {
                                this.Advance(BigInt(index + 1));
                                remaining = this.UnreadSpan;
                                continue;
                            }
                        }
                        if (index > 0)
                        {
                            this.Advance(BigInt(index));
                        }
                        sequence.$v = this.Sequence.Slice$7(copy.Position, this.Position);
                        if (advancePastDelimiter)
                        {
                            this.Advance(1n);
                        }
                        return true;
                    }
                    {
                        /*int*/ let escapeCount = 0;
                        for(/*int*/ let i = remaining.Length; i > 0 && $.$dsp(remaining.get_Item(((i - 1) | 0)).$v, T, ($t) => $t.System$IEquatable$$$Equals, delimiterEscape, [T]); i--, escapeCount++)
                        {
                        }
                        if (priorEscape && escapeCount === remaining.Length)
                        {
                            escapeCount++;
                        }
                        priorEscape = escapeCount % 2 !== 0;
                    }
                    this.Advance(BigInt(remaining.Length));
                    remaining = this.CurrentSpan;
                }
                copy.Clone(this);
                sequence.$v = new ($.$sm.System.Buffers.ReadOnlySequence$$(T))();
                return false;
            }
            /*bool */ TryReadToAny(/*out ReadOnlySpan<T>*/ span, /*scoped ReadOnlySpan<T>*/ delimiters, /*bool*/ advancePastDelimiter)
            {
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = delimiters.Length === 2 ? $.$$.System.MemoryExtensions.IndexOfAny$8(T, remaining, delimiters.get_Item(0).$v, delimiters.get_Item(1).$v) : $.$$.System.MemoryExtensions.IndexOfAny$4(T, remaining, delimiters);
                if (index !== -1)
                {
                    span.$v = remaining.Slice(0, index);
                    this.Advance(BigInt(index + (advancePastDelimiter ? 1 : 0)));
                    return true;
                }
                return this.TryReadToAnySlow(span, delimiters, advancePastDelimiter);
            }
            /*bool */ TryReadToAnySlow(/*out ReadOnlySpan<T>*/ span, /*scoped ReadOnlySpan<T>*/ delimiters, /*bool*/ advancePastDelimiter)
            {
                /*ReadOnlySequence<T>*/ let sequence;
                if (!this.TryReadToAnyInternal($.$ref(() => sequence, ($v) => sequence = $v, $.$sm.System.Buffers.ReadOnlySequence$$(T)), delimiters, advancePastDelimiter, ((this.CurrentSpan.Length - this.CurrentSpanIndex) | 0)))
                {
                    span.$v = new ($.$$.System.ReadOnlySpan$$(T))();
                    return false;
                }
                span.$v = sequence.IsSingleSegment ? sequence.First.Span : $.$$.System.ReadOnlySpan$$(T).op_Implicit$1($.$sm.System.Buffers.BuffersExtensions.ToArray(T, $.$ref(() => sequence, )));
                return true;
            }
            /*bool */ TryReadToAny$1(/*out ReadOnlySequence<T>*/ sequence, /*scoped ReadOnlySpan<T>*/ delimiters, /*bool*/ advancePastDelimiter)
            {
                return this.TryReadToAnyInternal(sequence, delimiters, advancePastDelimiter, 0);
            }
            /*bool */ TryReadToAnyInternal(/*out ReadOnlySequence<T>*/ sequence, /*scoped ReadOnlySpan<T>*/ delimiters, /*bool*/ advancePastDelimiter, /*int*/ skip)
            {
                /*SequenceReader<T>*/ let copy = this;
                if (skip > 0)
                {
                    this.Advance(BigInt(skip));
                }
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                while(!this.End)
                {
                    /*int*/ let index = delimiters.Length === 2 ? $.$$.System.MemoryExtensions.IndexOfAny$8(T, remaining, delimiters.get_Item(0).$v, delimiters.get_Item(1).$v) : $.$$.System.MemoryExtensions.IndexOfAny$4(T, remaining, delimiters);
                    if (index !== -1)
                    {
                        if (index > 0)
                        {
                            this.AdvanceCurrentSpan(BigInt(index));
                        }
                        sequence.$v = this.Sequence.Slice$7(copy.Position, this.Position);
                        if (advancePastDelimiter)
                        {
                            this.Advance(1n);
                        }
                        return true;
                    }
                    this.Advance(BigInt(remaining.Length));
                    remaining = this.CurrentSpan;
                }
                copy.Clone(this);
                sequence.$v = new ($.$sm.System.Buffers.ReadOnlySequence$$(T))();
                return false;
            }
            /*bool */ TryReadTo(/*out ReadOnlySpan<T>*/ span, /*scoped ReadOnlySpan<T>*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$2(T, remaining, delimiter);
                if (index >= 0)
                {
                    span.$v = remaining.Slice(0, index);
                    this.AdvanceCurrentSpan(BigInt(index + (advancePastDelimiter ? delimiter.Length : 0)));
                    return true;
                }
                return this.TryReadToSlow(span, delimiter, advancePastDelimiter);
            }
            /*bool */ TryReadToSlow(/*out ReadOnlySpan<T>*/ span, /*scoped ReadOnlySpan<T>*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                /*ReadOnlySequence<T>*/ let sequence;
                if (!this.TryReadTo$3($.$ref(() => sequence, ($v) => sequence = $v, $.$sm.System.Buffers.ReadOnlySequence$$(T)), delimiter, advancePastDelimiter))
                {
                    span.$v = new ($.$$.System.ReadOnlySpan$$(T))();
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(sequence.Length > 0n, "sequence.Length > 0");
                span.$v = sequence.IsSingleSegment ? sequence.First.Span : $.$$.System.ReadOnlySpan$$(T).op_Implicit$1($.$sm.System.Buffers.BuffersExtensions.ToArray(T, $.$ref(() => sequence, )));
                return true;
            }
            /*bool */ TryReadTo$3(/*out ReadOnlySequence<T>*/ sequence, /*scoped ReadOnlySpan<T>*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                if (delimiter.Length === 0)
                {
                    sequence.$v = new ($.$sm.System.Buffers.ReadOnlySequence$$(T))();
                    return true;
                }
                /*SequenceReader<T>*/ let copy = this;
                /*bool*/ let advanced = false;
                while(!this.End)
                {
                    if (!this.TryReadTo$4(sequence, delimiter.get_Item(0).$v, false))
                    {
                        copy.Clone(this);
                        return false;
                    }
                    if (delimiter.Length === 1)
                    {
                        if (advancePastDelimiter)
                        {
                            this.Advance(1n);
                        }
                        return true;
                    }
                    if (this.IsNext(delimiter, false))
                    {
                        if (advanced)
                        {
                            sequence.$v = copy.Sequence.Slice$2(copy.Consumed, this.Consumed - copy.Consumed);
                        }
                        if (advancePastDelimiter)
                        {
                            this.Advance(BigInt(delimiter.Length));
                        }
                        return true;
                    }
                    else 
                    {
                        this.Advance(1n);
                        advanced = true;
                    }
                }
                copy.Clone(this);
                sequence.$v = new ($.$sm.System.Buffers.ReadOnlySequence$$(T))();
                return false;
            }
            /*bool */ TryReadExact(/*int*/ count, /*out ReadOnlySequence<T>*/ sequence)
            {
                if (count < 0)
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(15/*ExceptionArgument.count*/);
                }
                if (BigInt(count) > this.Remaining)
                {
                    sequence.$v = new ($.$sm.System.Buffers.ReadOnlySequence$$(T))();
                    return false;
                }
                sequence.$v = this.Sequence.Slice$5(this.Position, count);
                if (count !== 0)
                {
                    this.Advance(BigInt(count));
                }
                return true;
            }
            /*bool */ TryAdvanceTo(/*T*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                if (index !== -1)
                {
                    this.Advance(BigInt(advancePastDelimiter ? ((index + 1) | 0) : index));
                    return true;
                }
                return this.TryReadToInternal($.$discardRef(), delimiter, advancePastDelimiter, 0);
            }
            /*bool */ TryAdvanceToAny(/*scoped ReadOnlySpan<T>*/ delimiters, /*bool*/ advancePastDelimiter)
            {
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = $.$$.System.MemoryExtensions.IndexOfAny$4(T, remaining, delimiters);
                if (index !== -1)
                {
                    this.AdvanceCurrentSpan(BigInt(index + (advancePastDelimiter ? 1 : 0)));
                    return true;
                }
                return this.TryReadToAnyInternal($.$discardRef(), delimiters, advancePastDelimiter, 0);
            }
            /*long */ AdvancePast(/*T*/ value)
            {
                /*long*/ let start = this.Consumed;
                do
                {
                    /*int*/ let i;
                    for(i = this.CurrentSpanIndex; i < this.CurrentSpan.Length && $.$dsp(this.CurrentSpan.get_Item(i).$v, T, ($t) => $t.System$IEquatable$$$Equals, value, [T]); i++)
                    {
                    }
                    /*int*/ let advanced = ((i - this.CurrentSpanIndex) | 0);
                    if (advanced === 0)
                    {
                        break;
                    }
                    this.AdvanceCurrentSpan(BigInt(advanced));
                }
                while(this.CurrentSpanIndex === 0 && !this.End);
                return this.Consumed - start;
            }
            /*long */ AdvancePastAny(/*scoped ReadOnlySpan<T>*/ values)
            {
                /*long*/ let start = this.Consumed;
                do
                {
                    /*int*/ let i;
                    for(i = this.CurrentSpanIndex; i < this.CurrentSpan.Length && $.$$.System.MemoryExtensions.IndexOf$4(T, values, this.CurrentSpan.get_Item(i).$v) !== -1; i++)
                    {
                    }
                    /*int*/ let advanced = ((i - this.CurrentSpanIndex) | 0);
                    if (advanced === 0)
                    {
                        break;
                    }
                    this.AdvanceCurrentSpan(BigInt(advanced));
                }
                while(this.CurrentSpanIndex === 0 && !this.End);
                return this.Consumed - start;
            }
            /*long */ AdvancePastAny$1(/*T*/ value0, /*T*/ value1, /*T*/ value2, /*T*/ value3)
            {
                /*long*/ let start = this.Consumed;
                do
                {
                    /*int*/ let i;
                    for(i = this.CurrentSpanIndex; i < this.CurrentSpan.Length; i++)
                    {
                        /*T*/ let value = this.CurrentSpan.get_Item(i).$v;
                        if (!$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value0, [T]) && !$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value1, [T]) && !$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value2, [T]) && !$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value3, [T]))
                        {
                            break;
                        }
                    }
                    /*int*/ let advanced = ((i - this.CurrentSpanIndex) | 0);
                    if (advanced === 0)
                    {
                        break;
                    }
                    this.AdvanceCurrentSpan(BigInt(advanced));
                }
                while(this.CurrentSpanIndex === 0 && !this.End);
                return this.Consumed - start;
            }
            /*long */ AdvancePastAny$2(/*T*/ value0, /*T*/ value1, /*T*/ value2)
            {
                /*long*/ let start = this.Consumed;
                do
                {
                    /*int*/ let i;
                    for(i = this.CurrentSpanIndex; i < this.CurrentSpan.Length; i++)
                    {
                        /*T*/ let value = this.CurrentSpan.get_Item(i).$v;
                        if (!$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value0, [T]) && !$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value1, [T]) && !$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value2, [T]))
                        {
                            break;
                        }
                    }
                    /*int*/ let advanced = ((i - this.CurrentSpanIndex) | 0);
                    if (advanced === 0)
                    {
                        break;
                    }
                    this.AdvanceCurrentSpan(BigInt(advanced));
                }
                while(this.CurrentSpanIndex === 0 && !this.End);
                return this.Consumed - start;
            }
            /*long */ AdvancePastAny$3(/*T*/ value0, /*T*/ value1)
            {
                /*long*/ let start = this.Consumed;
                do
                {
                    /*int*/ let i;
                    for(i = this.CurrentSpanIndex; i < this.CurrentSpan.Length; i++)
                    {
                        /*T*/ let value = this.CurrentSpan.get_Item(i).$v;
                        if (!$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value0, [T]) && !$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value1, [T]))
                        {
                            break;
                        }
                    }
                    /*int*/ let advanced = ((i - this.CurrentSpanIndex) | 0);
                    if (advanced === 0)
                    {
                        break;
                    }
                    this.AdvanceCurrentSpan(BigInt(advanced));
                }
                while(this.CurrentSpanIndex === 0 && !this.End);
                return this.Consumed - start;
            }
            /*void */ AdvanceToEnd()
            {
                if (this._moreData)
                {
                    this.Consumed = this.Length;
                    this.CurrentSpan = new ($.$$.System.ReadOnlySpan$$(T))();
                    this.CurrentSpanIndex = 0;
                    this._currentPosition = this.Sequence.End;
                    this._nextPosition = new $.$sm.System.SequencePosition();
                    this._moreData = false;
                }
            }
            /*bool */ IsNext$1(/*T*/ next, /*bool*/ advancePast)
            {
                if (this.End)
                {
                    return false;
                }
                if ($.$dsp(this.CurrentSpan.get_Item(this.CurrentSpanIndex).$v, T, ($t) => $t.System$IEquatable$$$Equals, next, [T]))
                {
                    if (advancePast)
                    {
                        this.AdvanceCurrentSpan(1n);
                    }
                    return true;
                }
                return false;
            }
            /*bool */ IsNext(/*scoped ReadOnlySpan<T>*/ next, /*bool*/ advancePast)
            {
                /*ReadOnlySpan<T>*/ let unread = this.UnreadSpan;
                if ($.$$.System.MemoryExtensions.StartsWith$2(T, unread, next))
                {
                    if (advancePast)
                    {
                        this.AdvanceCurrentSpan(BigInt(next.Length));
                    }
                    return true;
                }
                return unread.Length < next.Length && this.IsNextSlow(next, advancePast);
            }
            /*bool */ IsNextSlow(/*scoped ReadOnlySpan<T>*/ next, /*bool*/ advancePast)
            {
                /*ReadOnlySpan<T>*/ let currentSpan = this.UnreadSpan;
                $.$$.System.Diagnostics.Debug.Assert$2(currentSpan.Length < next.Length, "currentSpan.Length < next.Length");
                /*int*/ let fullLength = next.Length;
                /*SequencePosition*/ let nextPosition = this._nextPosition;
                while($.$$.System.MemoryExtensions.StartsWith$2(T, next, currentSpan))
                {
                    if (next.Length === currentSpan.Length)
                    {
                        if (advancePast)
                        {
                            this.Advance(BigInt(fullLength));
                        }
                        return true;
                    }
                    while(true)
                    {
                        /*ReadOnlyMemory<T>*/ let nextSegment;
                        if (!this.Sequence.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => nextPosition, ($v) => nextPosition = $v, null), $.$ref(() => nextSegment, ($v) => nextSegment = $v, $.$$.System.ReadOnlyMemory$$(T)), true))
                        {
                            return false;
                        }
                        if (nextSegment.Length > 0)
                        {
                            next = next.Slice$1(currentSpan.Length);
                            currentSpan = nextSegment.Span;
                            if (currentSpan.Length > next.Length)
                            {
                                currentSpan = currentSpan.Slice(0, next.Length);
                            }
                            break;
                        }
                    }
                }
                return false;
            }
            /*SequencePosition*/  get _currentPosition() { return this.$getField(0, 8); }
            /*SequencePosition*/  set _currentPosition(value) { this.$setField(0, 8, value); }
            /*SequencePosition*/  get _nextPosition() { return this.$getField(8, 8); }
            /*SequencePosition*/  set _nextPosition(value) { this.$setField(8, 8, value); }
            /*bool*/  get _moreData() { return this.$getField(16, 1); }
            /*bool*/  set _moreData(value) { this.$setField(16, 1, value); }
            /*long*/  get _length() { return this.$getField(17, 8); }
            /*long*/  set _length(value) { this.$setField(17, 8, value); }
            $ctor$3(/*ReadOnlySequence<T>*/ sequence)
            {
                super.$ctor$1();
                {
                    this.CurrentSpanIndex = 0;
                    this.Consumed = 0n;
                    this.Sequence = sequence;
                    this._currentPosition = sequence.Start;
                    this._length = BigInt(-1);
                    /*ReadOnlySpan<T>*/ let first;
                    sequence.GetFirstSpan$1($.$ref(() => first, ($v) => first = $v, $.$$.System.ReadOnlySpan$$(T)), $.$ref(() => this._nextPosition, ($v) => this._nextPosition = $v, $.$sm.System.SequencePosition));
                    this.CurrentSpan = first;
                    this._moreData = first.Length > 0;
                    if (!this._moreData && !sequence.IsSingleSegment)
                    {
                        this._moreData = true;
                        this.GetNextSpan();
                    }
                }
                return this;
            }
            /*bool */ get End()
            {
                return !this._moreData;
            }
            /*ReadOnlySequence<T>*/ Sequence;
            /*ReadOnlySequence<T> */ get UnreadSequence()
            {
                return this.Sequence.Slice$8(this.Position);
            }
            /*SequencePosition */ get Position()
            {
                return this.Sequence.GetPosition(BigInt(this.CurrentSpanIndex), this._currentPosition);
            }
            /*ReadOnlySpan<T>*/ CurrentSpan;
            /*int*/ CurrentSpanIndex = 0;
            /*ReadOnlySpan<T> */ get UnreadSpan()
            {
                return this.CurrentSpan.Slice$1(this.CurrentSpanIndex);
            }
            /*long*/ Consumed = 0n;
            /*long */ get Remaining()
            {
                return this.Length - this.Consumed;
            }
            /*long */ get Length()
            {
                if (this._length < 0n)
                {
                    $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Int64, () => this, ($v) => $v.Clone(this), 17).$v = this.Sequence.Length;
                }
                return this._length;
            }
            /*bool */ TryPeek$1(/*out T*/ value)
            {
                if (this._moreData)
                {
                    value.$v = this.CurrentSpan.get_Item(this.CurrentSpanIndex).$v;
                    return true;
                }
                else 
                {
                    value.$v = $.$default(T);
                    return false;
                }
            }
            /*bool */ TryPeek(/*long*/ offset, /*out T*/ value)
            {
                if (offset < 0n)
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_OffsetOutOfRange();
                }
                if (!this._moreData || this.Remaining <= offset)
                {
                    value.$v = $.$default(T);
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(BigInt(this.CurrentSpanIndex) + offset >= 0n, "CurrentSpanIndex + offset >= 0");
                if ((BigInt(this.CurrentSpanIndex) + offset) <= BigInt(this.CurrentSpan.Length - 1))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(offset <= BigInt(2147483647/*int.MaxValue*/), "offset <= int.MaxValue");
                    value.$v = this.CurrentSpan.get_Item(((this.CurrentSpanIndex + $.$cast(offset, $.$$.System.Int32)) | 0)).$v;
                    return true;
                }
                else 
                {
                    /*long*/ let remainingOffset = offset - (BigInt(this.CurrentSpan.Length - this.CurrentSpanIndex));
                    /*SequencePosition*/ let nextPosition = this._nextPosition;
                    /*ReadOnlyMemory<T>*/ let currentMemory;
                    while(this.Sequence.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => nextPosition, ($v) => nextPosition = $v, null), $.$ref(() => currentMemory, ($v) => currentMemory = $v, $.$$.System.ReadOnlyMemory$$(T)), true))
                    {
                        if (currentMemory.Length > 0)
                        {
                            if (remainingOffset >= BigInt(currentMemory.Length))
                            {
                                remainingOffset -= BigInt(currentMemory.Length);
                            }
                            else 
                            {
                                break;
                            }
                        }
                    }
                    value.$v = currentMemory.Span.get_Item($.$cast(remainingOffset, $.$$.System.Int32)).$v;
                    return true;
                }
            }
            /*bool */ TryRead(/*out T*/ value)
            {
                if (this.End)
                {
                    value.$v = $.$default(T);
                    return false;
                }
                value.$v = this.CurrentSpan.get_Item(this.CurrentSpanIndex).$v;
                this.CurrentSpanIndex++;
                this.Consumed++;
                if (this.CurrentSpanIndex >= this.CurrentSpan.Length)
                {
                    this.GetNextSpan();
                }
                return true;
            }
            /*void */ Rewind(/*long*/ count)
            {
                if ($.$cast(count, $.$$.System.UInt64) > $.$cast(this.Consumed, $.$$.System.UInt64))
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(15/*ExceptionArgument.count*/);
                }
                if (count === 0n)
                {
                    return;
                }
                this.Consumed -= count;
                if (BigInt(this.CurrentSpanIndex) >= count)
                {
                    this.CurrentSpanIndex -= $.$cast(count, $.$$.System.Int32);
                    this._moreData = true;
                }
                else 
                {
                    this.RetreatToPreviousSpan(this.Consumed);
                }
            }
            /*void */ RetreatToPreviousSpan(/*long*/ consumed)
            {
                this.ResetReader();
                this.Advance(consumed);
            }
            /*void */ ResetReader()
            {
                this.CurrentSpanIndex = 0;
                this.Consumed = 0n;
                this._currentPosition = this.Sequence.Start;
                this._nextPosition = this._currentPosition;
                /*ReadOnlyMemory<T>*/ let memory;
                if (this.Sequence.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => this._nextPosition, ($v) => this._nextPosition = $v, null), $.$ref(() => memory, ($v) => memory = $v, $.$$.System.ReadOnlyMemory$$(T)), true))
                {
                    this._moreData = true;
                    if (memory.Length === 0)
                    {
                        this.CurrentSpan = new ($.$$.System.ReadOnlySpan$$(T))();
                        this.GetNextSpan();
                    }
                    else 
                    {
                        this.CurrentSpan = memory.Span;
                    }
                }
                else 
                {
                    this._moreData = false;
                    this.CurrentSpan = new ($.$$.System.ReadOnlySpan$$(T))();
                }
            }
            /*void */ GetNextSpan()
            {
                if (!this.Sequence.IsSingleSegment)
                {
                    /*SequencePosition*/ let previousNextPosition = this._nextPosition;
                    /*ReadOnlyMemory<T>*/ let memory;
                    while(this.Sequence.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => this._nextPosition, ($v) => this._nextPosition = $v, null), $.$ref(() => memory, ($v) => memory = $v, $.$$.System.ReadOnlyMemory$$(T)), true))
                    {
                        this._currentPosition = previousNextPosition;
                        if (memory.Length > 0)
                        {
                            this.CurrentSpan = memory.Span;
                            this.CurrentSpanIndex = 0;
                            return;
                        }
                        else 
                        {
                            this.CurrentSpan = new ($.$$.System.ReadOnlySpan$$(T))();
                            this.CurrentSpanIndex = 0;
                            previousNextPosition = this._nextPosition;
                        }
                    }
                }
                this._moreData = false;
            }
            /*void */ Advance(/*long*/ count)
            {
                /*long*/ let TooBigOrNegative = $.$cast(18446744071562067968n, $.$$.System.Int64);
                if ((count & TooBigOrNegative) === 0n && ((this.CurrentSpan.Length - this.CurrentSpanIndex) | 0) > $.$cast(count, $.$$.System.Int32))
                {
                    this.CurrentSpanIndex += $.$cast(count, $.$$.System.Int32);
                    this.Consumed += count;
                }
                else 
                {
                    this.AdvanceToNextSpan(count);
                }
            }
            /*void */ AdvanceCurrentSpan(/*long*/ count)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(count >= 0n, "count >= 0");
                this.Consumed += count;
                this.CurrentSpanIndex += $.$cast(count, $.$$.System.Int32);
                if (this.CurrentSpanIndex >= this.CurrentSpan.Length)
                {
                    this.GetNextSpan();
                }
            }
            /*void */ AdvanceWithinSpan(/*long*/ count)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(count >= 0n, "count >= 0");
                this.Consumed += count;
                this.CurrentSpanIndex += $.$cast(count, $.$$.System.Int32);
                $.$$.System.Diagnostics.Debug.Assert$2(this.CurrentSpanIndex < this.CurrentSpan.Length, "CurrentSpanIndex < CurrentSpan.Length");
            }
            /*void */ AdvanceToNextSpan(/*long*/ count)
            {
                if (count < 0n)
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(15/*ExceptionArgument.count*/);
                }
                this.Consumed += count;
                while(this._moreData)
                {
                    /*int*/ let remaining = ((this.CurrentSpan.Length - this.CurrentSpanIndex) | 0);
                    if (BigInt(remaining) > count)
                    {
                        this.CurrentSpanIndex += $.$cast(count, $.$$.System.Int32);
                        count = 0n;
                        break;
                    }
                    this.CurrentSpanIndex += remaining;
                    count -= BigInt(remaining);
                    $.$$.System.Diagnostics.Debug.Assert$2(count >= 0n, "count >= 0");
                    this.GetNextSpan();
                    if (count === 0n)
                    {
                        break;
                    }
                }
                if (count !== 0n)
                {
                    this.Consumed -= count;
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(15/*ExceptionArgument.count*/);
                }
            }
            /*bool */ TryCopyTo(/*Span<T>*/ destination)
            {
                /*ReadOnlySpan<T>*/ let firstSpan = this.UnreadSpan;
                if (firstSpan.Length >= destination.Length)
                {
                    firstSpan.Slice(0, destination.Length).CopyTo(destination);
                    return true;
                }
                return this.TryCopyMultisegment(destination);
            }
            /*bool */ TryCopyMultisegment(/*Span<T>*/ destination)
            {
                if (this.Remaining < BigInt(destination.Length))
                {
                    return false;
                }
                /*ReadOnlySpan<T>*/ let firstSpan = this.UnreadSpan;
                $.$$.System.Diagnostics.Debug.Assert$2(firstSpan.Length < destination.Length, "firstSpan.Length < destination.Length");
                firstSpan.CopyTo(destination);
                /*int*/ let copied = firstSpan.Length;
                /*SequencePosition*/ let next = this._nextPosition;
                /*ReadOnlyMemory<T>*/ let nextSegment;
                while(this.Sequence.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => next, ($v) => next = $v, null), $.$ref(() => nextSegment, ($v) => nextSegment = $v, $.$$.System.ReadOnlyMemory$$(T)), true))
                {
                    if (nextSegment.Length > 0)
                    {
                        /*ReadOnlySpan<T>*/ let nextSpan = nextSegment.Span;
                        /*int*/ let toCopy = $.$$.System.Math.Min$4(nextSpan.Length, ((destination.Length - copied) | 0));
                        nextSpan.Slice(0, toCopy).CopyTo(destination.Slice$1(copied));
                        copied += toCopy;
                        if (copied >= destination.Length)
                        {
                            break;
                        }
                    }
                }
                return true;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._currentPosition = this._currentPosition.Clone();
                copy._nextPosition = this._nextPosition.Clone();
                copy._moreData = this._moreData;
                copy._length = this._length;
                copy.Sequence = this.Sequence.Clone();
                copy.CurrentSpan = this.CurrentSpan.Clone();
                copy.CurrentSpanIndex = this.CurrentSpanIndex;
                copy.Consumed = this.Consumed;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._currentPosition = $.$default($.$sm.System.SequencePosition);
                this._nextPosition = $.$default($.$sm.System.SequencePosition);
                this._moreData = false;
                this._length = 0n;
                this.Sequence = $.$default($.$sm.System.Buffers.ReadOnlySequence$$(T));
                this.CurrentSpan = $.$default($.$$.System.ReadOnlySpan$$(T));
            }
            static $h = 957959;
            static $g = 1;
            static $z = 58;
            static $f = 0b1011000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2200000000n),"f":50331649},"n":"End","d":this.$h,"h":Number(BigInt(this.$h)|0x2100000000n),"f":2097153},{"p":$.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2500000000n),"f":50331649},"n":"Sequence","d":this.$h,"h":Number(BigInt(this.$h)|0x2400000000n),"f":2097153},{"p":$.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2700000000n),"f":50331649},"n":"UnreadSequence","d":this.$h,"h":Number(BigInt(this.$h)|0x2600000000n),"f":2097153},{"p":1220103,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2900000000n),"f":50331649},"n":"Position","d":this.$h,"h":Number(BigInt(this.$h)|0x2800000000n),"f":2097153},{"p":$.$$.System.ReadOnlySpan$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2C00000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x2D00000000n),"f":83886082},"n":"CurrentSpan","d":this.$h,"h":Number(BigInt(this.$h)|0x2B00000000n),"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3000000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3100000000n),"f":83886082},"n":"CurrentSpanIndex","d":this.$h,"h":Number(BigInt(this.$h)|0x2F00000000n),"f":2097153},{"p":$.$$.System.ReadOnlySpan$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3300000000n),"f":50331649},"n":"UnreadSpan","d":this.$h,"h":Number(BigInt(this.$h)|0x3200000000n),"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3600000000n),"f":50331649},"s":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3700000000n),"f":83886082},"n":"Consumed","d":this.$h,"h":Number(BigInt(this.$h)|0x3500000000n),"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3900000000n),"f":50331649},"n":"Remaining","d":this.$h,"h":Number(BigInt(this.$h)|0x3800000000n),"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x3B00000000n),"f":50331649},"n":"Length","d":this.$h,"h":Number(BigInt(this.$h)|0x3A00000000n),"f":2097153}],"m":[{"r":262145,"p":[{"n":"span","p":$.$$.System.ReadOnlySpan$$(T).$h,"f":2},{"n":"delimiter","p":T?.$h??1507328},{"n":"advancePastDelimiter","p":262145,"f":65,"v":true}],"n":"TryReadTo","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":16777217},{"r":262145,"p":[{"n":"span","p":$.$$.System.ReadOnlySpan$$(T).$h,"f":2},{"n":"delimiter","p":T?.$h??1507328},{"n":"advancePastDelimiter","p":262145}],"n":"TryReadToSlow","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777218},{"r":262145,"p":[{"n":"span","p":$.$$.System.ReadOnlySpan$$(T).$h,"f":2},{"n":"delimiter","p":T?.$h??1507328},{"n":"delimiterEscape","p":T?.$h??1507328},{"n":"advancePastDelimiter","p":262145,"f":65,"v":true}],"n":"TryReadTo","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16777217},{"r":262145,"p":[{"n":"span","p":$.$$.System.ReadOnlySpan$$(T).$h,"f":2},{"n":"delimiter","p":T?.$h??1507328},{"n":"delimiterEscape","p":T?.$h??1507328},{"n":"index","p":655361},{"n":"advancePastDelimiter","p":262145}],"n":"TryReadToSlow","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16777218},{"r":262145,"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"f":2},{"n":"delimiter","p":T?.$h??1507328},{"n":"delimiterEscape","p":T?.$h??1507328},{"n":"index","p":655361},{"n":"advancePastDelimiter","p":262145}],"n":"TryReadToSlow","o":"@$3","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777218},{"r":262145,"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"f":2},{"n":"delimiter","p":T?.$h??1507328},{"n":"advancePastDelimiter","p":262145,"f":65,"v":true}],"n":"TryReadTo","o":"@$4","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777217},{"r":262145,"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"f":2},{"n":"delimiter","p":T?.$h??1507328},{"n":"advancePastDelimiter","p":262145},{"n":"skip","p":655361,"f":65,"v":0}],"n":"TryReadToInternal","d":this.$h,"h":Number(BigInt(this.$h)|0x700000000n),"f":16777218},{"r":262145,"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"f":2},{"n":"delimiter","p":T?.$h??1507328},{"n":"delimiterEscape","p":T?.$h??1507328},{"n":"advancePastDelimiter","p":262145,"f":65,"v":true}],"n":"TryReadTo","o":"@$5","d":this.$h,"h":Number(BigInt(this.$h)|0x800000000n),"f":16777217},{"r":262145,"p":[{"n":"span","p":$.$$.System.ReadOnlySpan$$(T).$h,"f":2},{"n":"delimiters","p":$.$$.System.ReadOnlySpan$$(T).$h},{"n":"advancePastDelimiter","p":262145,"f":65,"v":true}],"n":"TryReadToAny","d":this.$h,"h":Number(BigInt(this.$h)|0x900000000n),"f":16777217},{"r":262145,"p":[{"n":"span","p":$.$$.System.ReadOnlySpan$$(T).$h,"f":2},{"n":"delimiters","p":$.$$.System.ReadOnlySpan$$(T).$h},{"n":"advancePastDelimiter","p":262145}],"n":"TryReadToAnySlow","d":this.$h,"h":Number(BigInt(this.$h)|0xA00000000n),"f":16777218},{"r":262145,"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"f":2},{"n":"delimiters","p":$.$$.System.ReadOnlySpan$$(T).$h},{"n":"advancePastDelimiter","p":262145,"f":65,"v":true}],"n":"TryReadToAny","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0xB00000000n),"f":16777217},{"r":262145,"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"f":2},{"n":"delimiters","p":$.$$.System.ReadOnlySpan$$(T).$h},{"n":"advancePastDelimiter","p":262145},{"n":"skip","p":655361,"f":65,"v":0}],"n":"TryReadToAnyInternal","d":this.$h,"h":Number(BigInt(this.$h)|0xC00000000n),"f":16777218},{"r":262145,"p":[{"n":"span","p":$.$$.System.ReadOnlySpan$$(T).$h,"f":2},{"n":"delimiter","p":$.$$.System.ReadOnlySpan$$(T).$h},{"n":"advancePastDelimiter","p":262145,"f":65,"v":true}],"n":"TryReadTo","d":this.$h,"h":Number(BigInt(this.$h)|0xD00000000n),"f":16777217},{"r":262145,"p":[{"n":"span","p":$.$$.System.ReadOnlySpan$$(T).$h,"f":2},{"n":"delimiter","p":$.$$.System.ReadOnlySpan$$(T).$h},{"n":"advancePastDelimiter","p":262145}],"n":"TryReadToSlow","d":this.$h,"h":Number(BigInt(this.$h)|0xE00000000n),"f":16777218},{"r":262145,"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"f":2},{"n":"delimiter","p":$.$$.System.ReadOnlySpan$$(T).$h},{"n":"advancePastDelimiter","p":262145,"f":65,"v":true}],"n":"TryReadTo","o":"@$3","d":this.$h,"h":Number(BigInt(this.$h)|0xF00000000n),"f":16777217},{"r":262145,"p":[{"n":"count","p":655361},{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$(T).$h,"f":2}],"n":"TryReadExact","d":this.$h,"h":Number(BigInt(this.$h)|0x1000000000n),"f":16777217},{"r":262145,"p":[{"n":"delimiter","p":T?.$h??1507328},{"n":"advancePastDelimiter","p":262145,"f":65,"v":true}],"n":"TryAdvanceTo","d":this.$h,"h":Number(BigInt(this.$h)|0x1100000000n),"f":16777217},{"r":262145,"p":[{"n":"delimiters","p":$.$$.System.ReadOnlySpan$$(T).$h},{"n":"advancePastDelimiter","p":262145,"f":65,"v":true}],"n":"TryAdvanceToAny","d":this.$h,"h":Number(BigInt(this.$h)|0x1200000000n),"f":16777217},{"r":917505,"p":[{"n":"value","p":T?.$h??1507328}],"n":"AdvancePast","d":this.$h,"h":Number(BigInt(this.$h)|0x1300000000n),"f":16777217},{"r":917505,"p":[{"n":"values","p":$.$$.System.ReadOnlySpan$$(T).$h}],"n":"AdvancePastAny","d":this.$h,"h":Number(BigInt(this.$h)|0x1400000000n),"f":16777217},{"r":917505,"p":[{"n":"value0","p":T?.$h??1507328},{"n":"value1","p":T?.$h??1507328},{"n":"value2","p":T?.$h??1507328},{"n":"value3","p":T?.$h??1507328}],"n":"AdvancePastAny","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1500000000n),"f":16777217},{"r":917505,"p":[{"n":"value0","p":T?.$h??1507328},{"n":"value1","p":T?.$h??1507328},{"n":"value2","p":T?.$h??1507328}],"n":"AdvancePastAny","o":"@$2","d":this.$h,"h":Number(BigInt(this.$h)|0x1600000000n),"f":16777217},{"r":917505,"p":[{"n":"value0","p":T?.$h??1507328},{"n":"value1","p":T?.$h??1507328}],"n":"AdvancePastAny","o":"@$3","d":this.$h,"h":Number(BigInt(this.$h)|0x1700000000n),"f":16777217},{"r":65537,"n":"AdvanceToEnd","d":this.$h,"h":Number(BigInt(this.$h)|0x1800000000n),"f":16777217},{"r":262145,"p":[{"n":"next","p":T?.$h??1507328},{"n":"advancePast","p":262145,"f":65,"v":false}],"n":"IsNext","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x1900000000n),"f":16777217},{"r":262145,"p":[{"n":"next","p":$.$$.System.ReadOnlySpan$$(T).$h},{"n":"advancePast","p":262145,"f":65,"v":false}],"n":"IsNext","d":this.$h,"h":Number(BigInt(this.$h)|0x1A00000000n),"f":16777217},{"r":262145,"p":[{"n":"next","p":$.$$.System.ReadOnlySpan$$(T).$h},{"n":"advancePast","p":262145}],"n":"IsNextSlow","d":this.$h,"h":Number(BigInt(this.$h)|0x1B00000000n),"f":16777218},{"r":262145,"p":[{"n":"value","p":T?.$h??1507328,"f":2}],"n":"TryPeek","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x3C00000000n),"f":16777217},{"r":262145,"p":[{"n":"offset","p":917505},{"n":"value","p":T?.$h??1507328,"f":2}],"n":"TryPeek","d":this.$h,"h":Number(BigInt(this.$h)|0x3D00000000n),"f":16777217},{"r":262145,"p":[{"n":"value","p":T?.$h??1507328,"f":2}],"n":"TryRead","d":this.$h,"h":Number(BigInt(this.$h)|0x3E00000000n),"f":16777217},{"r":65537,"p":[{"n":"count","p":917505}],"n":"Rewind","d":this.$h,"h":Number(BigInt(this.$h)|0x3F00000000n),"f":16777217},{"r":65537,"p":[{"n":"consumed","p":917505}],"n":"RetreatToPreviousSpan","d":this.$h,"h":Number(BigInt(this.$h)|0x4000000000n),"f":16777218},{"r":65537,"n":"ResetReader","d":this.$h,"h":Number(BigInt(this.$h)|0x4100000000n),"f":16777218},{"r":65537,"n":"GetNextSpan","d":this.$h,"h":Number(BigInt(this.$h)|0x4200000000n),"f":16777218},{"r":65537,"p":[{"n":"count","p":917505}],"n":"Advance","d":this.$h,"h":Number(BigInt(this.$h)|0x4300000000n),"f":16777217},{"r":65537,"p":[{"n":"count","p":917505}],"n":"AdvanceCurrentSpan","d":this.$h,"h":Number(BigInt(this.$h)|0x4400000000n),"f":16777224},{"r":65537,"p":[{"n":"count","p":917505}],"n":"AdvanceWithinSpan","d":this.$h,"h":Number(BigInt(this.$h)|0x4500000000n),"f":16777224},{"r":65537,"p":[{"n":"count","p":917505}],"n":"AdvanceToNextSpan","d":this.$h,"h":Number(BigInt(this.$h)|0x4600000000n),"f":16777218},{"r":262145,"p":[{"n":"destination","p":$.$$.System.Span$$(T).$h}],"n":"TryCopyTo","d":this.$h,"h":Number(BigInt(this.$h)|0x4700000000n),"f":16777217},{"r":262145,"p":[{"n":"destination","p":$.$$.System.Span$$(T).$h}],"n":"TryCopyMultisegment","d":this.$h,"h":Number(BigInt(this.$h)|0x4800000000n),"f":16777224}],"l":[{"t":1220103,"n":"_currentPosition","d":this.$h,"h":Number(BigInt(this.$h)|0x1C00000000n),"f":4194306},{"t":1220103,"n":"_nextPosition","d":this.$h,"h":Number(BigInt(this.$h)|0x1D00000000n),"f":4194306},{"t":262145,"n":"_moreData","d":this.$h,"h":Number(BigInt(this.$h)|0x1E00000000n),"f":4194306},{"t":917505,"n":"_length","d":this.$h,"h":Number(BigInt(this.$h)|0x1F00000000n),"f":4194306}],"c":[{"p":[{"n":"sequence","p":$.$sm.System.Buffers.ReadOnlySequence$$(T).$h}],"n":".ctor","o":"$ctor$3","d":this.$h,"h":Number(BigInt(this.$h)|0x2000000000n),"f":16777217},{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x4900000000n),"f":16777217}],"g":[T?.$h??1507328],"s":[{"n":"T","f":10,"c":[$.$$.System.IEquatable$$(T).$h]}],"r":1,"h":this.$h}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Buffers.SequenceReader<${T?.$fullName}>`; }
        }));
        
        $asm.$cls("$sm.System.Buffers.ArrayMemoryPool<>", (T) => $asm.$gt("$sm.System.Buffers.ArrayMemoryPool<>", [T], ($self) => class ArrayMemoryPool$$ extends $.$sm.System.Buffers.MemoryPool$$(T)
        {
            static $_ArrayMemoryPoolBuffer;
            static get ArrayMemoryPoolBuffer()
            {
                let $cls = $.$sm.System.Buffers.ArrayMemoryPool$$(T);
                return $cls.$_ArrayMemoryPoolBuffer ??= $asm.$ncls("$sm.System.Buffers.ArrayMemoryPool$$.ArrayMemoryPoolBuffer", ($self) => class ArrayMemoryPoolBuffer extends $.$$.System.Object
                {
                    /*T[]?*/ _array = null;
                    $ctor$1(/*int*/ size)
                    {
                        super.$ctor();
                        {
                            this._array = $.$$.System.Buffers.ArrayPool$$(T).Shared.Rent(size);
                        }
                        return this;
                    }
                    /*Memory<T> */ get Memory()
                    {
                        /*T[]?*/ let array = this._array;
                        $.$$.System.ObjectDisposedException.ThrowIf(array === null, this);
                        return new ($.$$.System.Memory$$(T))().$ctor$7(array);
                    }
                    /*void */ Dispose()
                    {
                        /*T[]?*/ let array = this._array;
                        if (array !== null)
                        {
                            this._array = null;
                            $.$$.System.Buffers.ArrayPool$$(T).Shared.Return(array, false);
                        }
                    }
                    //Generated interface implemetation for System.Buffers.IMemoryOwner<T>.Memory.get
                    get System$Buffers$IMemoryOwner$$$Memory()
                    {
                        return this.Memory;
                    }
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        return this.Dispose(...arguments);
                    }
                    static $h = 237063;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Memory$$(T).$h,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x400000000n),"f":50331649},"n":"Memory","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":2097153}],"m":[{"r":65537,"n":"Dispose","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16777217}],"l":[{"t":$.$typeArray(T).$h,"n":"_array","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"size","p":655361}],"n":".ctor","o":"$ctor$1","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217}],"i":[$.$$.System.Buffers.IMemoryOwner$$(T).$h,57540609],"d":$.$sm.System.Buffers.ArrayMemoryPool$$(T).$h,"h":this.$h}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Buffers.IMemoryOwner$$(T), $.$$.System.IDisposable ]; }
                    static get $fullName() { return `System.Buffers.ArrayMemoryPool<${T?.$fullName}>.ArrayMemoryPoolBuffer`; }
                }, $cls, ($v) => $cls.$_ArrayMemoryPoolBuffer = $v);
            }
            /*int */ get MaxBufferSize()
            {
                return $.$$.System.Array.MaxLength;
            }
            /*IMemoryOwner<T> */ Rent(/*int*/ minimumBufferSize)
            {
                if (minimumBufferSize === -1)
                {
                    minimumBufferSize = ((1 + ($.trunc(4095 / (T.$z??4)))) | 0);
                }
                else if ((BigInt((minimumBufferSize >>> 0))) > BigInt($.$$.System.Array.MaxLength))
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(2/*ExceptionArgument.minimumBufferSize*/);
                }
                return new ($.$sm.System.Buffers.ArrayMemoryPool$$(T).ArrayMemoryPoolBuffer)().$ctor$1(minimumBufferSize);
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 171527;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":655361,"g":{"r":0,"d":0,"h":Number(BigInt(this.$h)|0x300000000n),"f":50429953},"n":"MaxBufferSize","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":2195457}],"m":[{"r":$.$$.System.Buffers.IMemoryOwner$$(T).$h,"p":[{"n":"minimumBufferSize","p":655361,"f":65,"v":-1}],"n":"Rent","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16875521},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x500000000n),"f":16875524}],"c":[{"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x600000000n),"f":16777217}],"i":[57540609],"g":[T?.$h??1507328],"j":[$.$sm.System.Buffers.ArrayMemoryPool$$(T).ArrayMemoryPoolBuffer.$h],"r":1,"h":this.$h}; }
            static get $b() { return $.$sm.System.Buffers.MemoryPool$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Buffers.ArrayMemoryPool<${T?.$fullName}>`; }
        }));
        
        $asm.$str("$sm.System.SequencePosition", ($self) => class SequencePosition extends $.$$.System.ValueType
        {
            /*object?*/  get _object() { return this.$getField(0, 4); }
            /*object?*/  set _object(value) { this.$setField(0, 4, value); }
            /*int*/  get _integer() { return this.$getField(4, 4); }
            /*int*/  set _integer(value) { this.$setField(4, 4, value); }
            $ctor$3(/*object?*/ object, /*int*/ integer)
            {
                super.$ctor$1();
                {
                    this._object = object;
                    this._integer = integer;
                }
                return this;
            }
            /*object? */ GetObject()
            {
                return this._object;
            }
            /*int */ GetInteger()
            {
                return this._integer;
            }
            /*bool */ Equals$2(/*SequencePosition*/ other)
            {
                return this._integer === other._integer && $.$$.System.Object.Equals(this._object, other._object);
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$sm.System.SequencePosition, { set $v(v){ other = v; } }) && this.Equals$2(other);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sm.System.SequencePosition.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                const $t1 = this._object;
                return $.$$.System.HashCode.Combine$6($.$$.System.Int32, $.$$.System.Int32, $.$ifnn($t1, ($t) => $.$$.System.Object.GetHashCode.call($t)) ?? 0, this._integer);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sm.System.SequencePosition.GetHashCode.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.SequencePosition>.Equals(System.SequencePosition)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._object = this._object;
                copy._integer = this._integer;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._object = null;
                this._integer = 0;
            }
            static $h = 1220103;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":131073,"n":"GetObject","d":1220103,"h":17181089287,"f":16777217,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":655361,"n":"GetInteger","d":1220103,"h":21476056583,"f":16777217,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":262145,"p":[{"n":"other","p":1220103}],"n":"Equals","o":"@$2","d":1220103,"h":25771023879,"f":16777217},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":1220103,"h":30065991175,"f":16809985,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":655361,"n":"GetHashCode","d":1220103,"h":34360958471,"f":16809985,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}],"l":[{"t":131073,"n":"_object","d":1220103,"h":4296187399,"f":4194306},{"t":655361,"n":"_integer","d":1220103,"h":8591154695,"f":4194306}],"c":[{"p":[{"n":"object","p":131073},{"n":"integer","p":655361}],"n":".ctor","o":"$ctor$3","d":1220103,"h":12886121991,"f":16777217},{"n":".ctor","o":"$ctor$2","d":1220103,"h":38655925767,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$sm.System.SequencePosition).$h],"h":1220103}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sm.System.SequencePosition) ]; }
            static get $fullName() { return `System.SequencePosition`; }
        });
        
        $asm.$str("$sm.System.ExceptionArgument", ($self) => class ExceptionArgument extends $.$$.System.Enum
        {
            static length = 0;
            static start = 1;
            static minimumBufferSize = 2;
            static elementIndex = 3;
            static comparable = 4;
            static comparer = 5;
            static destination = 6;
            static offset = 7;
            static startSegment = 8;
            static endSegment = 9;
            static startIndex = 10;
            static endIndex = 11;
            static array = 12;
            static culture = 13;
            static manager = 14;
            static count = 15;
            static writer = 16;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "length": 0n,
                    "start": 1n,
                    "minimumBufferSize": 2n,
                    "elementIndex": 3n,
                    "comparable": 4n,
                    "comparer": 5n,
                    "destination": 6n,
                    "offset": 7n,
                    "startSegment": 8n,
                    "endSegment": 9n,
                    "startIndex": 10n,
                    "endIndex": 11n,
                    "array": 12n,
                    "culture": 13n,
                    "manager": 14n,
                    "count": 15n,
                    "writer": 16n
                };
            }
            static $h = 1089031;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1089031,"n":"length","d":1089031,"h":4296056327,"f":4194337},{"t":1089031,"n":"start","d":1089031,"h":8591023623,"f":4194337},{"t":1089031,"n":"minimumBufferSize","d":1089031,"h":12885990919,"f":4194337},{"t":1089031,"n":"elementIndex","d":1089031,"h":17180958215,"f":4194337},{"t":1089031,"n":"comparable","d":1089031,"h":21475925511,"f":4194337},{"t":1089031,"n":"comparer","d":1089031,"h":25770892807,"f":4194337},{"t":1089031,"n":"destination","d":1089031,"h":30065860103,"f":4194337},{"t":1089031,"n":"offset","d":1089031,"h":34360827399,"f":4194337},{"t":1089031,"n":"startSegment","d":1089031,"h":38655794695,"f":4194337},{"t":1089031,"n":"endSegment","d":1089031,"h":42950761991,"f":4194337},{"t":1089031,"n":"startIndex","d":1089031,"h":47245729287,"f":4194337},{"t":1089031,"n":"endIndex","d":1089031,"h":51540696583,"f":4194337},{"t":1089031,"n":"array","d":1089031,"h":55835663879,"f":4194337},{"t":1089031,"n":"culture","d":1089031,"h":60130631175,"f":4194337},{"t":1089031,"n":"manager","d":1089031,"h":64425598471,"f":4194337},{"t":1089031,"n":"count","d":1089031,"h":68720565767,"f":4194337},{"t":1089031,"n":"writer","d":1089031,"h":73015533063,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1089031,"h":77310500359,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1089031}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.ExceptionArgument`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))