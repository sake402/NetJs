
//--TRIMMABLE-BOUNDARY-START(8)
(async function () {
(function ($global, $, $$) {
    "use strict";
    let _;
    let $qOZnef;
    let $BftXfb;
    
    
    
	$.$asm(
    "NetJs.System.Memory", 
    {
  "h": 8,
  "f": "System.Memory",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Memory",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Memory",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(327688)
        $asm.$cls(`$sm.SB.IBufferWriter<>`, (T) => $asm.$gt(`$sm.SB.IBufferWriter<>`, [T], ($self) => class IBufferWriter$$
        {
            static $H = 327688;
            static $h = 327688;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295294984),
    {
      "r": 65537,
      "p": [
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Advance",
      "o": "SB$IBufferWriter$$$Advance",
      "d": this.$h,
      "H": 4295294984,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295294984),
//--TRIMMABLE-BOUNDARY-START(8590262280),
    {
      "r": $.$$.S.Memory$$(T).$h,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "GetMemory",
      "o": "SB$IBufferWriter$$$GetMemory",
      "d": this.$h,
      "H": 8590262280,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590262280),
//--TRIMMABLE-BOUNDARY-START(12885229576),
    {
      "r": $.$$.S.Span$$(T).$h,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "GetSpan",
      "o": "SB$IBufferWriter$$$GetSpan",
      "d": this.$h,
      "H": 12885229576,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885229576)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 327688,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Buffers.IBufferWriter<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Buffers${separator}IBufferWriter$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(327688)
        
        

        //--TRIMMABLE-BOUNDARY-START(851976)
        $asm.$cls(`$sm.SB.ReadOnlySequenceSegment<>`, (T) => $asm.$gt(`$sm.SB.ReadOnlySequenceSegment<>`, [T], ($self) => class ReadOnlySequenceSegment$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(47245492232)
            /*ReadOnlyMemory<T>*/ Memory;
            //--TRIMMABLE-BOUNDARY-END(47245492232)
            
            //--TRIMMABLE-BOUNDARY-START(51540459528)
            /*ReadOnlySequenceSegment<T>?*/ Next = null;
            //--TRIMMABLE-BOUNDARY-END(51540459528)
            
            //--TRIMMABLE-BOUNDARY-START(55835426824)
            /*long*/ RunningIndex = 0n;
            //--TRIMMABLE-BOUNDARY-END(55835426824)
            
            //--TRIMMABLE-BOUNDARY-START(17180721160)
            //default constructor overload
            $ctor$1()
            {
                super.$ctor();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180721160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180721160)
            
            //--TRIMMABLE-BOUNDARY-START(17180721160)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(17180721160)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(47245492232)
                this.Memory = $.$default($.$$.S.ReadOnlyMemory$$(T));
                //--TRIMMABLE-BOUNDARY-END(47245492232)
                
            }
            static $H = 851976;
            static $h = 851976;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245492232),
    {
      "p": $.$$.S.ReadOnlyMemory$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25770655752,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 64425361416,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 83886084
      },
      "n": "Memory",
      "d": this.$h,
      "H": 47245492232,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245492232),
//--TRIMMABLE-BOUNDARY-START(51540459528),
    {
      "p": this.$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34360590344,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 73015296008,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 83886084
      },
      "n": "Next",
      "d": this.$h,
      "H": 51540459528,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540459528),
//--TRIMMABLE-BOUNDARY-START(55835426824),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "H": 42950524936,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 81605230600,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 83886084
      },
      "n": "RunningIndex",
      "d": this.$h,
      "H": 55835426824,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835426824)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180721160),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 17180721160,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(17180721160)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 851976,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Buffers.ReadOnlySequenceSegment<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Buffers${separator}ReadOnlySequenceSegment$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(851976)
        
        

        //--TRIMMABLE-BOUNDARY-START(393224)
        $asm.$cls(`$sm.SB.MemoryPool<>`, (T) => $asm.$gt(`$sm.SB.MemoryPool<>`, [T], ($self) => class MemoryPool$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(47245033480)
            /*ArrayMemoryPool<T>*/ static s_shared = null;
            //--TRIMMABLE-BOUNDARY-END(47245033480)
            
            //--TRIMMABLE-BOUNDARY-START(51540000776)
            static /*MemoryPool<T> */ get Shared()
            {
                return $.$sm.SB.MemoryPool$$(T).s_shared;
            }
            //--TRIMMABLE-BOUNDARY-END(51540000776)
            
            //--TRIMMABLE-BOUNDARY-START(8590327816)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327816);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327816)
            
            //--TRIMMABLE-BOUNDARY-START(12885295112)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
                $.$$.S.GC.SuppressFinalize(this);
            }
            //--TRIMMABLE-BOUNDARY-END(12885295112)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(8590327816)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(8590327816)
            
            //--TRIMMABLE-BOUNDARY-START(4295360520)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295360520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(47245033480)
                    this.s_shared = new ($.$sm.SB.ArrayMemoryPool$$(T))().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(47245033480)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360520)
            
            static $H = 393224;
            static $h = 393224;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540000776),
    {
      "p": this.$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34360131592,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331681
      },
      "n": "Shared",
      "d": this.$h,
      "H": 51540000776,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(51540000776),
//--TRIMMABLE-BOUNDARY-START(38655098888),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25770197000,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331905
      },
      "n": "MaxBufferSize",
      "d": this.$h,
      "H": 38655098888,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38655098888)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950066184),
    {
      "r": $.$$.SB.IMemoryOwner$$(T).$h,
      "p": [
        {
          "n": "minBufferSize",
          "p": 655361,
          "f": 65,
          "v": -1
        }
      ],
      "n": "Rent",
      "d": this.$h,
      "H": 42950066184,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42950066184),
//--TRIMMABLE-BOUNDARY-START(12885295112),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "H": 12885295112,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885295112),
//--TRIMMABLE-BOUNDARY-START(17180262408),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": this.$h,
      "H": 17180262408,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(17180262408)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245033480),
    {
      "t": $.$sm.SB.ArrayMemoryPool$$(T).$h,
      "n": "s_shared",
      "d": this.$h,
      "H": 47245033480,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245033480)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327816),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 8590327816,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590327816)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 393224,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Buffers.MemoryPool<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Buffers${separator}MemoryPool$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(393224)
        
        

        //--TRIMMABLE-BOUNDARY-START(720904)
        $asm.$cls(`$sm.SB.ReadOnlySequenceDebugView<>`, (T) => $asm.$gt(`$sm.SB.ReadOnlySequenceDebugView<>`, [T], ($self) => class ReadOnlySequenceDebugView$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688200)
            /*T[]*/ _array = null;
            //--TRIMMABLE-BOUNDARY-END(4295688200)
            
            //--TRIMMABLE-BOUNDARY-START(8590655496)
            /*ReadOnlySequenceDebugViewSegments*/ _segments;
            //--TRIMMABLE-BOUNDARY-END(8590655496)
            
            //--TRIMMABLE-BOUNDARY-START(12885622792)
            $ctor$1(/*ReadOnlySequence<T>*/ sequence)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885622792);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._array = $.$sm.SB.BuffersExtensions.ToArray(T, $.$ref(() => sequence, ));
                    /*var*/ let segmentCount = 0;
                    let $en1 = sequence.GetEnumerator();
                    while ($en1.MoveNext())
                    {
                        let _ = $en1.Current;
                        {
                            segmentCount++;
                        }
                    }
                    /*var*/ let segments = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.ReadOnlyMemory$$(T)), null, [segmentCount], null);
                    /*int*/ let i = 0;
                    let $en2 = sequence.GetEnumerator();
                    while ($en2.MoveNext())
                    {
                        let readOnlyMemory = $en2.Current;
                        {
                            $.$$.System.Array.$WriteT1.call(segments, readOnlyMemory, i);
                            i++;
                        }
                    }
                    this._segments = (() =>
                    {
                        //new $.$sm.SB.ReadOnlySequenceDebugView$$(T).ReadOnlySequenceDebugViewSegments()
                        const $t3 = $.$sm.SB.ReadOnlySequenceDebugView$$(T).ReadOnlySequenceDebugViewSegments;
                        const $i3 = new $t3();
                        $i3.$ctor$2();
                        $i3.Segments = segments;
                        return $i3;
                    })();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622792)
            
            //--TRIMMABLE-BOUNDARY-START(17180590088)
            /*ReadOnlySequenceDebugViewSegments */ get BufferSegments()
            {
                return this._segments;
            }
            //--TRIMMABLE-BOUNDARY-END(17180590088)
            
            //--TRIMMABLE-BOUNDARY-START(38655426568)
            /*T[] */ get Items()
            {
                return this._array;
            }
            //--TRIMMABLE-BOUNDARY-END(38655426568)
            
            //--TRIMMABLE-BOUNDARY-START(786440)
            static $_ReadOnlySequenceDebugViewSegments;
            static get ReadOnlySequenceDebugViewSegments()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(786440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sm.SB.ReadOnlySequenceDebugView$$(T);
                return $cls.$_ReadOnlySequenceDebugViewSegments ??= $asm.$nstr(`$sm.SB.ReadOnlySequenceDebugView<${T?.$fullName}>.ReadOnlySequenceDebugViewSegments`, ($self) => class ReadOnlySequenceDebugViewSegments extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(21475622920)
                    /*ReadOnlyMemory<T>[]*/ Segments = null;
                    //--TRIMMABLE-BOUNDARY-END(21475622920)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590721032)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(8590721032);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590721032)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590721032)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590721032)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Segments = this.Segments;
                        return copy;
                    }
                    static $H = 786440;
                    static $h = 786440;
                    static $z = 4;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475622920),
    {
      "p": $.$typeArray($.$$.S.ReadOnlyMemory$$(T)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17180655624,
        "h": Number(BigInt(786440)|0x400000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 30065557512,
        "h": Number(BigInt(786440)|0x700000000n),
        "f": 83886081
      },
      "n": "Segments",
      "d": 786440,
      "H": 21475622920,
      "h": Number(BigInt(786440)|0x500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 70909953,
          "c": 8660844545,
          "a": [
            {
              "v": 3,
              "t": 70975489
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475622920)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590721032),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786440,
      "H": 8590721032,
      "h": Number(BigInt(786440)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590721032)
  ],
  "d": 720904,
  "H": 786440,
  "h": 786440,
  "a": [
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "Count = {Segments.Length}",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "Name",
          "v": "Segments",
          "t": 1310721
        }
      ]
    }
  ]
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Buffers.ReadOnlySequenceDebugView<${T?.$fullName}>+ReadOnlySequenceDebugViewSegments`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Buffers${separator}ReadOnlySequenceDebugView$${T?.$getFullName(separator)}$${separator}ReadOnlySequenceDebugViewSegments`; }
                }, $cls, ($v) => $cls.$_ReadOnlySequenceDebugViewSegments = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(786440)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590655496)
                this._segments = $.$default($.$sm.SB.ReadOnlySequenceDebugView$$(T).ReadOnlySequenceDebugViewSegments);
                //--TRIMMABLE-BOUNDARY-END(8590655496)
                
            }
            static $H = 720904;
            static $h = 720904;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180590088),
    {
      "p": 786440,
      "g": {
        "r": 0,
        "d": 0,
        "H": 25770524680,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "n": "BufferSegments",
      "d": this.$h,
      "H": 17180590088,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180590088),
//--TRIMMABLE-BOUNDARY-START(38655426568),
    {
      "p": $.$typeArray(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34360459272,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "n": "Items",
      "d": this.$h,
      "H": 38655426568,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153,
      "a": [
        {
          "t": 70909953,
          "c": 8660844545,
          "a": [
            {
              "v": 3,
              "t": 70975489
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655426568)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688200),
    {
      "t": $.$typeArray(T).$h,
      "n": "_array",
      "d": this.$h,
      "H": 4295688200,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688200),
//--TRIMMABLE-BOUNDARY-START(8590655496),
    {
      "t": 786440,
      "n": "_segments",
      "d": this.$h,
      "H": 8590655496,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655496)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885622792),
    {
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.SB.ReadOnlySequence$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 12885622792,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885622792)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 720904,
  "h": this.$h
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sm.SB.ReadOnlySequenceDebugView$$(T).ReadOnlySequenceDebugViewSegments ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Buffers.ReadOnlySequenceDebugView<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Buffers${separator}ReadOnlySequenceDebugView$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(720904)
        
        

        //--TRIMMABLE-BOUNDARY-START(262152)
        $asm.$cls(`$sm.SB.BuffersExtensions`, ($self) => class BuffersExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(12885164040)
            static /*SequencePosition? */ PositionOf(T, /*in this ReadOnlySequence<T>*/ source, /*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (source.$v.IsSingleSegment)
                {
                    /*int*/ let index = $.$$.S.MemoryExtensions.IndexOf$4(T, source.$v.First.Span, value);
                    if (index !== -1)
                    {
                        return source.$v.Seek$1(BigInt(index), 7);
                    }
                    return null;
                }
                else 
                {
                    return $.$sm.SB.BuffersExtensions.PositionOfMultiSegment(T, source, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885164040)
            
            //--TRIMMABLE-BOUNDARY-START(17180131336)
            static /*SequencePosition? */ PositionOfMultiSegment(T, /*in ReadOnlySequence<T>*/ source, /*T*/ value)
            {
                /*ReadOnlyMemory<T>*/ let memory;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SequencePosition*/ let position = source.$v.Start;
                /*SequencePosition*/ let result = position;
                while(source.$v.TryGet($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sm.S.SequencePosition, () => position, ($v) => position = $v, null, true), $.$ref(() => memory, ($v) => memory = $v, $.$$.S.ReadOnlyMemory$$(T)), true))
                {
                    /*int*/ let index = $.$$.S.MemoryExtensions.IndexOf$4(T, memory.Span, value);
                    if (index !== -1)
                    {
                        return source.$v.GetPosition(BigInt(index), result);
                    }
                    else if (position.GetObject() === null)
                    {
                        break;
                    }
                    result = position;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131336)
            
            //--TRIMMABLE-BOUNDARY-START(4295229448)
            static /*void */ CopyTo(T, /*in this ReadOnlySequence<T>*/ source, /*Span<T>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (source.$v.IsSingleSegment)
                {
                    /*ReadOnlySpan<T>*/ let span = source.$v.First.Span;
                    if (span.Length > destination.Length)
                    {
                        $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.destination*/);
                    }
                    span.CopyTo(destination);
                }
                else 
                {
                    $.$sm.SB.BuffersExtensions.CopyToMultiSegment(T, source, destination);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295229448)
            
            //--TRIMMABLE-BOUNDARY-START(8590196744)
            static /*void */ CopyToMultiSegment(T, /*in ReadOnlySequence<T>*/ sequence, /*Span<T>*/ destination)
            {
                /*ReadOnlyMemory<T>*/ let memory;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (sequence.$v.Length > BigInt(destination.Length))
                {
                    $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.destination*/);
                }
                /*SequencePosition*/ let position = sequence.$v.Start;
                while(sequence.$v.TryGet($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sm.S.SequencePosition, () => position, ($v) => position = $v, null, true), $.$ref(() => memory, ($v) => memory = $v, $.$$.S.ReadOnlyMemory$$(T)), true))
                {
                    /*ReadOnlySpan<T>*/ let span = memory.Span;
                    span.CopyTo(destination);
                    if (position.GetObject() !== null)
                    {
                        destination = destination.Slice$1(span.Length);
                    }
                    else 
                    {
                        break;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590196744)
            
            //--TRIMMABLE-BOUNDARY-START(21475098632)
            static /*T[] */ ToArray(T, /*in this ReadOnlySequence<T>*/ sequence)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let array = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(T), null, [sequence.$v.Length], null);
                $.$sm.SB.BuffersExtensions.CopyTo(T, sequence, $.$$.S.Span$$(T).op_Implicit$2(array));
                return array;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098632)
            
            //--TRIMMABLE-BOUNDARY-START(25770065928)
            static /*void */ Write(T, /*this IBufferWriter<T>*/ writer, /*ReadOnlySpan<T>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770065928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Span<T>*/ let destination = writer.SB$IBufferWriter$$$GetSpan(0);
                if (value.Length <= destination.Length)
                {
                    value.CopyTo(destination);
                    writer.SB$IBufferWriter$$$Advance(value.Length);
                }
                else 
                {
                    $.$sm.SB.BuffersExtensions.WriteMultiSegment(T, writer, $.$ref(() => value, ), destination);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770065928)
            
            //--TRIMMABLE-BOUNDARY-START(30065033224)
            static /*void */ WriteMultiSegment(T, /*IBufferWriter<T>*/ writer, /*in ReadOnlySpan<T>*/ source, /*Span<T>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let input = source.$v;
                while(true)
                {
                    /*int*/ let writeSize = $.$$.S.Math.Min$4(destination.Length, input.Length);
                    input.Slice(0, writeSize).CopyTo(destination);
                    writer.SB$IBufferWriter$$$Advance(writeSize);
                    input = input.Slice$1(writeSize);
                    if (input.Length > 0)
                    {
                        destination = writer.SB$IBufferWriter$$$GetSpan(0);
                        if (destination.IsEmpty)
                        {
                            $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException(16/*ExceptionArgument.writer*/);
                        }
                        continue;
                    }
                    return;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065033224)
            
            static $h = 262152;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885164040),
    {
      "r": $.$typeNullable($.$sm.S.SequencePosition).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$sm.SB.ReadOnlySequence$$(T).$h,
          "f": 8
        },
        {
          "n": "value",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "PositionOf",
      "d": 262152,
      "h": 12885164040,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885164040),
//--TRIMMABLE-BOUNDARY-START(17180131336),
    {
      "r": $.$typeNullable($.$sm.S.SequencePosition).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$sm.SB.ReadOnlySequence$$(T).$h,
          "f": 8
        },
        {
          "n": "value",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "PositionOfMultiSegment",
      "d": 262152,
      "h": 17180131336,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(17180131336),
//--TRIMMABLE-BOUNDARY-START(4295229448),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$sm.SB.ReadOnlySequence$$(T).$h,
          "f": 8
        },
        {
          "n": "destination",
          "p": (T) => $.$$.S.Span$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CopyTo",
      "d": 262152,
      "h": 4295229448,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295229448),
//--TRIMMABLE-BOUNDARY-START(8590196744),
    {
      "r": 65537,
      "p": [
        {
          "n": "sequence",
          "p": (T) => $.$sm.SB.ReadOnlySequence$$(T).$h,
          "f": 8
        },
        {
          "n": "destination",
          "p": (T) => $.$$.S.Span$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CopyToMultiSegment",
      "d": 262152,
      "h": 8590196744,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(8590196744),
//--TRIMMABLE-BOUNDARY-START(21475098632),
    {
      "r": (T) => $.$typeArray(T).$h,
      "p": [
        {
          "n": "sequence",
          "p": (T) => $.$sm.SB.ReadOnlySequence$$(T).$h,
          "f": 8
        }
      ],
      "g": [
        "T"
      ],
      "n": "ToArray",
      "d": 262152,
      "h": 21475098632,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21475098632),
//--TRIMMABLE-BOUNDARY-START(25770065928),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": (T) => $.$sm.SB.IBufferWriter$$(T).$h
        },
        {
          "n": "value",
          "p": (T) => $.$$.S.ReadOnlySpan$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Write",
      "d": 262152,
      "h": 25770065928,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25770065928),
//--TRIMMABLE-BOUNDARY-START(30065033224),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": (T) => $.$sm.SB.IBufferWriter$$(T).$h
        },
        {
          "n": "source",
          "p": (T) => $.$$.S.ReadOnlySpan$$(T).$h,
          "f": 8
        },
        {
          "n": "destination",
          "p": (T) => $.$$.S.Span$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "WriteMultiSegment",
      "d": 262152,
      "h": 30065033224,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(30065033224)
  ],
  "h": 262152
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Buffers.BuffersExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Buffers${separator}BuffersExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262152)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114120)
        $asm.$cls(`$sm.SRI.SequenceMarshal`, ($self) => class SequenceMarshal
        {
            //--TRIMMABLE-BOUNDARY-START(12886016008)
            static /*bool */ TryGetReadOnlySequenceSegment(T, /*ReadOnlySequence<T>*/ sequence, /*out ReadOnlySequenceSegment<T>?*/ startSegment, /*out int*/ startIndex, /*out ReadOnlySequenceSegment<T>?*/ endSegment, /*out int*/ endIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886016008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return sequence.TryGetReadOnlySequenceSegment(startSegment, startIndex, endSegment, endIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(12886016008)
            
            //--TRIMMABLE-BOUNDARY-START(4296081416)
            static /*bool */ TryGetArray(T, /*ReadOnlySequence<T>*/ sequence, /*out ArraySegment<T>*/ segment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296081416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return sequence.TryGetArray(segment);
            }
            //--TRIMMABLE-BOUNDARY-END(4296081416)
            
            //--TRIMMABLE-BOUNDARY-START(8591048712)
            static /*bool */ TryGetReadOnlyMemory(T, /*ReadOnlySequence<T>*/ sequence, /*out ReadOnlyMemory<T>*/ memory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591048712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!sequence.IsSingleSegment)
                {
                    memory.$v = new ($.$$.S.ReadOnlyMemory$$(T))();
                    return false;
                }
                memory.$v = sequence.First;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591048712)
            
            //--TRIMMABLE-BOUNDARY-START(17180983304)
            static /*bool */ TryGetString(/*ReadOnlySequence<char>*/ sequence, /*out string?*/ text, /*out int*/ start, /*out int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180983304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return sequence.TryGetString(text, start, length);
            }
            //--TRIMMABLE-BOUNDARY-END(17180983304)
            
            //--TRIMMABLE-BOUNDARY-START(21475950600)
            static /*bool */ TryRead(T, /*ref SequenceReader<byte>*/ reader, /*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475950600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sm.SB.SequenceReaderExtensions.TryRead(T, reader, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475950600)
            
            static $h = 1114120;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886016008),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": (T) => $.$sm.SB.ReadOnlySequence$$(T).$h
        },
        {
          "n": "startSegment",
          "p": (T) => $.$sm.SB.ReadOnlySequenceSegment$$(T).$h,
          "f": 2
        },
        {
          "n": "startIndex",
          "p": 655361,
          "f": 2
        },
        {
          "n": "endSegment",
          "p": (T) => $.$sm.SB.ReadOnlySequenceSegment$$(T).$h,
          "f": 2
        },
        {
          "n": "endIndex",
          "p": 655361,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryGetReadOnlySequenceSegment",
      "d": 1114120,
      "h": 12886016008,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886016008),
//--TRIMMABLE-BOUNDARY-START(4296081416),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": (T) => $.$sm.SB.ReadOnlySequence$$(T).$h
        },
        {
          "n": "segment",
          "p": (T) => $.$$.S.ArraySegment$$(T).$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryGetArray",
      "d": 1114120,
      "h": 4296081416,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4296081416),
//--TRIMMABLE-BOUNDARY-START(8591048712),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": (T) => $.$sm.SB.ReadOnlySequence$$(T).$h
        },
        {
          "n": "memory",
          "p": (T) => $.$$.S.ReadOnlyMemory$$(T).$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryGetReadOnlyMemory",
      "d": 1114120,
      "h": 8591048712,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8591048712),
//--TRIMMABLE-BOUNDARY-START(17180983304),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Char).$h
        },
        {
          "n": "text",
          "p": 1310721,
          "f": 2
        },
        {
          "n": "start",
          "p": 655361,
          "f": 2
        },
        {
          "n": "length",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryGetString",
      "d": 1114120,
      "h": 17180983304,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17180983304),
//--TRIMMABLE-BOUNDARY-START(21475950600),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.SB.SequenceReader$$($.$$.S.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": (T) => T.$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryRead",
      "d": 1114120,
      "h": 21475950600,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21475950600)
  ],
  "h": 1114120
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Runtime.InteropServices.SequenceMarshal`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Runtime${separator}InteropServices${separator}SequenceMarshal`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114120)
        
        

        //--TRIMMABLE-BOUNDARY-START(983048)
        $asm.$cls(`$sm.SB.SequenceReaderExtensions`, ($self) => class SequenceReaderExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295950344)
            static /*bool */ TryRead(T, /*ref this SequenceReader<byte>*/ reader, /*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let span = reader.$v.UnreadSpan;
                if (span.Length < (T.$z??4))
                {
                    return $.$sm.SB.SequenceReaderExtensions.TryReadMultisegment(T, reader, value);
                }
                value.$v = $.$$.SRI.MemoryMarshal.Read(T, span);
                reader.$v.Advance(BigInt((T.$z??4)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(4295950344)
            
            //--TRIMMABLE-BOUNDARY-START(34360721416)
            static /*bool */ TryReadMultisegment(T, /*ref SequenceReader<byte>*/ reader, /*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360721416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(reader.$v.UnreadSpan.Length < (T.$z??4), "reader.UnreadSpan.Length < sizeof(T)");
                /*T*/ let buffer = $.$default(T);
                /*Span<byte>*/ let tempSpan = new ($.$$.S.Span$$($.$$.S.Byte))().$ctor$5($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT(T, () => buffer, ($v) => buffer = $v, null, true), (T.$z??4));
                if (!reader.$v.TryCopyTo(tempSpan))
                {
                    value.$v = $.$default(T);
                    return false;
                }
                value.$v = $.$$.SRI.MemoryMarshal.Read(T, $.$$.S.Span$$($.$$.S.Byte).op_Implicit(tempSpan));
                reader.$v.Advance(BigInt((T.$z??4)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(34360721416)
            
            //--TRIMMABLE-BOUNDARY-START(21475819528)
            static /*bool */ TryReadLittleEndian(/*ref this SequenceReader<byte>*/ reader, /*out short*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.BitConverter.IsLittleEndian)
                {
                    return $.$sm.SB.SequenceReaderExtensions.TryRead($.$$.S.Int16, reader, value);
                }
                return $.$sm.SB.SequenceReaderExtensions.TryReadReverseEndianness(reader, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475819528)
            
            //--TRIMMABLE-BOUNDARY-START(8590917640)
            static /*bool */ TryReadBigEndian(/*ref this SequenceReader<byte>*/ reader, /*out short*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590917640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.S.BitConverter.IsLittleEndian)
                {
                    return $.$sm.SB.SequenceReaderExtensions.TryRead($.$$.S.Int16, reader, value);
                }
                return $.$sm.SB.SequenceReaderExtensions.TryReadReverseEndianness(reader, value);
            }
            //--TRIMMABLE-BOUNDARY-END(8590917640)
            
            //--TRIMMABLE-BOUNDARY-START(38655688712)
            static /*bool */ TryReadReverseEndianness(/*ref SequenceReader<byte>*/ reader, /*out short*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655688712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.SB.SequenceReaderExtensions.TryRead($.$$.S.Int16, reader, value))
                {
                    value.$v = $.$$.SBB.BinaryPrimitives.ReverseEndianness$3(value.$v);
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(38655688712)
            
            //--TRIMMABLE-BOUNDARY-START(25770786824)
            static /*bool */ TryReadLittleEndian$1(/*ref this SequenceReader<byte>*/ reader, /*out int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770786824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.BitConverter.IsLittleEndian)
                {
                    return $.$sm.SB.SequenceReaderExtensions.TryRead($.$$.S.Int32, reader, value);
                }
                return $.$sm.SB.SequenceReaderExtensions.TryReadReverseEndianness$1(reader, value);
            }
            //--TRIMMABLE-BOUNDARY-END(25770786824)
            
            //--TRIMMABLE-BOUNDARY-START(12885884936)
            static /*bool */ TryReadBigEndian$1(/*ref this SequenceReader<byte>*/ reader, /*out int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885884936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.S.BitConverter.IsLittleEndian)
                {
                    return $.$sm.SB.SequenceReaderExtensions.TryRead($.$$.S.Int32, reader, value);
                }
                return $.$sm.SB.SequenceReaderExtensions.TryReadReverseEndianness$1(reader, value);
            }
            //--TRIMMABLE-BOUNDARY-END(12885884936)
            
            //--TRIMMABLE-BOUNDARY-START(42950656008)
            static /*bool */ TryReadReverseEndianness$1(/*ref SequenceReader<byte>*/ reader, /*out int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950656008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.SB.SequenceReaderExtensions.TryRead($.$$.S.Int32, reader, value))
                {
                    value.$v = $.$$.SBB.BinaryPrimitives.ReverseEndianness$4(value.$v);
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(42950656008)
            
            //--TRIMMABLE-BOUNDARY-START(30065754120)
            static /*bool */ TryReadLittleEndian$2(/*ref this SequenceReader<byte>*/ reader, /*out long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065754120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.BitConverter.IsLittleEndian)
                {
                    return $.$sm.SB.SequenceReaderExtensions.TryRead($.$$.S.Int64, reader, value);
                }
                return $.$sm.SB.SequenceReaderExtensions.TryReadReverseEndianness$2(reader, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30065754120)
            
            //--TRIMMABLE-BOUNDARY-START(17180852232)
            static /*bool */ TryReadBigEndian$2(/*ref this SequenceReader<byte>*/ reader, /*out long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180852232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.S.BitConverter.IsLittleEndian)
                {
                    return $.$sm.SB.SequenceReaderExtensions.TryRead($.$$.S.Int64, reader, value);
                }
                return $.$sm.SB.SequenceReaderExtensions.TryReadReverseEndianness$2(reader, value);
            }
            //--TRIMMABLE-BOUNDARY-END(17180852232)
            
            //--TRIMMABLE-BOUNDARY-START(47245623304)
            static /*bool */ TryReadReverseEndianness$2(/*ref SequenceReader<byte>*/ reader, /*out long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245623304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.SB.SequenceReaderExtensions.TryRead($.$$.S.Int64, reader, value))
                {
                    value.$v = $.$$.SBB.BinaryPrimitives.ReverseEndianness$5(value.$v);
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(47245623304)
            
            static $h = 983048;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295950344),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.SB.SequenceReader$$($.$$.S.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": (T) => T.$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryRead",
      "d": 983048,
      "h": 4295950344,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(4295950344),
//--TRIMMABLE-BOUNDARY-START(34360721416),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.SB.SequenceReader$$($.$$.S.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": (T) => T.$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryReadMultisegment",
      "d": 983048,
      "h": 34360721416,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(34360721416),
//--TRIMMABLE-BOUNDARY-START(21475819528),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.SB.SequenceReader$$($.$$.S.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 524289,
          "f": 2
        }
      ],
      "n": "TryReadLittleEndian",
      "d": 983048,
      "h": 21475819528,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475819528),
//--TRIMMABLE-BOUNDARY-START(8590917640),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.SB.SequenceReader$$($.$$.S.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 524289,
          "f": 2
        }
      ],
      "n": "TryReadBigEndian",
      "d": 983048,
      "h": 8590917640,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590917640),
//--TRIMMABLE-BOUNDARY-START(38655688712),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.SB.SequenceReader$$($.$$.S.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 524289,
          "f": 2
        }
      ],
      "n": "TryReadReverseEndianness",
      "d": 983048,
      "h": 38655688712,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38655688712),
//--TRIMMABLE-BOUNDARY-START(25770786824),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.SB.SequenceReader$$($.$$.S.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadLittleEndian",
      "o": "@$1",
      "d": 983048,
      "h": 25770786824,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770786824),
//--TRIMMABLE-BOUNDARY-START(12885884936),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.SB.SequenceReader$$($.$$.S.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadBigEndian",
      "o": "@$1",
      "d": 983048,
      "h": 12885884936,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885884936),
//--TRIMMABLE-BOUNDARY-START(42950656008),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.SB.SequenceReader$$($.$$.S.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadReverseEndianness",
      "o": "@$1",
      "d": 983048,
      "h": 42950656008,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42950656008),
//--TRIMMABLE-BOUNDARY-START(30065754120),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.SB.SequenceReader$$($.$$.S.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "TryReadLittleEndian",
      "o": "@$2",
      "d": 983048,
      "h": 30065754120,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065754120),
//--TRIMMABLE-BOUNDARY-START(17180852232),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.SB.SequenceReader$$($.$$.S.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "TryReadBigEndian",
      "o": "@$2",
      "d": 983048,
      "h": 17180852232,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180852232),
//--TRIMMABLE-BOUNDARY-START(47245623304),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.SB.SequenceReader$$($.$$.S.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "TryReadReverseEndianness",
      "o": "@$2",
      "d": 983048,
      "h": 47245623304,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47245623304)
  ],
  "h": 983048
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Buffers.SequenceReaderExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Buffers${separator}SequenceReaderExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983048)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245192)
        $asm.$cls(`$sm.S.SR`, ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(231929479176)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(231929479176)
            
            //--TRIMMABLE-BOUNDARY-START(201864708104)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    /*bool*/ let usingResourceKeys;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201864708104);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.S.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.S.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201864708104)
            
            //--TRIMMABLE-BOUNDARY-START(244814381064)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(244814381064);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sm.S.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(244814381064)
            
            //--TRIMMABLE-BOUNDARY-START(197569740808)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569740808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.S.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sm.S.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(197569740808)
            
            //--TRIMMABLE-BOUNDARY-START(193274773512)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274773512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$sm.S.SR.GetResourceString$1(resourceKey);
                return resourceKey === resourceString || resourceString === null ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(193274773512)
            
            //--TRIMMABLE-BOUNDARY-START(68720721928)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720721928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(68720721928)
            
            //--TRIMMABLE-BOUNDARY-START(64425754632)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425754632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(64425754632)
            
            //--TRIMMABLE-BOUNDARY-START(60130787336)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130787336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(60130787336)
            
            //--TRIMMABLE-BOUNDARY-START(73015689224)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015689224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sm.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(73015689224)
            
            //--TRIMMABLE-BOUNDARY-START(51540852744)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540852744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.S.String.Format$4(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(51540852744)
            
            //--TRIMMABLE-BOUNDARY-START(47245885448)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245885448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.S.String.Format$3(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(47245885448)
            
            //--TRIMMABLE-BOUNDARY-START(42950918152)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950918152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.S.SR.UsingResourceKeys())
                {
                    return $.$$.S.String.Join$7(", ", $.$$.S.ReadOnlySpan$$($.$$.S.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.S.String.Format$2(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(42950918152)
            
            //--TRIMMABLE-BOUNDARY-START(55835820040)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835820040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sm.S.SR.UsingResourceKeys())
                    {
                        return $.$strNN(resourceFormat) + ", " + $.$strNN($.$$.S.String.Join$6(", ", args));
                    }
                    return $.$$.S.String.Format$5(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(55835820040)
            
            //--TRIMMABLE-BOUNDARY-START(227634511880)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(227634511880)
            
            //--TRIMMABLE-BOUNDARY-START(219044577288)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(219044577288)
            
            //--TRIMMABLE-BOUNDARY-START(223339544584)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979806216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.S.Object.ReferenceEquals($.$sm.S.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.SR$1.ResourceManager().$ctor$3("System.Memory", $.$sm.S.SR.$type.Assembly);
                    $.$sm.S.SR.s_resourceManager = temp;
                }
                return $.$sm.S.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(223339544584)
            
            //--TRIMMABLE-BOUNDARY-START(34360983560)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030133256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sm.S.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519413768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sm.S.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34360983560)
            
            //--TRIMMABLE-BOUNDARY-START(206159675400)
            static /*string */ get NotSupported_CannotCallEqualsOnSpan()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210002440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Equals() on Span and ReadOnlySpan is not supported. Use operator== instead.";
            }
            //--TRIMMABLE-BOUNDARY-END(206159675400)
            
            //--TRIMMABLE-BOUNDARY-START(210454642696)
            static /*string */ get NotSupported_CannotCallGetHashCodeOnSpan()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799937032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "GetHashCode() on Span and ReadOnlySpan is not supported.";
            }
            //--TRIMMABLE-BOUNDARY-END(210454642696)
            
            //--TRIMMABLE-BOUNDARY-START(17181114376)
            static /*string */ get Argument_InvalidTypeWithPointersNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670394888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot use type '{0}'. Only value types without pointers or references are supported.";
            }
            //--TRIMMABLE-BOUNDARY-END(17181114376)
            
            //--TRIMMABLE-BOUNDARY-START(77310656520)
            static /*string */ FormatArgument_InvalidTypeWithPointersNotSupported(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310656520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Cannot use type '{0}'. Only value types without pointers or references are supported.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(77310656520)
            
            //--TRIMMABLE-BOUNDARY-START(12886147080)
            static /*string */ get Argument_DestinationTooShort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080460296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Destination is too short.";
            }
            //--TRIMMABLE-BOUNDARY-END(12886147080)
            
            //--TRIMMABLE-BOUNDARY-START(214749609992)
            static /*string */ get OutstandingReferences()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389871624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Release all references before disposing this instance.";
            }
            //--TRIMMABLE-BOUNDARY-END(214749609992)
            
            //--TRIMMABLE-BOUNDARY-START(8591179784)
            static /*string */ get Argument_BadFormatSpecifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490525704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Format specifier was invalid.";
            }
            //--TRIMMABLE-BOUNDARY-END(8591179784)
            
            //--TRIMMABLE-BOUNDARY-START(21476081672)
            static /*string */ get Argument_OverlapAlignmentMismatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260329480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Overlapping spans have mismatching alignment.";
            }
            //--TRIMMABLE-BOUNDARY-END(21476081672)
            
            //--TRIMMABLE-BOUNDARY-START(38655950856)
            static /*string */ get EndPositionNotReached()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620067848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "End position was not reached during enumeration.";
            }
            //--TRIMMABLE-BOUNDARY-END(38655950856)
            
            //--TRIMMABLE-BOUNDARY-START(30066016264)
            static /*string */ get BufferWriterAdvancedTooFar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440198664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot advance past the end of the buffer, which has a size of {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(30066016264)
            
            //--TRIMMABLE-BOUNDARY-START(85900591112)
            static /*string */ FormatBufferWriterAdvancedTooFar(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900591112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Cannot advance past the end of the buffer, which has a size of {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(85900591112)
            
            //--TRIMMABLE-BOUNDARY-START(25771048968)
            static /*string */ get BufferMaximumSizeExceeded()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850264072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot allocate a buffer of size {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(25771048968)
            
            //--TRIMMABLE-BOUNDARY-START(81605623816)
            static /*string */ FormatBufferMaximumSizeExceeded(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605623816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.S.String.Format$9("Cannot allocate a buffer of size {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(81605623816)
            
            //--TRIMMABLE-BOUNDARY-START(4296212488)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296212488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(231929479176)
                    this.s_usingResourceKeys = $.$sm.S.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(231929479176)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296212488)
            
            static $h = 1245192;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1245192
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SR`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245192)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376264)
        $asm.$cls(`$sm.S.ThrowHelper`, ($self) => class ThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(42951049224)
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951049224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$sm.S.ThrowHelper.CreateArgumentNullException(argument);
            }
            //--TRIMMABLE-BOUNDARY-END(42951049224)
            
            //--TRIMMABLE-BOUNDARY-START(4296343560)
            static /*ArgumentNullException */ CreateArgumentNullException(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296343560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.S.ArgumentNullException().$ctor$19($.$$.S.Enum.ToStringT($.$sm.S.ExceptionArgument, $.$$.S.UInt32, argument));
            }
            //--TRIMMABLE-BOUNDARY-END(4296343560)
            
            //--TRIMMABLE-BOUNDARY-START(55835951112)
            static /*void */ ThrowArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835951112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$sm.S.ThrowHelper.CreateArgumentOutOfRangeException(argument);
            }
            //--TRIMMABLE-BOUNDARY-END(55835951112)
            
            //--TRIMMABLE-BOUNDARY-START(17181245448)
            static /*ArgumentOutOfRangeException */ CreateArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181245448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.S.ArgumentOutOfRangeException().$ctor$20($.$$.S.Enum.ToStringT($.$sm.S.ExceptionArgument, $.$$.S.UInt32, argument));
            }
            //--TRIMMABLE-BOUNDARY-END(17181245448)
            
            //--TRIMMABLE-BOUNDARY-START(73015820296)
            static /*void */ ThrowInvalidOperationException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015820296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$sm.S.ThrowHelper.CreateInvalidOperationException();
            }
            //--TRIMMABLE-BOUNDARY-END(73015820296)
            
            //--TRIMMABLE-BOUNDARY-START(34361114632)
            static /*InvalidOperationException */ CreateInvalidOperationException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361114632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.S.InvalidOperationException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(34361114632)
            
            //--TRIMMABLE-BOUNDARY-START(68720853000)
            static /*void */ ThrowInvalidOperationException_EndPositionNotReached()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720853000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$sm.S.ThrowHelper.CreateInvalidOperationException_EndPositionNotReached();
            }
            //--TRIMMABLE-BOUNDARY-END(68720853000)
            
            //--TRIMMABLE-BOUNDARY-START(30066147336)
            static /*InvalidOperationException */ CreateInvalidOperationException_EndPositionNotReached()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066147336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.S.InvalidOperationException().$ctor$12($.$sm.S.SR.EndPositionNotReached);
            }
            //--TRIMMABLE-BOUNDARY-END(30066147336)
            
            //--TRIMMABLE-BOUNDARY-START(51540983816)
            static /*void */ ThrowArgumentOutOfRangeException_PositionOutOfRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540983816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$sm.S.ThrowHelper.CreateArgumentOutOfRangeException_PositionOutOfRange();
            }
            //--TRIMMABLE-BOUNDARY-END(51540983816)
            
            //--TRIMMABLE-BOUNDARY-START(12886278152)
            static /*ArgumentOutOfRangeException */ CreateArgumentOutOfRangeException_PositionOutOfRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886278152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.S.ArgumentOutOfRangeException().$ctor$20("position");
            }
            //--TRIMMABLE-BOUNDARY-END(12886278152)
            
            //--TRIMMABLE-BOUNDARY-START(47246016520)
            static /*void */ ThrowArgumentOutOfRangeException_OffsetOutOfRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246016520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$sm.S.ThrowHelper.CreateArgumentOutOfRangeException_OffsetOutOfRange();
            }
            //--TRIMMABLE-BOUNDARY-END(47246016520)
            
            //--TRIMMABLE-BOUNDARY-START(8591310856)
            static /*ArgumentOutOfRangeException */ CreateArgumentOutOfRangeException_OffsetOutOfRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591310856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.S.ArgumentOutOfRangeException().$ctor$20("offset");
            }
            //--TRIMMABLE-BOUNDARY-END(8591310856)
            
            //--TRIMMABLE-BOUNDARY-START(64425885704)
            static /*void */ ThrowArgumentValidationException$1(T, /*ReadOnlySequenceSegment<T>?*/ startSegment, /*int*/ startIndex, /*ReadOnlySequenceSegment<T>?*/ endSegment)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425885704);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sm.S.ThrowHelper.CreateArgumentValidationException$1(T, startSegment, startIndex, endSegment);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425885704)
            
            //--TRIMMABLE-BOUNDARY-START(25771180040)
            static /*Exception */ CreateArgumentValidationException$1(T, /*ReadOnlySequenceSegment<T>?*/ startSegment, /*int*/ startIndex, /*ReadOnlySequenceSegment<T>?*/ endSegment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771180040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (startSegment === null)
                {
                    return $.$sm.S.ThrowHelper.CreateArgumentNullException(8/*ExceptionArgument.startSegment*/);
                }
                else if (endSegment === null)
                {
                    return $.$sm.S.ThrowHelper.CreateArgumentNullException(9/*ExceptionArgument.endSegment*/);
                }
                else if (startSegment !== endSegment && startSegment.RunningIndex > endSegment.RunningIndex)
                {
                    return $.$sm.S.ThrowHelper.CreateArgumentOutOfRangeException(9/*ExceptionArgument.endSegment*/);
                }
                else if ((startSegment.Memory.Length >>> 0) < (startIndex >>> 0))
                {
                    return $.$sm.S.ThrowHelper.CreateArgumentOutOfRangeException(10/*ExceptionArgument.startIndex*/);
                }
                else 
                {
                    return $.$sm.S.ThrowHelper.CreateArgumentOutOfRangeException(11/*ExceptionArgument.endIndex*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771180040)
            
            //--TRIMMABLE-BOUNDARY-START(60130918408)
            static /*void */ ThrowArgumentValidationException(/*Array?*/ array, /*int*/ start)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130918408);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sm.S.ThrowHelper.CreateArgumentValidationException(array, start);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130918408)
            
            //--TRIMMABLE-BOUNDARY-START(21476212744)
            static /*Exception */ CreateArgumentValidationException(/*Array?*/ array, /*int*/ start)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476212744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (array === null)
                {
                    return $.$sm.S.ThrowHelper.CreateArgumentNullException(12/*ExceptionArgument.array*/);
                }
                else if ((start >>> 0) > (array.length >>> 0))
                {
                    return $.$sm.S.ThrowHelper.CreateArgumentOutOfRangeException(1/*ExceptionArgument.start*/);
                }
                else 
                {
                    return $.$sm.S.ThrowHelper.CreateArgumentOutOfRangeException(0/*ExceptionArgument.length*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476212744)
            
            //--TRIMMABLE-BOUNDARY-START(77310787592)
            static /*void */ ThrowStartOrEndArgumentValidationException(/*long*/ start)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310787592);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sm.S.ThrowHelper.CreateStartOrEndArgumentValidationException(start);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310787592)
            
            //--TRIMMABLE-BOUNDARY-START(38656081928)
            static /*ArgumentOutOfRangeException */ CreateStartOrEndArgumentValidationException(/*long*/ start)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656081928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (start < 0n)
                {
                    return $.$sm.S.ThrowHelper.CreateArgumentOutOfRangeException(1/*ExceptionArgument.start*/);
                }
                return $.$sm.S.ThrowHelper.CreateArgumentOutOfRangeException(0/*ExceptionArgument.length*/);
            }
            //--TRIMMABLE-BOUNDARY-END(38656081928)
            
            static $h = 1376264;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(42951049224),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1048584
        }
      ],
      "n": "ThrowArgumentNullException",
      "d": 1376264,
      "h": 42951049224,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42951049224),
//--TRIMMABLE-BOUNDARY-START(4296343560),
    {
      "r": 45023233,
      "p": [
        {
          "n": "argument",
          "p": 1048584
        }
      ],
      "n": "CreateArgumentNullException",
      "d": 1376264,
      "h": 4296343560,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4296343560),
//--TRIMMABLE-BOUNDARY-START(55835951112),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1048584
        }
      ],
      "n": "ThrowArgumentOutOfRangeException",
      "d": 1376264,
      "h": 55835951112,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55835951112),
//--TRIMMABLE-BOUNDARY-START(17181245448),
    {
      "r": 45088769,
      "p": [
        {
          "n": "argument",
          "p": 1048584
        }
      ],
      "n": "CreateArgumentOutOfRangeException",
      "d": 1376264,
      "h": 17181245448,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17181245448),
//--TRIMMABLE-BOUNDARY-START(73015820296),
    {
      "r": 65537,
      "n": "ThrowInvalidOperationException",
      "d": 1376264,
      "h": 73015820296,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(73015820296),
//--TRIMMABLE-BOUNDARY-START(34361114632),
    {
      "r": 91815937,
      "n": "CreateInvalidOperationException",
      "d": 1376264,
      "h": 34361114632,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34361114632),
//--TRIMMABLE-BOUNDARY-START(68720853000),
    {
      "r": 65537,
      "n": "ThrowInvalidOperationException_EndPositionNotReached",
      "d": 1376264,
      "h": 68720853000,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(68720853000),
//--TRIMMABLE-BOUNDARY-START(30066147336),
    {
      "r": 91815937,
      "n": "CreateInvalidOperationException_EndPositionNotReached",
      "d": 1376264,
      "h": 30066147336,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066147336),
//--TRIMMABLE-BOUNDARY-START(51540983816),
    {
      "r": 65537,
      "n": "ThrowArgumentOutOfRangeException_PositionOutOfRange",
      "d": 1376264,
      "h": 51540983816,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51540983816),
//--TRIMMABLE-BOUNDARY-START(12886278152),
    {
      "r": 45088769,
      "n": "CreateArgumentOutOfRangeException_PositionOutOfRange",
      "d": 1376264,
      "h": 12886278152,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12886278152),
//--TRIMMABLE-BOUNDARY-START(47246016520),
    {
      "r": 65537,
      "n": "ThrowArgumentOutOfRangeException_OffsetOutOfRange",
      "d": 1376264,
      "h": 47246016520,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(47246016520),
//--TRIMMABLE-BOUNDARY-START(8591310856),
    {
      "r": 45088769,
      "n": "CreateArgumentOutOfRangeException_OffsetOutOfRange",
      "d": 1376264,
      "h": 8591310856,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8591310856),
//--TRIMMABLE-BOUNDARY-START(64425885704),
    {
      "r": 65537,
      "p": [
        {
          "n": "startSegment",
          "p": (T) => $.$sm.SB.ReadOnlySequenceSegment$$(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endSegment",
          "p": (T) => $.$sm.SB.ReadOnlySequenceSegment$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "ThrowArgumentValidationException",
      "o": "@$1",
      "d": 1376264,
      "h": 64425885704,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(64425885704),
//--TRIMMABLE-BOUNDARY-START(25771180040),
    {
      "r": 80805889,
      "p": [
        {
          "n": "startSegment",
          "p": (T) => $.$sm.SB.ReadOnlySequenceSegment$$(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endSegment",
          "p": (T) => $.$sm.SB.ReadOnlySequenceSegment$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateArgumentValidationException",
      "o": "@$1",
      "d": 1376264,
      "h": 25771180040,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(25771180040),
//--TRIMMABLE-BOUNDARY-START(60130918408),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "start",
          "p": 655361
        }
      ],
      "n": "ThrowArgumentValidationException",
      "d": 1376264,
      "h": 60130918408,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60130918408),
//--TRIMMABLE-BOUNDARY-START(21476212744),
    {
      "r": 80805889,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "start",
          "p": 655361
        }
      ],
      "n": "CreateArgumentValidationException",
      "d": 1376264,
      "h": 21476212744,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(21476212744),
//--TRIMMABLE-BOUNDARY-START(77310787592),
    {
      "r": 65537,
      "p": [
        {
          "n": "start",
          "p": 917505
        }
      ],
      "n": "ThrowStartOrEndArgumentValidationException",
      "d": 1376264,
      "h": 77310787592,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77310787592),
//--TRIMMABLE-BOUNDARY-START(38656081928),
    {
      "r": 45088769,
      "p": [
        {
          "n": "start",
          "p": 917505
        }
      ],
      "n": "CreateStartOrEndArgumentValidationException",
      "d": 1376264,
      "h": 38656081928,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38656081928)
  ],
  "h": 1376264
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ThrowHelper`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376264)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310728)
        $asm.$cls(`$sm.ST.EncodingExtensions`, ($self) => class EncodingExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(55835885576)
            /*int*/ static MaxInputElementsPerIteration = 1048576;
            //--TRIMMABLE-BOUNDARY-END(55835885576)
            
            //--TRIMMABLE-BOUNDARY-START(34361049096)
            static /*long */ GetBytes$3(/*this Encoding*/ encoding, /*ReadOnlySpan<char>*/ chars, /*IBufferWriter<byte>*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361049096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (chars.Length <= 1048576/*MaxInputElementsPerIteration*/)
                {
                    /*int*/ let byteCount = encoding.GetByteCount$4(chars);
                    /*Span<byte>*/ let scratchBuffer = writer.SB$IBufferWriter$$$GetSpan(byteCount);
                    /*int*/ let actualBytesWritten = encoding.GetBytes$5(chars, scratchBuffer);
                    writer.SB$IBufferWriter$$$Advance(actualBytesWritten);
                    return BigInt(actualBytesWritten);
                }
                else 
                {
                    /*long*/ let totalBytesWritten;
                    $.$sm.ST.EncodingExtensions.Convert$3(encoding.GetEncoder(), chars, writer, true, $.$ref(() => totalBytesWritten, ($v) => totalBytesWritten = $v, $.$$.S.Int64), $.$discardRef());
                    return totalBytesWritten;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361049096)
            
            //--TRIMMABLE-BOUNDARY-START(21476147208)
            static /*long */ GetBytes(/*this Encoding*/ encoding, /*in ReadOnlySequence<char>*/ chars, /*IBufferWriter<byte>*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476147208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (chars.$v.IsSingleSegment)
                {
                    return $.$sm.ST.EncodingExtensions.GetBytes$3(encoding, chars.$v.FirstSpan, writer);
                }
                else 
                {
                    /*long*/ let bytesWritten;
                    $.$sm.ST.EncodingExtensions.Convert$2(encoding.GetEncoder(), chars, writer, true, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.S.Int64), $.$discardRef());
                    return bytesWritten;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476147208)
            
            //--TRIMMABLE-BOUNDARY-START(25771114504)
            static /*int */ GetBytes$1(/*this Encoding*/ encoding, /*in ReadOnlySequence<char>*/ chars, /*Span<byte>*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771114504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                if (chars.$v.IsSingleSegment)
                {
                    return encoding.GetBytes$5(chars.$v.FirstSpan, bytes);
                }
                else 
                {
                    /*ReadOnlySequence<char>*/ let remainingChars = chars.$v;
                    /*int*/ let originalBytesLength = bytes.Length;
                    /*Encoder*/ let encoder = encoding.GetEncoder();
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<char>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        remainingChars.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.S.ReadOnlySpan$$($.$$.S.Char)), $.$ref(() => next, ($v) => next = $v, $.$sm.S.SequencePosition));
                        isFinalSegment = remainingChars.IsSingleSegment;
                        /*int*/ let bytesWrittenJustNow = encoder.GetBytes$2(firstSpan, bytes, isFinalSegment);
                        bytes = bytes.Slice$1(bytesWrittenJustNow);
                        remainingChars = remainingChars.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    return ((originalBytesLength - bytes.Length) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771114504)
            
            //--TRIMMABLE-BOUNDARY-START(30066081800)
            static /*byte[] */ GetBytes$2(/*this Encoding*/ encoding, /*in ReadOnlySequence<char>*/ chars)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066081800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                if (chars.$v.IsSingleSegment)
                {
                    /*ReadOnlySpan<char>*/ let span = chars.$v.FirstSpan;
                    /*byte[]*/ let retVal = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [encoding.GetByteCount$4(span)], null);
                    encoding.GetBytes$5(span, $.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(retVal));
                    return retVal;
                }
                else 
                {
                    /*Encoder*/ let encoder = encoding.GetEncoder();
                    /*List<(byte[], int)>*/ let listOfSegments = new ($.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$typeArray($.$$.S.Byte), $.$$.S.Int32)))().$ctor$1();
                    /*int*/ let totalByteCount = 0;
                    /*ReadOnlySequence<char>*/ let remainingChars = chars.$v;
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<char>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        remainingChars.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.S.ReadOnlySpan$$($.$$.S.Char)), $.$ref(() => next, ($v) => next = $v, $.$sm.S.SequencePosition));
                        isFinalSegment = remainingChars.IsSingleSegment;
                        /*int*/ let byteCountThisIteration = encoder.GetByteCount$2(firstSpan, isFinalSegment);
                        /*byte[]*/ let rentedArray = $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Rent(byteCountThisIteration);
                        /*int*/ let actualBytesWrittenThisIteration = encoder.GetBytes$2(firstSpan, $.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(rentedArray), isFinalSegment);
                        listOfSegments.Add(new ($.$$.S.ValueTuple$$$($.$typeArray($.$$.S.Byte), $.$$.S.Int32))().$ctor$3(rentedArray, actualBytesWrittenThisIteration));
                        totalByteCount += actualBytesWrittenThisIteration;
                        if (totalByteCount < 0)
                        {
                            totalByteCount = 2147483647/*int.MaxValue*/;
                            break;
                        }
                        remainingChars = remainingChars.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    /*byte[]*/ let retVal = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf($.$$.S.Byte), null, [totalByteCount], null);
                    /*Span<byte>*/ let remainingBytes = $.$$.S.Span$$($.$$.S.Byte).op_Implicit$2(retVal);
                    let $en8 = listOfSegments.GetEnumerator();
                    while ($en8.MoveNext())
                    {
                        let $t9 = $en8.Current;
                        /*byte[]*/ let array = $t9.Item1;
                        /*int*/ let length = $t9.Item2;
                        {
                            $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Byte, array, 0, length).CopyTo(remainingBytes);
                            $.$$.SB.ArrayPool$$($.$$.S.Byte).Shared.Return(array, false);
                            remainingBytes = remainingBytes.Slice$1(length);
                        }
                    }
                    $.$$.SD.Debug.Assert$4(remainingBytes.IsEmpty, "Over-allocated the byte[] instance?");
                    return retVal;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066081800)
            
            //--TRIMMABLE-BOUNDARY-START(47245950984)
            static /*long */ GetChars$2(/*this Encoding*/ encoding, /*ReadOnlySpan<byte>*/ bytes, /*IBufferWriter<char>*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245950984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (bytes.Length <= 1048576/*MaxInputElementsPerIteration*/)
                {
                    /*int*/ let charCount = encoding.GetCharCount$4(bytes);
                    /*Span<char>*/ let scratchBuffer = writer.SB$IBufferWriter$$$GetSpan(charCount);
                    /*int*/ let actualCharsWritten = encoding.GetChars$5(bytes, scratchBuffer);
                    writer.SB$IBufferWriter$$$Advance(actualCharsWritten);
                    return BigInt(actualCharsWritten);
                }
                else 
                {
                    /*long*/ let totalCharsWritten;
                    $.$sm.ST.EncodingExtensions.Convert$1(encoding.GetDecoder(), bytes, writer, true, $.$ref(() => totalCharsWritten, ($v) => totalCharsWritten = $v, $.$$.S.Int64), $.$discardRef());
                    return totalCharsWritten;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245950984)
            
            //--TRIMMABLE-BOUNDARY-START(38656016392)
            static /*long */ GetChars(/*this Encoding*/ encoding, /*in ReadOnlySequence<byte>*/ bytes, /*IBufferWriter<char>*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656016392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (bytes.$v.IsSingleSegment)
                {
                    return $.$sm.ST.EncodingExtensions.GetChars$2(encoding, bytes.$v.FirstSpan, writer);
                }
                else 
                {
                    /*long*/ let charsWritten;
                    $.$sm.ST.EncodingExtensions.Convert(encoding.GetDecoder(), bytes, writer, true, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.S.Int64), $.$discardRef());
                    return charsWritten;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656016392)
            
            //--TRIMMABLE-BOUNDARY-START(42950983688)
            static /*int */ GetChars$1(/*this Encoding*/ encoding, /*in ReadOnlySequence<byte>*/ bytes, /*Span<char>*/ chars)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950983688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                if (bytes.$v.IsSingleSegment)
                {
                    return encoding.GetChars$5(bytes.$v.FirstSpan, chars);
                }
                else 
                {
                    /*ReadOnlySequence<byte>*/ let remainingBytes = bytes.$v;
                    /*int*/ let originalCharsLength = chars.Length;
                    /*Decoder*/ let decoder = encoding.GetDecoder();
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<byte>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        remainingBytes.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.S.ReadOnlySpan$$($.$$.S.Byte)), $.$ref(() => next, ($v) => next = $v, $.$sm.S.SequencePosition));
                        isFinalSegment = remainingBytes.IsSingleSegment;
                        /*int*/ let charsWrittenJustNow = decoder.GetChars$3(firstSpan, chars, isFinalSegment);
                        chars = chars.Slice$1(charsWrittenJustNow);
                        remainingBytes = remainingBytes.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    return ((originalCharsLength - chars.Length) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950983688)
            
            //--TRIMMABLE-BOUNDARY-START(51540918280)
            static /*string */ GetString(/*this Encoding*/ encoding, /*in ReadOnlySequence<byte>*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540918280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                if (bytes.$v.IsSingleSegment)
                {
                    return encoding.GetString$3(bytes.$v.FirstSpan);
                }
                else 
                {
                    /*Decoder*/ let decoder = encoding.GetDecoder();
                    /*List<(char[], int)>*/ let listOfSegments = new ($.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$typeArray($.$$.S.Char), $.$$.S.Int32)))().$ctor$1();
                    /*int*/ let totalCharCount = 0;
                    /*ReadOnlySequence<byte>*/ let remainingBytes = bytes.$v;
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<byte>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        remainingBytes.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.S.ReadOnlySpan$$($.$$.S.Byte)), $.$ref(() => next, ($v) => next = $v, $.$sm.S.SequencePosition));
                        isFinalSegment = remainingBytes.IsSingleSegment;
                        /*int*/ let charCountThisIteration = decoder.GetCharCount$3(firstSpan, isFinalSegment);
                        /*char[]*/ let rentedArray = $.$$.SB.ArrayPool$$($.$$.S.Char).Shared.Rent(charCountThisIteration);
                        /*int*/ let actualCharsWrittenThisIteration = decoder.GetChars$3(firstSpan, $.$$.S.Span$$($.$$.S.Char).op_Implicit$2(rentedArray), isFinalSegment);
                        listOfSegments.Add(new ($.$$.S.ValueTuple$$$($.$typeArray($.$$.S.Char), $.$$.S.Int32))().$ctor$3(rentedArray, actualCharsWrittenThisIteration));
                        totalCharCount += actualCharsWrittenThisIteration;
                        if (totalCharCount < 0)
                        {
                            totalCharCount = 2147483647/*int.MaxValue*/;
                            break;
                        }
                        remainingBytes = remainingBytes.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    return $.$$.S.String.Create$10($.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$typeArray($.$$.S.Char), $.$$.S.Int32)), totalCharCount, listOfSegments, new ($.$$.SB.SpanAction$$$($.$$.S.Char, $.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$typeArray($.$$.S.Char), $.$$.S.Int32))))().$ctor(this,  (/*span*/ span, /*listOfSegments*/ listOfSegments) =>
                    {
                        let $en17 = listOfSegments.GetEnumerator();
                        while ($en17.MoveNext())
                        {
                            let $t18 = $en17.Current;
                            /*char[]*/ let array = $t18.Item1;
                            /*int*/ let length = $t18.Item2;
                            {
                                $.$$.S.MemoryExtensions.AsSpan$11($.$$.S.Char, array, 0, length).CopyTo(span);
                                $.$$.SB.ArrayPool$$($.$$.S.Char).Shared.Return(array, false);
                                span = span.Slice$1(length);
                            }
                        }
                        $.$$.SD.Debug.Assert$4(span.IsEmpty, "Over-allocated the string instance?");
                    }, $qOZnef ??= {"r":65537,"p":[{"n":"span","p":$.$$.S.Span$$($.$$.S.Char).$h},{"n":"listOfSegments","p":$.$$.SCG.List$$($.$$.S.ValueTuple$$$($.$typeArray($.$$.S.Char), $.$$.S.Int32)).$h}],"n":"","d":1310728,"h":0,"f":17825794}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540918280)
            
            //--TRIMMABLE-BOUNDARY-START(17181179912)
            static /*void */ Convert$3(/*this Encoder*/ encoder, /*ReadOnlySpan<char>*/ chars, /*IBufferWriter<byte>*/ writer, /*bool*/ flush, /*out long*/ bytesUsed, /*out bool*/ completed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181179912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(encoder, "encoder");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                /*long*/ let totalBytesWritten = 0n;
                do
                {
                    /*int*/ let charsUsedJustNow;
                    /*int*/ let bytesWrittenJustNow;
                    /*int*/ let byteCountForThisSlice = (chars.Length <= 1048576/*MaxInputElementsPerIteration*/) ? encoder.GetByteCount$2(chars, flush) : encoder.GetByteCount$2(chars.Slice(0, 1048576/*MaxInputElementsPerIteration*/), false);
                    /*Span<byte>*/ let scratchBuffer = writer.SB$IBufferWriter$$$GetSpan(byteCountForThisSlice);
                    encoder.Convert$2(chars, scratchBuffer, flush, $.$ref(() => charsUsedJustNow, ($v) => charsUsedJustNow = $v, $.$$.S.Int32), $.$ref(() => bytesWrittenJustNow, ($v) => bytesWrittenJustNow = $v, $.$$.S.Int32), completed);
                    chars = chars.Slice$1(charsUsedJustNow);
                    writer.SB$IBufferWriter$$$Advance(bytesWrittenJustNow);
                    totalBytesWritten += BigInt(bytesWrittenJustNow);
                }
                while(!chars.IsEmpty);
                bytesUsed.$v = totalBytesWritten;
            }
            //--TRIMMABLE-BOUNDARY-END(17181179912)
            
            //--TRIMMABLE-BOUNDARY-START(12886212616)
            static /*void */ Convert$2(/*this Encoder*/ encoder, /*in ReadOnlySequence<char>*/ chars, /*IBufferWriter<byte>*/ writer, /*bool*/ flush, /*out long*/ bytesUsed, /*out bool*/ completed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886212616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (chars.$v.IsSingleSegment)
                {
                    $.$sm.ST.EncodingExtensions.Convert$3(encoder, chars.$v.FirstSpan, writer, flush, bytesUsed, completed);
                }
                else 
                {
                    /*ReadOnlySequence<char>*/ let remainingChars = chars.$v;
                    /*long*/ let totalBytesWritten = 0n;
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<char>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        /*long*/ let bytesWrittenThisIteration;
                        remainingChars.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.S.ReadOnlySpan$$($.$$.S.Char)), $.$ref(() => next, ($v) => next = $v, $.$sm.S.SequencePosition));
                        isFinalSegment = remainingChars.IsSingleSegment;
                        $.$sm.ST.EncodingExtensions.Convert$3(encoder, firstSpan, writer, flush && isFinalSegment, $.$ref(() => bytesWrittenThisIteration, ($v) => bytesWrittenThisIteration = $v, $.$$.S.Int64), completed);
                        totalBytesWritten += bytesWrittenThisIteration;
                        remainingChars = remainingChars.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    bytesUsed.$v = totalBytesWritten;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12886212616)
            
            //--TRIMMABLE-BOUNDARY-START(8591245320)
            static /*void */ Convert$1(/*this Decoder*/ decoder, /*ReadOnlySpan<byte>*/ bytes, /*IBufferWriter<char>*/ writer, /*bool*/ flush, /*out long*/ charsUsed, /*out bool*/ completed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591245320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.S.ArgumentNullException.ThrowIfNull$2(decoder, "decoder");
                $.$$.S.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                /*long*/ let totalCharsWritten = 0n;
                do
                {
                    /*int*/ let bytesUsedJustNow;
                    /*int*/ let charsWrittenJustNow;
                    /*int*/ let charCountForThisSlice = (bytes.Length <= 1048576/*MaxInputElementsPerIteration*/) ? decoder.GetCharCount$3(bytes, flush) : decoder.GetCharCount$3(bytes.Slice(0, 1048576/*MaxInputElementsPerIteration*/), false);
                    /*Span<char>*/ let scratchBuffer = writer.SB$IBufferWriter$$$GetSpan(charCountForThisSlice);
                    decoder.Convert$2(bytes, scratchBuffer, flush, $.$ref(() => bytesUsedJustNow, ($v) => bytesUsedJustNow = $v, $.$$.S.Int32), $.$ref(() => charsWrittenJustNow, ($v) => charsWrittenJustNow = $v, $.$$.S.Int32), completed);
                    bytes = bytes.Slice$1(bytesUsedJustNow);
                    writer.SB$IBufferWriter$$$Advance(charsWrittenJustNow);
                    totalCharsWritten += BigInt(charsWrittenJustNow);
                }
                while(!bytes.IsEmpty);
                charsUsed.$v = totalCharsWritten;
            }
            //--TRIMMABLE-BOUNDARY-END(8591245320)
            
            //--TRIMMABLE-BOUNDARY-START(4296278024)
            static /*void */ Convert(/*this Decoder*/ decoder, /*in ReadOnlySequence<byte>*/ bytes, /*IBufferWriter<char>*/ writer, /*bool*/ flush, /*out long*/ charsUsed, /*out bool*/ completed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (bytes.$v.IsSingleSegment)
                {
                    $.$sm.ST.EncodingExtensions.Convert$1(decoder, bytes.$v.FirstSpan, writer, flush, charsUsed, completed);
                }
                else 
                {
                    /*ReadOnlySequence<byte>*/ let remainingBytes = bytes.$v;
                    /*long*/ let totalCharsWritten = 0n;
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<byte>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        /*long*/ let charsWrittenThisIteration;
                        remainingBytes.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.S.ReadOnlySpan$$($.$$.S.Byte)), $.$ref(() => next, ($v) => next = $v, $.$sm.S.SequencePosition));
                        isFinalSegment = remainingBytes.IsSingleSegment;
                        $.$sm.ST.EncodingExtensions.Convert$1(decoder, firstSpan, writer, flush && isFinalSegment, $.$ref(() => charsWrittenThisIteration, ($v) => charsWrittenThisIteration = $v, $.$$.S.Int64), completed);
                        totalCharsWritten += charsWrittenThisIteration;
                        remainingBytes = remainingBytes.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    charsUsed.$v = totalCharsWritten;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296278024)
            
            static $h = 1310728;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361049096),
    {
      "r": 917505,
      "p": [
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "chars",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "writer",
          "p": $.$sm.SB.IBufferWriter$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetBytes",
      "o": "@$3",
      "d": 1310728,
      "h": 34361049096,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34361049096),
//--TRIMMABLE-BOUNDARY-START(21476147208),
    {
      "r": 917505,
      "p": [
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "chars",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Char).$h,
          "f": 8
        },
        {
          "n": "writer",
          "p": $.$sm.SB.IBufferWriter$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetBytes",
      "d": 1310728,
      "h": 21476147208,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476147208),
//--TRIMMABLE-BOUNDARY-START(25771114504),
    {
      "r": 655361,
      "p": [
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "chars",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Char).$h,
          "f": 8
        },
        {
          "n": "bytes",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "GetBytes",
      "o": "@$1",
      "d": 1310728,
      "h": 25771114504,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771114504),
//--TRIMMABLE-BOUNDARY-START(30066081800),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "chars",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Char).$h,
          "f": 8
        }
      ],
      "n": "GetBytes",
      "o": "@$2",
      "d": 1310728,
      "h": 30066081800,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066081800),
//--TRIMMABLE-BOUNDARY-START(47245950984),
    {
      "r": 917505,
      "p": [
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "bytes",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "writer",
          "p": $.$sm.SB.IBufferWriter$$($.$$.S.Char).$h
        }
      ],
      "n": "GetChars",
      "o": "@$2",
      "d": 1310728,
      "h": 47245950984,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245950984),
//--TRIMMABLE-BOUNDARY-START(38656016392),
    {
      "r": 917505,
      "p": [
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "bytes",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h,
          "f": 8
        },
        {
          "n": "writer",
          "p": $.$sm.SB.IBufferWriter$$($.$$.S.Char).$h
        }
      ],
      "n": "GetChars",
      "d": 1310728,
      "h": 38656016392,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38656016392),
//--TRIMMABLE-BOUNDARY-START(42950983688),
    {
      "r": 655361,
      "p": [
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "bytes",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h,
          "f": 8
        },
        {
          "n": "chars",
          "p": $.$$.S.Span$$($.$$.S.Char).$h
        }
      ],
      "n": "GetChars",
      "o": "@$1",
      "d": 1310728,
      "h": 42950983688,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950983688),
//--TRIMMABLE-BOUNDARY-START(51540918280),
    {
      "r": 1310721,
      "p": [
        {
          "n": "encoding",
          "p": 166723585
        },
        {
          "n": "bytes",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h,
          "f": 8
        }
      ],
      "n": "GetString",
      "d": 1310728,
      "h": 51540918280,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540918280),
//--TRIMMABLE-BOUNDARY-START(17181179912),
    {
      "r": 65537,
      "p": [
        {
          "n": "encoder",
          "p": 166002689
        },
        {
          "n": "chars",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Char).$h
        },
        {
          "n": "writer",
          "p": $.$sm.SB.IBufferWriter$$($.$$.S.Byte).$h
        },
        {
          "n": "flush",
          "p": 262145
        },
        {
          "n": "bytesUsed",
          "p": 917505,
          "f": 2
        },
        {
          "n": "completed",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "Convert",
      "o": "@$3",
      "d": 1310728,
      "h": 17181179912,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181179912),
//--TRIMMABLE-BOUNDARY-START(12886212616),
    {
      "r": 65537,
      "p": [
        {
          "n": "encoder",
          "p": 166002689
        },
        {
          "n": "chars",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Char).$h,
          "f": 8
        },
        {
          "n": "writer",
          "p": $.$sm.SB.IBufferWriter$$($.$$.S.Byte).$h
        },
        {
          "n": "flush",
          "p": 262145
        },
        {
          "n": "bytesUsed",
          "p": 917505,
          "f": 2
        },
        {
          "n": "completed",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "Convert",
      "o": "@$2",
      "d": 1310728,
      "h": 12886212616,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886212616),
//--TRIMMABLE-BOUNDARY-START(8591245320),
    {
      "r": 65537,
      "p": [
        {
          "n": "decoder",
          "p": 165412865
        },
        {
          "n": "bytes",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "writer",
          "p": $.$sm.SB.IBufferWriter$$($.$$.S.Char).$h
        },
        {
          "n": "flush",
          "p": 262145
        },
        {
          "n": "charsUsed",
          "p": 917505,
          "f": 2
        },
        {
          "n": "completed",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "Convert",
      "o": "@$1",
      "d": 1310728,
      "h": 8591245320,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591245320),
//--TRIMMABLE-BOUNDARY-START(4296278024),
    {
      "r": 65537,
      "p": [
        {
          "n": "decoder",
          "p": 165412865
        },
        {
          "n": "bytes",
          "p": $.$sm.SB.ReadOnlySequence$$($.$$.S.Byte).$h,
          "f": 8
        },
        {
          "n": "writer",
          "p": $.$sm.SB.IBufferWriter$$($.$$.S.Char).$h
        },
        {
          "n": "flush",
          "p": 262145
        },
        {
          "n": "charsUsed",
          "p": 917505,
          "f": 2
        },
        {
          "n": "completed",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "Convert",
      "d": 1310728,
      "h": 4296278024,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296278024)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55835885576),
    {
      "t": 655361,
      "n": "MaxInputElementsPerIteration",
      "d": 1310728,
      "h": 55835885576,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55835885576)
  ],
  "h": 1310728
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Text.EncodingExtensions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Text${separator}EncodingExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310728)
        
        

        //--TRIMMABLE-BOUNDARY-START(458760)
        $asm.$cls(`$sm.SB.ReadOnlySequence`, ($self) => class ReadOnlySequence
        {
            //--TRIMMABLE-BOUNDARY-START(12885360648)
            /*int*/ static FlagBitMask = -2147483648;
            //--TRIMMABLE-BOUNDARY-END(12885360648)
            
            //--TRIMMABLE-BOUNDARY-START(17180327944)
            /*int*/ static IndexBitMask = 2147483647;
            //--TRIMMABLE-BOUNDARY-END(17180327944)
            
            //--TRIMMABLE-BOUNDARY-START(4295426056)
            /*int*/ static ArrayEndMask = -2147483648;
            //--TRIMMABLE-BOUNDARY-END(4295426056)
            
            //--TRIMMABLE-BOUNDARY-START(21475295240)
            /*int*/ static MemoryManagerStartMask = -2147483648;
            //--TRIMMABLE-BOUNDARY-END(21475295240)
            
            //--TRIMMABLE-BOUNDARY-START(34360197128)
            /*int*/ static StringStartMask = -2147483648;
            //--TRIMMABLE-BOUNDARY-END(34360197128)
            
            //--TRIMMABLE-BOUNDARY-START(30065229832)
            /*int*/ static StringEndMask = -2147483648;
            //--TRIMMABLE-BOUNDARY-END(30065229832)
            
            //--TRIMMABLE-BOUNDARY-START(8590393352)
            static /*int */ ArrayToSequenceEnd(/*int*/ endIndex)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590393352);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return endIndex | -2147483648/*ArrayEndMask*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590393352)
            
            //--TRIMMABLE-BOUNDARY-START(25770262536)
            static /*int */ MemoryManagerToSequenceStart(/*int*/ startIndex)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770262536);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return startIndex | -2147483648/*MemoryManagerStartMask*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770262536)
            
            //--TRIMMABLE-BOUNDARY-START(42950131720)
            static /*int */ StringToSequenceStart(/*int*/ startIndex)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950131720);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return startIndex | -2147483648/*StringStartMask*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950131720)
            
            //--TRIMMABLE-BOUNDARY-START(38655164424)
            static /*int */ StringToSequenceEnd(/*int*/ endIndex)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655164424);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return endIndex | -2147483648/*StringEndMask*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655164424)
            
            static $h = 458760;
            static $f = 0b10000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590393352),
    {
      "r": 655361,
      "p": [
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": "ArrayToSequenceEnd",
      "d": 458760,
      "h": 8590393352,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590393352),
//--TRIMMABLE-BOUNDARY-START(25770262536),
    {
      "r": 655361,
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        }
      ],
      "n": "MemoryManagerToSequenceStart",
      "d": 458760,
      "h": 25770262536,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770262536),
//--TRIMMABLE-BOUNDARY-START(42950131720),
    {
      "r": 655361,
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        }
      ],
      "n": "StringToSequenceStart",
      "d": 458760,
      "h": 42950131720,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950131720),
//--TRIMMABLE-BOUNDARY-START(38655164424),
    {
      "r": 655361,
      "p": [
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": "StringToSequenceEnd",
      "d": 458760,
      "h": 38655164424,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655164424)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885360648),
    {
      "t": 655361,
      "n": "FlagBitMask",
      "d": 458760,
      "h": 12885360648,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885360648),
//--TRIMMABLE-BOUNDARY-START(17180327944),
    {
      "t": 655361,
      "n": "IndexBitMask",
      "d": 458760,
      "h": 17180327944,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180327944),
//--TRIMMABLE-BOUNDARY-START(4295426056),
    {
      "t": 655361,
      "n": "ArrayEndMask",
      "d": 458760,
      "h": 4295426056,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295426056),
//--TRIMMABLE-BOUNDARY-START(21475295240),
    {
      "t": 655361,
      "n": "MemoryManagerStartMask",
      "d": 458760,
      "h": 21475295240,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475295240),
//--TRIMMABLE-BOUNDARY-START(34360197128),
    {
      "t": 655361,
      "n": "StringStartMask",
      "d": 458760,
      "h": 34360197128,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360197128),
//--TRIMMABLE-BOUNDARY-START(30065229832),
    {
      "t": 655361,
      "n": "StringEndMask",
      "d": 458760,
      "h": 30065229832,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065229832)
  ],
  "h": 458760
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Buffers.ReadOnlySequence`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Buffers${separator}ReadOnlySequence`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458760)
        
        

        //--TRIMMABLE-BOUNDARY-START(65544)
        $asm.$cls(`$sm.SB.ArrayBufferWriter<>`, (T) => $asm.$gt(`$sm.SB.ArrayBufferWriter<>`, [T], ($self) => class ArrayBufferWriter$$ extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25769869320)
            /*int*/ static ArrayMaxLength = 2147483591;
            //--TRIMMABLE-BOUNDARY-END(25769869320)
            
            //--TRIMMABLE-BOUNDARY-START(42949738504)
            /*int*/ static DefaultInitialBufferSize = 256;
            //--TRIMMABLE-BOUNDARY-END(42949738504)
            
            //--TRIMMABLE-BOUNDARY-START(4295032840)
            /*T[]*/ _buffer = null;
            //--TRIMMABLE-BOUNDARY-END(4295032840)
            
            //--TRIMMABLE-BOUNDARY-START(8590000136)
            /*int*/ _index = 0;
            //--TRIMMABLE-BOUNDARY-END(8590000136)
            
            //--TRIMMABLE-BOUNDARY-START(12884967432)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967432);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._buffer = $.$$.S.Array.Empty(T);
                    this._index = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967432)
            
            //--TRIMMABLE-BOUNDARY-START(17179934728)
            $ctor$2(/*int*/ initialCapacity)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17179934728);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (initialCapacity <= 0)
                    {
                        throw new $.$$.S.ArgumentException().$ctor$13(null, "initialCapacity");
                    }
                    this._buffer = $.$$.SRC.RuntimeHelpers.CreateArray($.$typeOf(T), null, [initialCapacity], null);
                    this._index = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17179934728)
            
            //--TRIMMABLE-BOUNDARY-START(120259149832)
            /*ReadOnlyMemory<T> */ get WrittenMemory()
            {
                return $.$$.S.Memory$$(T).op_Implicit($.$$.S.MemoryExtensions.AsMemory$9(T, this._buffer, 0, this._index));
            }
            //--TRIMMABLE-BOUNDARY-END(120259149832)
            
            //--TRIMMABLE-BOUNDARY-START(124554117128)
            /*ReadOnlySpan<T> */ get WrittenSpan()
            {
                return $.$$.S.Span$$(T).op_Implicit($.$$.S.MemoryExtensions.AsSpan$11(T, this._buffer, 0, this._index));
            }
            //--TRIMMABLE-BOUNDARY-END(124554117128)
            
            //--TRIMMABLE-BOUNDARY-START(115964182536)
            /*int */ get WrittenCount()
            {
                return this._index;
            }
            //--TRIMMABLE-BOUNDARY-END(115964182536)
            
            //--TRIMMABLE-BOUNDARY-START(30064836616)
            /*int */ get Capacity()
            {
                return this._buffer.length;
            }
            //--TRIMMABLE-BOUNDARY-END(30064836616)
            
            //--TRIMMABLE-BOUNDARY-START(47244705800)
            /*int */ get FreeCapacity()
            {
                return ((this._buffer.length - this._index) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(47244705800)
            
            //--TRIMMABLE-BOUNDARY-START(38654771208)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(this._buffer.length >= this._index, "_buffer.Length >= _index");
                $.$$.S.MemoryExtensions.AsSpan$11(T, this._buffer, 0, this._index).Clear();
                this._index = 0;
            }
            //--TRIMMABLE-BOUNDARY-END(38654771208)
            
            //--TRIMMABLE-BOUNDARY-START(103079280648)
            /*void */ ResetWrittenCount()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079280648);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._index = 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079280648)
            
            //--TRIMMABLE-BOUNDARY-START(21474902024)
            /*void */ Advance(/*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (count < 0)
                {
                    throw new $.$$.S.ArgumentException().$ctor$13(null, "count");
                }
                if (this._index > ((this._buffer.length - count) | 0))
                {
                    $.$sm.SB.ArrayBufferWriter$$(T).ThrowInvalidOperationException_AdvancedTooFar(this._buffer.length);
                }
                this._index += count;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902024)
            
            //--TRIMMABLE-BOUNDARY-START(94489346056)
            /*Memory<T> */ GetMemory(/*int*/ sizeHint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489346056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckAndResizeBuffer(sizeHint);
                $.$$.SD.Debug.Assert$4(this._buffer.length > this._index, "_buffer.Length > _index");
                return $.$$.S.MemoryExtensions.AsMemory$10(T, this._buffer, this._index);
            }
            //--TRIMMABLE-BOUNDARY-END(94489346056)
            
            //--TRIMMABLE-BOUNDARY-START(98784313352)
            /*Span<T> */ GetSpan(/*int*/ sizeHint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784313352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckAndResizeBuffer(sizeHint);
                $.$$.SD.Debug.Assert$4(this._buffer.length > this._index, "_buffer.Length > _index");
                return $.$$.S.MemoryExtensions.AsSpan$12(T, this._buffer, this._index);
            }
            //--TRIMMABLE-BOUNDARY-END(98784313352)
            
            //--TRIMMABLE-BOUNDARY-START(34359803912)
            /*void */ CheckAndResizeBuffer(/*int*/ sizeHint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (sizeHint < 0)
                {
                    throw new $.$$.S.ArgumentException().$ctor$14("sizeHint");
                }
                if (sizeHint === 0)
                {
                    sizeHint = 1;
                }
                if (sizeHint > this.FreeCapacity)
                {
                    /*int*/ let currentLength = this._buffer.length;
                    /*int*/ let growBy = $.$$.S.Math.Max$4(sizeHint, currentLength);
                    if (currentLength === 0)
                    {
                        growBy = $.$$.S.Math.Max$4(growBy, 256/*DefaultInitialBufferSize*/);
                    }
                    /*int*/ let newSize = ((currentLength + growBy) | 0);
                    if ((newSize >>> 0) > 2147483647/*int.MaxValue*/)
                    {
                        /*uint*/ let needed = ((((((currentLength - this.FreeCapacity) | 0) + sizeHint) | 0)) >>> 0);
                        $.$$.SD.Debug.Assert$4(BigInt(needed) > BigInt(currentLength), "needed > currentLength");
                        if (needed > 2147483591/*ArrayMaxLength*/)
                        {
                            $.$sm.SB.ArrayBufferWriter$$(T).ThrowOutOfMemoryException(needed);
                        }
                        newSize = 2147483591/*ArrayMaxLength*/;
                    }
                    $.$$.S.Array.Resize(T, $.$ref(() => this._buffer, ($v) => this._buffer = $v, $.$typeArray(T)), newSize);
                }
                $.$$.SD.Debug.Assert$4(this.FreeCapacity > 0 && this.FreeCapacity >= sizeHint, "FreeCapacity > 0 && FreeCapacity >= sizeHint");
            }
            //--TRIMMABLE-BOUNDARY-END(34359803912)
            
            //--TRIMMABLE-BOUNDARY-START(107374247944)
            static /*void */ ThrowInvalidOperationException_AdvancedTooFar(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374247944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.InvalidOperationException().$ctor$12($.$sm.S.SR.Format$6($.$sm.S.SR.BufferWriterAdvancedTooFar, $.$box(capacity, $.$$.S.Int32)));
            }
            //--TRIMMABLE-BOUNDARY-END(107374247944)
            
            //--TRIMMABLE-BOUNDARY-START(111669215240)
            static /*void */ ThrowOutOfMemoryException(/*uint*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669215240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.OutOfMemoryException().$ctor$12($.$sm.S.SR.Format$6($.$sm.S.SR.BufferMaximumSizeExceeded, $.$box(capacity, $.$$.S.UInt32)));
            }
            //--TRIMMABLE-BOUNDARY-END(111669215240)
            
            //--TRIMMABLE-BOUNDARY-START(4295294984)
            //Generated interface implemetation for System.Buffers.IBufferWriter<T>.Advance(int)
            SB$IBufferWriter$$$Advance()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295294984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Advance(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295294984)
            
            //--TRIMMABLE-BOUNDARY-START(8590262280)
            //Generated interface implemetation for System.Buffers.IBufferWriter<T>.GetMemory(int)
            SB$IBufferWriter$$$GetMemory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590262280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetMemory(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590262280)
            
            //--TRIMMABLE-BOUNDARY-START(12885229576)
            //Generated interface implemetation for System.Buffers.IBufferWriter<T>.GetSpan(int)
            SB$IBufferWriter$$$GetSpan()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetSpan(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885229576)
            
            //--TRIMMABLE-BOUNDARY-START(12884967432)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(12884967432)
            
            static $H = 65544;
            static $h = 65544;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(120259149832),
    {
      "p": $.$$.S.ReadOnlyMemory$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81604444168,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "n": "WrittenMemory",
      "d": this.$h,
      "H": 120259149832,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259149832),
//--TRIMMABLE-BOUNDARY-START(124554117128),
    {
      "p": $.$$.S.ReadOnlySpan$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90194378760,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "n": "WrittenSpan",
      "d": this.$h,
      "H": 124554117128,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124554117128),
//--TRIMMABLE-BOUNDARY-START(115964182536),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 73014509576,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "n": "WrittenCount",
      "d": this.$h,
      "H": 115964182536,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964182536),
//--TRIMMABLE-BOUNDARY-START(30064836616),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 55834640392,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "n": "Capacity",
      "d": this.$h,
      "H": 30064836616,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30064836616),
//--TRIMMABLE-BOUNDARY-START(47244705800),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 64424574984,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "FreeCapacity",
      "d": this.$h,
      "H": 47244705800,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244705800)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38654771208),
    {
      "r": 65537,
      "n": "Clear",
      "d": this.$h,
      "H": 38654771208,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654771208),
//--TRIMMABLE-BOUNDARY-START(103079280648),
    {
      "r": 65537,
      "n": "ResetWrittenCount",
      "d": this.$h,
      "H": 103079280648,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079280648),
//--TRIMMABLE-BOUNDARY-START(21474902024),
    {
      "r": 65537,
      "p": [
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Advance",
      "d": this.$h,
      "H": 21474902024,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21474902024),
//--TRIMMABLE-BOUNDARY-START(94489346056),
    {
      "r": $.$$.S.Memory$$(T).$h,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "GetMemory",
      "d": this.$h,
      "H": 94489346056,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489346056),
//--TRIMMABLE-BOUNDARY-START(98784313352),
    {
      "r": $.$$.S.Span$$(T).$h,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "GetSpan",
      "d": this.$h,
      "H": 98784313352,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784313352),
//--TRIMMABLE-BOUNDARY-START(34359803912),
    {
      "r": 65537,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361
        }
      ],
      "n": "CheckAndResizeBuffer",
      "d": this.$h,
      "H": 34359803912,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34359803912),
//--TRIMMABLE-BOUNDARY-START(107374247944),
    {
      "r": 65537,
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": "ThrowInvalidOperationException_AdvancedTooFar",
      "d": this.$h,
      "H": 107374247944,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107374247944),
//--TRIMMABLE-BOUNDARY-START(111669215240),
    {
      "r": 65537,
      "p": [
        {
          "n": "capacity",
          "p": 720897
        }
      ],
      "n": "ThrowOutOfMemoryException",
      "d": this.$h,
      "H": 111669215240,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(111669215240)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25769869320),
    {
      "t": 655361,
      "n": "ArrayMaxLength",
      "d": this.$h,
      "H": 25769869320,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25769869320),
//--TRIMMABLE-BOUNDARY-START(42949738504),
    {
      "t": 655361,
      "n": "DefaultInitialBufferSize",
      "d": this.$h,
      "H": 42949738504,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42949738504),
//--TRIMMABLE-BOUNDARY-START(4295032840),
    {
      "t": $.$typeArray(T).$h,
      "n": "_buffer",
      "d": this.$h,
      "H": 4295032840,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032840),
//--TRIMMABLE-BOUNDARY-START(8590000136),
    {
      "t": 655361,
      "n": "_index",
      "d": this.$h,
      "H": 8590000136,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590000136)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967432),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "H": 12884967432,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12884967432),
//--TRIMMABLE-BOUNDARY-START(17179934728),
    {
      "p": [
        {
          "n": "initialCapacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 17179934728,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179934728)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 65544,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sm.SB.IBufferWriter$$(T) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Buffers.ArrayBufferWriter<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Buffers${separator}ArrayBufferWriter$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(65544)
        
        

        //--TRIMMABLE-BOUNDARY-START(917512)
        $asm.$str(`$sm.SB.SequenceReader<>`, (T) => $asm.$gt(`$sm.SB.SequenceReader<>`, [T], ($self) => class SequenceReader$$ extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295884808)
            /*SequencePosition*/ _currentPosition;
            //--TRIMMABLE-BOUNDARY-END(4295884808)
            
            //--TRIMMABLE-BOUNDARY-START(17180786696)
            /*SequencePosition*/ _nextPosition;
            //--TRIMMABLE-BOUNDARY-END(17180786696)
            
            //--TRIMMABLE-BOUNDARY-START(12885819400)
            /*bool*/ _moreData = false;
            //--TRIMMABLE-BOUNDARY-END(12885819400)
            
            //--TRIMMABLE-BOUNDARY-START(8590852104)
            /*long*/ _length = 0n;
            //--TRIMMABLE-BOUNDARY-END(8590852104)
            
            //--TRIMMABLE-BOUNDARY-START(42950590472)
            $ctor$3(/*ReadOnlySequence<T>*/ sequence)
            {
                super.$ctor$1();
                {
                    /*ReadOnlySpan<T>*/ let first;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950590472);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.CurrentSpanIndex = 0;
                    this.Consumed = 0n;
                    this.Sequence = sequence;
                    this._currentPosition = sequence.Start;
                    this._length = BigInt(-1);
                    sequence.GetFirstSpan$1($.$ref(() => first, ($v) => first = $v, $.$$.S.ReadOnlySpan$$(T)), $.$ref(() => this._nextPosition, ($v) => this._nextPosition = $v, $.$sm.S.SequencePosition));
                    this.CurrentSpan = first;
                    this._moreData = first.Length > 0;
                    if (!this._moreData && !sequence.IsSingleSegment)
                    {
                        this._moreData = true;
                        this.GetNextSpan();
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950590472)
            
            //--TRIMMABLE-BOUNDARY-START(103080132616)
            /*bool */ get End()
            {
                return !this._moreData;
            }
            //--TRIMMABLE-BOUNDARY-END(103080132616)
            
            //--TRIMMABLE-BOUNDARY-START(236224118792)
            /*ReadOnlySequence<T>*/ Sequence;
            //--TRIMMABLE-BOUNDARY-END(236224118792)
            
            //--TRIMMABLE-BOUNDARY-START(365073137672)
            /*ReadOnlySequence<T> */ get UnreadSequence()
            {
                return this.Sequence.Slice$8(this.Position);
            }
            //--TRIMMABLE-BOUNDARY-END(365073137672)
            
            //--TRIMMABLE-BOUNDARY-START(214749282312)
            /*SequencePosition */ get Position()
            {
                return this.Sequence.GetPosition(BigInt(this.CurrentSpanIndex), this._currentPosition);
            }
            //--TRIMMABLE-BOUNDARY-END(214749282312)
            
            //--TRIMMABLE-BOUNDARY-START(94490198024)
            /*ReadOnlySpan<T>*/ CurrentSpan;
            //--TRIMMABLE-BOUNDARY-END(94490198024)
            
            //--TRIMMABLE-BOUNDARY-START(98785165320)
            /*int*/ CurrentSpanIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(98785165320)
            
            //--TRIMMABLE-BOUNDARY-START(369368104968)
            /*ReadOnlySpan<T> */ get UnreadSpan()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979478536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CurrentSpan.Slice$1(this.CurrentSpanIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(369368104968)
            
            //--TRIMMABLE-BOUNDARY-START(90195230728)
            /*long*/ Consumed = 0n;
            //--TRIMMABLE-BOUNDARY-END(90195230728)
            
            //--TRIMMABLE-BOUNDARY-START(219044249608)
            /*long */ get Remaining()
            {
                return BigInt.asIntN(64, this.Length - this.Consumed);
            }
            //--TRIMMABLE-BOUNDARY-END(219044249608)
            
            //--TRIMMABLE-BOUNDARY-START(210454315016)
            /*long */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029805576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._length < 0n)
                {
                    $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$$.S.Int64, () => this, ($v) => $v.$clone(this), 17, true).$v = this.Sequence.Length;
                }
                return this._length;
            }
            //--TRIMMABLE-BOUNDARY-END(210454315016)
            
            //--TRIMMABLE-BOUNDARY-START(283468759048)
            /*bool */ TryPeek(/*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468759048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._moreData)
                {
                    value.$v = this.CurrentSpan._reference.GetAt(this.CurrentSpanIndex);
                    return true;
                }
                else 
                {
                    value.$v = $.$default(T);
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(283468759048)
            
            //--TRIMMABLE-BOUNDARY-START(287763726344)
            /*bool */ TryPeek$1(/*long*/ offset, /*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763726344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (offset < 0n)
                {
                    $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_OffsetOutOfRange();
                }
                if (!this._moreData || this.Remaining <= offset)
                {
                    value.$v = $.$default(T);
                    return false;
                }
                $.$$.SD.Debug.Assert$4(BigInt.asIntN(64, BigInt(this.CurrentSpanIndex) + offset) >= 0n, "CurrentSpanIndex + offset >= 0");
                if ((BigInt.asIntN(64, BigInt(this.CurrentSpanIndex) + offset)) <= BigInt(this.CurrentSpan.Length - 1))
                {
                    $.$$.SD.Debug.Assert$4(offset <= BigInt(2147483647/*int.MaxValue*/), "offset <= int.MaxValue");
                    value.$v = this.CurrentSpan._reference.GetAt(((this.CurrentSpanIndex + $.$cast(offset, $.$$.S.Int32)) | 0));
                    return true;
                }
                else 
                {
                    /*long*/ let remainingOffset = BigInt.asIntN(64, offset - BigInt(this.CurrentSpan.Length - this.CurrentSpanIndex));
                    /*SequencePosition*/ let nextPosition = this._nextPosition;
                    /*ReadOnlyMemory<T>*/ let currentMemory;
                    while(this.Sequence.TryGet($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sm.S.SequencePosition, () => nextPosition, ($v) => nextPosition = $v, null, true), $.$ref(() => currentMemory, ($v) => currentMemory = $v, $.$$.S.ReadOnlyMemory$$(T)), true))
                    {
                        if (currentMemory.Length > 0)
                        {
                            if (remainingOffset >= BigInt(currentMemory.Length))
                            {
                                remainingOffset -= BigInt(currentMemory.Length);
                            }
                            else 
                            {
                                break;
                            }
                        }
                    }
                    value.$v = currentMemory.Span._reference.GetAt($.$cast(remainingOffset, $.$$.S.Int32));
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(287763726344)
            
            //--TRIMMABLE-BOUNDARY-START(292058693640)
            /*bool */ TryRead(/*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058693640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.End)
                {
                    value.$v = $.$default(T);
                    return false;
                }
                value.$v = this.CurrentSpan._reference.GetAt(this.CurrentSpanIndex);
                this.CurrentSpanIndex++;
                this.Consumed++;
                if (this.CurrentSpanIndex >= this.CurrentSpan.Length)
                {
                    this.GetNextSpan();
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(292058693640)
            
            //--TRIMMABLE-BOUNDARY-START(231929151496)
            /*void */ Rewind(/*long*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929151496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$cast(count, $.$$.S.UInt64) > $.$cast(this.Consumed, $.$$.S.UInt64))
                {
                    $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException(15/*ExceptionArgument.count*/);
                }
                if (count === 0n)
                {
                    return;
                }
                this.Consumed -= count;
                if (BigInt(this.CurrentSpanIndex) >= count)
                {
                    this.CurrentSpanIndex -= $.$cast(count, $.$$.S.Int32);
                    this._moreData = true;
                }
                else 
                {
                    this.RetreatToPreviousSpan(this.Consumed);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231929151496)
            
            //--TRIMMABLE-BOUNDARY-START(227634184200)
            /*void */ RetreatToPreviousSpan(/*long*/ consumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634184200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ResetReader();
                this.Advance(consumed);
            }
            //--TRIMMABLE-BOUNDARY-END(227634184200)
            
            //--TRIMMABLE-BOUNDARY-START(223339216904)
            /*void */ ResetReader()
            {
                /*ReadOnlyMemory<T>*/ let memory;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339216904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CurrentSpanIndex = 0;
                this.Consumed = 0n;
                this._currentPosition = this.Sequence.Start;
                this._nextPosition = this._currentPosition;
                if (this.Sequence.TryGet($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sm.S.SequencePosition, () => this._nextPosition, ($v) => this._nextPosition = $v, null, true), $.$ref(() => memory, ($v) => memory = $v, $.$$.S.ReadOnlyMemory$$(T)), true))
                {
                    this._moreData = true;
                    if (memory.Length === 0)
                    {
                        this.CurrentSpan = new ($.$$.S.ReadOnlySpan$$(T))();
                        this.GetNextSpan();
                    }
                    else 
                    {
                        this.CurrentSpan = memory.Span;
                    }
                }
                else 
                {
                    this._moreData = false;
                    this.CurrentSpan = new ($.$$.S.ReadOnlySpan$$(T))();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223339216904)
            
            //--TRIMMABLE-BOUNDARY-START(193274445832)
            /*void */ GetNextSpan()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274445832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.Sequence.IsSingleSegment)
                {
                    /*ReadOnlyMemory<T>*/ let memory;
                    /*SequencePosition*/ let previousNextPosition = this._nextPosition;
                    while(this.Sequence.TryGet($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sm.S.SequencePosition, () => this._nextPosition, ($v) => this._nextPosition = $v, null, true), $.$ref(() => memory, ($v) => memory = $v, $.$$.S.ReadOnlyMemory$$(T)), true))
                    {
                        this._currentPosition = previousNextPosition;
                        if (memory.Length > 0)
                        {
                            this.CurrentSpan = memory.Span;
                            this.CurrentSpanIndex = 0;
                            return;
                        }
                        else 
                        {
                            this.CurrentSpan = new ($.$$.S.ReadOnlySpan$$(T))();
                            this.CurrentSpanIndex = 0;
                            previousNextPosition = this._nextPosition;
                        }
                    }
                }
                this._moreData = false;
            }
            //--TRIMMABLE-BOUNDARY-END(193274445832)
            
            //--TRIMMABLE-BOUNDARY-START(47245557768)
            /*void */ Advance(/*long*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245557768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let TooBigOrNegative = $.$cast(18446744071562067968n, $.$$.S.Int64);
                if ((count & TooBigOrNegative) === 0n && ((this.CurrentSpan.Length - this.CurrentSpanIndex) | 0) > $.$cast(count, $.$$.S.Int32))
                {
                    this.CurrentSpanIndex += $.$cast(count, $.$$.S.Int32);
                    this.Consumed += count;
                }
                else 
                {
                    this.AdvanceToNextSpan(count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245557768)
            
            //--TRIMMABLE-BOUNDARY-START(51540525064)
            /*void */ AdvanceCurrentSpan(/*long*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540525064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(count >= 0n, "count >= 0");
                this.Consumed += count;
                this.CurrentSpanIndex += $.$cast(count, $.$$.S.Int32);
                if (this.CurrentSpanIndex >= this.CurrentSpan.Length)
                {
                    this.GetNextSpan();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540525064)
            
            //--TRIMMABLE-BOUNDARY-START(85900263432)
            /*void */ AdvanceWithinSpan(/*long*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900263432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(count >= 0n, "count >= 0");
                this.Consumed += count;
                this.CurrentSpanIndex += $.$cast(count, $.$$.S.Int32);
                $.$$.SD.Debug.Assert$4(this.CurrentSpanIndex < this.CurrentSpan.Length, "CurrentSpanIndex < CurrentSpan.Length");
            }
            //--TRIMMABLE-BOUNDARY-END(85900263432)
            
            //--TRIMMABLE-BOUNDARY-START(81605296136)
            /*void */ AdvanceToNextSpan(/*long*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605296136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (count < 0n)
                {
                    $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException(15/*ExceptionArgument.count*/);
                }
                this.Consumed += count;
                while(this._moreData)
                {
                    /*int*/ let remaining = ((this.CurrentSpan.Length - this.CurrentSpanIndex) | 0);
                    if (BigInt(remaining) > count)
                    {
                        this.CurrentSpanIndex += $.$cast(count, $.$$.S.Int32);
                        count = 0n;
                        break;
                    }
                    this.CurrentSpanIndex += remaining;
                    count -= BigInt(remaining);
                    $.$$.SD.Debug.Assert$4(count >= 0n, "count >= 0");
                    this.GetNextSpan();
                    if (count === 0n)
                    {
                        break;
                    }
                }
                if (count !== 0n)
                {
                    this.Consumed -= count;
                    $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException(15/*ExceptionArgument.count*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605296136)
            
            //--TRIMMABLE-BOUNDARY-START(279173791752)
            /*bool */ TryCopyTo(/*Span<T>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173791752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let firstSpan = this.UnreadSpan;
                if (firstSpan.Length >= destination.Length)
                {
                    firstSpan.Slice(0, destination.Length).CopyTo(destination);
                    return true;
                }
                return this.TryCopyMultisegment(destination);
            }
            //--TRIMMABLE-BOUNDARY-END(279173791752)
            
            //--TRIMMABLE-BOUNDARY-START(274878824456)
            /*bool */ TryCopyMultisegment(/*Span<T>*/ destination)
            {
                /*ReadOnlyMemory<T>*/ let nextSegment;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878824456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Remaining < BigInt(destination.Length))
                {
                    return false;
                }
                /*ReadOnlySpan<T>*/ let firstSpan = this.UnreadSpan;
                $.$$.SD.Debug.Assert$4(firstSpan.Length < destination.Length, "firstSpan.Length < destination.Length");
                firstSpan.CopyTo(destination);
                /*int*/ let copied = firstSpan.Length;
                /*SequencePosition*/ let next = this._nextPosition;
                while(this.Sequence.TryGet($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sm.S.SequencePosition, () => next, ($v) => next = $v, null, true), $.$ref(() => nextSegment, ($v) => nextSegment = $v, $.$$.S.ReadOnlyMemory$$(T)), true))
                {
                    if (nextSegment.Length > 0)
                    {
                        /*ReadOnlySpan<T>*/ let nextSpan = nextSegment.Span;
                        /*int*/ let toCopy = $.$$.S.Math.Min$4(nextSpan.Length, ((destination.Length - copied) | 0));
                        nextSpan.Slice(0, toCopy).CopyTo(destination.Slice$1(copied));
                        copied += toCopy;
                        if (copied >= destination.Length)
                        {
                            break;
                        }
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(274878824456)
            
            //--TRIMMABLE-BOUNDARY-START(317828497416)
            /*bool */ TryReadTo$4(/*out ReadOnlySpan<T>*/ span, /*T*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828497416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = $.$$.S.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                if (index !== -1)
                {
                    span.$v = index === 0 ? new ($.$$.S.ReadOnlySpan$$(T))() : remaining.Slice(0, index);
                    this.AdvanceCurrentSpan(BigInt(index + (advancePastDelimiter ? 1 : 0)));
                    return true;
                }
                return this.TryReadToSlow$2(span, delimiter, advancePastDelimiter);
            }
            //--TRIMMABLE-BOUNDARY-END(317828497416)
            
            //--TRIMMABLE-BOUNDARY-START(356483203080)
            /*bool */ TryReadToSlow$2(/*out ReadOnlySpan<T>*/ span, /*T*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                /*ReadOnlySequence<T>*/ let sequence;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483203080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.TryReadToInternal($.$ref(() => sequence, ($v) => sequence = $v, $.$sm.SB.ReadOnlySequence$$(T)), delimiter, advancePastDelimiter, ((this.CurrentSpan.Length - this.CurrentSpanIndex) | 0)))
                {
                    span.$v = new ($.$$.S.ReadOnlySpan$$(T))();
                    return false;
                }
                span.$v = sequence.IsSingleSegment ? sequence.First.Span : $.$$.S.ReadOnlySpan$$(T).op_Implicit$1($.$sm.SB.BuffersExtensions.ToArray(T, $.$ref(() => sequence, )));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(356483203080)
            
            //--TRIMMABLE-BOUNDARY-START(322123464712)
            /*bool */ TryReadTo$5(/*out ReadOnlySpan<T>*/ span, /*T*/ delimiter, /*T*/ delimiterEscape, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123464712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = $.$$.S.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                if ((index > 0 && !$.$dsp(remaining._reference.GetAt(((index - 1) | 0)), T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], delimiterEscape)) || index === 0)
                {
                    span.$v = remaining.Slice(0, index);
                    this.AdvanceCurrentSpan(BigInt(index + (advancePastDelimiter ? 1 : 0)));
                    return true;
                }
                return this.TryReadToSlow$3(span, delimiter, delimiterEscape, index, advancePastDelimiter);
            }
            //--TRIMMABLE-BOUNDARY-END(322123464712)
            
            //--TRIMMABLE-BOUNDARY-START(360778170376)
            /*bool */ TryReadToSlow$3(/*out ReadOnlySpan<T>*/ span, /*T*/ delimiter, /*T*/ delimiterEscape, /*int*/ index, /*bool*/ advancePastDelimiter)
            {
                /*ReadOnlySequence<T>*/ let sequence;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360778170376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.TryReadToSlow($.$ref(() => sequence, ($v) => sequence = $v, $.$sm.SB.ReadOnlySequence$$(T)), delimiter, delimiterEscape, index, advancePastDelimiter))
                {
                    span.$v = new ($.$$.S.ReadOnlySpan$$(T))();
                    return false;
                }
                $.$$.SD.Debug.Assert$4(sequence.Length > 0n, "sequence.Length > 0");
                span.$v = sequence.IsSingleSegment ? sequence.First.Span : $.$$.S.ReadOnlySpan$$(T).op_Implicit$1($.$sm.SB.BuffersExtensions.ToArray(T, $.$ref(() => sequence, )));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(360778170376)
            
            //--TRIMMABLE-BOUNDARY-START(347893268488)
            /*bool */ TryReadToSlow(/*out ReadOnlySequence<T>*/ sequence, /*T*/ delimiter, /*T*/ delimiterEscape, /*int*/ index, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347893268488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SequenceReader<T>*/ let copy = $.$clone(this);
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*bool*/ let priorEscape = false;
                $doJumpStart15: do
                {
                    let $gotoJumpState16 = 0;
                    $gotoJumpStart16: while(true)
                    {
                        switch($gotoJumpState16)
                        {
                            case 0:
                            {
                                if (index >= 0)
                                {
                                    if (index === 0 && priorEscape)
                                    {
                                        priorEscape = false;
                                        this.Advance(BigInt(index + 1));
                                        remaining = this.UnreadSpan;
                                        $gotoJumpState16 = 1; /*goto Continue*/
                                        continue $gotoJumpStart16;
                                    }
                                    else if (index > 0 && $.$dsp(remaining._reference.GetAt(((index - 1) | 0)), T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], delimiterEscape))
                                    {
                                        /*int*/ var escapeCount = 1;
                                        /*int*/ var i = ((index - 2) | 0);
                                        for(; i >= 0; i--)
                                        {
                                            if (!$.$dsp(remaining._reference.GetAt(i), T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], delimiterEscape))
                                            {
                                                break;
                                            }
                                        }
                                        if (i < 0 && priorEscape)
                                        {
                                            escapeCount++;
                                        }
                                        escapeCount += ((((index - 2) | 0) - i) | 0);
                                        if ((escapeCount & 1) !== 0)
                                        {
                                            this.Advance(BigInt(index + 1));
                                            priorEscape = false;
                                            remaining = this.UnreadSpan;
                                            $gotoJumpState16 = 1; /*goto Continue*/
                                            continue $gotoJumpStart16;
                                        }
                                    }
                                    this.AdvanceCurrentSpan(BigInt(index));
                                    sequence.$v = this.Sequence.Slice$7(copy.Position, this.Position);
                                    if (advancePastDelimiter)
                                    {
                                        this.Advance(1n);
                                    }
                                    return true;
                                }
                                else 
                                {
                                    if ($.$$.S.MemoryExtensions.EndsWith$4(T, remaining, delimiterEscape))
                                    {
                                        /*int*/ var escapeCount = 1;
                                        /*int*/ var i = ((remaining.Length - 2) | 0);
                                        for(; i >= 0; i--)
                                        {
                                            if (!$.$dsp(remaining._reference.GetAt(i), T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], delimiterEscape))
                                            {
                                                break;
                                            }
                                        }
                                        escapeCount += ((((remaining.Length - 2) | 0) - i) | 0);
                                        if (i < 0 && priorEscape)
                                        {
                                            priorEscape = (escapeCount & 1) === 0;
                                        }
                                        else 
                                        {
                                            priorEscape = (escapeCount & 1) !== 0;
                                        }
                                    }
                                    else 
                                    {
                                        priorEscape = false;
                                    }
                                }
                                this.AdvanceCurrentSpan(BigInt(remaining.Length));
                                remaining = this.CurrentSpan;
                            }
                            case 1: /*Continue*/
                            index = $.$$.S.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                        }
                        break;
                    }
                }
                while(!this.End);
                $.$clone(copy).$clone(this);
                sequence.$v = new ($.$sm.SB.ReadOnlySequence$$(T))();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(347893268488)
            
            //--TRIMMABLE-BOUNDARY-START(304943595528)
            /*bool */ TryReadTo$1(/*out ReadOnlySequence<T>*/ sequence, /*T*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943595528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryReadToInternal(sequence, delimiter, advancePastDelimiter, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(304943595528)
            
            //--TRIMMABLE-BOUNDARY-START(343598301192)
            /*bool */ TryReadToInternal(/*out ReadOnlySequence<T>*/ sequence, /*T*/ delimiter, /*bool*/ advancePastDelimiter, /*int*/ skip)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343598301192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(skip >= 0, "skip >= 0");
                /*SequenceReader<T>*/ let copy = $.$clone(this);
                if (skip > 0)
                {
                    this.Advance(BigInt(skip));
                }
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                while(this._moreData)
                {
                    /*int*/ let index = $.$$.S.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                    if (index !== -1)
                    {
                        if (index > 0)
                        {
                            this.AdvanceCurrentSpan(BigInt(index));
                        }
                        sequence.$v = this.Sequence.Slice$7(copy.Position, this.Position);
                        if (advancePastDelimiter)
                        {
                            this.Advance(1n);
                        }
                        return true;
                    }
                    this.AdvanceCurrentSpan(BigInt(remaining.Length));
                    remaining = this.CurrentSpan;
                }
                $.$clone(copy).$clone(this);
                sequence.$v = new ($.$sm.SB.ReadOnlySequence$$(T))();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(343598301192)
            
            //--TRIMMABLE-BOUNDARY-START(309238562824)
            /*bool */ TryReadTo$2(/*out ReadOnlySequence<T>*/ sequence, /*T*/ delimiter, /*T*/ delimiterEscape, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238562824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SequenceReader<T>*/ let copy = $.$clone(this);
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*bool*/ let priorEscape = false;
                while(this._moreData)
                {
                    /*int*/ let index = $.$$.S.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                    if (index !== -1)
                    {
                        if (index === 0 && priorEscape)
                        {
                            priorEscape = false;
                            this.Advance(BigInt(index + 1));
                            remaining = this.UnreadSpan;
                            continue;
                        }
                        else if (index > 0 && $.$dsp(remaining._reference.GetAt(((index - 1) | 0)), T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], delimiterEscape))
                        {
                            /*int*/ let escapeCount = 0;
                            for(/*int*/ let i = index; i > 0 && $.$dsp(remaining._reference.GetAt(((i - 1) | 0)), T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], delimiterEscape); i--, escapeCount++)
                            {
                            }
                            if (escapeCount === index && priorEscape)
                            {
                                escapeCount++;
                            }
                            priorEscape = false;
                            if ((escapeCount & 1) !== 0)
                            {
                                this.Advance(BigInt(index + 1));
                                remaining = this.UnreadSpan;
                                continue;
                            }
                        }
                        if (index > 0)
                        {
                            this.Advance(BigInt(index));
                        }
                        sequence.$v = this.Sequence.Slice$7(copy.Position, this.Position);
                        if (advancePastDelimiter)
                        {
                            this.Advance(1n);
                        }
                        return true;
                    }
                    {
                        /*int*/ let escapeCount = 0;
                        for(/*int*/ let i = remaining.Length; i > 0 && $.$dsp(remaining._reference.GetAt(((i - 1) | 0)), T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], delimiterEscape); i--, escapeCount++)
                        {
                        }
                        if (priorEscape && escapeCount === remaining.Length)
                        {
                            escapeCount++;
                        }
                        priorEscape = escapeCount % 2 !== 0;
                    }
                    this.Advance(BigInt(remaining.Length));
                    remaining = this.CurrentSpan;
                }
                $.$clone(copy).$clone(this);
                sequence.$v = new ($.$sm.SB.ReadOnlySequence$$(T))();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(309238562824)
            
            //--TRIMMABLE-BOUNDARY-START(330713399304)
            /*bool */ TryReadToAny$1(/*out ReadOnlySpan<T>*/ span, /*scoped ReadOnlySpan<T>*/ delimiters, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713399304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = delimiters.Length === 2 ? $.$$.S.MemoryExtensions.IndexOfAny$8(T, remaining, delimiters._reference.GetAt(0), delimiters._reference.GetAt(1)) : $.$$.S.MemoryExtensions.IndexOfAny$4(T, remaining, delimiters);
                if (index !== -1)
                {
                    span.$v = remaining.Slice(0, index);
                    this.Advance(BigInt(index + (advancePastDelimiter ? 1 : 0)));
                    return true;
                }
                return this.TryReadToAnySlow(span, delimiters, advancePastDelimiter);
            }
            //--TRIMMABLE-BOUNDARY-END(330713399304)
            
            //--TRIMMABLE-BOUNDARY-START(339303333896)
            /*bool */ TryReadToAnySlow(/*out ReadOnlySpan<T>*/ span, /*scoped ReadOnlySpan<T>*/ delimiters, /*bool*/ advancePastDelimiter)
            {
                /*ReadOnlySequence<T>*/ let sequence;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303333896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.TryReadToAnyInternal($.$ref(() => sequence, ($v) => sequence = $v, $.$sm.SB.ReadOnlySequence$$(T)), delimiters, advancePastDelimiter, ((this.CurrentSpan.Length - this.CurrentSpanIndex) | 0)))
                {
                    span.$v = new ($.$$.S.ReadOnlySpan$$(T))();
                    return false;
                }
                span.$v = sequence.IsSingleSegment ? sequence.First.Span : $.$$.S.ReadOnlySpan$$(T).op_Implicit$1($.$sm.SB.BuffersExtensions.ToArray(T, $.$ref(() => sequence, )));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(339303333896)
            
            //--TRIMMABLE-BOUNDARY-START(326418432008)
            /*bool */ TryReadToAny(/*out ReadOnlySequence<T>*/ sequence, /*scoped ReadOnlySpan<T>*/ delimiters, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418432008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryReadToAnyInternal(sequence, delimiters, advancePastDelimiter, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(326418432008)
            
            //--TRIMMABLE-BOUNDARY-START(335008366600)
            /*bool */ TryReadToAnyInternal(/*out ReadOnlySequence<T>*/ sequence, /*scoped ReadOnlySpan<T>*/ delimiters, /*bool*/ advancePastDelimiter, /*int*/ skip)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335008366600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SequenceReader<T>*/ let copy = $.$clone(this);
                if (skip > 0)
                {
                    this.Advance(BigInt(skip));
                }
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                while(!this.End)
                {
                    /*int*/ let index = delimiters.Length === 2 ? $.$$.S.MemoryExtensions.IndexOfAny$8(T, remaining, delimiters._reference.GetAt(0), delimiters._reference.GetAt(1)) : $.$$.S.MemoryExtensions.IndexOfAny$4(T, remaining, delimiters);
                    if (index !== -1)
                    {
                        if (index > 0)
                        {
                            this.AdvanceCurrentSpan(BigInt(index));
                        }
                        sequence.$v = this.Sequence.Slice$7(copy.Position, this.Position);
                        if (advancePastDelimiter)
                        {
                            this.Advance(1n);
                        }
                        return true;
                    }
                    this.Advance(BigInt(remaining.Length));
                    remaining = this.CurrentSpan;
                }
                $.$clone(copy).$clone(this);
                sequence.$v = new ($.$sm.SB.ReadOnlySequence$$(T))();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(335008366600)
            
            //--TRIMMABLE-BOUNDARY-START(313533530120)
            /*bool */ TryReadTo$3(/*out ReadOnlySpan<T>*/ span, /*scoped ReadOnlySpan<T>*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533530120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = $.$$.S.MemoryExtensions.IndexOf$2(T, remaining, delimiter);
                if (index >= 0)
                {
                    span.$v = remaining.Slice(0, index);
                    this.AdvanceCurrentSpan(BigInt(index + (advancePastDelimiter ? delimiter.Length : 0)));
                    return true;
                }
                return this.TryReadToSlow$1(span, delimiter, advancePastDelimiter);
            }
            //--TRIMMABLE-BOUNDARY-END(313533530120)
            
            //--TRIMMABLE-BOUNDARY-START(352188235784)
            /*bool */ TryReadToSlow$1(/*out ReadOnlySpan<T>*/ span, /*scoped ReadOnlySpan<T>*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                /*ReadOnlySequence<T>*/ let sequence;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352188235784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.TryReadTo($.$ref(() => sequence, ($v) => sequence = $v, $.$sm.SB.ReadOnlySequence$$(T)), delimiter, advancePastDelimiter))
                {
                    span.$v = new ($.$$.S.ReadOnlySpan$$(T))();
                    return false;
                }
                $.$$.SD.Debug.Assert$4(sequence.Length > 0n, "sequence.Length > 0");
                span.$v = sequence.IsSingleSegment ? sequence.First.Span : $.$$.S.ReadOnlySpan$$(T).op_Implicit$1($.$sm.SB.BuffersExtensions.ToArray(T, $.$ref(() => sequence, )));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(352188235784)
            
            //--TRIMMABLE-BOUNDARY-START(300648628232)
            /*bool */ TryReadTo(/*out ReadOnlySequence<T>*/ sequence, /*scoped ReadOnlySpan<T>*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648628232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (delimiter.Length === 0)
                {
                    sequence.$v = new ($.$sm.SB.ReadOnlySequence$$(T))();
                    return true;
                }
                /*SequenceReader<T>*/ let copy = $.$clone(this);
                /*bool*/ let advanced = false;
                while(!this.End)
                {
                    if (!this.TryReadTo$1(sequence, delimiter._reference.GetAt(0), false))
                    {
                        $.$clone(copy).$clone(this);
                        return false;
                    }
                    if (delimiter.Length === 1)
                    {
                        if (advancePastDelimiter)
                        {
                            this.Advance(1n);
                        }
                        return true;
                    }
                    if (this.IsNext(delimiter, false))
                    {
                        if (advanced)
                        {
                            sequence.$v = copy.Sequence.Slice$2(copy.Consumed, BigInt.asIntN(64, this.Consumed - copy.Consumed));
                        }
                        if (advancePastDelimiter)
                        {
                            this.Advance(BigInt(delimiter.Length));
                        }
                        return true;
                    }
                    else 
                    {
                        this.Advance(1n);
                        advanced = true;
                    }
                }
                $.$clone(copy).$clone(this);
                sequence.$v = new ($.$sm.SB.ReadOnlySequence$$(T))();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(300648628232)
            
            //--TRIMMABLE-BOUNDARY-START(296353660936)
            /*bool */ TryReadExact(/*int*/ count, /*out ReadOnlySequence<T>*/ sequence)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353660936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (count < 0)
                {
                    $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException(15/*ExceptionArgument.count*/);
                }
                if (BigInt(count) > this.Remaining)
                {
                    sequence.$v = new ($.$sm.SB.ReadOnlySequence$$(T))();
                    return false;
                }
                sequence.$v = this.Sequence.Slice$5(this.Position, count);
                if (count !== 0)
                {
                    this.Advance(BigInt(count));
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(296353660936)
            
            //--TRIMMABLE-BOUNDARY-START(266288889864)
            /*bool */ TryAdvanceTo(/*T*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288889864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = $.$$.S.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                if (index !== -1)
                {
                    this.Advance(BigInt(advancePastDelimiter ? ((index + 1) | 0) : index));
                    return true;
                }
                return this.TryReadToInternal($.$discardRef(), delimiter, advancePastDelimiter, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(266288889864)
            
            //--TRIMMABLE-BOUNDARY-START(270583857160)
            /*bool */ TryAdvanceToAny(/*scoped ReadOnlySpan<T>*/ delimiters, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583857160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = $.$$.S.MemoryExtensions.IndexOfAny$4(T, remaining, delimiters);
                if (index !== -1)
                {
                    this.AdvanceCurrentSpan(BigInt(index + (advancePastDelimiter ? 1 : 0)));
                    return true;
                }
                return this.TryReadToAnyInternal($.$discardRef(), delimiters, advancePastDelimiter, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(270583857160)
            
            //--TRIMMABLE-BOUNDARY-START(55835492360)
            /*long */ AdvancePast(/*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835492360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let start = this.Consumed;
                do
                {
                    /*int*/ let i;
                    for(i = this.CurrentSpanIndex; i < this.CurrentSpan.Length && $.$dsp(this.CurrentSpan._reference.GetAt(i), T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], value); i++)
                    {
                    }
                    /*int*/ let advanced = ((i - this.CurrentSpanIndex) | 0);
                    if (advanced === 0)
                    {
                        break;
                    }
                    this.AdvanceCurrentSpan(BigInt(advanced));
                }
                while(this.CurrentSpanIndex === 0 && !this.End);
                return BigInt.asIntN(64, this.Consumed - start);
            }
            //--TRIMMABLE-BOUNDARY-END(55835492360)
            
            //--TRIMMABLE-BOUNDARY-START(60130459656)
            /*long */ AdvancePastAny(/*scoped ReadOnlySpan<T>*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130459656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let start = this.Consumed;
                do
                {
                    /*int*/ let i;
                    for(i = this.CurrentSpanIndex; i < this.CurrentSpan.Length && $.$$.S.MemoryExtensions.IndexOf$4(T, values, this.CurrentSpan._reference.GetAt(i)) !== -1; i++)
                    {
                    }
                    /*int*/ let advanced = ((i - this.CurrentSpanIndex) | 0);
                    if (advanced === 0)
                    {
                        break;
                    }
                    this.AdvanceCurrentSpan(BigInt(advanced));
                }
                while(this.CurrentSpanIndex === 0 && !this.End);
                return BigInt.asIntN(64, this.Consumed - start);
            }
            //--TRIMMABLE-BOUNDARY-END(60130459656)
            
            //--TRIMMABLE-BOUNDARY-START(64425426952)
            /*long */ AdvancePastAny$1(/*T*/ value0, /*T*/ value1, /*T*/ value2, /*T*/ value3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425426952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let start = this.Consumed;
                do
                {
                    /*int*/ let i;
                    for(i = this.CurrentSpanIndex; i < this.CurrentSpan.Length; i++)
                    {
                        /*T*/ let value = this.CurrentSpan._reference.GetAt(i);
                        if (!$.$dsp(value, T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], value0) && !$.$dsp(value, T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], value1) && !$.$dsp(value, T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], value2) && !$.$dsp(value, T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], value3))
                        {
                            break;
                        }
                    }
                    /*int*/ let advanced = ((i - this.CurrentSpanIndex) | 0);
                    if (advanced === 0)
                    {
                        break;
                    }
                    this.AdvanceCurrentSpan(BigInt(advanced));
                }
                while(this.CurrentSpanIndex === 0 && !this.End);
                return BigInt.asIntN(64, this.Consumed - start);
            }
            //--TRIMMABLE-BOUNDARY-END(64425426952)
            
            //--TRIMMABLE-BOUNDARY-START(68720394248)
            /*long */ AdvancePastAny$2(/*T*/ value0, /*T*/ value1, /*T*/ value2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720394248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let start = this.Consumed;
                do
                {
                    /*int*/ let i;
                    for(i = this.CurrentSpanIndex; i < this.CurrentSpan.Length; i++)
                    {
                        /*T*/ let value = this.CurrentSpan._reference.GetAt(i);
                        if (!$.$dsp(value, T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], value0) && !$.$dsp(value, T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], value1) && !$.$dsp(value, T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], value2))
                        {
                            break;
                        }
                    }
                    /*int*/ let advanced = ((i - this.CurrentSpanIndex) | 0);
                    if (advanced === 0)
                    {
                        break;
                    }
                    this.AdvanceCurrentSpan(BigInt(advanced));
                }
                while(this.CurrentSpanIndex === 0 && !this.End);
                return BigInt.asIntN(64, this.Consumed - start);
            }
            //--TRIMMABLE-BOUNDARY-END(68720394248)
            
            //--TRIMMABLE-BOUNDARY-START(73015361544)
            /*long */ AdvancePastAny$3(/*T*/ value0, /*T*/ value1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015361544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let start = this.Consumed;
                do
                {
                    /*int*/ let i;
                    for(i = this.CurrentSpanIndex; i < this.CurrentSpan.Length; i++)
                    {
                        /*T*/ let value = this.CurrentSpan._reference.GetAt(i);
                        if (!$.$dsp(value, T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], value0) && !$.$dsp(value, T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], value1))
                        {
                            break;
                        }
                    }
                    /*int*/ let advanced = ((i - this.CurrentSpanIndex) | 0);
                    if (advanced === 0)
                    {
                        break;
                    }
                    this.AdvanceCurrentSpan(BigInt(advanced));
                }
                while(this.CurrentSpanIndex === 0 && !this.End);
                return BigInt.asIntN(64, this.Consumed - start);
            }
            //--TRIMMABLE-BOUNDARY-END(73015361544)
            
            //--TRIMMABLE-BOUNDARY-START(77310328840)
            /*void */ AdvanceToEnd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310328840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._moreData)
                {
                    this.Consumed = this.Length;
                    this.CurrentSpan = new ($.$$.S.ReadOnlySpan$$(T))();
                    this.CurrentSpanIndex = 0;
                    this._currentPosition = this.Sequence.End;
                    this._nextPosition = new $.$sm.S.SequencePosition();
                    this._moreData = false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310328840)
            
            //--TRIMMABLE-BOUNDARY-START(201864380424)
            /*bool */ IsNext$1(/*T*/ next, /*bool*/ advancePast)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864380424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.End)
                {
                    return false;
                }
                if ($.$dsp(this.CurrentSpan._reference.GetAt(this.CurrentSpanIndex), T, ($t) => $t[`S$IEquatable$${T.$getFullName('$')}$Equals`], next))
                {
                    if (advancePast)
                    {
                        this.AdvanceCurrentSpan(1n);
                    }
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(201864380424)
            
            //--TRIMMABLE-BOUNDARY-START(197569413128)
            /*bool */ IsNext(/*scoped ReadOnlySpan<T>*/ next, /*bool*/ advancePast)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569413128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let unread = this.UnreadSpan;
                if ($.$$.S.MemoryExtensions.StartsWith$2(T, unread, next))
                {
                    if (advancePast)
                    {
                        this.AdvanceCurrentSpan(BigInt(next.Length));
                    }
                    return true;
                }
                return unread.Length < next.Length && this.IsNextSlow(next, advancePast);
            }
            //--TRIMMABLE-BOUNDARY-END(197569413128)
            
            //--TRIMMABLE-BOUNDARY-START(206159347720)
            /*bool */ IsNextSlow(/*scoped ReadOnlySpan<T>*/ next, /*bool*/ advancePast)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159347720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let currentSpan = this.UnreadSpan;
                $.$$.SD.Debug.Assert$4(currentSpan.Length < next.Length, "currentSpan.Length < next.Length");
                /*int*/ let fullLength = next.Length;
                /*SequencePosition*/ let nextPosition = this._nextPosition;
                while($.$$.S.MemoryExtensions.StartsWith$2(T, next, currentSpan))
                {
                    if (next.Length === currentSpan.Length)
                    {
                        if (advancePast)
                        {
                            this.Advance(BigInt(fullLength));
                        }
                        return true;
                    }
                    while(true)
                    {
                        /*ReadOnlyMemory<T>*/ let nextSegment;
                        if (!this.Sequence.TryGet($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sm.S.SequencePosition, () => nextPosition, ($v) => nextPosition = $v, null, true), $.$ref(() => nextSegment, ($v) => nextSegment = $v, $.$$.S.ReadOnlyMemory$$(T)), true))
                        {
                            return false;
                        }
                        if (nextSegment.Length > 0)
                        {
                            next = next.Slice$1(currentSpan.Length);
                            currentSpan = nextSegment.Span;
                            if (currentSpan.Length > next.Length)
                            {
                                currentSpan = currentSpan.Slice(0, next.Length);
                            }
                            break;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(206159347720)
            
            //--TRIMMABLE-BOUNDARY-START(38655623176)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655623176);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655623176)
            
            //--TRIMMABLE-BOUNDARY-START(38655623176)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(38655623176)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._currentPosition = this._currentPosition.$clone();
                copy._nextPosition = this._nextPosition.$clone();
                copy._moreData = this._moreData;
                copy._length = this._length;
                copy.Sequence = this.Sequence.$clone();
                copy.CurrentSpan = this.CurrentSpan.$clone();
                copy.CurrentSpanIndex = this.CurrentSpanIndex;
                copy.Consumed = this.Consumed;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295884808)
                this._currentPosition = $.$default($.$sm.S.SequencePosition);
                //--TRIMMABLE-BOUNDARY-END(4295884808)
                
                //--TRIMMABLE-BOUNDARY-START(17180786696)
                this._nextPosition = $.$default($.$sm.S.SequencePosition);
                //--TRIMMABLE-BOUNDARY-END(17180786696)
                
                //--TRIMMABLE-BOUNDARY-START(236224118792)
                this.Sequence = $.$default($.$sm.SB.ReadOnlySequence$$(T));
                //--TRIMMABLE-BOUNDARY-END(236224118792)
                
                //--TRIMMABLE-BOUNDARY-START(94490198024)
                this.CurrentSpan = $.$default($.$$.S.ReadOnlySpan$$(T));
                //--TRIMMABLE-BOUNDARY-END(94490198024)
                
            }
            static $H = 917512;
            static $h = 917512;
            static $g = 1;
            static $z = 58;
            static $f = 0b1011000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(103080132616),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 137439870984,
        "h": Number(BigInt(this.$h)|0x2000000000n),
        "f": 50331649
      },
      "n": "End",
      "d": this.$h,
      "H": 103080132616,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080132616),
//--TRIMMABLE-BOUNDARY-START(236224118792),
    {
      "p": $.$sm.SB.ReadOnlySequence$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 171799609352,
        "h": Number(BigInt(this.$h)|0x2800000000n),
        "f": 50331649
      },
      "n": "Sequence",
      "d": this.$h,
      "H": 236224118792,
      "h": Number(BigInt(this.$h)|0x3700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236224118792),
//--TRIMMABLE-BOUNDARY-START(365073137672),
    {
      "p": $.$sm.SB.ReadOnlySequence$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 180389543944,
        "h": Number(BigInt(this.$h)|0x2A00000000n),
        "f": 50331649
      },
      "n": "UnreadSequence",
      "d": this.$h,
      "H": 365073137672,
      "h": Number(BigInt(this.$h)|0x5500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(365073137672),
//--TRIMMABLE-BOUNDARY-START(214749282312),
    {
      "p": 1179656,
      "g": {
        "r": 0,
        "d": 0,
        "H": 154619740168,
        "h": Number(BigInt(this.$h)|0x2400000000n),
        "f": 50331649
      },
      "n": "Position",
      "d": this.$h,
      "H": 214749282312,
      "h": Number(BigInt(this.$h)|0x3200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214749282312),
//--TRIMMABLE-BOUNDARY-START(94490198024),
    {
      "p": $.$$.S.ReadOnlySpan$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 120260001800,
        "h": Number(BigInt(this.$h)|0x1C00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 253403987976,
        "h": Number(BigInt(this.$h)|0x3B00000000n),
        "f": 83886082
      },
      "n": "CurrentSpan",
      "d": this.$h,
      "H": 94490198024,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490198024),
//--TRIMMABLE-BOUNDARY-START(98785165320),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 128849936392,
        "h": Number(BigInt(this.$h)|0x1E00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 261993922568,
        "h": Number(BigInt(this.$h)|0x3D00000000n),
        "f": 83886082
      },
      "n": "CurrentSpanIndex",
      "d": this.$h,
      "H": 98785165320,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785165320),
//--TRIMMABLE-BOUNDARY-START(369368104968),
    {
      "p": $.$$.S.ReadOnlySpan$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 188979478536,
        "h": Number(BigInt(this.$h)|0x2C00000000n),
        "f": 50331649
      },
      "n": "UnreadSpan",
      "d": this.$h,
      "H": 369368104968,
      "h": Number(BigInt(this.$h)|0x5600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(369368104968),
//--TRIMMABLE-BOUNDARY-START(90195230728),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "H": 111670067208,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "H": 244814053384,
        "h": Number(BigInt(this.$h)|0x3900000000n),
        "f": 83886082
      },
      "n": "Consumed",
      "d": this.$h,
      "H": 90195230728,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195230728),
//--TRIMMABLE-BOUNDARY-START(219044249608),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "H": 163209674760,
        "h": Number(BigInt(this.$h)|0x2600000000n),
        "f": 50331649
      },
      "n": "Remaining",
      "d": this.$h,
      "H": 219044249608,
      "h": Number(BigInt(this.$h)|0x3300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219044249608),
//--TRIMMABLE-BOUNDARY-START(210454315016),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "H": 146029805576,
        "h": Number(BigInt(this.$h)|0x2200000000n),
        "f": 50331649
      },
      "n": "Length",
      "d": this.$h,
      "H": 210454315016,
      "h": Number(BigInt(this.$h)|0x3100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210454315016)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(283468759048),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryPeek",
      "d": this.$h,
      "H": 283468759048,
      "h": Number(BigInt(this.$h)|0x4200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(283468759048),
//--TRIMMABLE-BOUNDARY-START(287763726344),
    {
      "r": 262145,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "value",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryPeek",
      "o": "@$1",
      "d": this.$h,
      "H": 287763726344,
      "h": Number(BigInt(this.$h)|0x4300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(287763726344),
//--TRIMMABLE-BOUNDARY-START(292058693640),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": T?.$h??1572864,
          "f": 2
        }
      ],
      "n": "TryRead",
      "d": this.$h,
      "H": 292058693640,
      "h": Number(BigInt(this.$h)|0x4400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(292058693640),
//--TRIMMABLE-BOUNDARY-START(231929151496),
    {
      "r": 65537,
      "p": [
        {
          "n": "count",
          "p": 917505
        }
      ],
      "n": "Rewind",
      "d": this.$h,
      "H": 231929151496,
      "h": Number(BigInt(this.$h)|0x3600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(231929151496),
//--TRIMMABLE-BOUNDARY-START(227634184200),
    {
      "r": 65537,
      "p": [
        {
          "n": "consumed",
          "p": 917505
        }
      ],
      "n": "RetreatToPreviousSpan",
      "d": this.$h,
      "H": 227634184200,
      "h": Number(BigInt(this.$h)|0x3500000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(227634184200),
//--TRIMMABLE-BOUNDARY-START(223339216904),
    {
      "r": 65537,
      "n": "ResetReader",
      "d": this.$h,
      "H": 223339216904,
      "h": Number(BigInt(this.$h)|0x3400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(223339216904),
//--TRIMMABLE-BOUNDARY-START(193274445832),
    {
      "r": 65537,
      "n": "GetNextSpan",
      "d": this.$h,
      "H": 193274445832,
      "h": Number(BigInt(this.$h)|0x2D00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(193274445832),
//--TRIMMABLE-BOUNDARY-START(47245557768),
    {
      "r": 65537,
      "p": [
        {
          "n": "count",
          "p": 917505
        }
      ],
      "n": "Advance",
      "d": this.$h,
      "H": 47245557768,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245557768),
//--TRIMMABLE-BOUNDARY-START(51540525064),
    {
      "r": 65537,
      "p": [
        {
          "n": "count",
          "p": 917505
        }
      ],
      "n": "AdvanceCurrentSpan",
      "d": this.$h,
      "H": 51540525064,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51540525064),
//--TRIMMABLE-BOUNDARY-START(85900263432),
    {
      "r": 65537,
      "p": [
        {
          "n": "count",
          "p": 917505
        }
      ],
      "n": "AdvanceWithinSpan",
      "d": this.$h,
      "H": 85900263432,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(85900263432),
//--TRIMMABLE-BOUNDARY-START(81605296136),
    {
      "r": 65537,
      "p": [
        {
          "n": "count",
          "p": 917505
        }
      ],
      "n": "AdvanceToNextSpan",
      "d": this.$h,
      "H": 81605296136,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81605296136),
//--TRIMMABLE-BOUNDARY-START(279173791752),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$(T).$h
        }
      ],
      "n": "TryCopyTo",
      "d": this.$h,
      "H": 279173791752,
      "h": Number(BigInt(this.$h)|0x4100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(279173791752),
//--TRIMMABLE-BOUNDARY-START(274878824456),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.S.Span$$(T).$h
        }
      ],
      "n": "TryCopyMultisegment",
      "d": this.$h,
      "H": 274878824456,
      "h": Number(BigInt(this.$h)|0x4000000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(274878824456),
//--TRIMMABLE-BOUNDARY-START(317828497416),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.S.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": T?.$h??1572864
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryReadTo",
      "o": "@$4",
      "d": this.$h,
      "H": 317828497416,
      "h": Number(BigInt(this.$h)|0x4A00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(317828497416),
//--TRIMMABLE-BOUNDARY-START(356483203080),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.S.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": T?.$h??1572864
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145
        }
      ],
      "n": "TryReadToSlow",
      "o": "@$2",
      "d": this.$h,
      "H": 356483203080,
      "h": Number(BigInt(this.$h)|0x5300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(356483203080),
//--TRIMMABLE-BOUNDARY-START(322123464712),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.S.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": T?.$h??1572864
        },
        {
          "n": "delimiterEscape",
          "p": T?.$h??1572864
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryReadTo",
      "o": "@$5",
      "d": this.$h,
      "H": 322123464712,
      "h": Number(BigInt(this.$h)|0x4B00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(322123464712),
//--TRIMMABLE-BOUNDARY-START(360778170376),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.S.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": T?.$h??1572864
        },
        {
          "n": "delimiterEscape",
          "p": T?.$h??1572864
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145
        }
      ],
      "n": "TryReadToSlow",
      "o": "@$3",
      "d": this.$h,
      "H": 360778170376,
      "h": Number(BigInt(this.$h)|0x5400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(360778170376),
//--TRIMMABLE-BOUNDARY-START(347893268488),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.SB.ReadOnlySequence$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": T?.$h??1572864
        },
        {
          "n": "delimiterEscape",
          "p": T?.$h??1572864
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145
        }
      ],
      "n": "TryReadToSlow",
      "d": this.$h,
      "H": 347893268488,
      "h": Number(BigInt(this.$h)|0x5100000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(347893268488),
//--TRIMMABLE-BOUNDARY-START(304943595528),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.SB.ReadOnlySequence$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": T?.$h??1572864
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryReadTo",
      "o": "@$1",
      "d": this.$h,
      "H": 304943595528,
      "h": Number(BigInt(this.$h)|0x4700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(304943595528),
//--TRIMMABLE-BOUNDARY-START(343598301192),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.SB.ReadOnlySequence$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": T?.$h??1572864
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145
        },
        {
          "n": "skip",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "TryReadToInternal",
      "d": this.$h,
      "H": 343598301192,
      "h": Number(BigInt(this.$h)|0x5000000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(343598301192),
//--TRIMMABLE-BOUNDARY-START(309238562824),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.SB.ReadOnlySequence$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": T?.$h??1572864
        },
        {
          "n": "delimiterEscape",
          "p": T?.$h??1572864
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryReadTo",
      "o": "@$2",
      "d": this.$h,
      "H": 309238562824,
      "h": Number(BigInt(this.$h)|0x4800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(309238562824),
//--TRIMMABLE-BOUNDARY-START(330713399304),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.S.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiters",
          "p": $.$$.S.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryReadToAny",
      "o": "@$1",
      "d": this.$h,
      "H": 330713399304,
      "h": Number(BigInt(this.$h)|0x4D00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(330713399304),
//--TRIMMABLE-BOUNDARY-START(339303333896),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.S.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiters",
          "p": $.$$.S.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145
        }
      ],
      "n": "TryReadToAnySlow",
      "d": this.$h,
      "H": 339303333896,
      "h": Number(BigInt(this.$h)|0x4F00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(339303333896),
//--TRIMMABLE-BOUNDARY-START(326418432008),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.SB.ReadOnlySequence$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiters",
          "p": $.$$.S.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryReadToAny",
      "d": this.$h,
      "H": 326418432008,
      "h": Number(BigInt(this.$h)|0x4C00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(326418432008),
//--TRIMMABLE-BOUNDARY-START(335008366600),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.SB.ReadOnlySequence$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiters",
          "p": $.$$.S.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145
        },
        {
          "n": "skip",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "TryReadToAnyInternal",
      "d": this.$h,
      "H": 335008366600,
      "h": Number(BigInt(this.$h)|0x4E00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(335008366600),
//--TRIMMABLE-BOUNDARY-START(313533530120),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.S.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": $.$$.S.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryReadTo",
      "o": "@$3",
      "d": this.$h,
      "H": 313533530120,
      "h": Number(BigInt(this.$h)|0x4900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(313533530120),
//--TRIMMABLE-BOUNDARY-START(352188235784),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.S.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": $.$$.S.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145
        }
      ],
      "n": "TryReadToSlow",
      "o": "@$1",
      "d": this.$h,
      "H": 352188235784,
      "h": Number(BigInt(this.$h)|0x5200000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(352188235784),
//--TRIMMABLE-BOUNDARY-START(300648628232),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.SB.ReadOnlySequence$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": $.$$.S.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryReadTo",
      "d": this.$h,
      "H": 300648628232,
      "h": Number(BigInt(this.$h)|0x4600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(300648628232),
//--TRIMMABLE-BOUNDARY-START(296353660936),
    {
      "r": 262145,
      "p": [
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "sequence",
          "p": $.$sm.SB.ReadOnlySequence$$(T).$h,
          "f": 2
        }
      ],
      "n": "TryReadExact",
      "d": this.$h,
      "H": 296353660936,
      "h": Number(BigInt(this.$h)|0x4500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(296353660936),
//--TRIMMABLE-BOUNDARY-START(266288889864),
    {
      "r": 262145,
      "p": [
        {
          "n": "delimiter",
          "p": T?.$h??1572864
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryAdvanceTo",
      "d": this.$h,
      "H": 266288889864,
      "h": Number(BigInt(this.$h)|0x3E00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(266288889864),
//--TRIMMABLE-BOUNDARY-START(270583857160),
    {
      "r": 262145,
      "p": [
        {
          "n": "delimiters",
          "p": $.$$.S.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryAdvanceToAny",
      "d": this.$h,
      "H": 270583857160,
      "h": Number(BigInt(this.$h)|0x3F00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(270583857160),
//--TRIMMABLE-BOUNDARY-START(55835492360),
    {
      "r": 917505,
      "p": [
        {
          "n": "value",
          "p": T?.$h??1572864
        }
      ],
      "n": "AdvancePast",
      "d": this.$h,
      "H": 55835492360,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835492360),
//--TRIMMABLE-BOUNDARY-START(60130459656),
    {
      "r": 917505,
      "p": [
        {
          "n": "values",
          "p": $.$$.S.ReadOnlySpan$$(T).$h
        }
      ],
      "n": "AdvancePastAny",
      "d": this.$h,
      "H": 60130459656,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130459656),
//--TRIMMABLE-BOUNDARY-START(64425426952),
    {
      "r": 917505,
      "p": [
        {
          "n": "value0",
          "p": T?.$h??1572864
        },
        {
          "n": "value1",
          "p": T?.$h??1572864
        },
        {
          "n": "value2",
          "p": T?.$h??1572864
        },
        {
          "n": "value3",
          "p": T?.$h??1572864
        }
      ],
      "n": "AdvancePastAny",
      "o": "@$1",
      "d": this.$h,
      "H": 64425426952,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425426952),
//--TRIMMABLE-BOUNDARY-START(68720394248),
    {
      "r": 917505,
      "p": [
        {
          "n": "value0",
          "p": T?.$h??1572864
        },
        {
          "n": "value1",
          "p": T?.$h??1572864
        },
        {
          "n": "value2",
          "p": T?.$h??1572864
        }
      ],
      "n": "AdvancePastAny",
      "o": "@$2",
      "d": this.$h,
      "H": 68720394248,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720394248),
//--TRIMMABLE-BOUNDARY-START(73015361544),
    {
      "r": 917505,
      "p": [
        {
          "n": "value0",
          "p": T?.$h??1572864
        },
        {
          "n": "value1",
          "p": T?.$h??1572864
        }
      ],
      "n": "AdvancePastAny",
      "o": "@$3",
      "d": this.$h,
      "H": 73015361544,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015361544),
//--TRIMMABLE-BOUNDARY-START(77310328840),
    {
      "r": 65537,
      "n": "AdvanceToEnd",
      "d": this.$h,
      "H": 77310328840,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310328840),
//--TRIMMABLE-BOUNDARY-START(201864380424),
    {
      "r": 262145,
      "p": [
        {
          "n": "next",
          "p": T?.$h??1572864
        },
        {
          "n": "advancePast",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "IsNext",
      "o": "@$1",
      "d": this.$h,
      "H": 201864380424,
      "h": Number(BigInt(this.$h)|0x2F00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201864380424),
//--TRIMMABLE-BOUNDARY-START(197569413128),
    {
      "r": 262145,
      "p": [
        {
          "n": "next",
          "p": $.$$.S.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePast",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "IsNext",
      "d": this.$h,
      "H": 197569413128,
      "h": Number(BigInt(this.$h)|0x2E00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197569413128),
//--TRIMMABLE-BOUNDARY-START(206159347720),
    {
      "r": 262145,
      "p": [
        {
          "n": "next",
          "p": $.$$.S.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePast",
          "p": 262145
        }
      ],
      "n": "IsNextSlow",
      "d": this.$h,
      "H": 206159347720,
      "h": Number(BigInt(this.$h)|0x3000000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(206159347720)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295884808),
    {
      "t": 1179656,
      "n": "_currentPosition",
      "d": this.$h,
      "H": 4295884808,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884808),
//--TRIMMABLE-BOUNDARY-START(17180786696),
    {
      "t": 1179656,
      "n": "_nextPosition",
      "d": this.$h,
      "H": 17180786696,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180786696),
//--TRIMMABLE-BOUNDARY-START(12885819400),
    {
      "t": 262145,
      "n": "_moreData",
      "d": this.$h,
      "H": 12885819400,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885819400),
//--TRIMMABLE-BOUNDARY-START(8590852104),
    {
      "t": 917505,
      "n": "_length",
      "d": this.$h,
      "H": 8590852104,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852104)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(42950590472),
    {
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.SB.ReadOnlySequence$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 42950590472,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950590472),
//--TRIMMABLE-BOUNDARY-START(38655623176),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 38655623176,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655623176)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T",
      "f": 10,
      "c": [$.$$.S.IEquatable$$(T).$h
      ]
    }
  ],
  "r": 1,
  "H": 917512,
  "h": this.$h
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Buffers.SequenceReader<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Buffers${separator}SequenceReader$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(917512)
        
        

        //--TRIMMABLE-BOUNDARY-START(524296)
        $asm.$str(`$sm.SB.ReadOnlySequence<>`, (T) => $asm.$gt(`$sm.SB.ReadOnlySequence<>`, [T], ($self) => class ReadOnlySequence$$ extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(17180393480)
            /*object?*/ _startObject = null;
            //--TRIMMABLE-BOUNDARY-END(17180393480)
            
            //--TRIMMABLE-BOUNDARY-START(8590458888)
            /*object?*/ _endObject = null;
            //--TRIMMABLE-BOUNDARY-END(8590458888)
            
            //--TRIMMABLE-BOUNDARY-START(12885426184)
            /*int*/ _startInteger = 0;
            //--TRIMMABLE-BOUNDARY-END(12885426184)
            
            //--TRIMMABLE-BOUNDARY-START(4295491592)
            /*int*/ _endInteger = 0;
            //--TRIMMABLE-BOUNDARY-END(4295491592)
            
            //--TRIMMABLE-BOUNDARY-START(60130066440)
            /*ReadOnlySequence<T>*/ static Empty;
            //--TRIMMABLE-BOUNDARY-END(60130066440)
            
            //--TRIMMABLE-BOUNDARY-START(214748889096)
            /*long */ get Length()
            {
                return this.GetLength();
            }
            //--TRIMMABLE-BOUNDARY-END(214748889096)
            
            //--TRIMMABLE-BOUNDARY-START(206158954504)
            /*bool */ get IsEmpty()
            {
                return this.Length === 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(206158954504)
            
            //--TRIMMABLE-BOUNDARY-START(210453921800)
            /*bool */ get IsSingleSegment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964641288);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._startObject === this._endObject;
            }
            //--TRIMMABLE-BOUNDARY-END(210453921800)
            
            //--TRIMMABLE-BOUNDARY-START(68720001032)
            /*ReadOnlyMemory<T> */ get First()
            {
                return this.GetFirstBuffer();
            }
            //--TRIMMABLE-BOUNDARY-END(68720001032)
            
            //--TRIMMABLE-BOUNDARY-START(73014968328)
            /*ReadOnlySpan<T> */ get FirstSpan()
            {
                return this.GetFirstSpan();
            }
            //--TRIMMABLE-BOUNDARY-END(73014968328)
            
            //--TRIMMABLE-BOUNDARY-START(279173398536)
            /*SequencePosition */ get Start()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144510472);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sm.S.SequencePosition().$ctor$3(this._startObject, $.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._startInteger));
            }
            //--TRIMMABLE-BOUNDARY-END(279173398536)
            
            //--TRIMMABLE-BOUNDARY-START(64425033736)
            /*SequencePosition */ get End()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604902920);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sm.S.SequencePosition().$ctor$3(this._endObject, $.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._endInteger));
            }
            //--TRIMMABLE-BOUNDARY-END(64425033736)
            
            //--TRIMMABLE-BOUNDARY-START(34360262664)
            $ctor$4(/*object?*/ startSegment, /*int*/ startIndexAndFlags, /*object?*/ endSegment, /*int*/ endIndexAndFlags)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360262664);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.SD.Debug.Assert$4((startSegment !== null && endSegment !== null) || (startSegment === null && endSegment === null && startIndexAndFlags === 0 && endIndexAndFlags === 0), "(startSegment != null && endSegment != null) ||\r\n                (startSegment == null && endSegment == null && startIndexAndFlags == 0 && endIndexAndFlags == 0)");
                    this._startObject = startSegment;
                    this._endObject = endSegment;
                    this._startInteger = startIndexAndFlags;
                    this._endInteger = endIndexAndFlags;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360262664)
            
            //--TRIMMABLE-BOUNDARY-START(30065295368)
            $ctor$3(/*ReadOnlySequenceSegment<T>*/ startSegment, /*int*/ startIndex, /*ReadOnlySequenceSegment<T>*/ endSegment, /*int*/ endIndex)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065295368);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (startSegment === null || endSegment === null || (startSegment !== endSegment && startSegment.RunningIndex > endSegment.RunningIndex) || (startSegment.Memory.Length >>> 0) < (startIndex >>> 0) || (endSegment.Memory.Length >>> 0) < (endIndex >>> 0) || (startSegment === endSegment && endIndex < startIndex))
                    {
                        $.$sm.S.ThrowHelper.ThrowArgumentValidationException$1(T, startSegment, startIndex, endSegment);
                    }
                    this._startObject = startSegment;
                    this._endObject = endSegment;
                    this._startInteger = startIndex;
                    this._endInteger = endIndex;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065295368)
            
            //--TRIMMABLE-BOUNDARY-START(47245164552)
            $ctor$7(/*T[]*/ array)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47245164552);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (array === null)
                    {
                        $.$sm.S.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.array*/);
                    }
                    this._startObject = array;
                    this._endObject = array;
                    this._startInteger = 0;
                    this._endInteger = $.$sm.SB.ReadOnlySequence.ArrayToSequenceEnd(array.length);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(47245164552)
            
            //--TRIMMABLE-BOUNDARY-START(42950197256)
            $ctor$6(/*T[]*/ array, /*int*/ start, /*int*/ length)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950197256);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (array === null || (start >>> 0) > (array.length >>> 0) || (length >>> 0) > ((((array.length - start) | 0)) >>> 0))
                    {
                        $.$sm.S.ThrowHelper.ThrowArgumentValidationException(array, start);
                    }
                    this._startObject = array;
                    this._endObject = array;
                    this._startInteger = start;
                    this._endInteger = $.$sm.SB.ReadOnlySequence.ArrayToSequenceEnd(((start + length) | 0));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950197256)
            
            //--TRIMMABLE-BOUNDARY-START(38655229960)
            $ctor$5(/*ReadOnlyMemory<T>*/ memory)
            {
                super.$ctor$1();
                {
                    /*MemoryManager<T>?*/ let manager;
                    /*int*/ let index;
                    /*int*/ let length;
                    /*ArraySegment<T>*/ let segment;
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655229960);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if ($.$$.SRI.MemoryMarshal.TryGetMemoryManager(T, $.$$.SB.MemoryManager$$(T), memory, $.$ref(() => manager, ($v) => manager = $v, $.$$.SB.MemoryManager$$(T)), $.$ref(() => index, ($v) => index = $v, $.$$.S.Int32), $.$ref(() => length, ($v) => length = $v, $.$$.S.Int32)))
                    {
                        this._startObject = manager;
                        this._endObject = manager;
                        this._startInteger = $.$sm.SB.ReadOnlySequence.MemoryManagerToSequenceStart(index);
                        this._endInteger = ((index + length) | 0);
                    }
                    else if ($.$$.SRI.MemoryMarshal.TryGetArray(T, memory, $.$ref(() => segment, ($v) => segment = $v, $.$$.S.ArraySegment$$(T))))
                    {
                        /*T[]?*/ let array = segment.Array;
                        /*int*/ let start = segment.Offset;
                        this._startObject = array;
                        this._endObject = array;
                        this._startInteger = start;
                        this._endInteger = $.$sm.SB.ReadOnlySequence.ArrayToSequenceEnd(((start + segment.Count) | 0));
                    }
                    else if (T.$type === $.$$.S.Char.$type)
                    {
                        /*string?*/ let text;
                        /*int*/ let start;
                        if (!$.$$.SRI.MemoryMarshal.TryGetString($.$cast($.$cast(memory, $.$$.S.Object), $.$$.S.ReadOnlyMemory$$($.$$.S.Char)), $.$ref(() => text, ($v) => text = $v, $.$$.S.String), $.$ref(() => start, ($v) => start = $v, $.$$.S.Int32), $.$ref(() => length, ($v) => length = $v, $.$$.S.Int32)))
                        {
                            $.$sm.S.ThrowHelper.ThrowInvalidOperationException();
                        }
                        this._startObject = text;
                        this._endObject = text;
                        this._startInteger = $.$sm.SB.ReadOnlySequence.StringToSequenceStart(start);
                        this._endInteger = $.$sm.SB.ReadOnlySequence.StringToSequenceEnd(((start + length) | 0));
                    }
                    else 
                    {
                        $.$sm.S.ThrowHelper.ThrowInvalidOperationException();
                        this._startObject = null;
                        this._endObject = null;
                        this._startInteger = 0;
                        this._endInteger = 0;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655229960)
            
            //--TRIMMABLE-BOUNDARY-START(240518692872)
            /*ReadOnlySequence<T> */ Slice$2(/*long*/ start, /*long*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518692872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (start < 0n || length < 0n)
                {
                    $.$sm.S.ThrowHelper.ThrowStartOrEndArgumentValidationException(start);
                }
                /*SequencePosition*/ let begin;
                /*SequencePosition*/ let end;
                /*int*/ let startIndex = $.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                /*int*/ let endIndex = $.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                /*object?*/ let startObject = this._startObject;
                /*object?*/ let endObject = this._endObject;
                if (startObject !== endObject)
                {
                    $.$$.SD.Debug.Assert$4(startObject !== null, "startObject != null");
                    /*var*/ let startSegment = $.$cast(startObject, $.$sm.SB.ReadOnlySequenceSegment$$(T));
                    /*int*/ let currentLength = ((startSegment.Memory.Length - startIndex) | 0);
                    if (BigInt(currentLength) > start)
                    {
                        startIndex += $.$cast(start, $.$$.S.Int32);
                        begin = new $.$sm.S.SequencePosition().$ctor$3(startObject, startIndex);
                        end = $.$sm.SB.ReadOnlySequence$$(T).GetEndPosition(startSegment, startObject, startIndex, endObject, endIndex, length);
                    }
                    else 
                    {
                        if (currentLength < 0)
                        {
                            $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                        }
                        begin = $.$sm.SB.ReadOnlySequence$$(T).SeekMultiSegment(startSegment.Next, endObject, endIndex, BigInt.asIntN(64, start - BigInt(currentLength)), 1/*ExceptionArgument.start*/);
                        /*int*/ let beginIndex = begin.GetInteger();
                        /*object*/ let beginObject = begin.GetObject();
                        if (beginObject !== endObject)
                        {
                            $.$$.SD.Debug.Assert$4(beginObject !== null, "beginObject != null");
                            end = $.$sm.SB.ReadOnlySequence$$(T).GetEndPosition($.$cast(beginObject, $.$sm.SB.ReadOnlySequenceSegment$$(T)), beginObject, beginIndex, endObject, endIndex, length);
                        }
                        else 
                        {
                            if (BigInt(endIndex - beginIndex) < length)
                            {
                                $.$sm.S.ThrowHelper.ThrowStartOrEndArgumentValidationException(0n);
                            }
                            end = new $.$sm.S.SequencePosition().$ctor$3(beginObject, ((beginIndex + $.$cast(length, $.$$.S.Int32)) | 0));
                        }
                    }
                }
                else 
                {
                    if (BigInt(endIndex - startIndex) < start)
                    {
                        $.$sm.S.ThrowHelper.ThrowStartOrEndArgumentValidationException(BigInt(-1));
                    }
                    startIndex += $.$cast(start, $.$$.S.Int32);
                    begin = new $.$sm.S.SequencePosition().$ctor$3(startObject, startIndex);
                    if (BigInt(endIndex - startIndex) < length)
                    {
                        $.$sm.S.ThrowHelper.ThrowStartOrEndArgumentValidationException(0n);
                    }
                    end = new $.$sm.S.SequencePosition().$ctor$3(startObject, ((startIndex + $.$cast(length, $.$$.S.Int32)) | 0));
                }
                return this.SliceImpl($.$ref(() => begin, ), $.$ref(() => end, ));
            }
            //--TRIMMABLE-BOUNDARY-END(240518692872)
            
            //--TRIMMABLE-BOUNDARY-START(244813660168)
            /*ReadOnlySequence<T> */ Slice$3(/*long*/ start, /*SequencePosition*/ end)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813660168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let startIndex;
                /*object?*/ let startObject;
                /*uint*/ let endIndex;
                /*object?*/ let endObject;
                /*uint*/ let sliceEndIndex;
                /*object?*/ let sliceEndObject;
                /*var*/ let startSegment;
                /*ulong*/ let startRange;
                /*ulong*/ let sliceRange;
                /*int*/ let currentLength;
                let $gotoJumpState8 = 0;
                $gotoJumpStart8: while(true)
                {
                    switch($gotoJumpState8)
                    {
                        case 0:
                        {
                            if (start < 0n)
                            {
                                $.$sm.S.ThrowHelper.ThrowStartOrEndArgumentValidationException(start);
                            }
                            startIndex = ($.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._startInteger) >>> 0);
                            startObject = this._startObject;
                            endIndex = ($.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._endInteger) >>> 0);
                            endObject = this._endObject;
                            sliceEndIndex = (end.GetInteger() >>> 0);
                            sliceEndObject = end.GetObject();
                            if (sliceEndObject === null)
                            {
                                sliceEndObject = this._startObject;
                                sliceEndIndex = startIndex;
                            }
                            if (startObject === endObject)
                            {
                                if (!$.$sm.SB.ReadOnlySequence$$(T).InRange(sliceEndIndex, startIndex, endIndex))
                                {
                                    $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                if (BigInt(sliceEndIndex - startIndex) < start)
                                {
                                    $.$sm.S.ThrowHelper.ThrowStartOrEndArgumentValidationException(BigInt(-1));
                                }
                                $gotoJumpState8 = 1; /*goto FoundInFirstSegment*/
                                continue $gotoJumpStart8;
                            }
                            startSegment = $.$cast(startObject, $.$sm.SB.ReadOnlySequenceSegment$$(T));
                            startRange = $.$cast((BigInt.asIntN(64, startSegment.RunningIndex + BigInt(startIndex))), $.$$.S.UInt64);
                            sliceRange = $.$cast((BigInt.asIntN(64, ($.$cast(sliceEndObject, $.$sm.SB.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(sliceEndIndex))), $.$$.S.UInt64);
                            $.$$.SD.Debug.Assert$4(sliceEndIndex >= 0 && startIndex >= 0 && endIndex >= 0, "sliceEndIndex >= 0 && startIndex >= 0 && endIndex >= 0");
                            if (!$.$sm.SB.ReadOnlySequence$$(T).InRange$1(sliceRange, startRange, $.$cast((BigInt.asIntN(64, ($.$cast(endObject, $.$sm.SB.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(endIndex))), $.$$.S.UInt64)))
                            {
                                $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                            }
                            if (BigInt.asUintN(64, startRange + $.$cast(start, $.$$.S.UInt64)) > sliceRange)
                            {
                                $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.start*/);
                            }
                            currentLength = ((startSegment.Memory.Length - (startIndex | 0)) | 0);
                            if (BigInt(currentLength) <= start)
                            {
                                if (currentLength < 0)
                                {
                                    $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                /*SequencePosition*/ var begin = $.$sm.SB.ReadOnlySequence$$(T).SeekMultiSegment(startSegment.Next, sliceEndObject, (sliceEndIndex | 0), BigInt.asIntN(64, start - BigInt(currentLength)), 1/*ExceptionArgument.start*/);
                                return this.SliceImpl($.$ref(() => begin, ), $.$ref(() => end, ));
                            }
                        }
                        case 1: /*FoundInFirstSegment*/
                        $.$$.SD.Debug.Assert$4(start <= BigInt(2147483647/*int.MaxValue*/ - startIndex), "start <= int.MaxValue - startIndex");
                        return this.SliceImpl($.$ref(() => new $.$sm.S.SequencePosition().$ctor$3(startObject, (((startIndex | 0) + $.$cast(start, $.$$.S.Int32)) | 0)), ), $.$ref(() => new $.$sm.S.SequencePosition().$ctor$3(sliceEndObject, (sliceEndIndex | 0)), ));
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(244813660168)
            
            //--TRIMMABLE-BOUNDARY-START(257698562056)
            /*ReadOnlySequence<T> */ Slice$6(/*SequencePosition*/ start, /*long*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698562056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let startIndex;
                /*object?*/ let startObject;
                /*uint*/ let endIndex;
                /*object?*/ let endObject;
                /*uint*/ let sliceStartIndex;
                /*object?*/ let sliceStartObject;
                /*var*/ let sliceStartSegment;
                /*ulong*/ let sliceRange;
                /*ulong*/ let startRange;
                /*ulong*/ let endRange;
                /*int*/ let currentLength;
                let $gotoJumpState9 = 0;
                $gotoJumpStart9: while(true)
                {
                    switch($gotoJumpState9)
                    {
                        case 0:
                        {
                            startIndex = ($.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._startInteger) >>> 0);
                            startObject = this._startObject;
                            endIndex = ($.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._endInteger) >>> 0);
                            endObject = this._endObject;
                            sliceStartIndex = (start.GetInteger() >>> 0);
                            sliceStartObject = start.GetObject();
                            if (sliceStartObject === null)
                            {
                                sliceStartIndex = startIndex;
                                sliceStartObject = this._startObject;
                            }
                            if (startObject === endObject)
                            {
                                if (!$.$sm.SB.ReadOnlySequence$$(T).InRange(sliceStartIndex, startIndex, endIndex))
                                {
                                    $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                if (length < 0n)
                                {
                                    $.$sm.S.ThrowHelper.ThrowStartOrEndArgumentValidationException(0n);
                                }
                                if (BigInt(endIndex - sliceStartIndex) < length)
                                {
                                    $.$sm.S.ThrowHelper.ThrowStartOrEndArgumentValidationException(0n);
                                }
                                $gotoJumpState9 = 1; /*goto FoundInFirstSegment*/
                                continue $gotoJumpStart9;
                            }
                            sliceStartSegment = $.$cast(sliceStartObject, $.$sm.SB.ReadOnlySequenceSegment$$(T));
                            sliceRange = $.$cast(((BigInt.asIntN(64, sliceStartSegment.RunningIndex + BigInt(sliceStartIndex)))), $.$$.S.UInt64);
                            startRange = $.$cast((BigInt.asIntN(64, ($.$cast(startObject, $.$sm.SB.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(startIndex))), $.$$.S.UInt64);
                            endRange = $.$cast((BigInt.asIntN(64, ($.$cast(endObject, $.$sm.SB.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(endIndex))), $.$$.S.UInt64);
                            $.$$.SD.Debug.Assert$4(sliceStartIndex >= 0 && startIndex >= 0 && endIndex >= 0, "sliceStartIndex >= 0 && startIndex >= 0 && endIndex >= 0");
                            if (!$.$sm.SB.ReadOnlySequence$$(T).InRange$1(sliceRange, startRange, endRange))
                            {
                                $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                            }
                            if (length < 0n)
                            {
                                $.$sm.S.ThrowHelper.ThrowStartOrEndArgumentValidationException(0n);
                            }
                            if (BigInt.asUintN(64, sliceRange + $.$cast(length, $.$$.S.UInt64)) > endRange)
                            {
                                $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException(0/*ExceptionArgument.length*/);
                            }
                            currentLength = ((sliceStartSegment.Memory.Length - (sliceStartIndex | 0)) | 0);
                            if (BigInt(currentLength) < length)
                            {
                                if (currentLength < 0)
                                {
                                    $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                /*SequencePosition*/ var end = $.$sm.SB.ReadOnlySequence$$(T).SeekMultiSegment(sliceStartSegment.Next, endObject, (endIndex | 0), BigInt.asIntN(64, length - BigInt(currentLength)), 0/*ExceptionArgument.length*/);
                                return this.SliceImpl($.$ref(() => start, ), $.$ref(() => end, ));
                            }
                        }
                        case 1: /*FoundInFirstSegment*/
                        $.$$.SD.Debug.Assert$4(length <= BigInt(2147483647/*int.MaxValue*/ - sliceStartIndex), "length <= int.MaxValue - sliceStartIndex");
                        return this.SliceImpl($.$ref(() => new $.$sm.S.SequencePosition().$ctor$3(sliceStartObject, (sliceStartIndex | 0)), ), $.$ref(() => new $.$sm.S.SequencePosition().$ctor$3(sliceStartObject, (((sliceStartIndex | 0) + $.$cast(length, $.$$.S.Int32)) | 0)), ));
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(257698562056)
            
            //--TRIMMABLE-BOUNDARY-START(231928758280)
            /*ReadOnlySequence<T> */ Slice(/*int*/ start, /*int*/ length)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(231928758280);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Slice$2($.$cast(start, $.$$.S.Int64), BigInt(length));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231928758280)
            
            //--TRIMMABLE-BOUNDARY-START(236223725576)
            /*ReadOnlySequence<T> */ Slice$1(/*int*/ start, /*SequencePosition*/ end)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(236223725576);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Slice$3($.$cast(start, $.$$.S.Int64), end);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(236223725576)
            
            //--TRIMMABLE-BOUNDARY-START(253403594760)
            /*ReadOnlySequence<T> */ Slice$5(/*SequencePosition*/ start, /*int*/ length)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(253403594760);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Slice$6(start, $.$cast(length, $.$$.S.Int64));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(253403594760)
            
            //--TRIMMABLE-BOUNDARY-START(261993529352)
            /*ReadOnlySequence<T> */ Slice$7(/*SequencePosition*/ start, /*SequencePosition*/ end)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993529352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.BoundsCheck$1((start.GetInteger() >>> 0), start.GetObject(), (end.GetInteger() >>> 0), end.GetObject());
                return this.SliceImpl($.$ref(() => start, ), $.$ref(() => end, ));
            }
            //--TRIMMABLE-BOUNDARY-END(261993529352)
            
            //--TRIMMABLE-BOUNDARY-START(266288496648)
            /*ReadOnlySequence<T> */ Slice$8(/*SequencePosition*/ start)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288496648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let positionIsNotNull = start.GetObject() !== null;
                this.BoundsCheck($.$ref(() => start, ), positionIsNotNull);
                return this.SliceImpl$1($.$ref(() => positionIsNotNull ? start : this.Start, ));
            }
            //--TRIMMABLE-BOUNDARY-END(266288496648)
            
            //--TRIMMABLE-BOUNDARY-START(249108627464)
            /*ReadOnlySequence<T> */ Slice$4(/*long*/ start)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108627464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (start < 0n)
                {
                    $.$sm.S.ThrowHelper.ThrowStartOrEndArgumentValidationException(start);
                }
                if (start === 0n)
                {
                    return this;
                }
                /*SequencePosition*/ let begin = this.Seek$1(start, 1/*ExceptionArgument.start*/);
                return this.SliceImpl$1($.$ref(() => begin, ));
            }
            //--TRIMMABLE-BOUNDARY-END(249108627464)
            
            //--TRIMMABLE-BOUNDARY-START(283468365832)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468365832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (T.$type === $.$$.S.Char.$type)
                {
                    /*string?*/ let text;
                    /*int*/ let start;
                    /*int*/ let length;
                    /*ReadOnlySequence<T>*/ let localThis = this;
                    /*ReadOnlySequence<char>*/ let charSequence = $.$$.SRC.Unsafe.As($.$sm.SB.ReadOnlySequence$$(T), $.$sm.SB.ReadOnlySequence$$($.$$.S.Char), $.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sm.SB.ReadOnlySequence$$(T), () => localThis, ($v) => localThis = $v, null, true)).$v;
                    if (charSequence.TryGetString($.$ref(() => text, ($v) => text = $v, $.$$.S.String), $.$ref(() => start, ($v) => start = $v, $.$$.S.Int32), $.$ref(() => length, ($v) => length = $v, $.$$.S.Int32)))
                    {
                        return text.substr(start, length);
                    }
                    if (this.Length < BigInt(2147483647/*int.MaxValue*/))
                    {
                        return $.$$.S.String.Create$10($.$sm.SB.ReadOnlySequence$$($.$$.S.Char), $.$cast(this.Length, $.$$.S.Int32), charSequence, new ($.$$.SB.SpanAction$$$($.$$.S.Char, $.$sm.SB.ReadOnlySequence$$($.$$.S.Char)))().$ctor(this,  (/*span*/ span, /*sequence*/ sequence) =>
                        {
                            return $.$sm.SB.BuffersExtensions.CopyTo($.$$.S.Char, $.$ref(() => sequence, ), span);
                        }, $BftXfb ??= {"r":65537,"p":[{"n":"span","p":$.$$.S.Span$$($.$$.S.Char).$h},{"n":"sequence","p":$.$sm.SB.ReadOnlySequence$$($.$$.S.Char).$h}],"n":"","d":this.$h,"H":0,"h":0,"f":17825794}));
                    }
                }
                return `System.Buffers.ReadOnlySequence<${$.$strNN(T.$type.Name)}>[${$.$strNN(this.Length)}]`;
            }
            //--TRIMMABLE-BOUNDARY-END(283468365832)
            
            //--TRIMMABLE-BOUNDARY-START(141734445064)
            /*Enumerator */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141734445064);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$sm.SB.ReadOnlySequence$$(T).Enumerator)().$ctor$3(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141734445064)
            
            //--TRIMMABLE-BOUNDARY-START(188979085320)
            /*SequencePosition */ GetPosition$1(/*long*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979085320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (offset < 0n)
                {
                    $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_OffsetOutOfRange();
                }
                return this.Seek$1(offset, 7);
            }
            //--TRIMMABLE-BOUNDARY-END(188979085320)
            
            //--TRIMMABLE-BOUNDARY-START(180389150728)
            /*long */ GetOffset(/*SequencePosition*/ position)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389150728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let positionSequenceObject = position.GetObject();
                /*bool*/ let positionIsNull = positionSequenceObject === null;
                this.BoundsCheck($.$ref(() => position, ), !positionIsNull);
                /*object?*/ let startObject = this._startObject;
                /*object?*/ let endObject = this._endObject;
                /*uint*/ let positionIndex = (position.GetInteger() >>> 0);
                if (positionIsNull)
                {
                    positionSequenceObject = this._startObject;
                    positionIndex = ($.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._startInteger) >>> 0);
                }
                if (startObject === endObject)
                {
                    return BigInt(positionIndex);
                }
                else 
                {
                    $.$$.SD.Debug.Assert$4(positionSequenceObject !== null, "positionSequenceObject != null");
                    if (BigInt(($.$cast(positionSequenceObject, $.$sm.SB.ReadOnlySequenceSegment$$(T))).Memory.Length) - BigInt(positionIndex) < 0n)
                    {
                        $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                    /*ReadOnlySequenceSegment<T>?*/ let currentSegment = $.$cast(startObject, $.$sm.SB.ReadOnlySequenceSegment$$(T));
                    while(currentSegment !== null && currentSegment !== positionSequenceObject)
                    {
                        currentSegment = currentSegment.Next;
                    }
                    if (currentSegment === null)
                    {
                        $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                    $.$$.SD.Debug.Assert$4(BigInt.asIntN(64, currentSegment.RunningIndex + BigInt(positionIndex)) >= 0n, "currentSegment!.RunningIndex + positionIndex >= 0");
                    return BigInt.asIntN(64, currentSegment.RunningIndex + BigInt(positionIndex));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(180389150728)
            
            //--TRIMMABLE-BOUNDARY-START(184684118024)
            /*SequencePosition */ GetPosition(/*long*/ offset, /*SequencePosition*/ origin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684118024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (offset < 0n)
                {
                    $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_OffsetOutOfRange();
                }
                return this.Seek($.$ref(() => origin, ), offset);
            }
            //--TRIMMABLE-BOUNDARY-END(184684118024)
            
            //--TRIMMABLE-BOUNDARY-START(287763333128)
            /*bool */ TryGet(/*ref SequencePosition*/ position, /*out ReadOnlyMemory<T>*/ memory, /*bool*/ advance)
            {
                /*SequencePosition*/ let next;
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763333128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let result = this.TryGetBuffer(position, memory, $.$ref(() => next, ($v) => next = $v, $.$sm.S.SequencePosition));
                if (advance)
                {
                    position.$v = next;
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(287763333128)
            
            //--TRIMMABLE-BOUNDARY-START(589832)
            static $_Enumerator;
            static get Enumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(589832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sm.SB.ReadOnlySequence$$(T);
                return $cls.$_Enumerator ??= $asm.$nstr(`$sm.SB.ReadOnlySequence<${T?.$fullName}>.Enumerator`, ($self) => class Enumerator extends $.$$.S.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12885491720)
                    /*ReadOnlySequence<T>*/ _sequence;
                    //--TRIMMABLE-BOUNDARY-END(12885491720)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590524424)
                    /*SequencePosition*/ _next;
                    //--TRIMMABLE-BOUNDARY-END(8590524424)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295557128)
                    /*ReadOnlyMemory<T>*/ _currentMemory;
                    //--TRIMMABLE-BOUNDARY-END(4295557128)
                    
                    //--TRIMMABLE-BOUNDARY-START(21475426312)
                    $ctor$3(/*in ReadOnlySequence<T>*/ sequence)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(21475426312);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._currentMemory = new ($.$$.S.ReadOnlyMemory$$(T))();
                            this._next = sequence.$v.Start;
                            this._sequence = sequence.$v;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(21475426312)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770393608)
                    /*ReadOnlyMemory<T> */ get Current()
                    {
                        return this._currentMemory;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770393608)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655295496)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655295496);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._next.GetObject() === null)
                        {
                            return false;
                        }
                        return this._sequence.TryGet($.$$.SRC.RuntimeHelpers.CreateObjectReferenceT($.$sm.S.SequencePosition, () => this._next, ($v) => this._next = $v, null, true), $.$ref(() => this._currentMemory, ($v) => this._currentMemory = $v, $.$$.S.ReadOnlyMemory$$(T)), true);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655295496)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180459016)
                    //default constructor overload
                    $ctor$2()
                    {
                        super.$ctor$1();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(17180459016);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180459016)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180459016)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$2();
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180459016)
                    
                    $clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._sequence = this._sequence.$clone();
                        copy._next = this._next.$clone();
                        copy._currentMemory = this._currentMemory.$clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(12885491720)
                        this._sequence = $.$default($.$sm.SB.ReadOnlySequence$$(T));
                        //--TRIMMABLE-BOUNDARY-END(12885491720)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590524424)
                        this._next = $.$default($.$sm.S.SequencePosition);
                        //--TRIMMABLE-BOUNDARY-END(8590524424)
                        
                        //--TRIMMABLE-BOUNDARY-START(4295557128)
                        this._currentMemory = $.$default($.$$.S.ReadOnlyMemory$$(T));
                        //--TRIMMABLE-BOUNDARY-END(4295557128)
                        
                    }
                    static $H = 589832;
                    static $h = 589832;
                    static $z = 36;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.ValueType; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770393608),
    {
      "p": $.$$.S.ReadOnlyMemory$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 34360328200,
        "h": Number(BigInt(589832)|0x800000000n),
        "f": 50331649
      },
      "n": "Current",
      "d": 589832,
      "H": 25770393608,
      "h": Number(BigInt(589832)|0x600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770393608)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655295496),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 589832,
      "H": 38655295496,
      "h": Number(BigInt(589832)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655295496)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885491720),
    {
      "t": 524296,
      "n": "_sequence",
      "d": 589832,
      "H": 12885491720,
      "h": Number(BigInt(589832)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885491720),
//--TRIMMABLE-BOUNDARY-START(8590524424),
    {
      "t": 1179656,
      "n": "_next",
      "d": 589832,
      "H": 8590524424,
      "h": Number(BigInt(589832)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524424),
//--TRIMMABLE-BOUNDARY-START(4295557128),
    {
      "t": $.$$.S.ReadOnlyMemory$$(T).$h,
      "n": "_currentMemory",
      "d": 589832,
      "H": 4295557128,
      "h": Number(BigInt(589832)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557128)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475426312),
    {
      "p": [
        {
          "n": "sequence",
          "p": 524296,
          "f": 8
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589832,
      "H": 21475426312,
      "h": Number(BigInt(589832)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426312),
//--TRIMMABLE-BOUNDARY-START(17180459016),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589832,
      "H": 17180459016,
      "h": Number(BigInt(589832)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180459016)
  ],
  "d": 524296,
  "H": 589832,
  "h": 589832
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Buffers.ReadOnlySequence<${T?.$fullName}>+Enumerator`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Buffers${separator}ReadOnlySequence$${T?.$getFullName(separator)}$${separator}Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(589832)
            
            //--TRIMMABLE-BOUNDARY-START(655368)
            static $_SequenceType;
            static get SequenceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(655368);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sm.SB.ReadOnlySequence$$(T);
                return $cls.$_SequenceType ??= $asm.$nstr(`$sm.SB.ReadOnlySequence<${T?.$fullName}>.SequenceType`, ($self) => class SequenceType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
                {
                    static MultiSegment = 0;
                    static Array = 1;
                    static MemoryManager = 2;
                    static String = 3;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(655368);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "MultiSegment": 0n,
                            "Array": 1n,
                            "MemoryManager": 2n,
                            "String": 3n
                        };
                    }
                    //--TRIMMABLE-BOUNDARY-START(4295622664)
                    //default constructor overload
                    $ctor$3()
                    {
                        super.$ctor$2();
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4295622664);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295622664)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295622664)
                    //generic new constructor
                    $gctor()
                    {
                        return this.$ctor$3();
                    }
                    //--TRIMMABLE-BOUNDARY-END(4295622664)
                    
                    static $H = 655368;
                    static $h = 655368;
                    static $z = 4;
                    static $f = 0b110000011011001000;
                    static $k = 4;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Enum; }
                    static get $eut() { return $.$$.S.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180524552),
    {
      "t": 655368,
      "n": "MultiSegment",
      "d": 655368,
      "H": 17180524552,
      "h": Number(BigInt(655368)|0x400000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180524552),
//--TRIMMABLE-BOUNDARY-START(8590589960),
    {
      "t": 655368,
      "n": "Array",
      "d": 655368,
      "H": 8590589960,
      "h": Number(BigInt(655368)|0x200000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590589960),
//--TRIMMABLE-BOUNDARY-START(12885557256),
    {
      "t": 655368,
      "n": "MemoryManager",
      "d": 655368,
      "H": 12885557256,
      "h": Number(BigInt(655368)|0x300000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885557256),
//--TRIMMABLE-BOUNDARY-START(21475491848),
    {
      "t": 655368,
      "n": "String",
      "d": 655368,
      "H": 21475491848,
      "h": Number(BigInt(655368)|0x500000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475491848)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622664),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655368,
      "H": 4295622664,
      "h": Number(BigInt(655368)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622664)
  ],
  "d": 524296,
  "H": 655368,
  "h": 655368
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Buffers.ReadOnlySequence<${T?.$fullName}>+SequenceType`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Buffers${separator}ReadOnlySequence$${T?.$getFullName(separator)}$${separator}SequenceType`; }
                }, $cls, ($v) => $cls.$_SequenceType = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655368)
            
            //--TRIMMABLE-BOUNDARY-START(296353267720)
            /*bool */ TryGetBuffer(/*in SequencePosition*/ position, /*out ReadOnlyMemory<T>*/ memory, /*out SequencePosition*/ next)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353267720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let positionObject = position.$v.GetObject();
                next.$v = new $.$sm.S.SequencePosition();
                if (positionObject === null)
                {
                    memory.$v = new ($.$$.S.ReadOnlyMemory$$(T))();
                    return false;
                }
                /*SequenceType*/ let type = this.GetSequenceType();
                /*object?*/ let endObject = this._endObject;
                /*int*/ let startIndex = position.$v.GetInteger();
                /*int*/ let endIndex = $.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                if (type === 0/*SequenceType.MultiSegment*/)
                {
                    $.$$.SD.Debug.Assert$4($.$is(positionObject, $.$sm.SB.ReadOnlySequenceSegment$$(T)), "positionObject is ReadOnlySequenceSegment<T>");
                    /*ReadOnlySequenceSegment<T>*/ let startSegment = $.$cast(positionObject, $.$sm.SB.ReadOnlySequenceSegment$$(T));
                    if (startSegment !== endObject)
                    {
                        /*ReadOnlySequenceSegment<T>?*/ let nextSegment = startSegment.Next;
                        if (nextSegment === null)
                        {
                            $.$sm.S.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                        }
                        next.$v = new $.$sm.S.SequencePosition().$ctor$3(nextSegment, 0);
                        memory.$v = startSegment.Memory.Slice$1(startIndex);
                    }
                    else 
                    {
                        memory.$v = startSegment.Memory.Slice(startIndex, ((endIndex - startIndex) | 0));
                    }
                }
                else 
                {
                    if (positionObject !== endObject)
                    {
                        $.$sm.S.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                    }
                    if (type === 1/*SequenceType.Array*/)
                    {
                        $.$$.SD.Debug.Assert$4($.$is(positionObject, $.$typeArray(T)), "positionObject is T[]");
                        memory.$v = new ($.$$.S.ReadOnlyMemory$$(T))().$ctor$4($.$cast(positionObject, $.$typeArray(T)), startIndex, ((endIndex - startIndex) | 0));
                    }
                    else if (T.$type === $.$$.S.Char.$type && type === 3/*SequenceType.String*/)
                    {
                        $.$$.SD.Debug.Assert$4($.$is(positionObject, $.$$.S.String), "positionObject is string");
                        memory.$v = $.$cast($.$cast($.$$.S.MemoryExtensions.AsMemory$1(($.$cast(positionObject, $.$$.S.String)), startIndex, ((endIndex - startIndex) | 0)), $.$$.S.Object), $.$$.S.ReadOnlyMemory$$(T));
                    }
                    else 
                    {
                        $.$$.SD.Debug.Assert$4(type === 2/*SequenceType.MemoryManager*/, "type == SequenceType.MemoryManager");
                        $.$$.SD.Debug.Assert$4($.$is(positionObject, $.$$.SB.MemoryManager$$(T)), "positionObject is MemoryManager<T>");
                        memory.$v = $.$$.S.Memory$$(T).op_Implicit(($.$cast(positionObject, $.$$.SB.MemoryManager$$(T))).Memory.Slice(startIndex, ((endIndex - startIndex) | 0)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(296353267720)
            
            //--TRIMMABLE-BOUNDARY-START(146029412360)
            /*ReadOnlyMemory<T> */ GetFirstBuffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029412360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let startObject = this._startObject;
                if (startObject === null)
                {
                    return new ($.$$.S.ReadOnlyMemory$$(T))();
                }
                /*int*/ let startIndex = this._startInteger;
                /*int*/ let endIndex = this._endInteger;
                /*bool*/ let isMultiSegment = startObject !== this._endObject;
                if ((startIndex | endIndex) >= 0)
                {
                    /*ReadOnlyMemory<T>*/ let memory = ($.$cast(startObject, $.$sm.SB.ReadOnlySequenceSegment$$(T))).Memory;
                    if (isMultiSegment)
                    {
                        return memory.Slice$1(startIndex);
                    }
                    return memory.Slice(startIndex, ((endIndex - startIndex) | 0));
                }
                else 
                {
                    return this.GetFirstBufferSlow(startObject, isMultiSegment);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029412360)
            
            //--TRIMMABLE-BOUNDARY-START(150324379656)
            /*ReadOnlyMemory<T> */ GetFirstBufferSlow(/*object*/ startObject, /*bool*/ isMultiSegment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324379656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (isMultiSegment)
                {
                    $.$sm.S.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                }
                /*int*/ let startIndex = this._startInteger;
                /*int*/ let endIndex = this._endInteger;
                $.$$.SD.Debug.Assert$4(startIndex < 0 || endIndex < 0, "startIndex < 0 || endIndex < 0");
                if (startIndex >= 0)
                {
                    $.$$.SD.Debug.Assert$4(endIndex < 0, "endIndex < 0");
                    return new ($.$$.S.ReadOnlyMemory$$(T))().$ctor$4($.$cast(startObject, $.$typeArray(T)), startIndex, (((endIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/) - startIndex) | 0));
                }
                else 
                {
                    if (T.$type === $.$$.S.Char.$type && endIndex < 0)
                    {
                        return $.$cast($.$cast($.$$.S.MemoryExtensions.AsMemory$1(($.$cast(startObject, $.$$.S.String)), startIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/, ((endIndex - startIndex) | 0)), $.$$.S.Object), $.$$.S.ReadOnlyMemory$$(T));
                    }
                    else 
                    {
                        startIndex &= 2147483647/*ReadOnlySequence.IndexBitMask*/;
                        return $.$$.S.Memory$$(T).op_Implicit(($.$cast(startObject, $.$$.SB.MemoryManager$$(T))).Memory.Slice(startIndex, ((endIndex - startIndex) | 0)));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324379656)
            
            //--TRIMMABLE-BOUNDARY-START(154619346952)
            /*ReadOnlySpan<T> */ GetFirstSpan()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619346952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let startObject = this._startObject;
                if (startObject === null)
                {
                    return new ($.$$.S.ReadOnlySpan$$(T))();
                }
                /*int*/ let startIndex = this._startInteger;
                /*int*/ let endIndex = this._endInteger;
                /*bool*/ let isMultiSegment = startObject !== this._endObject;
                if ((startIndex | endIndex) >= 0)
                {
                    /*ReadOnlySpan<T>*/ let span = ($.$cast(startObject, $.$sm.SB.ReadOnlySequenceSegment$$(T))).Memory.Span;
                    if (isMultiSegment)
                    {
                        return span.Slice$1(startIndex);
                    }
                    return span.Slice(startIndex, ((endIndex - startIndex) | 0));
                }
                else 
                {
                    return this.GetFirstSpanSlow(startObject, isMultiSegment);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619346952)
            
            //--TRIMMABLE-BOUNDARY-START(163209281544)
            /*ReadOnlySpan<T> */ GetFirstSpanSlow(/*object*/ startObject, /*bool*/ isMultiSegment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209281544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (isMultiSegment)
                {
                    $.$sm.S.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                }
                /*int*/ let startIndex = this._startInteger;
                /*int*/ let endIndex = this._endInteger;
                $.$$.SD.Debug.Assert$4(startIndex < 0 || endIndex < 0, "startIndex < 0 || endIndex < 0");
                if (startIndex >= 0)
                {
                    $.$$.SD.Debug.Assert$4(endIndex < 0, "endIndex < 0");
                    /*ReadOnlySpan<T>*/ let span = $.$$.S.ReadOnlySpan$$(T).op_Implicit$1($.$cast(startObject, $.$typeArray(T)));
                    return span.Slice(startIndex, (((endIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/) - startIndex) | 0));
                }
                else 
                {
                    if (T.$type === $.$$.S.Char.$type && endIndex < 0)
                    {
                        /*var*/ let memory = $.$cast($.$cast($.$$.S.MemoryExtensions.AsMemory$4(($.$cast(startObject, $.$$.S.String))), $.$$.S.Object), $.$$.S.ReadOnlyMemory$$(T));
                        return memory.Span.Slice(startIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/, ((endIndex - startIndex) | 0));
                    }
                    else 
                    {
                        startIndex &= 2147483647/*ReadOnlySequence.IndexBitMask*/;
                        return $.$$.S.Span$$(T).op_Implicit(($.$cast(startObject, $.$$.SB.MemoryManager$$(T))).Memory.Span.Slice(startIndex, ((endIndex - startIndex) | 0)));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209281544)
            
            //--TRIMMABLE-BOUNDARY-START(223338823688)
            /*SequencePosition */ Seek$1(/*long*/ offset, /*ExceptionArgument*/ exceptionArgument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338823688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let startObject;
                /*object?*/ let endObject;
                /*int*/ let startIndex;
                /*int*/ let endIndex;
                let $gotoJumpState18 = 0;
                $gotoJumpStart18: while(true)
                {
                    switch($gotoJumpState18)
                    {
                        case 0:
                        {
                            startObject = this._startObject;
                            endObject = this._endObject;
                            startIndex = $.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                            endIndex = $.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                            if (startObject !== endObject)
                            {
                                $.$$.SD.Debug.Assert$4(startObject !== null, "startObject != null");
                                /*var*/ var startSegment = $.$cast(startObject, $.$sm.SB.ReadOnlySequenceSegment$$(T));
                                /*int*/ var currentLength = ((startSegment.Memory.Length - startIndex) | 0);
                                if (BigInt(currentLength) > offset || offset === 0n)
                                {
                                    $gotoJumpState18 = 1; /*goto IsSingleSegment*/
                                    continue $gotoJumpStart18;
                                }
                                if (currentLength < 0)
                                {
                                    $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                return $.$sm.SB.ReadOnlySequence$$(T).SeekMultiSegment(startSegment.Next, endObject, endIndex, BigInt.asIntN(64, offset - BigInt(currentLength)), exceptionArgument);
                            }
                            $.$$.SD.Debug.Assert$4(startObject === endObject, "startObject == endObject");
                            if (BigInt(endIndex - startIndex) < offset)
                            {
                                $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException(exceptionArgument);
                            }
                        }
                        case 1: /*IsSingleSegment*/
                        return new $.$sm.S.SequencePosition().$ctor$3(startObject, ((startIndex + $.$cast(offset, $.$$.S.Int32)) | 0));
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223338823688)
            
            //--TRIMMABLE-BOUNDARY-START(219043856392)
            /*SequencePosition */ Seek(/*in SequencePosition*/ start, /*long*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043856392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let startObject;
                /*object?*/ let endObject;
                /*int*/ let startIndex;
                /*int*/ let endIndex;
                let $gotoJumpState19 = 0;
                $gotoJumpStart19: while(true)
                {
                    switch($gotoJumpState19)
                    {
                        case 0:
                        {
                            startObject = start.$v.GetObject();
                            endObject = this._endObject;
                            startIndex = start.$v.GetInteger();
                            endIndex = $.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                            if (startObject !== endObject)
                            {
                                $.$$.SD.Debug.Assert$4(startObject !== null, "startObject != null");
                                /*var*/ var startSegment = $.$cast(startObject, $.$sm.SB.ReadOnlySequenceSegment$$(T));
                                /*int*/ var currentLength = ((startSegment.Memory.Length - startIndex) | 0);
                                if (BigInt(currentLength) > offset)
                                {
                                    $gotoJumpState19 = 1; /*goto IsSingleSegment*/
                                    continue $gotoJumpStart19;
                                }
                                if (currentLength < 0)
                                {
                                    $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                return $.$sm.SB.ReadOnlySequence$$(T).SeekMultiSegment(startSegment.Next, endObject, endIndex, BigInt.asIntN(64, offset - BigInt(currentLength)), 7/*ExceptionArgument.offset*/);
                            }
                            $.$$.SD.Debug.Assert$4(startObject === endObject, "startObject == endObject");
                            if (BigInt(endIndex - startIndex) < offset)
                            {
                                $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException(7/*ExceptionArgument.offset*/);
                            }
                        }
                        case 1: /*IsSingleSegment*/
                        return new $.$sm.S.SequencePosition().$ctor$3(startObject, ((startIndex + $.$cast(offset, $.$$.S.Int32)) | 0));
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219043856392)
            
            //--TRIMMABLE-BOUNDARY-START(227633790984)
            static /*SequencePosition */ SeekMultiSegment(/*ReadOnlySequenceSegment<T>?*/ currentSegment, /*object*/ endObject, /*int*/ endIndex, /*long*/ offset, /*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633790984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $gotoJumpState20 = 0;
                $gotoJumpStart20: while(true)
                {
                    switch($gotoJumpState20)
                    {
                        case 0:
                        {
                            $.$$.SD.Debug.Assert$4(currentSegment !== null, "currentSegment != null");
                            $.$$.SD.Debug.Assert$4(offset >= 0n, "offset >= 0");
                            while(currentSegment !== null && currentSegment !== endObject)
                            {
                                /*int*/ var memoryLength = currentSegment.Memory.Length;
                                if (BigInt(memoryLength) > offset)
                                {
                                    $gotoJumpState20 = 1; /*goto FoundSegment*/
                                    continue $gotoJumpStart20;
                                }
                                offset -= BigInt(memoryLength);
                                currentSegment = currentSegment.Next;
                            }
                            if (currentSegment === null || BigInt(endIndex) < offset)
                            {
                                $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException(argument);
                            }
                        }
                        case 1: /*FoundSegment*/
                        return new $.$sm.S.SequencePosition().$ctor$3(currentSegment, $.$cast(offset, $.$$.S.Int32));
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227633790984)
            
            //--TRIMMABLE-BOUNDARY-START(51540131848)
            /*void */ BoundsCheck(/*in SequencePosition*/ position, /*bool*/ positionIsNotNull)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540131848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let sliceStartIndex = (position.$v.GetInteger() >>> 0);
                /*object?*/ let startObject = this._startObject;
                /*object?*/ let endObject = this._endObject;
                /*uint*/ let startIndex = ($.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._startInteger) >>> 0);
                /*uint*/ let endIndex = ($.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._endInteger) >>> 0);
                if (startObject === endObject)
                {
                    if (!$.$sm.SB.ReadOnlySequence$$(T).InRange(sliceStartIndex, startIndex, endIndex))
                    {
                        $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                }
                else 
                {
                    /*ulong*/ let startRange = $.$cast((BigInt.asIntN(64, ($.$cast(startObject, $.$sm.SB.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(startIndex))), $.$$.S.UInt64);
                    /*long*/ let runningIndex = 0n;
                    if (positionIsNotNull)
                    {
                        $.$$.SD.Debug.Assert$4(position.$v.GetObject() !== null, "position.GetObject() != null");
                        runningIndex = ($.$cast(position.$v.GetObject(), $.$sm.SB.ReadOnlySequenceSegment$$(T))).RunningIndex;
                    }
                    if (!$.$sm.SB.ReadOnlySequence$$(T).InRange$1($.$cast((BigInt.asIntN(64, runningIndex + BigInt(sliceStartIndex))), $.$$.S.UInt64), startRange, $.$cast((BigInt.asIntN(64, ($.$cast(endObject, $.$sm.SB.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(endIndex))), $.$$.S.UInt64)))
                    {
                        $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540131848)
            
            //--TRIMMABLE-BOUNDARY-START(55835099144)
            /*void */ BoundsCheck$1(/*uint*/ sliceStartIndex, /*object?*/ sliceStartObject, /*uint*/ sliceEndIndex, /*object?*/ sliceEndObject)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835099144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let startObject = this._startObject;
                /*object?*/ let endObject = this._endObject;
                /*uint*/ let startIndex = ($.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._startInteger) >>> 0);
                /*uint*/ let endIndex = ($.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._endInteger) >>> 0);
                if (startObject === endObject)
                {
                    if (sliceStartObject !== sliceEndObject || sliceStartObject !== startObject || sliceStartIndex > sliceEndIndex || sliceStartIndex < startIndex || sliceEndIndex > endIndex)
                    {
                        $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                }
                else 
                {
                    $.$$.SD.Debug.Assert$4(sliceStartIndex >= 0 && startIndex >= 0 && endIndex >= 0, "sliceStartIndex >= 0 && startIndex >= 0 && endIndex >= 0");
                    /*ulong*/ let sliceStartRange = BigInt(sliceStartIndex);
                    /*ulong*/ let sliceEndRange = BigInt(sliceEndIndex);
                    if (sliceStartObject !== null)
                    {
                        sliceStartRange += $.$cast(($.$cast(sliceStartObject, $.$sm.SB.ReadOnlySequenceSegment$$(T))).RunningIndex, $.$$.S.UInt64);
                    }
                    if (sliceEndObject !== null)
                    {
                        sliceEndRange += $.$cast(($.$cast(sliceEndObject, $.$sm.SB.ReadOnlySequenceSegment$$(T))).RunningIndex, $.$$.S.UInt64);
                    }
                    if (sliceStartRange > sliceEndRange)
                    {
                        $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                    if (sliceStartRange < $.$cast((BigInt.asIntN(64, ($.$cast(startObject, $.$sm.SB.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(startIndex))), $.$$.S.UInt64) || sliceEndRange > $.$cast((BigInt.asIntN(64, ($.$cast(endObject, $.$sm.SB.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(endIndex))), $.$$.S.UInt64))
                    {
                        $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835099144)
            
            //--TRIMMABLE-BOUNDARY-START(137439477768)
            static /*SequencePosition */ GetEndPosition(/*ReadOnlySequenceSegment<T>*/ startSegment, /*object*/ startObject, /*int*/ startIndex, /*object*/ endObject, /*int*/ endIndex, /*long*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439477768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let currentLength = ((startSegment.Memory.Length - startIndex) | 0);
                if (BigInt(currentLength) > length)
                {
                    return new $.$sm.S.SequencePosition().$ctor$3(startObject, ((startIndex + $.$cast(length, $.$$.S.Int32)) | 0));
                }
                if (currentLength < 0)
                {
                    $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                }
                return $.$sm.SB.ReadOnlySequence$$(T).SeekMultiSegment(startSegment.Next, endObject, endIndex, BigInt.asIntN(64, length - BigInt(currentLength)), 0/*ExceptionArgument.length*/);
            }
            //--TRIMMABLE-BOUNDARY-END(137439477768)
            
            //--TRIMMABLE-BOUNDARY-START(193274052616)
            /*SequenceType */ GetSequenceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274052616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast((-(((((2 * (this._startInteger >> 31)) | 0) + (this._endInteger >> 31)) | 0))), $.$sm.SB.ReadOnlySequence$$(T).SequenceType);
            }
            //--TRIMMABLE-BOUNDARY-END(193274052616)
            
            //--TRIMMABLE-BOUNDARY-START(171799216136)
            static /*int */ GetIndex(/*int*/ Integer)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(171799216136);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Integer & 2147483647/*ReadOnlySequence.IndexBitMask*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171799216136)
            
            //--TRIMMABLE-BOUNDARY-START(270583463944)
            /*ReadOnlySequence<T> */ SliceImpl(/*in SequencePosition*/ start, /*in SequencePosition*/ end)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583463944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$sm.SB.ReadOnlySequence$$(T))().$ctor$4(start.$v.GetObject(), start.$v.GetInteger() | (this._startInteger & -2147483648/*ReadOnlySequence.FlagBitMask*/), end.$v.GetObject(), end.$v.GetInteger() | (this._endInteger & -2147483648/*ReadOnlySequence.FlagBitMask*/));
            }
            //--TRIMMABLE-BOUNDARY-END(270583463944)
            
            //--TRIMMABLE-BOUNDARY-START(274878431240)
            /*ReadOnlySequence<T> */ SliceImpl$1(/*in SequencePosition*/ start)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878431240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$sm.SB.ReadOnlySequence$$(T))().$ctor$4(start.$v.GetObject(), start.$v.GetInteger() | (this._startInteger & -2147483648/*ReadOnlySequence.FlagBitMask*/), this._endObject, this._endInteger);
            }
            //--TRIMMABLE-BOUNDARY-END(274878431240)
            
            //--TRIMMABLE-BOUNDARY-START(176094183432)
            /*long */ GetLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094183432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let startObject = this._startObject;
                /*object?*/ let endObject = this._endObject;
                /*int*/ let startIndex = $.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                /*int*/ let endIndex = $.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                if (startObject !== endObject)
                {
                    /*var*/ let startSegment = $.$cast(startObject, $.$sm.SB.ReadOnlySequenceSegment$$(T));
                    /*var*/ let endSegment = $.$cast(endObject, $.$sm.SB.ReadOnlySequenceSegment$$(T));
                    return BigInt.asIntN(64, (BigInt.asIntN(64, endSegment.RunningIndex + BigInt(endIndex))) - (BigInt.asIntN(64, startSegment.RunningIndex + BigInt(startIndex))));
                }
                return BigInt(endIndex - startIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(176094183432)
            
            //--TRIMMABLE-BOUNDARY-START(300648235016)
            /*bool */ TryGetReadOnlySequenceSegment(/*out ReadOnlySequenceSegment<T>?*/ startSegment, /*out int*/ startIndex, /*out ReadOnlySequenceSegment<T>?*/ endSegment, /*out int*/ endIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648235016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let startObject = this._startObject;
                if (startObject === null || this.GetSequenceType() !== 0/*SequenceType.MultiSegment*/)
                {
                    startSegment.$v = null;
                    startIndex.$v = 0;
                    endSegment.$v = null;
                    endIndex.$v = 0;
                    return false;
                }
                $.$$.SD.Debug.Assert$4(this._endObject !== null, "_endObject != null");
                startSegment.$v = $.$cast(startObject, $.$sm.SB.ReadOnlySequenceSegment$$(T));
                startIndex.$v = $.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                endSegment.$v = $.$cast(this._endObject, $.$sm.SB.ReadOnlySequenceSegment$$(T));
                endIndex.$v = $.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(300648235016)
            
            //--TRIMMABLE-BOUNDARY-START(292058300424)
            /*bool */ TryGetArray(/*out ArraySegment<T>*/ segment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058300424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.GetSequenceType() !== 1/*SequenceType.Array*/)
                {
                    segment.$v = new ($.$$.S.ArraySegment$$(T))();
                    return false;
                }
                $.$$.SD.Debug.Assert$4(this._startObject !== null, "_startObject != null");
                /*int*/ let startIndex = $.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                segment.$v = new ($.$$.S.ArraySegment$$(T))().$ctor$3($.$cast(this._startObject, $.$typeArray(T)), startIndex, (($.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._endInteger) - startIndex) | 0));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(292058300424)
            
            //--TRIMMABLE-BOUNDARY-START(304943202312)
            /*bool */ TryGetString(/*out string?*/ text, /*out int*/ start, /*out int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943202312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (T.$type !== $.$$.S.Char.$type || this.GetSequenceType() !== 3/*SequenceType.String*/)
                {
                    start.$v = 0;
                    length.$v = 0;
                    text.$v = null;
                    return false;
                }
                $.$$.SD.Debug.Assert$4(this._startObject !== null, "_startObject != null");
                start.$v = $.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                length.$v = (($.$sm.SB.ReadOnlySequence$$(T).GetIndex(this._endInteger) - start.$v) | 0);
                text.$v = $.$cast(this._startObject, $.$$.S.String);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(304943202312)
            
            //--TRIMMABLE-BOUNDARY-START(197569019912)
            static /*bool */ InRange(/*uint*/ value, /*uint*/ start, /*uint*/ end)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569019912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(start <= 2147483647/*int.MaxValue*/, "start <= int.MaxValue");
                $.$$.SD.Debug.Assert$4(end <= 2147483647/*int.MaxValue*/, "end <= int.MaxValue");
                $.$$.SD.Debug.Assert$4(start <= end, "start <= end");
                return ((((value - start) >>> 0)) >>> 0) <= ((((end - start) >>> 0)) >>> 0);
            }
            //--TRIMMABLE-BOUNDARY-END(197569019912)
            
            //--TRIMMABLE-BOUNDARY-START(201863987208)
            static /*bool */ InRange$1(/*ulong*/ value, /*ulong*/ start, /*ulong*/ end)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863987208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(start <= 9223372036854775807n, "start <= long.MaxValue");
                $.$$.SD.Debug.Assert$4(end <= 9223372036854775807n, "end <= long.MaxValue");
                $.$$.SD.Debug.Assert$4(start <= end, "start <= end");
                return (BigInt.asUintN(64, value - start)) <= (BigInt.asUintN(64, end - start));
            }
            //--TRIMMABLE-BOUNDARY-END(201863987208)
            
            //--TRIMMABLE-BOUNDARY-START(158914314248)
            /*void */ GetFirstSpan$1(/*out ReadOnlySpan<T>*/ first, /*out SequencePosition*/ next)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914314248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                first.$v = new ($.$$.S.ReadOnlySpan$$(T))();
                next.$v = new $.$sm.S.SequencePosition();
                /*object?*/ let startObject = this._startObject;
                /*int*/ let startIndex = this._startInteger;
                if (startObject !== null)
                {
                    /*bool*/ let hasMultipleSegments = startObject !== this._endObject;
                    /*int*/ let endIndex = this._endInteger;
                    if (startIndex >= 0)
                    {
                        if (endIndex >= 0)
                        {
                            /*ReadOnlySequenceSegment<T>*/ let segment = $.$cast(startObject, $.$sm.SB.ReadOnlySequenceSegment$$(T));
                            first.$v = segment.Memory.Span;
                            if (hasMultipleSegments)
                            {
                                first.$v = first.$v.Slice$1(startIndex);
                                next.$v = new $.$sm.S.SequencePosition().$ctor$3(segment.Next, 0);
                            }
                            else 
                            {
                                first.$v = first.$v.Slice(startIndex, ((endIndex - startIndex) | 0));
                            }
                        }
                        else 
                        {
                            if (hasMultipleSegments)
                            {
                                $.$sm.S.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                            }
                            first.$v = new ($.$$.S.ReadOnlySpan$$(T))().$ctor$6($.$cast(startObject, $.$typeArray(T)), startIndex, (((endIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/) - startIndex) | 0));
                        }
                    }
                    else 
                    {
                        first.$v = $.$sm.SB.ReadOnlySequence$$(T).GetFirstSpanSlow$1(startObject, startIndex, endIndex, hasMultipleSegments);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914314248)
            
            //--TRIMMABLE-BOUNDARY-START(167504248840)
            static /*ReadOnlySpan<T> */ GetFirstSpanSlow$1(/*object*/ startObject, /*int*/ startIndex, /*int*/ endIndex, /*bool*/ hasMultipleSegments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504248840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.SD.Debug.Assert$4(startIndex < 0, "startIndex < 0");
                if (hasMultipleSegments)
                {
                    $.$sm.S.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                }
                if (T.$type === $.$$.S.Char.$type && endIndex < 0)
                {
                    /*ReadOnlySpan<char>*/ let spanOfChar = $.$$.S.MemoryExtensions.AsSpan$1(($.$cast(startObject, $.$$.S.String)), startIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/, ((endIndex - startIndex) | 0));
                    return $.$$.SRI.MemoryMarshal.CreateReadOnlySpan(T, $.$$.SRC.Unsafe.As($.$$.S.Char, T, $.$$.SRI.MemoryMarshal.GetReference($.$$.S.Char, spanOfChar)), spanOfChar.Length);
                }
                else 
                {
                    startIndex &= 2147483647/*ReadOnlySequence.IndexBitMask*/;
                    return $.$$.S.Span$$(T).op_Implicit(($.$cast(startObject, $.$$.SB.MemoryManager$$(T))).Memory.Span.Slice(startIndex, ((endIndex - startIndex) | 0)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167504248840)
            
            //--TRIMMABLE-BOUNDARY-START(25770328072)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770328072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770328072)
            
            //--TRIMMABLE-BOUNDARY-START(25770328072)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(25770328072)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._startObject = this._startObject;
                copy._endObject = this._endObject;
                copy._startInteger = this._startInteger;
                copy._endInteger = this._endInteger;
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(21475360776)
            //Static Initializer
            static $sinit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360776);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                {
                    //--TRIMMABLE-BOUNDARY-START(60130066440)
                    this.Empty = new ($.$sm.SB.ReadOnlySequence$$(T))().$ctor$7($.$$.S.Array.Empty(T));
                    //--TRIMMABLE-BOUNDARY-END(60130066440)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475360776)
            
            static $H = 524296;
            static $h = 524296;
            static $g = 1;
            static $z = 16;
            static $f = 0b1011000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(214748889096),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "H": 124554575880,
        "h": Number(BigInt(this.$h)|0x1D00000000n),
        "f": 50331649
      },
      "n": "Length",
      "d": this.$h,
      "H": 214748889096,
      "h": Number(BigInt(this.$h)|0x3200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214748889096),
//--TRIMMABLE-BOUNDARY-START(206158954504),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 107374706696,
        "h": Number(BigInt(this.$h)|0x1900000000n),
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": this.$h,
      "H": 206158954504,
      "h": Number(BigInt(this.$h)|0x3000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206158954504),
//--TRIMMABLE-BOUNDARY-START(210453921800),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "H": 115964641288,
        "h": Number(BigInt(this.$h)|0x1B00000000n),
        "f": 50331649
      },
      "n": "IsSingleSegment",
      "d": this.$h,
      "H": 210453921800,
      "h": Number(BigInt(this.$h)|0x3100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210453921800),
//--TRIMMABLE-BOUNDARY-START(68720001032),
    {
      "p": $.$$.S.ReadOnlyMemory$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 90194837512,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "n": "First",
      "d": this.$h,
      "H": 68720001032,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720001032),
//--TRIMMABLE-BOUNDARY-START(73014968328),
    {
      "p": $.$$.S.ReadOnlySpan$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 98784772104,
        "h": Number(BigInt(this.$h)|0x1700000000n),
        "f": 50331649
      },
      "n": "FirstSpan",
      "d": this.$h,
      "H": 73014968328,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014968328),
//--TRIMMABLE-BOUNDARY-START(279173398536),
    {
      "p": 1179656,
      "g": {
        "r": 0,
        "d": 0,
        "H": 133144510472,
        "h": Number(BigInt(this.$h)|0x1F00000000n),
        "f": 50331649
      },
      "n": "Start",
      "d": this.$h,
      "H": 279173398536,
      "h": Number(BigInt(this.$h)|0x4100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279173398536),
//--TRIMMABLE-BOUNDARY-START(64425033736),
    {
      "p": 1179656,
      "g": {
        "r": 0,
        "d": 0,
        "H": 81604902920,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "n": "End",
      "d": this.$h,
      "H": 64425033736,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425033736)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(240518692872),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 917505
        },
        {
          "n": "length",
          "p": 917505
        }
      ],
      "n": "Slice",
      "o": "@$2",
      "d": this.$h,
      "H": 240518692872,
      "h": Number(BigInt(this.$h)|0x3800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(240518692872),
//--TRIMMABLE-BOUNDARY-START(244813660168),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 917505
        },
        {
          "n": "end",
          "p": 1179656
        }
      ],
      "n": "Slice",
      "o": "@$3",
      "d": this.$h,
      "H": 244813660168,
      "h": Number(BigInt(this.$h)|0x3900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(244813660168),
//--TRIMMABLE-BOUNDARY-START(257698562056),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 1179656
        },
        {
          "n": "length",
          "p": 917505
        }
      ],
      "n": "Slice",
      "o": "@$6",
      "d": this.$h,
      "H": 257698562056,
      "h": Number(BigInt(this.$h)|0x3C00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(257698562056),
//--TRIMMABLE-BOUNDARY-START(231928758280),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "Slice",
      "d": this.$h,
      "H": 231928758280,
      "h": Number(BigInt(this.$h)|0x3600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(231928758280),
//--TRIMMABLE-BOUNDARY-START(236223725576),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 1179656
        }
      ],
      "n": "Slice",
      "o": "@$1",
      "d": this.$h,
      "H": 236223725576,
      "h": Number(BigInt(this.$h)|0x3700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(236223725576),
//--TRIMMABLE-BOUNDARY-START(253403594760),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 1179656
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "Slice",
      "o": "@$5",
      "d": this.$h,
      "H": 253403594760,
      "h": Number(BigInt(this.$h)|0x3B00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(253403594760),
//--TRIMMABLE-BOUNDARY-START(261993529352),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 1179656
        },
        {
          "n": "end",
          "p": 1179656
        }
      ],
      "n": "Slice",
      "o": "@$7",
      "d": this.$h,
      "H": 261993529352,
      "h": Number(BigInt(this.$h)|0x3D00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(261993529352),
//--TRIMMABLE-BOUNDARY-START(266288496648),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 1179656
        }
      ],
      "n": "Slice",
      "o": "@$8",
      "d": this.$h,
      "H": 266288496648,
      "h": Number(BigInt(this.$h)|0x3E00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(266288496648),
//--TRIMMABLE-BOUNDARY-START(249108627464),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 917505
        }
      ],
      "n": "Slice",
      "o": "@$4",
      "d": this.$h,
      "H": 249108627464,
      "h": Number(BigInt(this.$h)|0x3A00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(249108627464),
//--TRIMMABLE-BOUNDARY-START(283468365832),
    {
      "r": 1310721,
      "n": "ToString",
      "d": this.$h,
      "H": 283468365832,
      "h": Number(BigInt(this.$h)|0x4200000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(283468365832),
//--TRIMMABLE-BOUNDARY-START(141734445064),
    {
      "r": 589832,
      "n": "GetEnumerator",
      "d": this.$h,
      "H": 141734445064,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(141734445064),
//--TRIMMABLE-BOUNDARY-START(188979085320),
    {
      "r": 1179656,
      "p": [
        {
          "n": "offset",
          "p": 917505
        }
      ],
      "n": "GetPosition",
      "o": "@$1",
      "d": this.$h,
      "H": 188979085320,
      "h": Number(BigInt(this.$h)|0x2C00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188979085320),
//--TRIMMABLE-BOUNDARY-START(180389150728),
    {
      "r": 917505,
      "p": [
        {
          "n": "position",
          "p": 1179656
        }
      ],
      "n": "GetOffset",
      "d": this.$h,
      "H": 180389150728,
      "h": Number(BigInt(this.$h)|0x2A00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(180389150728),
//--TRIMMABLE-BOUNDARY-START(184684118024),
    {
      "r": 1179656,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 1179656
        }
      ],
      "n": "GetPosition",
      "d": this.$h,
      "H": 184684118024,
      "h": Number(BigInt(this.$h)|0x2B00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684118024),
//--TRIMMABLE-BOUNDARY-START(287763333128),
    {
      "r": 262145,
      "p": [
        {
          "n": "position",
          "p": 1179656,
          "f": 4
        },
        {
          "n": "memory",
          "p": $.$$.S.ReadOnlyMemory$$(T).$h,
          "f": 2
        },
        {
          "n": "advance",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryGet",
      "d": this.$h,
      "H": 287763333128,
      "h": Number(BigInt(this.$h)|0x4300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(287763333128),
//--TRIMMABLE-BOUNDARY-START(296353267720),
    {
      "r": 262145,
      "p": [
        {
          "n": "position",
          "p": 1179656,
          "f": 8
        },
        {
          "n": "memory",
          "p": $.$$.S.ReadOnlyMemory$$(T).$h,
          "f": 2
        },
        {
          "n": "next",
          "p": 1179656,
          "f": 2
        }
      ],
      "n": "TryGetBuffer",
      "d": this.$h,
      "H": 296353267720,
      "h": Number(BigInt(this.$h)|0x4500000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(296353267720),
//--TRIMMABLE-BOUNDARY-START(146029412360),
    {
      "r": $.$$.S.ReadOnlyMemory$$(T).$h,
      "n": "GetFirstBuffer",
      "d": this.$h,
      "H": 146029412360,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(146029412360),
//--TRIMMABLE-BOUNDARY-START(150324379656),
    {
      "r": $.$$.S.ReadOnlyMemory$$(T).$h,
      "p": [
        {
          "n": "startObject",
          "p": 131073
        },
        {
          "n": "isMultiSegment",
          "p": 262145
        }
      ],
      "n": "GetFirstBufferSlow",
      "d": this.$h,
      "H": 150324379656,
      "h": Number(BigInt(this.$h)|0x2300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(150324379656),
//--TRIMMABLE-BOUNDARY-START(154619346952),
    {
      "r": $.$$.S.ReadOnlySpan$$(T).$h,
      "n": "GetFirstSpan",
      "d": this.$h,
      "H": 154619346952,
      "h": Number(BigInt(this.$h)|0x2400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(154619346952),
//--TRIMMABLE-BOUNDARY-START(163209281544),
    {
      "r": $.$$.S.ReadOnlySpan$$(T).$h,
      "p": [
        {
          "n": "startObject",
          "p": 131073
        },
        {
          "n": "isMultiSegment",
          "p": 262145
        }
      ],
      "n": "GetFirstSpanSlow",
      "d": this.$h,
      "H": 163209281544,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(163209281544),
//--TRIMMABLE-BOUNDARY-START(223338823688),
    {
      "r": 1179656,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "exceptionArgument",
          "p": 1048584,
          "f": 65,
          "v": 7
        }
      ],
      "n": "Seek",
      "o": "@$1",
      "d": this.$h,
      "H": 223338823688,
      "h": Number(BigInt(this.$h)|0x3400000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(223338823688),
//--TRIMMABLE-BOUNDARY-START(219043856392),
    {
      "r": 1179656,
      "p": [
        {
          "n": "start",
          "p": 1179656,
          "f": 8
        },
        {
          "n": "offset",
          "p": 917505
        }
      ],
      "n": "Seek",
      "d": this.$h,
      "H": 219043856392,
      "h": Number(BigInt(this.$h)|0x3300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(219043856392),
//--TRIMMABLE-BOUNDARY-START(227633790984),
    {
      "r": 1179656,
      "p": [
        {
          "n": "currentSegment",
          "p": $.$sm.SB.ReadOnlySequenceSegment$$(T).$h
        },
        {
          "n": "endObject",
          "p": 131073
        },
        {
          "n": "endIndex",
          "p": 655361
        },
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "argument",
          "p": 1048584
        }
      ],
      "n": "SeekMultiSegment",
      "d": this.$h,
      "H": 227633790984,
      "h": Number(BigInt(this.$h)|0x3500000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(227633790984),
//--TRIMMABLE-BOUNDARY-START(51540131848),
    {
      "r": 65537,
      "p": [
        {
          "n": "position",
          "p": 1179656,
          "f": 8
        },
        {
          "n": "positionIsNotNull",
          "p": 262145
        }
      ],
      "n": "BoundsCheck",
      "d": this.$h,
      "H": 51540131848,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540131848),
//--TRIMMABLE-BOUNDARY-START(55835099144),
    {
      "r": 65537,
      "p": [
        {
          "n": "sliceStartIndex",
          "p": 720897
        },
        {
          "n": "sliceStartObject",
          "p": 131073
        },
        {
          "n": "sliceEndIndex",
          "p": 720897
        },
        {
          "n": "sliceEndObject",
          "p": 131073
        }
      ],
      "n": "BoundsCheck",
      "o": "@$1",
      "d": this.$h,
      "H": 55835099144,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55835099144),
//--TRIMMABLE-BOUNDARY-START(137439477768),
    {
      "r": 1179656,
      "p": [
        {
          "n": "startSegment",
          "p": $.$sm.SB.ReadOnlySequenceSegment$$(T).$h
        },
        {
          "n": "startObject",
          "p": 131073
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endObject",
          "p": 131073
        },
        {
          "n": "endIndex",
          "p": 655361
        },
        {
          "n": "length",
          "p": 917505
        }
      ],
      "n": "GetEndPosition",
      "d": this.$h,
      "H": 137439477768,
      "h": Number(BigInt(this.$h)|0x2000000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(137439477768),
//--TRIMMABLE-BOUNDARY-START(193274052616),
    {
      "r": 655368,
      "n": "GetSequenceType",
      "d": this.$h,
      "H": 193274052616,
      "h": Number(BigInt(this.$h)|0x2D00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(193274052616),
//--TRIMMABLE-BOUNDARY-START(171799216136),
    {
      "r": 655361,
      "p": [
        {
          "n": "Integer",
          "p": 655361
        }
      ],
      "n": "GetIndex",
      "d": this.$h,
      "H": 171799216136,
      "h": Number(BigInt(this.$h)|0x2800000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(171799216136),
//--TRIMMABLE-BOUNDARY-START(270583463944),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 1179656,
          "f": 8
        },
        {
          "n": "end",
          "p": 1179656,
          "f": 8
        }
      ],
      "n": "SliceImpl",
      "d": this.$h,
      "H": 270583463944,
      "h": Number(BigInt(this.$h)|0x3F00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(270583463944),
//--TRIMMABLE-BOUNDARY-START(274878431240),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 1179656,
          "f": 8
        }
      ],
      "n": "SliceImpl",
      "o": "@$1",
      "d": this.$h,
      "H": 274878431240,
      "h": Number(BigInt(this.$h)|0x4000000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(274878431240),
//--TRIMMABLE-BOUNDARY-START(176094183432),
    {
      "r": 917505,
      "n": "GetLength",
      "d": this.$h,
      "H": 176094183432,
      "h": Number(BigInt(this.$h)|0x2900000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(176094183432),
//--TRIMMABLE-BOUNDARY-START(300648235016),
    {
      "r": 262145,
      "p": [
        {
          "n": "startSegment",
          "p": $.$sm.SB.ReadOnlySequenceSegment$$(T).$h,
          "f": 2
        },
        {
          "n": "startIndex",
          "p": 655361,
          "f": 2
        },
        {
          "n": "endSegment",
          "p": $.$sm.SB.ReadOnlySequenceSegment$$(T).$h,
          "f": 2
        },
        {
          "n": "endIndex",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryGetReadOnlySequenceSegment",
      "d": this.$h,
      "H": 300648235016,
      "h": Number(BigInt(this.$h)|0x4600000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(300648235016),
//--TRIMMABLE-BOUNDARY-START(292058300424),
    {
      "r": 262145,
      "p": [
        {
          "n": "segment",
          "p": $.$$.S.ArraySegment$$(T).$h,
          "f": 2
        }
      ],
      "n": "TryGetArray",
      "d": this.$h,
      "H": 292058300424,
      "h": Number(BigInt(this.$h)|0x4400000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(292058300424),
//--TRIMMABLE-BOUNDARY-START(304943202312),
    {
      "r": 262145,
      "p": [
        {
          "n": "text",
          "p": 1310721,
          "f": 2
        },
        {
          "n": "start",
          "p": 655361,
          "f": 2
        },
        {
          "n": "length",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryGetString",
      "d": this.$h,
      "H": 304943202312,
      "h": Number(BigInt(this.$h)|0x4700000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(304943202312),
//--TRIMMABLE-BOUNDARY-START(197569019912),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 720897
        },
        {
          "n": "start",
          "p": 720897
        },
        {
          "n": "end",
          "p": 720897
        }
      ],
      "n": "InRange",
      "d": this.$h,
      "H": 197569019912,
      "h": Number(BigInt(this.$h)|0x2E00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(197569019912),
//--TRIMMABLE-BOUNDARY-START(201863987208),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 983041
        },
        {
          "n": "start",
          "p": 983041
        },
        {
          "n": "end",
          "p": 983041
        }
      ],
      "n": "InRange",
      "o": "@$1",
      "d": this.$h,
      "H": 201863987208,
      "h": Number(BigInt(this.$h)|0x2F00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(201863987208),
//--TRIMMABLE-BOUNDARY-START(158914314248),
    {
      "r": 65537,
      "p": [
        {
          "n": "first",
          "p": $.$$.S.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "next",
          "p": 1179656,
          "f": 2
        }
      ],
      "n": "GetFirstSpan",
      "o": "@$1",
      "d": this.$h,
      "H": 158914314248,
      "h": Number(BigInt(this.$h)|0x2500000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(158914314248),
//--TRIMMABLE-BOUNDARY-START(167504248840),
    {
      "r": $.$$.S.ReadOnlySpan$$(T).$h,
      "p": [
        {
          "n": "startObject",
          "p": 131073
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        },
        {
          "n": "hasMultipleSegments",
          "p": 262145
        }
      ],
      "n": "GetFirstSpanSlow",
      "o": "@$1",
      "d": this.$h,
      "H": 167504248840,
      "h": Number(BigInt(this.$h)|0x2700000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(167504248840)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180393480),
    {
      "t": 131073,
      "n": "_startObject",
      "d": this.$h,
      "H": 17180393480,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180393480),
//--TRIMMABLE-BOUNDARY-START(8590458888),
    {
      "t": 131073,
      "n": "_endObject",
      "d": this.$h,
      "H": 8590458888,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590458888),
//--TRIMMABLE-BOUNDARY-START(12885426184),
    {
      "t": 655361,
      "n": "_startInteger",
      "d": this.$h,
      "H": 12885426184,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885426184),
//--TRIMMABLE-BOUNDARY-START(4295491592),
    {
      "t": 655361,
      "n": "_endInteger",
      "d": this.$h,
      "H": 4295491592,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491592),
//--TRIMMABLE-BOUNDARY-START(60130066440),
    {
      "t": this.$h,
      "n": "Empty",
      "d": this.$h,
      "H": 60130066440,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130066440)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(34360262664),
    {
      "p": [
        {
          "n": "startSegment",
          "p": 131073
        },
        {
          "n": "startIndexAndFlags",
          "p": 655361
        },
        {
          "n": "endSegment",
          "p": 131073
        },
        {
          "n": "endIndexAndFlags",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "H": 34360262664,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360262664),
//--TRIMMABLE-BOUNDARY-START(30065295368),
    {
      "p": [
        {
          "n": "startSegment",
          "p": $.$sm.SB.ReadOnlySequenceSegment$$(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endSegment",
          "p": $.$sm.SB.ReadOnlySequenceSegment$$(T).$h
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "H": 30065295368,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065295368),
//--TRIMMABLE-BOUNDARY-START(47245164552),
    {
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": this.$h,
      "H": 47245164552,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245164552),
//--TRIMMABLE-BOUNDARY-START(42950197256),
    {
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": this.$h,
      "H": 42950197256,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950197256),
//--TRIMMABLE-BOUNDARY-START(38655229960),
    {
      "p": [
        {
          "n": "memory",
          "p": $.$$.S.ReadOnlyMemory$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "H": 38655229960,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655229960),
//--TRIMMABLE-BOUNDARY-START(25770328072),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 25770328072,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770328072)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 524296,
  "h": this.$h,
  "a": [
    {
      "t": 71434241,
      "c": 21546270721,
      "a": [
        {
          "v": 720904,
          "t": 188547073
        }
      ]
    },
    {
      "t": 71106561,
      "c": 25840910337,
      "a": [
        {
          "v": "{ToString(),raw}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sm.SB.ReadOnlySequence$$(T).Enumerator, $.$sm.SB.ReadOnlySequence$$(T).SequenceType ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Buffers.ReadOnlySequence<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Buffers${separator}ReadOnlySequence$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(524296)
        
        

        //--TRIMMABLE-BOUNDARY-START(131080)
        $asm.$cls(`$sm.SB.ArrayMemoryPool<>`, (T) => $asm.$gt(`$sm.SB.ArrayMemoryPool<>`, [T], ($self) => class ArrayMemoryPool$$ extends $.$sm.SB.MemoryPool$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(21474967560)
            /*int */ get MaxBufferSize()
            {
                return $.$$.S.Array.MaxLength;
            }
            //--TRIMMABLE-BOUNDARY-END(21474967560)
            
            //--TRIMMABLE-BOUNDARY-START(25769934856)
            /*IMemoryOwner<T> */ Rent(/*int*/ minimumBufferSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (minimumBufferSize === -1)
                {
                    minimumBufferSize = ((1 + ($.trunc(4095 / (T.$z??4)))) | 0);
                }
                else if (BigInt((minimumBufferSize >>> 0)) > BigInt($.$$.S.Array.MaxLength))
                {
                    $.$sm.S.ThrowHelper.ThrowArgumentOutOfRangeException(2/*ExceptionArgument.minimumBufferSize*/);
                }
                return new ($.$sm.SB.ArrayMemoryPool$$(T).ArrayMemoryPoolBuffer)().$ctor$1(minimumBufferSize);
            }
            //--TRIMMABLE-BOUNDARY-END(25769934856)
            
            //--TRIMMABLE-BOUNDARY-START(8590065672)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065672);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590065672)
            
            //--TRIMMABLE-BOUNDARY-START(196616)
            static $_ArrayMemoryPoolBuffer;
            static get ArrayMemoryPoolBuffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(196616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$sm.SB.ArrayMemoryPool$$(T);
                return $cls.$_ArrayMemoryPoolBuffer ??= $asm.$ncls(`$sm.SB.ArrayMemoryPool<${T?.$fullName}>.ArrayMemoryPoolBuffer`, ($self) => class ArrayMemoryPoolBuffer extends $.$$.S.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4295163912)
                    /*T[]?*/ _array = null;
                    //--TRIMMABLE-BOUNDARY-END(4295163912)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590131208)
                    $ctor$1(/*int*/ size)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590131208);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._array = $.$$.SB.ArrayPool$$(T).Shared.Rent(size);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590131208)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770000392)
                    /*Memory<T> */ get Memory()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475033096);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*T[]?*/ let array = this._array;
                        $.$$.S.ObjectDisposedException.ThrowIf(array === null, this);
                        return new ($.$$.S.Memory$$(T))().$ctor$8(array);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770000392)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885098504)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885098504);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*T[]?*/ let array = this._array;
                        if (array !== null)
                        {
                            this._array = null;
                            $.$$.SB.ArrayPool$$(T).Shared.Return(array, false);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885098504)
                    
                    //--TRIMMABLE-BOUNDARY-START(8639021057)
                    //Generated interface implemetation for System.Buffers.IMemoryOwner<T>.Memory.get
                    get SB$IMemoryOwner$$$Memory()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12933988353);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Memory;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8639021057)
                    
                    //--TRIMMABLE-BOUNDARY-START(4386062337)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    S$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4386062337);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4386062337)
                    
                    static $H = 196616;
                    static $h = 196616;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770000392),
    {
      "p": $.$$.S.Memory$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "H": 21475033096,
        "h": Number(BigInt(196616)|0x500000000n),
        "f": 50331649
      },
      "n": "Memory",
      "d": 196616,
      "H": 25770000392,
      "h": Number(BigInt(196616)|0x600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770000392)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885098504),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 196616,
      "H": 12885098504,
      "h": Number(BigInt(196616)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885098504)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295163912),
    {
      "t": $.$typeArray(T).$h,
      "n": "_array",
      "d": 196616,
      "H": 4295163912,
      "h": Number(BigInt(196616)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295163912)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590131208),
    {
      "p": [
        {
          "n": "size",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196616,
      "H": 8590131208,
      "h": Number(BigInt(196616)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590131208)
  ],
  "d": 131080,
  "H": 196616,
  "h": 196616
}; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.SB.IMemoryOwner$$(T), $.$$.S.IDisposable ]; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Buffers.ArrayMemoryPool<${T?.$fullName}>+ArrayMemoryPoolBuffer`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Buffers${separator}ArrayMemoryPool$${T?.$getFullName(separator)}$${separator}ArrayMemoryPoolBuffer`; }
                }, $cls, ($v) => $cls.$_ArrayMemoryPoolBuffer = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(196616)
            
            //--TRIMMABLE-BOUNDARY-START(4295098376)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098376)
            
            //--TRIMMABLE-BOUNDARY-START(4295098376)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295098376)
            
            static $H = 131080;
            static $h = 131080;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$sm.SB.MemoryPool$$(T); }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21474967560),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "H": 17180000264,
        "h": Number(BigInt(this.$h)|0x400000000n),
        "f": 50429953
      },
      "n": "MaxBufferSize",
      "d": this.$h,
      "H": 21474967560,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 2195457
    },
//--TRIMMABLE-BOUNDARY-END(21474967560)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25769934856),
    {
      "r": $.$$.SB.IMemoryOwner$$(T).$h,
      "p": [
        {
          "n": "minimumBufferSize",
          "p": 655361,
          "f": 65,
          "v": -1
        }
      ],
      "n": "Rent",
      "d": this.$h,
      "H": 25769934856,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16875521
    },
//--TRIMMABLE-BOUNDARY-END(25769934856),
//--TRIMMABLE-BOUNDARY-START(8590065672),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": this.$h,
      "H": 8590065672,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16875524
    },
//--TRIMMABLE-BOUNDARY-END(8590065672)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098376),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "H": 4295098376,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098376)
  ],
  "s": [
    {
      "h": T?.$h??1572864,
      "n": "T"
    }
  ],
  "r": 1,
  "H": 131080,
  "h": this.$h
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$sm.SB.ArrayMemoryPool$$(T).ArrayMemoryPoolBuffer ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Buffers.ArrayMemoryPool<${T?.$fullName}>`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Buffers${separator}ArrayMemoryPool$${T?.$getFullName(separator)}$`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(131080)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179656)
        $asm.$str(`$sm.S.SequencePosition`, ($self) => class SequencePosition extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8591114248)
            /*object?*/ _object = null;
            //--TRIMMABLE-BOUNDARY-END(8591114248)
            
            //--TRIMMABLE-BOUNDARY-START(4296146952)
            /*int*/ _integer = 0;
            //--TRIMMABLE-BOUNDARY-END(4296146952)
            
            //--TRIMMABLE-BOUNDARY-START(17181048840)
            $ctor$3(/*object?*/ object, /*int*/ integer)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181048840);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._object = object;
                    this._integer = integer;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181048840)
            
            //--TRIMMABLE-BOUNDARY-START(38655885320)
            /*object? */ GetObject()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655885320);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._object;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655885320)
            
            //--TRIMMABLE-BOUNDARY-START(34360918024)
            /*int */ GetInteger()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360918024);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._integer;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360918024)
            
            //--TRIMMABLE-BOUNDARY-START(25770983432)
            /*bool */ Equals$2(/*SequencePosition*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770983432);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._integer === other._integer && $.$$.S.Object.Equals(this._object, other._object);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770983432)
            
            //--TRIMMABLE-BOUNDARY-START(21476016136)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476016136);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$sm.S.SequencePosition, { set $v($v){ other = $v; } }) && this.Equals$2(other);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476016136)
            
            //--TRIMMABLE-BOUNDARY-START(30065950728)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065950728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let __ca1__;
                return $.$$.S.HashCode.Combine$6($.$$.S.Int32, $.$$.S.Int32, ((__ca1__ = this._object) !== null ? $.$dspc(__ca1__, $.$$.S.Object, ($t) => $t.GetHashCode) : 0), this._integer);
            }
            //--TRIMMABLE-BOUNDARY-END(30065950728)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<System.SequencePosition>.Equals(System.SequencePosition)
            S$IEquatable$System$SequencePosition$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(12886081544)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886081544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081544)
            
            //--TRIMMABLE-BOUNDARY-START(12886081544)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886081544)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._object = this._object;
                copy._integer = this._integer;
                return copy;
            }
            static $h = 1179656;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655885320),
    {
      "r": 131073,
      "n": "GetObject",
      "d": 1179656,
      "h": 38655885320,
      "f": 16777217,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655885320),
//--TRIMMABLE-BOUNDARY-START(34360918024),
    {
      "r": 655361,
      "n": "GetInteger",
      "d": 1179656,
      "h": 34360918024,
      "f": 16777217,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360918024),
//--TRIMMABLE-BOUNDARY-START(25770983432),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1179656
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1179656,
      "h": 25770983432,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770983432),
//--TRIMMABLE-BOUNDARY-START(21476016136),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1179656,
      "h": 21476016136,
      "f": 16809985,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21476016136),
//--TRIMMABLE-BOUNDARY-START(30065950728),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1179656,
      "h": 30065950728,
      "f": 16809985,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30065950728)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591114248),
    {
      "t": 131073,
      "n": "_object",
      "d": 1179656,
      "h": 8591114248,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591114248),
//--TRIMMABLE-BOUNDARY-START(4296146952),
    {
      "t": 655361,
      "n": "_integer",
      "d": 1179656,
      "h": 4296146952,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296146952)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17181048840),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "integer",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1179656,
      "h": 17181048840,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181048840),
//--TRIMMABLE-BOUNDARY-START(12886081544),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179656,
      "h": 12886081544,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886081544)
  ],
  "h": 1179656
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$sm.S.SequencePosition) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.SequencePosition`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}SequencePosition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179656)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048584)
        $asm.$str(`$sm.S.ExceptionArgument`, ($self) => class ExceptionArgument extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static length = 0;
            static start = 1;
            static minimumBufferSize = 2;
            static elementIndex = 3;
            static comparable = 4;
            static comparer = 5;
            static destination = 6;
            static offset = 7;
            static startSegment = 8;
            static endSegment = 9;
            static startIndex = 10;
            static endIndex = 11;
            static array = 12;
            static culture = 13;
            static manager = 14;
            static count = 15;
            static writer = 16;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1048584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "length": 0n,
                    "start": 1n,
                    "minimumBufferSize": 2n,
                    "elementIndex": 3n,
                    "comparable": 4n,
                    "comparer": 5n,
                    "destination": 6n,
                    "offset": 7n,
                    "startSegment": 8n,
                    "endSegment": 9n,
                    "startIndex": 10n,
                    "endIndex": 11n,
                    "array": 12n,
                    "culture": 13n,
                    "manager": 14n,
                    "count": 15n,
                    "writer": 16n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296015880)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296015880);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296015880)
            
            //--TRIMMABLE-BOUNDARY-START(4296015880)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296015880)
            
            static $h = 1048584;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245688840),
    {
      "t": 1048584,
      "n": "length",
      "d": 1048584,
      "h": 47245688840,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245688840),
//--TRIMMABLE-BOUNDARY-START(64425558024),
    {
      "t": 1048584,
      "n": "start",
      "d": 1048584,
      "h": 64425558024,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425558024),
//--TRIMMABLE-BOUNDARY-START(55835623432),
    {
      "t": 1048584,
      "n": "minimumBufferSize",
      "d": 1048584,
      "h": 55835623432,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835623432),
//--TRIMMABLE-BOUNDARY-START(34360786952),
    {
      "t": 1048584,
      "n": "elementIndex",
      "d": 1048584,
      "h": 34360786952,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360786952),
//--TRIMMABLE-BOUNDARY-START(12885950472),
    {
      "t": 1048584,
      "n": "comparable",
      "d": 1048584,
      "h": 12885950472,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885950472),
//--TRIMMABLE-BOUNDARY-START(17180917768),
    {
      "t": 1048584,
      "n": "comparer",
      "d": 1048584,
      "h": 17180917768,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180917768),
//--TRIMMABLE-BOUNDARY-START(30065819656),
    {
      "t": 1048584,
      "n": "destination",
      "d": 1048584,
      "h": 30065819656,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065819656),
//--TRIMMABLE-BOUNDARY-START(60130590728),
    {
      "t": 1048584,
      "n": "offset",
      "d": 1048584,
      "h": 60130590728,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130590728),
//--TRIMMABLE-BOUNDARY-START(73015492616),
    {
      "t": 1048584,
      "n": "startSegment",
      "d": 1048584,
      "h": 73015492616,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015492616),
//--TRIMMABLE-BOUNDARY-START(42950721544),
    {
      "t": 1048584,
      "n": "endSegment",
      "d": 1048584,
      "h": 42950721544,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950721544),
//--TRIMMABLE-BOUNDARY-START(68720525320),
    {
      "t": 1048584,
      "n": "startIndex",
      "d": 1048584,
      "h": 68720525320,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720525320),
//--TRIMMABLE-BOUNDARY-START(38655754248),
    {
      "t": 1048584,
      "n": "endIndex",
      "d": 1048584,
      "h": 38655754248,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655754248),
//--TRIMMABLE-BOUNDARY-START(8590983176),
    {
      "t": 1048584,
      "n": "array",
      "d": 1048584,
      "h": 8590983176,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590983176),
//--TRIMMABLE-BOUNDARY-START(25770852360),
    {
      "t": 1048584,
      "n": "culture",
      "d": 1048584,
      "h": 25770852360,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770852360),
//--TRIMMABLE-BOUNDARY-START(51540656136),
    {
      "t": 1048584,
      "n": "manager",
      "d": 1048584,
      "h": 51540656136,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540656136),
//--TRIMMABLE-BOUNDARY-START(21475885064),
    {
      "t": 1048584,
      "n": "count",
      "d": 1048584,
      "h": 21475885064,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475885064),
//--TRIMMABLE-BOUNDARY-START(77310459912),
    {
      "t": 1048584,
      "n": "writer",
      "d": 1048584,
      "h": 77310459912,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310459912)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015880),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1048584,
      "h": 4296015880,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015880)
  ],
  "h": 1048584
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.ExceptionArgument`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}ExceptionArgument`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048584)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib"));
})();
//--TRIMMABLE-BOUNDARY-END(8)
