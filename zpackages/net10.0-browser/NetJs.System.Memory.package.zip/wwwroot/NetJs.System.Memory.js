
//--TRIMMABLE-BOUNDARY-START(8)
(function ($global, $, $$) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Memory", 
    {
  "h": 8,
  "f": "System.Memory",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.System.Memory",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.System.Memory",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(327688)
        $asm.$cls("$sm.System.Buffers.IBufferWriter<>", (T) => $asm.$gt("$sm.System.Buffers.IBufferWriter<>", [T], ($self) => class IBufferWriter$$
        {
            static $h = 327688;
            static $g = 1;
            static $f = 0b1100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295294984),
    {
      "r": 65537,
      "p": [
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Advance",
      "o": "System$Buffers$IBufferWriter$$$Advance",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4295294984),
//--TRIMMABLE-BOUNDARY-START(8590262280),
    {
      "r": $.$$.System.Memory$$(T).$h,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "GetMemory",
      "o": "System$Buffers$IBufferWriter$$$GetMemory",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(8590262280),
//--TRIMMABLE-BOUNDARY-START(12885229576),
    {
      "r": $.$$.System.Span$$(T).$h,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "GetSpan",
      "o": "System$Buffers$IBufferWriter$$$GetSpan",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(12885229576)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $fullName() { return `System.Buffers.IBufferWriter<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(327688)
        
        
        //--TRIMMABLE-BOUNDARY-START(851976)
        $asm.$cls("$sm.System.Buffers.ReadOnlySequenceSegment<>", (T) => $asm.$gt("$sm.System.Buffers.ReadOnlySequenceSegment<>", [T], ($self) => class ReadOnlySequenceSegment$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(47245492232)
            /*ReadOnlyMemory<T>*/ Memory;
            //--TRIMMABLE-BOUNDARY-END(47245492232)
            
            //--TRIMMABLE-BOUNDARY-START(51540459528)
            /*ReadOnlySequenceSegment<T>?*/ Next = null;
            //--TRIMMABLE-BOUNDARY-END(51540459528)
            
            //--TRIMMABLE-BOUNDARY-START(55835426824)
            /*long*/ RunningIndex = 0n;
            //--TRIMMABLE-BOUNDARY-END(55835426824)
            
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Memory = $.$default($.$$.System.ReadOnlyMemory$$(T));
            }
            static $h = 851976;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(47245492232),
    {
      "p": $.$$.System.ReadOnlyMemory$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 83886084
      },
      "n": "Memory",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245492232),
//--TRIMMABLE-BOUNDARY-START(51540459528),
    {
      "p": this.$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 83886084
      },
      "n": "Next",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540459528),
//--TRIMMABLE-BOUNDARY-START(55835426824),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xA00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 83886084
      },
      "n": "RunningIndex",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835426824)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819272),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295819272)
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Buffers.ReadOnlySequenceSegment<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(851976)
        
        
        //--TRIMMABLE-BOUNDARY-START(393224)
        $asm.$cls("$sm.System.Buffers.MemoryPool<>", (T) => $asm.$gt("$sm.System.Buffers.MemoryPool<>", [T], ($self) => class MemoryPool$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(47245033480)
            /*ArrayMemoryPool<T>*/ static s_shared = null;
            //--TRIMMABLE-BOUNDARY-END(47245033480)
            
            //--TRIMMABLE-BOUNDARY-START(51540000776)
            static /*MemoryPool<T> */ get Shared()
            {
                return $.$sm.System.Buffers.MemoryPool$$(T).s_shared;
            }
            //--TRIMMABLE-BOUNDARY-END(51540000776)
            
            //--TRIMMABLE-BOUNDARY-START(8590327816)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327816);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327816)
            
            //--TRIMMABLE-BOUNDARY-START(12885295112)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885295112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.Dispose$1(true);
                $.$$.System.GC.SuppressFinalize(this);
            }
            //--TRIMMABLE-BOUNDARY-END(12885295112)
            
            //--TRIMMABLE-BOUNDARY-START(4385144833)
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385144833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385144833)
            
            //--TRIMMABLE-BOUNDARY-START(4295360520)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(47245033480)
                    this.s_shared = new ($.$sm.System.Buffers.ArrayMemoryPool$$(T))().$ctor$2();
                    //--TRIMMABLE-BOUNDARY-END(47245033480)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360520)
            
            static $h = 393224;
            static $g = 1;
            static $f = 0b1110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(51540000776),
    {
      "p": this.$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331681
      },
      "n": "Shared",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(51540000776),
//--TRIMMABLE-BOUNDARY-START(38655098888),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331905
      },
      "n": "MaxBufferSize",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38655098888)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42950066184),
    {
      "r": $.$$.System.Buffers.IMemoryOwner$$(T).$h,
      "p": [
        {
          "n": "minBufferSize",
          "p": 655361,
          "f": 65,
          "v": -1
        }
      ],
      "n": "Rent",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(42950066184),
//--TRIMMABLE-BOUNDARY-START(12885295112),
    {
      "r": 65537,
      "n": "Dispose",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885295112),
//--TRIMMABLE-BOUNDARY-START(17180262408),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777476
    },
//--TRIMMABLE-BOUNDARY-END(17180262408)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245033480),
    {
      "t": $.$sm.System.Buffers.ArrayMemoryPool$$(T).$h,
      "n": "s_shared",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(47245033480)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590327816),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(8590327816)
  ],
  "i": [90177537
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Buffers.MemoryPool<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(393224)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245192)
        $asm.$cls("$sm.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(227634511880)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(227634511880)
            
            //--TRIMMABLE-BOUNDARY-START(219044577288)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(219044577288)
            
            //--TRIMMABLE-BOUNDARY-START(223339544584)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979806216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$sm.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Memory", $.$sm.System.SR.$type.Assembly);
                    $.$sm.System.SR.s_resourceManager = temp;
                }
                return $.$sm.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(223339544584)
            
            //--TRIMMABLE-BOUNDARY-START(34360983560)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030133256);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sm.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519413768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$sm.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(34360983560)
            
            //--TRIMMABLE-BOUNDARY-START(206159675400)
            static /*string */ get NotSupported_CannotCallEqualsOnSpan()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210002440);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Equals() on Span and ReadOnlySpan is not supported. Use operator== instead.";
            }
            //--TRIMMABLE-BOUNDARY-END(206159675400)
            
            //--TRIMMABLE-BOUNDARY-START(210454642696)
            static /*string */ get NotSupported_CannotCallGetHashCodeOnSpan()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799937032);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "GetHashCode() on Span and ReadOnlySpan is not supported.";
            }
            //--TRIMMABLE-BOUNDARY-END(210454642696)
            
            //--TRIMMABLE-BOUNDARY-START(17181114376)
            static /*string */ get Argument_InvalidTypeWithPointersNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670394888);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot use type '{0}'. Only value types without pointers or references are supported.";
            }
            //--TRIMMABLE-BOUNDARY-END(17181114376)
            
            //--TRIMMABLE-BOUNDARY-START(77310656520)
            static /*string */ FormatArgument_InvalidTypeWithPointersNotSupported(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310656520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Cannot use type '{0}'. Only value types without pointers or references are supported.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(77310656520)
            
            //--TRIMMABLE-BOUNDARY-START(12886147080)
            static /*string */ get Argument_DestinationTooShort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080460296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Destination is too short.";
            }
            //--TRIMMABLE-BOUNDARY-END(12886147080)
            
            //--TRIMMABLE-BOUNDARY-START(214749609992)
            static /*string */ get OutstandingReferences()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389871624);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Release all references before disposing this instance.";
            }
            //--TRIMMABLE-BOUNDARY-END(214749609992)
            
            //--TRIMMABLE-BOUNDARY-START(8591179784)
            static /*string */ get Argument_BadFormatSpecifier()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490525704);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Format specifier was invalid.";
            }
            //--TRIMMABLE-BOUNDARY-END(8591179784)
            
            //--TRIMMABLE-BOUNDARY-START(21476081672)
            static /*string */ get Argument_OverlapAlignmentMismatch()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260329480);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Overlapping spans have mismatching alignment.";
            }
            //--TRIMMABLE-BOUNDARY-END(21476081672)
            
            //--TRIMMABLE-BOUNDARY-START(38655950856)
            static /*string */ get EndPositionNotReached()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620067848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "End position was not reached during enumeration.";
            }
            //--TRIMMABLE-BOUNDARY-END(38655950856)
            
            //--TRIMMABLE-BOUNDARY-START(30066016264)
            static /*string */ get BufferWriterAdvancedTooFar()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440198664);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot advance past the end of the buffer, which has a size of {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(30066016264)
            
            //--TRIMMABLE-BOUNDARY-START(85900591112)
            static /*string */ FormatBufferWriterAdvancedTooFar(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900591112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Cannot advance past the end of the buffer, which has a size of {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(85900591112)
            
            //--TRIMMABLE-BOUNDARY-START(25771048968)
            static /*string */ get BufferMaximumSizeExceeded()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850264072);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot allocate a buffer of size {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(25771048968)
            
            //--TRIMMABLE-BOUNDARY-START(81605623816)
            static /*string */ FormatBufferMaximumSizeExceeded(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605623816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Cannot allocate a buffer of size {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(81605623816)
            
            //--TRIMMABLE-BOUNDARY-START(231929479176)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(231929479176)
            
            //--TRIMMABLE-BOUNDARY-START(201864708104)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(201864708104);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(201864708104)
            
            //--TRIMMABLE-BOUNDARY-START(244814381064)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(244814381064);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$sm.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(244814381064)
            
            //--TRIMMABLE-BOUNDARY-START(193274773512)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274773512);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$sm.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(193274773512)
            
            //--TRIMMABLE-BOUNDARY-START(197569740808)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569740808);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$sm.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(197569740808)
            
            //--TRIMMABLE-BOUNDARY-START(42950918152)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950918152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(42950918152)
            
            //--TRIMMABLE-BOUNDARY-START(47245885448)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245885448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(47245885448)
            
            //--TRIMMABLE-BOUNDARY-START(51540852744)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540852744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(51540852744)
            
            //--TRIMMABLE-BOUNDARY-START(55835820040)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835820040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sm.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(55835820040)
            
            //--TRIMMABLE-BOUNDARY-START(60130787336)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130787336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(60130787336)
            
            //--TRIMMABLE-BOUNDARY-START(64425754632)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425754632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(64425754632)
            
            //--TRIMMABLE-BOUNDARY-START(68720721928)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720721928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(68720721928)
            
            //--TRIMMABLE-BOUNDARY-START(73015689224)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015689224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$sm.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(73015689224)
            
            //--TRIMMABLE-BOUNDARY-START(4296212488)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(231929479176)
                    this.s_usingResourceKeys = $.$sm.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(231929479176)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4296212488)
            
            static $h = 1245192;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 1245192
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245192)
        
        
        //--TRIMMABLE-BOUNDARY-START(983048)
        $asm.$cls("$sm.System.Buffers.SequenceReaderExtensions", ($self) => class SequenceReaderExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(4295950344)
            static /*bool */ TryRead(T, /*ref this SequenceReader<byte>*/ reader, /*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295950344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<byte>*/ let span = reader.$v.UnreadSpan;
                if (span.Length < (T.$z??4))
                {
                    return $.$sm.System.Buffers.SequenceReaderExtensions.TryReadMultisegment(T, reader, value);
                }
                value.$v = $.$$.System.Runtime.InteropServices.MemoryMarshal.Read(T, span);
                reader.$v.Advance(BigInt((T.$z??4)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(4295950344)
            
            //--TRIMMABLE-BOUNDARY-START(34360721416)
            static /*bool */ TryReadMultisegment(T, /*ref SequenceReader<byte>*/ reader, /*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360721416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(reader.$v.UnreadSpan.Length < (T.$z??4), "reader.UnreadSpan.Length < sizeof(T)");
                /*T*/ let buffer = $.$default(T);
                /*Span<byte>*/ let tempSpan = new ($.$$.System.Span$$($.$$.System.Byte))().$ctor$5($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT(T, () => buffer, ($v) => buffer = $v, null), (T.$z??4));
                if (!reader.$v.TryCopyTo(tempSpan))
                {
                    value.$v = $.$default(T);
                    return false;
                }
                value.$v = $.$$.System.Runtime.InteropServices.MemoryMarshal.Read(T, $.$$.System.Span$$($.$$.System.Byte).op_Implicit(tempSpan));
                reader.$v.Advance(BigInt((T.$z??4)));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(34360721416)
            
            //--TRIMMABLE-BOUNDARY-START(21475819528)
            static /*bool */ TryReadLittleEndian(/*ref this SequenceReader<byte>*/ reader, /*out short*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475819528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.BitConverter.IsLittleEndian)
                {
                    return $.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int16, $.$ref(() => reader, ($v) => reader = $v), value);
                }
                return $.$sm.System.Buffers.SequenceReaderExtensions.TryReadReverseEndianness(reader, value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475819528)
            
            //--TRIMMABLE-BOUNDARY-START(8590917640)
            static /*bool */ TryReadBigEndian(/*ref this SequenceReader<byte>*/ reader, /*out short*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590917640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.BitConverter.IsLittleEndian)
                {
                    return $.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int16, $.$ref(() => reader, ($v) => reader = $v), value);
                }
                return $.$sm.System.Buffers.SequenceReaderExtensions.TryReadReverseEndianness(reader, value);
            }
            //--TRIMMABLE-BOUNDARY-END(8590917640)
            
            //--TRIMMABLE-BOUNDARY-START(38655688712)
            static /*bool */ TryReadReverseEndianness(/*ref SequenceReader<byte>*/ reader, /*out short*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655688712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int16, $.$ref(() => reader, ($v) => reader = $v), value))
                {
                    value.$v = $.$$.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$3(value.$v);
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(38655688712)
            
            //--TRIMMABLE-BOUNDARY-START(25770786824)
            static /*bool */ TryReadLittleEndian$1(/*ref this SequenceReader<byte>*/ reader, /*out int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770786824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.BitConverter.IsLittleEndian)
                {
                    return $.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int32, $.$ref(() => reader, ($v) => reader = $v), value);
                }
                return $.$sm.System.Buffers.SequenceReaderExtensions.TryReadReverseEndianness$1(reader, value);
            }
            //--TRIMMABLE-BOUNDARY-END(25770786824)
            
            //--TRIMMABLE-BOUNDARY-START(12885884936)
            static /*bool */ TryReadBigEndian$1(/*ref this SequenceReader<byte>*/ reader, /*out int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885884936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.BitConverter.IsLittleEndian)
                {
                    return $.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int32, $.$ref(() => reader, ($v) => reader = $v), value);
                }
                return $.$sm.System.Buffers.SequenceReaderExtensions.TryReadReverseEndianness$1(reader, value);
            }
            //--TRIMMABLE-BOUNDARY-END(12885884936)
            
            //--TRIMMABLE-BOUNDARY-START(42950656008)
            static /*bool */ TryReadReverseEndianness$1(/*ref SequenceReader<byte>*/ reader, /*out int*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950656008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int32, $.$ref(() => reader, ($v) => reader = $v), value))
                {
                    value.$v = $.$$.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$4(value.$v);
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(42950656008)
            
            //--TRIMMABLE-BOUNDARY-START(30065754120)
            static /*bool */ TryReadLittleEndian$2(/*ref this SequenceReader<byte>*/ reader, /*out long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065754120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.BitConverter.IsLittleEndian)
                {
                    return $.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int64, $.$ref(() => reader, ($v) => reader = $v), value);
                }
                return $.$sm.System.Buffers.SequenceReaderExtensions.TryReadReverseEndianness$2(reader, value);
            }
            //--TRIMMABLE-BOUNDARY-END(30065754120)
            
            //--TRIMMABLE-BOUNDARY-START(17180852232)
            static /*bool */ TryReadBigEndian$2(/*ref this SequenceReader<byte>*/ reader, /*out long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180852232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!$.$$.System.BitConverter.IsLittleEndian)
                {
                    return $.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int64, $.$ref(() => reader, ($v) => reader = $v), value);
                }
                return $.$sm.System.Buffers.SequenceReaderExtensions.TryReadReverseEndianness$2(reader, value);
            }
            //--TRIMMABLE-BOUNDARY-END(17180852232)
            
            //--TRIMMABLE-BOUNDARY-START(47245623304)
            static /*bool */ TryReadReverseEndianness$2(/*ref SequenceReader<byte>*/ reader, /*out long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245623304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$sm.System.Buffers.SequenceReaderExtensions.TryRead($.$$.System.Int64, $.$ref(() => reader, ($v) => reader = $v), value))
                {
                    value.$v = $.$$.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$5(value.$v);
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(47245623304)
            
            static $h = 983048;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295950344),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": (T) => T.$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryRead",
      "d": 983048,
      "h": 4295950344,
      "f": 16908328
    },
//--TRIMMABLE-BOUNDARY-END(4295950344),
//--TRIMMABLE-BOUNDARY-START(34360721416),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": (T) => T.$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryReadMultisegment",
      "d": 983048,
      "h": 34360721416,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(34360721416),
//--TRIMMABLE-BOUNDARY-START(21475819528),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 524289,
          "f": 2
        }
      ],
      "n": "TryReadLittleEndian",
      "d": 983048,
      "h": 21475819528,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475819528),
//--TRIMMABLE-BOUNDARY-START(8590917640),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 524289,
          "f": 2
        }
      ],
      "n": "TryReadBigEndian",
      "d": 983048,
      "h": 8590917640,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590917640),
//--TRIMMABLE-BOUNDARY-START(38655688712),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 524289,
          "f": 2
        }
      ],
      "n": "TryReadReverseEndianness",
      "d": 983048,
      "h": 38655688712,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38655688712),
//--TRIMMABLE-BOUNDARY-START(25770786824),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadLittleEndian",
      "o": "@$1",
      "d": 983048,
      "h": 25770786824,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770786824),
//--TRIMMABLE-BOUNDARY-START(12885884936),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadBigEndian",
      "o": "@$1",
      "d": 983048,
      "h": 12885884936,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885884936),
//--TRIMMABLE-BOUNDARY-START(42950656008),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryReadReverseEndianness",
      "o": "@$1",
      "d": 983048,
      "h": 42950656008,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(42950656008),
//--TRIMMABLE-BOUNDARY-START(30065754120),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "TryReadLittleEndian",
      "o": "@$2",
      "d": 983048,
      "h": 30065754120,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30065754120),
//--TRIMMABLE-BOUNDARY-START(17180852232),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "TryReadBigEndian",
      "o": "@$2",
      "d": 983048,
      "h": 17180852232,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180852232),
//--TRIMMABLE-BOUNDARY-START(47245623304),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "TryReadReverseEndianness",
      "o": "@$2",
      "d": 983048,
      "h": 47245623304,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(47245623304)
  ],
  "h": 983048
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Buffers.SequenceReaderExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983048)
        
        
        //--TRIMMABLE-BOUNDARY-START(720904)
        $asm.$cls("$sm.System.Buffers.ReadOnlySequenceDebugView<>", (T) => $asm.$gt("$sm.System.Buffers.ReadOnlySequenceDebugView<>", [T], ($self) => class ReadOnlySequenceDebugView$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688200)
            /*T[]*/ _array = null;
            //--TRIMMABLE-BOUNDARY-END(4295688200)
            
            //--TRIMMABLE-BOUNDARY-START(8590655496)
            /*ReadOnlySequenceDebugViewSegments*/ _segments;
            //--TRIMMABLE-BOUNDARY-END(8590655496)
            
            //--TRIMMABLE-BOUNDARY-START(12885622792)
            $ctor$1(/*ReadOnlySequence<T>*/ sequence)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885622792);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._array = $.$sm.System.Buffers.BuffersExtensions.ToArray(T, $.$ref(() => sequence, ));
                    /*var*/ let segmentCount = 0;
                    var $en3 = sequence.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var _ = $en3.Current;
                        {
                            segmentCount++;
                        }
                    }
                    /*var*/ let segments = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.ReadOnlyMemory$$(T)), null, [segmentCount], null);
                    /*int*/ let i = 0;
                    var $en3 = sequence.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var readOnlyMemory = $en3.Current;
                        {
                            $.$$.System.Array.$WriteT1.call(segments, readOnlyMemory, i);
                            i++;
                        }
                    }
                    this._segments = (() =>
                    {
                        //new $.$sm.System.Buffers.ReadOnlySequenceDebugView$$(T).ReadOnlySequenceDebugViewSegments()
                        const $t1 = $.$sm.System.Buffers.ReadOnlySequenceDebugView$$(T).ReadOnlySequenceDebugViewSegments;
                        const $i1 = new $t1();
                        $i1.Segments = segments;
                        return $i1;
                    })();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885622792)
            
            //--TRIMMABLE-BOUNDARY-START(17180590088)
            /*ReadOnlySequenceDebugViewSegments */ get BufferSegments()
            {
                return this._segments;
            }
            //--TRIMMABLE-BOUNDARY-END(17180590088)
            
            //--TRIMMABLE-BOUNDARY-START(38655426568)
            /*T[] */ get Items()
            {
                return this._array;
            }
            //--TRIMMABLE-BOUNDARY-END(38655426568)
            
            //--TRIMMABLE-BOUNDARY-START(786440)
            static $_ReadOnlySequenceDebugViewSegments;
            static get ReadOnlySequenceDebugViewSegments()
            {
                let $cls = $.$sm.System.Buffers.ReadOnlySequenceDebugView$$(T);
                return $cls.$_ReadOnlySequenceDebugViewSegments ??= $asm.$nstr("$sm.System.Buffers.ReadOnlySequenceDebugView$$.ReadOnlySequenceDebugViewSegments", ($self) => class ReadOnlySequenceDebugViewSegments extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(21475622920)
                    /*ReadOnlyMemory<T>[]*/ Segments = null;
                    //--TRIMMABLE-BOUNDARY-END(21475622920)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Segments = this.Segments;
                        return copy;
                    }
                    static $h = 786440;
                    static $z = 4;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475622920),
    {
      "p": $.$typeArray($.$$.System.ReadOnlyMemory$$(T)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(786440)|0x400000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(786440)|0x700000000n),
        "f": 83886081
      },
      "n": "Segments",
      "d": 786440,
      "h": Number(BigInt(786440)|0x500000000n),
      "f": 2097153,
      "a": [
        {
          "t": 70057985,
          "c": 4365025281,
          "a": [
            {
              "v": 3,
              "t": 70123521
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475622920)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753736),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786440,
      "h": Number(BigInt(786440)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753736)
  ],
  "d": $.$sm.System.Buffers.ReadOnlySequenceDebugView$$(T).$h,
  "h": 786440,
  "a": [
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "Count = {Segments.Length}",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "Name",
          "v": "Segments",
          "t": 1310721
        }
      ]
    }
  ]
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Buffers.ReadOnlySequenceDebugView<${T?.$fullName}>.ReadOnlySequenceDebugViewSegments`; }
                }, $cls, ($v) => $cls.$_ReadOnlySequenceDebugViewSegments = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(786440)
            
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8590655496)
                this._segments = $.$default($.$sm.System.Buffers.ReadOnlySequenceDebugView$$(T).ReadOnlySequenceDebugViewSegments);
                //--TRIMMABLE-BOUNDARY-END(8590655496)
                
            }
            static $h = 720904;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180590088),
    {
      "p": 786440,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x600000000n),
        "f": 50331649
      },
      "n": "BufferSegments",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180590088),
//--TRIMMABLE-BOUNDARY-START(38655426568),
    {
      "p": $.$typeArray(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x800000000n),
        "f": 50331649
      },
      "n": "Items",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 2097153,
      "a": [
        {
          "t": 70057985,
          "c": 4365025281,
          "a": [
            {
              "v": 3,
              "t": 70123521
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655426568)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295688200),
    {
      "t": $.$typeArray(T).$h,
      "n": "_array",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295688200),
//--TRIMMABLE-BOUNDARY-START(8590655496),
    {
      "t": 786440,
      "n": "_segments",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590655496)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885622792),
    {
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885622792)
  ],
  "g": [T?.$h??1507328
  ],
  "j": [786440
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Buffers.ReadOnlySequenceDebugView<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(720904)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114120)
        $asm.$cls("$sm.System.Runtime.InteropServices.SequenceMarshal", ($self) => class SequenceMarshal
        {
            //--TRIMMABLE-BOUNDARY-START(12886016008)
            static /*bool */ TryGetReadOnlySequenceSegment(T, /*ReadOnlySequence<T>*/ sequence, /*out ReadOnlySequenceSegment<T>?*/ startSegment, /*out int*/ startIndex, /*out ReadOnlySequenceSegment<T>?*/ endSegment, /*out int*/ endIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886016008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return sequence.TryGetReadOnlySequenceSegment(startSegment, startIndex, endSegment, endIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(12886016008)
            
            //--TRIMMABLE-BOUNDARY-START(4296081416)
            static /*bool */ TryGetArray(T, /*ReadOnlySequence<T>*/ sequence, /*out ArraySegment<T>*/ segment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296081416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return sequence.TryGetArray(segment);
            }
            //--TRIMMABLE-BOUNDARY-END(4296081416)
            
            //--TRIMMABLE-BOUNDARY-START(8591048712)
            static /*bool */ TryGetReadOnlyMemory(T, /*ReadOnlySequence<T>*/ sequence, /*out ReadOnlyMemory<T>*/ memory)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591048712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!sequence.IsSingleSegment)
                {
                    memory.$v = new ($.$$.System.ReadOnlyMemory$$(T))();
                    return false;
                }
                memory.$v = sequence.First;
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(8591048712)
            
            //--TRIMMABLE-BOUNDARY-START(17180983304)
            static /*bool */ TryGetString(/*ReadOnlySequence<char>*/ sequence, /*out string?*/ text, /*out int*/ start, /*out int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180983304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return sequence.TryGetString(text, start, length);
            }
            //--TRIMMABLE-BOUNDARY-END(17180983304)
            
            //--TRIMMABLE-BOUNDARY-START(21475950600)
            static /*bool */ TryRead(T, /*ref SequenceReader<byte>*/ reader, /*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475950600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$sm.System.Buffers.SequenceReaderExtensions.TryRead(T, $.$ref(() => reader, ($v) => reader = $v), value);
            }
            //--TRIMMABLE-BOUNDARY-END(21475950600)
            
            static $h = 1114120;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886016008),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": (T) => $.$sm.System.Buffers.ReadOnlySequence$$(T).$h
        },
        {
          "n": "startSegment",
          "p": (T) => $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h,
          "f": 2
        },
        {
          "n": "startIndex",
          "p": 655361,
          "f": 2
        },
        {
          "n": "endSegment",
          "p": (T) => $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h,
          "f": 2
        },
        {
          "n": "endIndex",
          "p": 655361,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryGetReadOnlySequenceSegment",
      "d": 1114120,
      "h": 12886016008,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12886016008),
//--TRIMMABLE-BOUNDARY-START(4296081416),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": (T) => $.$sm.System.Buffers.ReadOnlySequence$$(T).$h
        },
        {
          "n": "segment",
          "p": (T) => $.$$.System.ArraySegment$$(T).$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryGetArray",
      "d": 1114120,
      "h": 4296081416,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4296081416),
//--TRIMMABLE-BOUNDARY-START(8591048712),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": (T) => $.$sm.System.Buffers.ReadOnlySequence$$(T).$h
        },
        {
          "n": "memory",
          "p": (T) => $.$$.System.ReadOnlyMemory$$(T).$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryGetReadOnlyMemory",
      "d": 1114120,
      "h": 8591048712,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(8591048712),
//--TRIMMABLE-BOUNDARY-START(17180983304),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char).$h
        },
        {
          "n": "text",
          "p": 1310721,
          "f": 2
        },
        {
          "n": "start",
          "p": 655361,
          "f": 2
        },
        {
          "n": "length",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryGetString",
      "d": 1114120,
      "h": 17180983304,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(17180983304),
//--TRIMMABLE-BOUNDARY-START(21475950600),
    {
      "r": 262145,
      "p": [
        {
          "n": "reader",
          "p": $.$sm.System.Buffers.SequenceReader$$($.$$.System.Byte).$h,
          "f": 4
        },
        {
          "n": "value",
          "p": (T) => T.$h,
          "f": 2
        }
      ],
      "g": [
        "T"
      ],
      "n": "TryRead",
      "d": 1114120,
      "h": 21475950600,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21475950600)
  ],
  "h": 1114120
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Runtime.InteropServices.SequenceMarshal`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114120)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376264)
        $asm.$cls("$sm.System.ThrowHelper", ($self) => class ThrowHelper
        {
            //--TRIMMABLE-BOUNDARY-START(42951049224)
            static /*void */ ThrowArgumentNullException(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951049224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$sm.System.ThrowHelper.CreateArgumentNullException(argument);
            }
            //--TRIMMABLE-BOUNDARY-END(42951049224)
            
            //--TRIMMABLE-BOUNDARY-START(4296343560)
            static /*ArgumentNullException */ CreateArgumentNullException(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296343560);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.System.ArgumentNullException().$ctor$19($.$$.System.Enum.ToStringT($.$sm.System.ExceptionArgument, $.$$.System.UInt32, argument));
            }
            //--TRIMMABLE-BOUNDARY-END(4296343560)
            
            //--TRIMMABLE-BOUNDARY-START(47246016520)
            static /*void */ ThrowArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246016520);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException(argument);
            }
            //--TRIMMABLE-BOUNDARY-END(47246016520)
            
            //--TRIMMABLE-BOUNDARY-START(8591310856)
            static /*ArgumentOutOfRangeException */ CreateArgumentOutOfRangeException(/*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591310856);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.System.ArgumentOutOfRangeException().$ctor$20($.$$.System.Enum.ToStringT($.$sm.System.ExceptionArgument, $.$$.System.UInt32, argument));
            }
            //--TRIMMABLE-BOUNDARY-END(8591310856)
            
            //--TRIMMABLE-BOUNDARY-START(68720853000)
            static /*void */ ThrowInvalidOperationException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720853000);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$sm.System.ThrowHelper.CreateInvalidOperationException();
            }
            //--TRIMMABLE-BOUNDARY-END(68720853000)
            
            //--TRIMMABLE-BOUNDARY-START(30066147336)
            static /*InvalidOperationException */ CreateInvalidOperationException()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066147336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.System.InvalidOperationException().$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(30066147336)
            
            //--TRIMMABLE-BOUNDARY-START(73015820296)
            static /*void */ ThrowInvalidOperationException_EndPositionNotReached()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015820296);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$sm.System.ThrowHelper.CreateInvalidOperationException_EndPositionNotReached();
            }
            //--TRIMMABLE-BOUNDARY-END(73015820296)
            
            //--TRIMMABLE-BOUNDARY-START(34361114632)
            static /*InvalidOperationException */ CreateInvalidOperationException_EndPositionNotReached()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361114632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.System.InvalidOperationException().$ctor$12($.$sm.System.SR.EndPositionNotReached);
            }
            //--TRIMMABLE-BOUNDARY-END(34361114632)
            
            //--TRIMMABLE-BOUNDARY-START(55835951112)
            static /*void */ ThrowArgumentOutOfRangeException_PositionOutOfRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835951112);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException_PositionOutOfRange();
            }
            //--TRIMMABLE-BOUNDARY-END(55835951112)
            
            //--TRIMMABLE-BOUNDARY-START(17181245448)
            static /*ArgumentOutOfRangeException */ CreateArgumentOutOfRangeException_PositionOutOfRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181245448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.System.ArgumentOutOfRangeException().$ctor$20("position");
            }
            //--TRIMMABLE-BOUNDARY-END(17181245448)
            
            //--TRIMMABLE-BOUNDARY-START(51540983816)
            static /*void */ ThrowArgumentOutOfRangeException_OffsetOutOfRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540983816);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException_OffsetOutOfRange();
            }
            //--TRIMMABLE-BOUNDARY-END(51540983816)
            
            //--TRIMMABLE-BOUNDARY-START(12886278152)
            static /*ArgumentOutOfRangeException */ CreateArgumentOutOfRangeException_OffsetOutOfRange()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886278152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$$.System.ArgumentOutOfRangeException().$ctor$20("offset");
            }
            //--TRIMMABLE-BOUNDARY-END(12886278152)
            
            //--TRIMMABLE-BOUNDARY-START(60130918408)
            static /*void */ ThrowArgumentValidationException$1(T, /*ReadOnlySequenceSegment<T>?*/ startSegment, /*int*/ startIndex, /*ReadOnlySequenceSegment<T>?*/ endSegment)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60130918408);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sm.System.ThrowHelper.CreateArgumentValidationException$1(T, startSegment, startIndex, endSegment);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60130918408)
            
            //--TRIMMABLE-BOUNDARY-START(21476212744)
            static /*Exception */ CreateArgumentValidationException$1(T, /*ReadOnlySequenceSegment<T>?*/ startSegment, /*int*/ startIndex, /*ReadOnlySequenceSegment<T>?*/ endSegment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476212744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (startSegment === null)
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentNullException(8/*ExceptionArgument.startSegment*/);
                }
                else if (endSegment === null)
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentNullException(9/*ExceptionArgument.endSegment*/);
                }
                else if (startSegment !== endSegment && startSegment.RunningIndex > endSegment.RunningIndex)
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException(9/*ExceptionArgument.endSegment*/);
                }
                else if ((startSegment.Memory.Length >>> 0) < (startIndex >>> 0))
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException(10/*ExceptionArgument.startIndex*/);
                }
                else 
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException(11/*ExceptionArgument.endIndex*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476212744)
            
            //--TRIMMABLE-BOUNDARY-START(64425885704)
            static /*void */ ThrowArgumentValidationException(/*Array?*/ array, /*int*/ start)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64425885704);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sm.System.ThrowHelper.CreateArgumentValidationException(array, start);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64425885704)
            
            //--TRIMMABLE-BOUNDARY-START(25771180040)
            static /*Exception */ CreateArgumentValidationException(/*Array?*/ array, /*int*/ start)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771180040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (array === null)
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentNullException(12/*ExceptionArgument.array*/);
                }
                else if ((start >>> 0) > (array.length >>> 0))
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException(1/*ExceptionArgument.start*/);
                }
                else 
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException(0/*ExceptionArgument.length*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771180040)
            
            //--TRIMMABLE-BOUNDARY-START(77310787592)
            static /*void */ ThrowStartOrEndArgumentValidationException(/*long*/ start)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77310787592);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw $.$sm.System.ThrowHelper.CreateStartOrEndArgumentValidationException(start);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310787592)
            
            //--TRIMMABLE-BOUNDARY-START(38656081928)
            static /*ArgumentOutOfRangeException */ CreateStartOrEndArgumentValidationException(/*long*/ start)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656081928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (start < 0n)
                {
                    return $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException(1/*ExceptionArgument.start*/);
                }
                return $.$sm.System.ThrowHelper.CreateArgumentOutOfRangeException(0/*ExceptionArgument.length*/);
            }
            //--TRIMMABLE-BOUNDARY-END(38656081928)
            
            static $h = 1376264;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(42951049224),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1048584
        }
      ],
      "n": "ThrowArgumentNullException",
      "d": 1376264,
      "h": 42951049224,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(42951049224),
//--TRIMMABLE-BOUNDARY-START(4296343560),
    {
      "r": 44171265,
      "p": [
        {
          "n": "argument",
          "p": 1048584
        }
      ],
      "n": "CreateArgumentNullException",
      "d": 1376264,
      "h": 4296343560,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(4296343560),
//--TRIMMABLE-BOUNDARY-START(47246016520),
    {
      "r": 65537,
      "p": [
        {
          "n": "argument",
          "p": 1048584
        }
      ],
      "n": "ThrowArgumentOutOfRangeException",
      "d": 1376264,
      "h": 47246016520,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(47246016520),
//--TRIMMABLE-BOUNDARY-START(8591310856),
    {
      "r": 44236801,
      "p": [
        {
          "n": "argument",
          "p": 1048584
        }
      ],
      "n": "CreateArgumentOutOfRangeException",
      "d": 1376264,
      "h": 8591310856,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8591310856),
//--TRIMMABLE-BOUNDARY-START(68720853000),
    {
      "r": 65537,
      "n": "ThrowInvalidOperationException",
      "d": 1376264,
      "h": 68720853000,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(68720853000),
//--TRIMMABLE-BOUNDARY-START(30066147336),
    {
      "r": 90898433,
      "n": "CreateInvalidOperationException",
      "d": 1376264,
      "h": 30066147336,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(30066147336),
//--TRIMMABLE-BOUNDARY-START(73015820296),
    {
      "r": 65537,
      "n": "ThrowInvalidOperationException_EndPositionNotReached",
      "d": 1376264,
      "h": 73015820296,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(73015820296),
//--TRIMMABLE-BOUNDARY-START(34361114632),
    {
      "r": 90898433,
      "n": "CreateInvalidOperationException_EndPositionNotReached",
      "d": 1376264,
      "h": 34361114632,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34361114632),
//--TRIMMABLE-BOUNDARY-START(55835951112),
    {
      "r": 65537,
      "n": "ThrowArgumentOutOfRangeException_PositionOutOfRange",
      "d": 1376264,
      "h": 55835951112,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(55835951112),
//--TRIMMABLE-BOUNDARY-START(17181245448),
    {
      "r": 44236801,
      "n": "CreateArgumentOutOfRangeException_PositionOutOfRange",
      "d": 1376264,
      "h": 17181245448,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(17181245448),
//--TRIMMABLE-BOUNDARY-START(51540983816),
    {
      "r": 65537,
      "n": "ThrowArgumentOutOfRangeException_OffsetOutOfRange",
      "d": 1376264,
      "h": 51540983816,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(51540983816),
//--TRIMMABLE-BOUNDARY-START(12886278152),
    {
      "r": 44236801,
      "n": "CreateArgumentOutOfRangeException_OffsetOutOfRange",
      "d": 1376264,
      "h": 12886278152,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(12886278152),
//--TRIMMABLE-BOUNDARY-START(60130918408),
    {
      "r": 65537,
      "p": [
        {
          "n": "startSegment",
          "p": (T) => $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endSegment",
          "p": (T) => $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "ThrowArgumentValidationException",
      "o": "@$1",
      "d": 1376264,
      "h": 60130918408,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(60130918408),
//--TRIMMABLE-BOUNDARY-START(21476212744),
    {
      "r": 79888385,
      "p": [
        {
          "n": "startSegment",
          "p": (T) => $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endSegment",
          "p": (T) => $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CreateArgumentValidationException",
      "o": "@$1",
      "d": 1376264,
      "h": 21476212744,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(21476212744),
//--TRIMMABLE-BOUNDARY-START(64425885704),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "start",
          "p": 655361
        }
      ],
      "n": "ThrowArgumentValidationException",
      "d": 1376264,
      "h": 64425885704,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(64425885704),
//--TRIMMABLE-BOUNDARY-START(25771180040),
    {
      "r": 79888385,
      "p": [
        {
          "n": "array",
          "p": 1245185
        },
        {
          "n": "start",
          "p": 655361
        }
      ],
      "n": "CreateArgumentValidationException",
      "d": 1376264,
      "h": 25771180040,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(25771180040),
//--TRIMMABLE-BOUNDARY-START(77310787592),
    {
      "r": 65537,
      "p": [
        {
          "n": "start",
          "p": 917505
        }
      ],
      "n": "ThrowStartOrEndArgumentValidationException",
      "d": 1376264,
      "h": 77310787592,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77310787592),
//--TRIMMABLE-BOUNDARY-START(38656081928),
    {
      "r": 44236801,
      "p": [
        {
          "n": "start",
          "p": 917505
        }
      ],
      "n": "CreateStartOrEndArgumentValidationException",
      "d": 1376264,
      "h": 38656081928,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(38656081928)
  ],
  "h": 1376264
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.ThrowHelper`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376264)
        
        
        //--TRIMMABLE-BOUNDARY-START(262152)
        $asm.$cls("$sm.System.Buffers.BuffersExtensions", ($self) => class BuffersExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(12885164040)
            static /*SequencePosition? */ PositionOf(T, /*in this ReadOnlySequence<T>*/ source, /*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164040);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (source.$v.IsSingleSegment)
                {
                    /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$4(T, source.$v.First.Span, value);
                    if (index !== -1)
                    {
                        return source.$v.Seek(BigInt(index), 7);
                    }
                    return null;
                }
                else 
                {
                    return $.$sm.System.Buffers.BuffersExtensions.PositionOfMultiSegment(T, source, value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12885164040)
            
            //--TRIMMABLE-BOUNDARY-START(17180131336)
            static /*SequencePosition? */ PositionOfMultiSegment(T, /*in ReadOnlySequence<T>*/ source, /*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180131336);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SequencePosition*/ let position = source.$v.Start;
                /*SequencePosition*/ let result = position;
                /*ReadOnlyMemory<T>*/ let memory;
                while(source.$v.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => position, ($v) => position = $v, null), $.$ref(() => memory, ($v) => memory = $v, $.$$.System.ReadOnlyMemory$$(T)), true))
                {
                    /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$4(T, memory.Span, value);
                    if (index !== -1)
                    {
                        return source.$v.GetPosition(BigInt(index), result);
                    }
                    else if (position.GetObject() === null)
                    {
                        break;
                    }
                    result = position;
                }
                return null;
            }
            //--TRIMMABLE-BOUNDARY-END(17180131336)
            
            //--TRIMMABLE-BOUNDARY-START(4295229448)
            static /*void */ CopyTo(T, /*in this ReadOnlySequence<T>*/ source, /*Span<T>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229448);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (source.$v.IsSingleSegment)
                {
                    /*ReadOnlySpan<T>*/ let span = source.$v.First.Span;
                    if (span.Length > destination.Length)
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.destination*/);
                    }
                    span.CopyTo(destination);
                }
                else 
                {
                    $.$sm.System.Buffers.BuffersExtensions.CopyToMultiSegment(T, source, destination);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295229448)
            
            //--TRIMMABLE-BOUNDARY-START(8590196744)
            static /*void */ CopyToMultiSegment(T, /*in ReadOnlySequence<T>*/ sequence, /*Span<T>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196744);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (sequence.$v.Length > BigInt(destination.Length))
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(6/*ExceptionArgument.destination*/);
                }
                /*SequencePosition*/ let position = sequence.$v.Start;
                /*ReadOnlyMemory<T>*/ let memory;
                while(sequence.$v.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => position, ($v) => position = $v, null), $.$ref(() => memory, ($v) => memory = $v, $.$$.System.ReadOnlyMemory$$(T)), true))
                {
                    /*ReadOnlySpan<T>*/ let span = memory.Span;
                    span.CopyTo(destination);
                    if (position.GetObject() !== null)
                    {
                        destination = destination.Slice$1(span.Length);
                    }
                    else 
                    {
                        break;
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590196744)
            
            //--TRIMMABLE-BOUNDARY-START(21475098632)
            static /*T[] */ ToArray(T, /*in this ReadOnlySequence<T>*/ sequence)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098632);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let array = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [sequence.$v.Length], null);
                $.$sm.System.Buffers.BuffersExtensions.CopyTo(T, $.$ref(() => sequence, ), $.$$.System.Span$$(T).op_Implicit$2(array));
                return array;
            }
            //--TRIMMABLE-BOUNDARY-END(21475098632)
            
            //--TRIMMABLE-BOUNDARY-START(25770065928)
            static /*void */ Write(T, /*this IBufferWriter<T>*/ writer, /*ReadOnlySpan<T>*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770065928);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Span<T>*/ let destination = writer.System$Buffers$IBufferWriter$$$GetSpan(0, [T]);
                if (value.Length <= destination.Length)
                {
                    value.CopyTo(destination);
                    writer.System$Buffers$IBufferWriter$$$Advance(value.Length, [T]);
                }
                else 
                {
                    $.$sm.System.Buffers.BuffersExtensions.WriteMultiSegment(T, writer, $.$ref(() => value, ), destination);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770065928)
            
            //--TRIMMABLE-BOUNDARY-START(30065033224)
            static /*void */ WriteMultiSegment(T, /*IBufferWriter<T>*/ writer, /*in ReadOnlySpan<T>*/ source, /*Span<T>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033224);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let input = source.$v;
                while(true)
                {
                    /*int*/ let writeSize = $.$$.System.Math.Min$4(destination.Length, input.Length);
                    input.Slice(0, writeSize).CopyTo(destination);
                    writer.System$Buffers$IBufferWriter$$$Advance(writeSize, [T]);
                    input = input.Slice$1(writeSize);
                    if (input.Length > 0)
                    {
                        destination = writer.System$Buffers$IBufferWriter$$$GetSpan(0, [T]);
                        if (destination.IsEmpty)
                        {
                            $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(16/*ExceptionArgument.writer*/);
                        }
                        continue;
                    }
                    return;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30065033224)
            
            static $h = 262152;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885164040),
    {
      "r": $.$typeNullable($.$sm.System.SequencePosition).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
          "f": 8
        },
        {
          "n": "value",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "PositionOf",
      "d": 262152,
      "h": 12885164040,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(12885164040),
//--TRIMMABLE-BOUNDARY-START(17180131336),
    {
      "r": $.$typeNullable($.$sm.System.SequencePosition).$h,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
          "f": 8
        },
        {
          "n": "value",
          "p": (T) => T.$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "PositionOfMultiSegment",
      "d": 262152,
      "h": 17180131336,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(17180131336),
//--TRIMMABLE-BOUNDARY-START(4295229448),
    {
      "r": 65537,
      "p": [
        {
          "n": "source",
          "p": (T) => $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
          "f": 8
        },
        {
          "n": "destination",
          "p": (T) => $.$$.System.Span$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CopyTo",
      "d": 262152,
      "h": 4295229448,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(4295229448),
//--TRIMMABLE-BOUNDARY-START(8590196744),
    {
      "r": 65537,
      "p": [
        {
          "n": "sequence",
          "p": (T) => $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
          "f": 8
        },
        {
          "n": "destination",
          "p": (T) => $.$$.System.Span$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "CopyToMultiSegment",
      "d": 262152,
      "h": 8590196744,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(8590196744),
//--TRIMMABLE-BOUNDARY-START(21475098632),
    {
      "r": (T) => $.$typeArray(T).$h,
      "p": [
        {
          "n": "sequence",
          "p": (T) => $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
          "f": 8
        }
      ],
      "g": [
        "T"
      ],
      "n": "ToArray",
      "d": 262152,
      "h": 21475098632,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21475098632),
//--TRIMMABLE-BOUNDARY-START(25770065928),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": (T) => $.$sm.System.Buffers.IBufferWriter$$(T).$h
        },
        {
          "n": "value",
          "p": (T) => $.$$.System.ReadOnlySpan$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "Write",
      "d": 262152,
      "h": 25770065928,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25770065928),
//--TRIMMABLE-BOUNDARY-START(30065033224),
    {
      "r": 65537,
      "p": [
        {
          "n": "writer",
          "p": (T) => $.$sm.System.Buffers.IBufferWriter$$(T).$h
        },
        {
          "n": "source",
          "p": (T) => $.$$.System.ReadOnlySpan$$(T).$h,
          "f": 8
        },
        {
          "n": "destination",
          "p": (T) => $.$$.System.Span$$(T).$h
        }
      ],
      "g": [
        "T"
      ],
      "n": "WriteMultiSegment",
      "d": 262152,
      "h": 30065033224,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(30065033224)
  ],
  "h": 262152
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Buffers.BuffersExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262152)
        
        
        //--TRIMMABLE-BOUNDARY-START(458760)
        $asm.$cls("$sm.System.Buffers.ReadOnlySequence", ($self) => class ReadOnlySequence
        {
            //--TRIMMABLE-BOUNDARY-START(12885360648)
            /*int*/ static FlagBitMask = -2147483648;
            //--TRIMMABLE-BOUNDARY-END(12885360648)
            
            //--TRIMMABLE-BOUNDARY-START(17180327944)
            /*int*/ static IndexBitMask = 2147483647;
            //--TRIMMABLE-BOUNDARY-END(17180327944)
            
            //--TRIMMABLE-BOUNDARY-START(4295426056)
            /*int*/ static ArrayEndMask = -2147483648;
            //--TRIMMABLE-BOUNDARY-END(4295426056)
            
            //--TRIMMABLE-BOUNDARY-START(21475295240)
            /*int*/ static MemoryManagerStartMask = -2147483648;
            //--TRIMMABLE-BOUNDARY-END(21475295240)
            
            //--TRIMMABLE-BOUNDARY-START(34360197128)
            /*int*/ static StringStartMask = -2147483648;
            //--TRIMMABLE-BOUNDARY-END(34360197128)
            
            //--TRIMMABLE-BOUNDARY-START(30065229832)
            /*int*/ static StringEndMask = -2147483648;
            //--TRIMMABLE-BOUNDARY-END(30065229832)
            
            //--TRIMMABLE-BOUNDARY-START(8590393352)
            static /*int */ ArrayToSequenceEnd(/*int*/ endIndex)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590393352);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return endIndex | -2147483648/*ArrayEndMask*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590393352)
            
            //--TRIMMABLE-BOUNDARY-START(25770262536)
            static /*int */ MemoryManagerToSequenceStart(/*int*/ startIndex)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770262536);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return startIndex | -2147483648/*MemoryManagerStartMask*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25770262536)
            
            //--TRIMMABLE-BOUNDARY-START(42950131720)
            static /*int */ StringToSequenceStart(/*int*/ startIndex)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950131720);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return startIndex | -2147483648/*StringStartMask*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950131720)
            
            //--TRIMMABLE-BOUNDARY-START(38655164424)
            static /*int */ StringToSequenceEnd(/*int*/ endIndex)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655164424);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return endIndex | -2147483648/*StringEndMask*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655164424)
            
            static $h = 458760;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590393352),
    {
      "r": 655361,
      "p": [
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": "ArrayToSequenceEnd",
      "d": 458760,
      "h": 8590393352,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590393352),
//--TRIMMABLE-BOUNDARY-START(25770262536),
    {
      "r": 655361,
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        }
      ],
      "n": "MemoryManagerToSequenceStart",
      "d": 458760,
      "h": 25770262536,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25770262536),
//--TRIMMABLE-BOUNDARY-START(42950131720),
    {
      "r": 655361,
      "p": [
        {
          "n": "startIndex",
          "p": 655361
        }
      ],
      "n": "StringToSequenceStart",
      "d": 458760,
      "h": 42950131720,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950131720),
//--TRIMMABLE-BOUNDARY-START(38655164424),
    {
      "r": 655361,
      "p": [
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": "StringToSequenceEnd",
      "d": 458760,
      "h": 38655164424,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655164424)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885360648),
    {
      "t": 655361,
      "n": "FlagBitMask",
      "d": 458760,
      "h": 12885360648,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885360648),
//--TRIMMABLE-BOUNDARY-START(17180327944),
    {
      "t": 655361,
      "n": "IndexBitMask",
      "d": 458760,
      "h": 17180327944,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180327944),
//--TRIMMABLE-BOUNDARY-START(4295426056),
    {
      "t": 655361,
      "n": "ArrayEndMask",
      "d": 458760,
      "h": 4295426056,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4295426056),
//--TRIMMABLE-BOUNDARY-START(21475295240),
    {
      "t": 655361,
      "n": "MemoryManagerStartMask",
      "d": 458760,
      "h": 21475295240,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475295240),
//--TRIMMABLE-BOUNDARY-START(34360197128),
    {
      "t": 655361,
      "n": "StringStartMask",
      "d": 458760,
      "h": 34360197128,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360197128),
//--TRIMMABLE-BOUNDARY-START(30065229832),
    {
      "t": 655361,
      "n": "StringEndMask",
      "d": 458760,
      "h": 30065229832,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065229832)
  ],
  "h": 458760
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Buffers.ReadOnlySequence`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458760)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310728)
        $asm.$cls("$sm.System.Text.EncodingExtensions", ($self) => class EncodingExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(55835885576)
            /*int*/ static MaxInputElementsPerIteration = 1048576;
            //--TRIMMABLE-BOUNDARY-END(55835885576)
            
            //--TRIMMABLE-BOUNDARY-START(21476147208)
            static /*long */ GetBytes(/*this Encoding*/ encoding, /*ReadOnlySpan<char>*/ chars, /*IBufferWriter<byte>*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476147208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (chars.Length <= 1048576/*MaxInputElementsPerIteration*/)
                {
                    /*int*/ let byteCount = encoding.GetByteCount$4(chars);
                    /*Span<byte>*/ let scratchBuffer = writer.System$Buffers$IBufferWriter$$$GetSpan(byteCount, [$.$$.System.Byte]);
                    /*int*/ let actualBytesWritten = encoding.GetBytes$5(chars, scratchBuffer);
                    writer.System$Buffers$IBufferWriter$$$Advance(actualBytesWritten, [$.$$.System.Byte]);
                    return BigInt(actualBytesWritten);
                }
                else 
                {
                    /*long*/ let totalBytesWritten;
                    $.$sm.System.Text.EncodingExtensions.Convert$2(encoding.GetEncoder(), chars, writer, true, $.$ref(() => totalBytesWritten, ($v) => totalBytesWritten = $v, $.$$.System.Int64), $.$discardRef());
                    return totalBytesWritten;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476147208)
            
            //--TRIMMABLE-BOUNDARY-START(25771114504)
            static /*long */ GetBytes$2(/*this Encoding*/ encoding, /*in ReadOnlySequence<char>*/ chars, /*IBufferWriter<byte>*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771114504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (chars.$v.IsSingleSegment)
                {
                    return $.$sm.System.Text.EncodingExtensions.GetBytes(encoding, chars.$v.FirstSpan, writer);
                }
                else 
                {
                    /*long*/ let bytesWritten;
                    $.$sm.System.Text.EncodingExtensions.Convert$3(encoding.GetEncoder(), chars, writer, true, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int64), $.$discardRef());
                    return bytesWritten;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25771114504)
            
            //--TRIMMABLE-BOUNDARY-START(30066081800)
            static /*int */ GetBytes$1(/*this Encoding*/ encoding, /*in ReadOnlySequence<char>*/ chars, /*Span<byte>*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066081800);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                if (chars.$v.IsSingleSegment)
                {
                    return encoding.GetBytes$5(chars.$v.FirstSpan, bytes);
                }
                else 
                {
                    /*ReadOnlySequence<char>*/ let remainingChars = chars.$v;
                    /*int*/ let originalBytesLength = bytes.Length;
                    /*Encoder*/ let encoder = encoding.GetEncoder();
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<char>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        remainingChars.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Char)), $.$ref(() => next, ($v) => next = $v, $.$sm.System.SequencePosition));
                        isFinalSegment = remainingChars.IsSingleSegment;
                        /*int*/ let bytesWrittenJustNow = encoder.GetBytes$2(firstSpan, bytes, isFinalSegment);
                        bytes = bytes.Slice$1(bytesWrittenJustNow);
                        remainingChars = remainingChars.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    return ((originalBytesLength - bytes.Length) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30066081800)
            
            //--TRIMMABLE-BOUNDARY-START(34361049096)
            static /*byte[] */ GetBytes$3(/*this Encoding*/ encoding, /*in ReadOnlySequence<char>*/ chars)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361049096);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                if (chars.$v.IsSingleSegment)
                {
                    /*ReadOnlySpan<char>*/ let span = chars.$v.FirstSpan;
                    /*byte[]*/ let retVal = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [encoding.GetByteCount$4(span)], null);
                    encoding.GetBytes$5(span, $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(retVal));
                    return retVal;
                }
                else 
                {
                    /*Encoder*/ let encoder = encoding.GetEncoder();
                    /*List<(byte[], int)>*/ let listOfSegments = new ($.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$typeArray($.$$.System.Byte), $.$$.System.Int32)))().$ctor$1();
                    /*int*/ let totalByteCount = 0;
                    /*ReadOnlySequence<char>*/ let remainingChars = chars.$v;
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<char>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        remainingChars.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Char)), $.$ref(() => next, ($v) => next = $v, $.$sm.System.SequencePosition));
                        isFinalSegment = remainingChars.IsSingleSegment;
                        /*int*/ let byteCountThisIteration = encoder.GetByteCount$2(firstSpan, isFinalSegment);
                        /*byte[]*/ let rentedArray = $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Rent(byteCountThisIteration);
                        /*int*/ let actualBytesWrittenThisIteration = encoder.GetBytes$2(firstSpan, $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(rentedArray), isFinalSegment);
                        listOfSegments.Add(new ($.$$.System.ValueTuple$$$($.$typeArray($.$$.System.Byte), $.$$.System.Int32))().$ctor$3(rentedArray, actualBytesWrittenThisIteration));
                        totalByteCount += actualBytesWrittenThisIteration;
                        if (totalByteCount < 0)
                        {
                            totalByteCount = 2147483647/*int.MaxValue*/;
                            break;
                        }
                        remainingChars = remainingChars.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    /*byte[]*/ let retVal = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [totalByteCount], null);
                    /*Span<byte>*/ let remainingBytes = $.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(retVal);
                    var $en3 = listOfSegments.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var $t1 = $en3.Current;
                        /*byte[]*/ let array = $t1.Item1;
                        /*int*/ let length = $t1.Item2;
                        {
                            $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Byte, array, 0, length).CopyTo(remainingBytes);
                            $.$$.System.Buffers.ArrayPool$$($.$$.System.Byte).Shared.Return(array, false);
                            remainingBytes = remainingBytes.Slice$1(length);
                        }
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(remainingBytes.IsEmpty, "Over-allocated the byte[] instance?");
                    return retVal;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34361049096)
            
            //--TRIMMABLE-BOUNDARY-START(38656016392)
            static /*long */ GetChars(/*this Encoding*/ encoding, /*ReadOnlySpan<byte>*/ bytes, /*IBufferWriter<char>*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656016392);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (bytes.Length <= 1048576/*MaxInputElementsPerIteration*/)
                {
                    /*int*/ let charCount = encoding.GetCharCount$4(bytes);
                    /*Span<char>*/ let scratchBuffer = writer.System$Buffers$IBufferWriter$$$GetSpan(charCount, [$.$$.System.Char]);
                    /*int*/ let actualCharsWritten = encoding.GetChars$5(bytes, scratchBuffer);
                    writer.System$Buffers$IBufferWriter$$$Advance(actualCharsWritten, [$.$$.System.Char]);
                    return BigInt(actualCharsWritten);
                }
                else 
                {
                    /*long*/ let totalCharsWritten;
                    $.$sm.System.Text.EncodingExtensions.Convert(encoding.GetDecoder(), bytes, writer, true, $.$ref(() => totalCharsWritten, ($v) => totalCharsWritten = $v, $.$$.System.Int64), $.$discardRef());
                    return totalCharsWritten;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38656016392)
            
            //--TRIMMABLE-BOUNDARY-START(42950983688)
            static /*long */ GetChars$2(/*this Encoding*/ encoding, /*in ReadOnlySequence<byte>*/ bytes, /*IBufferWriter<char>*/ writer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950983688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                if (bytes.$v.IsSingleSegment)
                {
                    return $.$sm.System.Text.EncodingExtensions.GetChars(encoding, bytes.$v.FirstSpan, writer);
                }
                else 
                {
                    /*long*/ let charsWritten;
                    $.$sm.System.Text.EncodingExtensions.Convert$1(encoding.GetDecoder(), bytes, writer, true, $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int64), $.$discardRef());
                    return charsWritten;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42950983688)
            
            //--TRIMMABLE-BOUNDARY-START(47245950984)
            static /*int */ GetChars$1(/*this Encoding*/ encoding, /*in ReadOnlySequence<byte>*/ bytes, /*Span<char>*/ chars)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245950984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                if (bytes.$v.IsSingleSegment)
                {
                    return encoding.GetChars$5(bytes.$v.FirstSpan, chars);
                }
                else 
                {
                    /*ReadOnlySequence<byte>*/ let remainingBytes = bytes.$v;
                    /*int*/ let originalCharsLength = chars.Length;
                    /*Decoder*/ let decoder = encoding.GetDecoder();
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<byte>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        remainingBytes.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => next, ($v) => next = $v, $.$sm.System.SequencePosition));
                        isFinalSegment = remainingBytes.IsSingleSegment;
                        /*int*/ let charsWrittenJustNow = decoder.GetChars$3(firstSpan, chars, isFinalSegment);
                        chars = chars.Slice$1(charsWrittenJustNow);
                        remainingBytes = remainingBytes.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    return ((originalCharsLength - chars.Length) | 0);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245950984)
            
            //--TRIMMABLE-BOUNDARY-START(51540918280)
            static /*string */ GetString(/*this Encoding*/ encoding, /*in ReadOnlySequence<byte>*/ bytes)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540918280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoding, "encoding");
                if (bytes.$v.IsSingleSegment)
                {
                    return encoding.GetString$3(bytes.$v.FirstSpan);
                }
                else 
                {
                    /*Decoder*/ let decoder = encoding.GetDecoder();
                    /*List<(char[], int)>*/ let listOfSegments = new ($.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$typeArray($.$$.System.Char), $.$$.System.Int32)))().$ctor$1();
                    /*int*/ let totalCharCount = 0;
                    /*ReadOnlySequence<byte>*/ let remainingBytes = bytes.$v;
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<byte>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        remainingBytes.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => next, ($v) => next = $v, $.$sm.System.SequencePosition));
                        isFinalSegment = remainingBytes.IsSingleSegment;
                        /*int*/ let charCountThisIteration = decoder.GetCharCount$3(firstSpan, isFinalSegment);
                        /*char[]*/ let rentedArray = $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Rent(charCountThisIteration);
                        /*int*/ let actualCharsWrittenThisIteration = decoder.GetChars$3(firstSpan, $.$$.System.Span$$($.$$.System.Char).op_Implicit$2(rentedArray), isFinalSegment);
                        listOfSegments.Add(new ($.$$.System.ValueTuple$$$($.$typeArray($.$$.System.Char), $.$$.System.Int32))().$ctor$3(rentedArray, actualCharsWrittenThisIteration));
                        totalCharCount += actualCharsWrittenThisIteration;
                        if (totalCharCount < 0)
                        {
                            totalCharCount = 2147483647/*int.MaxValue*/;
                            break;
                        }
                        remainingBytes = remainingBytes.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    return $.$$.System.String.Create$10($.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$typeArray($.$$.System.Char), $.$$.System.Int32)), totalCharCount, listOfSegments, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$typeArray($.$$.System.Char), $.$$.System.Int32))))().$ctor(this,  (/*span*/ span, /*listOfSegments*/ listOfSegments) =>
                    {
                        var $en4 = listOfSegments.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var $t1 = $en4.Current;
                            /*char[]*/ let array = $t1.Item1;
                            /*int*/ let length = $t1.Item2;
                            {
                                $.$$.System.MemoryExtensions.AsSpan$11($.$$.System.Char, array, 0, length).CopyTo(span);
                                $.$$.System.Buffers.ArrayPool$$($.$$.System.Char).Shared.Return(array, false);
                                span = span.Slice$1(length);
                            }
                        }
                        $.$$.System.Diagnostics.Debug.Assert$2(span.IsEmpty, "Over-allocated the string instance?");
                    }, {
  "r": 65537,
  "p": [
    {
      "n": "span",
      "p": $.$$.System.Span$$($.$$.System.Char).$h
    },
    {
      "n": "listOfSegments",
      "p": $.$$.System.Collections.Generic.List$$($.$$.System.ValueTuple$$$($.$typeArray($.$$.System.Char), $.$$.System.Int32)).$h
    }
  ],
  "n": "",
  "d": 1310728,
  "h": 0,
  "f": 17825794
}));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540918280)
            
            //--TRIMMABLE-BOUNDARY-START(4296278024)
            static /*void */ Convert$2(/*this Encoder*/ encoder, /*ReadOnlySpan<char>*/ chars, /*IBufferWriter<byte>*/ writer, /*bool*/ flush, /*out long*/ bytesUsed, /*out bool*/ completed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(encoder, "encoder");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                /*long*/ let totalBytesWritten = 0n;
                do
                {
                    /*int*/ let byteCountForThisSlice = (chars.Length <= 1048576/*MaxInputElementsPerIteration*/) ? encoder.GetByteCount$2(chars, flush) : encoder.GetByteCount$2(chars.Slice(0, 1048576/*MaxInputElementsPerIteration*/), false);
                    /*Span<byte>*/ let scratchBuffer = writer.System$Buffers$IBufferWriter$$$GetSpan(byteCountForThisSlice, [$.$$.System.Byte]);
                    /*int*/ let charsUsedJustNow;
                    /*int*/ let bytesWrittenJustNow;
                    encoder.Convert$2(chars, scratchBuffer, flush, $.$ref(() => charsUsedJustNow, ($v) => charsUsedJustNow = $v, $.$$.System.Int32), $.$ref(() => bytesWrittenJustNow, ($v) => bytesWrittenJustNow = $v, $.$$.System.Int32), completed);
                    chars = chars.Slice$1(charsUsedJustNow);
                    writer.System$Buffers$IBufferWriter$$$Advance(bytesWrittenJustNow, [$.$$.System.Byte]);
                    totalBytesWritten += BigInt(bytesWrittenJustNow);
                }
                while(!chars.IsEmpty);
                bytesUsed.$v = totalBytesWritten;
            }
            //--TRIMMABLE-BOUNDARY-END(4296278024)
            
            //--TRIMMABLE-BOUNDARY-START(8591245320)
            static /*void */ Convert$3(/*this Encoder*/ encoder, /*in ReadOnlySequence<char>*/ chars, /*IBufferWriter<byte>*/ writer, /*bool*/ flush, /*out long*/ bytesUsed, /*out bool*/ completed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591245320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (chars.$v.IsSingleSegment)
                {
                    $.$sm.System.Text.EncodingExtensions.Convert$2(encoder, chars.$v.FirstSpan, writer, flush, bytesUsed, completed);
                }
                else 
                {
                    /*ReadOnlySequence<char>*/ let remainingChars = chars.$v;
                    /*long*/ let totalBytesWritten = 0n;
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<char>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        remainingChars.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Char)), $.$ref(() => next, ($v) => next = $v, $.$sm.System.SequencePosition));
                        isFinalSegment = remainingChars.IsSingleSegment;
                        /*long*/ let bytesWrittenThisIteration;
                        $.$sm.System.Text.EncodingExtensions.Convert$2(encoder, firstSpan, writer, flush && isFinalSegment, $.$ref(() => bytesWrittenThisIteration, ($v) => bytesWrittenThisIteration = $v, $.$$.System.Int64), completed);
                        totalBytesWritten += bytesWrittenThisIteration;
                        remainingChars = remainingChars.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    bytesUsed.$v = totalBytesWritten;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8591245320)
            
            //--TRIMMABLE-BOUNDARY-START(12886212616)
            static /*void */ Convert(/*this Decoder*/ decoder, /*ReadOnlySpan<byte>*/ bytes, /*IBufferWriter<char>*/ writer, /*bool*/ flush, /*out long*/ charsUsed, /*out bool*/ completed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886212616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(decoder, "decoder");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(writer, "writer");
                /*long*/ let totalCharsWritten = 0n;
                do
                {
                    /*int*/ let charCountForThisSlice = (bytes.Length <= 1048576/*MaxInputElementsPerIteration*/) ? decoder.GetCharCount$3(bytes, flush) : decoder.GetCharCount$3(bytes.Slice(0, 1048576/*MaxInputElementsPerIteration*/), false);
                    /*Span<char>*/ let scratchBuffer = writer.System$Buffers$IBufferWriter$$$GetSpan(charCountForThisSlice, [$.$$.System.Char]);
                    /*int*/ let bytesUsedJustNow;
                    /*int*/ let charsWrittenJustNow;
                    decoder.Convert$2(bytes, scratchBuffer, flush, $.$ref(() => bytesUsedJustNow, ($v) => bytesUsedJustNow = $v, $.$$.System.Int32), $.$ref(() => charsWrittenJustNow, ($v) => charsWrittenJustNow = $v, $.$$.System.Int32), completed);
                    bytes = bytes.Slice$1(bytesUsedJustNow);
                    writer.System$Buffers$IBufferWriter$$$Advance(charsWrittenJustNow, [$.$$.System.Char]);
                    totalCharsWritten += BigInt(charsWrittenJustNow);
                }
                while(!bytes.IsEmpty);
                charsUsed.$v = totalCharsWritten;
            }
            //--TRIMMABLE-BOUNDARY-END(12886212616)
            
            //--TRIMMABLE-BOUNDARY-START(17181179912)
            static /*void */ Convert$1(/*this Decoder*/ decoder, /*in ReadOnlySequence<byte>*/ bytes, /*IBufferWriter<char>*/ writer, /*bool*/ flush, /*out long*/ charsUsed, /*out bool*/ completed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181179912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (bytes.$v.IsSingleSegment)
                {
                    $.$sm.System.Text.EncodingExtensions.Convert(decoder, bytes.$v.FirstSpan, writer, flush, charsUsed, completed);
                }
                else 
                {
                    /*ReadOnlySequence<byte>*/ let remainingBytes = bytes.$v;
                    /*long*/ let totalCharsWritten = 0n;
                    /*bool*/ let isFinalSegment;
                    do
                    {
                        /*ReadOnlySpan<byte>*/ let firstSpan;
                        /*SequencePosition*/ let next;
                        remainingBytes.GetFirstSpan$1($.$ref(() => firstSpan, ($v) => firstSpan = $v, $.$$.System.ReadOnlySpan$$($.$$.System.Byte)), $.$ref(() => next, ($v) => next = $v, $.$sm.System.SequencePosition));
                        isFinalSegment = remainingBytes.IsSingleSegment;
                        /*long*/ let charsWrittenThisIteration;
                        $.$sm.System.Text.EncodingExtensions.Convert(decoder, firstSpan, writer, flush && isFinalSegment, $.$ref(() => charsWrittenThisIteration, ($v) => charsWrittenThisIteration = $v, $.$$.System.Int64), completed);
                        totalCharsWritten += charsWrittenThisIteration;
                        remainingBytes = remainingBytes.Slice$8(next);
                    }
                    while(!isFinalSegment);
                    charsUsed.$v = totalCharsWritten;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17181179912)
            
            static $h = 1310728;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(21476147208),
    {
      "r": 917505,
      "p": [
        {
          "n": "encoding",
          "p": 165806081
        },
        {
          "n": "chars",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "writer",
          "p": $.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte).$h
        }
      ],
      "n": "GetBytes",
      "d": 1310728,
      "h": 21476147208,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21476147208),
//--TRIMMABLE-BOUNDARY-START(25771114504),
    {
      "r": 917505,
      "p": [
        {
          "n": "encoding",
          "p": 165806081
        },
        {
          "n": "chars",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char).$h,
          "f": 8
        },
        {
          "n": "writer",
          "p": $.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte).$h
        }
      ],
      "n": "GetBytes",
      "o": "@$2",
      "d": 1310728,
      "h": 25771114504,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771114504),
//--TRIMMABLE-BOUNDARY-START(30066081800),
    {
      "r": 655361,
      "p": [
        {
          "n": "encoding",
          "p": 165806081
        },
        {
          "n": "chars",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char).$h,
          "f": 8
        },
        {
          "n": "bytes",
          "p": $.$$.System.Span$$($.$$.System.Byte).$h
        }
      ],
      "n": "GetBytes",
      "o": "@$1",
      "d": 1310728,
      "h": 30066081800,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066081800),
//--TRIMMABLE-BOUNDARY-START(34361049096),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "p": [
        {
          "n": "encoding",
          "p": 165806081
        },
        {
          "n": "chars",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char).$h,
          "f": 8
        }
      ],
      "n": "GetBytes",
      "o": "@$3",
      "d": 1310728,
      "h": 34361049096,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34361049096),
//--TRIMMABLE-BOUNDARY-START(38656016392),
    {
      "r": 917505,
      "p": [
        {
          "n": "encoding",
          "p": 165806081
        },
        {
          "n": "bytes",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "writer",
          "p": $.$sm.System.Buffers.IBufferWriter$$($.$$.System.Char).$h
        }
      ],
      "n": "GetChars",
      "d": 1310728,
      "h": 38656016392,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38656016392),
//--TRIMMABLE-BOUNDARY-START(42950983688),
    {
      "r": 917505,
      "p": [
        {
          "n": "encoding",
          "p": 165806081
        },
        {
          "n": "bytes",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,
          "f": 8
        },
        {
          "n": "writer",
          "p": $.$sm.System.Buffers.IBufferWriter$$($.$$.System.Char).$h
        }
      ],
      "n": "GetChars",
      "o": "@$2",
      "d": 1310728,
      "h": 42950983688,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42950983688),
//--TRIMMABLE-BOUNDARY-START(47245950984),
    {
      "r": 655361,
      "p": [
        {
          "n": "encoding",
          "p": 165806081
        },
        {
          "n": "bytes",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,
          "f": 8
        },
        {
          "n": "chars",
          "p": $.$$.System.Span$$($.$$.System.Char).$h
        }
      ],
      "n": "GetChars",
      "o": "@$1",
      "d": 1310728,
      "h": 47245950984,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47245950984),
//--TRIMMABLE-BOUNDARY-START(51540918280),
    {
      "r": 1310721,
      "p": [
        {
          "n": "encoding",
          "p": 165806081
        },
        {
          "n": "bytes",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,
          "f": 8
        }
      ],
      "n": "GetString",
      "d": 1310728,
      "h": 51540918280,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51540918280),
//--TRIMMABLE-BOUNDARY-START(4296278024),
    {
      "r": 65537,
      "p": [
        {
          "n": "encoder",
          "p": 165085185
        },
        {
          "n": "chars",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "writer",
          "p": $.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte).$h
        },
        {
          "n": "flush",
          "p": 262145
        },
        {
          "n": "bytesUsed",
          "p": 917505,
          "f": 2
        },
        {
          "n": "completed",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "Convert",
      "o": "@$2",
      "d": 1310728,
      "h": 4296278024,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4296278024),
//--TRIMMABLE-BOUNDARY-START(8591245320),
    {
      "r": 65537,
      "p": [
        {
          "n": "encoder",
          "p": 165085185
        },
        {
          "n": "chars",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char).$h,
          "f": 8
        },
        {
          "n": "writer",
          "p": $.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte).$h
        },
        {
          "n": "flush",
          "p": 262145
        },
        {
          "n": "bytesUsed",
          "p": 917505,
          "f": 2
        },
        {
          "n": "completed",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "Convert",
      "o": "@$3",
      "d": 1310728,
      "h": 8591245320,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591245320),
//--TRIMMABLE-BOUNDARY-START(12886212616),
    {
      "r": 65537,
      "p": [
        {
          "n": "decoder",
          "p": 164495361
        },
        {
          "n": "bytes",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h
        },
        {
          "n": "writer",
          "p": $.$sm.System.Buffers.IBufferWriter$$($.$$.System.Char).$h
        },
        {
          "n": "flush",
          "p": 262145
        },
        {
          "n": "charsUsed",
          "p": 917505,
          "f": 2
        },
        {
          "n": "completed",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "Convert",
      "d": 1310728,
      "h": 12886212616,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12886212616),
//--TRIMMABLE-BOUNDARY-START(17181179912),
    {
      "r": 65537,
      "p": [
        {
          "n": "decoder",
          "p": 164495361
        },
        {
          "n": "bytes",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Byte).$h,
          "f": 8
        },
        {
          "n": "writer",
          "p": $.$sm.System.Buffers.IBufferWriter$$($.$$.System.Char).$h
        },
        {
          "n": "flush",
          "p": 262145
        },
        {
          "n": "charsUsed",
          "p": 917505,
          "f": 2
        },
        {
          "n": "completed",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "Convert",
      "o": "@$1",
      "d": 1310728,
      "h": 17181179912,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17181179912)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(55835885576),
    {
      "t": 655361,
      "n": "MaxInputElementsPerIteration",
      "d": 1310728,
      "h": 55835885576,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(55835885576)
  ],
  "h": 1310728
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.EncodingExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310728)
        
        
        //--TRIMMABLE-BOUNDARY-START(65544)
        $asm.$cls("$sm.System.Buffers.ArrayBufferWriter<>", (T) => $asm.$gt("$sm.System.Buffers.ArrayBufferWriter<>", [T], ($self) => class ArrayBufferWriter$$ extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(25769869320)
            /*int*/ static ArrayMaxLength = 2147483591;
            //--TRIMMABLE-BOUNDARY-END(25769869320)
            
            //--TRIMMABLE-BOUNDARY-START(42949738504)
            /*int*/ static DefaultInitialBufferSize = 256;
            //--TRIMMABLE-BOUNDARY-END(42949738504)
            
            //--TRIMMABLE-BOUNDARY-START(4295032840)
            /*T[]*/ _buffer = null;
            //--TRIMMABLE-BOUNDARY-END(4295032840)
            
            //--TRIMMABLE-BOUNDARY-START(8590000136)
            /*int*/ _index = 0;
            //--TRIMMABLE-BOUNDARY-END(8590000136)
            
            //--TRIMMABLE-BOUNDARY-START(12884967432)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967432);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._buffer = $.$$.System.Array.Empty(T);
                    this._index = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12884967432)
            
            //--TRIMMABLE-BOUNDARY-START(17179934728)
            $ctor$2(/*int*/ initialCapacity)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17179934728);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (initialCapacity <= 0)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13(null, "initialCapacity");
                    }
                    this._buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf(T), null, [initialCapacity], null);
                    this._index = 0;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17179934728)
            
            //--TRIMMABLE-BOUNDARY-START(120259149832)
            /*ReadOnlyMemory<T> */ get WrittenMemory()
            {
                return $.$$.System.Memory$$(T).op_Implicit$2($.$$.System.MemoryExtensions.AsMemory$9(T, this._buffer, 0, this._index));
            }
            //--TRIMMABLE-BOUNDARY-END(120259149832)
            
            //--TRIMMABLE-BOUNDARY-START(124554117128)
            /*ReadOnlySpan<T> */ get WrittenSpan()
            {
                return $.$$.System.Span$$(T).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11(T, this._buffer, 0, this._index));
            }
            //--TRIMMABLE-BOUNDARY-END(124554117128)
            
            //--TRIMMABLE-BOUNDARY-START(115964182536)
            /*int */ get WrittenCount()
            {
                return this._index;
            }
            //--TRIMMABLE-BOUNDARY-END(115964182536)
            
            //--TRIMMABLE-BOUNDARY-START(30064836616)
            /*int */ get Capacity()
            {
                return this._buffer.length;
            }
            //--TRIMMABLE-BOUNDARY-END(30064836616)
            
            //--TRIMMABLE-BOUNDARY-START(47244705800)
            /*int */ get FreeCapacity()
            {
                return ((this._buffer.length - this._index) | 0);
            }
            //--TRIMMABLE-BOUNDARY-END(47244705800)
            
            //--TRIMMABLE-BOUNDARY-START(38654771208)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(this._buffer.length >= this._index, "_buffer.Length >= _index");
                $.$$.System.MemoryExtensions.AsSpan$11(T, this._buffer, 0, this._index).Clear();
                this._index = 0;
            }
            //--TRIMMABLE-BOUNDARY-END(38654771208)
            
            //--TRIMMABLE-BOUNDARY-START(103079280648)
            /*void */ ResetWrittenCount()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079280648);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._index = 0;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079280648)
            
            //--TRIMMABLE-BOUNDARY-START(21474902024)
            /*void */ Advance(/*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (count < 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13(null, "count");
                }
                if (this._index > ((this._buffer.length - count) | 0))
                {
                    $.$sm.System.Buffers.ArrayBufferWriter$$(T).ThrowInvalidOperationException_AdvancedTooFar(this._buffer.length);
                }
                this._index += count;
            }
            //--TRIMMABLE-BOUNDARY-END(21474902024)
            
            //--TRIMMABLE-BOUNDARY-START(94489346056)
            /*Memory<T> */ GetMemory(/*int*/ sizeHint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489346056);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckAndResizeBuffer(sizeHint);
                $.$$.System.Diagnostics.Debug.Assert$2(this._buffer.length > this._index, "_buffer.Length > _index");
                return $.$$.System.MemoryExtensions.AsMemory$10(T, this._buffer, this._index);
            }
            //--TRIMMABLE-BOUNDARY-END(94489346056)
            
            //--TRIMMABLE-BOUNDARY-START(98784313352)
            /*Span<T> */ GetSpan(/*int*/ sizeHint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784313352);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CheckAndResizeBuffer(sizeHint);
                $.$$.System.Diagnostics.Debug.Assert$2(this._buffer.length > this._index, "_buffer.Length > _index");
                return $.$$.System.MemoryExtensions.AsSpan$12(T, this._buffer, this._index);
            }
            //--TRIMMABLE-BOUNDARY-END(98784313352)
            
            //--TRIMMABLE-BOUNDARY-START(34359803912)
            /*void */ CheckAndResizeBuffer(/*int*/ sizeHint)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (sizeHint < 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$14("sizeHint");
                }
                if (sizeHint === 0)
                {
                    sizeHint = 1;
                }
                if (sizeHint > this.FreeCapacity)
                {
                    /*int*/ let currentLength = this._buffer.length;
                    /*int*/ let growBy = $.$$.System.Math.Max$4(sizeHint, currentLength);
                    if (currentLength === 0)
                    {
                        growBy = $.$$.System.Math.Max$4(growBy, 256/*DefaultInitialBufferSize*/);
                    }
                    /*int*/ let newSize = ((currentLength + growBy) | 0);
                    if ((newSize >>> 0) > 2147483647/*int.MaxValue*/)
                    {
                        /*uint*/ let needed = ((((((currentLength - this.FreeCapacity) | 0) + sizeHint) | 0)) >>> 0);
                        $.$$.System.Diagnostics.Debug.Assert$2(BigInt(needed) > BigInt(currentLength), "needed > currentLength");
                        if (needed > 2147483591/*ArrayMaxLength*/)
                        {
                            $.$sm.System.Buffers.ArrayBufferWriter$$(T).ThrowOutOfMemoryException(needed);
                        }
                        newSize = 2147483591/*ArrayMaxLength*/;
                    }
                    $.$$.System.Array.Resize(T, $.$ref(() => this._buffer, ($v) => this._buffer = $v, $.$typeArray(T)), newSize);
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this.FreeCapacity > 0 && this.FreeCapacity >= sizeHint, "FreeCapacity > 0 && FreeCapacity >= sizeHint");
            }
            //--TRIMMABLE-BOUNDARY-END(34359803912)
            
            //--TRIMMABLE-BOUNDARY-START(107374247944)
            static /*void */ ThrowInvalidOperationException_AdvancedTooFar(/*int*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374247944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.InvalidOperationException().$ctor$12($.$sm.System.SR.Format$6($.$sm.System.SR.BufferWriterAdvancedTooFar, $.$box(capacity, $.$$.System.Int32)));
            }
            //--TRIMMABLE-BOUNDARY-END(107374247944)
            
            //--TRIMMABLE-BOUNDARY-START(111669215240)
            static /*void */ ThrowOutOfMemoryException(/*uint*/ capacity)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669215240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.OutOfMemoryException().$ctor$12($.$sm.System.SR.Format$6($.$sm.System.SR.BufferMaximumSizeExceeded, $.$box(capacity, $.$$.System.UInt32)));
            }
            //--TRIMMABLE-BOUNDARY-END(111669215240)
            
            //--TRIMMABLE-BOUNDARY-START(4295294984)
            //Generated interface implemetation for System.Buffers.IBufferWriter<T>.Advance(int)
            System$Buffers$IBufferWriter$$$Advance()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295294984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Advance(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4295294984)
            
            //--TRIMMABLE-BOUNDARY-START(8590262280)
            //Generated interface implemetation for System.Buffers.IBufferWriter<T>.GetMemory(int)
            System$Buffers$IBufferWriter$$$GetMemory()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590262280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetMemory(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8590262280)
            
            //--TRIMMABLE-BOUNDARY-START(12885229576)
            //Generated interface implemetation for System.Buffers.IBufferWriter<T>.GetSpan(int)
            System$Buffers$IBufferWriter$$$GetSpan()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetSpan(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12885229576)
            
            static $h = 65544;
            static $g = 1;
            static $f = 0b11010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(120259149832),
    {
      "p": $.$$.System.ReadOnlyMemory$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1300000000n),
        "f": 50331649
      },
      "n": "WrittenMemory",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1C00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259149832),
//--TRIMMABLE-BOUNDARY-START(124554117128),
    {
      "p": $.$$.System.ReadOnlySpan$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1500000000n),
        "f": 50331649
      },
      "n": "WrittenSpan",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1D00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124554117128),
//--TRIMMABLE-BOUNDARY-START(115964182536),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1100000000n),
        "f": 50331649
      },
      "n": "WrittenCount",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1B00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964182536),
//--TRIMMABLE-BOUNDARY-START(30064836616),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xD00000000n),
        "f": 50331649
      },
      "n": "Capacity",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30064836616),
//--TRIMMABLE-BOUNDARY-START(47244705800),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0xF00000000n),
        "f": 50331649
      },
      "n": "FreeCapacity",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47244705800)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38654771208),
    {
      "r": 65537,
      "n": "Clear",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38654771208),
//--TRIMMABLE-BOUNDARY-START(103079280648),
    {
      "r": 65537,
      "n": "ResetWrittenCount",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(103079280648),
//--TRIMMABLE-BOUNDARY-START(21474902024),
    {
      "r": 65537,
      "p": [
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Advance",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21474902024),
//--TRIMMABLE-BOUNDARY-START(94489346056),
    {
      "r": $.$$.System.Memory$$(T).$h,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "GetMemory",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(94489346056),
//--TRIMMABLE-BOUNDARY-START(98784313352),
    {
      "r": $.$$.System.Span$$(T).$h,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "GetSpan",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(98784313352),
//--TRIMMABLE-BOUNDARY-START(34359803912),
    {
      "r": 65537,
      "p": [
        {
          "n": "sizeHint",
          "p": 655361
        }
      ],
      "n": "CheckAndResizeBuffer",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34359803912),
//--TRIMMABLE-BOUNDARY-START(107374247944),
    {
      "r": 65537,
      "p": [
        {
          "n": "capacity",
          "p": 655361
        }
      ],
      "n": "ThrowInvalidOperationException_AdvancedTooFar",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1900000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(107374247944),
//--TRIMMABLE-BOUNDARY-START(111669215240),
    {
      "r": 65537,
      "p": [
        {
          "n": "capacity",
          "p": 720897
        }
      ],
      "n": "ThrowOutOfMemoryException",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1A00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(111669215240)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(25769869320),
    {
      "t": 655361,
      "n": "ArrayMaxLength",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(25769869320),
//--TRIMMABLE-BOUNDARY-START(42949738504),
    {
      "t": 655361,
      "n": "DefaultInitialBufferSize",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(42949738504),
//--TRIMMABLE-BOUNDARY-START(4295032840),
    {
      "t": $.$typeArray(T).$h,
      "n": "_buffer",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295032840),
//--TRIMMABLE-BOUNDARY-START(8590000136),
    {
      "t": 655361,
      "n": "_index",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590000136)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12884967432),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12884967432),
//--TRIMMABLE-BOUNDARY-START(17179934728),
    {
      "p": [
        {
          "n": "initialCapacity",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17179934728)
  ],
  "i": [$.$sm.System.Buffers.IBufferWriter$$(T).$h
  ],
  "g": [T?.$h??1507328
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$sm.System.Buffers.IBufferWriter$$(T) ]; }
            static get $fullName() { return `System.Buffers.ArrayBufferWriter<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(65544)
        
        
        //--TRIMMABLE-BOUNDARY-START(917512)
        $asm.$str("$sm.System.Buffers.SequenceReader<>", (T) => $asm.$gt("$sm.System.Buffers.SequenceReader<>", [T], ($self) => class SequenceReader$$ extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295884808)
            /*SequencePosition*/  get _currentPosition() { return this.$getField(0, 8); }
            /*SequencePosition*/  set _currentPosition(value) { this.$setField(0, 8, value); }
            //--TRIMMABLE-BOUNDARY-END(4295884808)
            
            //--TRIMMABLE-BOUNDARY-START(17180786696)
            /*SequencePosition*/  get _nextPosition() { return this.$getField(8, 8); }
            /*SequencePosition*/  set _nextPosition(value) { this.$setField(8, 8, value); }
            //--TRIMMABLE-BOUNDARY-END(17180786696)
            
            //--TRIMMABLE-BOUNDARY-START(12885819400)
            /*bool*/  get _moreData() { return this.$getField(16, 1); }
            /*bool*/  set _moreData(value) { this.$setField(16, 1, value); }
            //--TRIMMABLE-BOUNDARY-END(12885819400)
            
            //--TRIMMABLE-BOUNDARY-START(8590852104)
            /*long*/  get _length() { return this.$getField(17, 8); }
            /*long*/  set _length(value) { this.$setField(17, 8, value); }
            //--TRIMMABLE-BOUNDARY-END(8590852104)
            
            //--TRIMMABLE-BOUNDARY-START(21475753992)
            $ctor$3(/*ReadOnlySequence<T>*/ sequence)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475753992);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this.CurrentSpanIndex = 0;
                    this.Consumed = 0n;
                    this.Sequence = sequence;
                    this._currentPosition = sequence.Start;
                    this._length = BigInt(-1);
                    /*ReadOnlySpan<T>*/ let first;
                    sequence.GetFirstSpan$1($.$ref(() => first, ($v) => first = $v, $.$$.System.ReadOnlySpan$$(T)), $.$ref(() => this._nextPosition, ($v) => this._nextPosition = $v, $.$sm.System.SequencePosition));
                    this.CurrentSpan = first;
                    this._moreData = first.Length > 0;
                    if (!this._moreData && !sequence.IsSingleSegment)
                    {
                        this._moreData = true;
                        this.GetNextSpan();
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475753992)
            
            //--TRIMMABLE-BOUNDARY-START(103080132616)
            /*bool */ get End()
            {
                return !this._moreData;
            }
            //--TRIMMABLE-BOUNDARY-END(103080132616)
            
            //--TRIMMABLE-BOUNDARY-START(236224118792)
            /*ReadOnlySequence<T>*/ Sequence;
            //--TRIMMABLE-BOUNDARY-END(236224118792)
            
            //--TRIMMABLE-BOUNDARY-START(365073137672)
            /*ReadOnlySequence<T> */ get UnreadSequence()
            {
                return this.Sequence.Slice$8(this.Position);
            }
            //--TRIMMABLE-BOUNDARY-END(365073137672)
            
            //--TRIMMABLE-BOUNDARY-START(214749282312)
            /*SequencePosition */ get Position()
            {
                return this.Sequence.GetPosition(BigInt(this.CurrentSpanIndex), this._currentPosition);
            }
            //--TRIMMABLE-BOUNDARY-END(214749282312)
            
            //--TRIMMABLE-BOUNDARY-START(94490198024)
            /*ReadOnlySpan<T>*/ CurrentSpan;
            //--TRIMMABLE-BOUNDARY-END(94490198024)
            
            //--TRIMMABLE-BOUNDARY-START(98785165320)
            /*int*/ CurrentSpanIndex = 0;
            //--TRIMMABLE-BOUNDARY-END(98785165320)
            
            //--TRIMMABLE-BOUNDARY-START(369368104968)
            /*ReadOnlySpan<T> */ get UnreadSpan()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979478536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CurrentSpan.Slice$1(this.CurrentSpanIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(369368104968)
            
            //--TRIMMABLE-BOUNDARY-START(90195230728)
            /*long*/ Consumed = 0n;
            //--TRIMMABLE-BOUNDARY-END(90195230728)
            
            //--TRIMMABLE-BOUNDARY-START(219044249608)
            /*long */ get Remaining()
            {
                return this.Length - this.Consumed;
            }
            //--TRIMMABLE-BOUNDARY-END(219044249608)
            
            //--TRIMMABLE-BOUNDARY-START(210454315016)
            /*long */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029805576);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._length < 0n)
                {
                    $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Int64, () => this, ($v) => $v.Clone(this), 17).$v = this.Sequence.Length;
                }
                return this._length;
            }
            //--TRIMMABLE-BOUNDARY-END(210454315016)
            
            //--TRIMMABLE-BOUNDARY-START(283468759048)
            /*bool */ TryPeek$1(/*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468759048);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._moreData)
                {
                    value.$v = this.CurrentSpan.get_Item(this.CurrentSpanIndex).$v;
                    return true;
                }
                else 
                {
                    value.$v = $.$default(T);
                    return false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(283468759048)
            
            //--TRIMMABLE-BOUNDARY-START(287763726344)
            /*bool */ TryPeek(/*long*/ offset, /*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763726344);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (offset < 0n)
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_OffsetOutOfRange();
                }
                if (!this._moreData || this.Remaining <= offset)
                {
                    value.$v = $.$default(T);
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(BigInt(this.CurrentSpanIndex) + offset >= 0n, "CurrentSpanIndex + offset >= 0");
                if ((BigInt(this.CurrentSpanIndex) + offset) <= BigInt(this.CurrentSpan.Length - 1))
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(offset <= BigInt(2147483647/*int.MaxValue*/), "offset <= int.MaxValue");
                    value.$v = this.CurrentSpan.get_Item(((this.CurrentSpanIndex + $.$cast(offset, $.$$.System.Int32)) | 0)).$v;
                    return true;
                }
                else 
                {
                    /*long*/ let remainingOffset = offset - (BigInt(this.CurrentSpan.Length - this.CurrentSpanIndex));
                    /*SequencePosition*/ let nextPosition = this._nextPosition;
                    /*ReadOnlyMemory<T>*/ let currentMemory;
                    while(this.Sequence.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => nextPosition, ($v) => nextPosition = $v, null), $.$ref(() => currentMemory, ($v) => currentMemory = $v, $.$$.System.ReadOnlyMemory$$(T)), true))
                    {
                        if (currentMemory.Length > 0)
                        {
                            if (remainingOffset >= BigInt(currentMemory.Length))
                            {
                                remainingOffset -= BigInt(currentMemory.Length);
                            }
                            else 
                            {
                                break;
                            }
                        }
                    }
                    value.$v = currentMemory.Span.get_Item($.$cast(remainingOffset, $.$$.System.Int32)).$v;
                    return true;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(287763726344)
            
            //--TRIMMABLE-BOUNDARY-START(292058693640)
            /*bool */ TryRead(/*out T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058693640);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.End)
                {
                    value.$v = $.$default(T);
                    return false;
                }
                value.$v = this.CurrentSpan.get_Item(this.CurrentSpanIndex).$v;
                this.CurrentSpanIndex++;
                this.Consumed++;
                if (this.CurrentSpanIndex >= this.CurrentSpan.Length)
                {
                    this.GetNextSpan();
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(292058693640)
            
            //--TRIMMABLE-BOUNDARY-START(231929151496)
            /*void */ Rewind(/*long*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929151496);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$cast(count, $.$$.System.UInt64) > $.$cast(this.Consumed, $.$$.System.UInt64))
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(15/*ExceptionArgument.count*/);
                }
                if (count === 0n)
                {
                    return;
                }
                this.Consumed -= count;
                if (BigInt(this.CurrentSpanIndex) >= count)
                {
                    this.CurrentSpanIndex -= $.$cast(count, $.$$.System.Int32);
                    this._moreData = true;
                }
                else 
                {
                    this.RetreatToPreviousSpan(this.Consumed);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231929151496)
            
            //--TRIMMABLE-BOUNDARY-START(227634184200)
            /*void */ RetreatToPreviousSpan(/*long*/ consumed)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634184200);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.ResetReader();
                this.Advance(consumed);
            }
            //--TRIMMABLE-BOUNDARY-END(227634184200)
            
            //--TRIMMABLE-BOUNDARY-START(223339216904)
            /*void */ ResetReader()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339216904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.CurrentSpanIndex = 0;
                this.Consumed = 0n;
                this._currentPosition = this.Sequence.Start;
                this._nextPosition = this._currentPosition;
                /*ReadOnlyMemory<T>*/ let memory;
                if (this.Sequence.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => this._nextPosition, ($v) => this._nextPosition = $v, null), $.$ref(() => memory, ($v) => memory = $v, $.$$.System.ReadOnlyMemory$$(T)), true))
                {
                    this._moreData = true;
                    if (memory.Length === 0)
                    {
                        this.CurrentSpan = new ($.$$.System.ReadOnlySpan$$(T))();
                        this.GetNextSpan();
                    }
                    else 
                    {
                        this.CurrentSpan = memory.Span;
                    }
                }
                else 
                {
                    this._moreData = false;
                    this.CurrentSpan = new ($.$$.System.ReadOnlySpan$$(T))();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223339216904)
            
            //--TRIMMABLE-BOUNDARY-START(193274445832)
            /*void */ GetNextSpan()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274445832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!this.Sequence.IsSingleSegment)
                {
                    /*SequencePosition*/ let previousNextPosition = this._nextPosition;
                    /*ReadOnlyMemory<T>*/ let memory;
                    while(this.Sequence.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => this._nextPosition, ($v) => this._nextPosition = $v, null), $.$ref(() => memory, ($v) => memory = $v, $.$$.System.ReadOnlyMemory$$(T)), true))
                    {
                        this._currentPosition = previousNextPosition;
                        if (memory.Length > 0)
                        {
                            this.CurrentSpan = memory.Span;
                            this.CurrentSpanIndex = 0;
                            return;
                        }
                        else 
                        {
                            this.CurrentSpan = new ($.$$.System.ReadOnlySpan$$(T))();
                            this.CurrentSpanIndex = 0;
                            previousNextPosition = this._nextPosition;
                        }
                    }
                }
                this._moreData = false;
            }
            //--TRIMMABLE-BOUNDARY-END(193274445832)
            
            //--TRIMMABLE-BOUNDARY-START(47245557768)
            /*void */ Advance(/*long*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245557768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let TooBigOrNegative = $.$cast(18446744071562067968n, $.$$.System.Int64);
                if ((count & TooBigOrNegative) === 0n && ((this.CurrentSpan.Length - this.CurrentSpanIndex) | 0) > $.$cast(count, $.$$.System.Int32))
                {
                    this.CurrentSpanIndex += $.$cast(count, $.$$.System.Int32);
                    this.Consumed += count;
                }
                else 
                {
                    this.AdvanceToNextSpan(count);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47245557768)
            
            //--TRIMMABLE-BOUNDARY-START(51540525064)
            /*void */ AdvanceCurrentSpan(/*long*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540525064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(count >= 0n, "count >= 0");
                this.Consumed += count;
                this.CurrentSpanIndex += $.$cast(count, $.$$.System.Int32);
                if (this.CurrentSpanIndex >= this.CurrentSpan.Length)
                {
                    this.GetNextSpan();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540525064)
            
            //--TRIMMABLE-BOUNDARY-START(85900263432)
            /*void */ AdvanceWithinSpan(/*long*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900263432);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(count >= 0n, "count >= 0");
                this.Consumed += count;
                this.CurrentSpanIndex += $.$cast(count, $.$$.System.Int32);
                $.$$.System.Diagnostics.Debug.Assert$2(this.CurrentSpanIndex < this.CurrentSpan.Length, "CurrentSpanIndex < CurrentSpan.Length");
            }
            //--TRIMMABLE-BOUNDARY-END(85900263432)
            
            //--TRIMMABLE-BOUNDARY-START(81605296136)
            /*void */ AdvanceToNextSpan(/*long*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605296136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (count < 0n)
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(15/*ExceptionArgument.count*/);
                }
                this.Consumed += count;
                while(this._moreData)
                {
                    /*int*/ let remaining = ((this.CurrentSpan.Length - this.CurrentSpanIndex) | 0);
                    if (BigInt(remaining) > count)
                    {
                        this.CurrentSpanIndex += $.$cast(count, $.$$.System.Int32);
                        count = 0n;
                        break;
                    }
                    this.CurrentSpanIndex += remaining;
                    count -= BigInt(remaining);
                    $.$$.System.Diagnostics.Debug.Assert$2(count >= 0n, "count >= 0");
                    this.GetNextSpan();
                    if (count === 0n)
                    {
                        break;
                    }
                }
                if (count !== 0n)
                {
                    this.Consumed -= count;
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(15/*ExceptionArgument.count*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81605296136)
            
            //--TRIMMABLE-BOUNDARY-START(279173791752)
            /*bool */ TryCopyTo(/*Span<T>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173791752);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let firstSpan = this.UnreadSpan;
                if (firstSpan.Length >= destination.Length)
                {
                    firstSpan.Slice(0, destination.Length).CopyTo(destination);
                    return true;
                }
                return this.TryCopyMultisegment(destination);
            }
            //--TRIMMABLE-BOUNDARY-END(279173791752)
            
            //--TRIMMABLE-BOUNDARY-START(274878824456)
            /*bool */ TryCopyMultisegment(/*Span<T>*/ destination)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878824456);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.Remaining < BigInt(destination.Length))
                {
                    return false;
                }
                /*ReadOnlySpan<T>*/ let firstSpan = this.UnreadSpan;
                $.$$.System.Diagnostics.Debug.Assert$2(firstSpan.Length < destination.Length, "firstSpan.Length < destination.Length");
                firstSpan.CopyTo(destination);
                /*int*/ let copied = firstSpan.Length;
                /*SequencePosition*/ let next = this._nextPosition;
                /*ReadOnlyMemory<T>*/ let nextSegment;
                while(this.Sequence.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => next, ($v) => next = $v, null), $.$ref(() => nextSegment, ($v) => nextSegment = $v, $.$$.System.ReadOnlyMemory$$(T)), true))
                {
                    if (nextSegment.Length > 0)
                    {
                        /*ReadOnlySpan<T>*/ let nextSpan = nextSegment.Span;
                        /*int*/ let toCopy = $.$$.System.Math.Min$4(nextSpan.Length, ((destination.Length - copied) | 0));
                        nextSpan.Slice(0, toCopy).CopyTo(destination.Slice$1(copied));
                        copied += toCopy;
                        if (copied >= destination.Length)
                        {
                            break;
                        }
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(274878824456)
            
            //--TRIMMABLE-BOUNDARY-START(300648628232)
            /*bool */ TryReadTo$1(/*out ReadOnlySpan<T>*/ span, /*T*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648628232);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                if (index !== -1)
                {
                    span.$v = index === 0 ? new ($.$$.System.ReadOnlySpan$$(T))() : remaining.Slice(0, index);
                    this.AdvanceCurrentSpan(BigInt(index + (advancePastDelimiter ? 1 : 0)));
                    return true;
                }
                return this.TryReadToSlow$1(span, delimiter, advancePastDelimiter);
            }
            //--TRIMMABLE-BOUNDARY-END(300648628232)
            
            //--TRIMMABLE-BOUNDARY-START(347893268488)
            /*bool */ TryReadToSlow$1(/*out ReadOnlySpan<T>*/ span, /*T*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347893268488);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySequence<T>*/ let sequence;
                if (!this.TryReadToInternal($.$ref(() => sequence, ($v) => sequence = $v, $.$sm.System.Buffers.ReadOnlySequence$$(T)), delimiter, advancePastDelimiter, ((this.CurrentSpan.Length - this.CurrentSpanIndex) | 0)))
                {
                    span.$v = new ($.$$.System.ReadOnlySpan$$(T))();
                    return false;
                }
                span.$v = sequence.IsSingleSegment ? sequence.First.Span : $.$$.System.ReadOnlySpan$$(T).op_Implicit$1($.$sm.System.Buffers.BuffersExtensions.ToArray(T, $.$ref(() => sequence, )));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(347893268488)
            
            //--TRIMMABLE-BOUNDARY-START(304943595528)
            /*bool */ TryReadTo$2(/*out ReadOnlySpan<T>*/ span, /*T*/ delimiter, /*T*/ delimiterEscape, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943595528);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                if ((index > 0 && !$.$dsp(remaining.get_Item(((index - 1) | 0)).$v, T, ($t) => $t.System$IEquatable$$$Equals, delimiterEscape, [T])) || index === 0)
                {
                    span.$v = remaining.Slice(0, index);
                    this.AdvanceCurrentSpan(BigInt(index + (advancePastDelimiter ? 1 : 0)));
                    return true;
                }
                return this.TryReadToSlow$2(span, delimiter, delimiterEscape, index, advancePastDelimiter);
            }
            //--TRIMMABLE-BOUNDARY-END(304943595528)
            
            //--TRIMMABLE-BOUNDARY-START(352188235784)
            /*bool */ TryReadToSlow$2(/*out ReadOnlySpan<T>*/ span, /*T*/ delimiter, /*T*/ delimiterEscape, /*int*/ index, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352188235784);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySequence<T>*/ let sequence;
                if (!this.TryReadToSlow$3($.$ref(() => sequence, ($v) => sequence = $v, $.$sm.System.Buffers.ReadOnlySequence$$(T)), delimiter, delimiterEscape, index, advancePastDelimiter))
                {
                    span.$v = new ($.$$.System.ReadOnlySpan$$(T))();
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(sequence.Length > 0n, "sequence.Length > 0");
                span.$v = sequence.IsSingleSegment ? sequence.First.Span : $.$$.System.ReadOnlySpan$$(T).op_Implicit$1($.$sm.System.Buffers.BuffersExtensions.ToArray(T, $.$ref(() => sequence, )));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(352188235784)
            
            //--TRIMMABLE-BOUNDARY-START(356483203080)
            /*bool */ TryReadToSlow$3(/*out ReadOnlySequence<T>*/ sequence, /*T*/ delimiter, /*T*/ delimiterEscape, /*int*/ index, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483203080);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SequenceReader<T>*/ let copy = this;
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*bool*/ let priorEscape = false;
                $doJumpStart1: do
                {
                    let $gotoJumpState2 = 0;
                    $gotoJumpStart2: while(true)
                    {
                        switch($gotoJumpState2)
                        {
                            case 0:
                            {
                                if (index >= 0)
                                {
                                    if (index === 0 && priorEscape)
                                    {
                                        priorEscape = false;
                                        this.Advance(BigInt(index + 1));
                                        remaining = this.UnreadSpan;
                                        $gotoJumpState2 = 1; /*goto Continue*/
                                        continue $gotoJumpStart2;
                                    }
                                    else if (index > 0 && $.$dsp(remaining.get_Item(((index - 1) | 0)).$v, T, ($t) => $t.System$IEquatable$$$Equals, delimiterEscape, [T]))
                                    {
                                        /*int*/ let escapeCount = 1;
                                        /*int*/ let i = ((index - 2) | 0);
                                        for(; i >= 0; i--)
                                        {
                                            if (!$.$dsp(remaining.get_Item(i).$v, T, ($t) => $t.System$IEquatable$$$Equals, delimiterEscape, [T]))
                                            {
                                                break;
                                            }
                                        }
                                        if (i < 0 && priorEscape)
                                        {
                                            escapeCount++;
                                        }
                                        escapeCount += ((((index - 2) | 0) - i) | 0);
                                        if ((escapeCount & 1) !== 0)
                                        {
                                            this.Advance(BigInt(index + 1));
                                            priorEscape = false;
                                            remaining = this.UnreadSpan;
                                            $gotoJumpState2 = 1; /*goto Continue*/
                                            continue $gotoJumpStart2;
                                        }
                                    }
                                    this.AdvanceCurrentSpan(BigInt(index));
                                    sequence.$v = this.Sequence.Slice$7(copy.Position, this.Position);
                                    if (advancePastDelimiter)
                                    {
                                        this.Advance(1n);
                                    }
                                    return true;
                                }
                                else 
                                {
                                    if ($.$$.System.MemoryExtensions.EndsWith$4(T, remaining, delimiterEscape))
                                    {
                                        /*int*/ let escapeCount = 1;
                                        /*int*/ let i = ((remaining.Length - 2) | 0);
                                        for(; i >= 0; i--)
                                        {
                                            if (!$.$dsp(remaining.get_Item(i).$v, T, ($t) => $t.System$IEquatable$$$Equals, delimiterEscape, [T]))
                                            {
                                                break;
                                            }
                                        }
                                        escapeCount += ((((remaining.Length - 2) | 0) - i) | 0);
                                        if (i < 0 && priorEscape)
                                        {
                                            priorEscape = (escapeCount & 1) === 0;
                                        }
                                        else 
                                        {
                                            priorEscape = (escapeCount & 1) !== 0;
                                        }
                                    }
                                    else 
                                    {
                                        priorEscape = false;
                                    }
                                }
                                this.AdvanceCurrentSpan(BigInt(remaining.Length));
                                remaining = this.CurrentSpan;
                            }
                            case 1: /*Continue*/
                            index = $.$$.System.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                        }
                        break;
                    }
                }
                while(!this.End);
                copy.Clone(this);
                sequence.$v = new ($.$sm.System.Buffers.ReadOnlySequence$$(T))();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(356483203080)
            
            //--TRIMMABLE-BOUNDARY-START(309238562824)
            /*bool */ TryReadTo$4(/*out ReadOnlySequence<T>*/ sequence, /*T*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238562824);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryReadToInternal(sequence, delimiter, advancePastDelimiter, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(309238562824)
            
            //--TRIMMABLE-BOUNDARY-START(343598301192)
            /*bool */ TryReadToInternal(/*out ReadOnlySequence<T>*/ sequence, /*T*/ delimiter, /*bool*/ advancePastDelimiter, /*int*/ skip)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343598301192);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(skip >= 0, "skip >= 0");
                /*SequenceReader<T>*/ let copy = this;
                if (skip > 0)
                {
                    this.Advance(BigInt(skip));
                }
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                while(this._moreData)
                {
                    /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                    if (index !== -1)
                    {
                        if (index > 0)
                        {
                            this.AdvanceCurrentSpan(BigInt(index));
                        }
                        sequence.$v = this.Sequence.Slice$7(copy.Position, this.Position);
                        if (advancePastDelimiter)
                        {
                            this.Advance(1n);
                        }
                        return true;
                    }
                    this.AdvanceCurrentSpan(BigInt(remaining.Length));
                    remaining = this.CurrentSpan;
                }
                copy.Clone(this);
                sequence.$v = new ($.$sm.System.Buffers.ReadOnlySequence$$(T))();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(343598301192)
            
            //--TRIMMABLE-BOUNDARY-START(313533530120)
            /*bool */ TryReadTo$5(/*out ReadOnlySequence<T>*/ sequence, /*T*/ delimiter, /*T*/ delimiterEscape, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533530120);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SequenceReader<T>*/ let copy = this;
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*bool*/ let priorEscape = false;
                while(this._moreData)
                {
                    /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                    if (index !== -1)
                    {
                        if (index === 0 && priorEscape)
                        {
                            priorEscape = false;
                            this.Advance(BigInt(index + 1));
                            remaining = this.UnreadSpan;
                            continue;
                        }
                        else if (index > 0 && $.$dsp(remaining.get_Item(((index - 1) | 0)).$v, T, ($t) => $t.System$IEquatable$$$Equals, delimiterEscape, [T]))
                        {
                            /*int*/ let escapeCount = 0;
                            for(/*int*/ let i = index; i > 0 && $.$dsp(remaining.get_Item(((i - 1) | 0)).$v, T, ($t) => $t.System$IEquatable$$$Equals, delimiterEscape, [T]); i--, escapeCount++)
                            {
                            }
                            if (escapeCount === index && priorEscape)
                            {
                                escapeCount++;
                            }
                            priorEscape = false;
                            if ((escapeCount & 1) !== 0)
                            {
                                this.Advance(BigInt(index + 1));
                                remaining = this.UnreadSpan;
                                continue;
                            }
                        }
                        if (index > 0)
                        {
                            this.Advance(BigInt(index));
                        }
                        sequence.$v = this.Sequence.Slice$7(copy.Position, this.Position);
                        if (advancePastDelimiter)
                        {
                            this.Advance(1n);
                        }
                        return true;
                    }
                    {
                        /*int*/ let escapeCount = 0;
                        for(/*int*/ let i = remaining.Length; i > 0 && $.$dsp(remaining.get_Item(((i - 1) | 0)).$v, T, ($t) => $t.System$IEquatable$$$Equals, delimiterEscape, [T]); i--, escapeCount++)
                        {
                        }
                        if (priorEscape && escapeCount === remaining.Length)
                        {
                            escapeCount++;
                        }
                        priorEscape = escapeCount % 2 !== 0;
                    }
                    this.Advance(BigInt(remaining.Length));
                    remaining = this.CurrentSpan;
                }
                copy.Clone(this);
                sequence.$v = new ($.$sm.System.Buffers.ReadOnlySequence$$(T))();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(313533530120)
            
            //--TRIMMABLE-BOUNDARY-START(326418432008)
            /*bool */ TryReadToAny(/*out ReadOnlySpan<T>*/ span, /*scoped ReadOnlySpan<T>*/ delimiters, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418432008);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = delimiters.Length === 2 ? $.$$.System.MemoryExtensions.IndexOfAny$8(T, remaining, delimiters.get_Item(0).$v, delimiters.get_Item(1).$v) : $.$$.System.MemoryExtensions.IndexOfAny$4(T, remaining, delimiters);
                if (index !== -1)
                {
                    span.$v = remaining.Slice(0, index);
                    this.Advance(BigInt(index + (advancePastDelimiter ? 1 : 0)));
                    return true;
                }
                return this.TryReadToAnySlow(span, delimiters, advancePastDelimiter);
            }
            //--TRIMMABLE-BOUNDARY-END(326418432008)
            
            //--TRIMMABLE-BOUNDARY-START(339303333896)
            /*bool */ TryReadToAnySlow(/*out ReadOnlySpan<T>*/ span, /*scoped ReadOnlySpan<T>*/ delimiters, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303333896);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySequence<T>*/ let sequence;
                if (!this.TryReadToAnyInternal($.$ref(() => sequence, ($v) => sequence = $v, $.$sm.System.Buffers.ReadOnlySequence$$(T)), delimiters, advancePastDelimiter, ((this.CurrentSpan.Length - this.CurrentSpanIndex) | 0)))
                {
                    span.$v = new ($.$$.System.ReadOnlySpan$$(T))();
                    return false;
                }
                span.$v = sequence.IsSingleSegment ? sequence.First.Span : $.$$.System.ReadOnlySpan$$(T).op_Implicit$1($.$sm.System.Buffers.BuffersExtensions.ToArray(T, $.$ref(() => sequence, )));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(339303333896)
            
            //--TRIMMABLE-BOUNDARY-START(330713399304)
            /*bool */ TryReadToAny$1(/*out ReadOnlySequence<T>*/ sequence, /*scoped ReadOnlySpan<T>*/ delimiters, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713399304);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.TryReadToAnyInternal(sequence, delimiters, advancePastDelimiter, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(330713399304)
            
            //--TRIMMABLE-BOUNDARY-START(335008366600)
            /*bool */ TryReadToAnyInternal(/*out ReadOnlySequence<T>*/ sequence, /*scoped ReadOnlySpan<T>*/ delimiters, /*bool*/ advancePastDelimiter, /*int*/ skip)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335008366600);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SequenceReader<T>*/ let copy = this;
                if (skip > 0)
                {
                    this.Advance(BigInt(skip));
                }
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                while(!this.End)
                {
                    /*int*/ let index = delimiters.Length === 2 ? $.$$.System.MemoryExtensions.IndexOfAny$8(T, remaining, delimiters.get_Item(0).$v, delimiters.get_Item(1).$v) : $.$$.System.MemoryExtensions.IndexOfAny$4(T, remaining, delimiters);
                    if (index !== -1)
                    {
                        if (index > 0)
                        {
                            this.AdvanceCurrentSpan(BigInt(index));
                        }
                        sequence.$v = this.Sequence.Slice$7(copy.Position, this.Position);
                        if (advancePastDelimiter)
                        {
                            this.Advance(1n);
                        }
                        return true;
                    }
                    this.Advance(BigInt(remaining.Length));
                    remaining = this.CurrentSpan;
                }
                copy.Clone(this);
                sequence.$v = new ($.$sm.System.Buffers.ReadOnlySequence$$(T))();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(335008366600)
            
            //--TRIMMABLE-BOUNDARY-START(317828497416)
            /*bool */ TryReadTo(/*out ReadOnlySpan<T>*/ span, /*scoped ReadOnlySpan<T>*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828497416);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$2(T, remaining, delimiter);
                if (index >= 0)
                {
                    span.$v = remaining.Slice(0, index);
                    this.AdvanceCurrentSpan(BigInt(index + (advancePastDelimiter ? delimiter.Length : 0)));
                    return true;
                }
                return this.TryReadToSlow(span, delimiter, advancePastDelimiter);
            }
            //--TRIMMABLE-BOUNDARY-END(317828497416)
            
            //--TRIMMABLE-BOUNDARY-START(360778170376)
            /*bool */ TryReadToSlow(/*out ReadOnlySpan<T>*/ span, /*scoped ReadOnlySpan<T>*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360778170376);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySequence<T>*/ let sequence;
                if (!this.TryReadTo$3($.$ref(() => sequence, ($v) => sequence = $v, $.$sm.System.Buffers.ReadOnlySequence$$(T)), delimiter, advancePastDelimiter))
                {
                    span.$v = new ($.$$.System.ReadOnlySpan$$(T))();
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(sequence.Length > 0n, "sequence.Length > 0");
                span.$v = sequence.IsSingleSegment ? sequence.First.Span : $.$$.System.ReadOnlySpan$$(T).op_Implicit$1($.$sm.System.Buffers.BuffersExtensions.ToArray(T, $.$ref(() => sequence, )));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(360778170376)
            
            //--TRIMMABLE-BOUNDARY-START(322123464712)
            /*bool */ TryReadTo$3(/*out ReadOnlySequence<T>*/ sequence, /*scoped ReadOnlySpan<T>*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123464712);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (delimiter.Length === 0)
                {
                    sequence.$v = new ($.$sm.System.Buffers.ReadOnlySequence$$(T))();
                    return true;
                }
                /*SequenceReader<T>*/ let copy = this;
                /*bool*/ let advanced = false;
                while(!this.End)
                {
                    if (!this.TryReadTo$4(sequence, delimiter.get_Item(0).$v, false))
                    {
                        copy.Clone(this);
                        return false;
                    }
                    if (delimiter.Length === 1)
                    {
                        if (advancePastDelimiter)
                        {
                            this.Advance(1n);
                        }
                        return true;
                    }
                    if (this.IsNext(delimiter, false))
                    {
                        if (advanced)
                        {
                            sequence.$v = copy.Sequence.Slice$2(copy.Consumed, this.Consumed - copy.Consumed);
                        }
                        if (advancePastDelimiter)
                        {
                            this.Advance(BigInt(delimiter.Length));
                        }
                        return true;
                    }
                    else 
                    {
                        this.Advance(1n);
                        advanced = true;
                    }
                }
                copy.Clone(this);
                sequence.$v = new ($.$sm.System.Buffers.ReadOnlySequence$$(T))();
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(322123464712)
            
            //--TRIMMABLE-BOUNDARY-START(296353660936)
            /*bool */ TryReadExact(/*int*/ count, /*out ReadOnlySequence<T>*/ sequence)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353660936);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (count < 0)
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(15/*ExceptionArgument.count*/);
                }
                if (BigInt(count) > this.Remaining)
                {
                    sequence.$v = new ($.$sm.System.Buffers.ReadOnlySequence$$(T))();
                    return false;
                }
                sequence.$v = this.Sequence.Slice$5(this.Position, count);
                if (count !== 0)
                {
                    this.Advance(BigInt(count));
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(296353660936)
            
            //--TRIMMABLE-BOUNDARY-START(266288889864)
            /*bool */ TryAdvanceTo(/*T*/ delimiter, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288889864);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = $.$$.System.MemoryExtensions.IndexOf$4(T, remaining, delimiter);
                if (index !== -1)
                {
                    this.Advance(BigInt(advancePastDelimiter ? ((index + 1) | 0) : index));
                    return true;
                }
                return this.TryReadToInternal($.$discardRef(), delimiter, advancePastDelimiter, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(266288889864)
            
            //--TRIMMABLE-BOUNDARY-START(270583857160)
            /*bool */ TryAdvanceToAny(/*scoped ReadOnlySpan<T>*/ delimiters, /*bool*/ advancePastDelimiter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583857160);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let remaining = this.UnreadSpan;
                /*int*/ let index = $.$$.System.MemoryExtensions.IndexOfAny$4(T, remaining, delimiters);
                if (index !== -1)
                {
                    this.AdvanceCurrentSpan(BigInt(index + (advancePastDelimiter ? 1 : 0)));
                    return true;
                }
                return this.TryReadToAnyInternal($.$discardRef(), delimiters, advancePastDelimiter, 0);
            }
            //--TRIMMABLE-BOUNDARY-END(270583857160)
            
            //--TRIMMABLE-BOUNDARY-START(55835492360)
            /*long */ AdvancePast(/*T*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835492360);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let start = this.Consumed;
                do
                {
                    /*int*/ let i;
                    for(i = this.CurrentSpanIndex; i < this.CurrentSpan.Length && $.$dsp(this.CurrentSpan.get_Item(i).$v, T, ($t) => $t.System$IEquatable$$$Equals, value, [T]); i++)
                    {
                    }
                    /*int*/ let advanced = ((i - this.CurrentSpanIndex) | 0);
                    if (advanced === 0)
                    {
                        break;
                    }
                    this.AdvanceCurrentSpan(BigInt(advanced));
                }
                while(this.CurrentSpanIndex === 0 && !this.End);
                return this.Consumed - start;
            }
            //--TRIMMABLE-BOUNDARY-END(55835492360)
            
            //--TRIMMABLE-BOUNDARY-START(60130459656)
            /*long */ AdvancePastAny(/*scoped ReadOnlySpan<T>*/ values)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130459656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let start = this.Consumed;
                do
                {
                    /*int*/ let i;
                    for(i = this.CurrentSpanIndex; i < this.CurrentSpan.Length && $.$$.System.MemoryExtensions.IndexOf$4(T, values, this.CurrentSpan.get_Item(i).$v) !== -1; i++)
                    {
                    }
                    /*int*/ let advanced = ((i - this.CurrentSpanIndex) | 0);
                    if (advanced === 0)
                    {
                        break;
                    }
                    this.AdvanceCurrentSpan(BigInt(advanced));
                }
                while(this.CurrentSpanIndex === 0 && !this.End);
                return this.Consumed - start;
            }
            //--TRIMMABLE-BOUNDARY-END(60130459656)
            
            //--TRIMMABLE-BOUNDARY-START(64425426952)
            /*long */ AdvancePastAny$1(/*T*/ value0, /*T*/ value1, /*T*/ value2, /*T*/ value3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425426952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let start = this.Consumed;
                do
                {
                    /*int*/ let i;
                    for(i = this.CurrentSpanIndex; i < this.CurrentSpan.Length; i++)
                    {
                        /*T*/ let value = this.CurrentSpan.get_Item(i).$v;
                        if (!$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value0, [T]) && !$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value1, [T]) && !$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value2, [T]) && !$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value3, [T]))
                        {
                            break;
                        }
                    }
                    /*int*/ let advanced = ((i - this.CurrentSpanIndex) | 0);
                    if (advanced === 0)
                    {
                        break;
                    }
                    this.AdvanceCurrentSpan(BigInt(advanced));
                }
                while(this.CurrentSpanIndex === 0 && !this.End);
                return this.Consumed - start;
            }
            //--TRIMMABLE-BOUNDARY-END(64425426952)
            
            //--TRIMMABLE-BOUNDARY-START(68720394248)
            /*long */ AdvancePastAny$2(/*T*/ value0, /*T*/ value1, /*T*/ value2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720394248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let start = this.Consumed;
                do
                {
                    /*int*/ let i;
                    for(i = this.CurrentSpanIndex; i < this.CurrentSpan.Length; i++)
                    {
                        /*T*/ let value = this.CurrentSpan.get_Item(i).$v;
                        if (!$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value0, [T]) && !$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value1, [T]) && !$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value2, [T]))
                        {
                            break;
                        }
                    }
                    /*int*/ let advanced = ((i - this.CurrentSpanIndex) | 0);
                    if (advanced === 0)
                    {
                        break;
                    }
                    this.AdvanceCurrentSpan(BigInt(advanced));
                }
                while(this.CurrentSpanIndex === 0 && !this.End);
                return this.Consumed - start;
            }
            //--TRIMMABLE-BOUNDARY-END(68720394248)
            
            //--TRIMMABLE-BOUNDARY-START(73015361544)
            /*long */ AdvancePastAny$3(/*T*/ value0, /*T*/ value1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015361544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*long*/ let start = this.Consumed;
                do
                {
                    /*int*/ let i;
                    for(i = this.CurrentSpanIndex; i < this.CurrentSpan.Length; i++)
                    {
                        /*T*/ let value = this.CurrentSpan.get_Item(i).$v;
                        if (!$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value0, [T]) && !$.$dsp(value, T, ($t) => $t.System$IEquatable$$$Equals, value1, [T]))
                        {
                            break;
                        }
                    }
                    /*int*/ let advanced = ((i - this.CurrentSpanIndex) | 0);
                    if (advanced === 0)
                    {
                        break;
                    }
                    this.AdvanceCurrentSpan(BigInt(advanced));
                }
                while(this.CurrentSpanIndex === 0 && !this.End);
                return this.Consumed - start;
            }
            //--TRIMMABLE-BOUNDARY-END(73015361544)
            
            //--TRIMMABLE-BOUNDARY-START(77310328840)
            /*void */ AdvanceToEnd()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310328840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this._moreData)
                {
                    this.Consumed = this.Length;
                    this.CurrentSpan = new ($.$$.System.ReadOnlySpan$$(T))();
                    this.CurrentSpanIndex = 0;
                    this._currentPosition = this.Sequence.End;
                    this._nextPosition = new $.$sm.System.SequencePosition();
                    this._moreData = false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77310328840)
            
            //--TRIMMABLE-BOUNDARY-START(197569413128)
            /*bool */ IsNext$1(/*T*/ next, /*bool*/ advancePast)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569413128);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.End)
                {
                    return false;
                }
                if ($.$dsp(this.CurrentSpan.get_Item(this.CurrentSpanIndex).$v, T, ($t) => $t.System$IEquatable$$$Equals, next, [T]))
                {
                    if (advancePast)
                    {
                        this.AdvanceCurrentSpan(1n);
                    }
                    return true;
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(197569413128)
            
            //--TRIMMABLE-BOUNDARY-START(201864380424)
            /*bool */ IsNext(/*scoped ReadOnlySpan<T>*/ next, /*bool*/ advancePast)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864380424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let unread = this.UnreadSpan;
                if ($.$$.System.MemoryExtensions.StartsWith$2(T, unread, next))
                {
                    if (advancePast)
                    {
                        this.AdvanceCurrentSpan(BigInt(next.Length));
                    }
                    return true;
                }
                return unread.Length < next.Length && this.IsNextSlow(next, advancePast);
            }
            //--TRIMMABLE-BOUNDARY-END(201864380424)
            
            //--TRIMMABLE-BOUNDARY-START(206159347720)
            /*bool */ IsNextSlow(/*scoped ReadOnlySpan<T>*/ next, /*bool*/ advancePast)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159347720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ReadOnlySpan<T>*/ let currentSpan = this.UnreadSpan;
                $.$$.System.Diagnostics.Debug.Assert$2(currentSpan.Length < next.Length, "currentSpan.Length < next.Length");
                /*int*/ let fullLength = next.Length;
                /*SequencePosition*/ let nextPosition = this._nextPosition;
                while($.$$.System.MemoryExtensions.StartsWith$2(T, next, currentSpan))
                {
                    if (next.Length === currentSpan.Length)
                    {
                        if (advancePast)
                        {
                            this.Advance(BigInt(fullLength));
                        }
                        return true;
                    }
                    while(true)
                    {
                        /*ReadOnlyMemory<T>*/ let nextSegment;
                        if (!this.Sequence.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => nextPosition, ($v) => nextPosition = $v, null), $.$ref(() => nextSegment, ($v) => nextSegment = $v, $.$$.System.ReadOnlyMemory$$(T)), true))
                        {
                            return false;
                        }
                        if (nextSegment.Length > 0)
                        {
                            next = next.Slice$1(currentSpan.Length);
                            currentSpan = nextSegment.Span;
                            if (currentSpan.Length > next.Length)
                            {
                                currentSpan = currentSpan.Slice(0, next.Length);
                            }
                            break;
                        }
                    }
                }
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(206159347720)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._currentPosition = this._currentPosition.Clone();
                copy._nextPosition = this._nextPosition.Clone();
                copy._moreData = this._moreData;
                copy._length = this._length;
                copy.Sequence = this.Sequence.Clone();
                copy.CurrentSpan = this.CurrentSpan.Clone();
                copy.CurrentSpanIndex = this.CurrentSpanIndex;
                copy.Consumed = this.Consumed;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(4295884808)
                this._currentPosition = $.$default($.$sm.System.SequencePosition);
                //--TRIMMABLE-BOUNDARY-END(4295884808)
                
                //--TRIMMABLE-BOUNDARY-START(17180786696)
                this._nextPosition = $.$default($.$sm.System.SequencePosition);
                //--TRIMMABLE-BOUNDARY-END(17180786696)
                
                //--TRIMMABLE-BOUNDARY-START(12885819400)
                this._moreData = false;
                //--TRIMMABLE-BOUNDARY-END(12885819400)
                
                //--TRIMMABLE-BOUNDARY-START(8590852104)
                this._length = 0n;
                //--TRIMMABLE-BOUNDARY-END(8590852104)
                
                this.Sequence = $.$default($.$sm.System.Buffers.ReadOnlySequence$$(T));
                this.CurrentSpan = $.$default($.$$.System.ReadOnlySpan$$(T));
            }
            static $h = 917512;
            static $g = 1;
            static $z = 58;
            static $f = 0b1011000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(103080132616),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2000000000n),
        "f": 50331649
      },
      "n": "End",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1800000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080132616),
//--TRIMMABLE-BOUNDARY-START(236224118792),
    {
      "p": $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2800000000n),
        "f": 50331649
      },
      "n": "Sequence",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(236224118792),
//--TRIMMABLE-BOUNDARY-START(365073137672),
    {
      "p": $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2A00000000n),
        "f": 50331649
      },
      "n": "UnreadSequence",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(365073137672),
//--TRIMMABLE-BOUNDARY-START(214749282312),
    {
      "p": 1179656,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2400000000n),
        "f": 50331649
      },
      "n": "Position",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214749282312),
//--TRIMMABLE-BOUNDARY-START(94490198024),
    {
      "p": $.$$.System.ReadOnlySpan$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1C00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x3B00000000n),
        "f": 83886082
      },
      "n": "CurrentSpan",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94490198024),
//--TRIMMABLE-BOUNDARY-START(98785165320),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1E00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x3D00000000n),
        "f": 83886082
      },
      "n": "CurrentSpanIndex",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1700000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98785165320),
//--TRIMMABLE-BOUNDARY-START(369368104968),
    {
      "p": $.$$.System.ReadOnlySpan$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2C00000000n),
        "f": 50331649
      },
      "n": "UnreadSpan",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(369368104968),
//--TRIMMABLE-BOUNDARY-START(90195230728),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x3900000000n),
        "f": 83886082
      },
      "n": "Consumed",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1500000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90195230728),
//--TRIMMABLE-BOUNDARY-START(219044249608),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2600000000n),
        "f": 50331649
      },
      "n": "Remaining",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219044249608),
//--TRIMMABLE-BOUNDARY-START(210454315016),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2200000000n),
        "f": 50331649
      },
      "n": "Length",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210454315016)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(283468759048),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryPeek",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(283468759048),
//--TRIMMABLE-BOUNDARY-START(287763726344),
    {
      "r": 262145,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "value",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryPeek",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(287763726344),
//--TRIMMABLE-BOUNDARY-START(292058693640),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": T?.$h??1507328,
          "f": 2
        }
      ],
      "n": "TryRead",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(292058693640),
//--TRIMMABLE-BOUNDARY-START(231929151496),
    {
      "r": 65537,
      "p": [
        {
          "n": "count",
          "p": 917505
        }
      ],
      "n": "Rewind",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(231929151496),
//--TRIMMABLE-BOUNDARY-START(227634184200),
    {
      "r": 65537,
      "p": [
        {
          "n": "consumed",
          "p": 917505
        }
      ],
      "n": "RetreatToPreviousSpan",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3500000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(227634184200),
//--TRIMMABLE-BOUNDARY-START(223339216904),
    {
      "r": 65537,
      "n": "ResetReader",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(223339216904),
//--TRIMMABLE-BOUNDARY-START(193274445832),
    {
      "r": 65537,
      "n": "GetNextSpan",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2D00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(193274445832),
//--TRIMMABLE-BOUNDARY-START(47245557768),
    {
      "r": 65537,
      "p": [
        {
          "n": "count",
          "p": 917505
        }
      ],
      "n": "Advance",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245557768),
//--TRIMMABLE-BOUNDARY-START(51540525064),
    {
      "r": 65537,
      "p": [
        {
          "n": "count",
          "p": 917505
        }
      ],
      "n": "AdvanceCurrentSpan",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(51540525064),
//--TRIMMABLE-BOUNDARY-START(85900263432),
    {
      "r": 65537,
      "p": [
        {
          "n": "count",
          "p": 917505
        }
      ],
      "n": "AdvanceWithinSpan",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1400000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(85900263432),
//--TRIMMABLE-BOUNDARY-START(81605296136),
    {
      "r": 65537,
      "p": [
        {
          "n": "count",
          "p": 917505
        }
      ],
      "n": "AdvanceToNextSpan",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(81605296136),
//--TRIMMABLE-BOUNDARY-START(279173791752),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.System.Span$$(T).$h
        }
      ],
      "n": "TryCopyTo",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(279173791752),
//--TRIMMABLE-BOUNDARY-START(274878824456),
    {
      "r": 262145,
      "p": [
        {
          "n": "destination",
          "p": $.$$.System.Span$$(T).$h
        }
      ],
      "n": "TryCopyMultisegment",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4000000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(274878824456),
//--TRIMMABLE-BOUNDARY-START(300648628232),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.System.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": T?.$h??1507328
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryReadTo",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(300648628232),
//--TRIMMABLE-BOUNDARY-START(347893268488),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.System.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": T?.$h??1507328
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145
        }
      ],
      "n": "TryReadToSlow",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5100000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(347893268488),
//--TRIMMABLE-BOUNDARY-START(304943595528),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.System.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": T?.$h??1507328
        },
        {
          "n": "delimiterEscape",
          "p": T?.$h??1507328
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryReadTo",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(304943595528),
//--TRIMMABLE-BOUNDARY-START(352188235784),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.System.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": T?.$h??1507328
        },
        {
          "n": "delimiterEscape",
          "p": T?.$h??1507328
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145
        }
      ],
      "n": "TryReadToSlow",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5200000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(352188235784),
//--TRIMMABLE-BOUNDARY-START(356483203080),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": T?.$h??1507328
        },
        {
          "n": "delimiterEscape",
          "p": T?.$h??1507328
        },
        {
          "n": "index",
          "p": 655361
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145
        }
      ],
      "n": "TryReadToSlow",
      "o": "@$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(356483203080),
//--TRIMMABLE-BOUNDARY-START(309238562824),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": T?.$h??1507328
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryReadTo",
      "o": "@$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(309238562824),
//--TRIMMABLE-BOUNDARY-START(343598301192),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": T?.$h??1507328
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145
        },
        {
          "n": "skip",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "TryReadToInternal",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5000000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(343598301192),
//--TRIMMABLE-BOUNDARY-START(313533530120),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": T?.$h??1507328
        },
        {
          "n": "delimiterEscape",
          "p": T?.$h??1507328
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryReadTo",
      "o": "@$5",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(313533530120),
//--TRIMMABLE-BOUNDARY-START(326418432008),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.System.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiters",
          "p": $.$$.System.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryReadToAny",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4C00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(326418432008),
//--TRIMMABLE-BOUNDARY-START(339303333896),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.System.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiters",
          "p": $.$$.System.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145
        }
      ],
      "n": "TryReadToAnySlow",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4F00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(339303333896),
//--TRIMMABLE-BOUNDARY-START(330713399304),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiters",
          "p": $.$$.System.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryReadToAny",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4D00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(330713399304),
//--TRIMMABLE-BOUNDARY-START(335008366600),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiters",
          "p": $.$$.System.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145
        },
        {
          "n": "skip",
          "p": 655361,
          "f": 65,
          "v": 0
        }
      ],
      "n": "TryReadToAnyInternal",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4E00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(335008366600),
//--TRIMMABLE-BOUNDARY-START(317828497416),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.System.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": $.$$.System.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryReadTo",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4A00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(317828497416),
//--TRIMMABLE-BOUNDARY-START(360778170376),
    {
      "r": 262145,
      "p": [
        {
          "n": "span",
          "p": $.$$.System.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": $.$$.System.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145
        }
      ],
      "n": "TryReadToSlow",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x5400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(360778170376),
//--TRIMMABLE-BOUNDARY-START(322123464712),
    {
      "r": 262145,
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
          "f": 2
        },
        {
          "n": "delimiter",
          "p": $.$$.System.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryReadTo",
      "o": "@$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4B00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(322123464712),
//--TRIMMABLE-BOUNDARY-START(296353660936),
    {
      "r": 262145,
      "p": [
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "sequence",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
          "f": 2
        }
      ],
      "n": "TryReadExact",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(296353660936),
//--TRIMMABLE-BOUNDARY-START(266288889864),
    {
      "r": 262145,
      "p": [
        {
          "n": "delimiter",
          "p": T?.$h??1507328
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryAdvanceTo",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3E00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(266288889864),
//--TRIMMABLE-BOUNDARY-START(270583857160),
    {
      "r": 262145,
      "p": [
        {
          "n": "delimiters",
          "p": $.$$.System.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePastDelimiter",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryAdvanceToAny",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3F00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(270583857160),
//--TRIMMABLE-BOUNDARY-START(55835492360),
    {
      "r": 917505,
      "p": [
        {
          "n": "value",
          "p": T?.$h??1507328
        }
      ],
      "n": "AdvancePast",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(55835492360),
//--TRIMMABLE-BOUNDARY-START(60130459656),
    {
      "r": 917505,
      "p": [
        {
          "n": "values",
          "p": $.$$.System.ReadOnlySpan$$(T).$h
        }
      ],
      "n": "AdvancePastAny",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130459656),
//--TRIMMABLE-BOUNDARY-START(64425426952),
    {
      "r": 917505,
      "p": [
        {
          "n": "value0",
          "p": T?.$h??1507328
        },
        {
          "n": "value1",
          "p": T?.$h??1507328
        },
        {
          "n": "value2",
          "p": T?.$h??1507328
        },
        {
          "n": "value3",
          "p": T?.$h??1507328
        }
      ],
      "n": "AdvancePastAny",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(64425426952),
//--TRIMMABLE-BOUNDARY-START(68720394248),
    {
      "r": 917505,
      "p": [
        {
          "n": "value0",
          "p": T?.$h??1507328
        },
        {
          "n": "value1",
          "p": T?.$h??1507328
        },
        {
          "n": "value2",
          "p": T?.$h??1507328
        }
      ],
      "n": "AdvancePastAny",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1000000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(68720394248),
//--TRIMMABLE-BOUNDARY-START(73015361544),
    {
      "r": 917505,
      "p": [
        {
          "n": "value0",
          "p": T?.$h??1507328
        },
        {
          "n": "value1",
          "p": T?.$h??1507328
        }
      ],
      "n": "AdvancePastAny",
      "o": "@$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(73015361544),
//--TRIMMABLE-BOUNDARY-START(77310328840),
    {
      "r": 65537,
      "n": "AdvanceToEnd",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310328840),
//--TRIMMABLE-BOUNDARY-START(197569413128),
    {
      "r": 262145,
      "p": [
        {
          "n": "next",
          "p": T?.$h??1507328
        },
        {
          "n": "advancePast",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "IsNext",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2E00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(197569413128),
//--TRIMMABLE-BOUNDARY-START(201864380424),
    {
      "r": 262145,
      "p": [
        {
          "n": "next",
          "p": $.$$.System.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePast",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "IsNext",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2F00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(201864380424),
//--TRIMMABLE-BOUNDARY-START(206159347720),
    {
      "r": 262145,
      "p": [
        {
          "n": "next",
          "p": $.$$.System.ReadOnlySpan$$(T).$h
        },
        {
          "n": "advancePast",
          "p": 262145
        }
      ],
      "n": "IsNextSlow",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3000000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(206159347720)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295884808),
    {
      "t": 1179656,
      "n": "_currentPosition",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884808),
//--TRIMMABLE-BOUNDARY-START(17180786696),
    {
      "t": 1179656,
      "n": "_nextPosition",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180786696),
//--TRIMMABLE-BOUNDARY-START(12885819400),
    {
      "t": 262145,
      "n": "_moreData",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885819400),
//--TRIMMABLE-BOUNDARY-START(8590852104),
    {
      "t": 917505,
      "n": "_length",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852104)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21475753992),
    {
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475753992),
//--TRIMMABLE-BOUNDARY-START(25770721288),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770721288)
  ],
  "g": [T?.$h??1507328
  ],
  "s": [
    {
      "n": "T",
      "f": 10,
      "c": [$.$$.System.IEquatable$$(T).$h
      ]
    }
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Buffers.SequenceReader<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(917512)
        
        
        //--TRIMMABLE-BOUNDARY-START(524296)
        $asm.$str("$sm.System.Buffers.ReadOnlySequence<>", (T) => $asm.$gt("$sm.System.Buffers.ReadOnlySequence<>", [T], ($self) => class ReadOnlySequence$$ extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(304943202312)
            /*bool */ TryGetBuffer(/*in SequencePosition*/ position, /*out ReadOnlyMemory<T>*/ memory, /*out SequencePosition*/ next)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943202312);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let positionObject = position.$v.GetObject();
                next.$v = new $.$sm.System.SequencePosition();
                if (positionObject === null)
                {
                    memory.$v = new ($.$$.System.ReadOnlyMemory$$(T))();
                    return false;
                }
                /*SequenceType*/ let type = this.GetSequenceType();
                /*object?*/ let endObject = this._endObject;
                /*int*/ let startIndex = position.$v.GetInteger();
                /*int*/ let endIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                if (type === 0/*SequenceType.MultiSegment*/)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$is(positionObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T)), "positionObject is ReadOnlySequenceSegment<T>");
                    /*ReadOnlySequenceSegment<T>*/ let startSegment = $.$cast(positionObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                    if (startSegment !== endObject)
                    {
                        /*ReadOnlySequenceSegment<T>?*/ let nextSegment = startSegment.Next;
                        if (nextSegment === null)
                        {
                            $.$sm.System.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                        }
                        next.$v = new $.$sm.System.SequencePosition().$ctor$3(nextSegment, 0);
                        memory.$v = startSegment.Memory.Slice$1(startIndex);
                    }
                    else 
                    {
                        memory.$v = startSegment.Memory.Slice(startIndex, ((endIndex - startIndex) | 0));
                    }
                }
                else 
                {
                    if (positionObject !== endObject)
                    {
                        $.$sm.System.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                    }
                    if (type === 1/*SequenceType.Array*/)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$is(positionObject, $.$typeArray(T)), "positionObject is T[]");
                        memory.$v = new ($.$$.System.ReadOnlyMemory$$(T))().$ctor$4($.$cast(positionObject, $.$typeArray(T)), startIndex, ((endIndex - startIndex) | 0));
                    }
                    else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Char.$type) && type === 3/*SequenceType.String*/)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2($.$is(positionObject, $.$$.System.String), "positionObject is string");
                        memory.$v = $.$cast($.$cast($.$$.System.MemoryExtensions.AsMemory$1(($.$cast(positionObject, $.$$.System.String)), startIndex, ((endIndex - startIndex) | 0)), $.$$.System.Object), $.$$.System.ReadOnlyMemory$$(T));
                    }
                    else 
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(type === 2/*SequenceType.MemoryManager*/, "type == SequenceType.MemoryManager");
                        $.$$.System.Diagnostics.Debug.Assert$2($.$is(positionObject, $.$$.System.Buffers.MemoryManager$$(T)), "positionObject is MemoryManager<T>");
                        memory.$v = $.$$.System.Memory$$(T).op_Implicit$2(($.$cast(positionObject, $.$$.System.Buffers.MemoryManager$$(T))).Memory.Slice(startIndex, ((endIndex - startIndex) | 0)));
                    }
                }
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(304943202312)
            
            //--TRIMMABLE-BOUNDARY-START(150324379656)
            /*ReadOnlyMemory<T> */ GetFirstBuffer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324379656);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let startObject = this._startObject;
                if (startObject === null)
                {
                    return new ($.$$.System.ReadOnlyMemory$$(T))();
                }
                /*int*/ let startIndex = this._startInteger;
                /*int*/ let endIndex = this._endInteger;
                /*bool*/ let isMultiSegment = startObject !== this._endObject;
                if ((startIndex | endIndex) >= 0)
                {
                    /*ReadOnlyMemory<T>*/ let memory = ($.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).Memory;
                    if (isMultiSegment)
                    {
                        return memory.Slice$1(startIndex);
                    }
                    return memory.Slice(startIndex, ((endIndex - startIndex) | 0));
                }
                else 
                {
                    return this.GetFirstBufferSlow(startObject, isMultiSegment);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324379656)
            
            //--TRIMMABLE-BOUNDARY-START(154619346952)
            /*ReadOnlyMemory<T> */ GetFirstBufferSlow(/*object*/ startObject, /*bool*/ isMultiSegment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619346952);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (isMultiSegment)
                {
                    $.$sm.System.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                }
                /*int*/ let startIndex = this._startInteger;
                /*int*/ let endIndex = this._endInteger;
                $.$$.System.Diagnostics.Debug.Assert$2(startIndex < 0 || endIndex < 0, "startIndex < 0 || endIndex < 0");
                if (startIndex >= 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(endIndex < 0, "endIndex < 0");
                    return new ($.$$.System.ReadOnlyMemory$$(T))().$ctor$4($.$cast(startObject, $.$typeArray(T)), startIndex, (((endIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/) - startIndex) | 0));
                }
                else 
                {
                    if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Char.$type) && endIndex < 0)
                    {
                        return $.$cast($.$cast($.$$.System.MemoryExtensions.AsMemory$1(($.$cast(startObject, $.$$.System.String)), startIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/, ((endIndex - startIndex) | 0)), $.$$.System.Object), $.$$.System.ReadOnlyMemory$$(T));
                    }
                    else 
                    {
                        startIndex &= 2147483647/*ReadOnlySequence.IndexBitMask*/;
                        return $.$$.System.Memory$$(T).op_Implicit$2(($.$cast(startObject, $.$$.System.Buffers.MemoryManager$$(T))).Memory.Slice(startIndex, ((endIndex - startIndex) | 0)));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154619346952)
            
            //--TRIMMABLE-BOUNDARY-START(158914314248)
            /*ReadOnlySpan<T> */ GetFirstSpan()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914314248);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let startObject = this._startObject;
                if (startObject === null)
                {
                    return new ($.$$.System.ReadOnlySpan$$(T))();
                }
                /*int*/ let startIndex = this._startInteger;
                /*int*/ let endIndex = this._endInteger;
                /*bool*/ let isMultiSegment = startObject !== this._endObject;
                if ((startIndex | endIndex) >= 0)
                {
                    /*ReadOnlySpan<T>*/ let span = ($.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).Memory.Span;
                    if (isMultiSegment)
                    {
                        return span.Slice$1(startIndex);
                    }
                    return span.Slice(startIndex, ((endIndex - startIndex) | 0));
                }
                else 
                {
                    return this.GetFirstSpanSlow(startObject, isMultiSegment);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158914314248)
            
            //--TRIMMABLE-BOUNDARY-START(167504248840)
            /*ReadOnlySpan<T> */ GetFirstSpanSlow(/*object*/ startObject, /*bool*/ isMultiSegment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504248840);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (isMultiSegment)
                {
                    $.$sm.System.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                }
                /*int*/ let startIndex = this._startInteger;
                /*int*/ let endIndex = this._endInteger;
                $.$$.System.Diagnostics.Debug.Assert$2(startIndex < 0 || endIndex < 0, "startIndex < 0 || endIndex < 0");
                if (startIndex >= 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(endIndex < 0, "endIndex < 0");
                    /*ReadOnlySpan<T>*/ let span = $.$$.System.ReadOnlySpan$$(T).op_Implicit$1($.$cast(startObject, $.$typeArray(T)));
                    return span.Slice(startIndex, (((endIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/) - startIndex) | 0));
                }
                else 
                {
                    if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Char.$type) && endIndex < 0)
                    {
                        /*var*/ let memory = $.$cast($.$cast($.$$.System.MemoryExtensions.AsMemory$4(($.$cast(startObject, $.$$.System.String))), $.$$.System.Object), $.$$.System.ReadOnlyMemory$$(T));
                        return memory.Span.Slice(startIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/, ((endIndex - startIndex) | 0));
                    }
                    else 
                    {
                        startIndex &= 2147483647/*ReadOnlySequence.IndexBitMask*/;
                        return $.$$.System.Span$$(T).op_Implicit(($.$cast(startObject, $.$$.System.Buffers.MemoryManager$$(T))).Memory.Span.Slice(startIndex, ((endIndex - startIndex) | 0)));
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167504248840)
            
            //--TRIMMABLE-BOUNDARY-START(223338823688)
            /*SequencePosition */ Seek(/*long*/ offset, /*ExceptionArgument*/ exceptionArgument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338823688);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let startObject;
                /*object?*/ let endObject;
                /*int*/ let startIndex;
                /*int*/ let endIndex;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            startObject = this._startObject;
                            endObject = this._endObject;
                            startIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                            endIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                            if (startObject !== endObject)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(startObject !== null, "startObject != null");
                                /*var*/ let startSegment = $.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                                /*int*/ let currentLength = ((startSegment.Memory.Length - startIndex) | 0);
                                if (BigInt(currentLength) > offset || offset === 0n)
                                {
                                    $gotoJumpState1 = 1; /*goto IsSingleSegment*/
                                    continue $gotoJumpStart1;
                                }
                                if (currentLength < 0)
                                {
                                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                return $.$sm.System.Buffers.ReadOnlySequence$$(T).SeekMultiSegment(startSegment.Next, endObject, endIndex, offset - BigInt(currentLength), exceptionArgument);
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2(startObject === endObject, "startObject == endObject");
                            if (BigInt(endIndex - startIndex) < offset)
                            {
                                $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(exceptionArgument);
                            }
                        }
                        case 1: /*IsSingleSegment*/
                        return new $.$sm.System.SequencePosition().$ctor$3(startObject, ((startIndex + $.$cast(offset, $.$$.System.Int32)) | 0));
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(223338823688)
            
            //--TRIMMABLE-BOUNDARY-START(227633790984)
            /*SequencePosition */ Seek$1(/*in SequencePosition*/ start, /*long*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633790984);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let startObject;
                /*object?*/ let endObject;
                /*int*/ let startIndex;
                /*int*/ let endIndex;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            startObject = start.$v.GetObject();
                            endObject = this._endObject;
                            startIndex = start.$v.GetInteger();
                            endIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                            if (startObject !== endObject)
                            {
                                $.$$.System.Diagnostics.Debug.Assert$2(startObject !== null, "startObject != null");
                                /*var*/ let startSegment = $.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                                /*int*/ let currentLength = ((startSegment.Memory.Length - startIndex) | 0);
                                if (BigInt(currentLength) > offset)
                                {
                                    $gotoJumpState1 = 1; /*goto IsSingleSegment*/
                                    continue $gotoJumpStart1;
                                }
                                if (currentLength < 0)
                                {
                                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                return $.$sm.System.Buffers.ReadOnlySequence$$(T).SeekMultiSegment(startSegment.Next, endObject, endIndex, offset - BigInt(currentLength), 7/*ExceptionArgument.offset*/);
                            }
                            $.$$.System.Diagnostics.Debug.Assert$2(startObject === endObject, "startObject == endObject");
                            if (BigInt(endIndex - startIndex) < offset)
                            {
                                $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(7/*ExceptionArgument.offset*/);
                            }
                        }
                        case 1: /*IsSingleSegment*/
                        return new $.$sm.System.SequencePosition().$ctor$3(startObject, ((startIndex + $.$cast(offset, $.$$.System.Int32)) | 0));
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(227633790984)
            
            //--TRIMMABLE-BOUNDARY-START(231928758280)
            static /*SequencePosition */ SeekMultiSegment(/*ReadOnlySequenceSegment<T>?*/ currentSegment, /*object*/ endObject, /*int*/ endIndex, /*long*/ offset, /*ExceptionArgument*/ argument)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928758280);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(currentSegment !== null, "currentSegment != null");
                            $.$$.System.Diagnostics.Debug.Assert$2(offset >= 0n, "offset >= 0");
                            while(currentSegment !== null && currentSegment !== endObject)
                            {
                                /*int*/ let memoryLength = currentSegment.Memory.Length;
                                if (BigInt(memoryLength) > offset)
                                {
                                    $gotoJumpState1 = 1; /*goto FoundSegment*/
                                    continue $gotoJumpStart1;
                                }
                                offset -= BigInt(memoryLength);
                                currentSegment = currentSegment.Next;
                            }
                            if (currentSegment === null || BigInt(endIndex) < offset)
                            {
                                $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(argument);
                            }
                        }
                        case 1: /*FoundSegment*/
                        return new $.$sm.System.SequencePosition().$ctor$3(currentSegment, $.$cast(offset, $.$$.System.Int32));
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(231928758280)
            
            //--TRIMMABLE-BOUNDARY-START(51540131848)
            /*void */ BoundsCheck$1(/*in SequencePosition*/ position, /*bool*/ positionIsNotNull)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540131848);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let sliceStartIndex = (position.$v.GetInteger() >>> 0);
                /*object?*/ let startObject = this._startObject;
                /*object?*/ let endObject = this._endObject;
                /*uint*/ let startIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger) >>> 0);
                /*uint*/ let endIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger) >>> 0);
                if (startObject === endObject)
                {
                    if (!$.$sm.System.Buffers.ReadOnlySequence$$(T).InRange(sliceStartIndex, startIndex, endIndex))
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                }
                else 
                {
                    /*ulong*/ let startRange = $.$cast((($.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(startIndex)), $.$$.System.UInt64);
                    /*long*/ let runningIndex = 0n;
                    if (positionIsNotNull)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(position.$v.GetObject() !== null, "position.GetObject() != null");
                        runningIndex = ($.$cast(position.$v.GetObject(), $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex;
                    }
                    if (!$.$sm.System.Buffers.ReadOnlySequence$$(T).InRange$1($.$cast((runningIndex + BigInt(sliceStartIndex)), $.$$.System.UInt64), startRange, $.$cast((($.$cast(endObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(endIndex)), $.$$.System.UInt64)))
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51540131848)
            
            //--TRIMMABLE-BOUNDARY-START(55835099144)
            /*void */ BoundsCheck(/*uint*/ sliceStartIndex, /*object?*/ sliceStartObject, /*uint*/ sliceEndIndex, /*object?*/ sliceEndObject)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835099144);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let startObject = this._startObject;
                /*object?*/ let endObject = this._endObject;
                /*uint*/ let startIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger) >>> 0);
                /*uint*/ let endIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger) >>> 0);
                if (startObject === endObject)
                {
                    if (sliceStartObject !== sliceEndObject || sliceStartObject !== startObject || sliceStartIndex > sliceEndIndex || sliceStartIndex < startIndex || sliceEndIndex > endIndex)
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(sliceStartIndex >= 0 && startIndex >= 0 && endIndex >= 0, "sliceStartIndex >= 0 && startIndex >= 0 && endIndex >= 0");
                    /*ulong*/ let sliceStartRange = BigInt(sliceStartIndex);
                    /*ulong*/ let sliceEndRange = BigInt(sliceEndIndex);
                    if (sliceStartObject !== null)
                    {
                        sliceStartRange += $.$cast(($.$cast(sliceStartObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex, $.$$.System.UInt64);
                    }
                    if (sliceEndObject !== null)
                    {
                        sliceEndRange += $.$cast(($.$cast(sliceEndObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex, $.$$.System.UInt64);
                    }
                    if (sliceStartRange > sliceEndRange)
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                    if (sliceStartRange < $.$cast((($.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(startIndex)), $.$$.System.UInt64) || sliceEndRange > $.$cast((($.$cast(endObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(endIndex)), $.$$.System.UInt64))
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55835099144)
            
            //--TRIMMABLE-BOUNDARY-START(141734445064)
            static /*SequencePosition */ GetEndPosition(/*ReadOnlySequenceSegment<T>*/ startSegment, /*object*/ startObject, /*int*/ startIndex, /*object*/ endObject, /*int*/ endIndex, /*long*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734445064);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let currentLength = ((startSegment.Memory.Length - startIndex) | 0);
                if (BigInt(currentLength) > length)
                {
                    return new $.$sm.System.SequencePosition().$ctor$3(startObject, ((startIndex + $.$cast(length, $.$$.System.Int32)) | 0));
                }
                if (currentLength < 0)
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                }
                return $.$sm.System.Buffers.ReadOnlySequence$$(T).SeekMultiSegment(startSegment.Next, endObject, endIndex, length - BigInt(currentLength), 0/*ExceptionArgument.length*/);
            }
            //--TRIMMABLE-BOUNDARY-END(141734445064)
            
            //--TRIMMABLE-BOUNDARY-START(197569019912)
            /*SequenceType */ GetSequenceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569019912);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$cast((-(((((2 * (this._startInteger >> 31)) | 0) + (this._endInteger >> 31)) | 0))), $.$sm.System.Buffers.ReadOnlySequence$$(T).SequenceType);
            }
            //--TRIMMABLE-BOUNDARY-END(197569019912)
            
            //--TRIMMABLE-BOUNDARY-START(176094183432)
            static /*int */ GetIndex(/*int*/ Integer)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(176094183432);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return Integer & 2147483647/*ReadOnlySequence.IndexBitMask*/;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(176094183432)
            
            //--TRIMMABLE-BOUNDARY-START(279173398536)
            /*ReadOnlySequence<T> */ SliceImpl(/*in SequencePosition*/ start, /*in SequencePosition*/ end)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173398536);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$sm.System.Buffers.ReadOnlySequence$$(T))().$ctor$3(start.$v.GetObject(), start.$v.GetInteger() | (this._startInteger & -2147483648/*ReadOnlySequence.FlagBitMask*/), end.$v.GetObject(), end.$v.GetInteger() | (this._endInteger & -2147483648/*ReadOnlySequence.FlagBitMask*/));
            }
            //--TRIMMABLE-BOUNDARY-END(279173398536)
            
            //--TRIMMABLE-BOUNDARY-START(283468365832)
            /*ReadOnlySequence<T> */ SliceImpl$1(/*in SequencePosition*/ start)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283468365832);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new ($.$sm.System.Buffers.ReadOnlySequence$$(T))().$ctor$3(start.$v.GetObject(), start.$v.GetInteger() | (this._startInteger & -2147483648/*ReadOnlySequence.FlagBitMask*/), this._endObject, this._endInteger);
            }
            //--TRIMMABLE-BOUNDARY-END(283468365832)
            
            //--TRIMMABLE-BOUNDARY-START(180389150728)
            /*long */ GetLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389150728);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let startObject = this._startObject;
                /*object?*/ let endObject = this._endObject;
                /*int*/ let startIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                /*int*/ let endIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                if (startObject !== endObject)
                {
                    /*var*/ let startSegment = $.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                    /*var*/ let endSegment = $.$cast(endObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                    return (endSegment.RunningIndex + BigInt(endIndex)) - (startSegment.RunningIndex + BigInt(startIndex));
                }
                return BigInt(endIndex - startIndex);
            }
            //--TRIMMABLE-BOUNDARY-END(180389150728)
            
            //--TRIMMABLE-BOUNDARY-START(309238169608)
            /*bool */ TryGetReadOnlySequenceSegment(/*out ReadOnlySequenceSegment<T>?*/ startSegment, /*out int*/ startIndex, /*out ReadOnlySequenceSegment<T>?*/ endSegment, /*out int*/ endIndex)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238169608);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let startObject = this._startObject;
                if (startObject === null || this.GetSequenceType() !== 0/*SequenceType.MultiSegment*/)
                {
                    startSegment.$v = null;
                    startIndex.$v = 0;
                    endSegment.$v = null;
                    endIndex.$v = 0;
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this._endObject !== null, "_endObject != null");
                startSegment.$v = $.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                startIndex.$v = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                endSegment.$v = $.$cast(this._endObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                endIndex.$v = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(309238169608)
            
            //--TRIMMABLE-BOUNDARY-START(300648235016)
            /*bool */ TryGetArray(/*out ArraySegment<T>*/ segment)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648235016);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (this.GetSequenceType() !== 1/*SequenceType.Array*/)
                {
                    segment.$v = new ($.$$.System.ArraySegment$$(T))();
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this._startObject !== null, "_startObject != null");
                /*int*/ let startIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                segment.$v = new ($.$$.System.ArraySegment$$(T))().$ctor$3($.$cast(this._startObject, $.$typeArray(T)), startIndex, (($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger) - startIndex) | 0));
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(300648235016)
            
            //--TRIMMABLE-BOUNDARY-START(313533136904)
            /*bool */ TryGetString(/*out string?*/ text, /*out int*/ start, /*out int*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533136904);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Inequality$1(T.$type, $.$$.System.Char.$type) || this.GetSequenceType() !== 3/*SequenceType.String*/)
                {
                    start.$v = 0;
                    length.$v = 0;
                    text.$v = null;
                    return false;
                }
                $.$$.System.Diagnostics.Debug.Assert$2(this._startObject !== null, "_startObject != null");
                start.$v = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                length.$v = (($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger) - start.$v) | 0);
                text.$v = $.$cast(this._startObject, $.$$.System.String);
                return true;
            }
            //--TRIMMABLE-BOUNDARY-END(313533136904)
            
            //--TRIMMABLE-BOUNDARY-START(201863987208)
            static /*bool */ InRange(/*uint*/ value, /*uint*/ start, /*uint*/ end)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863987208);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(start <= 2147483647/*int.MaxValue*/, "start <= int.MaxValue");
                $.$$.System.Diagnostics.Debug.Assert$2(end <= 2147483647/*int.MaxValue*/, "end <= int.MaxValue");
                $.$$.System.Diagnostics.Debug.Assert$2(start <= end, "start <= end");
                return ((((value - start) >>> 0)) >>> 0) <= ((((end - start) >>> 0)) >>> 0);
            }
            //--TRIMMABLE-BOUNDARY-END(201863987208)
            
            //--TRIMMABLE-BOUNDARY-START(206158954504)
            static /*bool */ InRange$1(/*ulong*/ value, /*ulong*/ start, /*ulong*/ end)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158954504);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(start <= 9223372036854775807n, "start <= long.MaxValue");
                $.$$.System.Diagnostics.Debug.Assert$2(end <= 9223372036854775807n, "end <= long.MaxValue");
                $.$$.System.Diagnostics.Debug.Assert$2(start <= end, "start <= end");
                return (value - start) <= (end - start);
            }
            //--TRIMMABLE-BOUNDARY-END(206158954504)
            
            //--TRIMMABLE-BOUNDARY-START(163209281544)
            /*void */ GetFirstSpan$1(/*out ReadOnlySpan<T>*/ first, /*out SequencePosition*/ next)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209281544);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                first.$v = new ($.$$.System.ReadOnlySpan$$(T))();
                next.$v = new $.$sm.System.SequencePosition();
                /*object?*/ let startObject = this._startObject;
                /*int*/ let startIndex = this._startInteger;
                if (startObject !== null)
                {
                    /*bool*/ let hasMultipleSegments = startObject !== this._endObject;
                    /*int*/ let endIndex = this._endInteger;
                    if (startIndex >= 0)
                    {
                        if (endIndex >= 0)
                        {
                            /*ReadOnlySequenceSegment<T>*/ let segment = $.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                            first.$v = segment.Memory.Span;
                            if (hasMultipleSegments)
                            {
                                first.$v = first.$v.Slice$1(startIndex);
                                next.$v = new $.$sm.System.SequencePosition().$ctor$3(segment.Next, 0);
                            }
                            else 
                            {
                                first.$v = first.$v.Slice(startIndex, ((endIndex - startIndex) | 0));
                            }
                        }
                        else 
                        {
                            if (hasMultipleSegments)
                            {
                                $.$sm.System.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                            }
                            first.$v = new ($.$$.System.ReadOnlySpan$$(T))().$ctor$3($.$cast(startObject, $.$typeArray(T)), startIndex, (((endIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/) - startIndex) | 0));
                        }
                    }
                    else 
                    {
                        first.$v = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetFirstSpanSlow$1(startObject, startIndex, endIndex, hasMultipleSegments);
                    }
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163209281544)
            
            //--TRIMMABLE-BOUNDARY-START(171799216136)
            static /*ReadOnlySpan<T> */ GetFirstSpanSlow$1(/*object*/ startObject, /*int*/ startIndex, /*int*/ endIndex, /*bool*/ hasMultipleSegments)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799216136);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(startIndex < 0, "startIndex < 0");
                if (hasMultipleSegments)
                {
                    $.$sm.System.ThrowHelper.ThrowInvalidOperationException_EndPositionNotReached();
                }
                if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Char.$type) && endIndex < 0)
                {
                    /*ReadOnlySpan<char>*/ let spanOfChar = $.$$.System.MemoryExtensions.AsSpan$1(($.$cast(startObject, $.$$.System.String)), startIndex & 2147483647/*ReadOnlySequence.IndexBitMask*/, ((endIndex - startIndex) | 0));
                    return $.$$.System.Runtime.InteropServices.MemoryMarshal.CreateReadOnlySpan(T, $.$$.System.Runtime.CompilerServices.Unsafe.As($.$$.System.Char, T, $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Char, spanOfChar)), spanOfChar.Length);
                }
                else 
                {
                    startIndex &= 2147483647/*ReadOnlySequence.IndexBitMask*/;
                    return $.$$.System.Span$$(T).op_Implicit(($.$cast(startObject, $.$$.System.Buffers.MemoryManager$$(T))).Memory.Span.Slice(startIndex, ((endIndex - startIndex) | 0)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(171799216136)
            
            //--TRIMMABLE-BOUNDARY-START(17180393480)
            /*object?*/  get _startObject() { return this.$getField(0, 4); }
            /*object?*/  set _startObject(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(17180393480)
            
            //--TRIMMABLE-BOUNDARY-START(8590458888)
            /*object?*/  get _endObject() { return this.$getField(4, 4); }
            /*object?*/  set _endObject(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8590458888)
            
            //--TRIMMABLE-BOUNDARY-START(12885426184)
            /*int*/  get _startInteger() { return this.$getField(8, 4); }
            /*int*/  set _startInteger(value) { this.$setField(8, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(12885426184)
            
            //--TRIMMABLE-BOUNDARY-START(4295491592)
            /*int*/  get _endInteger() { return this.$getField(12, 4); }
            /*int*/  set _endInteger(value) { this.$setField(12, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4295491592)
            
            //--TRIMMABLE-BOUNDARY-START(60130066440)
            /*ReadOnlySequence<T>*/ static Empty;
            //--TRIMMABLE-BOUNDARY-END(60130066440)
            
            //--TRIMMABLE-BOUNDARY-START(219043856392)
            /*long */ get Length()
            {
                return this.GetLength();
            }
            //--TRIMMABLE-BOUNDARY-END(219043856392)
            
            //--TRIMMABLE-BOUNDARY-START(210453921800)
            /*bool */ get IsEmpty()
            {
                return this.Length === 0n;
            }
            //--TRIMMABLE-BOUNDARY-END(210453921800)
            
            //--TRIMMABLE-BOUNDARY-START(214748889096)
            /*bool */ get IsSingleSegment()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259608584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._startObject === this._endObject;
            }
            //--TRIMMABLE-BOUNDARY-END(214748889096)
            
            //--TRIMMABLE-BOUNDARY-START(73014968328)
            /*ReadOnlyMemory<T> */ get First()
            {
                return this.GetFirstBuffer();
            }
            //--TRIMMABLE-BOUNDARY-END(73014968328)
            
            //--TRIMMABLE-BOUNDARY-START(77309935624)
            /*ReadOnlySpan<T> */ get FirstSpan()
            {
                return this.GetFirstSpan();
            }
            //--TRIMMABLE-BOUNDARY-END(77309935624)
            
            //--TRIMMABLE-BOUNDARY-START(287763333128)
            /*SequencePosition */ get Start()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439477768);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sm.System.SequencePosition().$ctor$3(this._startObject, $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger));
            }
            //--TRIMMABLE-BOUNDARY-END(287763333128)
            
            //--TRIMMABLE-BOUNDARY-START(64425033736)
            /*SequencePosition */ get End()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899870216);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return new $.$sm.System.SequencePosition().$ctor$3(this._endObject, $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger));
            }
            //--TRIMMABLE-BOUNDARY-END(64425033736)
            
            //--TRIMMABLE-BOUNDARY-START(25770328072)
            $ctor$3(/*object?*/ startSegment, /*int*/ startIndexAndFlags, /*object?*/ endSegment, /*int*/ endIndexAndFlags)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770328072);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2((startSegment !== null && endSegment !== null) || (startSegment === null && endSegment === null && startIndexAndFlags === 0 && endIndexAndFlags === 0), "(startSegment != null && endSegment != null) ||\r\n                (startSegment == null && endSegment == null && startIndexAndFlags == 0 && endIndexAndFlags == 0)");
                    this._startObject = startSegment;
                    this._endObject = endSegment;
                    this._startInteger = startIndexAndFlags;
                    this._endInteger = endIndexAndFlags;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770328072)
            
            //--TRIMMABLE-BOUNDARY-START(30065295368)
            $ctor$7(/*ReadOnlySequenceSegment<T>*/ startSegment, /*int*/ startIndex, /*ReadOnlySequenceSegment<T>*/ endSegment, /*int*/ endIndex)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065295368);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (startSegment === null || endSegment === null || (startSegment !== endSegment && startSegment.RunningIndex > endSegment.RunningIndex) || (startSegment.Memory.Length >>> 0) < (startIndex >>> 0) || (endSegment.Memory.Length >>> 0) < (endIndex >>> 0) || (startSegment === endSegment && endIndex < startIndex))
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentValidationException$1(T, startSegment, startIndex, endSegment);
                    }
                    this._startObject = startSegment;
                    this._endObject = endSegment;
                    this._startInteger = startIndex;
                    this._endInteger = endIndex;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(30065295368)
            
            //--TRIMMABLE-BOUNDARY-START(34360262664)
            $ctor$6(/*T[]*/ array)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360262664);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (array === null)
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentNullException(12/*ExceptionArgument.array*/);
                    }
                    this._startObject = array;
                    this._endObject = array;
                    this._startInteger = 0;
                    this._endInteger = $.$sm.System.Buffers.ReadOnlySequence.ArrayToSequenceEnd(array.length);
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(34360262664)
            
            //--TRIMMABLE-BOUNDARY-START(38655229960)
            $ctor$5(/*T[]*/ array, /*int*/ start, /*int*/ length)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655229960);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    if (array === null || (start >>> 0) > (array.length >>> 0) || (length >>> 0) > ((((array.length - start) | 0)) >>> 0))
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentValidationException(array, start);
                    }
                    this._startObject = array;
                    this._endObject = array;
                    this._startInteger = start;
                    this._endInteger = $.$sm.System.Buffers.ReadOnlySequence.ArrayToSequenceEnd(((start + length) | 0));
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(38655229960)
            
            //--TRIMMABLE-BOUNDARY-START(42950197256)
            $ctor$4(/*ReadOnlyMemory<T>*/ memory)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950197256);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*MemoryManager<T>?*/ let manager;
                    /*int*/ let index;
                    /*int*/ let length;
                    /*ArraySegment<T>*/ let segment;
                    if ($.$$.System.Runtime.InteropServices.MemoryMarshal.TryGetMemoryManager(T, $.$$.System.Buffers.MemoryManager$$(T), memory, $.$ref(() => manager, ($v) => manager = $v, $.$$.System.Buffers.MemoryManager$$(T)), $.$ref(() => index, ($v) => index = $v, $.$$.System.Int32), $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32)))
                    {
                        this._startObject = manager;
                        this._endObject = manager;
                        this._startInteger = $.$sm.System.Buffers.ReadOnlySequence.MemoryManagerToSequenceStart(index);
                        this._endInteger = ((index + length) | 0);
                    }
                    else if ($.$$.System.Runtime.InteropServices.MemoryMarshal.TryGetArray(T, memory, $.$ref(() => segment, ($v) => segment = $v, $.$$.System.ArraySegment$$(T))))
                    {
                        /*T[]?*/ let array = segment.Array;
                        /*int*/ let start = segment.Offset;
                        this._startObject = array;
                        this._endObject = array;
                        this._startInteger = start;
                        this._endInteger = $.$sm.System.Buffers.ReadOnlySequence.ArrayToSequenceEnd(((start + segment.Count) | 0));
                    }
                    else if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Char.$type))
                    {
                        /*string?*/ let text;
                        /*int*/ let start;
                        if (!$.$$.System.Runtime.InteropServices.MemoryMarshal.TryGetString($.$cast($.$cast(memory, $.$$.System.Object), $.$$.System.ReadOnlyMemory$$($.$$.System.Char)), $.$ref(() => text, ($v) => text = $v, $.$$.System.String), $.$ref(() => start, ($v) => start = $v, $.$$.System.Int32), $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32)))
                        {
                            $.$sm.System.ThrowHelper.ThrowInvalidOperationException();
                        }
                        this._startObject = text;
                        this._endObject = text;
                        this._startInteger = $.$sm.System.Buffers.ReadOnlySequence.StringToSequenceStart(start);
                        this._endInteger = $.$sm.System.Buffers.ReadOnlySequence.StringToSequenceEnd(((start + length) | 0));
                    }
                    else 
                    {
                        $.$sm.System.ThrowHelper.ThrowInvalidOperationException();
                        this._startObject = null;
                        this._endObject = null;
                        this._startInteger = 0;
                        this._endInteger = 0;
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(42950197256)
            
            //--TRIMMABLE-BOUNDARY-START(240518692872)
            /*ReadOnlySequence<T> */ Slice$2(/*long*/ start, /*long*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518692872);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (start < 0n || length < 0n)
                {
                    $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(start);
                }
                /*SequencePosition*/ let begin;
                /*SequencePosition*/ let end;
                /*int*/ let startIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger);
                /*int*/ let endIndex = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger);
                /*object?*/ let startObject = this._startObject;
                /*object?*/ let endObject = this._endObject;
                if (startObject !== endObject)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(startObject !== null, "startObject != null");
                    /*var*/ let startSegment = $.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                    /*int*/ let currentLength = ((startSegment.Memory.Length - startIndex) | 0);
                    if (BigInt(currentLength) > start)
                    {
                        startIndex += $.$cast(start, $.$$.System.Int32);
                        begin = new $.$sm.System.SequencePosition().$ctor$3(startObject, startIndex);
                        end = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetEndPosition(startSegment, startObject, startIndex, endObject, endIndex, length);
                    }
                    else 
                    {
                        if (currentLength < 0)
                        {
                            $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                        }
                        begin = $.$sm.System.Buffers.ReadOnlySequence$$(T).SeekMultiSegment(startSegment.Next, endObject, endIndex, start - BigInt(currentLength), 1/*ExceptionArgument.start*/);
                        /*int*/ let beginIndex = begin.GetInteger();
                        /*object*/ let beginObject = begin.GetObject();
                        if (beginObject !== endObject)
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(beginObject !== null, "beginObject != null");
                            end = $.$sm.System.Buffers.ReadOnlySequence$$(T).GetEndPosition($.$cast(beginObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T)), beginObject, beginIndex, endObject, endIndex, length);
                        }
                        else 
                        {
                            if (BigInt(endIndex - beginIndex) < length)
                            {
                                $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(0n);
                            }
                            end = new $.$sm.System.SequencePosition().$ctor$3(beginObject, ((beginIndex + $.$cast(length, $.$$.System.Int32)) | 0));
                        }
                    }
                }
                else 
                {
                    if (BigInt(endIndex - startIndex) < start)
                    {
                        $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(BigInt(-1));
                    }
                    startIndex += $.$cast(start, $.$$.System.Int32);
                    begin = new $.$sm.System.SequencePosition().$ctor$3(startObject, startIndex);
                    if (BigInt(endIndex - startIndex) < length)
                    {
                        $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(0n);
                    }
                    end = new $.$sm.System.SequencePosition().$ctor$3(startObject, ((startIndex + $.$cast(length, $.$$.System.Int32)) | 0));
                }
                return this.SliceImpl($.$ref(() => begin, ), $.$ref(() => end, ));
            }
            //--TRIMMABLE-BOUNDARY-END(240518692872)
            
            //--TRIMMABLE-BOUNDARY-START(244813660168)
            /*ReadOnlySequence<T> */ Slice$3(/*long*/ start, /*SequencePosition*/ end)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813660168);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let startIndex;
                /*object?*/ let startObject;
                /*uint*/ let endIndex;
                /*object?*/ let endObject;
                /*uint*/ let sliceEndIndex;
                /*object?*/ let sliceEndObject;
                /*var*/ let startSegment;
                /*ulong*/ let startRange;
                /*ulong*/ let sliceRange;
                /*int*/ let currentLength;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            if (start < 0n)
                            {
                                $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(start);
                            }
                            startIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger) >>> 0);
                            startObject = this._startObject;
                            endIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger) >>> 0);
                            endObject = this._endObject;
                            sliceEndIndex = (end.GetInteger() >>> 0);
                            sliceEndObject = end.GetObject();
                            if (sliceEndObject === null)
                            {
                                sliceEndObject = this._startObject;
                                sliceEndIndex = startIndex;
                            }
                            if (startObject === endObject)
                            {
                                if (!$.$sm.System.Buffers.ReadOnlySequence$$(T).InRange(sliceEndIndex, startIndex, endIndex))
                                {
                                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                if (BigInt(sliceEndIndex - startIndex) < start)
                                {
                                    $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(BigInt(-1));
                                }
                                $gotoJumpState1 = 1; /*goto FoundInFirstSegment*/
                                continue $gotoJumpStart1;
                            }
                            startSegment = $.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                            startRange = $.$cast((startSegment.RunningIndex + BigInt(startIndex)), $.$$.System.UInt64);
                            sliceRange = $.$cast((($.$cast(sliceEndObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(sliceEndIndex)), $.$$.System.UInt64);
                            $.$$.System.Diagnostics.Debug.Assert$2(sliceEndIndex >= 0 && startIndex >= 0 && endIndex >= 0, "sliceEndIndex >= 0 && startIndex >= 0 && endIndex >= 0");
                            if (!$.$sm.System.Buffers.ReadOnlySequence$$(T).InRange$1(sliceRange, startRange, $.$cast((($.$cast(endObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(endIndex)), $.$$.System.UInt64)))
                            {
                                $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                            }
                            if (startRange + $.$cast(start, $.$$.System.UInt64) > sliceRange)
                            {
                                $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(1/*ExceptionArgument.start*/);
                            }
                            currentLength = ((startSegment.Memory.Length - (startIndex | 0)) | 0);
                            if (BigInt(currentLength) <= start)
                            {
                                if (currentLength < 0)
                                {
                                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                /*SequencePosition*/ let begin = $.$sm.System.Buffers.ReadOnlySequence$$(T).SeekMultiSegment(startSegment.Next, sliceEndObject, (sliceEndIndex | 0), start - BigInt(currentLength), 1/*ExceptionArgument.start*/);
                                return this.SliceImpl($.$ref(() => begin, ), $.$ref(() => end, ));
                            }
                        }
                        case 1: /*FoundInFirstSegment*/
                        $.$$.System.Diagnostics.Debug.Assert$2(start <= BigInt(2147483647/*int.MaxValue*/ - startIndex), "start <= int.MaxValue - startIndex");
                        return this.SliceImpl($.$ref(() => new $.$sm.System.SequencePosition().$ctor$3(startObject, (((startIndex | 0) + $.$cast(start, $.$$.System.Int32)) | 0)), ), $.$ref(() => new $.$sm.System.SequencePosition().$ctor$3(sliceEndObject, (sliceEndIndex | 0)), ));
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(244813660168)
            
            //--TRIMMABLE-BOUNDARY-START(249108627464)
            /*ReadOnlySequence<T> */ Slice$6(/*SequencePosition*/ start, /*long*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108627464);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*uint*/ let startIndex;
                /*object?*/ let startObject;
                /*uint*/ let endIndex;
                /*object?*/ let endObject;
                /*uint*/ let sliceStartIndex;
                /*object?*/ let sliceStartObject;
                /*var*/ let sliceStartSegment;
                /*ulong*/ let sliceRange;
                /*ulong*/ let startRange;
                /*ulong*/ let endRange;
                /*int*/ let currentLength;
                let $gotoJumpState1 = 0;
                $gotoJumpStart1: while(true)
                {
                    switch($gotoJumpState1)
                    {
                        case 0:
                        {
                            startIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger) >>> 0);
                            startObject = this._startObject;
                            endIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._endInteger) >>> 0);
                            endObject = this._endObject;
                            sliceStartIndex = (start.GetInteger() >>> 0);
                            sliceStartObject = start.GetObject();
                            if (sliceStartObject === null)
                            {
                                sliceStartIndex = startIndex;
                                sliceStartObject = this._startObject;
                            }
                            if (startObject === endObject)
                            {
                                if (!$.$sm.System.Buffers.ReadOnlySequence$$(T).InRange(sliceStartIndex, startIndex, endIndex))
                                {
                                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                if (length < 0n)
                                {
                                    $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(0n);
                                }
                                if (BigInt(endIndex - sliceStartIndex) < length)
                                {
                                    $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(0n);
                                }
                                $gotoJumpState1 = 1; /*goto FoundInFirstSegment*/
                                continue $gotoJumpStart1;
                            }
                            sliceStartSegment = $.$cast(sliceStartObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                            sliceRange = $.$cast(((sliceStartSegment.RunningIndex + BigInt(sliceStartIndex))), $.$$.System.UInt64);
                            startRange = $.$cast((($.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(startIndex)), $.$$.System.UInt64);
                            endRange = $.$cast((($.$cast(endObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).RunningIndex + BigInt(endIndex)), $.$$.System.UInt64);
                            $.$$.System.Diagnostics.Debug.Assert$2(sliceStartIndex >= 0 && startIndex >= 0 && endIndex >= 0, "sliceStartIndex >= 0 && startIndex >= 0 && endIndex >= 0");
                            if (!$.$sm.System.Buffers.ReadOnlySequence$$(T).InRange$1(sliceRange, startRange, endRange))
                            {
                                $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                            }
                            if (length < 0n)
                            {
                                $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(0n);
                            }
                            if (sliceRange + $.$cast(length, $.$$.System.UInt64) > endRange)
                            {
                                $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(0/*ExceptionArgument.length*/);
                            }
                            currentLength = ((sliceStartSegment.Memory.Length - (sliceStartIndex | 0)) | 0);
                            if (BigInt(currentLength) < length)
                            {
                                if (currentLength < 0)
                                {
                                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                                }
                                /*SequencePosition*/ let end = $.$sm.System.Buffers.ReadOnlySequence$$(T).SeekMultiSegment(sliceStartSegment.Next, endObject, (endIndex | 0), length - BigInt(currentLength), 0/*ExceptionArgument.length*/);
                                return this.SliceImpl($.$ref(() => start, ), $.$ref(() => end, ));
                            }
                        }
                        case 1: /*FoundInFirstSegment*/
                        $.$$.System.Diagnostics.Debug.Assert$2(length <= BigInt(2147483647/*int.MaxValue*/ - sliceStartIndex), "length <= int.MaxValue - sliceStartIndex");
                        return this.SliceImpl($.$ref(() => new $.$sm.System.SequencePosition().$ctor$3(sliceStartObject, (sliceStartIndex | 0)), ), $.$ref(() => new $.$sm.System.SequencePosition().$ctor$3(sliceStartObject, (((sliceStartIndex | 0) + $.$cast(length, $.$$.System.Int32)) | 0)), ));
                    }
                    break;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(249108627464)
            
            //--TRIMMABLE-BOUNDARY-START(253403594760)
            /*ReadOnlySequence<T> */ Slice(/*int*/ start, /*int*/ length)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(253403594760);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Slice$2($.$cast(start, $.$$.System.Int64), BigInt(length));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(253403594760)
            
            //--TRIMMABLE-BOUNDARY-START(257698562056)
            /*ReadOnlySequence<T> */ Slice$1(/*int*/ start, /*SequencePosition*/ end)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(257698562056);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Slice$3($.$cast(start, $.$$.System.Int64), end);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(257698562056)
            
            //--TRIMMABLE-BOUNDARY-START(261993529352)
            /*ReadOnlySequence<T> */ Slice$5(/*SequencePosition*/ start, /*int*/ length)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(261993529352);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.Slice$6(start, $.$cast(length, $.$$.System.Int64));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(261993529352)
            
            //--TRIMMABLE-BOUNDARY-START(266288496648)
            /*ReadOnlySequence<T> */ Slice$7(/*SequencePosition*/ start, /*SequencePosition*/ end)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288496648);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this.BoundsCheck((start.GetInteger() >>> 0), start.GetObject(), (end.GetInteger() >>> 0), end.GetObject());
                return this.SliceImpl($.$ref(() => start, ), $.$ref(() => end, ));
            }
            //--TRIMMABLE-BOUNDARY-END(266288496648)
            
            //--TRIMMABLE-BOUNDARY-START(270583463944)
            /*ReadOnlySequence<T> */ Slice$8(/*SequencePosition*/ start)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583463944);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*bool*/ let positionIsNotNull = start.GetObject() !== null;
                this.BoundsCheck$1($.$ref(() => start, ), positionIsNotNull);
                return this.SliceImpl$1($.$ref(() => positionIsNotNull ? start : this.Start, ));
            }
            //--TRIMMABLE-BOUNDARY-END(270583463944)
            
            //--TRIMMABLE-BOUNDARY-START(274878431240)
            /*ReadOnlySequence<T> */ Slice$4(/*long*/ start)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878431240);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (start < 0n)
                {
                    $.$sm.System.ThrowHelper.ThrowStartOrEndArgumentValidationException(start);
                }
                if (start === 0n)
                {
                    return this;
                }
                /*SequencePosition*/ let begin = this.Seek(start, 1/*ExceptionArgument.start*/);
                return this.SliceImpl$1($.$ref(() => begin, ));
            }
            //--TRIMMABLE-BOUNDARY-END(274878431240)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 292058300424, 330712612865)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058300424);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Type.op_Equality$1(T.$type, $.$$.System.Char.$type))
                {
                    /*ReadOnlySequence<T>*/ let localThis = this;
                    /*ReadOnlySequence<char>*/ let charSequence = $.$$.System.Runtime.CompilerServices.Unsafe.As($.$sm.System.Buffers.ReadOnlySequence$$(T), $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.Buffers.ReadOnlySequence$$(T), () => localThis, ($v) => localThis = $v, null)).$v;
                    /*string?*/ let text;
                    /*int*/ let start;
                    /*int*/ let length;
                    if (charSequence.TryGetString($.$ref(() => text, ($v) => text = $v, $.$$.System.String), $.$ref(() => start, ($v) => start = $v, $.$$.System.Int32), $.$ref(() => length, ($v) => length = $v, $.$$.System.Int32)))
                    {
                        return $.$$.System.String.Substring.call(text, start, length);
                    }
                    if (this.Length < BigInt(2147483647/*int.MaxValue*/))
                    {
                        return $.$$.System.String.Create$10($.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char), $.$cast(this.Length, $.$$.System.Int32), charSequence, new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char)))().$ctor(this,  (/*span*/ span, /*sequence*/ sequence) =>
                        {
                            return $.$sm.System.Buffers.BuffersExtensions.CopyTo($.$$.System.Char, $.$ref(() => sequence, ), span);
                        }, {
  "r": 65537,
  "p": [
    {
      "n": "span",
      "p": $.$$.System.Span$$($.$$.System.Char).$h
    },
    {
      "n": "sequence",
      "p": $.$sm.System.Buffers.ReadOnlySequence$$($.$$.System.Char).$h
    }
  ],
  "n": "",
  "d": this.$h,
  "h": 0,
  "f": 17825794
}));
                    }
                }
                return `System.Buffers.ReadOnlySequence<${T.$type.Name}>[${this.Length}]`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sm.System.Buffers.ReadOnlySequence$$(T).ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 292058300424, 330712612865)
            
            //--TRIMMABLE-BOUNDARY-START(146029412360)
            /*Enumerator */ GetEnumerator()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146029412360);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return new ($.$sm.System.Buffers.ReadOnlySequence$$(T).Enumerator)().$ctor$3(this);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146029412360)
            
            //--TRIMMABLE-BOUNDARY-START(188979085320)
            /*SequencePosition */ GetPosition$1(/*long*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979085320);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (offset < 0n)
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_OffsetOutOfRange();
                }
                return this.Seek(offset, 7);
            }
            //--TRIMMABLE-BOUNDARY-END(188979085320)
            
            //--TRIMMABLE-BOUNDARY-START(184684118024)
            /*long */ GetOffset(/*SequencePosition*/ position)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684118024);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*object?*/ let positionSequenceObject = position.GetObject();
                /*bool*/ let positionIsNull = positionSequenceObject === null;
                this.BoundsCheck$1($.$ref(() => position, ), !positionIsNull);
                /*object?*/ let startObject = this._startObject;
                /*object?*/ let endObject = this._endObject;
                /*uint*/ let positionIndex = (position.GetInteger() >>> 0);
                if (positionIsNull)
                {
                    positionSequenceObject = this._startObject;
                    positionIndex = ($.$sm.System.Buffers.ReadOnlySequence$$(T).GetIndex(this._startInteger) >>> 0);
                }
                if (startObject === endObject)
                {
                    return BigInt(positionIndex);
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(positionSequenceObject !== null, "positionSequenceObject != null");
                    if (BigInt(($.$cast(positionSequenceObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T))).Memory.Length) - BigInt(positionIndex) < 0n)
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                    /*ReadOnlySequenceSegment<T>?*/ let currentSegment = $.$cast(startObject, $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T));
                    while(currentSegment !== null && currentSegment !== positionSequenceObject)
                    {
                        currentSegment = currentSegment.Next;
                    }
                    if (currentSegment === null)
                    {
                        $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_PositionOutOfRange();
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(currentSegment.RunningIndex + BigInt(positionIndex) >= 0n, "currentSegment!.RunningIndex + positionIndex >= 0");
                    return currentSegment.RunningIndex + BigInt(positionIndex);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(184684118024)
            
            //--TRIMMABLE-BOUNDARY-START(193274052616)
            /*SequencePosition */ GetPosition(/*long*/ offset, /*SequencePosition*/ origin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274052616);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (offset < 0n)
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException_OffsetOutOfRange();
                }
                return this.Seek$1($.$ref(() => origin, ), offset);
            }
            //--TRIMMABLE-BOUNDARY-END(193274052616)
            
            //--TRIMMABLE-BOUNDARY-START(296353267720)
            /*bool */ TryGet(/*ref SequencePosition*/ position, /*out ReadOnlyMemory<T>*/ memory, /*bool*/ advance)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353267720);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*SequencePosition*/ let next;
                /*bool*/ let result = this.TryGetBuffer(position, memory, $.$ref(() => next, ($v) => next = $v, $.$sm.System.SequencePosition));
                if (advance)
                {
                    position.$v = next;
                }
                return result;
            }
            //--TRIMMABLE-BOUNDARY-END(296353267720)
            
            //--TRIMMABLE-BOUNDARY-START(589832)
            static $_Enumerator;
            static get Enumerator()
            {
                let $cls = $.$sm.System.Buffers.ReadOnlySequence$$(T);
                return $cls.$_Enumerator ??= $asm.$nstr("$sm.System.Buffers.ReadOnlySequence$$.Enumerator", ($self) => class Enumerator extends $.$$.System.ValueType
                {
                    //--TRIMMABLE-BOUNDARY-START(12885491720)
                    /*ReadOnlySequence<T>*/  get _sequence() { return this.$getField(0, 16); }
                    /*ReadOnlySequence<T>*/  set _sequence(value) { this.$setField(0, 16, value); }
                    //--TRIMMABLE-BOUNDARY-END(12885491720)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590524424)
                    /*SequencePosition*/  get _next() { return this.$getField(16, 8); }
                    /*SequencePosition*/  set _next(value) { this.$setField(16, 8, value); }
                    //--TRIMMABLE-BOUNDARY-END(8590524424)
                    
                    //--TRIMMABLE-BOUNDARY-START(4295557128)
                    /*ReadOnlyMemory<T>*/  get _currentMemory() { return this.$getField(24, 12); }
                    /*ReadOnlyMemory<T>*/  set _currentMemory(value) { this.$setField(24, 12, value); }
                    //--TRIMMABLE-BOUNDARY-END(4295557128)
                    
                    //--TRIMMABLE-BOUNDARY-START(17180459016)
                    $ctor$3(/*in ReadOnlySequence<T>*/ sequence)
                    {
                        super.$ctor$1();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(17180459016);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._currentMemory = new ($.$$.System.ReadOnlyMemory$$(T))();
                            this._next = sequence.$v.Start;
                            this._sequence = sequence.$v;
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(17180459016)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770393608)
                    /*ReadOnlyMemory<T> */ get Current()
                    {
                        return this._currentMemory;
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770393608)
                    
                    //--TRIMMABLE-BOUNDARY-START(38655295496)
                    /*bool */ MoveNext()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(38655295496);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        if (this._next.GetObject() === null)
                        {
                            return false;
                        }
                        return this._sequence.TryGet($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$sm.System.SequencePosition, () => this._next, ($v) => this._next = $v, null), $.$ref(() => this._currentMemory, ($v) => this._currentMemory = $v, $.$$.System.ReadOnlyMemory$$(T)), true);
                    }
                    //--TRIMMABLE-BOUNDARY-END(38655295496)
                    
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._sequence = this._sequence.Clone();
                        copy._next = this._next.Clone();
                        copy._currentMemory = this._currentMemory.Clone();
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        //--TRIMMABLE-BOUNDARY-START(12885491720)
                        this._sequence = $.$default($.$sm.System.Buffers.ReadOnlySequence$$(T));
                        //--TRIMMABLE-BOUNDARY-END(12885491720)
                        
                        //--TRIMMABLE-BOUNDARY-START(8590524424)
                        this._next = $.$default($.$sm.System.SequencePosition);
                        //--TRIMMABLE-BOUNDARY-END(8590524424)
                        
                        //--TRIMMABLE-BOUNDARY-START(4295557128)
                        this._currentMemory = $.$default($.$$.System.ReadOnlyMemory$$(T));
                        //--TRIMMABLE-BOUNDARY-END(4295557128)
                        
                    }
                    static $h = 589832;
                    static $z = 36;
                    static $f = 0b10000001011000001;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770393608),
    {
      "p": $.$$.System.ReadOnlyMemory$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(589832)|0x800000000n),
        "f": 50331649
      },
      "n": "Current",
      "d": 589832,
      "h": Number(BigInt(589832)|0x600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770393608)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655295496),
    {
      "r": 262145,
      "n": "MoveNext",
      "d": 589832,
      "h": Number(BigInt(589832)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655295496)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885491720),
    {
      "t": $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
      "n": "_sequence",
      "d": 589832,
      "h": Number(BigInt(589832)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885491720),
//--TRIMMABLE-BOUNDARY-START(8590524424),
    {
      "t": 1179656,
      "n": "_next",
      "d": 589832,
      "h": Number(BigInt(589832)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590524424),
//--TRIMMABLE-BOUNDARY-START(4295557128),
    {
      "t": $.$$.System.ReadOnlyMemory$$(T).$h,
      "n": "_currentMemory",
      "d": 589832,
      "h": Number(BigInt(589832)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295557128)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180459016),
    {
      "p": [
        {
          "n": "sequence",
          "p": $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
          "f": 8
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589832,
      "h": Number(BigInt(589832)|0x400000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180459016),
//--TRIMMABLE-BOUNDARY-START(21475426312),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 589832,
      "h": Number(BigInt(589832)|0x500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475426312)
  ],
  "d": $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
  "h": 589832
}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Buffers.ReadOnlySequence<${T?.$fullName}>.Enumerator`; }
                }, $cls, ($v) => $cls.$_Enumerator = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(589832)
            
            //--TRIMMABLE-BOUNDARY-START(655368)
            static $_SequenceType;
            static get SequenceType()
            {
                let $cls = $.$sm.System.Buffers.ReadOnlySequence$$(T);
                return $cls.$_SequenceType ??= $asm.$nstr("$sm.System.Buffers.ReadOnlySequence$$.SequenceType", ($self) => class SequenceType extends $.$$.System.Enum
                {
                    static MultiSegment = 0;
                    static Array = 1;
                    static MemoryManager = 2;
                    static String = 3;
                    static $map;
                    static get Map()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(655368);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.$map ??= 
                        {
                            "MultiSegment": 0n,
                            "Array": 1n,
                            "MemoryManager": 2n,
                            "String": 3n
                        };
                    }
                    static $h = 655368;
                    static $z = 4;
                    static $f = 0b110000011011001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180524552),
    {
      "t": 655368,
      "n": "MultiSegment",
      "d": 655368,
      "h": Number(BigInt(655368)|0x400000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180524552),
//--TRIMMABLE-BOUNDARY-START(8590589960),
    {
      "t": 655368,
      "n": "Array",
      "d": 655368,
      "h": Number(BigInt(655368)|0x200000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590589960),
//--TRIMMABLE-BOUNDARY-START(12885557256),
    {
      "t": 655368,
      "n": "MemoryManager",
      "d": 655368,
      "h": Number(BigInt(655368)|0x300000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885557256),
//--TRIMMABLE-BOUNDARY-START(21475491848),
    {
      "t": 655368,
      "n": "String",
      "d": 655368,
      "h": Number(BigInt(655368)|0x500000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475491848)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622664),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655368,
      "h": Number(BigInt(655368)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622664)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "d": $.$sm.System.Buffers.ReadOnlySequence$$(T).$h,
  "h": 655368
}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Buffers.ReadOnlySequence<${T?.$fullName}>.SequenceType`; }
                }, $cls, ($v) => $cls.$_SequenceType = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(655368)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._startObject = this._startObject;
                copy._endObject = this._endObject;
                copy._startInteger = this._startInteger;
                copy._endInteger = this._endInteger;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(17180393480)
                this._startObject = null;
                //--TRIMMABLE-BOUNDARY-END(17180393480)
                
                //--TRIMMABLE-BOUNDARY-START(8590458888)
                this._endObject = null;
                //--TRIMMABLE-BOUNDARY-END(8590458888)
                
                //--TRIMMABLE-BOUNDARY-START(12885426184)
                this._startInteger = 0;
                //--TRIMMABLE-BOUNDARY-END(12885426184)
                
                //--TRIMMABLE-BOUNDARY-START(4295491592)
                this._endInteger = 0;
                //--TRIMMABLE-BOUNDARY-END(4295491592)
                
            }
            //--TRIMMABLE-BOUNDARY-START(21475360776)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(60130066440)
                    this.Empty = new ($.$sm.System.Buffers.ReadOnlySequence$$(T))().$ctor$6($.$$.System.Array.Empty(T));
                    //--TRIMMABLE-BOUNDARY-END(60130066440)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21475360776)
            
            static $h = 524296;
            static $g = 1;
            static $z = 16;
            static $f = 0b1011000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "p": [
//--TRIMMABLE-BOUNDARY-START(219043856392),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1E00000000n),
        "f": 50331649
      },
      "n": "Length",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(219043856392),
//--TRIMMABLE-BOUNDARY-START(210453921800),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1A00000000n),
        "f": 50331649
      },
      "n": "IsEmpty",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210453921800),
//--TRIMMABLE-BOUNDARY-START(214748889096),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1C00000000n),
        "f": 50331649
      },
      "n": "IsSingleSegment",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(214748889096),
//--TRIMMABLE-BOUNDARY-START(73014968328),
    {
      "p": $.$$.System.ReadOnlyMemory$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1600000000n),
        "f": 50331649
      },
      "n": "First",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1100000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014968328),
//--TRIMMABLE-BOUNDARY-START(77309935624),
    {
      "p": $.$$.System.ReadOnlySpan$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1800000000n),
        "f": 50331649
      },
      "n": "FirstSpan",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x1200000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309935624),
//--TRIMMABLE-BOUNDARY-START(287763333128),
    {
      "p": 1179656,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x2000000000n),
        "f": 50331649
      },
      "n": "Start",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4300000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(287763333128),
//--TRIMMABLE-BOUNDARY-START(64425033736),
    {
      "p": 1179656,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x1400000000n),
        "f": 50331649
      },
      "n": "End",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xF00000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(64425033736)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(304943202312),
    {
      "r": 262145,
      "p": [
        {
          "n": "position",
          "p": 1179656,
          "f": 8
        },
        {
          "n": "memory",
          "p": $.$$.System.ReadOnlyMemory$$(T).$h,
          "f": 2
        },
        {
          "n": "next",
          "p": 1179656,
          "f": 2
        }
      ],
      "n": "TryGetBuffer",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4700000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(304943202312),
//--TRIMMABLE-BOUNDARY-START(150324379656),
    {
      "r": $.$$.System.ReadOnlyMemory$$(T).$h,
      "n": "GetFirstBuffer",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2300000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(150324379656),
//--TRIMMABLE-BOUNDARY-START(154619346952),
    {
      "r": $.$$.System.ReadOnlyMemory$$(T).$h,
      "p": [
        {
          "n": "startObject",
          "p": 131073
        },
        {
          "n": "isMultiSegment",
          "p": 262145
        }
      ],
      "n": "GetFirstBufferSlow",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2400000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(154619346952),
//--TRIMMABLE-BOUNDARY-START(158914314248),
    {
      "r": $.$$.System.ReadOnlySpan$$(T).$h,
      "n": "GetFirstSpan",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2500000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(158914314248),
//--TRIMMABLE-BOUNDARY-START(167504248840),
    {
      "r": $.$$.System.ReadOnlySpan$$(T).$h,
      "p": [
        {
          "n": "startObject",
          "p": 131073
        },
        {
          "n": "isMultiSegment",
          "p": 262145
        }
      ],
      "n": "GetFirstSpanSlow",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2700000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(167504248840),
//--TRIMMABLE-BOUNDARY-START(223338823688),
    {
      "r": 1179656,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "exceptionArgument",
          "p": 1048584,
          "f": 65,
          "v": 7
        }
      ],
      "n": "Seek",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3400000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(223338823688),
//--TRIMMABLE-BOUNDARY-START(227633790984),
    {
      "r": 1179656,
      "p": [
        {
          "n": "start",
          "p": 1179656,
          "f": 8
        },
        {
          "n": "offset",
          "p": 917505
        }
      ],
      "n": "Seek",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3500000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(227633790984),
//--TRIMMABLE-BOUNDARY-START(231928758280),
    {
      "r": 1179656,
      "p": [
        {
          "n": "currentSegment",
          "p": $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h
        },
        {
          "n": "endObject",
          "p": 131073
        },
        {
          "n": "endIndex",
          "p": 655361
        },
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "argument",
          "p": 1048584
        }
      ],
      "n": "SeekMultiSegment",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3600000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(231928758280),
//--TRIMMABLE-BOUNDARY-START(51540131848),
    {
      "r": 65537,
      "p": [
        {
          "n": "position",
          "p": 1179656,
          "f": 8
        },
        {
          "n": "positionIsNotNull",
          "p": 262145
        }
      ],
      "n": "BoundsCheck",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xC00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(51540131848),
//--TRIMMABLE-BOUNDARY-START(55835099144),
    {
      "r": 65537,
      "p": [
        {
          "n": "sliceStartIndex",
          "p": 720897
        },
        {
          "n": "sliceStartObject",
          "p": 131073
        },
        {
          "n": "sliceEndIndex",
          "p": 720897
        },
        {
          "n": "sliceEndObject",
          "p": 131073
        }
      ],
      "n": "BoundsCheck",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xD00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(55835099144),
//--TRIMMABLE-BOUNDARY-START(141734445064),
    {
      "r": 1179656,
      "p": [
        {
          "n": "startSegment",
          "p": $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h
        },
        {
          "n": "startObject",
          "p": 131073
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endObject",
          "p": 131073
        },
        {
          "n": "endIndex",
          "p": 655361
        },
        {
          "n": "length",
          "p": 917505
        }
      ],
      "n": "GetEndPosition",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2100000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(141734445064),
//--TRIMMABLE-BOUNDARY-START(197569019912),
    {
      "r": 655368,
      "n": "GetSequenceType",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2E00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(197569019912),
//--TRIMMABLE-BOUNDARY-START(176094183432),
    {
      "r": 655361,
      "p": [
        {
          "n": "Integer",
          "p": 655361
        }
      ],
      "n": "GetIndex",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2900000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(176094183432),
//--TRIMMABLE-BOUNDARY-START(279173398536),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 1179656,
          "f": 8
        },
        {
          "n": "end",
          "p": 1179656,
          "f": 8
        }
      ],
      "n": "SliceImpl",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4100000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(279173398536),
//--TRIMMABLE-BOUNDARY-START(283468365832),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 1179656,
          "f": 8
        }
      ],
      "n": "SliceImpl",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4200000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(283468365832),
//--TRIMMABLE-BOUNDARY-START(180389150728),
    {
      "r": 917505,
      "n": "GetLength",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2A00000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(180389150728),
//--TRIMMABLE-BOUNDARY-START(309238169608),
    {
      "r": 262145,
      "p": [
        {
          "n": "startSegment",
          "p": $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h,
          "f": 2
        },
        {
          "n": "startIndex",
          "p": 655361,
          "f": 2
        },
        {
          "n": "endSegment",
          "p": $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h,
          "f": 2
        },
        {
          "n": "endIndex",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryGetReadOnlySequenceSegment",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4800000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(309238169608),
//--TRIMMABLE-BOUNDARY-START(300648235016),
    {
      "r": 262145,
      "p": [
        {
          "n": "segment",
          "p": $.$$.System.ArraySegment$$(T).$h,
          "f": 2
        }
      ],
      "n": "TryGetArray",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4600000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(300648235016),
//--TRIMMABLE-BOUNDARY-START(313533136904),
    {
      "r": 262145,
      "p": [
        {
          "n": "text",
          "p": 1310721,
          "f": 2
        },
        {
          "n": "start",
          "p": 655361,
          "f": 2
        },
        {
          "n": "length",
          "p": 655361,
          "f": 2
        }
      ],
      "n": "TryGetString",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4900000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(313533136904),
//--TRIMMABLE-BOUNDARY-START(201863987208),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 720897
        },
        {
          "n": "start",
          "p": 720897
        },
        {
          "n": "end",
          "p": 720897
        }
      ],
      "n": "InRange",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2F00000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(201863987208),
//--TRIMMABLE-BOUNDARY-START(206158954504),
    {
      "r": 262145,
      "p": [
        {
          "n": "value",
          "p": 983041
        },
        {
          "n": "start",
          "p": 983041
        },
        {
          "n": "end",
          "p": 983041
        }
      ],
      "n": "InRange",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3000000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(206158954504),
//--TRIMMABLE-BOUNDARY-START(163209281544),
    {
      "r": 65537,
      "p": [
        {
          "n": "first",
          "p": $.$$.System.ReadOnlySpan$$(T).$h,
          "f": 2
        },
        {
          "n": "next",
          "p": 1179656,
          "f": 2
        }
      ],
      "n": "GetFirstSpan",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2600000000n),
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(163209281544),
//--TRIMMABLE-BOUNDARY-START(171799216136),
    {
      "r": $.$$.System.ReadOnlySpan$$(T).$h,
      "p": [
        {
          "n": "startObject",
          "p": 131073
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endIndex",
          "p": 655361
        },
        {
          "n": "hasMultipleSegments",
          "p": 262145
        }
      ],
      "n": "GetFirstSpanSlow",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2800000000n),
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(171799216136),
//--TRIMMABLE-BOUNDARY-START(240518692872),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 917505
        },
        {
          "n": "length",
          "p": 917505
        }
      ],
      "n": "Slice",
      "o": "@$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(240518692872),
//--TRIMMABLE-BOUNDARY-START(244813660168),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 917505
        },
        {
          "n": "end",
          "p": 1179656
        }
      ],
      "n": "Slice",
      "o": "@$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(244813660168),
//--TRIMMABLE-BOUNDARY-START(249108627464),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 1179656
        },
        {
          "n": "length",
          "p": 917505
        }
      ],
      "n": "Slice",
      "o": "@$6",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3A00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(249108627464),
//--TRIMMABLE-BOUNDARY-START(253403594760),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "Slice",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3B00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(253403594760),
//--TRIMMABLE-BOUNDARY-START(257698562056),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "end",
          "p": 1179656
        }
      ],
      "n": "Slice",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3C00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(257698562056),
//--TRIMMABLE-BOUNDARY-START(261993529352),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 1179656
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": "Slice",
      "o": "@$5",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3D00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(261993529352),
//--TRIMMABLE-BOUNDARY-START(266288496648),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 1179656
        },
        {
          "n": "end",
          "p": 1179656
        }
      ],
      "n": "Slice",
      "o": "@$7",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3E00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(266288496648),
//--TRIMMABLE-BOUNDARY-START(270583463944),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 1179656
        }
      ],
      "n": "Slice",
      "o": "@$8",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x3F00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(270583463944),
//--TRIMMABLE-BOUNDARY-START(274878431240),
    {
      "r": this.$h,
      "p": [
        {
          "n": "start",
          "p": 917505
        }
      ],
      "n": "Slice",
      "o": "@$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4000000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(274878431240),
//--TRIMMABLE-BOUNDARY-START(ALL, 292058300424, 330712612865),
    {
      "r": 1310721,
      "n": "ToString",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4400000000n),
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 292058300424, 330712612865),
//--TRIMMABLE-BOUNDARY-START(146029412360),
    {
      "r": 589832,
      "n": "GetEnumerator",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(146029412360),
//--TRIMMABLE-BOUNDARY-START(188979085320),
    {
      "r": 1179656,
      "p": [
        {
          "n": "offset",
          "p": 917505
        }
      ],
      "n": "GetPosition",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2C00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(188979085320),
//--TRIMMABLE-BOUNDARY-START(184684118024),
    {
      "r": 917505,
      "p": [
        {
          "n": "position",
          "p": 1179656
        }
      ],
      "n": "GetOffset",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2B00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(184684118024),
//--TRIMMABLE-BOUNDARY-START(193274052616),
    {
      "r": 1179656,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 1179656
        }
      ],
      "n": "GetPosition",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x2D00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(193274052616),
//--TRIMMABLE-BOUNDARY-START(296353267720),
    {
      "r": 262145,
      "p": [
        {
          "n": "position",
          "p": 1179656,
          "f": 4
        },
        {
          "n": "memory",
          "p": $.$$.System.ReadOnlyMemory$$(T).$h,
          "f": 2
        },
        {
          "n": "advance",
          "p": 262145,
          "f": 65,
          "v": true
        }
      ],
      "n": "TryGet",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x4500000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(296353267720)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180393480),
    {
      "t": 131073,
      "n": "_startObject",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x400000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(17180393480),
//--TRIMMABLE-BOUNDARY-START(8590458888),
    {
      "t": 131073,
      "n": "_endObject",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x200000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590458888),
//--TRIMMABLE-BOUNDARY-START(12885426184),
    {
      "t": 655361,
      "n": "_startInteger",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885426184),
//--TRIMMABLE-BOUNDARY-START(4295491592),
    {
      "t": 655361,
      "n": "_endInteger",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295491592),
//--TRIMMABLE-BOUNDARY-START(60130066440),
    {
      "t": this.$h,
      "n": "Empty",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xE00000000n),
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130066440)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(25770328072),
    {
      "p": [
        {
          "n": "startSegment",
          "p": 131073
        },
        {
          "n": "startIndexAndFlags",
          "p": 655361
        },
        {
          "n": "endSegment",
          "p": 131073
        },
        {
          "n": "endIndexAndFlags",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(25770328072),
//--TRIMMABLE-BOUNDARY-START(30065295368),
    {
      "p": [
        {
          "n": "startSegment",
          "p": $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h
        },
        {
          "n": "startIndex",
          "p": 655361
        },
        {
          "n": "endSegment",
          "p": $.$sm.System.Buffers.ReadOnlySequenceSegment$$(T).$h
        },
        {
          "n": "endIndex",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065295368),
//--TRIMMABLE-BOUNDARY-START(34360262664),
    {
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x800000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360262664),
//--TRIMMABLE-BOUNDARY-START(38655229960),
    {
      "p": [
        {
          "n": "array",
          "p": $.$typeArray(T).$h
        },
        {
          "n": "start",
          "p": 655361
        },
        {
          "n": "length",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x900000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655229960),
//--TRIMMABLE-BOUNDARY-START(42950197256),
    {
      "p": [
        {
          "n": "memory",
          "p": $.$$.System.ReadOnlyMemory$$(T).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xA00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950197256),
//--TRIMMABLE-BOUNDARY-START(47245164552),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0xB00000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245164552)
  ],
  "g": [T?.$h??1507328
  ],
  "j": [589832,655368
  ],
  "r": 1,
  "h": this.$h,
  "a": [
    {
      "t": 70582273,
      "c": 8660516865,
      "a": [
        {
          "v": $.$sm.System.Buffers.ReadOnlySequenceDebugView$$().$h,
          "t": 187629569
        }
      ]
    },
    {
      "t": 70254593,
      "c": 8660189185,
      "a": [
        {
          "v": "{ToString(),raw}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Buffers.ReadOnlySequence<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(524296)
        
        
        //--TRIMMABLE-BOUNDARY-START(131080)
        $asm.$cls("$sm.System.Buffers.ArrayMemoryPool<>", (T) => $asm.$gt("$sm.System.Buffers.ArrayMemoryPool<>", [T], ($self) => class ArrayMemoryPool$$ extends $.$sm.System.Buffers.MemoryPool$$(T)
        {
            //--TRIMMABLE-BOUNDARY-START(ALL, 25769934856, 38655098888)
            /*int */ get MaxBufferSize()
            {
                return $.$$.System.Array.MaxLength;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25769934856, 38655098888)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 30064902152, 42950066184)
            /*IMemoryOwner<T> */ Rent(/*int*/ minimumBufferSize)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902152);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (minimumBufferSize === -1)
                {
                    minimumBufferSize = ((1 + ($.trunc(4095 / (T.$z??4)))) | 0);
                }
                else if ((BigInt((minimumBufferSize >>> 0))) > BigInt($.$$.System.Array.MaxLength))
                {
                    $.$sm.System.ThrowHelper.ThrowArgumentOutOfRangeException(2/*ExceptionArgument.minimumBufferSize*/);
                }
                return new ($.$sm.System.Buffers.ArrayMemoryPool$$(T).ArrayMemoryPoolBuffer)().$ctor$1(minimumBufferSize);
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 30064902152, 42950066184)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 12885032968, 17180262408)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885032968);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 12885032968, 17180262408)
            
            //--TRIMMABLE-BOUNDARY-START(196616)
            static $_ArrayMemoryPoolBuffer;
            static get ArrayMemoryPoolBuffer()
            {
                let $cls = $.$sm.System.Buffers.ArrayMemoryPool$$(T);
                return $cls.$_ArrayMemoryPoolBuffer ??= $asm.$ncls("$sm.System.Buffers.ArrayMemoryPool$$.ArrayMemoryPoolBuffer", ($self) => class ArrayMemoryPoolBuffer extends $.$$.System.Object
                {
                    //--TRIMMABLE-BOUNDARY-START(4295163912)
                    /*T[]?*/ _array = null;
                    //--TRIMMABLE-BOUNDARY-END(4295163912)
                    
                    //--TRIMMABLE-BOUNDARY-START(8590131208)
                    $ctor$1(/*int*/ size)
                    {
                        super.$ctor();
                        {
                            //--TRIMMABLE-BOUNDARY-START(TRACE)
                            $.$trace(8590131208);
                            //--TRIMMABLE-BOUNDARY-END(TRACE)
                            this._array = $.$$.System.Buffers.ArrayPool$$(T).Shared.Rent(size);
                        }
                        return this;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8590131208)
                    
                    //--TRIMMABLE-BOUNDARY-START(25770000392)
                    /*Memory<T> */ get Memory()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(21475033096);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*T[]?*/ let array = this._array;
                        $.$$.System.ObjectDisposedException.ThrowIf(array === null, this);
                        return new ($.$$.System.Memory$$(T))().$ctor$7(array);
                    }
                    //--TRIMMABLE-BOUNDARY-END(25770000392)
                    
                    //--TRIMMABLE-BOUNDARY-START(12885098504)
                    /*void */ Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12885098504);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        /*T[]?*/ let array = this._array;
                        if (array !== null)
                        {
                            this._array = null;
                            $.$$.System.Buffers.ArrayPool$$(T).Shared.Return(array, false);
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(12885098504)
                    
                    //--TRIMMABLE-BOUNDARY-START(8638169089)
                    //Generated interface implemetation for System.Buffers.IMemoryOwner<T>.Memory.get
                    get System$Buffers$IMemoryOwner$$$Memory()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(12933136385);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Memory;
                    }
                    //--TRIMMABLE-BOUNDARY-END(8638169089)
                    
                    //--TRIMMABLE-BOUNDARY-START(4385144833)
                    //Generated interface implemetation for System.IDisposable.Dispose()
                    System$IDisposable$Dispose()
                    {
                        //--TRIMMABLE-BOUNDARY-START(TRACE)
                        $.$trace(4385144833);
                        //--TRIMMABLE-BOUNDARY-END(TRACE)
                        return this.Dispose(...arguments);
                    }
                    //--TRIMMABLE-BOUNDARY-END(4385144833)
                    
                    static $h = 196616;
                    static $f = 0b10000000011010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770000392),
    {
      "p": $.$$.System.Memory$$(T).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(196616)|0x500000000n),
        "f": 50331649
      },
      "n": "Memory",
      "d": 196616,
      "h": Number(BigInt(196616)|0x600000000n),
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770000392)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885098504),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 196616,
      "h": Number(BigInt(196616)|0x300000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885098504)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295163912),
    {
      "t": $.$typeArray(T).$h,
      "n": "_array",
      "d": 196616,
      "h": Number(BigInt(196616)|0x100000000n),
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295163912)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590131208),
    {
      "p": [
        {
          "n": "size",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196616,
      "h": Number(BigInt(196616)|0x200000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590131208)
  ],
  "i": [$.$$.System.Buffers.IMemoryOwner$$(T).$h,90177537
  ],
  "d": $.$sm.System.Buffers.ArrayMemoryPool$$(T).$h,
  "h": 196616
}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Buffers.IMemoryOwner$$(T), $.$$.System.IDisposable ]; }
                    static get $fullName() { return `System.Buffers.ArrayMemoryPool<${T?.$fullName}>.ArrayMemoryPoolBuffer`; }
                }, $cls, ($v) => $cls.$_ArrayMemoryPoolBuffer = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(196616)
            
            //default reference type constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                return this;
            }
            static $h = 131080;
            static $g = 1;
            static $f = 0b11010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 25769934856, 38655098888),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": Number(BigInt(this.$h)|0x500000000n),
        "f": 50429953
      },
      "n": "MaxBufferSize",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x600000000n),
      "f": 2195457
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25769934856, 38655098888)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 30064902152, 42950066184),
    {
      "r": $.$$.System.Buffers.IMemoryOwner$$(T).$h,
      "p": [
        {
          "n": "minimumBufferSize",
          "p": 655361,
          "f": 65,
          "v": -1
        }
      ],
      "n": "Rent",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x700000000n),
      "f": 16875521
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30064902152, 42950066184),
//--TRIMMABLE-BOUNDARY-START(ALL, 12885032968, 17180262408),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x300000000n),
      "f": 16875524
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 12885032968, 17180262408)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098376),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": this.$h,
      "h": Number(BigInt(this.$h)|0x100000000n),
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098376)
  ],
  "i": [90177537
  ],
  "g": [T?.$h??1507328
  ],
  "j": [196616
  ],
  "r": 1,
  "h": this.$h
}; }
            static get $b() { return $.$sm.System.Buffers.MemoryPool$$(T); }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Buffers.ArrayMemoryPool<${T?.$fullName}>`; }
        }));
        //--TRIMMABLE-BOUNDARY-END(131080)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179656)
        $asm.$str("$sm.System.SequencePosition", ($self) => class SequencePosition extends $.$$.System.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(8591114248)
            /*object?*/  get _object() { return this.$getField(0, 4); }
            /*object?*/  set _object(value) { this.$setField(0, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(8591114248)
            
            //--TRIMMABLE-BOUNDARY-START(4296146952)
            /*int*/  get _integer() { return this.$getField(4, 4); }
            /*int*/  set _integer(value) { this.$setField(4, 4, value); }
            //--TRIMMABLE-BOUNDARY-END(4296146952)
            
            //--TRIMMABLE-BOUNDARY-START(12886081544)
            $ctor$3(/*object?*/ object, /*int*/ integer)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886081544);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._object = object;
                    this._integer = integer;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886081544)
            
            //--TRIMMABLE-BOUNDARY-START(38655885320)
            /*object? */ GetObject()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655885320);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._object;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38655885320)
            
            //--TRIMMABLE-BOUNDARY-START(34360918024)
            /*int */ GetInteger()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34360918024);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._integer;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360918024)
            
            //--TRIMMABLE-BOUNDARY-START(21476016136)
            /*bool */ Equals$2(/*SequencePosition*/ other)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476016136);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._integer === other._integer && $.$$.System.Object.Equals(this._object, other._object);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21476016136)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25770983432, 34359869441)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770983432);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let other;
                    return $.$is(obj, $.$sm.System.SequencePosition, { set $v(v){ other = v; } }) && this.Equals$2(other);
                }
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sm.System.SequencePosition.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25770983432, 34359869441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 30065950728, 184683724801)
            static/*conventional*/ /*int */ GetHashCode()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30065950728);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    const $t1 = this._object;
                    return $.$$.System.HashCode.Combine$6($.$$.System.Int32, $.$$.System.Int32, $.$ifnn($t1, ($t) => $.$$.System.Object.GetHashCode.call($t)) ?? 0, this._integer);
                }
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sm.System.SequencePosition.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(ALL, 30065950728, 184683724801)
            
            //--TRIMMABLE-BOUNDARY-START(4385210369)
            //Generated interface implemetation for System.IEquatable<System.SequencePosition>.Equals(System.SequencePosition)
            System$IEquatable$$$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385210369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385210369)
            
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._object = this._object;
                copy._integer = this._integer;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                //--TRIMMABLE-BOUNDARY-START(8591114248)
                this._object = null;
                //--TRIMMABLE-BOUNDARY-END(8591114248)
                
                //--TRIMMABLE-BOUNDARY-START(4296146952)
                this._integer = 0;
                //--TRIMMABLE-BOUNDARY-END(4296146952)
                
            }
            static $h = 1179656;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 196609,
  "m": [
//--TRIMMABLE-BOUNDARY-START(38655885320),
    {
      "r": 131073,
      "n": "GetObject",
      "d": 1179656,
      "h": 38655885320,
      "f": 16777217,
      "a": [
        {
          "t": 64159745,
          "c": 4359127041,
          "a": [
            {
              "v": 1,
              "t": 64225281
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655885320),
//--TRIMMABLE-BOUNDARY-START(34360918024),
    {
      "r": 655361,
      "n": "GetInteger",
      "d": 1179656,
      "h": 34360918024,
      "f": 16777217,
      "a": [
        {
          "t": 64159745,
          "c": 4359127041,
          "a": [
            {
              "v": 1,
              "t": 64225281
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360918024),
//--TRIMMABLE-BOUNDARY-START(21476016136),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 1179656
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 1179656,
      "h": 21476016136,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476016136),
//--TRIMMABLE-BOUNDARY-START(ALL, 25770983432, 34359869441),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1179656,
      "h": 25770983432,
      "f": 16809985,
      "a": [
        {
          "t": 64159745,
          "c": 4359127041,
          "a": [
            {
              "v": 1,
              "t": 64225281
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25770983432, 34359869441),
//--TRIMMABLE-BOUNDARY-START(ALL, 30065950728, 184683724801),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1179656,
      "h": 30065950728,
      "f": 16809985,
      "a": [
        {
          "t": 64159745,
          "c": 4359127041,
          "a": [
            {
              "v": 1,
              "t": 64225281
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30065950728, 184683724801)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591114248),
    {
      "t": 131073,
      "n": "_object",
      "d": 1179656,
      "h": 8591114248,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591114248),
//--TRIMMABLE-BOUNDARY-START(4296146952),
    {
      "t": 655361,
      "n": "_integer",
      "d": 1179656,
      "h": 4296146952,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296146952)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12886081544),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "integer",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1179656,
      "h": 12886081544,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886081544),
//--TRIMMABLE-BOUNDARY-START(17181048840),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1179656,
      "h": 17181048840,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181048840)
  ],
  "i": [$.$$.System.IEquatable$$($.$sm.System.SequencePosition).$h
  ],
  "h": 1179656
}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sm.System.SequencePosition) ]; }
            static get $fullName() { return `System.SequencePosition`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179656)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048584)
        $asm.$str("$sm.System.ExceptionArgument", ($self) => class ExceptionArgument extends $.$$.System.Enum
        {
            static length = 0;
            static start = 1;
            static minimumBufferSize = 2;
            static elementIndex = 3;
            static comparable = 4;
            static comparer = 5;
            static destination = 6;
            static offset = 7;
            static startSegment = 8;
            static endSegment = 9;
            static startIndex = 10;
            static endIndex = 11;
            static array = 12;
            static culture = 13;
            static manager = 14;
            static count = 15;
            static writer = 16;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1048584);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "length": 0n,
                    "start": 1n,
                    "minimumBufferSize": 2n,
                    "elementIndex": 3n,
                    "comparable": 4n,
                    "comparer": 5n,
                    "destination": 6n,
                    "offset": 7n,
                    "startSegment": 8n,
                    "endSegment": 9n,
                    "startIndex": 10n,
                    "endIndex": 11n,
                    "array": 12n,
                    "culture": 13n,
                    "manager": 14n,
                    "count": 15n,
                    "writer": 16n
                };
            }
            static $h = 1048584;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(47245688840),
    {
      "t": 1048584,
      "n": "length",
      "d": 1048584,
      "h": 47245688840,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245688840),
//--TRIMMABLE-BOUNDARY-START(64425558024),
    {
      "t": 1048584,
      "n": "start",
      "d": 1048584,
      "h": 64425558024,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425558024),
//--TRIMMABLE-BOUNDARY-START(55835623432),
    {
      "t": 1048584,
      "n": "minimumBufferSize",
      "d": 1048584,
      "h": 55835623432,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835623432),
//--TRIMMABLE-BOUNDARY-START(34360786952),
    {
      "t": 1048584,
      "n": "elementIndex",
      "d": 1048584,
      "h": 34360786952,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360786952),
//--TRIMMABLE-BOUNDARY-START(12885950472),
    {
      "t": 1048584,
      "n": "comparable",
      "d": 1048584,
      "h": 12885950472,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885950472),
//--TRIMMABLE-BOUNDARY-START(17180917768),
    {
      "t": 1048584,
      "n": "comparer",
      "d": 1048584,
      "h": 17180917768,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180917768),
//--TRIMMABLE-BOUNDARY-START(30065819656),
    {
      "t": 1048584,
      "n": "destination",
      "d": 1048584,
      "h": 30065819656,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065819656),
//--TRIMMABLE-BOUNDARY-START(60130590728),
    {
      "t": 1048584,
      "n": "offset",
      "d": 1048584,
      "h": 60130590728,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130590728),
//--TRIMMABLE-BOUNDARY-START(73015492616),
    {
      "t": 1048584,
      "n": "startSegment",
      "d": 1048584,
      "h": 73015492616,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015492616),
//--TRIMMABLE-BOUNDARY-START(42950721544),
    {
      "t": 1048584,
      "n": "endSegment",
      "d": 1048584,
      "h": 42950721544,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950721544),
//--TRIMMABLE-BOUNDARY-START(68720525320),
    {
      "t": 1048584,
      "n": "startIndex",
      "d": 1048584,
      "h": 68720525320,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720525320),
//--TRIMMABLE-BOUNDARY-START(38655754248),
    {
      "t": 1048584,
      "n": "endIndex",
      "d": 1048584,
      "h": 38655754248,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655754248),
//--TRIMMABLE-BOUNDARY-START(8590983176),
    {
      "t": 1048584,
      "n": "array",
      "d": 1048584,
      "h": 8590983176,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590983176),
//--TRIMMABLE-BOUNDARY-START(25770852360),
    {
      "t": 1048584,
      "n": "culture",
      "d": 1048584,
      "h": 25770852360,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770852360),
//--TRIMMABLE-BOUNDARY-START(51540656136),
    {
      "t": 1048584,
      "n": "manager",
      "d": 1048584,
      "h": 51540656136,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540656136),
//--TRIMMABLE-BOUNDARY-START(21475885064),
    {
      "t": 1048584,
      "n": "count",
      "d": 1048584,
      "h": 21475885064,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475885064),
//--TRIMMABLE-BOUNDARY-START(77310459912),
    {
      "t": 1048584,
      "n": "writer",
      "d": 1048584,
      "h": 77310459912,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310459912)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015880),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1048584,
      "h": 4296015880,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015880)
  ],
  "i": [89915393,96468993,90374145,90046465
  ],
  "h": 1048584
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.ExceptionArgument`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048584)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib"))
//--TRIMMABLE-BOUNDARY-END(8)
