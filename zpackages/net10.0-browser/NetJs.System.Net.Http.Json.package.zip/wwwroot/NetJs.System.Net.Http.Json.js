
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $sicb, $sipl, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $sre, $srei, $srel, $srp, $srl, $stew, $str, $stj) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Http.Json", 
    {"h":33742,"f":"System.Net.Http.Json","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Http.Json","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Http.Json","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snhj.System.Net.Http.Json.HttpClientJsonExtensions", ($self) => class HttpClientJsonExtensions
        {
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync$1(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, null, null);
                return client.PutAsync(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync$4(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, null, null);
                return client.PutAsync$2(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PutAsJsonAsync$1(TValue, client, requestUri, value, null, new $.$$.System.Threading.CancellationToken());
            }
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync$3(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PutAsJsonAsync$4(TValue, client, requestUri, value, null, new $.$$.System.Threading.CancellationToken());
            }
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync$2(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$3(TValue, value, jsonTypeInfo, null);
                return client.PutAsync(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync$5(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$3(TValue, value, jsonTypeInfo, null);
                return client.PutAsync$2(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync$1(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, null, null);
                return client.PostAsync(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync$4(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, null, null);
                return client.PostAsync$2(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PostAsJsonAsync$1(TValue, client, requestUri, value, null, new $.$$.System.Threading.CancellationToken());
            }
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync$3(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PostAsJsonAsync$4(TValue, client, requestUri, value, null, new $.$$.System.Threading.CancellationToken());
            }
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync$2(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$3(TValue, value, jsonTypeInfo, null);
                return client.PostAsync(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync$5(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$3(TValue, value, jsonTypeInfo, null);
                return client.PostAsync$2(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync$1(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, null, null);
                return client.PatchAsync(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync$4(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, null, null);
                return client.PatchAsync$2(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PatchAsJsonAsync$1(TValue, client, requestUri, value, null, new $.$$.System.Threading.CancellationToken());
            }
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync$3(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PatchAsJsonAsync$4(TValue, client, requestUri, value, null, new $.$$.System.Threading.CancellationToken());
            }
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync$2(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$3(TValue, value, jsonTypeInfo, null);
                return client.PatchAsync(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync$5(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$3(TValue, value, jsonTypeInfo, null);
                return client.PatchAsync$2(requestUri, content, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable$1(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsAsyncEnumerable$4(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), options, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable$4(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonStreamAsyncCore(TValue, client, requestUri, options, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable$2(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsAsyncEnumerable$5(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), jsonTypeInfo, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable$5(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonStreamAsyncCore$1(TValue, client, requestUri, jsonTypeInfo, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsAsyncEnumerable$1(TValue, client, requestUri, null, new $.$$.System.Threading.CancellationToken());
            }
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable$3(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsAsyncEnumerable$4(TValue, client, requestUri, null, new $.$$.System.Threading.CancellationToken());
            }
            static /*IAsyncEnumerable<TValue?> */ FromJsonStreamAsyncCore(TValue, /*HttpClient*/ client, /*Uri?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                /*var*/ let jsonTypeInfo = $.$cast($.$snhj.System.Net.Http.Json.JsonHelpers.GetJsonTypeInfo(TValue.$type, options), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue));
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonStreamAsyncCore$1(TValue, client, requestUri, jsonTypeInfo, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ FromJsonStreamAsyncCore$1(TValue, /*HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                return Core(client, requestUri, jsonTypeInfo, cancellationToken);
                /*static IAsyncEnumerable<TValue?>*/ /*async*/  function Core(/*HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
                {
                    return new ($.$$.NetJs.YieldToIterator$$(TValue))().$ctor$1(async function*()
                    {
                        /*HttpResponseMessage*/ let response = await client.GetAsync$5(requestUri, 1/*HttpCompletionOption.ResponseHeadersRead*/, cancellationToken).ConfigureAwait$2(false);
                        try
                        {
                            response.EnsureSuccessStatusCode();
                            /*Stream*/ let readStream = await $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetHttpResponseStreamAsync(client, response, false, cancellationToken).ConfigureAwait(false);
                            try
                            {
                                var $en6 = $.$$.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait$1(TValue, $.$stj.System.Text.Json.JsonSerializer.DeserializeAsyncEnumerable$3(TValue, readStream, jsonTypeInfo, cancellationToken), false).GetAsyncEnumerator();
                                while (await $en6.MoveNextAsync())
                                {
                                    var value = $en6.Current;
                                    {
                                        yield value;
                                    }
                                }
                            }
                            finally
                            {
                                readStream?.System$IDisposable$Dispose();
                            }
                        }
                        finally
                        {
                            response?.System$IDisposable$Dispose();
                        }
                    }.bind(this));
                }
            }
            /*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ static s_deleteAsync = null;
            static /*Task<object?> */ DeleteFromJsonAsync$1(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$4(client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), type, options, cancellationToken);
            }
            static /*Task<object?> */ DeleteFromJsonAsync$4(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_deleteAsync, client, requestUri, type, options, cancellationToken);
            }
            static /*Task<TValue?> */ DeleteFromJsonAsync$7(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$10(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), options, cancellationToken);
            }
            static /*Task<TValue?> */ DeleteFromJsonAsync$10(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$3(TValue, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_deleteAsync, client, requestUri, options, cancellationToken);
            }
            static /*Task<object?> */ DeleteFromJsonAsync$2(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$5(client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), type, context, cancellationToken);
            }
            static /*Task<object?> */ DeleteFromJsonAsync$5(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$1($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_deleteAsync, client, requestUri, type, context, cancellationToken);
            }
            static /*Task<TValue?> */ DeleteFromJsonAsync$8(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$11(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), jsonTypeInfo, cancellationToken);
            }
            static /*Task<TValue?> */ DeleteFromJsonAsync$11(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$4(TValue, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_deleteAsync, client, requestUri, jsonTypeInfo, cancellationToken);
            }
            static /*Task<object?> */ DeleteFromJsonAsync(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$1(client, requestUri, type, null, new $.$$.System.Threading.CancellationToken());
            }
            static /*Task<object?> */ DeleteFromJsonAsync$3(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$4(client, requestUri, type, null, new $.$$.System.Threading.CancellationToken());
            }
            static /*Task<TValue?> */ DeleteFromJsonAsync$6(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$7(TValue, client, requestUri, null, new $.$$.System.Threading.CancellationToken());
            }
            static /*Task<TValue?> */ DeleteFromJsonAsync$9(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$10(TValue, client, requestUri, null, new $.$$.System.Threading.CancellationToken());
            }
            /*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ static s_getAsync = null;
            static /*Task<object?> */ GetFromJsonAsync$1(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$4(client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), type, options, cancellationToken);
            }
            static /*Task<object?> */ GetFromJsonAsync$4(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore(new ($.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)))().$ctor($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions, /*static*/ (/*client*/ client, /*uri*/ uri, /*cancellation*/ cancellation) =>
                {
                    return client.GetAsync$5(uri, 1/*HttpCompletionOption.ResponseHeadersRead*/, cancellation);
                }, {"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"uri","p":1746220},{"n":"cancellation","p":125829121}],"n":"","d":99278,"h":0,"f":17825826}), client, requestUri, type, options, cancellationToken);
            }
            static /*Task<TValue?> */ GetFromJsonAsync$7(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$10(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), options, cancellationToken);
            }
            static /*Task<TValue?> */ GetFromJsonAsync$10(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$3(TValue, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_getAsync, client, requestUri, options, cancellationToken);
            }
            static /*Task<object?> */ GetFromJsonAsync$2(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$5(client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), type, context, cancellationToken);
            }
            static /*Task<object?> */ GetFromJsonAsync$5(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$1($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_getAsync, client, requestUri, type, context, cancellationToken);
            }
            static /*Task<TValue?> */ GetFromJsonAsync$8(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$11(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), jsonTypeInfo, cancellationToken);
            }
            static /*Task<TValue?> */ GetFromJsonAsync$11(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$4(TValue, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_getAsync, client, requestUri, jsonTypeInfo, cancellationToken);
            }
            static /*Task<object?> */ GetFromJsonAsync(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$1(client, requestUri, type, null, new $.$$.System.Threading.CancellationToken());
            }
            static /*Task<object?> */ GetFromJsonAsync$3(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$4(client, requestUri, type, null, new $.$$.System.Threading.CancellationToken());
            }
            static /*Task<TValue?> */ GetFromJsonAsync$6(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$7(TValue, client, requestUri, null, new $.$$.System.Threading.CancellationToken());
            }
            static /*Task<TValue?> */ GetFromJsonAsync$9(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$10(TValue, client, requestUri, null, new $.$$.System.Threading.CancellationToken());
            }
            static /*Task<object?> */ FromJsonAsyncCore(/*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ getMethod, /*HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$2($.$$.System.Object, $.$$.System.ValueTuple$$$($.$$.System.Type, $.$stj.System.Text.Json.JsonSerializerOptions), getMethod, client, requestUri, new ($.$$.System.Func$$$$$($.$$.System.IO.Stream, $.$$.System.ValueTuple$$$($.$$.System.Type, $.$stj.System.Text.Json.JsonSerializerOptions), $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Object)))().$ctor($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions, /*static*/ (/*stream*/ stream, /*options*/ options, /*cancellation*/ cancellation) =>
                {
                    return $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync(stream, options.Item1, options.Item2 ?? $.$stj.System.Text.Json.JsonSerializerOptions.Web, cancellation);
                }, {"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Object).$h,"p":[{"n":"stream","p":62193665},{"n":"options","p":$.$$.System.ValueTuple$$$($.$$.System.Type, $.$stj.System.Text.Json.JsonSerializerOptions).$h},{"n":"cancellation","p":125829121}],"n":"","d":99278,"h":0,"f":17825826}), new ($.$$.System.ValueTuple$$$($.$$.System.Type, $.$stj.System.Text.Json.JsonSerializerOptions))().$ctor$3(type, options), cancellationToken);
            }
            static /*Task<TValue?> */ FromJsonAsyncCore$3(TValue, /*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ getMethod, /*HttpClient*/ client, /*Uri?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$2(TValue, $.$stj.System.Text.Json.JsonSerializerOptions, getMethod, client, requestUri, new ($.$$.System.Func$$$$$($.$$.System.IO.Stream, $.$stj.System.Text.Json.JsonSerializerOptions, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.ValueTask$$(TValue)))().$ctor($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions, /*static*/ (/*stream*/ stream, /*options*/ options, /*cancellation*/ cancellation) =>
                {
                    return $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$6(TValue, stream, options ?? $.$stj.System.Text.Json.JsonSerializerOptions.Web, cancellation);
                }, {"r":(TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"stream","p":62193665},{"n":"options","p":3388355},{"n":"cancellation","p":125829121}],"n":"","d":99278,"h":0,"f":17825826}), options, cancellationToken);
            }
            static /*Task<object?> */ FromJsonAsyncCore$1(/*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ getMethod, /*HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$2($.$$.System.Object, $.$$.System.ValueTuple$$$($.$$.System.Type, $.$stj.System.Text.Json.Serialization.JsonSerializerContext), getMethod, client, requestUri, new ($.$$.System.Func$$$$$($.$$.System.IO.Stream, $.$$.System.ValueTuple$$$($.$$.System.Type, $.$stj.System.Text.Json.Serialization.JsonSerializerContext), $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Object)))().$ctor($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions, /*static*/ (/*stream*/ stream, /*options*/ options, /*cancellation*/ cancellation) =>
                {
                    return $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$1(stream, options.Item1, options.Item2, cancellation);
                }, {"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Object).$h,"p":[{"n":"stream","p":62193665},{"n":"options","p":$.$$.System.ValueTuple$$$($.$$.System.Type, $.$stj.System.Text.Json.Serialization.JsonSerializerContext).$h},{"n":"cancellation","p":125829121}],"n":"","d":99278,"h":0,"f":17825826}), new ($.$$.System.ValueTuple$$$($.$$.System.Type, $.$stj.System.Text.Json.Serialization.JsonSerializerContext))().$ctor$3(type, context), cancellationToken);
            }
            static /*Task<TValue?> */ FromJsonAsyncCore$4(TValue, /*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ getMethod, /*HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$2(TValue, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue), getMethod, client, requestUri, new ($.$$.System.Func$$$$$($.$$.System.IO.Stream, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue), $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.ValueTask$$(TValue)))().$ctor($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions, /*static*/ (/*stream*/ stream, /*options*/ options, /*cancellation*/ cancellation) =>
                {
                    return $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$7(TValue, stream, options, cancellation);
                }, {"r":(TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,"p":[{"n":"stream","p":62193665},{"n":"options","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellation","p":125829121}],"n":"","d":99278,"h":0,"f":17825826}), jsonTypeInfo, cancellationToken);
            }
            static /*Task<TValue?> */ FromJsonAsyncCore$2(TValue, TJsonOptions, /*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ getMethod, /*HttpClient*/ client, /*Uri?*/ requestUri, /*Func<Stream, TJsonOptions, CancellationToken, ValueTask<TValue?>>*/ deserializeMethod, /*TJsonOptions*/ jsonOptions, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*TimeSpan*/ let timeout = client.Timeout;
                /*CancellationTokenSource?*/ let linkedCTS = null;
                if ($.$$.System.TimeSpan.op_Inequality(timeout, $.$$.System.Threading.Timeout.InfiniteTimeSpan))
                {
                    linkedCTS = $.$$.System.Threading.CancellationTokenSource.CreateLinkedTokenSource$2(cancellationToken);
                    linkedCTS.CancelAfter$1(timeout);
                }
                /*Task<HttpResponseMessage>*/ let responseTask;
                try
                {
                    responseTask = getMethod.Invoke(client, requestUri, cancellationToken);
                }
                catch($e)
                {
                    linkedCTS?.Dispose();
                    throw $e;
                }
                /*bool*/ let usingResponseHeadersRead = !$.$$.System.Object.ReferenceEquals(getMethod, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_deleteAsync);
                return Core(client, responseTask, usingResponseHeadersRead, linkedCTS, deserializeMethod, jsonOptions, cancellationToken);
                /*static Task<TValue?>*/ /*async*/  function Core(/*HttpClient*/ client, /*Task<HttpResponseMessage>*/ responseTask, /*bool*/ usingResponseHeadersRead, /*CancellationTokenSource?*/ linkedCTS, /*Func<Stream, TJsonOptions, CancellationToken, ValueTask<TValue?>>*/ deserializeMethod, /*TJsonOptions*/ jsonOptions, /*CancellationToken*/ cancellationToken)
                {
                    return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$(TValue), TValue, async () => 
                    {
                        try
                        {
                            /*HttpResponseMessage*/ let response = await responseTask.ConfigureAwait$2(false);
                            try
                            {
                                response.EnsureSuccessStatusCode();
                                try
                                {
                                    /*Stream*/ let readStream = await $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetHttpResponseStreamAsync(client, response, usingResponseHeadersRead, cancellationToken).ConfigureAwait(false);
                                    try
                                    {
                                        return await deserializeMethod.Invoke(readStream, jsonOptions, (linkedCTS?.Token ?? null) ?? cancellationToken).ConfigureAwait(false);
                                    }
                                    finally
                                    {
                                        readStream?.System$IDisposable$Dispose();
                                    }
                                }
                                catch(oce)
                                {
                                    /*string*/ let message = $.$snhj.System.SR.Format$6($.$snhj.System.SR.net_http_request_timedout, $.$box(client.Timeout.TotalSeconds, $.$$.System.Double));
                                    throw new $.$$.System.Threading.Tasks.TaskCanceledException().$ctor$18(message, new $.$$.System.TimeoutException().$ctor$11(oce.Message, oce), oce.CancellationToken);
                                }
                            }
                            finally
                            {
                                response?.System$IDisposable$Dispose();
                            }
                        }
                        finally
                        {
                            {
                                linkedCTS?.Dispose();
                            }
                        }
                    });
                }
            }
            static /*Uri? */ CreateUri(/*string?*/ uri)
            {
                return $.$$.System.String.IsNullOrEmpty(uri) ? null : new $.$spu.System.Uri().$ctor$3(uri, 0/*UriKind.RelativeOrAbsolute*/);
            }
            static /*ValueTask<Stream> */ GetHttpResponseStreamAsync(/*HttpClient*/ client, /*HttpResponseMessage*/ response, /*bool*/ usingResponseHeadersRead, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.Diagnostics.Debug.Assert$2((client.MaxResponseContentBufferSize > 0n) && (client.MaxResponseContentBufferSize <= BigInt(2147483647/*int.MaxValue*/)), "client.MaxResponseContentBufferSize is > 0 and <= int.MaxValue");
                /*int*/ let contentLengthLimit = $.$cast(client.MaxResponseContentBufferSize, $.$$.System.Int32);
                let contentLength;
                if ($.$is(response.Content.Headers.ContentLength, $.$$.System.Int64, { set $v(v){ contentLength = v; } }) && contentLength > BigInt(contentLengthLimit))
                {
                    $.$snhj.System.Net.Http.Json.LengthLimitReadStream.ThrowExceededBufferLimit(contentLengthLimit);
                }
                /*ValueTask<Stream>*/ let task = $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(response.Content, cancellationToken);
                return usingResponseHeadersRead ? $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetLengthLimitReadStreamAsync(client, task) : task;
            }
            static /*ValueTask<Stream> *//*async*/  GetLengthLimitReadStreamAsync(/*HttpClient*/ client, /*ValueTask<Stream>*/ task)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream), $.$$.System.IO.Stream, async () => 
                {
                    /*Stream*/ let contentStream = await task.ConfigureAwait(false);
                    return new $.$snhj.System.Net.Http.Json.LengthLimitReadStream().$ctor$3(contentStream, $.$cast(client.MaxResponseContentBufferSize, $.$$.System.Int32));
                });
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_deleteAsync = new ($.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)))().$ctor($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions, /*static*/ (/*client*/ client, /*uri*/ uri, /*cancellation*/ cancellation) =>
                    {
                        return client.DeleteAsync$2(uri, cancellation);
                    }, {"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"uri","p":1746220},{"n":"cancellation","p":125829121}],"n":"","d":99278,"h":0,"f":17825826});
                }
                {
                    this.s_getAsync = new ($.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)))().$ctor($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions, /*static*/ (/*client*/ client, /*uri*/ uri, /*cancellation*/ cancellation) =>
                    {
                        return client.GetAsync$5(uri, 1/*HttpCompletionOption.ResponseHeadersRead*/, cancellation);
                    }, {"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"uri","p":1746220},{"n":"cancellation","p":125829121}],"n":"","d":99278,"h":0,"f":17825826});
                }
            }
            static $h = 99278;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":(TValue) => TValue.$h},{"n":"options","p":3388355,"f":65},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"PutAsJsonAsync","o":"@$1","d":99278,"h":4295066574,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"value","p":(TValue) => TValue.$h},{"n":"options","p":3388355,"f":65},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"PutAsJsonAsync","o":"@$4","d":99278,"h":8590033870,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":(TValue) => TValue.$h},{"n":"cancellationToken","p":125829121}],"g":["TValue"],"n":"PutAsJsonAsync","d":99278,"h":12885001166,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"value","p":(TValue) => TValue.$h},{"n":"cancellationToken","p":125829121}],"g":["TValue"],"n":"PutAsJsonAsync","o":"@$3","d":99278,"h":17179968462,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":(TValue) => TValue.$h},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"PutAsJsonAsync","o":"@$2","d":99278,"h":21474935758,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"value","p":(TValue) => TValue.$h},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"PutAsJsonAsync","o":"@$5","d":99278,"h":25769903054,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":(TValue) => TValue.$h},{"n":"options","p":3388355,"f":65},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"PostAsJsonAsync","o":"@$1","d":99278,"h":30064870350,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"value","p":(TValue) => TValue.$h},{"n":"options","p":3388355,"f":65},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"PostAsJsonAsync","o":"@$4","d":99278,"h":34359837646,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":(TValue) => TValue.$h},{"n":"cancellationToken","p":125829121}],"g":["TValue"],"n":"PostAsJsonAsync","d":99278,"h":38654804942,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"value","p":(TValue) => TValue.$h},{"n":"cancellationToken","p":125829121}],"g":["TValue"],"n":"PostAsJsonAsync","o":"@$3","d":99278,"h":42949772238,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":(TValue) => TValue.$h},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"PostAsJsonAsync","o":"@$2","d":99278,"h":47244739534,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"value","p":(TValue) => TValue.$h},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"PostAsJsonAsync","o":"@$5","d":99278,"h":51539706830,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":(TValue) => TValue.$h},{"n":"options","p":3388355,"f":65},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"PatchAsJsonAsync","o":"@$1","d":99278,"h":55834674126,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"value","p":(TValue) => TValue.$h},{"n":"options","p":3388355,"f":65},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"PatchAsJsonAsync","o":"@$4","d":99278,"h":60129641422,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":(TValue) => TValue.$h},{"n":"cancellationToken","p":125829121}],"g":["TValue"],"n":"PatchAsJsonAsync","d":99278,"h":64424608718,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"value","p":(TValue) => TValue.$h},{"n":"cancellationToken","p":125829121}],"g":["TValue"],"n":"PatchAsJsonAsync","o":"@$3","d":99278,"h":68719576014,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":(TValue) => TValue.$h},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"PatchAsJsonAsync","o":"@$2","d":99278,"h":73014543310,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"value","p":(TValue) => TValue.$h},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"PatchAsJsonAsync","o":"@$5","d":99278,"h":77309510606,"f":16908321},{"r":(TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"GetFromJsonAsAsyncEnumerable","o":"@$1","d":99278,"h":81604477902,"f":16908321},{"r":(TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"GetFromJsonAsAsyncEnumerable","o":"@$4","d":99278,"h":85899445198,"f":16908321},{"r":(TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"GetFromJsonAsAsyncEnumerable","o":"@$2","d":99278,"h":90194412494,"f":16908321},{"r":(TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"GetFromJsonAsAsyncEnumerable","o":"@$5","d":99278,"h":94489379790,"f":16908321},{"r":(TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"GetFromJsonAsAsyncEnumerable","d":99278,"h":98784347086,"f":16908321},{"r":(TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"GetFromJsonAsAsyncEnumerable","o":"@$3","d":99278,"h":103079314382,"f":16908321},{"r":(TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121}],"g":["TValue"],"n":"FromJsonStreamAsyncCore","d":99278,"h":107374281678,"f":16908322},{"r":(TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125829121}],"g":["TValue"],"n":"FromJsonStreamAsyncCore","o":"@$1","d":99278,"h":111669248974,"f":16908322},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"type","p":142475265},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121,"f":65}],"n":"DeleteFromJsonAsync","o":"@$1","d":99278,"h":120259183566,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"type","p":142475265},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121,"f":65}],"n":"DeleteFromJsonAsync","o":"@$4","d":99278,"h":124554150862,"f":16777249},{"r":(TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"DeleteFromJsonAsync","o":"@$7","d":99278,"h":128849118158,"f":16908321},{"r":(TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"DeleteFromJsonAsync","o":"@$10","d":99278,"h":133144085454,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"type","p":142475265},{"n":"context","p":14791619},{"n":"cancellationToken","p":125829121,"f":65}],"n":"DeleteFromJsonAsync","o":"@$2","d":99278,"h":137439052750,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"type","p":142475265},{"n":"context","p":14791619},{"n":"cancellationToken","p":125829121,"f":65}],"n":"DeleteFromJsonAsync","o":"@$5","d":99278,"h":141734020046,"f":16777249},{"r":(TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"DeleteFromJsonAsync","o":"@$8","d":99278,"h":146028987342,"f":16908321},{"r":(TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"DeleteFromJsonAsync","o":"@$11","d":99278,"h":150323954638,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"type","p":142475265},{"n":"cancellationToken","p":125829121,"f":65}],"n":"DeleteFromJsonAsync","d":99278,"h":154618921934,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"type","p":142475265},{"n":"cancellationToken","p":125829121,"f":65}],"n":"DeleteFromJsonAsync","o":"@$3","d":99278,"h":158913889230,"f":16777249},{"r":(TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"DeleteFromJsonAsync","o":"@$6","d":99278,"h":163208856526,"f":16908321},{"r":(TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"DeleteFromJsonAsync","o":"@$9","d":99278,"h":167503823822,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"type","p":142475265},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121,"f":65}],"n":"GetFromJsonAsync","o":"@$1","d":99278,"h":176093758414,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"type","p":142475265},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121,"f":65}],"n":"GetFromJsonAsync","o":"@$4","d":99278,"h":180388725710,"f":16777249},{"r":(TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"GetFromJsonAsync","o":"@$7","d":99278,"h":184683693006,"f":16908321},{"r":(TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"GetFromJsonAsync","o":"@$10","d":99278,"h":188978660302,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"type","p":142475265},{"n":"context","p":14791619},{"n":"cancellationToken","p":125829121,"f":65}],"n":"GetFromJsonAsync","o":"@$2","d":99278,"h":193273627598,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"type","p":142475265},{"n":"context","p":14791619},{"n":"cancellationToken","p":125829121,"f":65}],"n":"GetFromJsonAsync","o":"@$5","d":99278,"h":197568594894,"f":16777249},{"r":(TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"GetFromJsonAsync","o":"@$8","d":99278,"h":201863562190,"f":16908321},{"r":(TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"GetFromJsonAsync","o":"@$11","d":99278,"h":206158529486,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"type","p":142475265},{"n":"cancellationToken","p":125829121,"f":65}],"n":"GetFromJsonAsync","d":99278,"h":210453496782,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"type","p":142475265},{"n":"cancellationToken","p":125829121,"f":65}],"n":"GetFromJsonAsync","o":"@$3","d":99278,"h":214748464078,"f":16777249},{"r":(TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"GetFromJsonAsync","o":"@$6","d":99278,"h":219043431374,"f":16908321},{"r":(TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"GetFromJsonAsync","o":"@$9","d":99278,"h":223338398670,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"getMethod","p":$.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h},{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"type","p":142475265},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121,"f":65}],"n":"FromJsonAsyncCore","d":99278,"h":227633365966,"f":16777250},{"r":(TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"getMethod","p":$.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h},{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"FromJsonAsyncCore","o":"@$3","d":99278,"h":231928333262,"f":16908322},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"getMethod","p":$.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h},{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"type","p":142475265},{"n":"context","p":14791619},{"n":"cancellationToken","p":125829121,"f":65}],"n":"FromJsonAsyncCore","o":"@$1","d":99278,"h":236223300558,"f":16777250},{"r":(TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"getMethod","p":$.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h},{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125829121}],"g":["TValue"],"n":"FromJsonAsyncCore","o":"@$4","d":99278,"h":240518267854,"f":16908322},{"r":(TValue, TJsonOptions) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"getMethod","p":$.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h},{"n":"client","p":6422573},{"n":"requestUri","p":1746220},{"n":"deserializeMethod","p":(TValue, TJsonOptions) => $.$$.System.Func$$$$$($.$$.System.IO.Stream, TJsonOptions, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.ValueTask$$(TValue)).$h},{"n":"jsonOptions","p":(TValue, TJsonOptions) => TJsonOptions.$h},{"n":"cancellationToken","p":125829121}],"g":["TValue","TJsonOptions"],"n":"FromJsonAsyncCore","o":"@$2","d":99278,"h":244813235150,"f":16908322},{"r":1746220,"p":[{"n":"uri","p":1310721}],"n":"CreateUri","d":99278,"h":249108202446,"f":16777250},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream).$h,"p":[{"n":"client","p":6422573},{"n":"response","p":7733293},{"n":"usingResponseHeadersRead","p":262145},{"n":"cancellationToken","p":125829121}],"n":"GetHttpResponseStreamAsync","d":99278,"h":253403169742,"f":16777250},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream).$h,"p":[{"n":"client","p":6422573},{"n":"task","p":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream).$h}],"n":"GetLengthLimitReadStreamAsync","d":99278,"h":257698137038,"f":16781346}],"l":[{"t":$.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h,"n":"s_deleteAsync","d":99278,"h":115964216270,"f":4194338},{"t":$.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h,"n":"s_getAsync","d":99278,"h":171798791118,"f":4194338}],"h":99278}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Http.Json.HttpClientJsonExtensions`; }
        });
        
        $asm.$cls("$snhj.System.Net.Http.Json.JsonHelpers", ($self) => class JsonHelpers
        {
            static /*JsonTypeInfo */ GetJsonTypeInfo(/*Type*/ type, /*JsonSerializerOptions?*/ options)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(!(type === null), "type is not null");
                options ??= $.$stj.System.Text.Json.JsonSerializerOptions.Web;
                options.MakeReadOnly$1(true);
                return options.GetTypeInfo(type);
            }
            /*string*/ static DefaultMediaType = null;
            static /*Encoding? */ GetEncoding(/*HttpContent*/ content)
            {
                /*Encoding?*/ let encoding = null;
                let charset;
                if ($.$is((content.Headers.ContentType?.CharSet ?? null), $.$$.System.String, { set $v(v){ charset = v; } }))
                {
                    try
                    {
                        if (charset.length > 2 && $.$$.System.String.get_Chars.call(charset, 0) === /*\"*/ 34 && $.$$.System.String.get_Chars.call(charset, ((charset.length - 1) | 0)) === /*\"*/ 34)
                        {
                            encoding = $.$$.System.Text.Encoding.GetEncoding$3($.$$.System.String.Substring.call(charset, 1, ((charset.length - 2) | 0)));
                        }
                        else 
                        {
                            encoding = $.$$.System.Text.Encoding.GetEncoding$3(charset);
                        }
                    }
                    catch(e)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$11($.$snhj.System.SR.CharSetInvalid, e);
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(encoding !== null, "encoding != null");
                }
                return encoding;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultMediaType = "application/json; charset=utf-8";
                }
            }
            static $h = 295886;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":16823235,"p":[{"n":"type","p":142475265},{"n":"options","p":3388355}],"n":"GetJsonTypeInfo","d":295886,"h":4295263182,"f":16777256},{"r":121700353,"p":[{"n":"content","p":6619181}],"n":"GetEncoding","d":295886,"h":12885197774,"f":16777256}],"l":[{"t":1310721,"n":"DefaultMediaType","d":295886,"h":8590230478,"f":4194344}],"h":295886}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Http.Json.JsonHelpers`; }
        });
        
        $asm.$cls("$snhj.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$snhj.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Net.Http.Json", $.$snhj.System.SR.$type.Assembly);
                    $.$snhj.System.SR.s_resourceManager = temp;
                }
                return $.$snhj.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$snhj.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$snhj.System.SR.resourceCulture = value;
            }
            static /*string */ get Argument_InvalidOffLen()
            {
                return "Offset and length were out of bounds for the array or count is greater than the number of elements from index to the end of the source collection.";
            }
            static /*string */ get CharSetInvalid()
            {
                return "The character set provided in ContentType is invalid.";
            }
            static /*string */ get CharSetNotSupported()
            {
                return "The character set provided in ContentType is not supported.";
            }
            static /*string */ get SerializeWrongType()
            {
                return "The specified type {0} must derive from the specific value's type {1}.";
            }
            static /*string */ FormatSerializeWrongType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("The specified type {0} must derive from the specific value's type {1}.", arg1, arg2);
            }
            static /*string */ get net_http_request_timedout()
            {
                return "The request was canceled due to the configured HttpClient.Timeout of {0} seconds elapsing.";
            }
            static /*string */ Formatnet_http_request_timedout(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The request was canceled due to the configured HttpClient.Timeout of {0} seconds elapsing.", arg1);
            }
            static /*string */ get net_http_content_buffersize_exceeded()
            {
                return "Cannot write more bytes to the buffer than the configured maximum buffer size: {0}.";
            }
            static /*string */ Formatnet_http_content_buffersize_exceeded(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Cannot write more bytes to the buffer than the configured maximum buffer size: {0}.", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$snhj.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$snhj.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$snhj.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$snhj.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$snhj.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$snhj.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 426958;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":426958}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$snhj.System.Net.Http.Json.HttpContentJsonExtensions", ($self) => class HttpContentJsonExtensions
        {
            static /*IAsyncEnumerable<TValue?> */ ReadFromJsonAsAsyncEnumerable(TValue, /*this HttpContent*/ content, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsAsyncEnumerable$1(TValue, content, null, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ ReadFromJsonAsAsyncEnumerable$1(TValue, /*this HttpContent*/ content, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsAsyncEnumerableCore(TValue, content, options, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ ReadFromJsonAsAsyncEnumerable$2(TValue, /*this HttpContent*/ content, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsAsyncEnumerableCore$1(TValue, content, jsonTypeInfo, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ ReadFromJsonAsAsyncEnumerableCore(TValue, /*HttpContent*/ content, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                /*var*/ let jsonTypeInfo = $.$cast($.$snhj.System.Net.Http.Json.JsonHelpers.GetJsonTypeInfo(TValue.$type, options), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue));
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsAsyncEnumerableCore$1(TValue, content, jsonTypeInfo, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> *//*async*/  ReadFromJsonAsAsyncEnumerableCore$1(TValue, /*HttpContent*/ content, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return new ($.$$.NetJs.YieldToIterator$$(TValue))().$ctor$1(async function*()
                {
                    /*Stream*/ let contentStream = await $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(content, cancellationToken).ConfigureAwait(false);
                    try
                    {
                        var $en4 = $.$$.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait$1(TValue, $.$stj.System.Text.Json.JsonSerializer.DeserializeAsyncEnumerable$3(TValue, contentStream, jsonTypeInfo, cancellationToken), false).GetAsyncEnumerator();
                        while (await $en4.MoveNextAsync())
                        {
                            var value = $en4.Current;
                            {
                                yield value;
                            }
                        }
                    }
                    finally
                    {
                        contentStream?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            static /*Task<Stream> */ ReadHttpContentStreamAsync(/*HttpContent*/ content, /*CancellationToken*/ cancellationToken)
            {
                return content.ReadAsStreamAsync$1(cancellationToken);
            }
            static /*Stream */ GetTranscodingStream(/*Stream*/ contentStream, /*Encoding*/ sourceEncoding)
            {
                return $.$$.System.Text.Encoding.CreateTranscodingStream(contentStream, sourceEncoding, $.$$.System.Text.Encoding.UTF8, false);
            }
            /*string*/ static SerializationUnreferencedCodeMessage = null;
            /*string*/ static SerializationDynamicCodeMessage = null;
            static /*Task<object?> */ ReadFromJsonAsync$1(/*this HttpContent*/ content, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsyncCore(content, type, options, cancellationToken);
            }
            static /*Task<object?> */ ReadFromJsonAsync(/*this HttpContent*/ content, /*Type*/ type, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsync$1(content, type, null, cancellationToken);
            }
            static /*Task<T?> */ ReadFromJsonAsync$4(T, /*this HttpContent*/ content, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsyncCore$2(T, content, options, cancellationToken);
            }
            static /*Task<T?> */ ReadFromJsonAsync$3(T, /*this HttpContent*/ content, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsync$4(T, content, null, cancellationToken);
            }
            static /*Task<object?> *//*async*/  ReadFromJsonAsyncCore(/*HttpContent*/ content, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Object), $.$$.System.Object, async () => 
                {
                    let contentStream = null;
                    try
                    {
                        contentStream = await $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(content, cancellationToken).ConfigureAwait(false);
                        return await $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync(contentStream, type, options ?? $.$stj.System.Text.Json.JsonSerializerOptions.Web, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        contentStream?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*Task<T?> *//*async*/  ReadFromJsonAsyncCore$2(T, /*HttpContent*/ content, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$(T), T, async () => 
                {
                    let contentStream = null;
                    try
                    {
                        contentStream = await $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(content, cancellationToken).ConfigureAwait(false);
                        return await $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$6(T, contentStream, options ?? $.$stj.System.Text.Json.JsonSerializerOptions.Web, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        contentStream?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*Task<object?> */ ReadFromJsonAsync$2(/*this HttpContent*/ content, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsyncCore$1(content, type, context, cancellationToken);
            }
            static /*Task<T?> */ ReadFromJsonAsync$5(T, /*this HttpContent*/ content, /*JsonTypeInfo<T>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsyncCore$3(T, content, jsonTypeInfo, cancellationToken);
            }
            static /*Task<object?> *//*async*/  ReadFromJsonAsyncCore$1(/*HttpContent*/ content, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Object), $.$$.System.Object, async () => 
                {
                    let contentStream = null;
                    try
                    {
                        contentStream = await $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(content, cancellationToken).ConfigureAwait(false);
                        return await $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$1(contentStream, type, context, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        contentStream?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*Task<T?> *//*async*/  ReadFromJsonAsyncCore$3(T, /*HttpContent*/ content, /*JsonTypeInfo<T>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$(T), T, async () => 
                {
                    let contentStream = null;
                    try
                    {
                        contentStream = await $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(content, cancellationToken).ConfigureAwait(false);
                        return await $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$7(T, contentStream, jsonTypeInfo, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        contentStream?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*ValueTask<Stream> */ GetContentStreamAsync(/*HttpContent*/ content, /*CancellationToken*/ cancellationToken)
            {
                /*Task<Stream>*/ let task = $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadHttpContentStreamAsync(content, cancellationToken);
                let sourceEncoding;
                return $.$is($.$snhj.System.Net.Http.Json.JsonHelpers.GetEncoding(content), $.$$.System.Text.Encoding, { set $v(v){ sourceEncoding = v; } }) && sourceEncoding !== $.$$.System.Text.Encoding.UTF8 ? $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetTranscodingStreamAsync(task, sourceEncoding) : new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream))().$ctor$5(task);
            }
            static /*ValueTask<Stream> *//*async*/  GetTranscodingStreamAsync(/*Task<Stream>*/ task, /*Encoding*/ sourceEncoding)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream), $.$$.System.IO.Stream, async () => 
                {
                    /*Stream*/ let contentStream = await task.ConfigureAwait$2(false);
                    return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetTranscodingStream(contentStream, sourceEncoding);
                });
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.SerializationUnreferencedCodeMessage = "JSON serialization and deserialization might require types that cannot be statically analyzed. Use the overload that takes a JsonTypeInfo or JsonSerializerContext, or make sure all of the required types are preserved.";
                }
                {
                    this.SerializationDynamicCodeMessage = "JSON serialization and deserialization might require types that cannot be statically analyzed. Use the overload that takes a JsonTypeInfo or JsonSerializerContext.";
                }
            }
            static $h = 164814;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":(TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"content","p":6619181},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"ReadFromJsonAsAsyncEnumerable","d":164814,"h":4295132110,"f":16908321},{"r":(TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"content","p":6619181},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"ReadFromJsonAsAsyncEnumerable","o":"@$1","d":164814,"h":8590099406,"f":16908321},{"r":(TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"content","p":6619181},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125829121,"f":65}],"g":["TValue"],"n":"ReadFromJsonAsAsyncEnumerable","o":"@$2","d":164814,"h":12885066702,"f":16908321},{"r":(TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"content","p":6619181},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121}],"g":["TValue"],"n":"ReadFromJsonAsAsyncEnumerableCore","d":164814,"h":17180033998,"f":16908322},{"r":(TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"content","p":6619181},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125829121,"a":[{"t":90374145,"c":4385341441}]}],"g":["TValue"],"n":"ReadFromJsonAsAsyncEnumerableCore","o":"@$1","d":164814,"h":21475001294,"f":16912418},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.IO.Stream).$h,"p":[{"n":"content","p":6619181},{"n":"cancellationToken","p":125829121}],"n":"ReadHttpContentStreamAsync","d":164814,"h":25769968590,"f":16777250},{"r":62193665,"p":[{"n":"contentStream","p":62193665},{"n":"sourceEncoding","p":121700353}],"n":"GetTranscodingStream","d":164814,"h":30064935886,"f":16777250},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"content","p":6619181},{"n":"type","p":142475265},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadFromJsonAsync","o":"@$1","d":164814,"h":42949837774,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"content","p":6619181},{"n":"type","p":142475265},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadFromJsonAsync","d":164814,"h":47244805070,"f":16777249},{"r":(T) => $.$$.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"content","p":6619181},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121,"f":65}],"g":["T"],"n":"ReadFromJsonAsync","o":"@$4","d":164814,"h":51539772366,"f":16908321},{"r":(T) => $.$$.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"content","p":6619181},{"n":"cancellationToken","p":125829121,"f":65}],"g":["T"],"n":"ReadFromJsonAsync","o":"@$3","d":164814,"h":55834739662,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"content","p":6619181},{"n":"type","p":142475265},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121}],"n":"ReadFromJsonAsyncCore","d":164814,"h":60129706958,"f":16781346},{"r":(T) => $.$$.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"content","p":6619181},{"n":"options","p":3388355},{"n":"cancellationToken","p":125829121}],"g":["T"],"n":"ReadFromJsonAsyncCore","o":"@$2","d":164814,"h":64424674254,"f":16912418},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"content","p":6619181},{"n":"type","p":142475265},{"n":"context","p":14791619},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadFromJsonAsync","o":"@$2","d":164814,"h":68719641550,"f":16777249},{"r":(T) => $.$$.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"content","p":6619181},{"n":"jsonTypeInfo","p":(T) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(T).$h},{"n":"cancellationToken","p":125829121,"f":65}],"g":["T"],"n":"ReadFromJsonAsync","o":"@$5","d":164814,"h":73014608846,"f":16908321},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,"p":[{"n":"content","p":6619181},{"n":"type","p":142475265},{"n":"context","p":14791619},{"n":"cancellationToken","p":125829121}],"n":"ReadFromJsonAsyncCore","o":"@$1","d":164814,"h":77309576142,"f":16781346},{"r":(T) => $.$$.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"content","p":6619181},{"n":"jsonTypeInfo","p":(T) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(T).$h},{"n":"cancellationToken","p":125829121}],"g":["T"],"n":"ReadFromJsonAsyncCore","o":"@$3","d":164814,"h":81604543438,"f":16912418},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream).$h,"p":[{"n":"content","p":6619181},{"n":"cancellationToken","p":125829121}],"n":"GetContentStreamAsync","d":164814,"h":85899510734,"f":16777256},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream).$h,"p":[{"n":"task","p":$.$$.System.Threading.Tasks.Task$$($.$$.System.IO.Stream).$h},{"n":"sourceEncoding","p":121700353}],"n":"GetTranscodingStreamAsync","d":164814,"h":90194478030,"f":16781346}],"l":[{"t":1310721,"n":"SerializationUnreferencedCodeMessage","d":164814,"h":34359903182,"f":4194344},{"t":1310721,"n":"SerializationDynamicCodeMessage","d":164814,"h":38654870478,"f":4194344}],"h":164814}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Http.Json.HttpContentJsonExtensions`; }
        });
        
        $asm.$cls("$snhj.System.Net.Http.Json.JsonContent", ($self) => class JsonContent extends $.$snh.System.Net.Http.HttpContent
        {
            /*void */ SerializeToStream(/*Stream*/ stream, /*TransportContext?*/ context, /*CancellationToken*/ cancellationToken)
            {
                let targetEncoding;
                if ($.$is($.$snhj.System.Net.Http.Json.JsonHelpers.GetEncoding(this), $.$$.System.Text.Encoding, { set $v(v){ targetEncoding = v; } }) && targetEncoding !== $.$$.System.Text.Encoding.UTF8)
                {
                    this.SerializeToStreamAsyncTranscoding(stream, false, targetEncoding, cancellationToken).GetAwaiter().GetResult();
                }
                else 
                {
                    $.$stj.System.Text.Json.JsonSerializer.Serialize$2(stream, this.Value, this._typeInfo);
                }
            }
            /*Task */ SerializeToStreamAsync(/*Stream*/ stream, /*TransportContext?*/ context, /*CancellationToken*/ cancellationToken)
            {
                return this.SerializeToStreamAsyncCore(stream, cancellationToken);
            }
            /*JsonTypeInfo*/ _typeInfo = null;
            /*Type */ get ObjectType()
            {
                return this._typeInfo.Type;
            }
            /*object?*/ Value = null;
            $ctor$2(/*object?*/ inputValue, /*JsonTypeInfo*/ jsonTypeInfo, /*MediaTypeHeaderValue?*/ mediaType)
            {
                super.$ctor$1();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(jsonTypeInfo === null), "jsonTypeInfo is not null");
                    $.$$.System.Diagnostics.Debug.Assert$2(inputValue === null || jsonTypeInfo.Type.IsAssignableFrom($.$$.System.Object.GetType.call(inputValue)), "inputValue is null || jsonTypeInfo.Type.IsAssignableFrom(inputValue.GetType())");
                    this.Value = inputValue;
                    this._typeInfo = jsonTypeInfo;
                    if (!(mediaType === null))
                    {
                        this.Headers.ContentType = mediaType;
                    }
                    else 
                    {
                        this.Headers.TryAddWithoutValidation$1("Content-Type", "application/json; charset=utf-8"/*JsonHelpers.DefaultMediaType*/);
                    }
                }
                return this;
            }
            static /*JsonContent */ Create$2(T, /*T*/ inputValue, /*MediaTypeHeaderValue?*/ mediaType, /*JsonSerializerOptions?*/ options)
            {
                return $.$snhj.System.Net.Http.Json.JsonContent.Create$1($.$box(inputValue, T), $.$snhj.System.Net.Http.Json.JsonHelpers.GetJsonTypeInfo(T.$type, options), mediaType);
            }
            static /*JsonContent */ Create(/*object?*/ inputValue, /*Type*/ inputType, /*MediaTypeHeaderValue?*/ mediaType, /*JsonSerializerOptions?*/ options)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inputType, "inputType");
                $.$snhj.System.Net.Http.Json.JsonContent.EnsureTypeCompatibility(inputValue, inputType);
                return new $.$snhj.System.Net.Http.Json.JsonContent().$ctor$2(inputValue, $.$snhj.System.Net.Http.Json.JsonHelpers.GetJsonTypeInfo(inputType, options), mediaType);
            }
            static /*JsonContent */ Create$3(T, /*T?*/ inputValue, /*JsonTypeInfo<T>*/ jsonTypeInfo, /*MediaTypeHeaderValue?*/ mediaType)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsonTypeInfo, "jsonTypeInfo");
                return new $.$snhj.System.Net.Http.Json.JsonContent().$ctor$2($.$box(inputValue, T), jsonTypeInfo, mediaType);
            }
            static /*JsonContent */ Create$1(/*object?*/ inputValue, /*JsonTypeInfo*/ jsonTypeInfo, /*MediaTypeHeaderValue?*/ mediaType)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsonTypeInfo, "jsonTypeInfo");
                $.$snhj.System.Net.Http.Json.JsonContent.EnsureTypeCompatibility(inputValue, jsonTypeInfo.Type);
                return new $.$snhj.System.Net.Http.Json.JsonContent().$ctor$2(inputValue, jsonTypeInfo, mediaType);
            }
            /*Task */ SerializeToStreamAsync$1(/*Stream*/ stream, /*TransportContext?*/ context)
            {
                return this.SerializeToStreamAsyncCore(stream, $.$$.System.Threading.CancellationToken.None);
            }
            /*bool */ TryComputeLength(/*out long*/ length)
            {
                length.$v = 0n;
                return false;
            }
            /*Task */ SerializeToStreamAsyncCore(/*Stream*/ targetStream, /*CancellationToken*/ cancellationToken)
            {
                /*Encoding?*/ let targetEncoding = $.$snhj.System.Net.Http.Json.JsonHelpers.GetEncoding(this);
                return targetEncoding !== null && targetEncoding !== $.$$.System.Text.Encoding.UTF8 ? this.SerializeToStreamAsyncTranscoding(targetStream, true, targetEncoding, cancellationToken) : $.$stj.System.Text.Json.JsonSerializer.SerializeAsync$2(targetStream, this.Value, this._typeInfo, cancellationToken);
            }
            /*Task *//*async*/  SerializeToStreamAsyncTranscoding(/*Stream*/ targetStream, /*bool*/ $async, /*Encoding*/ targetEncoding, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    /*Stream*/ let transcodingStream = $.$$.System.Text.Encoding.CreateTranscodingStream(targetStream, targetEncoding, $.$$.System.Text.Encoding.UTF8, true);
                    try
                    {
                        if ($async)
                        {
                            await $.$stj.System.Text.Json.JsonSerializer.SerializeAsync$2(transcodingStream, this.Value, this._typeInfo, cancellationToken).ConfigureAwait(false);
                        }
                        else 
                        {
                            $.$stj.System.Text.Json.JsonSerializer.Serialize$2(transcodingStream, this.Value, this._typeInfo);
                        }
                    }
                    finally
                    {
                        {
                            if ($async)
                            {
                                await transcodingStream.DisposeAsync().ConfigureAwait(false);
                            }
                            else 
                            {
                                transcodingStream.Dispose();
                            }
                        }
                    }
                });
            }
            static /*void */ EnsureTypeCompatibility(/*object?*/ inputValue, /*Type*/ inputType)
            {
                if (!(inputValue === null) && !inputType.IsAssignableFrom($.$$.System.Object.GetType.call(inputValue)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$snhj.System.SR.Format$5($.$snhj.System.SR.SerializeWrongType, inputType, $.$$.System.Object.GetType.call(inputValue)));
                }
            }
            static $h = 230350;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6619181,"p":[{"p":142475265,"g":{"r":0,"d":0,"h":21475066830,"f":50331649},"n":"ObjectType","d":230350,"h":17180099534,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":34359968718,"f":50331649},"n":"Value","d":230350,"h":30065001422,"f":2097153}],"m":[{"r":65537,"p":[{"n":"stream","p":62193665},{"n":"context","p":5030645},{"n":"cancellationToken","p":125829121}],"n":"SerializeToStream","d":230350,"h":4295197646,"f":16809988},{"r":133169153,"p":[{"n":"stream","p":62193665},{"n":"context","p":5030645},{"n":"cancellationToken","p":125829121}],"n":"SerializeToStreamAsync","d":230350,"h":8590164942,"f":16809988},{"r":230350,"p":[{"n":"inputValue","p":(T) => T.$h},{"n":"mediaType","p":4784173,"f":65},{"n":"options","p":3388355,"f":65}],"g":["T"],"n":"Create","o":"@$2","d":230350,"h":42949903310,"f":16908321},{"r":230350,"p":[{"n":"inputValue","p":131073},{"n":"inputType","p":142475265},{"n":"mediaType","p":4784173,"f":65},{"n":"options","p":3388355,"f":65}],"n":"Create","d":230350,"h":47244870606,"f":16777249},{"r":230350,"p":[{"n":"inputValue","p":(T) => T.$h},{"n":"jsonTypeInfo","p":(T) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(T).$h},{"n":"mediaType","p":4784173,"f":65}],"g":["T"],"n":"Create","o":"@$3","d":230350,"h":51539837902,"f":16908321},{"r":230350,"p":[{"n":"inputValue","p":131073},{"n":"jsonTypeInfo","p":16823235},{"n":"mediaType","p":4784173,"f":65}],"n":"Create","o":"@$1","d":230350,"h":55834805198,"f":16777249},{"r":133169153,"p":[{"n":"stream","p":62193665},{"n":"context","p":5030645}],"n":"SerializeToStreamAsync","o":"@$1","d":230350,"h":60129772494,"f":16809988},{"r":262145,"p":[{"n":"length","p":917505,"f":2}],"n":"TryComputeLength","d":230350,"h":64424739790,"f":16809988},{"r":133169153,"p":[{"n":"targetStream","p":62193665},{"n":"cancellationToken","p":125829121}],"n":"SerializeToStreamAsyncCore","d":230350,"h":68719707086,"f":16777218},{"r":133169153,"p":[{"n":"targetStream","p":62193665},{"n":"async","p":262145},{"n":"targetEncoding","p":121700353},{"n":"cancellationToken","p":125829121}],"n":"SerializeToStreamAsyncTranscoding","d":230350,"h":73014674382,"f":16781314},{"r":65537,"p":[{"n":"inputValue","p":131073},{"n":"inputType","p":142475265}],"n":"EnsureTypeCompatibility","d":230350,"h":77309641678,"f":16777250}],"l":[{"t":16823235,"n":"_typeInfo","d":230350,"h":12885132238,"f":4194306}],"c":[{"p":[{"n":"inputValue","p":131073},{"n":"jsonTypeInfo","p":16823235},{"n":"mediaType","p":4784173}],"n":".ctor","o":"$ctor$2","d":230350,"h":38654936014,"f":16777218}],"i":[57540609],"h":230350}; }
            static get $b() { return $.$snh.System.Net.Http.HttpContent; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Http.Json.JsonContent`; }
        });
        
        $asm.$cls("$snhj.System.Net.Http.Json.LengthLimitReadStream", ($self) => class LengthLimitReadStream extends $.$$.System.IO.Stream
        {
            /*Stream*/ _innerStream = null;
            /*int*/ _lengthLimit = 0;
            /*int*/ _remainingLength = 0;
            $ctor$3(/*Stream*/ innerStream, /*int*/ lengthLimit)
            {
                super.$ctor$2();
                {
                    this._innerStream = innerStream;
                    this._lengthLimit = this._remainingLength = lengthLimit;
                }
                return this;
            }
            /*void */ CheckLengthLimit(/*int*/ read)
            {
                this._remainingLength -= read;
                if (this._remainingLength < 0)
                {
                    $.$snhj.System.Net.Http.Json.LengthLimitReadStream.ThrowExceededBufferLimit(this._lengthLimit);
                }
            }
            static /*void */ ThrowExceededBufferLimit(/*int*/ limit)
            {
                throw new $.$snh.System.Net.Http.HttpRequestException().$ctor$8($.$snhj.System.SR.Format$6($.$snhj.System.SR.net_http_content_buffersize_exceeded, $.$box(limit, $.$$.System.Int32)));
            }
            /*bool */ get CanRead()
            {
                return this._innerStream.CanRead;
            }
            /*bool */ get CanSeek()
            {
                return this._innerStream.CanSeek;
            }
            /*bool */ get CanWrite()
            {
                return false;
            }
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                return this.ReadAsync$2(new ($.$$.System.Memory$$($.$$.System.Byte))().$ctor$5(buffer, offset, count), cancellationToken).AsTask();
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                /*ValueTask<int>*/ let readTask = this._innerStream.ReadAsync$2(buffer, cancellationToken);
                if (buffer.IsEmpty)
                {
                    return readTask;
                }
                if (readTask.IsCompletedSuccessfully)
                {
                    /*int*/ let read = readTask.Result;
                    this.CheckLengthLimit(read);
                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32))().$ctor$6(read);
                }
                return Core.call(this, readTask);
                /*ValueTask<int>*/ /*async*/  function Core(/*ValueTask<int>*/ readTask)
                {
                    return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                    {
                        /*int*/ let read = await readTask.ConfigureAwait(false);
                        this.CheckLengthLimit(read);
                        return read;
                    });
                }
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                /*int*/ let read = this._innerStream.Read(buffer, offset, count);
                this.CheckLengthLimit(read);
                return read;
            }
            /*void */ Flush()
            {
                return this._innerStream.Flush();
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                return this._innerStream.FlushAsync$1(cancellationToken);
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                return this._innerStream.Seek(offset, origin);
            }
            /*void */ SetLength(/*long*/ value)
            {
                return this._innerStream.SetLength(value);
            }
            /*long */ get Length()
            {
                return this._innerStream.Length;
            }
            /*long */ get Position()
            {
                return this._innerStream.Position;
            }
            /*long */ set Position(value)
            {
                this._innerStream.Position = value;
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$$.System.NotSupportedException().$ctor$9();
            }
            static $h = 361422;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360099790,"f":50364417},"n":"CanRead","d":361422,"h":30065132494,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":42950034382,"f":50364417},"n":"CanSeek","d":361422,"h":38655067086,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":51539968974,"f":50364417},"n":"CanWrite","d":361422,"h":47245001678,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":90194674638,"f":50364417},"n":"Length","d":361422,"h":85899707342,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":98784609230,"f":50364417},"s":{"r":0,"d":0,"h":103079576526,"f":83918849},"n":"Position","d":361422,"h":94489641934,"f":2129921}],"m":[{"r":65537,"p":[{"n":"read","p":655361}],"n":"CheckLengthLimit","d":361422,"h":21475197902,"f":16777218},{"r":65537,"p":[{"n":"limit","p":655361}],"n":"ThrowExceededBufferLimit","d":361422,"h":25770165198,"f":16777256},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ReadAsync","d":361422,"h":55834936270,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAsync","o":"@$2","d":361422,"h":60129903566,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":361422,"h":64424870862,"f":16809985},{"r":65537,"n":"Flush","d":361422,"h":68719838158,"f":16809985},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121}],"n":"FlushAsync","o":"@$1","d":361422,"h":73014805454,"f":16809985},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":361422,"h":77309772750,"f":16809985},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":361422,"h":81604740046,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":361422,"h":107374543822,"f":16809985}],"l":[{"t":62193665,"n":"_innerStream","d":361422,"h":4295328718,"f":4194306},{"t":655361,"n":"_lengthLimit","d":361422,"h":8590296014,"f":4194306},{"t":655361,"n":"_remainingLength","d":361422,"h":12885263310,"f":4194306}],"c":[{"p":[{"n":"innerStream","p":62193665},{"n":"lengthLimit","p":655361}],"n":".ctor","o":"$ctor$3","d":361422,"h":17180230606,"f":16777217}],"i":[57540609,56950785],"h":361422}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Http.Json.LengthLimitReadStream`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.IO.Pipelines", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.RegularExpressions", "NetJs.System.Text.Json"))