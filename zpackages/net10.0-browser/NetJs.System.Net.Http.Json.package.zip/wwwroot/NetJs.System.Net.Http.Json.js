
//--TRIMMABLE-BOUNDARY-START(54)
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $sicb, $sipl, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $sre, $srei, $srel, $srp, $srl, $stew, $str, $stj) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Http.Json", 
    {
  "h": 54,
  "f": "System.Net.Http.Json",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159121409,
      "c": 13044023297,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106299393,
      "c": 4401266689,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106364929,
      "c": 4401332225,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106823681,
      "c": 4401790977,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 4401922049,
      "a": [
        {
          "v": "1.0.35\u002B39e7ca3e4bf1d7d75afdb3a3db320b6c1a1b2fcf",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 4402774017,
      "a": [
        {
          "v": "NetJs.System.Net.Http.Json",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 4402905089,
      "a": [
        {
          "v": "NetJs.System.Net.Http.Json",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 4403036161,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159186945,
      "c": 4454154241,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 158924801,
      "c": 4453892097,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65590)
        $asm.$cls("$snhj.System.Net.Http.Json.HttpClientJsonExtensions", ($self) => class HttpClientJsonExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(206158495798)
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync$1(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158495798);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, null, null);
                return client.PostAsync(requestUri, content, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(206158495798)
            
            //--TRIMMABLE-BOUNDARY-START(210453463094)
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync$4(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453463094);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, null, null);
                return client.PostAsync$2(requestUri, content, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(210453463094)
            
            //--TRIMMABLE-BOUNDARY-START(214748430390)
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(214748430390);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PostAsJsonAsync$1(TValue, client, requestUri, value, null, new $.$$.System.Threading.CancellationToken());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(214748430390)
            
            //--TRIMMABLE-BOUNDARY-START(219043397686)
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync$3(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(219043397686);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PostAsJsonAsync$4(TValue, client, requestUri, value, null, new $.$$.System.Threading.CancellationToken());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(219043397686)
            
            //--TRIMMABLE-BOUNDARY-START(223338364982)
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync$2(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338364982);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$3(TValue, value, jsonTypeInfo, null);
                return client.PostAsync(requestUri, content, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(223338364982)
            
            //--TRIMMABLE-BOUNDARY-START(227633332278)
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync$5(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633332278);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$3(TValue, value, jsonTypeInfo, null);
                return client.PostAsync$2(requestUri, content, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(227633332278)
            
            //--TRIMMABLE-BOUNDARY-START(231928299574)
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync$1(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928299574);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, null, null);
                return client.PutAsync(requestUri, content, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(231928299574)
            
            //--TRIMMABLE-BOUNDARY-START(236223266870)
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync$4(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223266870);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, null, null);
                return client.PutAsync$2(requestUri, content, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(236223266870)
            
            //--TRIMMABLE-BOUNDARY-START(240518234166)
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(240518234166);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PutAsJsonAsync$1(TValue, client, requestUri, value, null, new $.$$.System.Threading.CancellationToken());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(240518234166)
            
            //--TRIMMABLE-BOUNDARY-START(244813201462)
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync$3(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(244813201462);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PutAsJsonAsync$4(TValue, client, requestUri, value, null, new $.$$.System.Threading.CancellationToken());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(244813201462)
            
            //--TRIMMABLE-BOUNDARY-START(249108168758)
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync$2(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108168758);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$3(TValue, value, jsonTypeInfo, null);
                return client.PutAsync(requestUri, content, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(249108168758)
            
            //--TRIMMABLE-BOUNDARY-START(253403136054)
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync$5(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403136054);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$3(TValue, value, jsonTypeInfo, null);
                return client.PutAsync$2(requestUri, content, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(253403136054)
            
            //--TRIMMABLE-BOUNDARY-START(94489346102)
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable$1(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(94489346102);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsAsyncEnumerable$4(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), options, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(94489346102)
            
            //--TRIMMABLE-BOUNDARY-START(98784313398)
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable$4(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(98784313398);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonStreamAsyncCore(TValue, client, requestUri, options, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(98784313398)
            
            //--TRIMMABLE-BOUNDARY-START(103079280694)
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable$2(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079280694);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsAsyncEnumerable$5(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), jsonTypeInfo, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(103079280694)
            
            //--TRIMMABLE-BOUNDARY-START(107374247990)
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable$5(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(107374247990);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonStreamAsyncCore$1(TValue, client, requestUri, jsonTypeInfo, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(107374247990)
            
            //--TRIMMABLE-BOUNDARY-START(111669215286)
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111669215286);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsAsyncEnumerable$1(TValue, client, requestUri, null, new $.$$.System.Threading.CancellationToken());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(111669215286)
            
            //--TRIMMABLE-BOUNDARY-START(115964182582)
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable$3(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(115964182582);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsAsyncEnumerable$4(TValue, client, requestUri, null, new $.$$.System.Threading.CancellationToken());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(115964182582)
            
            //--TRIMMABLE-BOUNDARY-START(85899411510)
            static /*IAsyncEnumerable<TValue?> */ FromJsonStreamAsyncCore(TValue, /*HttpClient*/ client, /*Uri?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899411510);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let jsonTypeInfo = $.$cast($.$snhj.System.Net.Http.Json.JsonHelpers.GetJsonTypeInfo(TValue.$type, options), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue));
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonStreamAsyncCore$1(TValue, client, requestUri, jsonTypeInfo, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(85899411510)
            
            //--TRIMMABLE-BOUNDARY-START(90194378806)
            static /*IAsyncEnumerable<TValue?> */ FromJsonStreamAsyncCore$1(TValue, /*HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194378806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                return Core(client, requestUri, jsonTypeInfo, cancellationToken);
                /*static IAsyncEnumerable<TValue?>*/ /*async*/  function Core(/*HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
                {
                    return new ($.$$.NetJs.YieldToIterator$$(TValue))().$ctor$1(async function*()
                    {
                        /*HttpResponseMessage*/ let response = await client.GetAsync$5(requestUri, 1/*HttpCompletionOption.ResponseHeadersRead*/, cancellationToken).ConfigureAwait$2(false);
                        try
                        {
                            response.EnsureSuccessStatusCode();
                            /*Stream*/ let readStream = await $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetHttpResponseStreamAsync(client, response, false, cancellationToken).ConfigureAwait(false);
                            try
                            {
                                var $en6 = $.$$.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait$1(TValue, $.$stj.System.Text.Json.JsonSerializer.DeserializeAsyncEnumerable$3(TValue, readStream, jsonTypeInfo, cancellationToken), false).GetAsyncEnumerator();
                                while (await $en6.MoveNextAsync())
                                {
                                    var value = $en6.Current;
                                    {
                                        yield value;
                                    }
                                }
                            }
                            finally
                            {
                                readStream?.System$IDisposable$Dispose();
                            }
                        }
                        finally
                        {
                            response?.System$IDisposable$Dispose();
                        }
                    }.bind(this));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(90194378806)
            
            //--TRIMMABLE-BOUNDARY-START(180388692022)
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync$1(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180388692022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, null, null);
                return client.PatchAsync(requestUri, content, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(180388692022)
            
            //--TRIMMABLE-BOUNDARY-START(184683659318)
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync$4(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683659318);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, null, null);
                return client.PatchAsync$2(requestUri, content, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(184683659318)
            
            //--TRIMMABLE-BOUNDARY-START(188978626614)
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(188978626614);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PatchAsJsonAsync$1(TValue, client, requestUri, value, null, new $.$$.System.Threading.CancellationToken());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(188978626614)
            
            //--TRIMMABLE-BOUNDARY-START(193273593910)
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync$3(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193273593910);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PatchAsJsonAsync$4(TValue, client, requestUri, value, null, new $.$$.System.Threading.CancellationToken());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193273593910)
            
            //--TRIMMABLE-BOUNDARY-START(197568561206)
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync$2(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568561206);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$3(TValue, value, jsonTypeInfo, null);
                return client.PatchAsync(requestUri, content, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(197568561206)
            
            //--TRIMMABLE-BOUNDARY-START(201863528502)
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync$5(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201863528502);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$3(TValue, value, jsonTypeInfo, null);
                return client.PatchAsync$2(requestUri, content, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(201863528502)
            
            //--TRIMMABLE-BOUNDARY-START(257698103350)
            /*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ static s_deleteAsync = null;
            //--TRIMMABLE-BOUNDARY-END(257698103350)
            
            //--TRIMMABLE-BOUNDARY-START(12884967478)
            static /*Task<object?> */ DeleteFromJsonAsync$1(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12884967478);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$4(client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), type, options, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(12884967478)
            
            //--TRIMMABLE-BOUNDARY-START(17179934774)
            static /*Task<object?> */ DeleteFromJsonAsync$4(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17179934774);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_deleteAsync, client, requestUri, type, options, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17179934774)
            
            //--TRIMMABLE-BOUNDARY-START(21474902070)
            static /*Task<TValue?> */ DeleteFromJsonAsync$7(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21474902070);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$10(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), options, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(21474902070)
            
            //--TRIMMABLE-BOUNDARY-START(25769869366)
            static /*Task<TValue?> */ DeleteFromJsonAsync$10(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25769869366);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$3(TValue, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_deleteAsync, client, requestUri, options, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(25769869366)
            
            //--TRIMMABLE-BOUNDARY-START(30064836662)
            static /*Task<object?> */ DeleteFromJsonAsync$2(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(30064836662);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$5(client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), type, context, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(30064836662)
            
            //--TRIMMABLE-BOUNDARY-START(34359803958)
            static /*Task<object?> */ DeleteFromJsonAsync$5(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(34359803958);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$1($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_deleteAsync, client, requestUri, type, context, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359803958)
            
            //--TRIMMABLE-BOUNDARY-START(38654771254)
            static /*Task<TValue?> */ DeleteFromJsonAsync$8(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38654771254);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$11(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), jsonTypeInfo, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(38654771254)
            
            //--TRIMMABLE-BOUNDARY-START(42949738550)
            static /*Task<TValue?> */ DeleteFromJsonAsync$11(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42949738550);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$4(TValue, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_deleteAsync, client, requestUri, jsonTypeInfo, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(42949738550)
            
            //--TRIMMABLE-BOUNDARY-START(47244705846)
            static /*Task<object?> */ DeleteFromJsonAsync(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(47244705846);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$1(client, requestUri, type, null, new $.$$.System.Threading.CancellationToken());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(47244705846)
            
            //--TRIMMABLE-BOUNDARY-START(51539673142)
            static /*Task<object?> */ DeleteFromJsonAsync$3(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(51539673142);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$4(client, requestUri, type, null, new $.$$.System.Threading.CancellationToken());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(51539673142)
            
            //--TRIMMABLE-BOUNDARY-START(55834640438)
            static /*Task<TValue?> */ DeleteFromJsonAsync$6(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(55834640438);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$7(TValue, client, requestUri, null, new $.$$.System.Threading.CancellationToken());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(55834640438)
            
            //--TRIMMABLE-BOUNDARY-START(60129607734)
            static /*Task<TValue?> */ DeleteFromJsonAsync$9(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(60129607734);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$10(TValue, client, requestUri, null, new $.$$.System.Threading.CancellationToken());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(60129607734)
            
            //--TRIMMABLE-BOUNDARY-START(261993070646)
            /*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ static s_getAsync = null;
            //--TRIMMABLE-BOUNDARY-END(261993070646)
            
            //--TRIMMABLE-BOUNDARY-START(120259149878)
            static /*Task<object?> */ GetFromJsonAsync$1(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(120259149878);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$4(client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), type, options, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(120259149878)
            
            //--TRIMMABLE-BOUNDARY-START(124554117174)
            static /*Task<object?> */ GetFromJsonAsync$4(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554117174);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore(new ($.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)))().$ctor($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions, /*static*/ (/*client*/ client, /*uri*/ uri, /*cancellation*/ cancellation) =>
                    {
                        return client.GetAsync$5(uri, 1/*HttpCompletionOption.ResponseHeadersRead*/, cancellation);
                    }, {
  "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
  "p": [
    {
      "n": "client",
      "p": 6488117
    },
    {
      "n": "uri",
      "p": 1703938
    },
    {
      "n": "cancellation",
      "p": 169934849
    }
  ],
  "n": "",
  "d": 65590,
  "h": 0,
  "f": 17825826
}), client, requestUri, type, options, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(124554117174)
            
            //--TRIMMABLE-BOUNDARY-START(128849084470)
            static /*Task<TValue?> */ GetFromJsonAsync$7(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(128849084470);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$10(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), options, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(128849084470)
            
            //--TRIMMABLE-BOUNDARY-START(133144051766)
            static /*Task<TValue?> */ GetFromJsonAsync$10(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133144051766);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$3(TValue, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_getAsync, client, requestUri, options, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(133144051766)
            
            //--TRIMMABLE-BOUNDARY-START(137439019062)
            static /*Task<object?> */ GetFromJsonAsync$2(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(137439019062);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$5(client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), type, context, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(137439019062)
            
            //--TRIMMABLE-BOUNDARY-START(141733986358)
            static /*Task<object?> */ GetFromJsonAsync$5(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(141733986358);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$1($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_getAsync, client, requestUri, type, context, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(141733986358)
            
            //--TRIMMABLE-BOUNDARY-START(146028953654)
            static /*Task<TValue?> */ GetFromJsonAsync$8(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(146028953654);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$11(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), jsonTypeInfo, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(146028953654)
            
            //--TRIMMABLE-BOUNDARY-START(150323920950)
            static /*Task<TValue?> */ GetFromJsonAsync$11(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150323920950);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$4(TValue, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_getAsync, client, requestUri, jsonTypeInfo, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150323920950)
            
            //--TRIMMABLE-BOUNDARY-START(154618888246)
            static /*Task<object?> */ GetFromJsonAsync(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(154618888246);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$1(client, requestUri, type, null, new $.$$.System.Threading.CancellationToken());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(154618888246)
            
            //--TRIMMABLE-BOUNDARY-START(158913855542)
            static /*Task<object?> */ GetFromJsonAsync$3(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(158913855542);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$4(client, requestUri, type, null, new $.$$.System.Threading.CancellationToken());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(158913855542)
            
            //--TRIMMABLE-BOUNDARY-START(163208822838)
            static /*Task<TValue?> */ GetFromJsonAsync$6(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(163208822838);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$7(TValue, client, requestUri, null, new $.$$.System.Threading.CancellationToken());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(163208822838)
            
            //--TRIMMABLE-BOUNDARY-START(167503790134)
            static /*Task<TValue?> */ GetFromJsonAsync$9(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(167503790134);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$10(TValue, client, requestUri, null, new $.$$.System.Threading.CancellationToken());
                }
            }
            //--TRIMMABLE-BOUNDARY-END(167503790134)
            
            //--TRIMMABLE-BOUNDARY-START(64424575030)
            static /*Task<object?> */ FromJsonAsyncCore(/*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ getMethod, /*HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424575030);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$2($.$$.System.Object, $.$$.System.ValueTuple$$$($.$$.System.Type, $.$stj.System.Text.Json.JsonSerializerOptions), getMethod, client, requestUri, new ($.$$.System.Func$$$$$($.$$.System.IO.Stream, $.$$.System.ValueTuple$$$($.$$.System.Type, $.$stj.System.Text.Json.JsonSerializerOptions), $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Object)))().$ctor($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions, /*static*/ (/*stream*/ stream, /*options*/ options, /*cancellation*/ cancellation) =>
                    {
                        return $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync(stream, options.Item1, options.Item2 ?? $.$stj.System.Text.Json.JsonSerializerOptions.Web, cancellation);
                    }, {
  "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Object).$h,
  "p": [
    {
      "n": "stream",
      "p": 94830593
    },
    {
      "n": "options",
      "p": $.$$.System.ValueTuple$$$($.$$.System.Type, $.$stj.System.Text.Json.JsonSerializerOptions).$h
    },
    {
      "n": "cancellation",
      "p": 169934849
    }
  ],
  "n": "",
  "d": 65590,
  "h": 0,
  "f": 17825826
}), new ($.$$.System.ValueTuple$$$($.$$.System.Type, $.$stj.System.Text.Json.JsonSerializerOptions))().$ctor$3(type, options), cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(64424575030)
            
            //--TRIMMABLE-BOUNDARY-START(68719542326)
            static /*Task<TValue?> */ FromJsonAsyncCore$3(TValue, /*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ getMethod, /*HttpClient*/ client, /*Uri?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719542326);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$2(TValue, $.$stj.System.Text.Json.JsonSerializerOptions, getMethod, client, requestUri, new ($.$$.System.Func$$$$$($.$$.System.IO.Stream, $.$stj.System.Text.Json.JsonSerializerOptions, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.ValueTask$$(TValue)))().$ctor($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions, /*static*/ (/*stream*/ stream, /*options*/ options, /*cancellation*/ cancellation) =>
                    {
                        return $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$6(TValue, stream, options ?? $.$stj.System.Text.Json.JsonSerializerOptions.Web, cancellation);
                    }, {
  "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
  "p": [
    {
      "n": "stream",
      "p": 94830593
    },
    {
      "n": "options",
      "p": 3342420
    },
    {
      "n": "cancellation",
      "p": 169934849
    }
  ],
  "n": "",
  "d": 65590,
  "h": 0,
  "f": 17825826
}), options, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(68719542326)
            
            //--TRIMMABLE-BOUNDARY-START(73014509622)
            static /*Task<object?> */ FromJsonAsyncCore$1(/*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ getMethod, /*HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014509622);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$2($.$$.System.Object, $.$$.System.ValueTuple$$$($.$$.System.Type, $.$stj.System.Text.Json.Serialization.JsonSerializerContext), getMethod, client, requestUri, new ($.$$.System.Func$$$$$($.$$.System.IO.Stream, $.$$.System.ValueTuple$$$($.$$.System.Type, $.$stj.System.Text.Json.Serialization.JsonSerializerContext), $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Object)))().$ctor($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions, /*static*/ (/*stream*/ stream, /*options*/ options, /*cancellation*/ cancellation) =>
                    {
                        return $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$1(stream, options.Item1, options.Item2, cancellation);
                    }, {
  "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Object).$h,
  "p": [
    {
      "n": "stream",
      "p": 94830593
    },
    {
      "n": "options",
      "p": $.$$.System.ValueTuple$$$($.$$.System.Type, $.$stj.System.Text.Json.Serialization.JsonSerializerContext).$h
    },
    {
      "n": "cancellation",
      "p": 169934849
    }
  ],
  "n": "",
  "d": 65590,
  "h": 0,
  "f": 17825826
}), new ($.$$.System.ValueTuple$$$($.$$.System.Type, $.$stj.System.Text.Json.Serialization.JsonSerializerContext))().$ctor$3(type, context), cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(73014509622)
            
            //--TRIMMABLE-BOUNDARY-START(77309476918)
            static /*Task<TValue?> */ FromJsonAsyncCore$4(TValue, /*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ getMethod, /*HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309476918);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$2(TValue, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue), getMethod, client, requestUri, new ($.$$.System.Func$$$$$($.$$.System.IO.Stream, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue), $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.ValueTask$$(TValue)))().$ctor($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions, /*static*/ (/*stream*/ stream, /*options*/ options, /*cancellation*/ cancellation) =>
                    {
                        return $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$7(TValue, stream, options, cancellation);
                    }, {
  "r": (TValue) => $.$$.System.Threading.Tasks.ValueTask$$(TValue).$h,
  "p": [
    {
      "n": "stream",
      "p": 94830593
    },
    {
      "n": "options",
      "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
    },
    {
      "n": "cancellation",
      "p": 169934849
    }
  ],
  "n": "",
  "d": 65590,
  "h": 0,
  "f": 17825826
}), jsonTypeInfo, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(77309476918)
            
            //--TRIMMABLE-BOUNDARY-START(81604444214)
            static /*Task<TValue?> */ FromJsonAsyncCore$2(TValue, TJsonOptions, /*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ getMethod, /*HttpClient*/ client, /*Uri?*/ requestUri, /*Func<Stream, TJsonOptions, CancellationToken, ValueTask<TValue?>>*/ deserializeMethod, /*TJsonOptions*/ jsonOptions, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604444214);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(client, "client");
                /*TimeSpan*/ let timeout = client.Timeout;
                /*CancellationTokenSource?*/ let linkedCTS = null;
                if ($.$$.System.TimeSpan.op_Inequality(timeout, $.$$.System.Threading.Timeout.InfiniteTimeSpan))
                {
                    linkedCTS = $.$$.System.Threading.CancellationTokenSource.CreateLinkedTokenSource$2(cancellationToken);
                    linkedCTS.CancelAfter$1(timeout);
                }
                /*Task<HttpResponseMessage>*/ let responseTask;
                try
                {
                    responseTask = getMethod.Invoke(client, requestUri, cancellationToken);
                }
                catch($e)
                {
                    linkedCTS?.Dispose();
                    throw $e;
                }
                /*bool*/ let usingResponseHeadersRead = !$.$$.System.Object.ReferenceEquals(getMethod, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_deleteAsync);
                return Core(client, responseTask, usingResponseHeadersRead, linkedCTS, deserializeMethod, jsonOptions, cancellationToken);
                /*static Task<TValue?>*/ /*async*/  function Core(/*HttpClient*/ client, /*Task<HttpResponseMessage>*/ responseTask, /*bool*/ usingResponseHeadersRead, /*CancellationTokenSource?*/ linkedCTS, /*Func<Stream, TJsonOptions, CancellationToken, ValueTask<TValue?>>*/ deserializeMethod, /*TJsonOptions*/ jsonOptions, /*CancellationToken*/ cancellationToken)
                {
                    return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$(TValue), TValue, async () => 
                    {
                        try
                        {
                            /*HttpResponseMessage*/ let response = await responseTask.ConfigureAwait$2(false);
                            try
                            {
                                response.EnsureSuccessStatusCode();
                                try
                                {
                                    /*Stream*/ let readStream = await $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetHttpResponseStreamAsync(client, response, usingResponseHeadersRead, cancellationToken).ConfigureAwait(false);
                                    try
                                    {
                                        return await deserializeMethod.Invoke(readStream, jsonOptions, (linkedCTS?.Token ?? null) ?? cancellationToken).ConfigureAwait(false);
                                    }
                                    finally
                                    {
                                        readStream?.System$IDisposable$Dispose();
                                    }
                                }
                                catch(oce)
                                {
                                    /*string*/ let message = $.$snhj.System.SR.Format$6($.$snhj.System.SR.net_http_request_timedout, $.$box(client.Timeout.TotalSeconds, $.$$.System.Double));
                                    throw new $.$$.System.Threading.Tasks.TaskCanceledException().$ctor$18(message, new $.$$.System.TimeoutException().$ctor$11(oce.Message, oce), oce.CancellationToken);
                                }
                            }
                            finally
                            {
                                response?.System$IDisposable$Dispose();
                            }
                        }
                        finally
                        {
                            {
                                linkedCTS?.Dispose();
                            }
                        }
                    });
                }
            }
            //--TRIMMABLE-BOUNDARY-END(81604444214)
            
            //--TRIMMABLE-BOUNDARY-START(8590000182)
            static /*Uri? */ CreateUri(/*string?*/ uri)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590000182);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$$.System.String.IsNullOrEmpty(uri) ? null : new $.$spu.System.Uri().$ctor$3(uri, 0/*UriKind.RelativeOrAbsolute*/);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(8590000182)
            
            //--TRIMMABLE-BOUNDARY-START(171798757430)
            static /*ValueTask<Stream> */ GetHttpResponseStreamAsync(/*HttpClient*/ client, /*HttpResponseMessage*/ response, /*bool*/ usingResponseHeadersRead, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171798757430);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2((client.MaxResponseContentBufferSize > 0n) && (client.MaxResponseContentBufferSize <= BigInt(2147483647/*int.MaxValue*/)), "client.MaxResponseContentBufferSize is > 0 and <= int.MaxValue");
                /*int*/ let contentLengthLimit = $.$cast(client.MaxResponseContentBufferSize, $.$$.System.Int32);
                let contentLength;
                if ($.$is(response.Content.Headers.ContentLength, $.$$.System.Int64, { set $v(v){ contentLength = v; } }) && contentLength > BigInt(contentLengthLimit))
                {
                    $.$snhj.System.Net.Http.Json.LengthLimitReadStream.ThrowExceededBufferLimit(contentLengthLimit);
                }
                /*ValueTask<Stream>*/ let task = $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(response.Content, cancellationToken);
                return usingResponseHeadersRead ? $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetLengthLimitReadStreamAsync(client, task) : task;
            }
            //--TRIMMABLE-BOUNDARY-END(171798757430)
            
            //--TRIMMABLE-BOUNDARY-START(176093724726)
            static /*ValueTask<Stream> *//*async*/  GetLengthLimitReadStreamAsync(/*HttpClient*/ client, /*ValueTask<Stream>*/ task)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream), $.$$.System.IO.Stream, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(176093724726);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*Stream*/ let contentStream = await task.ConfigureAwait(false);
                    return new $.$snhj.System.Net.Http.Json.LengthLimitReadStream().$ctor$3(contentStream, $.$cast(client.MaxResponseContentBufferSize, $.$$.System.Int32));
                });
            }
            //--TRIMMABLE-BOUNDARY-END(176093724726)
            
            //--TRIMMABLE-BOUNDARY-START(4295032886)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(257698103350)
                    this.s_deleteAsync = new ($.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)))().$ctor($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions, /*static*/ (/*client*/ client, /*uri*/ uri, /*cancellation*/ cancellation) =>
                    {
                        return client.DeleteAsync$2(uri, cancellation);
                    }, {
  "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
  "p": [
    {
      "n": "client",
      "p": 6488117
    },
    {
      "n": "uri",
      "p": 1703938
    },
    {
      "n": "cancellation",
      "p": 169934849
    }
  ],
  "n": "",
  "d": 65590,
  "h": 0,
  "f": 17825826
});
                    //--TRIMMABLE-BOUNDARY-END(257698103350)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(261993070646)
                    this.s_getAsync = new ($.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)))().$ctor($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions, /*static*/ (/*client*/ client, /*uri*/ uri, /*cancellation*/ cancellation) =>
                    {
                        return client.GetAsync$5(uri, 1/*HttpCompletionOption.ResponseHeadersRead*/, cancellation);
                    }, {
  "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
  "p": [
    {
      "n": "client",
      "p": 6488117
    },
    {
      "n": "uri",
      "p": 1703938
    },
    {
      "n": "cancellation",
      "p": 169934849
    }
  ],
  "n": "",
  "d": 65590,
  "h": 0,
  "f": 17825826
});
                    //--TRIMMABLE-BOUNDARY-END(261993070646)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295032886)
            
            static $h = 65590;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(206158495798),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "options",
          "p": 3342420,
          "f": 65
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PostAsJsonAsync",
      "o": "@$1",
      "d": 65590,
      "h": 206158495798,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(206158495798),
//--TRIMMABLE-BOUNDARY-START(210453463094),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "options",
          "p": 3342420,
          "f": 65
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PostAsJsonAsync",
      "o": "@$4",
      "d": 65590,
      "h": 210453463094,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(210453463094),
//--TRIMMABLE-BOUNDARY-START(214748430390),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PostAsJsonAsync",
      "d": 65590,
      "h": 214748430390,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(214748430390),
//--TRIMMABLE-BOUNDARY-START(219043397686),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PostAsJsonAsync",
      "o": "@$3",
      "d": 65590,
      "h": 219043397686,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(219043397686),
//--TRIMMABLE-BOUNDARY-START(223338364982),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "jsonTypeInfo",
          "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PostAsJsonAsync",
      "o": "@$2",
      "d": 65590,
      "h": 223338364982,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(223338364982),
//--TRIMMABLE-BOUNDARY-START(227633332278),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "jsonTypeInfo",
          "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PostAsJsonAsync",
      "o": "@$5",
      "d": 65590,
      "h": 227633332278,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(227633332278),
//--TRIMMABLE-BOUNDARY-START(231928299574),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "options",
          "p": 3342420,
          "f": 65
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PutAsJsonAsync",
      "o": "@$1",
      "d": 65590,
      "h": 231928299574,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(231928299574),
//--TRIMMABLE-BOUNDARY-START(236223266870),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "options",
          "p": 3342420,
          "f": 65
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PutAsJsonAsync",
      "o": "@$4",
      "d": 65590,
      "h": 236223266870,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(236223266870),
//--TRIMMABLE-BOUNDARY-START(240518234166),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PutAsJsonAsync",
      "d": 65590,
      "h": 240518234166,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(240518234166),
//--TRIMMABLE-BOUNDARY-START(244813201462),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PutAsJsonAsync",
      "o": "@$3",
      "d": 65590,
      "h": 244813201462,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(244813201462),
//--TRIMMABLE-BOUNDARY-START(249108168758),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "jsonTypeInfo",
          "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PutAsJsonAsync",
      "o": "@$2",
      "d": 65590,
      "h": 249108168758,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(249108168758),
//--TRIMMABLE-BOUNDARY-START(253403136054),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "jsonTypeInfo",
          "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PutAsJsonAsync",
      "o": "@$5",
      "d": 65590,
      "h": 253403136054,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(253403136054),
//--TRIMMABLE-BOUNDARY-START(94489346102),
    {
      "r": (TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetFromJsonAsAsyncEnumerable",
      "o": "@$1",
      "d": 65590,
      "h": 94489346102,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(94489346102),
//--TRIMMABLE-BOUNDARY-START(98784313398),
    {
      "r": (TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetFromJsonAsAsyncEnumerable",
      "o": "@$4",
      "d": 65590,
      "h": 98784313398,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(98784313398),
//--TRIMMABLE-BOUNDARY-START(103079280694),
    {
      "r": (TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "jsonTypeInfo",
          "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetFromJsonAsAsyncEnumerable",
      "o": "@$2",
      "d": 65590,
      "h": 103079280694,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(103079280694),
//--TRIMMABLE-BOUNDARY-START(107374247990),
    {
      "r": (TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "jsonTypeInfo",
          "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetFromJsonAsAsyncEnumerable",
      "o": "@$5",
      "d": 65590,
      "h": 107374247990,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(107374247990),
//--TRIMMABLE-BOUNDARY-START(111669215286),
    {
      "r": (TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetFromJsonAsAsyncEnumerable",
      "d": 65590,
      "h": 111669215286,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(111669215286),
//--TRIMMABLE-BOUNDARY-START(115964182582),
    {
      "r": (TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetFromJsonAsAsyncEnumerable",
      "o": "@$3",
      "d": 65590,
      "h": 115964182582,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(115964182582),
//--TRIMMABLE-BOUNDARY-START(85899411510),
    {
      "r": (TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "FromJsonStreamAsyncCore",
      "d": 65590,
      "h": 85899411510,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(85899411510),
//--TRIMMABLE-BOUNDARY-START(90194378806),
    {
      "r": (TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "jsonTypeInfo",
          "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "FromJsonStreamAsyncCore",
      "o": "@$1",
      "d": 65590,
      "h": 90194378806,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(90194378806),
//--TRIMMABLE-BOUNDARY-START(180388692022),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "options",
          "p": 3342420,
          "f": 65
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PatchAsJsonAsync",
      "o": "@$1",
      "d": 65590,
      "h": 180388692022,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(180388692022),
//--TRIMMABLE-BOUNDARY-START(184683659318),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "options",
          "p": 3342420,
          "f": 65
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PatchAsJsonAsync",
      "o": "@$4",
      "d": 65590,
      "h": 184683659318,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(184683659318),
//--TRIMMABLE-BOUNDARY-START(188978626614),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PatchAsJsonAsync",
      "d": 65590,
      "h": 188978626614,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(188978626614),
//--TRIMMABLE-BOUNDARY-START(193273593910),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PatchAsJsonAsync",
      "o": "@$3",
      "d": 65590,
      "h": 193273593910,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(193273593910),
//--TRIMMABLE-BOUNDARY-START(197568561206),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "jsonTypeInfo",
          "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PatchAsJsonAsync",
      "o": "@$2",
      "d": 65590,
      "h": 197568561206,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(197568561206),
//--TRIMMABLE-BOUNDARY-START(201863528502),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "value",
          "p": (TValue) => TValue.$h
        },
        {
          "n": "jsonTypeInfo",
          "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "PatchAsJsonAsync",
      "o": "@$5",
      "d": 65590,
      "h": 201863528502,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(201863528502),
//--TRIMMABLE-BOUNDARY-START(12884967478),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "DeleteFromJsonAsync",
      "o": "@$1",
      "d": 65590,
      "h": 12884967478,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12884967478),
//--TRIMMABLE-BOUNDARY-START(17179934774),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "DeleteFromJsonAsync",
      "o": "@$4",
      "d": 65590,
      "h": 17179934774,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17179934774),
//--TRIMMABLE-BOUNDARY-START(21474902070),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "DeleteFromJsonAsync",
      "o": "@$7",
      "d": 65590,
      "h": 21474902070,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21474902070),
//--TRIMMABLE-BOUNDARY-START(25769869366),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "DeleteFromJsonAsync",
      "o": "@$10",
      "d": 65590,
      "h": 25769869366,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25769869366),
//--TRIMMABLE-BOUNDARY-START(30064836662),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "context",
          "p": 15138900
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "DeleteFromJsonAsync",
      "o": "@$2",
      "d": 65590,
      "h": 30064836662,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30064836662),
//--TRIMMABLE-BOUNDARY-START(34359803958),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "context",
          "p": 15138900
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "DeleteFromJsonAsync",
      "o": "@$5",
      "d": 65590,
      "h": 34359803958,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34359803958),
//--TRIMMABLE-BOUNDARY-START(38654771254),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "jsonTypeInfo",
          "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "DeleteFromJsonAsync",
      "o": "@$8",
      "d": 65590,
      "h": 38654771254,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(38654771254),
//--TRIMMABLE-BOUNDARY-START(42949738550),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "jsonTypeInfo",
          "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "DeleteFromJsonAsync",
      "o": "@$11",
      "d": 65590,
      "h": 42949738550,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(42949738550),
//--TRIMMABLE-BOUNDARY-START(47244705846),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "DeleteFromJsonAsync",
      "d": 65590,
      "h": 47244705846,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47244705846),
//--TRIMMABLE-BOUNDARY-START(51539673142),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "DeleteFromJsonAsync",
      "o": "@$3",
      "d": 65590,
      "h": 51539673142,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51539673142),
//--TRIMMABLE-BOUNDARY-START(55834640438),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "DeleteFromJsonAsync",
      "o": "@$6",
      "d": 65590,
      "h": 55834640438,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(55834640438),
//--TRIMMABLE-BOUNDARY-START(60129607734),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "DeleteFromJsonAsync",
      "o": "@$9",
      "d": 65590,
      "h": 60129607734,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(60129607734),
//--TRIMMABLE-BOUNDARY-START(120259149878),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "GetFromJsonAsync",
      "o": "@$1",
      "d": 65590,
      "h": 120259149878,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(120259149878),
//--TRIMMABLE-BOUNDARY-START(124554117174),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "GetFromJsonAsync",
      "o": "@$4",
      "d": 65590,
      "h": 124554117174,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(124554117174),
//--TRIMMABLE-BOUNDARY-START(128849084470),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetFromJsonAsync",
      "o": "@$7",
      "d": 65590,
      "h": 128849084470,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(128849084470),
//--TRIMMABLE-BOUNDARY-START(133144051766),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetFromJsonAsync",
      "o": "@$10",
      "d": 65590,
      "h": 133144051766,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(133144051766),
//--TRIMMABLE-BOUNDARY-START(137439019062),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "context",
          "p": 15138900
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "GetFromJsonAsync",
      "o": "@$2",
      "d": 65590,
      "h": 137439019062,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(137439019062),
//--TRIMMABLE-BOUNDARY-START(141733986358),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "context",
          "p": 15138900
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "GetFromJsonAsync",
      "o": "@$5",
      "d": 65590,
      "h": 141733986358,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(141733986358),
//--TRIMMABLE-BOUNDARY-START(146028953654),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "jsonTypeInfo",
          "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetFromJsonAsync",
      "o": "@$8",
      "d": 65590,
      "h": 146028953654,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(146028953654),
//--TRIMMABLE-BOUNDARY-START(150323920950),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "jsonTypeInfo",
          "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetFromJsonAsync",
      "o": "@$11",
      "d": 65590,
      "h": 150323920950,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(150323920950),
//--TRIMMABLE-BOUNDARY-START(154618888246),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "GetFromJsonAsync",
      "d": 65590,
      "h": 154618888246,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(154618888246),
//--TRIMMABLE-BOUNDARY-START(158913855542),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "GetFromJsonAsync",
      "o": "@$3",
      "d": 65590,
      "h": 158913855542,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(158913855542),
//--TRIMMABLE-BOUNDARY-START(163208822838),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetFromJsonAsync",
      "o": "@$6",
      "d": 65590,
      "h": 163208822838,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(163208822838),
//--TRIMMABLE-BOUNDARY-START(167503790134),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "GetFromJsonAsync",
      "o": "@$9",
      "d": 65590,
      "h": 167503790134,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(167503790134),
//--TRIMMABLE-BOUNDARY-START(64424575030),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "getMethod",
          "p": $.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h
        },
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "FromJsonAsyncCore",
      "d": 65590,
      "h": 64424575030,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(64424575030),
//--TRIMMABLE-BOUNDARY-START(68719542326),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,
      "p": [
        {
          "n": "getMethod",
          "p": $.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h
        },
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "FromJsonAsyncCore",
      "o": "@$3",
      "d": 65590,
      "h": 68719542326,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(68719542326),
//--TRIMMABLE-BOUNDARY-START(73014509622),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "getMethod",
          "p": $.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h
        },
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "context",
          "p": 15138900
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "FromJsonAsyncCore",
      "o": "@$1",
      "d": 65590,
      "h": 73014509622,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(73014509622),
//--TRIMMABLE-BOUNDARY-START(77309476918),
    {
      "r": (TValue) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,
      "p": [
        {
          "n": "getMethod",
          "p": $.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h
        },
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "jsonTypeInfo",
          "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "FromJsonAsyncCore",
      "o": "@$4",
      "d": 65590,
      "h": 77309476918,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(77309476918),
//--TRIMMABLE-BOUNDARY-START(81604444214),
    {
      "r": (TValue, TJsonOptions) => $.$$.System.Threading.Tasks.Task$$(TValue).$h,
      "p": [
        {
          "n": "getMethod",
          "p": $.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h
        },
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "requestUri",
          "p": 1703938
        },
        {
          "n": "deserializeMethod",
          "p": (TValue, TJsonOptions) => $.$$.System.Func$$$$$($.$$.System.IO.Stream, TJsonOptions, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.ValueTask$$(TValue)).$h
        },
        {
          "n": "jsonOptions",
          "p": (TValue, TJsonOptions) => TJsonOptions.$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue",
        "TJsonOptions"
      ],
      "n": "FromJsonAsyncCore",
      "o": "@$2",
      "d": 65590,
      "h": 81604444214,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(81604444214),
//--TRIMMABLE-BOUNDARY-START(8590000182),
    {
      "r": 1703938,
      "p": [
        {
          "n": "uri",
          "p": 1310721
        }
      ],
      "n": "CreateUri",
      "d": 65590,
      "h": 8590000182,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8590000182),
//--TRIMMABLE-BOUNDARY-START(171798757430),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "response",
          "p": 7864373
        },
        {
          "n": "usingResponseHeadersRead",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "GetHttpResponseStreamAsync",
      "d": 65590,
      "h": 171798757430,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(171798757430),
//--TRIMMABLE-BOUNDARY-START(176093724726),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream).$h,
      "p": [
        {
          "n": "client",
          "p": 6488117
        },
        {
          "n": "task",
          "p": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream).$h
        }
      ],
      "n": "GetLengthLimitReadStreamAsync",
      "d": 65590,
      "h": 176093724726,
      "f": 16781346
    },
//--TRIMMABLE-BOUNDARY-END(176093724726)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(257698103350),
    {
      "t": $.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h,
      "n": "s_deleteAsync",
      "d": 65590,
      "h": 257698103350,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(257698103350),
//--TRIMMABLE-BOUNDARY-START(261993070646),
    {
      "t": $.$$.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h,
      "n": "s_getAsync",
      "d": 65590,
      "h": 261993070646,
      "f": 4194338
    },
//--TRIMMABLE-BOUNDARY-END(261993070646)
  ],
  "h": 65590
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Http.Json.HttpClientJsonExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65590)
        
        
        //--TRIMMABLE-BOUNDARY-START(131126)
        $asm.$cls("$snhj.System.Net.Http.Json.HttpContentJsonExtensions", ($self) => class HttpContentJsonExtensions
        {
            //--TRIMMABLE-BOUNDARY-START(17180000310)
            static /*IAsyncEnumerable<TValue?> */ ReadFromJsonAsAsyncEnumerable(TValue, /*this HttpContent*/ content, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180000310);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsAsyncEnumerable$1(TValue, content, null, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180000310)
            
            //--TRIMMABLE-BOUNDARY-START(21474967606)
            static /*IAsyncEnumerable<TValue?> */ ReadFromJsonAsAsyncEnumerable$1(TValue, /*this HttpContent*/ content, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967606);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsAsyncEnumerableCore(TValue, content, options, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(21474967606)
            
            //--TRIMMABLE-BOUNDARY-START(25769934902)
            static /*IAsyncEnumerable<TValue?> */ ReadFromJsonAsAsyncEnumerable$2(TValue, /*this HttpContent*/ content, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934902);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsAsyncEnumerableCore$1(TValue, content, jsonTypeInfo, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(25769934902)
            
            //--TRIMMABLE-BOUNDARY-START(30064902198)
            static /*IAsyncEnumerable<TValue?> */ ReadFromJsonAsAsyncEnumerableCore(TValue, /*HttpContent*/ content, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902198);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*var*/ let jsonTypeInfo = $.$cast($.$snhj.System.Net.Http.Json.JsonHelpers.GetJsonTypeInfo(TValue.$type, options), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue));
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsAsyncEnumerableCore$1(TValue, content, jsonTypeInfo, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(30064902198)
            
            //--TRIMMABLE-BOUNDARY-START(34359869494)
            static /*IAsyncEnumerable<TValue?> *//*async*/  ReadFromJsonAsAsyncEnumerableCore$1(TValue, /*HttpContent*/ content, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return new ($.$$.NetJs.YieldToIterator$$(TValue))().$ctor$1(async function*()
                {
                    /*Stream*/ let contentStream = await $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(content, cancellationToken).ConfigureAwait(false);
                    try
                    {
                        var $en4 = $.$$.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait$1(TValue, $.$stj.System.Text.Json.JsonSerializer.DeserializeAsyncEnumerable$3(TValue, contentStream, jsonTypeInfo, cancellationToken), false).GetAsyncEnumerator();
                        while (await $en4.MoveNextAsync())
                        {
                            var value = $en4.Current;
                            {
                                yield value;
                            }
                        }
                    }
                    finally
                    {
                        contentStream?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            //--TRIMMABLE-BOUNDARY-END(34359869494)
            
            //--TRIMMABLE-BOUNDARY-START(81604509750)
            static /*Task<Stream> */ ReadHttpContentStreamAsync(/*HttpContent*/ content, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604509750);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return content.ReadAsStreamAsync$1(cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(81604509750)
            
            //--TRIMMABLE-BOUNDARY-START(8590065718)
            static /*Stream */ GetTranscodingStream(/*Stream*/ contentStream, /*Encoding*/ sourceEncoding)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590065718);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.Text.Encoding.CreateTranscodingStream(contentStream, sourceEncoding, $.$$.System.Text.Encoding.UTF8, false);
            }
            //--TRIMMABLE-BOUNDARY-END(8590065718)
            
            //--TRIMMABLE-BOUNDARY-START(90194444342)
            /*string*/ static SerializationUnreferencedCodeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(90194444342)
            
            //--TRIMMABLE-BOUNDARY-START(85899477046)
            /*string*/ static SerializationDynamicCodeMessage = null;
            //--TRIMMABLE-BOUNDARY-END(85899477046)
            
            //--TRIMMABLE-BOUNDARY-START(38654836790)
            static /*Task<object?> */ ReadFromJsonAsync$1(/*this HttpContent*/ content, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsyncCore(content, type, options, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(38654836790)
            
            //--TRIMMABLE-BOUNDARY-START(42949804086)
            static /*Task<object?> */ ReadFromJsonAsync(/*this HttpContent*/ content, /*Type*/ type, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949804086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsync$1(content, type, null, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(42949804086)
            
            //--TRIMMABLE-BOUNDARY-START(47244771382)
            static /*Task<T?> */ ReadFromJsonAsync$4(T, /*this HttpContent*/ content, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244771382);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsyncCore$2(T, content, options, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(47244771382)
            
            //--TRIMMABLE-BOUNDARY-START(51539738678)
            static /*Task<T?> */ ReadFromJsonAsync$3(T, /*this HttpContent*/ content, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539738678);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsync$4(T, content, null, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(51539738678)
            
            //--TRIMMABLE-BOUNDARY-START(64424640566)
            static /*Task<object?> *//*async*/  ReadFromJsonAsyncCore(/*HttpContent*/ content, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Object), $.$$.System.Object, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424640566);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let contentStream = null;
                    try
                    {
                        contentStream = await $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(content, cancellationToken).ConfigureAwait(false);
                        return await $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync(contentStream, type, options ?? $.$stj.System.Text.Json.JsonSerializerOptions.Web, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        contentStream?.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(64424640566)
            
            //--TRIMMABLE-BOUNDARY-START(68719607862)
            static /*Task<T?> *//*async*/  ReadFromJsonAsyncCore$2(T, /*HttpContent*/ content, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$(T), T, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719607862);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let contentStream = null;
                    try
                    {
                        contentStream = await $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(content, cancellationToken).ConfigureAwait(false);
                        return await $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$6(T, contentStream, options ?? $.$stj.System.Text.Json.JsonSerializerOptions.Web, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        contentStream?.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(68719607862)
            
            //--TRIMMABLE-BOUNDARY-START(55834705974)
            static /*Task<object?> */ ReadFromJsonAsync$2(/*this HttpContent*/ content, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834705974);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsyncCore$1(content, type, context, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(55834705974)
            
            //--TRIMMABLE-BOUNDARY-START(60129673270)
            static /*Task<T?> */ ReadFromJsonAsync$5(T, /*this HttpContent*/ content, /*JsonTypeInfo<T>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673270);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsyncCore$3(T, content, jsonTypeInfo, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(60129673270)
            
            //--TRIMMABLE-BOUNDARY-START(73014575158)
            static /*Task<object?> *//*async*/  ReadFromJsonAsyncCore$1(/*HttpContent*/ content, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$($.$$.System.Object), $.$$.System.Object, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(73014575158);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let contentStream = null;
                    try
                    {
                        contentStream = await $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(content, cancellationToken).ConfigureAwait(false);
                        return await $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$1(contentStream, type, context, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        contentStream?.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(73014575158)
            
            //--TRIMMABLE-BOUNDARY-START(77309542454)
            static /*Task<T?> *//*async*/  ReadFromJsonAsyncCore$3(T, /*HttpContent*/ content, /*JsonTypeInfo<T>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task$$(T), T, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309542454);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    let contentStream = null;
                    try
                    {
                        contentStream = await $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(content, cancellationToken).ConfigureAwait(false);
                        return await $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$7(T, contentStream, jsonTypeInfo, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        contentStream?.System$IDisposable$Dispose();
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77309542454)
            
            //--TRIMMABLE-BOUNDARY-START(4295098422)
            static /*ValueTask<Stream> */ GetContentStreamAsync(/*HttpContent*/ content, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295098422);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Task<Stream>*/ let task = $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadHttpContentStreamAsync(content, cancellationToken);
                let sourceEncoding;
                return $.$is($.$snhj.System.Net.Http.Json.JsonHelpers.GetEncoding(content), $.$$.System.Text.Encoding, { set $v(v){ sourceEncoding = v; } }) && sourceEncoding !== $.$$.System.Text.Encoding.UTF8 ? $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetTranscodingStreamAsync(task, sourceEncoding) : new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream))().$ctor$5(task);
            }
            //--TRIMMABLE-BOUNDARY-END(4295098422)
            
            //--TRIMMABLE-BOUNDARY-START(12885033014)
            static /*ValueTask<Stream> *//*async*/  GetTranscodingStreamAsync(/*Task<Stream>*/ task, /*Encoding*/ sourceEncoding)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream), $.$$.System.IO.Stream, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885033014);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*Stream*/ let contentStream = await task.ConfigureAwait$2(false);
                    return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetTranscodingStream(contentStream, sourceEncoding);
                });
            }
            //--TRIMMABLE-BOUNDARY-END(12885033014)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(90194444342)
                    this.SerializationUnreferencedCodeMessage = "JSON serialization and deserialization might require types that cannot be statically analyzed. Use the overload that takes a JsonTypeInfo or JsonSerializerContext, or make sure all of the required types are preserved.";
                    //--TRIMMABLE-BOUNDARY-END(90194444342)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(85899477046)
                    this.SerializationDynamicCodeMessage = "JSON serialization and deserialization might require types that cannot be statically analyzed. Use the overload that takes a JsonTypeInfo or JsonSerializerContext.";
                    //--TRIMMABLE-BOUNDARY-END(85899477046)
                    
                }
            }
            static $h = 131126;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180000310),
    {
      "r": (TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "ReadFromJsonAsAsyncEnumerable",
      "d": 131126,
      "h": 17180000310,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180000310),
//--TRIMMABLE-BOUNDARY-START(21474967606),
    {
      "r": (TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "ReadFromJsonAsAsyncEnumerable",
      "o": "@$1",
      "d": 131126,
      "h": 21474967606,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(21474967606),
//--TRIMMABLE-BOUNDARY-START(25769934902),
    {
      "r": (TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "jsonTypeInfo",
          "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "ReadFromJsonAsAsyncEnumerable",
      "o": "@$2",
      "d": 131126,
      "h": 25769934902,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25769934902),
//--TRIMMABLE-BOUNDARY-START(30064902198),
    {
      "r": (TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "ReadFromJsonAsAsyncEnumerableCore",
      "d": 131126,
      "h": 30064902198,
      "f": 16908322
    },
//--TRIMMABLE-BOUNDARY-END(30064902198),
//--TRIMMABLE-BOUNDARY-START(34359869494),
    {
      "r": (TValue) => $.$$.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "jsonTypeInfo",
          "p": (TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "a": [
            {
              "t": 127664129,
              "c": 4422631425
            }
          ]
        }
      ],
      "g": [
        "TValue"
      ],
      "n": "ReadFromJsonAsAsyncEnumerableCore",
      "o": "@$1",
      "d": 131126,
      "h": 34359869494,
      "f": 16912418
    },
//--TRIMMABLE-BOUNDARY-END(34359869494),
//--TRIMMABLE-BOUNDARY-START(81604509750),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.IO.Stream).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "ReadHttpContentStreamAsync",
      "d": 131126,
      "h": 81604509750,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(81604509750),
//--TRIMMABLE-BOUNDARY-START(8590065718),
    {
      "r": 94830593,
      "p": [
        {
          "n": "contentStream",
          "p": 94830593
        },
        {
          "n": "sourceEncoding",
          "p": 165806081
        }
      ],
      "n": "GetTranscodingStream",
      "d": 131126,
      "h": 8590065718,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(8590065718),
//--TRIMMABLE-BOUNDARY-START(38654836790),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "ReadFromJsonAsync",
      "o": "@$1",
      "d": 131126,
      "h": 38654836790,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38654836790),
//--TRIMMABLE-BOUNDARY-START(42949804086),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "ReadFromJsonAsync",
      "d": 131126,
      "h": 42949804086,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42949804086),
//--TRIMMABLE-BOUNDARY-START(47244771382),
    {
      "r": (T) => $.$$.System.Threading.Tasks.Task$$(T).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "ReadFromJsonAsync",
      "o": "@$4",
      "d": 131126,
      "h": 47244771382,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(47244771382),
//--TRIMMABLE-BOUNDARY-START(51539738678),
    {
      "r": (T) => $.$$.System.Threading.Tasks.Task$$(T).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "ReadFromJsonAsync",
      "o": "@$3",
      "d": 131126,
      "h": 51539738678,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(51539738678),
//--TRIMMABLE-BOUNDARY-START(64424640566),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "ReadFromJsonAsyncCore",
      "d": 131126,
      "h": 64424640566,
      "f": 16781346
    },
//--TRIMMABLE-BOUNDARY-END(64424640566),
//--TRIMMABLE-BOUNDARY-START(68719607862),
    {
      "r": (T) => $.$$.System.Threading.Tasks.Task$$(T).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "options",
          "p": 3342420
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "T"
      ],
      "n": "ReadFromJsonAsyncCore",
      "o": "@$2",
      "d": 131126,
      "h": 68719607862,
      "f": 16912418
    },
//--TRIMMABLE-BOUNDARY-END(68719607862),
//--TRIMMABLE-BOUNDARY-START(55834705974),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "context",
          "p": 15138900
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "ReadFromJsonAsync",
      "o": "@$2",
      "d": 131126,
      "h": 55834705974,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55834705974),
//--TRIMMABLE-BOUNDARY-START(60129673270),
    {
      "r": (T) => $.$$.System.Threading.Tasks.Task$$(T).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "jsonTypeInfo",
          "p": (T) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(T).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "ReadFromJsonAsync",
      "o": "@$5",
      "d": 131126,
      "h": 60129673270,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(60129673270),
//--TRIMMABLE-BOUNDARY-START(73014575158),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Object).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "context",
          "p": 15138900
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "ReadFromJsonAsyncCore",
      "o": "@$1",
      "d": 131126,
      "h": 73014575158,
      "f": 16781346
    },
//--TRIMMABLE-BOUNDARY-END(73014575158),
//--TRIMMABLE-BOUNDARY-START(77309542454),
    {
      "r": (T) => $.$$.System.Threading.Tasks.Task$$(T).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "jsonTypeInfo",
          "p": (T) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(T).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "g": [
        "T"
      ],
      "n": "ReadFromJsonAsyncCore",
      "o": "@$3",
      "d": 131126,
      "h": 77309542454,
      "f": 16912418
    },
//--TRIMMABLE-BOUNDARY-END(77309542454),
//--TRIMMABLE-BOUNDARY-START(4295098422),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream).$h,
      "p": [
        {
          "n": "content",
          "p": 6684725
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "GetContentStreamAsync",
      "d": 131126,
      "h": 4295098422,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(4295098422),
//--TRIMMABLE-BOUNDARY-START(12885033014),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.IO.Stream).$h,
      "p": [
        {
          "n": "task",
          "p": $.$$.System.Threading.Tasks.Task$$($.$$.System.IO.Stream).$h
        },
        {
          "n": "sourceEncoding",
          "p": 165806081
        }
      ],
      "n": "GetTranscodingStreamAsync",
      "d": 131126,
      "h": 12885033014,
      "f": 16781346
    },
//--TRIMMABLE-BOUNDARY-END(12885033014)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(90194444342),
    {
      "t": 1310721,
      "n": "SerializationUnreferencedCodeMessage",
      "d": 131126,
      "h": 90194444342,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(90194444342),
//--TRIMMABLE-BOUNDARY-START(85899477046),
    {
      "t": 1310721,
      "n": "SerializationDynamicCodeMessage",
      "d": 131126,
      "h": 85899477046,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(85899477046)
  ],
  "h": 131126
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Http.Json.HttpContentJsonExtensions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131126)
        
        
        //--TRIMMABLE-BOUNDARY-START(393270)
        $asm.$cls("$snhj.System.SR", ($self) => class SR
        {
            //--TRIMMABLE-BOUNDARY-START(171799085110)
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            //--TRIMMABLE-BOUNDARY-END(171799085110)
            
            //--TRIMMABLE-BOUNDARY-START(163209150518)
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            //--TRIMMABLE-BOUNDARY-END(163209150518)
            
            //--TRIMMABLE-BOUNDARY-START(167504117814)
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849412150);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$$.System.Object.ReferenceEquals($.$snhj.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Net.Http.Json", $.$snhj.System.SR.$type.Assembly);
                    $.$snhj.System.SR.s_resourceManager = temp;
                }
                return $.$snhj.System.SR.s_resourceManager;
            }
            //--TRIMMABLE-BOUNDARY-END(167504117814)
            
            //--TRIMMABLE-BOUNDARY-START(21475229750)
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079608374);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$snhj.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188978954294);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$snhj.System.SR.resourceCulture = value;
            }
            //--TRIMMABLE-BOUNDARY-END(21475229750)
            
            //--TRIMMABLE-BOUNDARY-START(8590327862)
            static /*string */ get Argument_InvalidOffLen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309804598);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Offset and length were out of bounds for the array or count is greater than the number of elements from index to the end of the source collection.";
            }
            //--TRIMMABLE-BOUNDARY-END(8590327862)
            
            //--TRIMMABLE-BOUNDARY-START(12885295158)
            static /*string */ get CharSetInvalid()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899739190);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The character set provided in ContentType is invalid.";
            }
            //--TRIMMABLE-BOUNDARY-END(12885295158)
            
            //--TRIMMABLE-BOUNDARY-START(17180262454)
            static /*string */ get CharSetNotSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489673782);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The character set provided in ContentType is not supported.";
            }
            //--TRIMMABLE-BOUNDARY-END(17180262454)
            
            //--TRIMMABLE-BOUNDARY-START(180389019702)
            static /*string */ get SerializeWrongType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439346742);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The specified type {0} must derive from the specific value's type {1}.";
            }
            //--TRIMMABLE-BOUNDARY-END(180389019702)
            
            //--TRIMMABLE-BOUNDARY-START(68719870006)
            static /*string */ FormatSerializeWrongType(/*object*/ arg1, /*object*/ arg2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719870006);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$8("The specified type {0} must derive from the specific value's type {1}.", arg1, arg2);
            }
            //--TRIMMABLE-BOUNDARY-END(68719870006)
            
            //--TRIMMABLE-BOUNDARY-START(158914183222)
            static /*string */ get net_http_request_timedout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259477558);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "The request was canceled due to the configured HttpClient.Timeout of {0} seconds elapsing.";
            }
            //--TRIMMABLE-BOUNDARY-END(158914183222)
            
            //--TRIMMABLE-BOUNDARY-START(64424902710)
            static /*string */ Formatnet_http_request_timedout(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424902710);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("The request was canceled due to the configured HttpClient.Timeout of {0} seconds elapsing.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(64424902710)
            
            //--TRIMMABLE-BOUNDARY-START(154619215926)
            static /*string */ get net_http_content_buffersize_exceeded()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669542966);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return "Cannot write more bytes to the buffer than the configured maximum buffer size: {0}.";
            }
            //--TRIMMABLE-BOUNDARY-END(154619215926)
            
            //--TRIMMABLE-BOUNDARY-START(60129935414)
            static /*string */ Formatnet_http_content_buffersize_exceeded(/*object*/ arg1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129935414);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return $.$$.System.String.Format$9("Cannot write more bytes to the buffer than the configured maximum buffer size: {0}.", arg1);
            }
            //--TRIMMABLE-BOUNDARY-END(60129935414)
            
            //--TRIMMABLE-BOUNDARY-START(176094052406)
            /*bool*/ static s_usingResourceKeys = false;
            //--TRIMMABLE-BOUNDARY-END(176094052406)
            
            //--TRIMMABLE-BOUNDARY-START(150324248630)
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(150324248630);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*bool*/ let usingResourceKeys;
                    return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(150324248630)
            
            //--TRIMMABLE-BOUNDARY-START(193273921590)
            static /*bool */ UsingResourceKeys()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(193273921590);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.SR.s_usingResourceKeys;
                }
            }
            //--TRIMMABLE-BOUNDARY-END(193273921590)
            
            //--TRIMMABLE-BOUNDARY-START(141734314038)
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734314038);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$snhj.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(141734314038)
            
            //--TRIMMABLE-BOUNDARY-START(146029281334)
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029281334);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*string*/ let resourceString = $.$snhj.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            //--TRIMMABLE-BOUNDARY-END(146029281334)
            
            //--TRIMMABLE-BOUNDARY-START(25770197046)
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770197046);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(25770197046)
            
            //--TRIMMABLE-BOUNDARY-START(30065164342)
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065164342);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(30065164342)
            
            //--TRIMMABLE-BOUNDARY-START(34360131638)
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360131638);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(34360131638)
            
            //--TRIMMABLE-BOUNDARY-START(38655098934)
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655098934);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$snhj.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(38655098934)
            
            //--TRIMMABLE-BOUNDARY-START(42950066230)
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950066230);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            //--TRIMMABLE-BOUNDARY-END(42950066230)
            
            //--TRIMMABLE-BOUNDARY-START(47245033526)
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245033526);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            //--TRIMMABLE-BOUNDARY-END(47245033526)
            
            //--TRIMMABLE-BOUNDARY-START(51540000822)
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540000822);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            //--TRIMMABLE-BOUNDARY-END(51540000822)
            
            //--TRIMMABLE-BOUNDARY-START(55834968118)
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834968118);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (args !== null)
                {
                    if ($.$snhj.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //--TRIMMABLE-BOUNDARY-END(55834968118)
            
            //--TRIMMABLE-BOUNDARY-START(4295360566)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(176094052406)
                    this.s_usingResourceKeys = $.$snhj.System.SR.GetUsingResourceKeysSwitchValue();
                    //--TRIMMABLE-BOUNDARY-END(176094052406)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(4295360566)
            
            static $h = 393270;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "h": 393270
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393270)
        
        
        //--TRIMMABLE-BOUNDARY-START(262198)
        $asm.$cls("$snhj.System.Net.Http.Json.JsonHelpers", ($self) => class JsonHelpers
        {
            //--TRIMMABLE-BOUNDARY-START(12885164086)
            static /*JsonTypeInfo */ GetJsonTypeInfo(/*Type*/ type, /*JsonSerializerOptions?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885164086);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.Diagnostics.Debug.Assert$2(!(type === null), "type is not null");
                options ??= $.$stj.System.Text.Json.JsonSerializerOptions.Web;
                options.MakeReadOnly$1(true);
                return options.GetTypeInfo(type);
            }
            //--TRIMMABLE-BOUNDARY-END(12885164086)
            
            //--TRIMMABLE-BOUNDARY-START(4295229494)
            /*string*/ static DefaultMediaType = null;
            //--TRIMMABLE-BOUNDARY-END(4295229494)
            
            //--TRIMMABLE-BOUNDARY-START(8590196790)
            static /*Encoding? */ GetEncoding(/*HttpContent*/ content)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590196790);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Encoding?*/ let encoding = null;
                let charset;
                if ($.$is((content.Headers.ContentType?.CharSet ?? null), $.$$.System.String, { set $v(v){ charset = v; } }))
                {
                    try
                    {
                        if (charset.length > 2 && $.$$.System.String.get_Chars.call(charset, 0) === /*\"*/ 34 && $.$$.System.String.get_Chars.call(charset, ((charset.length - 1) | 0)) === /*\"*/ 34)
                        {
                            encoding = $.$$.System.Text.Encoding.GetEncoding$3($.$$.System.String.Substring.call(charset, 1, ((charset.length - 2) | 0)));
                        }
                        else 
                        {
                            encoding = $.$$.System.Text.Encoding.GetEncoding$3(charset);
                        }
                    }
                    catch(e)
                    {
                        throw new $.$$.System.InvalidOperationException().$ctor$11($.$snhj.System.SR.CharSetInvalid, e);
                    }
                    $.$$.System.Diagnostics.Debug.Assert$2(encoding !== null, "encoding != null");
                }
                return encoding;
            }
            //--TRIMMABLE-BOUNDARY-END(8590196790)
            
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(4295229494)
                    this.DefaultMediaType = "application/json; charset=utf-8";
                    //--TRIMMABLE-BOUNDARY-END(4295229494)
                    
                }
            }
            static $h = 262198;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885164086),
    {
      "r": 17170516,
      "p": [
        {
          "n": "type",
          "p": 187629569
        },
        {
          "n": "options",
          "p": 3342420
        }
      ],
      "n": "GetJsonTypeInfo",
      "d": 262198,
      "h": 12885164086,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(12885164086),
//--TRIMMABLE-BOUNDARY-START(8590196790),
    {
      "r": 165806081,
      "p": [
        {
          "n": "content",
          "p": 6684725
        }
      ],
      "n": "GetEncoding",
      "d": 262198,
      "h": 8590196790,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(8590196790)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295229494),
    {
      "t": 1310721,
      "n": "DefaultMediaType",
      "d": 262198,
      "h": 4295229494,
      "f": 4194344
    },
//--TRIMMABLE-BOUNDARY-END(4295229494)
  ],
  "h": 262198
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Http.Json.JsonHelpers`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262198)
        
        
        //--TRIMMABLE-BOUNDARY-START(196662)
        $asm.$cls("$snhj.System.Net.Http.Json.JsonContent", ($self) => class JsonContent extends $.$snh.System.Net.Http.HttpContent
        {
            //--TRIMMABLE-BOUNDARY-START(ALL, 60129738806, 287769493557)
            /*void */ SerializeToStream(/*Stream*/ stream, /*TransportContext?*/ context, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129738806);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let targetEncoding;
                if ($.$is($.$snhj.System.Net.Http.Json.JsonHelpers.GetEncoding(this), $.$$.System.Text.Encoding, { set $v(v){ targetEncoding = v; } }) && targetEncoding !== $.$$.System.Text.Encoding.UTF8)
                {
                    this.SerializeToStreamAsyncTranscoding(stream, false, targetEncoding, cancellationToken).GetAwaiter().GetResult();
                }
                else 
                {
                    $.$stj.System.Text.Json.JsonSerializer.Serialize$2(stream, this.Value, this._typeInfo);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 60129738806, 287769493557)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 64424706102, 296359428149)
            /*Task */ SerializeToStreamAsync(/*Stream*/ stream, /*TransportContext?*/ context, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(64424706102);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.SerializeToStreamAsyncCore(stream, cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 64424706102, 296359428149)
            
            //--TRIMMABLE-BOUNDARY-START(4295163958)
            /*JsonTypeInfo*/ _typeInfo = null;
            //--TRIMMABLE-BOUNDARY-END(4295163958)
            
            //--TRIMMABLE-BOUNDARY-START(55834771510)
            /*Type */ get ObjectType()
            {
                return this._typeInfo.Type;
            }
            //--TRIMMABLE-BOUNDARY-END(55834771510)
            
            //--TRIMMABLE-BOUNDARY-START(85899542582)
            /*object?*/ Value = null;
            //--TRIMMABLE-BOUNDARY-END(85899542582)
            
            //--TRIMMABLE-BOUNDARY-START(8590131254)
            $ctor$2(/*object?*/ inputValue, /*JsonTypeInfo*/ jsonTypeInfo, /*MediaTypeHeaderValue?*/ mediaType)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590131254);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    $.$$.System.Diagnostics.Debug.Assert$2(!(jsonTypeInfo === null), "jsonTypeInfo is not null");
                    $.$$.System.Diagnostics.Debug.Assert$2(inputValue === null || jsonTypeInfo.Type.IsAssignableFrom($.$$.System.Object.GetType.call(inputValue)), "inputValue is null || jsonTypeInfo.Type.IsAssignableFrom(inputValue.GetType())");
                    this.Value = inputValue;
                    this._typeInfo = jsonTypeInfo;
                    if (!(mediaType === null))
                    {
                        this.Headers.ContentType = mediaType;
                    }
                    else 
                    {
                        this.Headers.TryAddWithoutValidation$1("Content-Type", "application/json; charset=utf-8"/*JsonHelpers.DefaultMediaType*/);
                    }
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590131254)
            
            //--TRIMMABLE-BOUNDARY-START(17180065846)
            static /*JsonContent */ Create$2(T, /*T*/ inputValue, /*MediaTypeHeaderValue?*/ mediaType, /*JsonSerializerOptions?*/ options)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180065846);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return $.$snhj.System.Net.Http.Json.JsonContent.Create$1($.$box(inputValue, T), $.$snhj.System.Net.Http.Json.JsonHelpers.GetJsonTypeInfo(T.$type, options), mediaType);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(17180065846)
            
            //--TRIMMABLE-BOUNDARY-START(21475033142)
            static /*JsonContent */ Create(/*object?*/ inputValue, /*Type*/ inputType, /*MediaTypeHeaderValue?*/ mediaType, /*JsonSerializerOptions?*/ options)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033142);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(inputType, "inputType");
                $.$snhj.System.Net.Http.Json.JsonContent.EnsureTypeCompatibility(inputValue, inputType);
                return new $.$snhj.System.Net.Http.Json.JsonContent().$ctor$2(inputValue, $.$snhj.System.Net.Http.Json.JsonHelpers.GetJsonTypeInfo(inputType, options), mediaType);
            }
            //--TRIMMABLE-BOUNDARY-END(21475033142)
            
            //--TRIMMABLE-BOUNDARY-START(25770000438)
            static /*JsonContent */ Create$3(T, /*T?*/ inputValue, /*JsonTypeInfo<T>*/ jsonTypeInfo, /*MediaTypeHeaderValue?*/ mediaType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770000438);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsonTypeInfo, "jsonTypeInfo");
                return new $.$snhj.System.Net.Http.Json.JsonContent().$ctor$2($.$box(inputValue, T), jsonTypeInfo, mediaType);
            }
            //--TRIMMABLE-BOUNDARY-END(25770000438)
            
            //--TRIMMABLE-BOUNDARY-START(30064967734)
            static /*JsonContent */ Create$1(/*object?*/ inputValue, /*JsonTypeInfo*/ jsonTypeInfo, /*MediaTypeHeaderValue?*/ mediaType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064967734);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                $.$$.System.ArgumentNullException.ThrowIfNull$2(jsonTypeInfo, "jsonTypeInfo");
                $.$snhj.System.Net.Http.Json.JsonContent.EnsureTypeCompatibility(inputValue, jsonTypeInfo.Type);
                return new $.$snhj.System.Net.Http.Json.JsonContent().$ctor$2(inputValue, jsonTypeInfo, mediaType);
            }
            //--TRIMMABLE-BOUNDARY-END(30064967734)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 68719673398, 292064460853)
            /*Task */ SerializeToStreamAsync$1(/*Stream*/ stream, /*TransportContext?*/ context)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(68719673398);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.SerializeToStreamAsyncCore(stream, $.$$.System.Threading.CancellationToken.None);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 68719673398, 292064460853)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 81604575286, 304949362741)
            /*bool */ TryComputeLength(/*out long*/ length)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575286);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                length.$v = 0n;
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 81604575286, 304949362741)
            
            //--TRIMMABLE-BOUNDARY-START(73014640694)
            /*Task */ SerializeToStreamAsyncCore(/*Stream*/ targetStream, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640694);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*Encoding?*/ let targetEncoding = $.$snhj.System.Net.Http.Json.JsonHelpers.GetEncoding(this);
                return targetEncoding !== null && targetEncoding !== $.$$.System.Text.Encoding.UTF8 ? this.SerializeToStreamAsyncTranscoding(targetStream, true, targetEncoding, cancellationToken) : $.$stj.System.Text.Json.JsonSerializer.SerializeAsync$2(targetStream, this.Value, this._typeInfo, cancellationToken);
            }
            //--TRIMMABLE-BOUNDARY-END(73014640694)
            
            //--TRIMMABLE-BOUNDARY-START(77309607990)
            /*Task *//*async*/  SerializeToStreamAsyncTranscoding(/*Stream*/ targetStream, /*bool*/ $async, /*Encoding*/ targetEncoding, /*CancellationToken*/ cancellationToken)
            {
                return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.Task, $.$$.System.Void, async () => 
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(77309607990);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    /*Stream*/ let transcodingStream = $.$$.System.Text.Encoding.CreateTranscodingStream(targetStream, targetEncoding, $.$$.System.Text.Encoding.UTF8, true);
                    try
                    {
                        if ($async)
                        {
                            await $.$stj.System.Text.Json.JsonSerializer.SerializeAsync$2(transcodingStream, this.Value, this._typeInfo, cancellationToken).ConfigureAwait(false);
                        }
                        else 
                        {
                            $.$stj.System.Text.Json.JsonSerializer.Serialize$2(transcodingStream, this.Value, this._typeInfo);
                        }
                    }
                    finally
                    {
                        {
                            if ($async)
                            {
                                await transcodingStream.DisposeAsync().ConfigureAwait(false);
                            }
                            else 
                            {
                                transcodingStream.Dispose();
                            }
                        }
                    }
                });
            }
            //--TRIMMABLE-BOUNDARY-END(77309607990)
            
            //--TRIMMABLE-BOUNDARY-START(34359935030)
            static /*void */ EnsureTypeCompatibility(/*object?*/ inputValue, /*Type*/ inputType)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359935030);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                if (!(inputValue === null) && !inputType.IsAssignableFrom($.$$.System.Object.GetType.call(inputValue)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$14($.$snhj.System.SR.Format$5($.$snhj.System.SR.SerializeWrongType, inputType, $.$$.System.Object.GetType.call(inputValue)));
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34359935030)
            
            static $h = 196662;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 6684725,
  "p": [
//--TRIMMABLE-BOUNDARY-START(55834771510),
    {
      "p": 187629569,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949869622,
        "f": 50331649
      },
      "n": "ObjectType",
      "d": 196662,
      "h": 55834771510,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55834771510),
//--TRIMMABLE-BOUNDARY-START(85899542582),
    {
      "p": 131073,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539804214,
        "f": 50331649
      },
      "n": "Value",
      "d": 196662,
      "h": 85899542582,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899542582)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(ALL, 60129738806, 287769493557),
    {
      "r": 65537,
      "p": [
        {
          "n": "stream",
          "p": 94830593
        },
        {
          "n": "context",
          "p": 4980783
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "SerializeToStream",
      "d": 196662,
      "h": 60129738806,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 60129738806, 287769493557),
//--TRIMMABLE-BOUNDARY-START(ALL, 64424706102, 296359428149),
    {
      "r": 177537025,
      "p": [
        {
          "n": "stream",
          "p": 94830593
        },
        {
          "n": "context",
          "p": 4980783
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "SerializeToStreamAsync",
      "d": 196662,
      "h": 64424706102,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 64424706102, 296359428149),
//--TRIMMABLE-BOUNDARY-START(17180065846),
    {
      "r": 196662,
      "p": [
        {
          "n": "inputValue",
          "p": (T) => T.$h
        },
        {
          "n": "mediaType",
          "p": 4784181,
          "f": 65
        },
        {
          "n": "options",
          "p": 3342420,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "Create",
      "o": "@$2",
      "d": 196662,
      "h": 17180065846,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(17180065846),
//--TRIMMABLE-BOUNDARY-START(21475033142),
    {
      "r": 196662,
      "p": [
        {
          "n": "inputValue",
          "p": 131073
        },
        {
          "n": "inputType",
          "p": 187629569
        },
        {
          "n": "mediaType",
          "p": 4784181,
          "f": 65
        },
        {
          "n": "options",
          "p": 3342420,
          "f": 65
        }
      ],
      "n": "Create",
      "d": 196662,
      "h": 21475033142,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(21475033142),
//--TRIMMABLE-BOUNDARY-START(25770000438),
    {
      "r": 196662,
      "p": [
        {
          "n": "inputValue",
          "p": (T) => T.$h
        },
        {
          "n": "jsonTypeInfo",
          "p": (T) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(T).$h
        },
        {
          "n": "mediaType",
          "p": 4784181,
          "f": 65
        }
      ],
      "g": [
        "T"
      ],
      "n": "Create",
      "o": "@$3",
      "d": 196662,
      "h": 25770000438,
      "f": 16908321
    },
//--TRIMMABLE-BOUNDARY-END(25770000438),
//--TRIMMABLE-BOUNDARY-START(30064967734),
    {
      "r": 196662,
      "p": [
        {
          "n": "inputValue",
          "p": 131073
        },
        {
          "n": "jsonTypeInfo",
          "p": 17170516
        },
        {
          "n": "mediaType",
          "p": 4784181,
          "f": 65
        }
      ],
      "n": "Create",
      "o": "@$1",
      "d": 196662,
      "h": 30064967734,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30064967734),
//--TRIMMABLE-BOUNDARY-START(ALL, 68719673398, 292064460853),
    {
      "r": 177537025,
      "p": [
        {
          "n": "stream",
          "p": 94830593
        },
        {
          "n": "context",
          "p": 4980783
        }
      ],
      "n": "SerializeToStreamAsync",
      "o": "@$1",
      "d": 196662,
      "h": 68719673398,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 68719673398, 292064460853),
//--TRIMMABLE-BOUNDARY-START(ALL, 81604575286, 304949362741),
    {
      "r": 262145,
      "p": [
        {
          "n": "length",
          "p": 917505,
          "f": 2
        }
      ],
      "n": "TryComputeLength",
      "d": 196662,
      "h": 81604575286,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 81604575286, 304949362741),
//--TRIMMABLE-BOUNDARY-START(73014640694),
    {
      "r": 177537025,
      "p": [
        {
          "n": "targetStream",
          "p": 94830593
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "SerializeToStreamAsyncCore",
      "d": 196662,
      "h": 73014640694,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(73014640694),
//--TRIMMABLE-BOUNDARY-START(77309607990),
    {
      "r": 177537025,
      "p": [
        {
          "n": "targetStream",
          "p": 94830593
        },
        {
          "n": "async",
          "p": 262145
        },
        {
          "n": "targetEncoding",
          "p": 165806081
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "SerializeToStreamAsyncTranscoding",
      "d": 196662,
      "h": 77309607990,
      "f": 16781314
    },
//--TRIMMABLE-BOUNDARY-END(77309607990),
//--TRIMMABLE-BOUNDARY-START(34359935030),
    {
      "r": 65537,
      "p": [
        {
          "n": "inputValue",
          "p": 131073
        },
        {
          "n": "inputType",
          "p": 187629569
        }
      ],
      "n": "EnsureTypeCompatibility",
      "d": 196662,
      "h": 34359935030,
      "f": 16777250
    },
//--TRIMMABLE-BOUNDARY-END(34359935030)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295163958),
    {
      "t": 17170516,
      "n": "_typeInfo",
      "d": 196662,
      "h": 4295163958,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295163958)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590131254),
    {
      "p": [
        {
          "n": "inputValue",
          "p": 131073
        },
        {
          "n": "jsonTypeInfo",
          "p": 17170516
        },
        {
          "n": "mediaType",
          "p": 4784181
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 196662,
      "h": 8590131254,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(8590131254)
  ],
  "i": [90177537
  ],
  "h": 196662
}; }
            static get $b() { return $.$snh.System.Net.Http.HttpContent; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Http.Json.JsonContent`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196662)
        
        
        //--TRIMMABLE-BOUNDARY-START(327734)
        $asm.$cls("$snhj.System.Net.Http.Json.LengthLimitReadStream", ($self) => class LengthLimitReadStream extends $.$$.System.IO.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(4295295030)
            /*Stream*/ _innerStream = null;
            //--TRIMMABLE-BOUNDARY-END(4295295030)
            
            //--TRIMMABLE-BOUNDARY-START(8590262326)
            /*int*/ _lengthLimit = 0;
            //--TRIMMABLE-BOUNDARY-END(8590262326)
            
            //--TRIMMABLE-BOUNDARY-START(12885229622)
            /*int*/ _remainingLength = 0;
            //--TRIMMABLE-BOUNDARY-END(12885229622)
            
            //--TRIMMABLE-BOUNDARY-START(17180196918)
            $ctor$3(/*Stream*/ innerStream, /*int*/ lengthLimit)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180196918);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    this._innerStream = innerStream;
                    this._lengthLimit = this._remainingLength = lengthLimit;
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180196918)
            
            //--TRIMMABLE-BOUNDARY-START(34360066102)
            /*void */ CheckLengthLimit(/*int*/ read)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066102);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                this._remainingLength -= read;
                if (this._remainingLength < 0)
                {
                    $.$snhj.System.Net.Http.Json.LengthLimitReadStream.ThrowExceededBufferLimit(this._lengthLimit);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(34360066102)
            
            //--TRIMMABLE-BOUNDARY-START(128849346614)
            static /*void */ ThrowExceededBufferLimit(/*int*/ limit)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849346614);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$snh.System.Net.Http.HttpRequestException().$ctor$8($.$snhj.System.SR.Format$6($.$snhj.System.SR.net_http_content_buffersize_exceeded, $.$box(limit, $.$$.System.Int32)));
            }
            //--TRIMMABLE-BOUNDARY-END(128849346614)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 21475164214, 43044503553)
            /*bool */ get CanRead()
            {
                return this._innerStream.CanRead;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 21475164214, 43044503553)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 25770131510, 47339470849)
            /*bool */ get CanSeek()
            {
                return this._innerStream.CanSeek;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 25770131510, 47339470849)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 30065098806, 55929405441)
            /*bool */ get CanWrite()
            {
                return false;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 30065098806, 55929405441)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 103079542838, 257792868353)
            /*Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(103079542838);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this.ReadAsync$2(new ($.$$.System.Memory$$($.$$.System.Byte))().$ctor$5(buffer, offset, count), cancellationToken).AsTask();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 103079542838, 257792868353)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 107374510134, 262087835649)
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374510134);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*ValueTask<int>*/ let readTask = this._innerStream.ReadAsync$2(buffer, cancellationToken);
                if (buffer.IsEmpty)
                {
                    return readTask;
                }
                if (readTask.IsCompletedSuccessfully)
                {
                    /*int*/ let read = readTask.Result;
                    this.CheckLengthLimit(read);
                    return new ($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32))().$ctor$6(read);
                }
                return Core.call(this, readTask);
                /*ValueTask<int>*/ /*async*/  function Core(/*ValueTask<int>*/ readTask)
                {
                    return $.$$.NetJs.AsyncResolver.Async($.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32), $.$$.System.Int32, async () => 
                    {
                        /*int*/ let read = await readTask.ConfigureAwait(false);
                        this.CheckLengthLimit(read);
                        return read;
                    });
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 107374510134, 262087835649)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 98784575542, 244907966465)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784575542);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                /*int*/ let read = this._innerStream.Read(buffer, offset, count);
                this.CheckLengthLimit(read);
                return read;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 98784575542, 244907966465)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 38655033398, 128943849473)
            /*void */ Flush()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(38655033398);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerStream.Flush();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 38655033398, 128943849473)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 42950000694, 137533784065)
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(42950000694);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerStream.FlushAsync$1(cancellationToken);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 42950000694, 137533784065)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 111669477430, 326512345089)
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(111669477430);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerStream.Seek(offset, origin);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 111669477430, 326512345089)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 124554379318, 356577116161)
            /*void */ SetLength(/*long*/ value)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(124554379318);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    return this._innerStream.SetLength(value);
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 124554379318, 356577116161)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 90194640950, 223433129985)
            /*long */ get Length()
            {
                return this._innerStream.Length;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 90194640950, 223433129985)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 94489608246, 240612999169)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899673654);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._innerStream.Position;
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259412022);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this._innerStream.Position = value;
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 94489608246, 240612999169)
            
            //--TRIMMABLE-BOUNDARY-START(ALL, 133144313910, 382346919937)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(133144313910);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.System.NotSupportedException().$ctor$9();
                }
            }
            //--TRIMMABLE-BOUNDARY-END(ALL, 133144313910, 382346919937)
            
            static $h = 327734;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 94830593,
  "p": [
//--TRIMMABLE-BOUNDARY-START(ALL, 21475164214, 43044503553),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539935286,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 327734,
      "h": 21475164214,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 21475164214, 43044503553),
//--TRIMMABLE-BOUNDARY-START(ALL, 25770131510, 47339470849),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129869878,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 327734,
      "h": 25770131510,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 25770131510, 47339470849),
//--TRIMMABLE-BOUNDARY-START(ALL, 30065098806, 55929405441),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719804470,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 327734,
      "h": 30065098806,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 30065098806, 55929405441),
//--TRIMMABLE-BOUNDARY-START(ALL, 90194640950, 223433129985),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309739062,
        "f": 50364417
      },
      "n": "Length",
      "d": 327734,
      "h": 90194640950,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 90194640950, 223433129985),
//--TRIMMABLE-BOUNDARY-START(ALL, 94489608246, 240612999169),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899673654,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 120259412022,
        "f": 83918849
      },
      "n": "Position",
      "d": 327734,
      "h": 94489608246,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 94489608246, 240612999169)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(34360066102),
    {
      "r": 65537,
      "p": [
        {
          "n": "read",
          "p": 655361
        }
      ],
      "n": "CheckLengthLimit",
      "d": 327734,
      "h": 34360066102,
      "f": 16777218
    },
//--TRIMMABLE-BOUNDARY-END(34360066102),
//--TRIMMABLE-BOUNDARY-START(128849346614),
    {
      "r": 65537,
      "p": [
        {
          "n": "limit",
          "p": 655361
        }
      ],
      "n": "ThrowExceededBufferLimit",
      "d": 327734,
      "h": 128849346614,
      "f": 16777256
    },
//--TRIMMABLE-BOUNDARY-END(128849346614),
//--TRIMMABLE-BOUNDARY-START(ALL, 103079542838, 257792868353),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "ReadAsync",
      "d": 327734,
      "h": 103079542838,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 103079542838, 257792868353),
//--TRIMMABLE-BOUNDARY-START(ALL, 107374510134, 262087835649),
    {
      "r": $.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.System.Memory$$($.$$.System.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 169934849,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 327734,
      "h": 107374510134,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 107374510134, 262087835649),
//--TRIMMABLE-BOUNDARY-START(ALL, 98784575542, 244907966465),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 327734,
      "h": 98784575542,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 98784575542, 244907966465),
//--TRIMMABLE-BOUNDARY-START(ALL, 38655033398, 128943849473),
    {
      "r": 65537,
      "n": "Flush",
      "d": 327734,
      "h": 38655033398,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 38655033398, 128943849473),
//--TRIMMABLE-BOUNDARY-START(ALL, 42950000694, 137533784065),
    {
      "r": 177537025,
      "p": [
        {
          "n": "cancellationToken",
          "p": 169934849
        }
      ],
      "n": "FlushAsync",
      "o": "@$1",
      "d": 327734,
      "h": 42950000694,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 42950000694, 137533784065),
//--TRIMMABLE-BOUNDARY-START(ALL, 111669477430, 326512345089),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 94371841
        }
      ],
      "n": "Seek",
      "d": 327734,
      "h": 111669477430,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 111669477430, 326512345089),
//--TRIMMABLE-BOUNDARY-START(ALL, 124554379318, 356577116161),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 327734,
      "h": 124554379318,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 124554379318, 356577116161),
//--TRIMMABLE-BOUNDARY-START(ALL, 133144313910, 382346919937),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.System.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 327734,
      "h": 133144313910,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(ALL, 133144313910, 382346919937)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295295030),
    {
      "t": 94830593,
      "n": "_innerStream",
      "d": 327734,
      "h": 4295295030,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295295030),
//--TRIMMABLE-BOUNDARY-START(8590262326),
    {
      "t": 655361,
      "n": "_lengthLimit",
      "d": 327734,
      "h": 8590262326,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590262326),
//--TRIMMABLE-BOUNDARY-START(12885229622),
    {
      "t": 655361,
      "n": "_remainingLength",
      "d": 327734,
      "h": 12885229622,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(12885229622)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180196918),
    {
      "p": [
        {
          "n": "innerStream",
          "p": 94830593
        },
        {
          "n": "lengthLimit",
          "p": 655361
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327734,
      "h": 17180196918,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180196918)
  ],
  "i": [90177537,89587713
  ],
  "h": 327734
}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Http.Json.LengthLimitReadStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327734)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.IO.Pipelines", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Reflection.Emit", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encodings.Web", "NetJs.System.Text.RegularExpressions", "NetJs.System.Text.Json"))
//--TRIMMABLE-BOUNDARY-END(54)
