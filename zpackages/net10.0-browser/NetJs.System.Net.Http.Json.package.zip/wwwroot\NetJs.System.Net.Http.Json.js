
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $srei, $srel, $srp, $sri, $srl, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $sipl, $srn, $ssc, $stew, $sris, $stc, $scsl, $sfa, $sic, $sim, $sl, $snp, $sspw, $srij, $sicb, $sci, $sdd, $srm, $snnr, $sds, $sre, $sns, $sscr, $str, $snn, $snsc, $stj, $snq, $snh) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Http.Json", 
    {"h":43752,"f":"System.Net.Http.Json","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Http.Json","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Http.Json","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snhj.System.Net.Http.Json.HttpClientJsonExtensions", ($self) => class HttpClientJsonExtensions
        {
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsAsyncEnumerable$1(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), options, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable$1(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonStreamAsyncCore(TValue, client, requestUri, options, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable$2(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsAsyncEnumerable$3(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), jsonTypeInfo, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable$3(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonStreamAsyncCore$1(TValue, client, requestUri, jsonTypeInfo, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable$4(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsAsyncEnumerable(TValue, client, requestUri, null, new $.$spc.System.Threading.CancellationToken());
            }
            static /*IAsyncEnumerable<TValue?> */ GetFromJsonAsAsyncEnumerable$5(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsAsyncEnumerable$1(TValue, client, requestUri, null, new $.$spc.System.Threading.CancellationToken());
            }
            static /*IAsyncEnumerable<TValue?> */ FromJsonStreamAsyncCore(TValue, /*HttpClient*/ client, /*Uri?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                /*var*/ let jsonTypeInfo = $.$cast($.$snhj.System.Net.Http.Json.JsonHelpers.GetJsonTypeInfo(TValue.$type, options), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue));
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonStreamAsyncCore$1(TValue, client, requestUri, jsonTypeInfo, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ FromJsonStreamAsyncCore$1(TValue, /*HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(client, "client");
                return Core(client, requestUri, jsonTypeInfo, cancellationToken);
                /*static IAsyncEnumerable<TValue?>*/ /*async*/  function Core(/*HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
                {
                    return new ($.$spc.NetJs.YieldToIterator$$(TValue))().$ctor$1(async function*()
                    {
                        /*HttpResponseMessage*/ let response = await client.GetAsync$7(requestUri, 1/*HttpCompletionOption.ResponseHeadersRead*/, cancellationToken).ConfigureAwait$2(false);
                        try
                        {
                            response.EnsureSuccessStatusCode();
                            /*Stream*/ let readStream = await $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetHttpResponseStreamAsync(client, response, false, cancellationToken).ConfigureAwait(false);
                            try
                            {
                                var $en6 = $.$spc.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait$1(TValue, $.$stj.System.Text.Json.JsonSerializer.DeserializeAsyncEnumerable$6(TValue, readStream, jsonTypeInfo, cancellationToken), false).GetAsyncEnumerator();
                                while (await $en6.MoveNextAsync())
                                {
                                    var value = $en6.Current;
                                    {
                                        yield value;
                                    }
                                }
                            }
                            finally
                            {
                                readStream?.System$IDisposable$Dispose();
                            }
                        }
                        finally
                        {
                            response?.System$IDisposable$Dispose();
                        }
                    }.bind(this));
                }
            }
            static /*Task<object?> */ FromJsonAsyncCore(/*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ getMethod, /*HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$4($.$spc.System.Object, $.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$stj.System.Text.Json.JsonSerializerOptions), getMethod, client, requestUri, new ($.$spc.System.Func$$$$$($.$spc.System.IO.Stream, $.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$stj.System.Text.Json.JsonSerializerOptions), $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Object)))().$ctor(null, /*static*/ (/*stream*/ stream, /*options*/ options, /*cancellation*/ cancellation) =>
                {
                    return $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$6(stream, options.Item1, options.Item2 ?? $.$stj.System.Text.Json.JsonSerializerOptions.Web, cancellation);
                }), new ($.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$stj.System.Text.Json.JsonSerializerOptions))().$ctor$2(type, options), cancellationToken);
            }
            static /*Task<TValue?> */ FromJsonAsyncCore$1(TValue, /*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ getMethod, /*HttpClient*/ client, /*Uri?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$4(TValue, $.$stj.System.Text.Json.JsonSerializerOptions, getMethod, client, requestUri, new ($.$spc.System.Func$$$$$($.$spc.System.IO.Stream, $.$stj.System.Text.Json.JsonSerializerOptions, $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$(TValue)))().$ctor(null, /*static*/ (/*stream*/ stream, /**/ options, /*cancellation*/ cancellation) =>
                {
                    return $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$5(TValue, stream, options ?? $.$stj.System.Text.Json.JsonSerializerOptions.Web, cancellation);
                }), options, cancellationToken);
            }
            static /*Task<object?> */ FromJsonAsyncCore$2(/*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ getMethod, /*HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$4($.$spc.System.Object, $.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$stj.System.Text.Json.Serialization.JsonSerializerContext), getMethod, client, requestUri, new ($.$spc.System.Func$$$$$($.$spc.System.IO.Stream, $.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$stj.System.Text.Json.Serialization.JsonSerializerContext), $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Object)))().$ctor(null, /*static*/ (/*stream*/ stream, /*options*/ options, /*cancellation*/ cancellation) =>
                {
                    return $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$9(stream, options.Item1, options.Item2, cancellation);
                }), new ($.$spc.System.ValueTuple$$$($.$spc.System.Type, $.$stj.System.Text.Json.Serialization.JsonSerializerContext))().$ctor$2(type, context), cancellationToken);
            }
            static /*Task<TValue?> */ FromJsonAsyncCore$3(TValue, /*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ getMethod, /*HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$4(TValue, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue), getMethod, client, requestUri, new ($.$spc.System.Func$$$$$($.$spc.System.IO.Stream, $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue), $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$(TValue)))().$ctor(null, /*static*/ (/*stream*/ stream, /*options*/ options, /*cancellation*/ cancellation) =>
                {
                    return $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$7(TValue, stream, options, cancellation);
                }), jsonTypeInfo, cancellationToken);
            }
            static /*Task<TValue?> */ FromJsonAsyncCore$4(TValue, TJsonOptions, /*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ getMethod, /*HttpClient*/ client, /*Uri?*/ requestUri, /*Func<Stream, TJsonOptions, CancellationToken, ValueTask<TValue?>>*/ deserializeMethod, /*TJsonOptions*/ jsonOptions, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(client, "client");
                /*TimeSpan*/ let timeout = client.Timeout;
                /*CancellationTokenSource?*/ let linkedCTS = null;
                if ($.$spc.System.TimeSpan.op_Inequality(timeout, $.$spc.System.Threading.Timeout.InfiniteTimeSpan))
                {
                    linkedCTS = $.$spc.System.Threading.CancellationTokenSource.CreateLinkedTokenSource$1(cancellationToken);
                    linkedCTS.CancelAfter(timeout);
                }
                /*Task<HttpResponseMessage>*/ let responseTask;
                try
                {
                    responseTask = getMethod.Invoke(client, requestUri, cancellationToken);
                }
                catch($e)
                {
                    linkedCTS?.Dispose();
                    throw $e;
                }
                /*bool*/ let usingResponseHeadersRead = !$.$spc.System.Object.ReferenceEquals(getMethod, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_deleteAsync);
                return Core(client, responseTask, usingResponseHeadersRead, linkedCTS, deserializeMethod, jsonOptions, cancellationToken);
                /*static Task<TValue?>*/ /*async*/  function Core(/*HttpClient*/ client, /*Task<HttpResponseMessage>*/ responseTask, /*bool*/ usingResponseHeadersRead, /*CancellationTokenSource?*/ linkedCTS, /*Func<Stream, TJsonOptions, CancellationToken, ValueTask<TValue?>>*/ deserializeMethod, /*TJsonOptions*/ jsonOptions, /*CancellationToken*/ cancellationToken)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$(TValue), TValue, async () => 
                    {
                        try
                        {
                            /*HttpResponseMessage*/ let response = await responseTask.ConfigureAwait$2(false);
                            try
                            {
                                response.EnsureSuccessStatusCode();
                                try
                                {
                                    /*Stream*/ let readStream = await $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetHttpResponseStreamAsync(client, response, usingResponseHeadersRead, cancellationToken).ConfigureAwait(false);
                                    try
                                    {
                                        return await deserializeMethod.Invoke(readStream, jsonOptions, (linkedCTS?.Token ?? null) ?? cancellationToken).ConfigureAwait(false);
                                    }
                                    finally
                                    {
                                        readStream?.System$IDisposable$Dispose();
                                    }
                                }
                                catch(oce)
                                {
                                    /*string*/ let message = $.$snhj.System.SR.Format($.$snhj.System.SR.net_http_request_timedout, $.$box(client.Timeout.TotalSeconds, $.$spc.System.Double));
                                    throw new $.$spc.System.Threading.Tasks.TaskCanceledException().$ctor$19(message, new $.$spc.System.TimeoutException().$ctor$11(oce.Message, oce), oce.CancellationToken);
                                }
                            }
                            finally
                            {
                                response?.System$IDisposable$Dispose();
                            }
                        }
                        finally
                        {
                            {
                                linkedCTS?.Dispose();
                            }
                        }
                    });
                }
            }
            static /*Uri? */ CreateUri(/*string?*/ uri)
            {
                return $.$spc.System.String.IsNullOrEmpty(uri) ? null : new $.$spu.System.Uri().$ctor$4(uri, 0/*UriKind.RelativeOrAbsolute*/);
            }
            static /*ValueTask<Stream> */ GetHttpResponseStreamAsync(/*HttpClient*/ client, /*HttpResponseMessage*/ response, /*bool*/ usingResponseHeadersRead, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((client.MaxResponseContentBufferSize > 0n) && (client.MaxResponseContentBufferSize <= BigInt(2147483647/*int.MaxValue*/)), "client.MaxResponseContentBufferSize is > 0 and <= int.MaxValue");
                /*int*/ let contentLengthLimit = $.$cast(client.MaxResponseContentBufferSize, $.$spc.System.Int32);
                let contentLength;
                if ($.$is(response.Content.Headers.ContentLength, $.$spc.System.Int64, { set $v(v){ contentLength = v; } }) && contentLength > BigInt(contentLengthLimit))
                {
                    $.$snhj.System.Net.Http.Json.LengthLimitReadStream.ThrowExceededBufferLimit(contentLengthLimit);
                }
                /*ValueTask<Stream>*/ let task = $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(response.Content, cancellationToken);
                return usingResponseHeadersRead ? $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetLengthLimitReadStreamAsync(client, task) : task;
            }
            static /*ValueTask<Stream> *//*async*/  GetLengthLimitReadStreamAsync(/*HttpClient*/ client, /*ValueTask<Stream>*/ task)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.IO.Stream), $.$spc.System.IO.Stream, async () => 
                {
                    /*Stream*/ let contentStream = await task.ConfigureAwait(false);
                    return new $.$snhj.System.Net.Http.Json.LengthLimitReadStream().$ctor$3(contentStream, $.$cast(client.MaxResponseContentBufferSize, $.$spc.System.Int32));
                });
            }
            /*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ static s_deleteAsync = null;
            static /*Task<object?> */ DeleteFromJsonAsync(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$1(client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), type, options, cancellationToken);
            }
            static /*Task<object?> */ DeleteFromJsonAsync$1(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_deleteAsync, client, requestUri, type, options, cancellationToken);
            }
            static /*Task<TValue?> */ DeleteFromJsonAsync$2(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$3(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), options, cancellationToken);
            }
            static /*Task<TValue?> */ DeleteFromJsonAsync$3(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$1(TValue, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_deleteAsync, client, requestUri, options, cancellationToken);
            }
            static /*Task<object?> */ DeleteFromJsonAsync$4(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$5(client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), type, context, cancellationToken);
            }
            static /*Task<object?> */ DeleteFromJsonAsync$5(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$2($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_deleteAsync, client, requestUri, type, context, cancellationToken);
            }
            static /*Task<TValue?> */ DeleteFromJsonAsync$6(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$7(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), jsonTypeInfo, cancellationToken);
            }
            static /*Task<TValue?> */ DeleteFromJsonAsync$7(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$3(TValue, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_deleteAsync, client, requestUri, jsonTypeInfo, cancellationToken);
            }
            static /*Task<object?> */ DeleteFromJsonAsync$8(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync(client, requestUri, type, null, new $.$spc.System.Threading.CancellationToken());
            }
            static /*Task<object?> */ DeleteFromJsonAsync$9(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$1(client, requestUri, type, null, new $.$spc.System.Threading.CancellationToken());
            }
            static /*Task<TValue?> */ DeleteFromJsonAsync$10(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$2(TValue, client, requestUri, null, new $.$spc.System.Threading.CancellationToken());
            }
            static /*Task<TValue?> */ DeleteFromJsonAsync$11(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.DeleteFromJsonAsync$3(TValue, client, requestUri, null, new $.$spc.System.Threading.CancellationToken());
            }
            /*Func<HttpClient, Uri?, CancellationToken, Task<HttpResponseMessage>>*/ static s_getAsync = null;
            static /*Task<object?> */ GetFromJsonAsync(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$1(client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), type, options, cancellationToken);
            }
            static /*Task<object?> */ GetFromJsonAsync$1(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore(new ($.$spc.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)))().$ctor(null, /*static*/ (/*client*/ client, /*uri*/ uri, /*cancellation*/ cancellation) =>
                {
                    return client.GetAsync$7(uri, 1/*HttpCompletionOption.ResponseHeadersRead*/, cancellation);
                }), client, requestUri, type, options, cancellationToken);
            }
            static /*Task<TValue?> */ GetFromJsonAsync$2(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$3(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), options, cancellationToken);
            }
            static /*Task<TValue?> */ GetFromJsonAsync$3(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$1(TValue, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_getAsync, client, requestUri, options, cancellationToken);
            }
            static /*Task<object?> */ GetFromJsonAsync$4(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$5(client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), type, context, cancellationToken);
            }
            static /*Task<object?> */ GetFromJsonAsync$5(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$2($.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_getAsync, client, requestUri, type, context, cancellationToken);
            }
            static /*Task<TValue?> */ GetFromJsonAsync$6(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$7(TValue, client, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.CreateUri(requestUri), jsonTypeInfo, cancellationToken);
            }
            static /*Task<TValue?> */ GetFromJsonAsync$7(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.FromJsonAsyncCore$3(TValue, $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.s_getAsync, client, requestUri, jsonTypeInfo, cancellationToken);
            }
            static /*Task<object?> */ GetFromJsonAsync$8(/*this HttpClient*/ client, /*string?*/ requestUri, /*Type*/ type, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync(client, requestUri, type, null, new $.$spc.System.Threading.CancellationToken());
            }
            static /*Task<object?> */ GetFromJsonAsync$9(/*this HttpClient*/ client, /*Uri?*/ requestUri, /*Type*/ type, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$1(client, requestUri, type, null, new $.$spc.System.Threading.CancellationToken());
            }
            static /*Task<TValue?> */ GetFromJsonAsync$10(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$2(TValue, client, requestUri, null, new $.$spc.System.Threading.CancellationToken());
            }
            static /*Task<TValue?> */ GetFromJsonAsync$11(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.GetFromJsonAsync$3(TValue, client, requestUri, null, new $.$spc.System.Threading.CancellationToken());
            }
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create(TValue, value, null, null);
                return client.PostAsync$2(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync$1(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create(TValue, value, null, null);
                return client.PostAsync$3(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync$2(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PostAsJsonAsync(TValue, client, requestUri, value, null, new $.$spc.System.Threading.CancellationToken());
            }
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync$3(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PostAsJsonAsync$1(TValue, client, requestUri, value, null, new $.$spc.System.Threading.CancellationToken());
            }
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync$4(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, jsonTypeInfo, null);
                return client.PostAsync$2(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PostAsJsonAsync$5(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, jsonTypeInfo, null);
                return client.PostAsync$3(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create(TValue, value, null, null);
                return client.PutAsync$2(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync$1(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create(TValue, value, null, null);
                return client.PutAsync$3(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync$2(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PutAsJsonAsync(TValue, client, requestUri, value, null, new $.$spc.System.Threading.CancellationToken());
            }
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync$3(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PutAsJsonAsync$1(TValue, client, requestUri, value, null, new $.$spc.System.Threading.CancellationToken());
            }
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync$4(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, jsonTypeInfo, null);
                return client.PutAsync$2(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PutAsJsonAsync$5(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, jsonTypeInfo, null);
                return client.PutAsync$3(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create(TValue, value, null, null);
                return client.PatchAsync$2(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync$1(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create(TValue, value, null, null);
                return client.PatchAsync$3(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync$2(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PatchAsJsonAsync(TValue, client, requestUri, value, null, new $.$spc.System.Threading.CancellationToken());
            }
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync$3(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpClientJsonExtensions.PatchAsJsonAsync$1(TValue, client, requestUri, value, null, new $.$spc.System.Threading.CancellationToken());
            }
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync$4(TValue, /*this HttpClient*/ client, /*string?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, jsonTypeInfo, null);
                return client.PatchAsync$2(requestUri, content, cancellationToken);
            }
            static /*Task<HttpResponseMessage> */ PatchAsJsonAsync$5(TValue, /*this HttpClient*/ client, /*Uri?*/ requestUri, /*TValue*/ value, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(client, "client");
                /*JsonContent*/ let content = $.$snhj.System.Net.Http.Json.JsonContent.Create$2(TValue, value, jsonTypeInfo, null);
                return client.PatchAsync$3(requestUri, content, cancellationToken);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_deleteAsync = new ($.$spc.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)))().$ctor(null, /*static*/ (/*client*/ client, /*uri*/ uri, /*cancellation*/ cancellation) =>
                    {
                        return client.DeleteAsync$3(uri, cancellation);
                    });
                }
                {
                    this.s_getAsync = new ($.$spc.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)))().$ctor(null, /*static*/ (/*client*/ client, /*uri*/ uri, /*cancellation*/ cancellation) =>
                    {
                        return client.GetAsync$7(uri, 1/*HttpCompletionOption.ResponseHeadersRead*/, cancellation);
                    });
                }
            }
            static $h = 109288;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":(TValue) => $.$spc.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"GetFromJsonAsAsyncEnumerable","d":109288,"h":4295076584,"f":131105},{"r":(TValue) => $.$spc.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"GetFromJsonAsAsyncEnumerable","o":"@$1","d":109288,"h":8590043880,"f":131105},{"r":(TValue) => $.$spc.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"GetFromJsonAsAsyncEnumerable","o":"@$2","d":109288,"h":12885011176,"f":131105},{"r":(TValue) => $.$spc.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"GetFromJsonAsAsyncEnumerable","o":"@$3","d":109288,"h":17179978472,"f":131105},{"r":(TValue) => $.$spc.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"GetFromJsonAsAsyncEnumerable","o":"@$4","d":109288,"h":21474945768,"f":131105},{"r":(TValue) => $.$spc.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"GetFromJsonAsAsyncEnumerable","o":"@$5","d":109288,"h":25769913064,"f":131105},{"r":(TValue) => $.$spc.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"FromJsonStreamAsyncCore","d":109288,"h":30064880360,"f":131106},{"r":(TValue) => $.$spc.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"FromJsonStreamAsyncCore","o":"@$1","d":109288,"h":34359847656,"f":131106},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"getMethod","p":$.$spc.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h},{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"type","p":142606337},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193,"f":65}],"n":"FromJsonAsyncCore","d":109288,"h":38654814952,"f":34},{"r":(TValue) => $.$spc.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"getMethod","p":$.$spc.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h},{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"FromJsonAsyncCore","o":"@$1","d":109288,"h":42949782248,"f":131106},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"getMethod","p":$.$spc.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h},{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"type","p":142606337},{"n":"context","p":14792862},{"n":"cancellationToken","p":125960193,"f":65}],"n":"FromJsonAsyncCore","o":"@$2","d":109288,"h":47244749544,"f":34},{"r":(TValue) => $.$spc.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"getMethod","p":$.$spc.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h},{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"FromJsonAsyncCore","o":"@$3","d":109288,"h":51539716840,"f":131106},{"r":(TValue, TJsonOptions) => $.$spc.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"getMethod","p":$.$spc.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h},{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"deserializeMethod","p":(TValue, TJsonOptions) => $.$spc.System.Func$$$$$($.$spc.System.IO.Stream, TJsonOptions, $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$(TValue)).$h},{"n":"jsonOptions","p":51543277568},{"n":"cancellationToken","p":125960193}],"g":["TValue","TJsonOptions"],"n":"FromJsonAsyncCore","o":"@$4","d":109288,"h":55834684136,"f":131106},{"r":1767739,"p":[{"n":"uri","p":1310721}],"n":"CreateUri","d":109288,"h":60129651432,"f":34},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.IO.Stream).$h,"p":[{"n":"client","p":6422573},{"n":"response","p":7733293},{"n":"usingResponseHeadersRead","p":262145},{"n":"cancellationToken","p":125960193}],"n":"GetHttpResponseStreamAsync","d":109288,"h":64424618728,"f":34},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.IO.Stream).$h,"p":[{"n":"client","p":6422573},{"n":"task","p":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.IO.Stream).$h}],"n":"GetLengthLimitReadStreamAsync","d":109288,"h":68719586024,"f":4130},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"type","p":142606337},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193,"f":65}],"n":"DeleteFromJsonAsync","d":109288,"h":77309520616,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"type","p":142606337},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193,"f":65}],"n":"DeleteFromJsonAsync","o":"@$1","d":109288,"h":81604487912,"f":33},{"r":(TValue) => $.$spc.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"DeleteFromJsonAsync","o":"@$2","d":109288,"h":85899455208,"f":131105},{"r":(TValue) => $.$spc.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"DeleteFromJsonAsync","o":"@$3","d":109288,"h":90194422504,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"type","p":142606337},{"n":"context","p":14792862},{"n":"cancellationToken","p":125960193,"f":65}],"n":"DeleteFromJsonAsync","o":"@$4","d":109288,"h":94489389800,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"type","p":142606337},{"n":"context","p":14792862},{"n":"cancellationToken","p":125960193,"f":65}],"n":"DeleteFromJsonAsync","o":"@$5","d":109288,"h":98784357096,"f":33},{"r":(TValue) => $.$spc.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"DeleteFromJsonAsync","o":"@$6","d":109288,"h":103079324392,"f":131105},{"r":(TValue) => $.$spc.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"DeleteFromJsonAsync","o":"@$7","d":109288,"h":107374291688,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"type","p":142606337},{"n":"cancellationToken","p":125960193,"f":65}],"n":"DeleteFromJsonAsync","o":"@$8","d":109288,"h":111669258984,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"type","p":142606337},{"n":"cancellationToken","p":125960193,"f":65}],"n":"DeleteFromJsonAsync","o":"@$9","d":109288,"h":115964226280,"f":33},{"r":(TValue) => $.$spc.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"DeleteFromJsonAsync","o":"@$10","d":109288,"h":120259193576,"f":131105},{"r":(TValue) => $.$spc.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"DeleteFromJsonAsync","o":"@$11","d":109288,"h":124554160872,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"type","p":142606337},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193,"f":65}],"n":"GetFromJsonAsync","d":109288,"h":133144095464,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"type","p":142606337},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193,"f":65}],"n":"GetFromJsonAsync","o":"@$1","d":109288,"h":137439062760,"f":33},{"r":(TValue) => $.$spc.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"GetFromJsonAsync","o":"@$2","d":109288,"h":141734030056,"f":131105},{"r":(TValue) => $.$spc.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"GetFromJsonAsync","o":"@$3","d":109288,"h":146028997352,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"type","p":142606337},{"n":"context","p":14792862},{"n":"cancellationToken","p":125960193,"f":65}],"n":"GetFromJsonAsync","o":"@$4","d":109288,"h":150323964648,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"type","p":142606337},{"n":"context","p":14792862},{"n":"cancellationToken","p":125960193,"f":65}],"n":"GetFromJsonAsync","o":"@$5","d":109288,"h":154618931944,"f":33},{"r":(TValue) => $.$spc.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"GetFromJsonAsync","o":"@$6","d":109288,"h":158913899240,"f":131105},{"r":(TValue) => $.$spc.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"GetFromJsonAsync","o":"@$7","d":109288,"h":163208866536,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"type","p":142606337},{"n":"cancellationToken","p":125960193,"f":65}],"n":"GetFromJsonAsync","o":"@$8","d":109288,"h":167503833832,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"type","p":142606337},{"n":"cancellationToken","p":125960193,"f":65}],"n":"GetFromJsonAsync","o":"@$9","d":109288,"h":171798801128,"f":33},{"r":(TValue) => $.$spc.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"GetFromJsonAsync","o":"@$10","d":109288,"h":176093768424,"f":131105},{"r":(TValue) => $.$spc.System.Threading.Tasks.Task$$(TValue).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"GetFromJsonAsync","o":"@$11","d":109288,"h":180388735720,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":180392230912},{"n":"options","p":3389598,"f":65},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"PostAsJsonAsync","d":109288,"h":184683703016,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"value","p":184687198208},{"n":"options","p":3389598,"f":65},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"PostAsJsonAsync","o":"@$1","d":109288,"h":188978670312,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":188982165504},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"PostAsJsonAsync","o":"@$2","d":109288,"h":193273637608,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"value","p":193277132800},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"PostAsJsonAsync","o":"@$3","d":109288,"h":197568604904,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":197572100096},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"PostAsJsonAsync","o":"@$4","d":109288,"h":201863572200,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"value","p":201867067392},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"PostAsJsonAsync","o":"@$5","d":109288,"h":206158539496,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":206162034688},{"n":"options","p":3389598,"f":65},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"PutAsJsonAsync","d":109288,"h":210453506792,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"value","p":210457001984},{"n":"options","p":3389598,"f":65},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"PutAsJsonAsync","o":"@$1","d":109288,"h":214748474088,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":214751969280},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"PutAsJsonAsync","o":"@$2","d":109288,"h":219043441384,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"value","p":219046936576},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"PutAsJsonAsync","o":"@$3","d":109288,"h":223338408680,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":223341903872},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"PutAsJsonAsync","o":"@$4","d":109288,"h":227633375976,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"value","p":227636871168},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"PutAsJsonAsync","o":"@$5","d":109288,"h":231928343272,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":231931838464},{"n":"options","p":3389598,"f":65},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"PatchAsJsonAsync","d":109288,"h":236223310568,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"value","p":236226805760},{"n":"options","p":3389598,"f":65},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"PatchAsJsonAsync","o":"@$1","d":109288,"h":240518277864,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":240521773056},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"PatchAsJsonAsync","o":"@$2","d":109288,"h":244813245160,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"value","p":244816740352},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"PatchAsJsonAsync","o":"@$3","d":109288,"h":249108212456,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1310721},{"n":"value","p":249111707648},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"PatchAsJsonAsync","o":"@$4","d":109288,"h":253403179752,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage).$h,"p":[{"n":"client","p":6422573},{"n":"requestUri","p":1767739},{"n":"value","p":253406674944},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"PatchAsJsonAsync","o":"@$5","d":109288,"h":257698147048,"f":131105}],"l":[{"t":$.$spc.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h,"n":"s_deleteAsync","d":109288,"h":73014553320,"f":34},{"t":$.$spc.System.Func$$$$$($.$snh.System.Net.Http.HttpClient, $.$spu.System.Uri, $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.Task$$($.$snh.System.Net.Http.HttpResponseMessage)).$h,"n":"s_getAsync","d":109288,"h":128849128168,"f":34}],"h":109288}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Http.Json.HttpClientJsonExtensions`; }
        });
        
        $asm.$cls("$snhj.System.Net.Http.Json.HttpContentJsonExtensions", ($self) => class HttpContentJsonExtensions
        {
            static /*IAsyncEnumerable<TValue?> */ ReadFromJsonAsAsyncEnumerable(TValue, /*this HttpContent*/ content, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsAsyncEnumerable$1(TValue, content, null, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ ReadFromJsonAsAsyncEnumerable$1(TValue, /*this HttpContent*/ content, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsAsyncEnumerableCore(TValue, content, options, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ ReadFromJsonAsAsyncEnumerable$2(TValue, /*this HttpContent*/ content, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsAsyncEnumerableCore$1(TValue, content, jsonTypeInfo, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> */ ReadFromJsonAsAsyncEnumerableCore(TValue, /*HttpContent*/ content, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                /*var*/ let jsonTypeInfo = $.$cast($.$snhj.System.Net.Http.Json.JsonHelpers.GetJsonTypeInfo(TValue.$type, options), $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue));
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsAsyncEnumerableCore$1(TValue, content, jsonTypeInfo, cancellationToken);
            }
            static /*IAsyncEnumerable<TValue?> *//*async*/  ReadFromJsonAsAsyncEnumerableCore$1(TValue, /*HttpContent*/ content, /*JsonTypeInfo<TValue>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return new ($.$spc.NetJs.YieldToIterator$$(TValue))().$ctor$1(async function*()
                {
                    /*Stream*/ let contentStream = await $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(content, cancellationToken).ConfigureAwait(false);
                    try
                    {
                        var $en4 = $.$spc.System.Threading.Tasks.TaskAsyncEnumerableExtensions.ConfigureAwait$1(TValue, $.$stj.System.Text.Json.JsonSerializer.DeserializeAsyncEnumerable$6(TValue, contentStream, jsonTypeInfo, cancellationToken), false).GetAsyncEnumerator();
                        while (await $en4.MoveNextAsync())
                        {
                            var value = $en4.Current;
                            {
                                yield value;
                            }
                        }
                    }
                    finally
                    {
                        contentStream?.System$IDisposable$Dispose();
                    }
                }.bind(this));
            }
            /*string*/ static SerializationUnreferencedCodeMessage = null;
            /*string*/ static SerializationDynamicCodeMessage = null;
            static /*Task<object?> */ ReadFromJsonAsync(/*this HttpContent*/ content, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsyncCore(content, type, options, cancellationToken);
            }
            static /*Task<object?> */ ReadFromJsonAsync$1(/*this HttpContent*/ content, /*Type*/ type, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsync(content, type, null, cancellationToken);
            }
            static /*Task<T?> */ ReadFromJsonAsync$2(T, /*this HttpContent*/ content, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsyncCore$1(T, content, options, cancellationToken);
            }
            static /*Task<T?> */ ReadFromJsonAsync$3(T, /*this HttpContent*/ content, /*CancellationToken*/ cancellationToken)
            {
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsync$2(T, content, null, cancellationToken);
            }
            static /*Task<object?> *//*async*/  ReadFromJsonAsyncCore(/*HttpContent*/ content, /*Type*/ type, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object), $.$spc.System.Object, async () => 
                {
                    let contentStream = null;
                    try
                    {
                        contentStream = await $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(content, cancellationToken).ConfigureAwait(false);
                        return await $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$6(contentStream, type, options ?? $.$stj.System.Text.Json.JsonSerializerOptions.Web, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        contentStream?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*Task<T?> *//*async*/  ReadFromJsonAsyncCore$1(T, /*HttpContent*/ content, /*JsonSerializerOptions?*/ options, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$(T), T, async () => 
                {
                    let contentStream = null;
                    try
                    {
                        contentStream = await $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(content, cancellationToken).ConfigureAwait(false);
                        return await $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$5(T, contentStream, options ?? $.$stj.System.Text.Json.JsonSerializerOptions.Web, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        contentStream?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*Task<object?> */ ReadFromJsonAsync$4(/*this HttpContent*/ content, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsyncCore$2(content, type, context, cancellationToken);
            }
            static /*Task<T?> */ ReadFromJsonAsync$5(T, /*this HttpContent*/ content, /*JsonTypeInfo<T>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(content, "content");
                return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadFromJsonAsyncCore$3(T, content, jsonTypeInfo, cancellationToken);
            }
            static /*Task<object?> *//*async*/  ReadFromJsonAsyncCore$2(/*HttpContent*/ content, /*Type*/ type, /*JsonSerializerContext*/ context, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object), $.$spc.System.Object, async () => 
                {
                    let contentStream = null;
                    try
                    {
                        contentStream = await $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(content, cancellationToken).ConfigureAwait(false);
                        return await $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$9(contentStream, type, context, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        contentStream?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*Task<T?> *//*async*/  ReadFromJsonAsyncCore$3(T, /*HttpContent*/ content, /*JsonTypeInfo<T>*/ jsonTypeInfo, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task$$(T), T, async () => 
                {
                    let contentStream = null;
                    try
                    {
                        contentStream = await $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetContentStreamAsync(content, cancellationToken).ConfigureAwait(false);
                        return await $.$stj.System.Text.Json.JsonSerializer.DeserializeAsync$7(T, contentStream, jsonTypeInfo, cancellationToken).ConfigureAwait(false);
                    }
                    finally
                    {
                        contentStream?.System$IDisposable$Dispose();
                    }
                });
            }
            static /*ValueTask<Stream> */ GetContentStreamAsync(/*HttpContent*/ content, /*CancellationToken*/ cancellationToken)
            {
                /*Task<Stream>*/ let task = $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.ReadHttpContentStreamAsync(content, cancellationToken);
                let sourceEncoding;
                return $.$is($.$snhj.System.Net.Http.Json.JsonHelpers.GetEncoding(content), $.$spc.System.Text.Encoding, { set $v(v){ sourceEncoding = v; } }) && sourceEncoding !== $.$spc.System.Text.Encoding.UTF8 ? $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetTranscodingStreamAsync(task, sourceEncoding) : new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.IO.Stream))().$ctor$3(task);
            }
            static /*ValueTask<Stream> *//*async*/  GetTranscodingStreamAsync(/*Task<Stream>*/ task, /*Encoding*/ sourceEncoding)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.IO.Stream), $.$spc.System.IO.Stream, async () => 
                {
                    /*Stream*/ let contentStream = await task.ConfigureAwait$2(false);
                    return $.$snhj.System.Net.Http.Json.HttpContentJsonExtensions.GetTranscodingStream(contentStream, sourceEncoding);
                });
            }
            static /*Task<Stream> */ ReadHttpContentStreamAsync(/*HttpContent*/ content, /*CancellationToken*/ cancellationToken)
            {
                return content.ReadAsStreamAsync$1(cancellationToken);
            }
            static /*Stream */ GetTranscodingStream(/*Stream*/ contentStream, /*Encoding*/ sourceEncoding)
            {
                return $.$spc.System.Text.Encoding.CreateTranscodingStream(contentStream, sourceEncoding, $.$spc.System.Text.Encoding.UTF8, false);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.SerializationUnreferencedCodeMessage = "JSON serialization and deserialization might require types that cannot be statically analyzed. Use the overload that takes a JsonTypeInfo or JsonSerializerContext, or make sure all of the required types are preserved.";
                }
                {
                    this.SerializationDynamicCodeMessage = "JSON serialization and deserialization might require types that cannot be statically analyzed. Use the overload that takes a JsonTypeInfo or JsonSerializerContext.";
                }
            }
            static $h = 174824;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":(TValue) => $.$spc.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"content","p":6619181},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"ReadFromJsonAsAsyncEnumerable","d":174824,"h":4295142120,"f":131105},{"r":(TValue) => $.$spc.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"content","p":6619181},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"ReadFromJsonAsAsyncEnumerable","o":"@$1","d":174824,"h":8590109416,"f":131105},{"r":(TValue) => $.$spc.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"content","p":6619181},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125960193,"f":65}],"g":["TValue"],"n":"ReadFromJsonAsAsyncEnumerable","o":"@$2","d":174824,"h":12885076712,"f":131105},{"r":(TValue) => $.$spc.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"content","p":6619181},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193}],"g":["TValue"],"n":"ReadFromJsonAsAsyncEnumerableCore","d":174824,"h":17180044008,"f":131106},{"r":(TValue) => $.$spc.System.Collections.Generic.IAsyncEnumerable$$(TValue).$h,"p":[{"n":"content","p":6619181},{"n":"jsonTypeInfo","p":(TValue) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(TValue).$h},{"n":"cancellationToken","p":125960193,"a":[{"t":90505217,"c":4385472513}]}],"g":["TValue"],"n":"ReadFromJsonAsAsyncEnumerableCore","o":"@$1","d":174824,"h":21475011304,"f":135202},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"content","p":6619181},{"n":"type","p":142606337},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadFromJsonAsync","d":174824,"h":34359913192,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"content","p":6619181},{"n":"type","p":142606337},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadFromJsonAsync","o":"@$1","d":174824,"h":38654880488,"f":33},{"r":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"content","p":6619181},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193,"f":65}],"g":["T"],"n":"ReadFromJsonAsync","o":"@$2","d":174824,"h":42949847784,"f":131105},{"r":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"content","p":6619181},{"n":"cancellationToken","p":125960193,"f":65}],"g":["T"],"n":"ReadFromJsonAsync","o":"@$3","d":174824,"h":47244815080,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"content","p":6619181},{"n":"type","p":142606337},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193}],"n":"ReadFromJsonAsyncCore","d":174824,"h":51539782376,"f":4130},{"r":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"content","p":6619181},{"n":"options","p":3389598},{"n":"cancellationToken","p":125960193}],"g":["T"],"n":"ReadFromJsonAsyncCore","o":"@$1","d":174824,"h":55834749672,"f":135202},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"content","p":6619181},{"n":"type","p":142606337},{"n":"context","p":14792862},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadFromJsonAsync","o":"@$4","d":174824,"h":60129716968,"f":33},{"r":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"content","p":6619181},{"n":"jsonTypeInfo","p":(T) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(T).$h},{"n":"cancellationToken","p":125960193,"f":65}],"g":["T"],"n":"ReadFromJsonAsync","o":"@$5","d":174824,"h":64424684264,"f":131105},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Object).$h,"p":[{"n":"content","p":6619181},{"n":"type","p":142606337},{"n":"context","p":14792862},{"n":"cancellationToken","p":125960193}],"n":"ReadFromJsonAsyncCore","o":"@$2","d":174824,"h":68719651560,"f":4130},{"r":(T) => $.$spc.System.Threading.Tasks.Task$$(T).$h,"p":[{"n":"content","p":6619181},{"n":"jsonTypeInfo","p":(T) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(T).$h},{"n":"cancellationToken","p":125960193}],"g":["T"],"n":"ReadFromJsonAsyncCore","o":"@$3","d":174824,"h":73014618856,"f":135202},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.IO.Stream).$h,"p":[{"n":"content","p":6619181},{"n":"cancellationToken","p":125960193}],"n":"GetContentStreamAsync","d":174824,"h":77309586152,"f":40},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.IO.Stream).$h,"p":[{"n":"task","p":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.IO.Stream).$h},{"n":"sourceEncoding","p":121831425}],"n":"GetTranscodingStreamAsync","d":174824,"h":81604553448,"f":4130},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.IO.Stream).$h,"p":[{"n":"content","p":6619181},{"n":"cancellationToken","p":125960193}],"n":"ReadHttpContentStreamAsync","d":174824,"h":85899520744,"f":34},{"r":62128129,"p":[{"n":"contentStream","p":62128129},{"n":"sourceEncoding","p":121831425}],"n":"GetTranscodingStream","d":174824,"h":90194488040,"f":34}],"l":[{"t":1310721,"n":"SerializationUnreferencedCodeMessage","d":174824,"h":25769978600,"f":40},{"t":1310721,"n":"SerializationDynamicCodeMessage","d":174824,"h":30064945896,"f":40}],"h":174824}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Http.Json.HttpContentJsonExtensions`; }
        });
        
        $asm.$cls("$snhj.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$snhj.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Net.Http.Json", $.$snhj.System.SR.$type.Assembly);
                    $.$snhj.System.SR.s_resourceManager = temp;
                }
                return $.$snhj.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$snhj.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$snhj.System.SR.resourceCulture = value;
            }
            static /*string */ get Argument_InvalidOffLen()
            {
                return "Offset and length were out of bounds for the array or count is greater than the number of elements from index to the end of the source collection.";
            }
            static /*string */ get CharSetInvalid()
            {
                return "The character set provided in ContentType is invalid.";
            }
            static /*string */ get CharSetNotSupported()
            {
                return "The character set provided in ContentType is not supported.";
            }
            static /*string */ get SerializeWrongType()
            {
                return "The specified type {0} must derive from the specific value's type {1}.";
            }
            static /*string */ FormatSerializeWrongType(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The specified type {0} must derive from the specific value's type {1}.", arg1, arg2);
            }
            static /*string */ get net_http_request_timedout()
            {
                return "The request was canceled due to the configured HttpClient.Timeout of {0} seconds elapsing.";
            }
            static /*string */ Formatnet_http_request_timedout(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The request was canceled due to the configured HttpClient.Timeout of {0} seconds elapsing.", arg1);
            }
            static /*string */ get net_http_content_buffersize_exceeded()
            {
                return "Cannot write more bytes to the buffer than the configured maximum buffer size: {0}.";
            }
            static /*string */ Formatnet_http_content_buffersize_exceeded(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Cannot write more bytes to the buffer than the configured maximum buffer size: {0}.", arg1);
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$snhj.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$snhj.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$snhj.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$snhj.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$snhj.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$snhj.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$snhj.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 436968;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":436968}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$snhj.System.Net.Http.Json.JsonHelpers", ($self) => class JsonHelpers
        {
            static /*JsonTypeInfo */ GetJsonTypeInfo(/*Type*/ type, /*JsonSerializerOptions?*/ options)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(!(type === null), "type is not null");
                options ??= $.$stj.System.Text.Json.JsonSerializerOptions.Web;
                options.MakeReadOnly$1(true);
                return options.GetTypeInfo(type);
            }
            /*string*/ static DefaultMediaType = null;
            static /*Encoding? */ GetEncoding(/*HttpContent*/ content)
            {
                /*Encoding?*/ let encoding = null;
                let charset;
                if ($.$is((content.Headers.ContentType?.CharSet ?? null), $.$spc.System.String, { set $v(v){ charset = v; } }))
                {
                    try
                    {
                        if (charset.length > 2 && $.$spc.System.String.get_Chars.call(charset, 0) === /*\"*/ 34 && $.$spc.System.String.get_Chars.call(charset, ((charset.length - 1) | 0)) === /*\"*/ 34)
                        {
                            encoding = $.$spc.System.Text.Encoding.GetEncoding$2($.$spc.System.String.Substring$1.call(charset, 1, ((charset.length - 2) | 0)));
                        }
                        else 
                        {
                            encoding = $.$spc.System.Text.Encoding.GetEncoding$2(charset);
                        }
                    }
                    catch(e)
                    {
                        throw new $.$spc.System.InvalidOperationException().$ctor$11($.$snhj.System.SR.CharSetInvalid, e);
                    }
                    $.$spc.System.Diagnostics.Debug.Assert$1(encoding !== null, "encoding != null");
                }
                return encoding;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.DefaultMediaType = "application/json; charset=utf-8";
                }
            }
            static $h = 305896;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":16824478,"p":[{"n":"type","p":142606337},{"n":"options","p":3389598}],"n":"GetJsonTypeInfo","d":305896,"h":4295273192,"f":40},{"r":121831425,"p":[{"n":"content","p":6619181}],"n":"GetEncoding","d":305896,"h":12885207784,"f":40}],"l":[{"t":1310721,"n":"DefaultMediaType","d":305896,"h":8590240488,"f":40}],"h":305896}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Http.Json.JsonHelpers`; }
        });
        
        $asm.$cls("$snhj.System.Net.Http.Json.JsonContent", ($self) => class JsonContent extends $.$snh.System.Net.Http.HttpContent
        {
            /*JsonTypeInfo*/ _typeInfo = null;
            /*Type */ get ObjectType()
            {
                return this._typeInfo.Type;
            }
            /*object?*/ Value = null;
            $ctor$2(/*object?*/ inputValue, /*JsonTypeInfo*/ jsonTypeInfo, /*MediaTypeHeaderValue?*/ mediaType)
            {
                super.$ctor$1();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(jsonTypeInfo === null), "jsonTypeInfo is not null");
                    $.$spc.System.Diagnostics.Debug.Assert$1(inputValue === null || jsonTypeInfo.Type.IsAssignableFrom($.$spc.System.Object.GetType.call(inputValue)), "inputValue is null || jsonTypeInfo.Type.IsAssignableFrom(inputValue.GetType())");
                    this.Value = inputValue;
                    this._typeInfo = jsonTypeInfo;
                    if (!(mediaType === null))
                    {
                        this.Headers.ContentType = mediaType;
                    }
                    else 
                    {
                        this.Headers.TryAddWithoutValidation("Content-Type", "application/json; charset=utf-8"/*JsonHelpers.DefaultMediaType*/);
                    }
                }
                return this;
            }
            static /*JsonContent */ Create(T, /*T*/ inputValue, /*MediaTypeHeaderValue?*/ mediaType, /*JsonSerializerOptions?*/ options)
            {
                return $.$snhj.System.Net.Http.Json.JsonContent.Create$3($.$box(inputValue, T), $.$snhj.System.Net.Http.Json.JsonHelpers.GetJsonTypeInfo(T.$type, options), mediaType);
            }
            static /*JsonContent */ Create$1(/*object?*/ inputValue, /*Type*/ inputType, /*MediaTypeHeaderValue?*/ mediaType, /*JsonSerializerOptions?*/ options)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(inputType, "inputType");
                $.$snhj.System.Net.Http.Json.JsonContent.EnsureTypeCompatibility(inputValue, inputType);
                return new $.$snhj.System.Net.Http.Json.JsonContent().$ctor$2(inputValue, $.$snhj.System.Net.Http.Json.JsonHelpers.GetJsonTypeInfo(inputType, options), mediaType);
            }
            static /*JsonContent */ Create$2(T, /*T?*/ inputValue, /*JsonTypeInfo<T>*/ jsonTypeInfo, /*MediaTypeHeaderValue?*/ mediaType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsonTypeInfo, "jsonTypeInfo");
                return new $.$snhj.System.Net.Http.Json.JsonContent().$ctor$2($.$box(inputValue, T), jsonTypeInfo, mediaType);
            }
            static /*JsonContent */ Create$3(/*object?*/ inputValue, /*JsonTypeInfo*/ jsonTypeInfo, /*MediaTypeHeaderValue?*/ mediaType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(jsonTypeInfo, "jsonTypeInfo");
                $.$snhj.System.Net.Http.Json.JsonContent.EnsureTypeCompatibility(inputValue, jsonTypeInfo.Type);
                return new $.$snhj.System.Net.Http.Json.JsonContent().$ctor$2(inputValue, jsonTypeInfo, mediaType);
            }
            /*Task */ SerializeToStreamAsync(/*Stream*/ stream, /*TransportContext?*/ context)
            {
                return this.SerializeToStreamAsyncCore(stream, $.$spc.System.Threading.CancellationToken.None);
            }
            /*bool */ TryComputeLength(/*out long*/ length)
            {
                length.$v = 0n;
                return false;
            }
            /*Task */ SerializeToStreamAsyncCore(/*Stream*/ targetStream, /*CancellationToken*/ cancellationToken)
            {
                /*Encoding?*/ let targetEncoding = $.$snhj.System.Net.Http.Json.JsonHelpers.GetEncoding(this);
                return targetEncoding !== null && targetEncoding !== $.$spc.System.Text.Encoding.UTF8 ? this.SerializeToStreamAsyncTranscoding(targetStream, true, targetEncoding, cancellationToken) : $.$stj.System.Text.Json.JsonSerializer.SerializeAsync$3(targetStream, this.Value, this._typeInfo, cancellationToken);
            }
            /*Task *//*async*/  SerializeToStreamAsyncTranscoding(/*Stream*/ targetStream, /*bool*/ $async, /*Encoding*/ targetEncoding, /*CancellationToken*/ cancellationToken)
            {
                return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.Task, $.$spc.System.Void, async () => 
                {
                    /*Stream*/ let transcodingStream = $.$spc.System.Text.Encoding.CreateTranscodingStream(targetStream, targetEncoding, $.$spc.System.Text.Encoding.UTF8, true);
                    try
                    {
                        if ($async)
                        {
                            await $.$stj.System.Text.Json.JsonSerializer.SerializeAsync$3(transcodingStream, this.Value, this._typeInfo, cancellationToken).ConfigureAwait(false);
                        }
                        else 
                        {
                            $.$stj.System.Text.Json.JsonSerializer.Serialize$3(transcodingStream, this.Value, this._typeInfo);
                        }
                    }
                    finally
                    {
                        {
                            if ($async)
                            {
                                await transcodingStream.DisposeAsync().ConfigureAwait(false);
                            }
                            else 
                            {
                                transcodingStream.Dispose();
                            }
                        }
                    }
                });
            }
            static /*void */ EnsureTypeCompatibility(/*object?*/ inputValue, /*Type*/ inputType)
            {
                if (!(inputValue === null) && !inputType.IsAssignableFrom($.$spc.System.Object.GetType.call(inputValue)))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$10($.$snhj.System.SR.Format$1($.$snhj.System.SR.SerializeWrongType, inputType, $.$spc.System.Object.GetType.call(inputValue)));
                }
            }
            /*void */ SerializeToStream(/*Stream*/ stream, /*TransportContext?*/ context, /*CancellationToken*/ cancellationToken)
            {
                let targetEncoding;
                if ($.$is($.$snhj.System.Net.Http.Json.JsonHelpers.GetEncoding(this), $.$spc.System.Text.Encoding, { set $v(v){ targetEncoding = v; } }) && targetEncoding !== $.$spc.System.Text.Encoding.UTF8)
                {
                    this.SerializeToStreamAsyncTranscoding(stream, false, targetEncoding, cancellationToken).GetAwaiter().GetResult();
                }
                else 
                {
                    $.$stj.System.Text.Json.JsonSerializer.Serialize$3(stream, this.Value, this._typeInfo);
                }
            }
            /*Task */ SerializeToStreamAsync$1(/*Stream*/ stream, /*TransportContext?*/ context, /*CancellationToken*/ cancellationToken)
            {
                return this.SerializeToStreamAsyncCore(stream, cancellationToken);
            }
            static $h = 240360;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":6619181,"p":[{"p":142606337,"g":{"r":0,"d":0,"h":12885142248,"f":1},"n":"ObjectType","d":240360,"h":8590174952,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":25770044136,"f":1},"n":"Value","d":240360,"h":21475076840,"f":1}],"m":[{"r":240360,"p":[{"n":"inputValue","p":30068375552},{"n":"mediaType","p":4784173,"f":65},{"n":"options","p":3389598,"f":65}],"g":["T"],"n":"Create","d":240360,"h":34359978728,"f":131105},{"r":240360,"p":[{"n":"inputValue","p":131073},{"n":"inputType","p":142606337},{"n":"mediaType","p":4784173,"f":65},{"n":"options","p":3389598,"f":65}],"n":"Create","o":"@$1","d":240360,"h":38654946024,"f":33},{"r":240360,"p":[{"n":"inputValue","p":38658310144},{"n":"jsonTypeInfo","p":(T) => $.$stj.System.Text.Json.Serialization.Metadata.JsonTypeInfo$$(T).$h},{"n":"mediaType","p":4784173,"f":65}],"g":["T"],"n":"Create","o":"@$2","d":240360,"h":42949913320,"f":131105},{"r":240360,"p":[{"n":"inputValue","p":131073},{"n":"jsonTypeInfo","p":16824478},{"n":"mediaType","p":4784173,"f":65}],"n":"Create","o":"@$3","d":240360,"h":47244880616,"f":33},{"r":133300225,"p":[{"n":"stream","p":62128129},{"n":"context","p":5019082}],"n":"SerializeToStreamAsync","d":240360,"h":51539847912,"f":32772},{"r":262145,"p":[{"n":"length","p":917505,"f":2}],"n":"TryComputeLength","d":240360,"h":55834815208,"f":32772},{"r":133300225,"p":[{"n":"targetStream","p":62128129},{"n":"cancellationToken","p":125960193}],"n":"SerializeToStreamAsyncCore","d":240360,"h":60129782504,"f":2},{"r":133300225,"p":[{"n":"targetStream","p":62128129},{"n":"async","p":262145},{"n":"targetEncoding","p":121831425},{"n":"cancellationToken","p":125960193}],"n":"SerializeToStreamAsyncTranscoding","d":240360,"h":64424749800,"f":4098},{"r":65537,"p":[{"n":"inputValue","p":131073},{"n":"inputType","p":142606337}],"n":"EnsureTypeCompatibility","d":240360,"h":68719717096,"f":34},{"r":65537,"p":[{"n":"stream","p":62128129},{"n":"context","p":5019082},{"n":"cancellationToken","p":125960193}],"n":"SerializeToStream","d":240360,"h":73014684392,"f":32772},{"r":133300225,"p":[{"n":"stream","p":62128129},{"n":"context","p":5019082},{"n":"cancellationToken","p":125960193}],"n":"SerializeToStreamAsync","o":"@$1","d":240360,"h":77309651688,"f":32772}],"l":[{"t":16824478,"n":"_typeInfo","d":240360,"h":4295207656,"f":2}],"c":[{"p":[{"n":"inputValue","p":131073},{"n":"jsonTypeInfo","p":16824478},{"n":"mediaType","p":4784173}],"n":".ctor","o":"$ctor$2","d":240360,"h":30065011432,"f":2}],"i":[57475073],"h":240360}; }
            static get $b() { return $.$snh.System.Net.Http.HttpContent; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Http.Json.JsonContent`; }
        });
        
        $asm.$cls("$snhj.System.Net.Http.Json.LengthLimitReadStream", ($self) => class LengthLimitReadStream extends $.$spc.System.IO.Stream
        {
            /*Stream*/ _innerStream = null;
            /*int*/ _lengthLimit = 0;
            /*int*/ _remainingLength = 0;
            $ctor$3(/*Stream*/ innerStream, /*int*/ lengthLimit)
            {
                super.$ctor$2();
                {
                    this._innerStream = innerStream;
                    this._lengthLimit = this._remainingLength = lengthLimit;
                }
                return this;
            }
            /*void */ CheckLengthLimit(/*int*/ read)
            {
                this._remainingLength -= read;
                if (this._remainingLength < 0)
                {
                    $.$snhj.System.Net.Http.Json.LengthLimitReadStream.ThrowExceededBufferLimit(this._lengthLimit);
                }
            }
            static /*void */ ThrowExceededBufferLimit(/*int*/ limit)
            {
                throw new $.$snh.System.Net.Http.HttpRequestException().$ctor$6($.$snhj.System.SR.Format($.$snhj.System.SR.net_http_content_buffersize_exceeded, $.$box(limit, $.$spc.System.Int32)));
            }
            /*bool */ get CanRead()
            {
                return this._innerStream.CanRead;
            }
            /*bool */ get CanSeek()
            {
                return this._innerStream.CanSeek;
            }
            /*bool */ get CanWrite()
            {
                return false;
            }
            /*Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*CancellationToken*/ cancellationToken)
            {
                return this.ReadAsync$2(new ($.$spc.System.Memory$$($.$spc.System.Byte))().$ctor$4(buffer, offset, count), cancellationToken).AsTask();
            }
            /*ValueTask<int> */ ReadAsync$2(/*Memory<byte>*/ buffer, /*CancellationToken*/ cancellationToken)
            {
                /*ValueTask<int>*/ let readTask = this._innerStream.ReadAsync$2(buffer, cancellationToken);
                if (buffer.IsEmpty)
                {
                    return readTask;
                }
                if (readTask.IsCompletedSuccessfully)
                {
                    /*int*/ let read = readTask.Result;
                    this.CheckLengthLimit(read);
                    return new ($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32))().$ctor$2(read);
                }
                return Core.call(this, readTask);
                /*ValueTask<int>*/ /*async*/  function Core(/*ValueTask<int>*/ readTask)
                {
                    return $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.Async($.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32), $.$spc.System.Int32, async () => 
                    {
                        /*int*/ let read = await readTask.ConfigureAwait(false);
                        this.CheckLengthLimit(read);
                        return read;
                    });
                }
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                /*int*/ let read = this._innerStream.Read(buffer, offset, count);
                this.CheckLengthLimit(read);
                return read;
            }
            /*void */ Flush()
            {
                return this._innerStream.Flush();
            }
            /*Task */ FlushAsync$1(/*CancellationToken*/ cancellationToken)
            {
                return this._innerStream.FlushAsync$1(cancellationToken);
            }
            /*long */ Seek(/*long*/ offset, /*SeekOrigin*/ origin)
            {
                return this._innerStream.Seek(offset, origin);
            }
            /*void */ SetLength(/*long*/ value)
            {
                return this._innerStream.SetLength(value);
            }
            /*long */ get Length()
            {
                return this._innerStream.Length;
            }
            /*long */ get Position()
            {
                return this._innerStream.Position;
            }
            /*long */ set Position(value)
            {
                this._innerStream.Position = value;
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$9();
            }
            static $h = 371432;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34360109800,"f":32769},"n":"CanRead","d":371432,"h":30065142504,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42950044392,"f":32769},"n":"CanSeek","d":371432,"h":38655077096,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":51539978984,"f":32769},"n":"CanWrite","d":371432,"h":47245011688,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":90194684648,"f":32769},"n":"Length","d":371432,"h":85899717352,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":98784619240,"f":32769},"s":{"r":0,"d":0,"h":103079586536,"f":32769},"n":"Position","d":371432,"h":94489651944,"f":32769}],"m":[{"r":65537,"p":[{"n":"read","p":655361}],"n":"CheckLengthLimit","d":371432,"h":21475207912,"f":2},{"r":65537,"p":[{"n":"limit","p":655361}],"n":"ThrowExceededBufferLimit","d":371432,"h":25770175208,"f":40},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":371432,"h":55834946280,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":371432,"h":60129913576,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":371432,"h":64424880872,"f":32769},{"r":65537,"n":"Flush","d":371432,"h":68719848168,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":371432,"h":73014815464,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":371432,"h":77309782760,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":371432,"h":81604750056,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":371432,"h":107374553832,"f":32769}],"l":[{"t":62128129,"n":"_innerStream","d":371432,"h":4295338728,"f":2},{"t":655361,"n":"_lengthLimit","d":371432,"h":8590306024,"f":2},{"t":655361,"n":"_remainingLength","d":371432,"h":12885273320,"f":2}],"c":[{"p":[{"n":"innerStream","p":62128129},{"n":"lengthLimit","p":655361}],"n":".ctor","o":"$ctor$3","d":371432,"h":17180240616,"f":1}],"i":[57475073,56885249],"h":371432}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Http.Json.LengthLimitReadStream`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Reflection.Emit.ILGeneration", "NetJs.System.Reflection.Emit.Lightweight", "NetJs.System.Reflection.Primitives", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Runtime.Loader", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.IO.Pipelines", "NetJs.System.Runtime.Numerics", "NetJs.System.Security.Claims", "NetJs.System.Text.Encodings.Web", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Channels", "NetJs.System.Console", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Net.NameResolution", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Reflection.Emit", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Text.RegularExpressions", "NetJs.System.Net.NetworkInformation", "NetJs.System.Net.Security", "NetJs.System.Text.Json", "NetJs.System.Net.Quic", "NetJs.System.Net.Http"))