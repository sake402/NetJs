
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $snv, $sris, $sri, $sl, $stt, $sttp, $sdd, $snp, $ssc, $sspw, $sto) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.NameResolution", 
    {"h":34197,"f":"System.Net.NameResolution","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.NameResolution","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.NameResolution","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snnr.System.Net.Dns", ($self) => class Dns
        {
            static /*System.IAsyncResult */ BeginGetHostAddresses(/*string*/ hostNameOrAddress, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.IAsyncResult */ BeginGetHostByName(/*string*/ hostName, /*System.AsyncCallback?*/ requestCallback, /*object?*/ stateObject)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.IAsyncResult */ BeginGetHostEntry$1(/*System.Net.IPAddress*/ address, /*System.AsyncCallback?*/ requestCallback, /*object?*/ stateObject)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.IAsyncResult */ BeginGetHostEntry(/*string*/ hostNameOrAddress, /*System.AsyncCallback?*/ requestCallback, /*object?*/ stateObject)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.IAsyncResult */ BeginResolve(/*string*/ hostName, /*System.AsyncCallback?*/ requestCallback, /*object?*/ stateObject)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPAddress[] */ EndGetHostAddresses(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ EndGetHostByName(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ EndGetHostEntry(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ EndResolve(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPAddress[] */ GetHostAddresses$1(/*string*/ hostNameOrAddress)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPAddress[] */ GetHostAddresses(/*string*/ hostNameOrAddress, /*System.Net.Sockets.AddressFamily*/ family)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPAddress[]> */ GetHostAddressesAsync$2(/*string*/ hostNameOrAddress)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPAddress[]> */ GetHostAddressesAsync$1(/*string*/ hostNameOrAddress, /*System.Net.Sockets.AddressFamily*/ family, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPAddress[]> */ GetHostAddressesAsync(/*string*/ hostNameOrAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostByAddress$1(/*System.Net.IPAddress*/ address)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostByAddress(/*string*/ address)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostByName(/*string*/ hostName)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostEntry$2(/*System.Net.IPAddress*/ address)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostEntry$1(/*string*/ hostNameOrAddress)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostEntry(/*string*/ hostNameOrAddress, /*System.Net.Sockets.AddressFamily*/ family)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPHostEntry> */ GetHostEntryAsync$3(/*System.Net.IPAddress*/ address)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPHostEntry> */ GetHostEntryAsync$2(/*string*/ hostNameOrAddress)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPHostEntry> */ GetHostEntryAsync$1(/*string*/ hostNameOrAddress, /*System.Net.Sockets.AddressFamily*/ family, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPHostEntry> */ GetHostEntryAsync(/*string*/ hostNameOrAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*string */ GetHostName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ Resolve(/*string*/ hostName)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 99733;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":57016321,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"requestCallback","p":14548993},{"n":"state","p":131073}],"n":"BeginGetHostAddresses","d":99733,"h":4295067029,"f":16777249},{"r":57016321,"p":[{"n":"hostName","p":1310721},{"n":"requestCallback","p":14548993},{"n":"stateObject","p":131073}],"n":"BeginGetHostByName","d":99733,"h":8590034325,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"BeginGetHostByName has been deprecated. Use BeginGetHostEntry instead.","t":1310721}]}]},{"r":57016321,"p":[{"n":"address","p":3064565},{"n":"requestCallback","p":14548993},{"n":"stateObject","p":131073}],"n":"BeginGetHostEntry","o":"@$1","d":99733,"h":12885001621,"f":16777249},{"r":57016321,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"requestCallback","p":14548993},{"n":"stateObject","p":131073}],"n":"BeginGetHostEntry","d":99733,"h":17179968917,"f":16777249},{"r":57016321,"p":[{"n":"hostName","p":1310721},{"n":"requestCallback","p":14548993},{"n":"stateObject","p":131073}],"n":"BeginResolve","d":99733,"h":21474936213,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"BeginResolve has been deprecated. Use BeginGetHostEntry instead.","t":1310721}]}]},{"r":$.$typeArray($.$snp.System.Net.IPAddress).$h,"p":[{"n":"asyncResult","p":57016321}],"n":"EndGetHostAddresses","d":99733,"h":25769903509,"f":16777249},{"r":165269,"p":[{"n":"asyncResult","p":57016321}],"n":"EndGetHostByName","d":99733,"h":30064870805,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EndGetHostByName has been deprecated. Use EndGetHostEntry instead.","t":1310721}]}]},{"r":165269,"p":[{"n":"asyncResult","p":57016321}],"n":"EndGetHostEntry","d":99733,"h":34359838101,"f":16777249},{"r":165269,"p":[{"n":"asyncResult","p":57016321}],"n":"EndResolve","d":99733,"h":38654805397,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EndResolve has been deprecated. Use EndGetHostEntry instead.","t":1310721}]}]},{"r":$.$typeArray($.$snp.System.Net.IPAddress).$h,"p":[{"n":"hostNameOrAddress","p":1310721}],"n":"GetHostAddresses","o":"@$1","d":99733,"h":42949772693,"f":16777249},{"r":$.$typeArray($.$snp.System.Net.IPAddress).$h,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"family","p":4506357}],"n":"GetHostAddresses","d":99733,"h":47244739989,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$typeArray($.$snp.System.Net.IPAddress)).$h,"p":[{"n":"hostNameOrAddress","p":1310721}],"n":"GetHostAddressesAsync","o":"@$2","d":99733,"h":51539707285,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$typeArray($.$snp.System.Net.IPAddress)).$h,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"family","p":4506357},{"n":"cancellationToken","p":125829121,"f":65}],"n":"GetHostAddressesAsync","o":"@$1","d":99733,"h":55834674581,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$typeArray($.$snp.System.Net.IPAddress)).$h,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"cancellationToken","p":125829121}],"n":"GetHostAddressesAsync","d":99733,"h":60129641877,"f":16777249},{"r":165269,"p":[{"n":"address","p":3064565}],"n":"GetHostByAddress","o":"@$1","d":99733,"h":64424609173,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"GetHostByAddress has been deprecated. Use GetHostEntry instead.","t":1310721}]}]},{"r":165269,"p":[{"n":"address","p":1310721}],"n":"GetHostByAddress","d":99733,"h":68719576469,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"GetHostByAddress has been deprecated. Use GetHostEntry instead.","t":1310721}]}]},{"r":165269,"p":[{"n":"hostName","p":1310721}],"n":"GetHostByName","d":99733,"h":73014543765,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"GetHostByName has been deprecated. Use GetHostEntry instead.","t":1310721}]}]},{"r":165269,"p":[{"n":"address","p":3064565}],"n":"GetHostEntry","o":"@$2","d":99733,"h":77309511061,"f":16777249},{"r":165269,"p":[{"n":"hostNameOrAddress","p":1310721}],"n":"GetHostEntry","o":"@$1","d":99733,"h":81604478357,"f":16777249},{"r":165269,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"family","p":4506357}],"n":"GetHostEntry","d":99733,"h":85899445653,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$snnr.System.Net.IPHostEntry).$h,"p":[{"n":"address","p":3064565}],"n":"GetHostEntryAsync","o":"@$3","d":99733,"h":90194412949,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$snnr.System.Net.IPHostEntry).$h,"p":[{"n":"hostNameOrAddress","p":1310721}],"n":"GetHostEntryAsync","o":"@$2","d":99733,"h":94489380245,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$snnr.System.Net.IPHostEntry).$h,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"family","p":4506357},{"n":"cancellationToken","p":125829121,"f":65}],"n":"GetHostEntryAsync","o":"@$1","d":99733,"h":98784347541,"f":16777249},{"r":$.$$.System.Threading.Tasks.Task$$($.$snnr.System.Net.IPHostEntry).$h,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"cancellationToken","p":125829121}],"n":"GetHostEntryAsync","d":99733,"h":103079314837,"f":16777249},{"r":1310721,"n":"GetHostName","d":99733,"h":107374282133,"f":16777249},{"r":165269,"p":[{"n":"hostName","p":1310721}],"n":"Resolve","d":99733,"h":111669249429,"f":16777249,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Resolve has been deprecated. Use GetHostEntry instead.","t":1310721}]}]}],"h":99733}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Dns`; }
        });
        
        $asm.$cls("$snnr.System.Net.IPHostEntry", ($self) => class IPHostEntry extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.IPAddress[] */ get AddressList()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress[] */ set AddressList(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ get Aliases()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ set Aliases(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get HostName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set HostName(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 165269;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$typeArray($.$snp.System.Net.IPAddress).$h,"g":{"r":0,"d":0,"h":12885067157,"f":50331649},"s":{"r":0,"d":0,"h":17180034453,"f":83886081},"n":"AddressList","d":165269,"h":8590099861,"f":2097153},{"p":$.$typeArray($.$$.System.String).$h,"g":{"r":0,"d":0,"h":25769969045,"f":50331649},"s":{"r":0,"d":0,"h":30064936341,"f":83886081},"n":"Aliases","d":165269,"h":21475001749,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":38654870933,"f":50331649},"s":{"r":0,"d":0,"h":42949838229,"f":83886081},"n":"HostName","d":165269,"h":34359903637,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":165269,"h":4295132565,"f":16777217}],"h":165269}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.IPHostEntry`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped"))