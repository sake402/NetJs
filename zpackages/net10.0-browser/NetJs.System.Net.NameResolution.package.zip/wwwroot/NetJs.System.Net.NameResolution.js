
//--TRIMMABLE-BOUNDARY-START(51)
(async function () {
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $snv, $sris, $sl, $stt, $sttp, $sdd, $snp, $ssc, $sspw, $sto) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.Net.NameResolution", 
    {
  "h": 51,
  "f": "System.Net.NameResolution",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Net.NameResolution",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Net.NameResolution",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65587)
        $asm.$cls(`$snnr.SN.Dns`, ($self) => class Dns
        {
            //--TRIMMABLE-BOUNDARY-START(4295032883)
            static /*System.IAsyncResult */ BeginGetHostAddresses(/*string*/ hostNameOrAddress, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(4295032883)
            
            //--TRIMMABLE-BOUNDARY-START(8590000179)
            static /*System.IAsyncResult */ BeginGetHostByName(/*string*/ hostName, /*System.AsyncCallback?*/ requestCallback, /*object?*/ stateObject)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590000179)
            
            //--TRIMMABLE-BOUNDARY-START(12884967475)
            static /*System.IAsyncResult */ BeginGetHostEntry(/*System.Net.IPAddress*/ address, /*System.AsyncCallback?*/ requestCallback, /*object?*/ stateObject)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12884967475)
            
            //--TRIMMABLE-BOUNDARY-START(17179934771)
            static /*System.IAsyncResult */ BeginGetHostEntry$1(/*string*/ hostNameOrAddress, /*System.AsyncCallback?*/ requestCallback, /*object?*/ stateObject)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17179934771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17179934771)
            
            //--TRIMMABLE-BOUNDARY-START(21474902067)
            static /*System.IAsyncResult */ BeginResolve(/*string*/ hostName, /*System.AsyncCallback?*/ requestCallback, /*object?*/ stateObject)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21474902067)
            
            //--TRIMMABLE-BOUNDARY-START(25769869363)
            static /*System.Net.IPAddress[] */ EndGetHostAddresses(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25769869363)
            
            //--TRIMMABLE-BOUNDARY-START(30064836659)
            static /*System.Net.IPHostEntry */ EndGetHostByName(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064836659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30064836659)
            
            //--TRIMMABLE-BOUNDARY-START(34359803955)
            static /*System.Net.IPHostEntry */ EndGetHostEntry(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359803955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34359803955)
            
            //--TRIMMABLE-BOUNDARY-START(38654771251)
            static /*System.Net.IPHostEntry */ EndResolve(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654771251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38654771251)
            
            //--TRIMMABLE-BOUNDARY-START(47244705843)
            static /*System.Net.IPAddress[] */ GetHostAddresses$1(/*string*/ hostNameOrAddress)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244705843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47244705843)
            
            //--TRIMMABLE-BOUNDARY-START(42949738547)
            static /*System.Net.IPAddress[] */ GetHostAddresses(/*string*/ hostNameOrAddress, /*System.Net.Sockets.AddressFamily*/ family)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949738547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42949738547)
            
            //--TRIMMABLE-BOUNDARY-START(60129607731)
            static /*System.Threading.Tasks.Task<System.Net.IPAddress[]> */ GetHostAddressesAsync$2(/*string*/ hostNameOrAddress)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129607731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60129607731)
            
            //--TRIMMABLE-BOUNDARY-START(51539673139)
            static /*System.Threading.Tasks.Task<System.Net.IPAddress[]> */ GetHostAddressesAsync(/*string*/ hostNameOrAddress, /*System.Net.Sockets.AddressFamily*/ family, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539673139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51539673139)
            
            //--TRIMMABLE-BOUNDARY-START(55834640435)
            static /*System.Threading.Tasks.Task<System.Net.IPAddress[]> */ GetHostAddressesAsync$1(/*string*/ hostNameOrAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834640435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55834640435)
            
            //--TRIMMABLE-BOUNDARY-START(64424575027)
            static /*System.Net.IPHostEntry */ GetHostByAddress(/*System.Net.IPAddress*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424575027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64424575027)
            
            //--TRIMMABLE-BOUNDARY-START(68719542323)
            static /*System.Net.IPHostEntry */ GetHostByAddress$1(/*string*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719542323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68719542323)
            
            //--TRIMMABLE-BOUNDARY-START(73014509619)
            static /*System.Net.IPHostEntry */ GetHostByName(/*string*/ hostName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014509619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73014509619)
            
            //--TRIMMABLE-BOUNDARY-START(77309476915)
            static /*System.Net.IPHostEntry */ GetHostEntry(/*System.Net.IPAddress*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309476915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77309476915)
            
            //--TRIMMABLE-BOUNDARY-START(85899411507)
            static /*System.Net.IPHostEntry */ GetHostEntry$2(/*string*/ hostNameOrAddress)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899411507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(85899411507)
            
            //--TRIMMABLE-BOUNDARY-START(81604444211)
            static /*System.Net.IPHostEntry */ GetHostEntry$1(/*string*/ hostNameOrAddress, /*System.Net.Sockets.AddressFamily*/ family)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604444211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81604444211)
            
            //--TRIMMABLE-BOUNDARY-START(90194378803)
            static /*System.Threading.Tasks.Task<System.Net.IPHostEntry> */ GetHostEntryAsync(/*System.Net.IPAddress*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194378803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90194378803)
            
            //--TRIMMABLE-BOUNDARY-START(103079280691)
            static /*System.Threading.Tasks.Task<System.Net.IPHostEntry> */ GetHostEntryAsync$3(/*string*/ hostNameOrAddress)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079280691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103079280691)
            
            //--TRIMMABLE-BOUNDARY-START(94489346099)
            static /*System.Threading.Tasks.Task<System.Net.IPHostEntry> */ GetHostEntryAsync$1(/*string*/ hostNameOrAddress, /*System.Net.Sockets.AddressFamily*/ family, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489346099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(94489346099)
            
            //--TRIMMABLE-BOUNDARY-START(98784313395)
            static /*System.Threading.Tasks.Task<System.Net.IPHostEntry> */ GetHostEntryAsync$2(/*string*/ hostNameOrAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784313395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(98784313395)
            
            //--TRIMMABLE-BOUNDARY-START(107374247987)
            static /*string */ GetHostName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374247987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(107374247987)
            
            //--TRIMMABLE-BOUNDARY-START(111669215283)
            static /*System.Net.IPHostEntry */ Resolve(/*string*/ hostName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669215283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(111669215283)
            
            static $h = 65587;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4295032883),
    {
      "r": 90570753,
      "p": [
        {
          "n": "hostNameOrAddress",
          "p": 1310721
        },
        {
          "n": "requestCallback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginGetHostAddresses",
      "d": 65587,
      "h": 4295032883,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(4295032883),
//--TRIMMABLE-BOUNDARY-START(8590000179),
    {
      "r": 90570753,
      "p": [
        {
          "n": "hostName",
          "p": 1310721
        },
        {
          "n": "requestCallback",
          "p": 46006273
        },
        {
          "n": "stateObject",
          "p": 131073
        }
      ],
      "n": "BeginGetHostByName",
      "d": 65587,
      "h": 8590000179,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "BeginGetHostByName has been deprecated. Use BeginGetHostEntry instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590000179),
//--TRIMMABLE-BOUNDARY-START(12884967475),
    {
      "r": 90570753,
      "p": [
        {
          "n": "address",
          "p": 3014703
        },
        {
          "n": "requestCallback",
          "p": 46006273
        },
        {
          "n": "stateObject",
          "p": 131073
        }
      ],
      "n": "BeginGetHostEntry",
      "d": 65587,
      "h": 12884967475,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12884967475),
//--TRIMMABLE-BOUNDARY-START(17179934771),
    {
      "r": 90570753,
      "p": [
        {
          "n": "hostNameOrAddress",
          "p": 1310721
        },
        {
          "n": "requestCallback",
          "p": 46006273
        },
        {
          "n": "stateObject",
          "p": 131073
        }
      ],
      "n": "BeginGetHostEntry",
      "o": "@$1",
      "d": 65587,
      "h": 17179934771,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17179934771),
//--TRIMMABLE-BOUNDARY-START(21474902067),
    {
      "r": 90570753,
      "p": [
        {
          "n": "hostName",
          "p": 1310721
        },
        {
          "n": "requestCallback",
          "p": 46006273
        },
        {
          "n": "stateObject",
          "p": 131073
        }
      ],
      "n": "BeginResolve",
      "d": 65587,
      "h": 21474902067,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "BeginResolve has been deprecated. Use BeginGetHostEntry instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21474902067),
//--TRIMMABLE-BOUNDARY-START(25769869363),
    {
      "r": $.$typeArray($.$snp.SN.IPAddress).$h,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndGetHostAddresses",
      "d": 65587,
      "h": 25769869363,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25769869363),
//--TRIMMABLE-BOUNDARY-START(30064836659),
    {
      "r": 131123,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndGetHostByName",
      "d": 65587,
      "h": 30064836659,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "EndGetHostByName has been deprecated. Use EndGetHostEntry instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30064836659),
//--TRIMMABLE-BOUNDARY-START(34359803955),
    {
      "r": 131123,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndGetHostEntry",
      "d": 65587,
      "h": 34359803955,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(34359803955),
//--TRIMMABLE-BOUNDARY-START(38654771251),
    {
      "r": 131123,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndResolve",
      "d": 65587,
      "h": 38654771251,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "EndResolve has been deprecated. Use EndGetHostEntry instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38654771251),
//--TRIMMABLE-BOUNDARY-START(47244705843),
    {
      "r": $.$typeArray($.$snp.SN.IPAddress).$h,
      "p": [
        {
          "n": "hostNameOrAddress",
          "p": 1310721
        }
      ],
      "n": "GetHostAddresses",
      "o": "@$1",
      "d": 65587,
      "h": 47244705843,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47244705843),
//--TRIMMABLE-BOUNDARY-START(42949738547),
    {
      "r": $.$typeArray($.$snp.SN.IPAddress).$h,
      "p": [
        {
          "n": "hostNameOrAddress",
          "p": 1310721
        },
        {
          "n": "family",
          "p": 4456495
        }
      ],
      "n": "GetHostAddresses",
      "d": 65587,
      "h": 42949738547,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42949738547),
//--TRIMMABLE-BOUNDARY-START(60129607731),
    {
      "r": $.$$.STT.Task$$($.$typeArray($.$snp.SN.IPAddress)).$h,
      "p": [
        {
          "n": "hostNameOrAddress",
          "p": 1310721
        }
      ],
      "n": "GetHostAddressesAsync",
      "o": "@$2",
      "d": 65587,
      "h": 60129607731,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(60129607731),
//--TRIMMABLE-BOUNDARY-START(51539673139),
    {
      "r": $.$$.STT.Task$$($.$typeArray($.$snp.SN.IPAddress)).$h,
      "p": [
        {
          "n": "hostNameOrAddress",
          "p": 1310721
        },
        {
          "n": "family",
          "p": 4456495
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "GetHostAddressesAsync",
      "d": 65587,
      "h": 51539673139,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51539673139),
//--TRIMMABLE-BOUNDARY-START(55834640435),
    {
      "r": $.$$.STT.Task$$($.$typeArray($.$snp.SN.IPAddress)).$h,
      "p": [
        {
          "n": "hostNameOrAddress",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "GetHostAddressesAsync",
      "o": "@$1",
      "d": 65587,
      "h": 55834640435,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(55834640435),
//--TRIMMABLE-BOUNDARY-START(64424575027),
    {
      "r": 131123,
      "p": [
        {
          "n": "address",
          "p": 3014703
        }
      ],
      "n": "GetHostByAddress",
      "d": 65587,
      "h": 64424575027,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "GetHostByAddress has been deprecated. Use GetHostEntry instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64424575027),
//--TRIMMABLE-BOUNDARY-START(68719542323),
    {
      "r": 131123,
      "p": [
        {
          "n": "address",
          "p": 1310721
        }
      ],
      "n": "GetHostByAddress",
      "o": "@$1",
      "d": 65587,
      "h": 68719542323,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "GetHostByAddress has been deprecated. Use GetHostEntry instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68719542323),
//--TRIMMABLE-BOUNDARY-START(73014509619),
    {
      "r": 131123,
      "p": [
        {
          "n": "hostName",
          "p": 1310721
        }
      ],
      "n": "GetHostByName",
      "d": 65587,
      "h": 73014509619,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "GetHostByName has been deprecated. Use GetHostEntry instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73014509619),
//--TRIMMABLE-BOUNDARY-START(77309476915),
    {
      "r": 131123,
      "p": [
        {
          "n": "address",
          "p": 3014703
        }
      ],
      "n": "GetHostEntry",
      "d": 65587,
      "h": 77309476915,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(77309476915),
//--TRIMMABLE-BOUNDARY-START(85899411507),
    {
      "r": 131123,
      "p": [
        {
          "n": "hostNameOrAddress",
          "p": 1310721
        }
      ],
      "n": "GetHostEntry",
      "o": "@$2",
      "d": 65587,
      "h": 85899411507,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(85899411507),
//--TRIMMABLE-BOUNDARY-START(81604444211),
    {
      "r": 131123,
      "p": [
        {
          "n": "hostNameOrAddress",
          "p": 1310721
        },
        {
          "n": "family",
          "p": 4456495
        }
      ],
      "n": "GetHostEntry",
      "o": "@$1",
      "d": 65587,
      "h": 81604444211,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(81604444211),
//--TRIMMABLE-BOUNDARY-START(90194378803),
    {
      "r": $.$$.STT.Task$$($.$snnr.SN.IPHostEntry).$h,
      "p": [
        {
          "n": "address",
          "p": 3014703
        }
      ],
      "n": "GetHostEntryAsync",
      "d": 65587,
      "h": 90194378803,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(90194378803),
//--TRIMMABLE-BOUNDARY-START(103079280691),
    {
      "r": $.$$.STT.Task$$($.$snnr.SN.IPHostEntry).$h,
      "p": [
        {
          "n": "hostNameOrAddress",
          "p": 1310721
        }
      ],
      "n": "GetHostEntryAsync",
      "o": "@$3",
      "d": 65587,
      "h": 103079280691,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(103079280691),
//--TRIMMABLE-BOUNDARY-START(94489346099),
    {
      "r": $.$$.STT.Task$$($.$snnr.SN.IPHostEntry).$h,
      "p": [
        {
          "n": "hostNameOrAddress",
          "p": 1310721
        },
        {
          "n": "family",
          "p": 4456495
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "GetHostEntryAsync",
      "o": "@$1",
      "d": 65587,
      "h": 94489346099,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(94489346099),
//--TRIMMABLE-BOUNDARY-START(98784313395),
    {
      "r": $.$$.STT.Task$$($.$snnr.SN.IPHostEntry).$h,
      "p": [
        {
          "n": "hostNameOrAddress",
          "p": 1310721
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "GetHostEntryAsync",
      "o": "@$2",
      "d": 65587,
      "h": 98784313395,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(98784313395),
//--TRIMMABLE-BOUNDARY-START(107374247987),
    {
      "r": 1310721,
      "n": "GetHostName",
      "d": 65587,
      "h": 107374247987,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(107374247987),
//--TRIMMABLE-BOUNDARY-START(111669215283),
    {
      "r": 131123,
      "p": [
        {
          "n": "hostName",
          "p": 1310721
        }
      ],
      "n": "Resolve",
      "d": 65587,
      "h": 111669215283,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "Resolve has been deprecated. Use GetHostEntry instead.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111669215283)
  ],
  "h": 65587
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Dns`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Dns`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65587)
        
        

        //--TRIMMABLE-BOUNDARY-START(131123)
        $asm.$cls(`$snnr.SN.IPHostEntry`, ($self) => class IPHostEntry extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295098419)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295098419);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098419)
            
            //--TRIMMABLE-BOUNDARY-START(8590065715)
            /*System.Net.IPAddress[] */ get AddressList()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474967603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress[] */ set AddressList(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539738675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590065715)
            
            //--TRIMMABLE-BOUNDARY-START(12885033011)
            /*string[] */ get Aliases()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ set Aliases(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885033011)
            
            //--TRIMMABLE-BOUNDARY-START(42949804083)
            /*string */ get HostName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set HostName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719607859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42949804083)
            
            //--TRIMMABLE-BOUNDARY-START(4295098419)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295098419)
            
            static $h = 131123;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590065715),
    {
      "p": $.$typeArray($.$snp.SN.IPAddress).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21474967603,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51539738675,
        "f": 83886081
      },
      "n": "AddressList",
      "d": 131123,
      "h": 8590065715,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590065715),
//--TRIMMABLE-BOUNDARY-START(12885033011),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064902195,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60129673267,
        "f": 83886081
      },
      "n": "Aliases",
      "d": 131123,
      "h": 12885033011,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885033011),
//--TRIMMABLE-BOUNDARY-START(42949804083),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654836787,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719607859,
        "f": 83886081
      },
      "n": "HostName",
      "d": 131123,
      "h": 42949804083,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42949804083)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098419),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131123,
      "h": 4295098419,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098419)
  ],
  "h": 131123
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.IPHostEntry`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}IPHostEntry`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131123)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped"));
})();
//--TRIMMABLE-BOUNDARY-END(51)
