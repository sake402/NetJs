
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $sri, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $ssc, $sris, $sl, $snp, $sspw, $sdd) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.NameResolution", 
    {"h":38795,"f":"System.Net.NameResolution","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.NameResolution","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.NameResolution","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snnr.System.Net.Dns", ($self) => class Dns
        {
            static /*System.IAsyncResult */ BeginGetHostAddresses(/*string*/ hostNameOrAddress, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.IAsyncResult */ BeginGetHostByName(/*string*/ hostName, /*System.AsyncCallback?*/ requestCallback, /*object?*/ stateObject)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.IAsyncResult */ BeginGetHostEntry(/*System.Net.IPAddress*/ address, /*System.AsyncCallback?*/ requestCallback, /*object?*/ stateObject)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.IAsyncResult */ BeginGetHostEntry$1(/*string*/ hostNameOrAddress, /*System.AsyncCallback?*/ requestCallback, /*object?*/ stateObject)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.IAsyncResult */ BeginResolve(/*string*/ hostName, /*System.AsyncCallback?*/ requestCallback, /*object?*/ stateObject)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPAddress[] */ EndGetHostAddresses(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ EndGetHostByName(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ EndGetHostEntry(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ EndResolve(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPAddress[] */ GetHostAddresses(/*string*/ hostNameOrAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPAddress[] */ GetHostAddresses$1(/*string*/ hostNameOrAddress, /*System.Net.Sockets.AddressFamily*/ family)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPAddress[]> */ GetHostAddressesAsync(/*string*/ hostNameOrAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPAddress[]> */ GetHostAddressesAsync$1(/*string*/ hostNameOrAddress, /*System.Net.Sockets.AddressFamily*/ family, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPAddress[]> */ GetHostAddressesAsync$2(/*string*/ hostNameOrAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostByAddress(/*System.Net.IPAddress*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostByAddress$1(/*string*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostByName(/*string*/ hostName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostEntry(/*System.Net.IPAddress*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostEntry$1(/*string*/ hostNameOrAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostEntry$2(/*string*/ hostNameOrAddress, /*System.Net.Sockets.AddressFamily*/ family)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPHostEntry> */ GetHostEntryAsync(/*System.Net.IPAddress*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPHostEntry> */ GetHostEntryAsync$1(/*string*/ hostNameOrAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPHostEntry> */ GetHostEntryAsync$2(/*string*/ hostNameOrAddress, /*System.Net.Sockets.AddressFamily*/ family, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPHostEntry> */ GetHostEntryAsync$3(/*string*/ hostNameOrAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*string */ GetHostName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ Resolve(/*string*/ hostName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 104331;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":56950785,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginGetHostAddresses","d":104331,"h":4295071627,"f":33},{"r":56950785,"p":[{"n":"hostName","p":1310721},{"n":"requestCallback","p":14417921},{"n":"stateObject","p":131073}],"n":"BeginGetHostByName","d":104331,"h":8590038923,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"BeginGetHostByName has been deprecated. Use BeginGetHostEntry instead.","t":1310721}]}]},{"r":56950785,"p":[{"n":"address","p":3055579},{"n":"requestCallback","p":14417921},{"n":"stateObject","p":131073}],"n":"BeginGetHostEntry","d":104331,"h":12885006219,"f":33},{"r":56950785,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"requestCallback","p":14417921},{"n":"stateObject","p":131073}],"n":"BeginGetHostEntry","o":"@$1","d":104331,"h":17179973515,"f":33},{"r":56950785,"p":[{"n":"hostName","p":1310721},{"n":"requestCallback","p":14417921},{"n":"stateObject","p":131073}],"n":"BeginResolve","d":104331,"h":21474940811,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"BeginResolve has been deprecated. Use BeginGetHostEntry instead.","t":1310721}]}]},{"r":0,"p":[{"n":"asyncResult","p":56950785}],"n":"EndGetHostAddresses","d":104331,"h":25769908107,"f":33},{"r":169867,"p":[{"n":"asyncResult","p":56950785}],"n":"EndGetHostByName","d":104331,"h":30064875403,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EndGetHostByName has been deprecated. Use EndGetHostEntry instead.","t":1310721}]}]},{"r":169867,"p":[{"n":"asyncResult","p":56950785}],"n":"EndGetHostEntry","d":104331,"h":34359842699,"f":33},{"r":169867,"p":[{"n":"asyncResult","p":56950785}],"n":"EndResolve","d":104331,"h":38654809995,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EndResolve has been deprecated. Use EndGetHostEntry instead.","t":1310721}]}]},{"r":0,"p":[{"n":"hostNameOrAddress","p":1310721}],"n":"GetHostAddresses","d":104331,"h":42949777291,"f":33},{"r":0,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"family","p":4497371}],"n":"GetHostAddresses","o":"@$1","d":104331,"h":47244744587,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$typeArray($.$snp.System.Net.IPAddress)).$h,"p":[{"n":"hostNameOrAddress","p":1310721}],"n":"GetHostAddressesAsync","d":104331,"h":51539711883,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$typeArray($.$snp.System.Net.IPAddress)).$h,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"family","p":4497371},{"n":"cancellationToken","p":125960193,"f":65}],"n":"GetHostAddressesAsync","o":"@$1","d":104331,"h":55834679179,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$typeArray($.$snp.System.Net.IPAddress)).$h,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"cancellationToken","p":125960193}],"n":"GetHostAddressesAsync","o":"@$2","d":104331,"h":60129646475,"f":33},{"r":169867,"p":[{"n":"address","p":3055579}],"n":"GetHostByAddress","d":104331,"h":64424613771,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"GetHostByAddress has been deprecated. Use GetHostEntry instead.","t":1310721}]}]},{"r":169867,"p":[{"n":"address","p":1310721}],"n":"GetHostByAddress","o":"@$1","d":104331,"h":68719581067,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"GetHostByAddress has been deprecated. Use GetHostEntry instead.","t":1310721}]}]},{"r":169867,"p":[{"n":"hostName","p":1310721}],"n":"GetHostByName","d":104331,"h":73014548363,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"GetHostByName has been deprecated. Use GetHostEntry instead.","t":1310721}]}]},{"r":169867,"p":[{"n":"address","p":3055579}],"n":"GetHostEntry","d":104331,"h":77309515659,"f":33},{"r":169867,"p":[{"n":"hostNameOrAddress","p":1310721}],"n":"GetHostEntry","o":"@$1","d":104331,"h":81604482955,"f":33},{"r":169867,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"family","p":4497371}],"n":"GetHostEntry","o":"@$2","d":104331,"h":85899450251,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snnr.System.Net.IPHostEntry).$h,"p":[{"n":"address","p":3055579}],"n":"GetHostEntryAsync","d":104331,"h":90194417547,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snnr.System.Net.IPHostEntry).$h,"p":[{"n":"hostNameOrAddress","p":1310721}],"n":"GetHostEntryAsync","o":"@$1","d":104331,"h":94489384843,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snnr.System.Net.IPHostEntry).$h,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"family","p":4497371},{"n":"cancellationToken","p":125960193,"f":65}],"n":"GetHostEntryAsync","o":"@$2","d":104331,"h":98784352139,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snnr.System.Net.IPHostEntry).$h,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"cancellationToken","p":125960193}],"n":"GetHostEntryAsync","o":"@$3","d":104331,"h":103079319435,"f":33},{"r":1310721,"n":"GetHostName","d":104331,"h":107374286731,"f":33},{"r":169867,"p":[{"n":"hostName","p":1310721}],"n":"Resolve","d":104331,"h":111669254027,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Resolve has been deprecated. Use GetHostEntry instead.","t":1310721}]}]}],"h":104331}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Dns`; }
        });
        
        $asm.$cls("$snnr.System.Net.IPHostEntry", ($self) => class IPHostEntry extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.IPAddress[] */ get AddressList()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress[] */ set AddressList(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ get Aliases()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ set Aliases(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get HostName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set HostName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 169867;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":0,"g":{"r":0,"d":0,"h":12885071755,"f":1},"s":{"r":0,"d":0,"h":17180039051,"f":1},"n":"AddressList","d":169867,"h":8590104459,"f":1},{"p":0,"g":{"r":0,"d":0,"h":25769973643,"f":1},"s":{"r":0,"d":0,"h":30064940939,"f":1},"n":"Aliases","d":169867,"h":21475006347,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38654875531,"f":1},"s":{"r":0,"d":0,"h":42949842827,"f":1},"n":"HostName","d":169867,"h":34359908235,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":169867,"h":4295137163,"f":1}],"h":169867}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.IPHostEntry`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Diagnostics.DiagnosticSource"))