
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $sri, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $ssc, $sris, $sl, $snp, $sspw, $sdd) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.NameResolution", 
    {"h":49129,"f":"System.Net.NameResolution","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.NameResolution","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.NameResolution","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snnr.System.Net.Dns", ($self) => class Dns
        {
            static /*System.IAsyncResult */ BeginGetHostAddresses(/*string*/ hostNameOrAddress, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.IAsyncResult */ BeginGetHostByName(/*string*/ hostName, /*System.AsyncCallback?*/ requestCallback, /*object?*/ stateObject)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.IAsyncResult */ BeginGetHostEntry(/*System.Net.IPAddress*/ address, /*System.AsyncCallback?*/ requestCallback, /*object?*/ stateObject)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.IAsyncResult */ BeginGetHostEntry$1(/*string*/ hostNameOrAddress, /*System.AsyncCallback?*/ requestCallback, /*object?*/ stateObject)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.IAsyncResult */ BeginResolve(/*string*/ hostName, /*System.AsyncCallback?*/ requestCallback, /*object?*/ stateObject)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPAddress[] */ EndGetHostAddresses(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ EndGetHostByName(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ EndGetHostEntry(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ EndResolve(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPAddress[] */ GetHostAddresses(/*string*/ hostNameOrAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPAddress[] */ GetHostAddresses$1(/*string*/ hostNameOrAddress, /*System.Net.Sockets.AddressFamily*/ family)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPAddress[]> */ GetHostAddressesAsync(/*string*/ hostNameOrAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPAddress[]> */ GetHostAddressesAsync$1(/*string*/ hostNameOrAddress, /*System.Net.Sockets.AddressFamily*/ family, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPAddress[]> */ GetHostAddressesAsync$2(/*string*/ hostNameOrAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostByAddress(/*System.Net.IPAddress*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostByAddress$1(/*string*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostByName(/*string*/ hostName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostEntry(/*System.Net.IPAddress*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostEntry$1(/*string*/ hostNameOrAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ GetHostEntry$2(/*string*/ hostNameOrAddress, /*System.Net.Sockets.AddressFamily*/ family)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPHostEntry> */ GetHostEntryAsync(/*System.Net.IPAddress*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPHostEntry> */ GetHostEntryAsync$1(/*string*/ hostNameOrAddress)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPHostEntry> */ GetHostEntryAsync$2(/*string*/ hostNameOrAddress, /*System.Net.Sockets.AddressFamily*/ family, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.IPHostEntry> */ GetHostEntryAsync$3(/*string*/ hostNameOrAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*string */ GetHostName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IPHostEntry */ Resolve(/*string*/ hostName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 114665;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":56950785,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"requestCallback","p":14417921},{"n":"state","p":131073}],"n":"BeginGetHostAddresses","d":114665,"h":4295081961,"f":33},{"r":56950785,"p":[{"n":"hostName","p":1310721},{"n":"requestCallback","p":14417921},{"n":"stateObject","p":131073}],"n":"BeginGetHostByName","d":114665,"h":8590049257,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"BeginGetHostByName has been deprecated. Use BeginGetHostEntry instead.","t":1310721}]}]},{"r":56950785,"p":[{"n":"address","p":3071756},{"n":"requestCallback","p":14417921},{"n":"stateObject","p":131073}],"n":"BeginGetHostEntry","d":114665,"h":12885016553,"f":33},{"r":56950785,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"requestCallback","p":14417921},{"n":"stateObject","p":131073}],"n":"BeginGetHostEntry","o":"@$1","d":114665,"h":17179983849,"f":33},{"r":56950785,"p":[{"n":"hostName","p":1310721},{"n":"requestCallback","p":14417921},{"n":"stateObject","p":131073}],"n":"BeginResolve","d":114665,"h":21474951145,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"BeginResolve has been deprecated. Use BeginGetHostEntry instead.","t":1310721}]}]},{"r":0,"p":[{"n":"asyncResult","p":56950785}],"n":"EndGetHostAddresses","d":114665,"h":25769918441,"f":33},{"r":180201,"p":[{"n":"asyncResult","p":56950785}],"n":"EndGetHostByName","d":114665,"h":30064885737,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EndGetHostByName has been deprecated. Use EndGetHostEntry instead.","t":1310721}]}]},{"r":180201,"p":[{"n":"asyncResult","p":56950785}],"n":"EndGetHostEntry","d":114665,"h":34359853033,"f":33},{"r":180201,"p":[{"n":"asyncResult","p":56950785}],"n":"EndResolve","d":114665,"h":38654820329,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EndResolve has been deprecated. Use EndGetHostEntry instead.","t":1310721}]}]},{"r":0,"p":[{"n":"hostNameOrAddress","p":1310721}],"n":"GetHostAddresses","d":114665,"h":42949787625,"f":33},{"r":0,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"family","p":4513548}],"n":"GetHostAddresses","o":"@$1","d":114665,"h":47244754921,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$typeArray($.$snp.System.Net.IPAddress)).$h,"p":[{"n":"hostNameOrAddress","p":1310721}],"n":"GetHostAddressesAsync","d":114665,"h":51539722217,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$typeArray($.$snp.System.Net.IPAddress)).$h,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"family","p":4513548},{"n":"cancellationToken","p":125960193,"f":65}],"n":"GetHostAddressesAsync","o":"@$1","d":114665,"h":55834689513,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$typeArray($.$snp.System.Net.IPAddress)).$h,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"cancellationToken","p":125960193}],"n":"GetHostAddressesAsync","o":"@$2","d":114665,"h":60129656809,"f":33},{"r":180201,"p":[{"n":"address","p":3071756}],"n":"GetHostByAddress","d":114665,"h":64424624105,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"GetHostByAddress has been deprecated. Use GetHostEntry instead.","t":1310721}]}]},{"r":180201,"p":[{"n":"address","p":1310721}],"n":"GetHostByAddress","o":"@$1","d":114665,"h":68719591401,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"GetHostByAddress has been deprecated. Use GetHostEntry instead.","t":1310721}]}]},{"r":180201,"p":[{"n":"hostName","p":1310721}],"n":"GetHostByName","d":114665,"h":73014558697,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"GetHostByName has been deprecated. Use GetHostEntry instead.","t":1310721}]}]},{"r":180201,"p":[{"n":"address","p":3071756}],"n":"GetHostEntry","d":114665,"h":77309525993,"f":33},{"r":180201,"p":[{"n":"hostNameOrAddress","p":1310721}],"n":"GetHostEntry","o":"@$1","d":114665,"h":81604493289,"f":33},{"r":180201,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"family","p":4513548}],"n":"GetHostEntry","o":"@$2","d":114665,"h":85899460585,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snnr.System.Net.IPHostEntry).$h,"p":[{"n":"address","p":3071756}],"n":"GetHostEntryAsync","d":114665,"h":90194427881,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snnr.System.Net.IPHostEntry).$h,"p":[{"n":"hostNameOrAddress","p":1310721}],"n":"GetHostEntryAsync","o":"@$1","d":114665,"h":94489395177,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snnr.System.Net.IPHostEntry).$h,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"family","p":4513548},{"n":"cancellationToken","p":125960193,"f":65}],"n":"GetHostEntryAsync","o":"@$2","d":114665,"h":98784362473,"f":33},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snnr.System.Net.IPHostEntry).$h,"p":[{"n":"hostNameOrAddress","p":1310721},{"n":"cancellationToken","p":125960193}],"n":"GetHostEntryAsync","o":"@$3","d":114665,"h":103079329769,"f":33},{"r":1310721,"n":"GetHostName","d":114665,"h":107374297065,"f":33},{"r":180201,"p":[{"n":"hostName","p":1310721}],"n":"Resolve","d":114665,"h":111669264361,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"Resolve has been deprecated. Use GetHostEntry instead.","t":1310721}]}]}],"h":114665}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Dns`; }
        });
        
        $asm.$cls("$snnr.System.Net.IPHostEntry", ($self) => class IPHostEntry extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.IPAddress[] */ get AddressList()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress[] */ set AddressList(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ get Aliases()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string[] */ set Aliases(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get HostName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set HostName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 180201;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":0,"g":{"r":0,"d":0,"h":12885082089,"f":1},"s":{"r":0,"d":0,"h":17180049385,"f":1},"n":"AddressList","d":180201,"h":8590114793,"f":1},{"p":0,"g":{"r":0,"d":0,"h":25769983977,"f":1},"s":{"r":0,"d":0,"h":30064951273,"f":1},"n":"Aliases","d":180201,"h":21475016681,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38654885865,"f":1},"s":{"r":0,"d":0,"h":42949853161,"f":1},"n":"HostName","d":180201,"h":34359918569,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":180201,"h":4295147497,"f":1}],"h":180201}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.IPHostEntry`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Diagnostics.DiagnosticSource"))