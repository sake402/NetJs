
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stee, $scsl, $snv, $sri, $sl, $stt, $sttp, $sdd, $snp, $ssc, $sspw, $sto, $snnr, $sns) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.NetworkInformation", 
    {"h":53612,"f":"System.Net.NetworkInformation","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.NetworkInformation","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.NetworkInformation","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snn.System.Net.NetworkInformation.GatewayIPAddressInformation", ($self) => class GatewayIPAddressInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 184684;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3070790,"g":{"r":0,"d":0,"h":12885086572,"f":257},"n":"Address","d":184684,"h":8590119276,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":184684,"h":4295151980,"f":4}],"h":184684}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.GatewayIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IcmpV4Statistics", ($self) => class IcmpV4Statistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 315756;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885217644,"f":257},"n":"AddressMaskRepliesReceived","d":315756,"h":8590250348,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475152236,"f":257},"n":"AddressMaskRepliesSent","d":315756,"h":17180184940,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065086828,"f":257},"n":"AddressMaskRequestsReceived","d":315756,"h":25770119532,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655021420,"f":257},"n":"AddressMaskRequestsSent","d":315756,"h":34360054124,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47244956012,"f":257},"n":"DestinationUnreachableMessagesReceived","d":315756,"h":42949988716,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55834890604,"f":257},"n":"DestinationUnreachableMessagesSent","d":315756,"h":51539923308,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64424825196,"f":257},"n":"EchoRepliesReceived","d":315756,"h":60129857900,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73014759788,"f":257},"n":"EchoRepliesSent","d":315756,"h":68719792492,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":81604694380,"f":257},"n":"EchoRequestsReceived","d":315756,"h":77309727084,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90194628972,"f":257},"n":"EchoRequestsSent","d":315756,"h":85899661676,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98784563564,"f":257},"n":"ErrorsReceived","d":315756,"h":94489596268,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":107374498156,"f":257},"n":"ErrorsSent","d":315756,"h":103079530860,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":115964432748,"f":257},"n":"MessagesReceived","d":315756,"h":111669465452,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":124554367340,"f":257},"n":"MessagesSent","d":315756,"h":120259400044,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":133144301932,"f":257},"n":"ParameterProblemsReceived","d":315756,"h":128849334636,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":141734236524,"f":257},"n":"ParameterProblemsSent","d":315756,"h":137439269228,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":150324171116,"f":257},"n":"RedirectsReceived","d":315756,"h":146029203820,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":158914105708,"f":257},"n":"RedirectsSent","d":315756,"h":154619138412,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":167504040300,"f":257},"n":"SourceQuenchesReceived","d":315756,"h":163209073004,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":176093974892,"f":257},"n":"SourceQuenchesSent","d":315756,"h":171799007596,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":184683909484,"f":257},"n":"TimeExceededMessagesReceived","d":315756,"h":180388942188,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":193273844076,"f":257},"n":"TimeExceededMessagesSent","d":315756,"h":188978876780,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":201863778668,"f":257},"n":"TimestampRepliesReceived","d":315756,"h":197568811372,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":210453713260,"f":257},"n":"TimestampRepliesSent","d":315756,"h":206158745964,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":219043647852,"f":257},"n":"TimestampRequestsReceived","d":315756,"h":214748680556,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":227633582444,"f":257},"n":"TimestampRequestsSent","d":315756,"h":223338615148,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":315756,"h":4295283052,"f":4}],"h":315756}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IcmpV4Statistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IcmpV6Statistics", ($self) => class IcmpV6Statistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 381292;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885283180,"f":257},"n":"DestinationUnreachableMessagesReceived","d":381292,"h":8590315884,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475217772,"f":257},"n":"DestinationUnreachableMessagesSent","d":381292,"h":17180250476,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065152364,"f":257},"n":"EchoRepliesReceived","d":381292,"h":25770185068,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655086956,"f":257},"n":"EchoRepliesSent","d":381292,"h":34360119660,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245021548,"f":257},"n":"EchoRequestsReceived","d":381292,"h":42950054252,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55834956140,"f":257},"n":"EchoRequestsSent","d":381292,"h":51539988844,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64424890732,"f":257},"n":"ErrorsReceived","d":381292,"h":60129923436,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73014825324,"f":257},"n":"ErrorsSent","d":381292,"h":68719858028,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81604759916,"f":257},"n":"MembershipQueriesReceived","d":381292,"h":77309792620,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90194694508,"f":257},"n":"MembershipQueriesSent","d":381292,"h":85899727212,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98784629100,"f":257},"n":"MembershipReductionsReceived","d":381292,"h":94489661804,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107374563692,"f":257},"n":"MembershipReductionsSent","d":381292,"h":103079596396,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":115964498284,"f":257},"n":"MembershipReportsReceived","d":381292,"h":111669530988,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":124554432876,"f":257},"n":"MembershipReportsSent","d":381292,"h":120259465580,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":133144367468,"f":257},"n":"MessagesReceived","d":381292,"h":128849400172,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":141734302060,"f":257},"n":"MessagesSent","d":381292,"h":137439334764,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":150324236652,"f":257},"n":"NeighborAdvertisementsReceived","d":381292,"h":146029269356,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":158914171244,"f":257},"n":"NeighborAdvertisementsSent","d":381292,"h":154619203948,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":167504105836,"f":257},"n":"NeighborSolicitsReceived","d":381292,"h":163209138540,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":176094040428,"f":257},"n":"NeighborSolicitsSent","d":381292,"h":171799073132,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":184683975020,"f":257},"n":"PacketTooBigMessagesReceived","d":381292,"h":180389007724,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":193273909612,"f":257},"n":"PacketTooBigMessagesSent","d":381292,"h":188978942316,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":201863844204,"f":257},"n":"ParameterProblemsReceived","d":381292,"h":197568876908,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":210453778796,"f":257},"n":"ParameterProblemsSent","d":381292,"h":206158811500,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":219043713388,"f":257},"n":"RedirectsReceived","d":381292,"h":214748746092,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":227633647980,"f":257},"n":"RedirectsSent","d":381292,"h":223338680684,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":236223582572,"f":257},"n":"RouterAdvertisementsReceived","d":381292,"h":231928615276,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":244813517164,"f":257},"n":"RouterAdvertisementsSent","d":381292,"h":240518549868,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":253403451756,"f":257},"n":"RouterSolicitsReceived","d":381292,"h":249108484460,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":261993386348,"f":257},"n":"RouterSolicitsSent","d":381292,"h":257698419052,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":270583320940,"f":257},"n":"TimeExceededMessagesReceived","d":381292,"h":266288353644,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":279173255532,"f":257},"n":"TimeExceededMessagesSent","d":381292,"h":274878288236,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":381292,"h":4295348588,"f":4}],"h":381292}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IcmpV6Statistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPAddressInformation", ($self) => class IPAddressInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 446828;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3070790,"g":{"r":0,"d":0,"h":12885348716,"f":257},"n":"Address","d":446828,"h":8590381420,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":21475283308,"f":257},"n":"IsDnsEligible","d":446828,"h":17180316012,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":30065217900,"f":257},"n":"IsTransient","d":446828,"h":25770250604,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":446828,"h":4295414124,"f":4}],"h":446828}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPGlobalProperties", ($self) => class IPGlobalProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.IAsyncResult */ BeginGetUnicastAddresses(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformationCollection */ EndGetUnicastAddresses(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.IPGlobalProperties */ GetIPGlobalProperties()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformationCollection */ GetUnicastAddresses()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.NetworkInformation.UnicastIPAddressInformationCollection> */ GetUnicastAddressesAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 577900;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885479788,"f":257},"n":"DhcpScopeName","d":577900,"h":8590512492,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":21475414380,"f":257},"n":"DomainName","d":577900,"h":17180447084,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":30065348972,"f":257},"n":"HostName","d":577900,"h":25770381676,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":38655283564,"f":257},"n":"IsWinsProxy","d":577900,"h":34360316268,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1167724,"g":{"r":0,"d":0,"h":47245218156,"f":257},"n":"NodeType","d":577900,"h":42950250860,"f":257}],"m":[{"r":57016321,"p":[{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginGetUnicastAddresses","d":577900,"h":51540185452,"f":129},{"r":2412908,"p":[{"n":"asyncResult","p":57016321}],"n":"EndGetUnicastAddresses","d":577900,"h":55835152748,"f":129},{"r":0,"n":"GetActiveTcpConnections","d":577900,"h":60130120044,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":0,"n":"GetActiveTcpListeners","d":577900,"h":64425087340,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":0,"n":"GetActiveUdpListeners","d":577900,"h":68720054636,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":315756,"n":"GetIcmpV4Statistics","d":577900,"h":73015021932,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":381292,"n":"GetIcmpV6Statistics","d":577900,"h":77309989228,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":577900,"n":"GetIPGlobalProperties","d":577900,"h":81604956524,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":643436,"n":"GetIPv4GlobalStatistics","d":577900,"h":85899923820,"f":257},{"r":643436,"n":"GetIPv6GlobalStatistics","d":577900,"h":90194891116,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"r":2216300,"n":"GetTcpIPv4Statistics","d":577900,"h":94489858412,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2216300,"n":"GetTcpIPv6Statistics","d":577900,"h":98784825708,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2281836,"n":"GetUdpIPv4Statistics","d":577900,"h":103079793004,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2281836,"n":"GetUdpIPv6Statistics","d":577900,"h":107374760300,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2412908,"n":"GetUnicastAddresses","d":577900,"h":111669727596,"f":129},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformationCollection).$h,"n":"GetUnicastAddressesAsync","d":577900,"h":115964694892,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":577900,"h":4295545196,"f":4}],"h":577900}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPGlobalProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPGlobalStatistics", ($self) => class IPGlobalStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 643436;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885545324,"f":257},"n":"DefaultTtl","d":643436,"h":8590578028,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":21475479916,"f":257},"n":"ForwardingEnabled","d":643436,"h":17180512620,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":30065414508,"f":257},"n":"NumberOfInterfaces","d":643436,"h":25770447212,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":38655349100,"f":257},"n":"NumberOfIPAddresses","d":643436,"h":34360381804,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":47245283692,"f":257},"n":"NumberOfRoutes","d":643436,"h":42950316396,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":55835218284,"f":257},"n":"OutputPacketRequests","d":643436,"h":51540250988,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":64425152876,"f":257},"n":"OutputPacketRoutingDiscards","d":643436,"h":60130185580,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73015087468,"f":257},"n":"OutputPacketsDiscarded","d":643436,"h":68720120172,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605022060,"f":257},"n":"OutputPacketsWithNoRoute","d":643436,"h":77310054764,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":90194956652,"f":257},"n":"PacketFragmentFailures","d":643436,"h":85899989356,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":98784891244,"f":257},"n":"PacketReassembliesRequired","d":643436,"h":94489923948,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":107374825836,"f":257},"n":"PacketReassemblyFailures","d":643436,"h":103079858540,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":115964760428,"f":257},"n":"PacketReassemblyTimeout","d":643436,"h":111669793132,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":124554695020,"f":257},"n":"PacketsFragmented","d":643436,"h":120259727724,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":133144629612,"f":257},"n":"PacketsReassembled","d":643436,"h":128849662316,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":141734564204,"f":257},"n":"ReceivedPackets","d":643436,"h":137439596908,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":150324498796,"f":257},"n":"ReceivedPacketsDelivered","d":643436,"h":146029531500,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":158914433388,"f":257},"n":"ReceivedPacketsDiscarded","d":643436,"h":154619466092,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":167504367980,"f":257},"n":"ReceivedPacketsForwarded","d":643436,"h":163209400684,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":176094302572,"f":257},"n":"ReceivedPacketsWithAddressErrors","d":643436,"h":171799335276,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":184684237164,"f":257},"n":"ReceivedPacketsWithHeadersErrors","d":643436,"h":180389269868,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":193274171756,"f":257},"n":"ReceivedPacketsWithUnknownProtocol","d":643436,"h":188979204460,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":643436,"h":4295610732,"f":4}],"h":643436}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPGlobalStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPInterfaceProperties", ($self) => class IPInterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 708972;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":512364,"g":{"r":0,"d":0,"h":12885610860,"f":257},"n":"AnycastAddresses","d":708972,"h":8590643564,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":4053830,"g":{"r":0,"d":0,"h":21475545452,"f":257},"n":"DhcpServerAddresses","d":708972,"h":17180578156,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":4053830,"g":{"r":0,"d":0,"h":30065480044,"f":257},"n":"DnsAddresses","d":708972,"h":25770512748,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":38655414636,"f":257},"n":"DnsSuffix","d":708972,"h":34360447340,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":250220,"g":{"r":0,"d":0,"h":47245349228,"f":257},"n":"GatewayAddresses","d":708972,"h":42950381932,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":55835283820,"f":257},"n":"IsDnsEnabled","d":708972,"h":51540316524,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":64425218412,"f":257},"n":"IsDynamicDnsEnabled","d":708972,"h":60130251116,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1102188,"g":{"r":0,"d":0,"h":73015153004,"f":257},"n":"MulticastAddresses","d":708972,"h":68720185708,"f":257},{"p":2412908,"g":{"r":0,"d":0,"h":81605087596,"f":257},"n":"UnicastAddresses","d":708972,"h":77310120300,"f":257},{"p":4053830,"g":{"r":0,"d":0,"h":90195022188,"f":257},"n":"WinsServersAddresses","d":708972,"h":85900054892,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]}],"m":[{"r":840044,"n":"GetIPv4Properties","d":708972,"h":94489989484,"f":257},{"r":971116,"n":"GetIPv6Properties","d":708972,"h":98784956780,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":708972,"h":4295676268,"f":4}],"h":708972}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPInterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPInterfaceStatistics", ($self) => class IPInterfaceStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 774508;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885676396,"f":257},"n":"BytesReceived","d":774508,"h":8590709100,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475610988,"f":257},"n":"BytesSent","d":774508,"h":17180643692,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065545580,"f":257},"n":"IncomingPacketsDiscarded","d":774508,"h":25770578284,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655480172,"f":257},"n":"IncomingPacketsWithErrors","d":774508,"h":34360512876,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245414764,"f":257},"n":"IncomingUnknownProtocolPackets","d":774508,"h":42950447468,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"linux","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":55835349356,"f":257},"n":"NonUnicastPacketsReceived","d":774508,"h":51540382060,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64425283948,"f":257},"n":"NonUnicastPacketsSent","d":774508,"h":60130316652,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"linux","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73015218540,"f":257},"n":"OutgoingPacketsDiscarded","d":774508,"h":68720251244,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605153132,"f":257},"n":"OutgoingPacketsWithErrors","d":774508,"h":77310185836,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90195087724,"f":257},"n":"OutputQueueLength","d":774508,"h":85900120428,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98785022316,"f":257},"n":"UnicastPacketsReceived","d":774508,"h":94490055020,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107374956908,"f":257},"n":"UnicastPacketsSent","d":774508,"h":103079989612,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":774508,"h":4295741804,"f":4}],"h":774508}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPInterfaceStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv4InterfaceProperties", ($self) => class IPv4InterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 840044;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885741932,"f":257},"n":"Index","d":840044,"h":8590774636,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":21475676524,"f":257},"n":"IsAutomaticPrivateAddressingActive","d":840044,"h":17180709228,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":30065611116,"f":257},"n":"IsAutomaticPrivateAddressingEnabled","d":840044,"h":25770643820,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":38655545708,"f":257},"n":"IsDhcpEnabled","d":840044,"h":34360578412,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":47245480300,"f":257},"n":"IsForwardingEnabled","d":840044,"h":42950513004,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":55835414892,"f":257},"n":"Mtu","d":840044,"h":51540447596,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":64425349484,"f":257},"n":"UsesWins","d":840044,"h":60130382188,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":840044,"h":4295807340,"f":4}],"h":840044}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv4InterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv4InterfaceStatistics", ($self) => class IPv4InterfaceStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 905580;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885807468,"f":257},"n":"BytesReceived","d":905580,"h":8590840172,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475742060,"f":257},"n":"BytesSent","d":905580,"h":17180774764,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065676652,"f":257},"n":"IncomingPacketsDiscarded","d":905580,"h":25770709356,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655611244,"f":257},"n":"IncomingPacketsWithErrors","d":905580,"h":34360643948,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245545836,"f":257},"n":"IncomingUnknownProtocolPackets","d":905580,"h":42950578540,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55835480428,"f":257},"n":"NonUnicastPacketsReceived","d":905580,"h":51540513132,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64425415020,"f":257},"n":"NonUnicastPacketsSent","d":905580,"h":60130447724,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73015349612,"f":257},"n":"OutgoingPacketsDiscarded","d":905580,"h":68720382316,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605284204,"f":257},"n":"OutgoingPacketsWithErrors","d":905580,"h":77310316908,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90195218796,"f":257},"n":"OutputQueueLength","d":905580,"h":85900251500,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98785153388,"f":257},"n":"UnicastPacketsReceived","d":905580,"h":94490186092,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107375087980,"f":257},"n":"UnicastPacketsSent","d":905580,"h":103080120684,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":905580,"h":4295872876,"f":4}],"h":905580}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv4InterfaceStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv6InterfaceProperties", ($self) => class IPv6InterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*long */ GetScopeId(/*System.Net.NetworkInformation.ScopeLevel*/ scopeLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 971116;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885873004,"f":257},"n":"Index","d":971116,"h":8590905708,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":21475807596,"f":257},"n":"Mtu","d":971116,"h":17180840300,"f":257}],"m":[{"r":917505,"p":[{"n":"scopeLevel","p":1954156}],"n":"GetScopeId","d":971116,"h":25770774892,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":971116,"h":4295938412,"f":4}],"h":971116}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv6InterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkInterface", ($self) => class NetworkInterface extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string */ get Description()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get IPv6LoopbackInterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReceiveOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get LoopbackInterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.NetworkInterfaceType */ get NetworkInterfaceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.OperationalStatus */ get OperationalStatus()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Speed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get SupportsMulticast()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.NetworkInterface[] */ GetAllNetworkInterfaces()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPInterfaceProperties */ GetIPProperties()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPInterfaceStatistics */ GetIPStatistics()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPv4InterfaceStatistics */ GetIPv4Statistics()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ GetIsNetworkAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.PhysicalAddress */ GetPhysicalAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Supports(/*System.Net.NetworkInformation.NetworkInterfaceComponent*/ networkInterfaceComponent)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1560940;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12886462828,"f":129},"n":"Description","d":1560940,"h":8591495532,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":21476397420,"f":129},"n":"Id","d":1560940,"h":17181430124,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":30066332012,"f":33},"n":"IPv6LoopbackInterfaceIndex","d":1560940,"h":25771364716,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":38656266604,"f":129},"n":"IsReceiveOnly","d":1560940,"h":34361299308,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":47246201196,"f":33},"n":"LoopbackInterfaceIndex","d":1560940,"h":42951233900,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":55836135788,"f":129},"n":"Name","d":1560940,"h":51541168492,"f":129},{"p":1692012,"g":{"r":0,"d":0,"h":64426070380,"f":129},"n":"NetworkInterfaceType","d":1560940,"h":60131103084,"f":129},{"p":1757548,"g":{"r":0,"d":0,"h":73016004972,"f":129},"n":"OperationalStatus","d":1560940,"h":68721037676,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":81605939564,"f":129},"n":"Speed","d":1560940,"h":77310972268,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":90195874156,"f":129},"n":"SupportsMulticast","d":1560940,"h":85900906860,"f":129}],"m":[{"r":0,"n":"GetAllNetworkInterfaces","d":1560940,"h":94490841452,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":708972,"n":"GetIPProperties","d":1560940,"h":98785808748,"f":129},{"r":774508,"n":"GetIPStatistics","d":1560940,"h":103080776044,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":905580,"n":"GetIPv4Statistics","d":1560940,"h":107375743340,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":262145,"n":"GetIsNetworkAvailable","d":1560940,"h":111670710636,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":1823084,"n":"GetPhysicalAddress","d":1560940,"h":115965677932,"f":129},{"r":262145,"p":[{"n":"networkInterfaceComponent","p":1626476}],"n":"Supports","d":1560940,"h":120260645228,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":1560940,"h":4296528236,"f":4}],"h":1560940}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterface`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.TcpConnectionInformation", ($self) => class TcpConnectionInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2085228;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3332934,"g":{"r":0,"d":0,"h":12886987116,"f":257},"n":"LocalEndPoint","d":2085228,"h":8592019820,"f":257},{"p":3332934,"g":{"r":0,"d":0,"h":21476921708,"f":257},"n":"RemoteEndPoint","d":2085228,"h":17181954412,"f":257},{"p":2150764,"g":{"r":0,"d":0,"h":30066856300,"f":257},"n":"State","d":2085228,"h":25771889004,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2085228,"h":4297052524,"f":4}],"h":2085228}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpConnectionInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.TcpStatistics", ($self) => class TcpStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2216300;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887118188,"f":257},"n":"ConnectionsAccepted","d":2216300,"h":8592150892,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21477052780,"f":257},"n":"ConnectionsInitiated","d":2216300,"h":17182085484,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30066987372,"f":257},"n":"CumulativeConnections","d":2216300,"h":25772020076,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38656921964,"f":257},"n":"CurrentConnections","d":2216300,"h":34361954668,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47246856556,"f":257},"n":"ErrorsReceived","d":2216300,"h":42951889260,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55836791148,"f":257},"n":"FailedConnectionAttempts","d":2216300,"h":51541823852,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64426725740,"f":257},"n":"MaximumConnections","d":2216300,"h":60131758444,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73016660332,"f":257},"n":"MaximumTransmissionTimeout","d":2216300,"h":68721693036,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":81606594924,"f":257},"n":"MinimumTransmissionTimeout","d":2216300,"h":77311627628,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90196529516,"f":257},"n":"ResetConnections","d":2216300,"h":85901562220,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98786464108,"f":257},"n":"ResetsSent","d":2216300,"h":94491496812,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107376398700,"f":257},"n":"SegmentsReceived","d":2216300,"h":103081431404,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":115966333292,"f":257},"n":"SegmentsResent","d":2216300,"h":111671365996,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":124556267884,"f":257},"n":"SegmentsSent","d":2216300,"h":120261300588,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2216300,"h":4297183596,"f":4}],"h":2216300}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UdpStatistics", ($self) => class UdpStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2281836;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887183724,"f":257},"n":"DatagramsReceived","d":2281836,"h":8592216428,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21477118316,"f":257},"n":"DatagramsSent","d":2281836,"h":17182151020,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30067052908,"f":257},"n":"IncomingDatagramsDiscarded","d":2281836,"h":25772085612,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38656987500,"f":257},"n":"IncomingDatagramsWithErrors","d":2281836,"h":34362020204,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":47246922092,"f":257},"n":"UdpListeners","d":2281836,"h":42951954796,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2281836,"h":4297249132,"f":4}],"h":2281836}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.UdpStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.MulticastIPAddressInformation", ($self) => class MulticastIPAddressInformation extends $.$snn.System.Net.NetworkInformation.IPAddressInformation
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 1036652;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":446828,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885938540,"f":257},"n":"AddressPreferredLifetime","d":1036652,"h":8590971244,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":21475873132,"f":257},"n":"AddressValidLifetime","d":1036652,"h":17180905836,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":30065807724,"f":257},"n":"DhcpLeaseLifetime","d":1036652,"h":25770840428,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":119148,"g":{"r":0,"d":0,"h":38655742316,"f":257},"n":"DuplicateAddressDetectionState","d":1036652,"h":34360775020,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1888620,"g":{"r":0,"d":0,"h":47245676908,"f":257},"n":"PrefixOrigin","d":1036652,"h":42950709612,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":2019692,"g":{"r":0,"d":0,"h":55835611500,"f":257},"n":"SuffixOrigin","d":1036652,"h":51540644204,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":1036652,"h":4296003948,"f":4}],"h":1036652}; }
            static get $b() { return $.$snn.System.Net.NetworkInformation.IPAddressInformation; }
            static get $fullName() { return `System.Net.NetworkInformation.MulticastIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UnicastIPAddressInformation", ($self) => class UnicastIPAddressInformation extends $.$snn.System.Net.NetworkInformation.IPAddressInformation
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get PrefixLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2347372;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":446828,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887249260,"f":257},"n":"AddressPreferredLifetime","d":2347372,"h":8592281964,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":21477183852,"f":257},"n":"AddressValidLifetime","d":2347372,"h":17182216556,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":30067118444,"f":257},"n":"DhcpLeaseLifetime","d":2347372,"h":25772151148,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":119148,"g":{"r":0,"d":0,"h":38657053036,"f":257},"n":"DuplicateAddressDetectionState","d":2347372,"h":34362085740,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":3070790,"g":{"r":0,"d":0,"h":47246987628,"f":257},"n":"IPv4Mask","d":2347372,"h":42952020332,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":55836922220,"f":129},"n":"PrefixLength","d":2347372,"h":51541954924,"f":129},{"p":1888620,"g":{"r":0,"d":0,"h":64426856812,"f":257},"n":"PrefixOrigin","d":2347372,"h":60131889516,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":2019692,"g":{"r":0,"d":0,"h":73016791404,"f":257},"n":"SuffixOrigin","d":2347372,"h":68721824108,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":2347372,"h":4297314668,"f":4}],"h":2347372}; }
            static get $b() { return $.$snn.System.Net.NetworkInformation.IPAddressInformation; }
            static get $fullName() { return `System.Net.NetworkInformation.UnicastIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkChange", ($self) => class NetworkChange extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.NetworkInformation.NetworkAddressChangedEventHandler?*/static  add_NetworkAddressChanged(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAddressChangedEventHandler?*/static  remove_NetworkAddressChanged(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler?*/static  add_NetworkAvailabilityChanged(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler?*/static  remove_NetworkAvailabilityChanged(value)
            {
            }
            static /*void */ RegisterNetworkChange(/*System.Net.NetworkInformation.NetworkChange*/ nc)
            {
            }
            static $h = 1429868;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"nc","p":1429868}],"n":"RegisterNetworkChange","d":1429868,"h":34361168236,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]},{"t":70909953,"c":12955811841,"a":[{"v":"This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.","t":1310721},{"v":true,"t":262145}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":1429868,"h":4296397164,"f":1,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]},{"t":70909953,"c":12955811841,"a":[{"v":"This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.","t":1310721},{"v":true,"t":262145}]}]}],"e":[{"e":1233260,"m":{"r":65537,"p":[{"n":"value","p":1233260}],"n":"add_NetworkAddressChanged","d":1429868,"h":12886331756,"f":33},"r":{"r":65537,"p":[{"n":"value","p":1233260}],"n":"remove_NetworkAddressChanged","d":1429868,"h":17181299052,"f":33},"n":"NetworkAddressChanged","d":1429868,"h":8591364460,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"e":1298796,"m":{"r":65537,"p":[{"n":"value","p":1298796}],"n":"add_NetworkAvailabilityChanged","d":1429868,"h":25771233644,"f":33},"r":{"r":65537,"p":[{"n":"value","p":1298796}],"n":"remove_NetworkAvailabilityChanged","d":1429868,"h":30066200940,"f":33},"n":"NetworkAvailabilityChanged","d":1429868,"h":21476266348,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]}],"h":1429868}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkChange`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.PhysicalAddress", ($self) => class PhysicalAddress extends $.$spc.System.Object
        {
            /*System.Net.NetworkInformation.PhysicalAddress*/ static None = null;
            $ctor$1(/*byte[]*/ address)
            {
                super.$ctor();
                {
                }
                return this;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.Equals.apply(this, arguments); }
            /*byte[] */ GetAddressBytes()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.GetHashCode.apply(this, arguments); }
            static /*System.Net.NetworkInformation.PhysicalAddress */ Parse(/*System.ReadOnlySpan<char>*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.PhysicalAddress */ Parse$1(/*string?*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.ToString.apply(this, arguments); }
            static /*bool */ TryParse(/*System.ReadOnlySpan<char>*/ address, /*out System.Net.NetworkInformation.PhysicalAddress?*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ TryParse$1(/*string?*/ address, /*out System.Net.NetworkInformation.PhysicalAddress?*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1823084;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":1823084,"h":12886724972,"f":32769},{"r":0,"n":"GetAddressBytes","d":1823084,"h":17181692268,"f":1},{"r":655361,"n":"GetHashCode","d":1823084,"h":21476659564,"f":32769},{"r":1823084,"p":[{"n":"address","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Parse","d":1823084,"h":25771626860,"f":33},{"r":1823084,"p":[{"n":"address","p":1310721}],"n":"Parse","o":"@$1","d":1823084,"h":30066594156,"f":33},{"r":1310721,"n":"ToString","d":1823084,"h":34361561452,"f":32769},{"r":262145,"p":[{"n":"address","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"value","p":1823084,"f":2}],"n":"TryParse","d":1823084,"h":38656528748,"f":33},{"r":262145,"p":[{"n":"address","p":1310721},{"n":"value","p":1823084,"f":2}],"n":"TryParse","o":"@$1","d":1823084,"h":42951496044,"f":33}],"l":[{"t":1823084,"n":"None","d":1823084,"h":4296790380,"f":33}],"c":[{"p":[{"n":"address","p":0}],"n":".ctor","o":"$ctor$1","d":1823084,"h":8591757676,"f":1}],"h":1823084}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.PhysicalAddress`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.GatewayIPAddressInformationCollection", ($self) => class GatewayIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.GatewayIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.GatewayIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.GatewayIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Add(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Contains(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.CopyTo(System.Net.NetworkInformation.GatewayIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Remove(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.GatewayIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 250220;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885152108,"f":129},"n":"Count","d":250220,"h":8590184812,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475086700,"f":129},"n":"IsReadOnly","d":250220,"h":17180119404,"f":129},{"p":184684,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065021292,"f":129},"n":"Item","o":"@$2","d":250220,"h":25770053996,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":184684}],"n":"Add","d":250220,"h":34359988588,"f":129},{"r":65537,"n":"Clear","d":250220,"h":38654955884,"f":129},{"r":262145,"p":[{"n":"address","p":184684}],"n":"Contains","d":250220,"h":42949923180,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":250220,"h":47244890476,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,"n":"GetEnumerator","d":250220,"h":51539857772,"f":129},{"r":262145,"p":[{"n":"address","p":184684}],"n":"Remove","d":250220,"h":55834825068,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":250220,"h":4295217516,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,31653889],"h":250220}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.GatewayIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPAddressInformationCollection", ($self) => class IPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.IPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.IPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Add(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Contains(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.CopyTo(System.Net.NetworkInformation.IPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Remove(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.IPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 512364;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885414252,"f":129},"n":"Count","d":512364,"h":8590446956,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475348844,"f":129},"n":"IsReadOnly","d":512364,"h":17180381548,"f":129},{"p":446828,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065283436,"f":129},"n":"Item","o":"@$2","d":512364,"h":25770316140,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":446828}],"n":"Add","d":512364,"h":34360250732,"f":129},{"r":65537,"n":"Clear","d":512364,"h":38655218028,"f":129},{"r":262145,"p":[{"n":"address","p":446828}],"n":"Contains","d":512364,"h":42950185324,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":512364,"h":47245152620,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,"n":"GetEnumerator","d":512364,"h":51540119916,"f":129},{"r":262145,"p":[{"n":"address","p":446828}],"n":"Remove","d":512364,"h":55835087212,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":512364,"h":4295479660,"f":8}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,31653889],"h":512364}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.IPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.IPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.MulticastIPAddressInformationCollection", ($self) => class MulticastIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.MulticastIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.MulticastIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.MulticastIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Add(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Contains(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.CopyTo(System.Net.NetworkInformation.MulticastIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Remove(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.MulticastIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 1102188;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886004076,"f":129},"n":"Count","d":1102188,"h":8591036780,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475938668,"f":129},"n":"IsReadOnly","d":1102188,"h":17180971372,"f":129},{"p":1036652,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065873260,"f":129},"n":"Item","o":"@$2","d":1102188,"h":25770905964,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":1036652}],"n":"Add","d":1102188,"h":34360840556,"f":129},{"r":65537,"n":"Clear","d":1102188,"h":38655807852,"f":129},{"r":262145,"p":[{"n":"address","p":1036652}],"n":"Contains","d":1102188,"h":42950775148,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":1102188,"h":47245742444,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,"n":"GetEnumerator","d":1102188,"h":51540709740,"f":129},{"r":262145,"p":[{"n":"address","p":1036652}],"n":"Remove","d":1102188,"h":55835677036,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":1102188,"h":4296069484,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,31653889],"h":1102188}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.MulticastIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UnicastIPAddressInformationCollection", ($self) => class UnicastIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.UnicastIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.UnicastIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Add(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Contains(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.CopyTo(System.Net.NetworkInformation.UnicastIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Remove(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.UnicastIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 2412908;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12887314796,"f":129},"n":"Count","d":2412908,"h":8592347500,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21477249388,"f":129},"n":"IsReadOnly","d":2412908,"h":17182282092,"f":129},{"p":2347372,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30067183980,"f":129},"n":"Item","o":"@$2","d":2412908,"h":25772216684,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":2347372}],"n":"Add","d":2412908,"h":34362151276,"f":129},{"r":65537,"n":"Clear","d":2412908,"h":38657118572,"f":129},{"r":262145,"p":[{"n":"address","p":2347372}],"n":"Contains","d":2412908,"h":42952085868,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":2412908,"h":47247053164,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,"n":"GetEnumerator","d":2412908,"h":51542020460,"f":129},{"r":262145,"p":[{"n":"address","p":2347372}],"n":"Remove","d":2412908,"h":55836987756,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":2412908,"h":4297380204,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,31653889],"h":2412908}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.UnicastIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAddressChangedEventHandler", ($self) => class NetworkAddressChangedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ sender, /*$.$spc.System.EventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 1233260;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":46989313}],"n":"Invoke","d":1233260,"h":8591167852,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":46989313},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":1233260,"h":12886135148,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":1233260,"h":17181102444,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1233260,"h":4296200556,"f":1}],"i":[57212929,113377281],"h":1233260}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAddressChangedEventHandler`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler", ($self) => class NetworkAvailabilityChangedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ sender, /*$.$snn.System.Net.NetworkInformation.NetworkAvailabilityEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 1298796;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":1364332}],"n":"Invoke","d":1298796,"h":8591233388,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":1364332},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":1298796,"h":12886200684,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":1298796,"h":17181167980,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1298796,"h":4296266092,"f":1}],"i":[57212929,113377281],"h":1298796}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.DuplicateAddressDetectionState", ($self) => class DuplicateAddressDetectionState extends $.$spc.System.Enum
        {
            static Invalid = 0;
            static Tentative = 1;
            static Duplicate = 2;
            static Deprecated = 3;
            static Preferred = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Invalid": 0n,
                    "Tentative": 1n,
                    "Duplicate": 2n,
                    "Deprecated": 3n,
                    "Preferred": 4n
                };
            }
            static $h = 119148;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":119148,"n":"Invalid","d":119148,"h":4295086444,"f":33},{"t":119148,"n":"Tentative","d":119148,"h":8590053740,"f":33},{"t":119148,"n":"Duplicate","d":119148,"h":12885021036,"f":33},{"t":119148,"n":"Deprecated","d":119148,"h":17179988332,"f":33},{"t":119148,"n":"Preferred","d":119148,"h":21474955628,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":119148,"h":25769922924,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":119148}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.DuplicateAddressDetectionState`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetBiosNodeType", ($self) => class NetBiosNodeType extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Broadcast = 1;
            static Peer2Peer = 2;
            static Mixed = 4;
            static Hybrid = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Broadcast": 1n,
                    "Peer2Peer": 2n,
                    "Mixed": 4n,
                    "Hybrid": 8n
                };
            }
            static $h = 1167724;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1167724,"n":"Unknown","d":1167724,"h":4296135020,"f":33},{"t":1167724,"n":"Broadcast","d":1167724,"h":8591102316,"f":33},{"t":1167724,"n":"Peer2Peer","d":1167724,"h":12886069612,"f":33},{"t":1167724,"n":"Mixed","d":1167724,"h":17181036908,"f":33},{"t":1167724,"n":"Hybrid","d":1167724,"h":21476004204,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1167724,"h":25770971500,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1167724}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetBiosNodeType`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetworkInterfaceComponent", ($self) => class NetworkInterfaceComponent extends $.$spc.System.Enum
        {
            static IPv4 = 0;
            static IPv6 = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "IPv4": 0n,
                    "IPv6": 1n
                };
            }
            static $h = 1626476;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1626476,"n":"IPv4","d":1626476,"h":4296593772,"f":33},{"t":1626476,"n":"IPv6","d":1626476,"h":8591561068,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1626476,"h":12886528364,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1626476}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterfaceComponent`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetworkInterfaceType", ($self) => class NetworkInterfaceType extends $.$spc.System.Enum
        {
            static Unknown = 1;
            static Ethernet = 6;
            static TokenRing = 9;
            static Fddi = 15;
            static BasicIsdn = 20;
            static PrimaryIsdn = 21;
            static Ppp = 23;
            static Loopback = 24;
            static Ethernet3Megabit = 26;
            static Slip = 28;
            static Atm = 37;
            static GenericModem = 48;
            static FastEthernetT = 62;
            static Isdn = 63;
            static FastEthernetFx = 69;
            static Wireless80211 = 71;
            static AsymmetricDsl = 94;
            static RateAdaptDsl = 95;
            static SymmetricDsl = 96;
            static VeryHighSpeedDsl = 97;
            static IPOverAtm = 114;
            static GigabitEthernet = 117;
            static Tunnel = 131;
            static MultiRateSymmetricDsl = 143;
            static HighPerformanceSerialBus = 144;
            static Wman = 237;
            static Wwanpp = 243;
            static Wwanpp2 = 244;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 1n,
                    "Ethernet": 6n,
                    "TokenRing": 9n,
                    "Fddi": 15n,
                    "BasicIsdn": 20n,
                    "PrimaryIsdn": 21n,
                    "Ppp": 23n,
                    "Loopback": 24n,
                    "Ethernet3Megabit": 26n,
                    "Slip": 28n,
                    "Atm": 37n,
                    "GenericModem": 48n,
                    "FastEthernetT": 62n,
                    "Isdn": 63n,
                    "FastEthernetFx": 69n,
                    "Wireless80211": 71n,
                    "AsymmetricDsl": 94n,
                    "RateAdaptDsl": 95n,
                    "SymmetricDsl": 96n,
                    "VeryHighSpeedDsl": 97n,
                    "IPOverAtm": 114n,
                    "GigabitEthernet": 117n,
                    "Tunnel": 131n,
                    "MultiRateSymmetricDsl": 143n,
                    "HighPerformanceSerialBus": 144n,
                    "Wman": 237n,
                    "Wwanpp": 243n,
                    "Wwanpp2": 244n
                };
            }
            static $h = 1692012;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1692012,"n":"Unknown","d":1692012,"h":4296659308,"f":33},{"t":1692012,"n":"Ethernet","d":1692012,"h":8591626604,"f":33},{"t":1692012,"n":"TokenRing","d":1692012,"h":12886593900,"f":33},{"t":1692012,"n":"Fddi","d":1692012,"h":17181561196,"f":33},{"t":1692012,"n":"BasicIsdn","d":1692012,"h":21476528492,"f":33},{"t":1692012,"n":"PrimaryIsdn","d":1692012,"h":25771495788,"f":33},{"t":1692012,"n":"Ppp","d":1692012,"h":30066463084,"f":33},{"t":1692012,"n":"Loopback","d":1692012,"h":34361430380,"f":33},{"t":1692012,"n":"Ethernet3Megabit","d":1692012,"h":38656397676,"f":33},{"t":1692012,"n":"Slip","d":1692012,"h":42951364972,"f":33},{"t":1692012,"n":"Atm","d":1692012,"h":47246332268,"f":33},{"t":1692012,"n":"GenericModem","d":1692012,"h":51541299564,"f":33},{"t":1692012,"n":"FastEthernetT","d":1692012,"h":55836266860,"f":33},{"t":1692012,"n":"Isdn","d":1692012,"h":60131234156,"f":33},{"t":1692012,"n":"FastEthernetFx","d":1692012,"h":64426201452,"f":33},{"t":1692012,"n":"Wireless80211","d":1692012,"h":68721168748,"f":33},{"t":1692012,"n":"AsymmetricDsl","d":1692012,"h":73016136044,"f":33},{"t":1692012,"n":"RateAdaptDsl","d":1692012,"h":77311103340,"f":33},{"t":1692012,"n":"SymmetricDsl","d":1692012,"h":81606070636,"f":33},{"t":1692012,"n":"VeryHighSpeedDsl","d":1692012,"h":85901037932,"f":33},{"t":1692012,"n":"IPOverAtm","d":1692012,"h":90196005228,"f":33},{"t":1692012,"n":"GigabitEthernet","d":1692012,"h":94490972524,"f":33},{"t":1692012,"n":"Tunnel","d":1692012,"h":98785939820,"f":33},{"t":1692012,"n":"MultiRateSymmetricDsl","d":1692012,"h":103080907116,"f":33},{"t":1692012,"n":"HighPerformanceSerialBus","d":1692012,"h":107375874412,"f":33},{"t":1692012,"n":"Wman","d":1692012,"h":111670841708,"f":33},{"t":1692012,"n":"Wwanpp","d":1692012,"h":115965809004,"f":33},{"t":1692012,"n":"Wwanpp2","d":1692012,"h":120260776300,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1692012,"h":124555743596,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1692012}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterfaceType`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.OperationalStatus", ($self) => class OperationalStatus extends $.$spc.System.Enum
        {
            static Up = 1;
            static Down = 2;
            static Testing = 3;
            static Unknown = 4;
            static Dormant = 5;
            static NotPresent = 6;
            static LowerLayerDown = 7;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Up": 1n,
                    "Down": 2n,
                    "Testing": 3n,
                    "Unknown": 4n,
                    "Dormant": 5n,
                    "NotPresent": 6n,
                    "LowerLayerDown": 7n
                };
            }
            static $h = 1757548;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1757548,"n":"Up","d":1757548,"h":4296724844,"f":33},{"t":1757548,"n":"Down","d":1757548,"h":8591692140,"f":33},{"t":1757548,"n":"Testing","d":1757548,"h":12886659436,"f":33},{"t":1757548,"n":"Unknown","d":1757548,"h":17181626732,"f":33},{"t":1757548,"n":"Dormant","d":1757548,"h":21476594028,"f":33},{"t":1757548,"n":"NotPresent","d":1757548,"h":25771561324,"f":33},{"t":1757548,"n":"LowerLayerDown","d":1757548,"h":30066528620,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1757548,"h":34361495916,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1757548}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.OperationalStatus`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.PrefixOrigin", ($self) => class PrefixOrigin extends $.$spc.System.Enum
        {
            static Other = 0;
            static Manual = 1;
            static WellKnown = 2;
            static Dhcp = 3;
            static RouterAdvertisement = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Other": 0n,
                    "Manual": 1n,
                    "WellKnown": 2n,
                    "Dhcp": 3n,
                    "RouterAdvertisement": 4n
                };
            }
            static $h = 1888620;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1888620,"n":"Other","d":1888620,"h":4296855916,"f":33},{"t":1888620,"n":"Manual","d":1888620,"h":8591823212,"f":33},{"t":1888620,"n":"WellKnown","d":1888620,"h":12886790508,"f":33},{"t":1888620,"n":"Dhcp","d":1888620,"h":17181757804,"f":33},{"t":1888620,"n":"RouterAdvertisement","d":1888620,"h":21476725100,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1888620,"h":25771692396,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1888620}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.PrefixOrigin`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.ScopeLevel", ($self) => class ScopeLevel extends $.$spc.System.Enum
        {
            static None = 0;
            static Interface = 1;
            static Link = 2;
            static Subnet = 3;
            static Admin = 4;
            static Site = 5;
            static Organization = 8;
            static Global = 14;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Interface": 1n,
                    "Link": 2n,
                    "Subnet": 3n,
                    "Admin": 4n,
                    "Site": 5n,
                    "Organization": 8n,
                    "Global": 14n
                };
            }
            static $h = 1954156;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1954156,"n":"None","d":1954156,"h":4296921452,"f":33},{"t":1954156,"n":"Interface","d":1954156,"h":8591888748,"f":33},{"t":1954156,"n":"Link","d":1954156,"h":12886856044,"f":33},{"t":1954156,"n":"Subnet","d":1954156,"h":17181823340,"f":33},{"t":1954156,"n":"Admin","d":1954156,"h":21476790636,"f":33},{"t":1954156,"n":"Site","d":1954156,"h":25771757932,"f":33},{"t":1954156,"n":"Organization","d":1954156,"h":30066725228,"f":33},{"t":1954156,"n":"Global","d":1954156,"h":34361692524,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1954156,"h":38656659820,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1954156}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.ScopeLevel`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.SuffixOrigin", ($self) => class SuffixOrigin extends $.$spc.System.Enum
        {
            static Other = 0;
            static Manual = 1;
            static WellKnown = 2;
            static OriginDhcp = 3;
            static LinkLayerAddress = 4;
            static Random = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Other": 0n,
                    "Manual": 1n,
                    "WellKnown": 2n,
                    "OriginDhcp": 3n,
                    "LinkLayerAddress": 4n,
                    "Random": 5n
                };
            }
            static $h = 2019692;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2019692,"n":"Other","d":2019692,"h":4296986988,"f":33},{"t":2019692,"n":"Manual","d":2019692,"h":8591954284,"f":33},{"t":2019692,"n":"WellKnown","d":2019692,"h":12886921580,"f":33},{"t":2019692,"n":"OriginDhcp","d":2019692,"h":17181888876,"f":33},{"t":2019692,"n":"LinkLayerAddress","d":2019692,"h":21476856172,"f":33},{"t":2019692,"n":"Random","d":2019692,"h":25771823468,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2019692,"h":30066790764,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2019692}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.SuffixOrigin`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.TcpState", ($self) => class TcpState extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Closed = 1;
            static Listen = 2;
            static SynSent = 3;
            static SynReceived = 4;
            static Established = 5;
            static FinWait1 = 6;
            static FinWait2 = 7;
            static CloseWait = 8;
            static Closing = 9;
            static LastAck = 10;
            static TimeWait = 11;
            static DeleteTcb = 12;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Closed": 1n,
                    "Listen": 2n,
                    "SynSent": 3n,
                    "SynReceived": 4n,
                    "Established": 5n,
                    "FinWait1": 6n,
                    "FinWait2": 7n,
                    "CloseWait": 8n,
                    "Closing": 9n,
                    "LastAck": 10n,
                    "TimeWait": 11n,
                    "DeleteTcb": 12n
                };
            }
            static $h = 2150764;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2150764,"n":"Unknown","d":2150764,"h":4297118060,"f":33},{"t":2150764,"n":"Closed","d":2150764,"h":8592085356,"f":33},{"t":2150764,"n":"Listen","d":2150764,"h":12887052652,"f":33},{"t":2150764,"n":"SynSent","d":2150764,"h":17182019948,"f":33},{"t":2150764,"n":"SynReceived","d":2150764,"h":21476987244,"f":33},{"t":2150764,"n":"Established","d":2150764,"h":25771954540,"f":33},{"t":2150764,"n":"FinWait1","d":2150764,"h":30066921836,"f":33},{"t":2150764,"n":"FinWait2","d":2150764,"h":34361889132,"f":33},{"t":2150764,"n":"CloseWait","d":2150764,"h":38656856428,"f":33},{"t":2150764,"n":"Closing","d":2150764,"h":42951823724,"f":33},{"t":2150764,"n":"LastAck","d":2150764,"h":47246791020,"f":33},{"t":2150764,"n":"TimeWait","d":2150764,"h":51541758316,"f":33},{"t":2150764,"n":"DeleteTcb","d":2150764,"h":55836725612,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2150764,"h":60131692908,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2150764}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpState`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAvailabilityEventArgs", ($self) => class NetworkAvailabilityEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ get IsAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1364332;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886266220,"f":1},"n":"IsAvailable","d":1364332,"h":8591298924,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1364332,"h":4296331628,"f":8}],"h":1364332}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAvailabilityEventArgs`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkInformationException", ($self) => class NetworkInformationException extends $.$spc.System.ComponentModel.Win32Exception
        {
            $ctor$20()
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            $ctor$21(/*int*/ errorCode)
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            $ctor$22(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            /*int */ get ErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1495404;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":33357825,"h":1495404}; }
            static get $b() { return $.$spc.System.ComponentModel.Win32Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInformationException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets"))