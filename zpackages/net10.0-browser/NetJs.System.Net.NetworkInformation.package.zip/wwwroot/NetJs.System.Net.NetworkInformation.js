
//--TRIMMABLE-BOUNDARY-START(52)
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stee, $scsl, $snv, $sri, $sl, $stt, $sttp, $sdd, $snp, $ssc, $sspw, $sto, $snnr, $sns) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.NetworkInformation", 
    {
  "h": 52,
  "f": "System.Net.NetworkInformation",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 159252481,
      "c": 13044154369,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106430465,
      "c": 8696365057,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106496001,
      "c": 8696430593,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 106954753,
      "c": 8696889345,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107085825,
      "c": 8697020417,
      "a": [
        {
          "v": "1.0.35\u002Bdf6f45b09d58f65c84d384efc8772929a0c6464b",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107937793,
      "c": 8697872385,
      "a": [
        {
          "v": "NetJs.System.Net.NetworkInformation",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108068865,
      "c": 8698003457,
      "a": [
        {
          "v": "NetJs.System.Net.NetworkInformation",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108199937,
      "c": 8698134529,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159318017,
      "c": 4454285313,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159055873,
      "c": 4454023169,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(131124)
        $asm.$cls("$snn.System.Net.NetworkInformation.GatewayIPAddressInformation", ($self) => class GatewayIPAddressInformation extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295098420)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295098420);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098420)
            
            static $h = 131124;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590065716),
    {
      "p": 3014703,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180000308,
        "f": 50331905
      },
      "n": "Address",
      "d": 131124,
      "h": 8590065716,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590065716)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098420),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131124,
      "h": 4295098420,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295098420)
  ],
  "h": 131124
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.GatewayIPAddressInformation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131124)
        
        
        //--TRIMMABLE-BOUNDARY-START(262196)
        $asm.$cls("$snn.System.Net.NetworkInformation.IcmpV4Statistics", ($self) => class IcmpV4Statistics extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295229492)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229492);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229492)
            
            static $h = 262196;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590196788),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424771636,
        "f": 50331905
      },
      "n": "AddressMaskRepliesReceived",
      "d": 262196,
      "h": 8590196788,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590196788),
//--TRIMMABLE-BOUNDARY-START(12885164084),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014706228,
        "f": 50331905
      },
      "n": "AddressMaskRepliesSent",
      "d": 262196,
      "h": 12885164084,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885164084),
//--TRIMMABLE-BOUNDARY-START(17180131380),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604640820,
        "f": 50331905
      },
      "n": "AddressMaskRequestsReceived",
      "d": 262196,
      "h": 17180131380,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180131380),
//--TRIMMABLE-BOUNDARY-START(21475098676),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194575412,
        "f": 50331905
      },
      "n": "AddressMaskRequestsSent",
      "d": 262196,
      "h": 21475098676,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21475098676),
//--TRIMMABLE-BOUNDARY-START(25770065972),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784510004,
        "f": 50331905
      },
      "n": "DestinationUnreachableMessagesReceived",
      "d": 262196,
      "h": 25770065972,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25770065972),
//--TRIMMABLE-BOUNDARY-START(30065033268),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374444596,
        "f": 50331905
      },
      "n": "DestinationUnreachableMessagesSent",
      "d": 262196,
      "h": 30065033268,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30065033268),
//--TRIMMABLE-BOUNDARY-START(34360000564),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964379188,
        "f": 50331905
      },
      "n": "EchoRepliesReceived",
      "d": 262196,
      "h": 34360000564,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34360000564),
//--TRIMMABLE-BOUNDARY-START(38654967860),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554313780,
        "f": 50331905
      },
      "n": "EchoRepliesSent",
      "d": 262196,
      "h": 38654967860,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38654967860),
//--TRIMMABLE-BOUNDARY-START(42949935156),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144248372,
        "f": 50331905
      },
      "n": "EchoRequestsReceived",
      "d": 262196,
      "h": 42949935156,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(42949935156),
//--TRIMMABLE-BOUNDARY-START(47244902452),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734182964,
        "f": 50331905
      },
      "n": "EchoRequestsSent",
      "d": 262196,
      "h": 47244902452,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(47244902452),
//--TRIMMABLE-BOUNDARY-START(51539869748),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324117556,
        "f": 50331905
      },
      "n": "ErrorsReceived",
      "d": 262196,
      "h": 51539869748,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "freebsd",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51539869748),
//--TRIMMABLE-BOUNDARY-START(55834837044),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914052148,
        "f": 50331905
      },
      "n": "ErrorsSent",
      "d": 262196,
      "h": 55834837044,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "freebsd",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55834837044),
//--TRIMMABLE-BOUNDARY-START(283468103732),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167503986740,
        "f": 50331905
      },
      "n": "MessagesReceived",
      "d": 262196,
      "h": 283468103732,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "freebsd",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(283468103732),
//--TRIMMABLE-BOUNDARY-START(287763071028),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176093921332,
        "f": 50331905
      },
      "n": "MessagesSent",
      "d": 262196,
      "h": 287763071028,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "freebsd",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(287763071028),
//--TRIMMABLE-BOUNDARY-START(292058038324),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184683855924,
        "f": 50331905
      },
      "n": "ParameterProblemsReceived",
      "d": 262196,
      "h": 292058038324,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(292058038324),
//--TRIMMABLE-BOUNDARY-START(296353005620),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193273790516,
        "f": 50331905
      },
      "n": "ParameterProblemsSent",
      "d": 262196,
      "h": 296353005620,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(296353005620),
//--TRIMMABLE-BOUNDARY-START(300647972916),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201863725108,
        "f": 50331905
      },
      "n": "RedirectsReceived",
      "d": 262196,
      "h": 300647972916,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(300647972916),
//--TRIMMABLE-BOUNDARY-START(304942940212),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210453659700,
        "f": 50331905
      },
      "n": "RedirectsSent",
      "d": 262196,
      "h": 304942940212,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(304942940212),
//--TRIMMABLE-BOUNDARY-START(309237907508),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219043594292,
        "f": 50331905
      },
      "n": "SourceQuenchesReceived",
      "d": 262196,
      "h": 309237907508,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(309237907508),
//--TRIMMABLE-BOUNDARY-START(313532874804),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227633528884,
        "f": 50331905
      },
      "n": "SourceQuenchesSent",
      "d": 262196,
      "h": 313532874804,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(313532874804),
//--TRIMMABLE-BOUNDARY-START(317827842100),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236223463476,
        "f": 50331905
      },
      "n": "TimeExceededMessagesReceived",
      "d": 262196,
      "h": 317827842100,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(317827842100),
//--TRIMMABLE-BOUNDARY-START(322122809396),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244813398068,
        "f": 50331905
      },
      "n": "TimeExceededMessagesSent",
      "d": 262196,
      "h": 322122809396,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(322122809396),
//--TRIMMABLE-BOUNDARY-START(326417776692),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253403332660,
        "f": 50331905
      },
      "n": "TimestampRepliesReceived",
      "d": 262196,
      "h": 326417776692,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(326417776692),
//--TRIMMABLE-BOUNDARY-START(330712743988),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261993267252,
        "f": 50331905
      },
      "n": "TimestampRepliesSent",
      "d": 262196,
      "h": 330712743988,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(330712743988),
//--TRIMMABLE-BOUNDARY-START(335007711284),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270583201844,
        "f": 50331905
      },
      "n": "TimestampRequestsReceived",
      "d": 262196,
      "h": 335007711284,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(335007711284),
//--TRIMMABLE-BOUNDARY-START(339302678580),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279173136436,
        "f": 50331905
      },
      "n": "TimestampRequestsSent",
      "d": 262196,
      "h": 339302678580,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(339302678580)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229492),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262196,
      "h": 4295229492,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295229492)
  ],
  "h": 262196
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IcmpV4Statistics`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262196)
        
        
        //--TRIMMABLE-BOUNDARY-START(327732)
        $asm.$cls("$snn.System.Net.NetworkInformation.IcmpV6Statistics", ($self) => class IcmpV6Statistics extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295295028)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295295028);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295028)
            
            static $h = 327732;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590262324),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244967988,
        "f": 50331905
      },
      "n": "DestinationUnreachableMessagesReceived",
      "d": 327732,
      "h": 8590262324,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590262324),
//--TRIMMABLE-BOUNDARY-START(12885229620),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834902580,
        "f": 50331905
      },
      "n": "DestinationUnreachableMessagesSent",
      "d": 327732,
      "h": 12885229620,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885229620),
//--TRIMMABLE-BOUNDARY-START(17180196916),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424837172,
        "f": 50331905
      },
      "n": "EchoRepliesReceived",
      "d": 327732,
      "h": 17180196916,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180196916),
//--TRIMMABLE-BOUNDARY-START(21475164212),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014771764,
        "f": 50331905
      },
      "n": "EchoRepliesSent",
      "d": 327732,
      "h": 21475164212,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21475164212),
//--TRIMMABLE-BOUNDARY-START(25770131508),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604706356,
        "f": 50331905
      },
      "n": "EchoRequestsReceived",
      "d": 327732,
      "h": 25770131508,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25770131508),
//--TRIMMABLE-BOUNDARY-START(30065098804),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194640948,
        "f": 50331905
      },
      "n": "EchoRequestsSent",
      "d": 327732,
      "h": 30065098804,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30065098804),
//--TRIMMABLE-BOUNDARY-START(34360066100),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784575540,
        "f": 50331905
      },
      "n": "ErrorsReceived",
      "d": 327732,
      "h": 34360066100,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "freebsd",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360066100),
//--TRIMMABLE-BOUNDARY-START(38655033396),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374510132,
        "f": 50331905
      },
      "n": "ErrorsSent",
      "d": 327732,
      "h": 38655033396,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "freebsd",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655033396),
//--TRIMMABLE-BOUNDARY-START(317827907636),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964444724,
        "f": 50331905
      },
      "n": "MembershipQueriesReceived",
      "d": 327732,
      "h": 317827907636,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(317827907636),
//--TRIMMABLE-BOUNDARY-START(322122874932),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554379316,
        "f": 50331905
      },
      "n": "MembershipQueriesSent",
      "d": 327732,
      "h": 322122874932,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(322122874932),
//--TRIMMABLE-BOUNDARY-START(326417842228),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144313908,
        "f": 50331905
      },
      "n": "MembershipReductionsReceived",
      "d": 327732,
      "h": 326417842228,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(326417842228),
//--TRIMMABLE-BOUNDARY-START(330712809524),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734248500,
        "f": 50331905
      },
      "n": "MembershipReductionsSent",
      "d": 327732,
      "h": 330712809524,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(330712809524),
//--TRIMMABLE-BOUNDARY-START(335007776820),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324183092,
        "f": 50331905
      },
      "n": "MembershipReportsReceived",
      "d": 327732,
      "h": 335007776820,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(335007776820),
//--TRIMMABLE-BOUNDARY-START(339302744116),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914117684,
        "f": 50331905
      },
      "n": "MembershipReportsSent",
      "d": 327732,
      "h": 339302744116,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(339302744116),
//--TRIMMABLE-BOUNDARY-START(343597711412),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504052276,
        "f": 50331905
      },
      "n": "MessagesReceived",
      "d": 327732,
      "h": 343597711412,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "freebsd",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(343597711412),
//--TRIMMABLE-BOUNDARY-START(347892678708),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176093986868,
        "f": 50331905
      },
      "n": "MessagesSent",
      "d": 327732,
      "h": 347892678708,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "freebsd",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(347892678708),
//--TRIMMABLE-BOUNDARY-START(352187646004),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184683921460,
        "f": 50331905
      },
      "n": "NeighborAdvertisementsReceived",
      "d": 327732,
      "h": 352187646004,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(352187646004),
//--TRIMMABLE-BOUNDARY-START(356482613300),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193273856052,
        "f": 50331905
      },
      "n": "NeighborAdvertisementsSent",
      "d": 327732,
      "h": 356482613300,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(356482613300),
//--TRIMMABLE-BOUNDARY-START(360777580596),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201863790644,
        "f": 50331905
      },
      "n": "NeighborSolicitsReceived",
      "d": 327732,
      "h": 360777580596,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(360777580596),
//--TRIMMABLE-BOUNDARY-START(365072547892),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210453725236,
        "f": 50331905
      },
      "n": "NeighborSolicitsSent",
      "d": 327732,
      "h": 365072547892,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(365072547892),
//--TRIMMABLE-BOUNDARY-START(369367515188),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219043659828,
        "f": 50331905
      },
      "n": "PacketTooBigMessagesReceived",
      "d": 327732,
      "h": 369367515188,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(369367515188),
//--TRIMMABLE-BOUNDARY-START(373662482484),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227633594420,
        "f": 50331905
      },
      "n": "PacketTooBigMessagesSent",
      "d": 327732,
      "h": 373662482484,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(373662482484),
//--TRIMMABLE-BOUNDARY-START(377957449780),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236223529012,
        "f": 50331905
      },
      "n": "ParameterProblemsReceived",
      "d": 327732,
      "h": 377957449780,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(377957449780),
//--TRIMMABLE-BOUNDARY-START(382252417076),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244813463604,
        "f": 50331905
      },
      "n": "ParameterProblemsSent",
      "d": 327732,
      "h": 382252417076,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(382252417076),
//--TRIMMABLE-BOUNDARY-START(386547384372),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253403398196,
        "f": 50331905
      },
      "n": "RedirectsReceived",
      "d": 327732,
      "h": 386547384372,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(386547384372),
//--TRIMMABLE-BOUNDARY-START(390842351668),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261993332788,
        "f": 50331905
      },
      "n": "RedirectsSent",
      "d": 327732,
      "h": 390842351668,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(390842351668),
//--TRIMMABLE-BOUNDARY-START(395137318964),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270583267380,
        "f": 50331905
      },
      "n": "RouterAdvertisementsReceived",
      "d": 327732,
      "h": 395137318964,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(395137318964),
//--TRIMMABLE-BOUNDARY-START(399432286260),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279173201972,
        "f": 50331905
      },
      "n": "RouterAdvertisementsSent",
      "d": 327732,
      "h": 399432286260,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(399432286260),
//--TRIMMABLE-BOUNDARY-START(403727253556),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287763136564,
        "f": 50331905
      },
      "n": "RouterSolicitsReceived",
      "d": 327732,
      "h": 403727253556,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(403727253556),
//--TRIMMABLE-BOUNDARY-START(408022220852),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 296353071156,
        "f": 50331905
      },
      "n": "RouterSolicitsSent",
      "d": 327732,
      "h": 408022220852,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(408022220852),
//--TRIMMABLE-BOUNDARY-START(412317188148),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304943005748,
        "f": 50331905
      },
      "n": "TimeExceededMessagesReceived",
      "d": 327732,
      "h": 412317188148,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(412317188148),
//--TRIMMABLE-BOUNDARY-START(416612155444),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 313532940340,
        "f": 50331905
      },
      "n": "TimeExceededMessagesSent",
      "d": 327732,
      "h": 416612155444,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(416612155444)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295028),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327732,
      "h": 4295295028,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295295028)
  ],
  "h": 327732
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IcmpV6Statistics`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327732)
        
        
        //--TRIMMABLE-BOUNDARY-START(393268)
        $asm.$cls("$snn.System.Net.NetworkInformation.IPAddressInformation", ($self) => class IPAddressInformation extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295360564)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360564);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360564)
            
            static $h = 393268;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590327860),
    {
      "p": 3014703,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180262452,
        "f": 50331905
      },
      "n": "Address",
      "d": 393268,
      "h": 8590327860,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590327860),
//--TRIMMABLE-BOUNDARY-START(38655098932),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770197044,
        "f": 50331905
      },
      "n": "IsDnsEligible",
      "d": 393268,
      "h": 38655098932,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(38655098932),
//--TRIMMABLE-BOUNDARY-START(42950066228),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360131636,
        "f": 50331905
      },
      "n": "IsTransient",
      "d": 393268,
      "h": 42950066228,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(42950066228)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360564),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393268,
      "h": 4295360564,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295360564)
  ],
  "h": 393268
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressInformation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393268)
        
        
        //--TRIMMABLE-BOUNDARY-START(524340)
        $asm.$cls("$snn.System.Net.NetworkInformation.IPGlobalProperties", ($self) => class IPGlobalProperties extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295491636)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295491636);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491636)
            
            //--TRIMMABLE-BOUNDARY-START(8590458932)
            /*System.IAsyncResult */ BeginGetUnicastAddresses(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590458932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590458932)
            
            //--TRIMMABLE-BOUNDARY-START(21475360820)
            /*System.Net.NetworkInformation.UnicastIPAddressInformationCollection */ EndGetUnicastAddresses(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360820);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475360820)
            
            //--TRIMMABLE-BOUNDARY-START(90194837556)
            static /*System.Net.NetworkInformation.IPGlobalProperties */ GetIPGlobalProperties()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194837556);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90194837556)
            
            //--TRIMMABLE-BOUNDARY-START(120259608628)
            /*System.Net.NetworkInformation.UnicastIPAddressInformationCollection */ GetUnicastAddresses()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259608628);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120259608628)
            
            //--TRIMMABLE-BOUNDARY-START(124554575924)
            /*System.Threading.Tasks.Task<System.Net.NetworkInformation.UnicastIPAddressInformationCollection> */ GetUnicastAddressesAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554575924);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(124554575924)
            
            static $h = 524340;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885426228),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065295412,
        "f": 50331905
      },
      "n": "DhcpScopeName",
      "d": 524340,
      "h": 12885426228,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885426228),
//--TRIMMABLE-BOUNDARY-START(17180393524),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655230004,
        "f": 50331905
      },
      "n": "DomainName",
      "d": 524340,
      "h": 17180393524,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17180393524),
//--TRIMMABLE-BOUNDARY-START(128849543220),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245164596,
        "f": 50331905
      },
      "n": "HostName",
      "d": 524340,
      "h": 128849543220,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(128849543220),
//--TRIMMABLE-BOUNDARY-START(133144510516),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835099188,
        "f": 50331905
      },
      "n": "IsWinsProxy",
      "d": 524340,
      "h": 133144510516,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(133144510516),
//--TRIMMABLE-BOUNDARY-START(137439477812),
    {
      "p": 1114164,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425033780,
        "f": 50331905
      },
      "n": "NodeType",
      "d": 524340,
      "h": 137439477812,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(137439477812)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590458932),
    {
      "r": 89784321,
      "p": [
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginGetUnicastAddresses",
      "d": 524340,
      "h": 8590458932,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590458932),
//--TRIMMABLE-BOUNDARY-START(21475360820),
    {
      "r": 2359348,
      "p": [
        {
          "n": "asyncResult",
          "p": 89784321
        }
      ],
      "n": "EndGetUnicastAddresses",
      "d": 524340,
      "h": 21475360820,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475360820),
//--TRIMMABLE-BOUNDARY-START(68720001076),
    {
      "r": $.$typeArray($.$snn.System.Net.NetworkInformation.TcpConnectionInformation).$h,
      "n": "GetActiveTcpConnections",
      "d": 524340,
      "h": 68720001076,
      "f": 16777473,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(68720001076),
//--TRIMMABLE-BOUNDARY-START(73014968372),
    {
      "r": $.$typeArray($.$snp.System.Net.IPEndPoint).$h,
      "n": "GetActiveTcpListeners",
      "d": 524340,
      "h": 73014968372,
      "f": 16777473,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73014968372),
//--TRIMMABLE-BOUNDARY-START(77309935668),
    {
      "r": $.$typeArray($.$snp.System.Net.IPEndPoint).$h,
      "n": "GetActiveUdpListeners",
      "d": 524340,
      "h": 77309935668,
      "f": 16777473,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77309935668),
//--TRIMMABLE-BOUNDARY-START(81604902964),
    {
      "r": 262196,
      "n": "GetIcmpV4Statistics",
      "d": 524340,
      "h": 81604902964,
      "f": 16777473,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81604902964),
//--TRIMMABLE-BOUNDARY-START(85899870260),
    {
      "r": 327732,
      "n": "GetIcmpV6Statistics",
      "d": 524340,
      "h": 85899870260,
      "f": 16777473,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85899870260),
//--TRIMMABLE-BOUNDARY-START(90194837556),
    {
      "r": 524340,
      "n": "GetIPGlobalProperties",
      "d": 524340,
      "h": 90194837556,
      "f": 16777249,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "illumos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "solaris",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(90194837556),
//--TRIMMABLE-BOUNDARY-START(94489804852),
    {
      "r": 589876,
      "n": "GetIPv4GlobalStatistics",
      "d": 524340,
      "h": 94489804852,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(94489804852),
//--TRIMMABLE-BOUNDARY-START(98784772148),
    {
      "r": 589876,
      "n": "GetIPv6GlobalStatistics",
      "d": 524340,
      "h": 98784772148,
      "f": 16777473,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "freebsd",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98784772148),
//--TRIMMABLE-BOUNDARY-START(103079739444),
    {
      "r": 2162740,
      "n": "GetTcpIPv4Statistics",
      "d": 524340,
      "h": 103079739444,
      "f": 16777473,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103079739444),
//--TRIMMABLE-BOUNDARY-START(107374706740),
    {
      "r": 2162740,
      "n": "GetTcpIPv6Statistics",
      "d": 524340,
      "h": 107374706740,
      "f": 16777473,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107374706740),
//--TRIMMABLE-BOUNDARY-START(111669674036),
    {
      "r": 2228276,
      "n": "GetUdpIPv4Statistics",
      "d": 524340,
      "h": 111669674036,
      "f": 16777473,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111669674036),
//--TRIMMABLE-BOUNDARY-START(115964641332),
    {
      "r": 2228276,
      "n": "GetUdpIPv6Statistics",
      "d": 524340,
      "h": 115964641332,
      "f": 16777473,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115964641332),
//--TRIMMABLE-BOUNDARY-START(120259608628),
    {
      "r": 2359348,
      "n": "GetUnicastAddresses",
      "d": 524340,
      "h": 120259608628,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(120259608628),
//--TRIMMABLE-BOUNDARY-START(124554575924),
    {
      "r": $.$$.System.Threading.Tasks.Task$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformationCollection).$h,
      "n": "GetUnicastAddressesAsync",
      "d": 524340,
      "h": 124554575924,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(124554575924)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491636),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524340,
      "h": 4295491636,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295491636)
  ],
  "h": 524340
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPGlobalProperties`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524340)
        
        
        //--TRIMMABLE-BOUNDARY-START(589876)
        $asm.$cls("$snn.System.Net.NetworkInformation.IPGlobalStatistics", ($self) => class IPGlobalStatistics extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295557172)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295557172);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557172)
            
            static $h = 589876;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590524468),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475426356,
        "f": 50331905
      },
      "n": "DefaultTtl",
      "d": 589876,
      "h": 8590524468,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590524468),
//--TRIMMABLE-BOUNDARY-START(12885491764),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065360948,
        "f": 50331905
      },
      "n": "ForwardingEnabled",
      "d": 589876,
      "h": 12885491764,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885491764),
//--TRIMMABLE-BOUNDARY-START(206159020084),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655295540,
        "f": 50331905
      },
      "n": "NumberOfInterfaces",
      "d": 589876,
      "h": 206159020084,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(206159020084),
//--TRIMMABLE-BOUNDARY-START(210453987380),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245230132,
        "f": 50331905
      },
      "n": "NumberOfIPAddresses",
      "d": 589876,
      "h": 210453987380,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(210453987380),
//--TRIMMABLE-BOUNDARY-START(214748954676),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835164724,
        "f": 50331905
      },
      "n": "NumberOfRoutes",
      "d": 589876,
      "h": 214748954676,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(214748954676),
//--TRIMMABLE-BOUNDARY-START(219043921972),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425099316,
        "f": 50331905
      },
      "n": "OutputPacketRequests",
      "d": 589876,
      "h": 219043921972,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(219043921972),
//--TRIMMABLE-BOUNDARY-START(223338889268),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015033908,
        "f": 50331905
      },
      "n": "OutputPacketRoutingDiscards",
      "d": 589876,
      "h": 223338889268,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(223338889268),
//--TRIMMABLE-BOUNDARY-START(227633856564),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604968500,
        "f": 50331905
      },
      "n": "OutputPacketsDiscarded",
      "d": 589876,
      "h": 227633856564,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(227633856564),
//--TRIMMABLE-BOUNDARY-START(231928823860),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194903092,
        "f": 50331905
      },
      "n": "OutputPacketsWithNoRoute",
      "d": 589876,
      "h": 231928823860,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(231928823860),
//--TRIMMABLE-BOUNDARY-START(236223791156),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784837684,
        "f": 50331905
      },
      "n": "PacketFragmentFailures",
      "d": 589876,
      "h": 236223791156,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(236223791156),
//--TRIMMABLE-BOUNDARY-START(240518758452),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374772276,
        "f": 50331905
      },
      "n": "PacketReassembliesRequired",
      "d": 589876,
      "h": 240518758452,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(240518758452),
//--TRIMMABLE-BOUNDARY-START(244813725748),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964706868,
        "f": 50331905
      },
      "n": "PacketReassemblyFailures",
      "d": 589876,
      "h": 244813725748,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(244813725748),
//--TRIMMABLE-BOUNDARY-START(249108693044),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554641460,
        "f": 50331905
      },
      "n": "PacketReassemblyTimeout",
      "d": 589876,
      "h": 249108693044,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(249108693044),
//--TRIMMABLE-BOUNDARY-START(253403660340),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144576052,
        "f": 50331905
      },
      "n": "PacketsFragmented",
      "d": 589876,
      "h": 253403660340,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(253403660340),
//--TRIMMABLE-BOUNDARY-START(257698627636),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734510644,
        "f": 50331905
      },
      "n": "PacketsReassembled",
      "d": 589876,
      "h": 257698627636,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(257698627636),
//--TRIMMABLE-BOUNDARY-START(261993594932),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324445236,
        "f": 50331905
      },
      "n": "ReceivedPackets",
      "d": 589876,
      "h": 261993594932,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(261993594932),
//--TRIMMABLE-BOUNDARY-START(266288562228),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914379828,
        "f": 50331905
      },
      "n": "ReceivedPacketsDelivered",
      "d": 589876,
      "h": 266288562228,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(266288562228),
//--TRIMMABLE-BOUNDARY-START(270583529524),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504314420,
        "f": 50331905
      },
      "n": "ReceivedPacketsDiscarded",
      "d": 589876,
      "h": 270583529524,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(270583529524),
//--TRIMMABLE-BOUNDARY-START(274878496820),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094249012,
        "f": 50331905
      },
      "n": "ReceivedPacketsForwarded",
      "d": 589876,
      "h": 274878496820,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(274878496820),
//--TRIMMABLE-BOUNDARY-START(279173464116),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684183604,
        "f": 50331905
      },
      "n": "ReceivedPacketsWithAddressErrors",
      "d": 589876,
      "h": 279173464116,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(279173464116),
//--TRIMMABLE-BOUNDARY-START(283468431412),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193274118196,
        "f": 50331905
      },
      "n": "ReceivedPacketsWithHeadersErrors",
      "d": 589876,
      "h": 283468431412,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(283468431412),
//--TRIMMABLE-BOUNDARY-START(287763398708),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201864052788,
        "f": 50331905
      },
      "n": "ReceivedPacketsWithUnknownProtocol",
      "d": 589876,
      "h": 287763398708,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(287763398708)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557172),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589876,
      "h": 4295557172,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295557172)
  ],
  "h": 589876
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPGlobalStatistics`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589876)
        
        
        //--TRIMMABLE-BOUNDARY-START(655412)
        $asm.$cls("$snn.System.Net.NetworkInformation.IPInterfaceProperties", ($self) => class IPInterfaceProperties extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295622708)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295622708);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622708)
            
            static $h = 655412;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590590004),
    {
      "p": 458804,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360393780,
        "f": 50331905
      },
      "n": "AnycastAddresses",
      "d": 655412,
      "h": 8590590004,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590590004),
//--TRIMMABLE-BOUNDARY-START(12885557300),
    {
      "p": 3997743,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950328372,
        "f": 50331905
      },
      "n": "DhcpServerAddresses",
      "d": 655412,
      "h": 12885557300,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "freebsd",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885557300),
//--TRIMMABLE-BOUNDARY-START(17180524596),
    {
      "p": 3997743,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540262964,
        "f": 50331905
      },
      "n": "DnsAddresses",
      "d": 655412,
      "h": 17180524596,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180524596),
//--TRIMMABLE-BOUNDARY-START(21475491892),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130197556,
        "f": 50331905
      },
      "n": "DnsSuffix",
      "d": 655412,
      "h": 21475491892,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475491892),
//--TRIMMABLE-BOUNDARY-START(25770459188),
    {
      "p": 196660,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720132148,
        "f": 50331905
      },
      "n": "GatewayAddresses",
      "d": 655412,
      "h": 25770459188,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770459188),
//--TRIMMABLE-BOUNDARY-START(124554706996),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310066740,
        "f": 50331905
      },
      "n": "IsDnsEnabled",
      "d": 655412,
      "h": 124554706996,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "freebsd",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(124554706996),
//--TRIMMABLE-BOUNDARY-START(128849674292),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900001332,
        "f": 50331905
      },
      "n": "IsDynamicDnsEnabled",
      "d": 655412,
      "h": 128849674292,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128849674292),
//--TRIMMABLE-BOUNDARY-START(133144641588),
    {
      "p": 1048628,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489935924,
        "f": 50331905
      },
      "n": "MulticastAddresses",
      "d": 655412,
      "h": 133144641588,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(133144641588),
//--TRIMMABLE-BOUNDARY-START(137439608884),
    {
      "p": 2359348,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079870516,
        "f": 50331905
      },
      "n": "UnicastAddresses",
      "d": 655412,
      "h": 137439608884,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(137439608884),
//--TRIMMABLE-BOUNDARY-START(141734576180),
    {
      "p": 3997743,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669805108,
        "f": 50331905
      },
      "n": "WinsServersAddresses",
      "d": 655412,
      "h": 141734576180,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "freebsd",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141734576180)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(115964772404),
    {
      "r": 786484,
      "n": "GetIPv4Properties",
      "d": 655412,
      "h": 115964772404,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(115964772404),
//--TRIMMABLE-BOUNDARY-START(120259739700),
    {
      "r": 917556,
      "n": "GetIPv6Properties",
      "d": 655412,
      "h": 120259739700,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(120259739700)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622708),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 655412,
      "h": 4295622708,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295622708)
  ],
  "h": 655412
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPInterfaceProperties`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655412)
        
        
        //--TRIMMABLE-BOUNDARY-START(720948)
        $asm.$cls("$snn.System.Net.NetworkInformation.IPInterfaceStatistics", ($self) => class IPInterfaceStatistics extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295688244)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295688244);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688244)
            
            static $h = 720948;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590655540),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475557428,
        "f": 50331905
      },
      "n": "BytesReceived",
      "d": 720948,
      "h": 8590655540,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590655540),
//--TRIMMABLE-BOUNDARY-START(12885622836),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065492020,
        "f": 50331905
      },
      "n": "BytesSent",
      "d": 720948,
      "h": 12885622836,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885622836),
//--TRIMMABLE-BOUNDARY-START(120259805236),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655426612,
        "f": 50331905
      },
      "n": "IncomingPacketsDiscarded",
      "d": 720948,
      "h": 120259805236,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(120259805236),
//--TRIMMABLE-BOUNDARY-START(124554772532),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245361204,
        "f": 50331905
      },
      "n": "IncomingPacketsWithErrors",
      "d": 720948,
      "h": 124554772532,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(124554772532),
//--TRIMMABLE-BOUNDARY-START(128849739828),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835295796,
        "f": 50331905
      },
      "n": "IncomingUnknownProtocolPackets",
      "d": 720948,
      "h": 128849739828,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "linux",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128849739828),
//--TRIMMABLE-BOUNDARY-START(133144707124),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425230388,
        "f": 50331905
      },
      "n": "NonUnicastPacketsReceived",
      "d": 720948,
      "h": 133144707124,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(133144707124),
//--TRIMMABLE-BOUNDARY-START(137439674420),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015164980,
        "f": 50331905
      },
      "n": "NonUnicastPacketsSent",
      "d": 720948,
      "h": 137439674420,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "linux",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137439674420),
//--TRIMMABLE-BOUNDARY-START(141734641716),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605099572,
        "f": 50331905
      },
      "n": "OutgoingPacketsDiscarded",
      "d": 720948,
      "h": 141734641716,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "freebsd",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141734641716),
//--TRIMMABLE-BOUNDARY-START(146029609012),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195034164,
        "f": 50331905
      },
      "n": "OutgoingPacketsWithErrors",
      "d": 720948,
      "h": 146029609012,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(146029609012),
//--TRIMMABLE-BOUNDARY-START(150324576308),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784968756,
        "f": 50331905
      },
      "n": "OutputQueueLength",
      "d": 720948,
      "h": 150324576308,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(150324576308),
//--TRIMMABLE-BOUNDARY-START(154619543604),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374903348,
        "f": 50331905
      },
      "n": "UnicastPacketsReceived",
      "d": 720948,
      "h": 154619543604,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(154619543604),
//--TRIMMABLE-BOUNDARY-START(158914510900),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964837940,
        "f": 50331905
      },
      "n": "UnicastPacketsSent",
      "d": 720948,
      "h": 158914510900,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(158914510900)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688244),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 720948,
      "h": 4295688244,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295688244)
  ],
  "h": 720948
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPInterfaceStatistics`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720948)
        
        
        //--TRIMMABLE-BOUNDARY-START(786484)
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv4InterfaceProperties", ($self) => class IPv4InterfaceProperties extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295753780)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295753780);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295753780)
            
            static $h = 786484;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720263220),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885688372,
        "f": 50331905
      },
      "n": "Index",
      "d": 786484,
      "h": 68720263220,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(68720263220),
//--TRIMMABLE-BOUNDARY-START(73015230516),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475622964,
        "f": 50331905
      },
      "n": "IsAutomaticPrivateAddressingActive",
      "d": 786484,
      "h": 73015230516,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(73015230516),
//--TRIMMABLE-BOUNDARY-START(77310197812),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065557556,
        "f": 50331905
      },
      "n": "IsAutomaticPrivateAddressingEnabled",
      "d": 786484,
      "h": 77310197812,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310197812),
//--TRIMMABLE-BOUNDARY-START(81605165108),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655492148,
        "f": 50331905
      },
      "n": "IsDhcpEnabled",
      "d": 786484,
      "h": 81605165108,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605165108),
//--TRIMMABLE-BOUNDARY-START(85900132404),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245426740,
        "f": 50331905
      },
      "n": "IsForwardingEnabled",
      "d": 786484,
      "h": 85900132404,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "linux",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(85900132404),
//--TRIMMABLE-BOUNDARY-START(90195099700),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835361332,
        "f": 50331905
      },
      "n": "Mtu",
      "d": 786484,
      "h": 90195099700,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(90195099700),
//--TRIMMABLE-BOUNDARY-START(94490066996),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425295924,
        "f": 50331905
      },
      "n": "UsesWins",
      "d": 786484,
      "h": 94490066996,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "linux",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94490066996)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753780),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786484,
      "h": 4295753780,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295753780)
  ],
  "h": 786484
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv4InterfaceProperties`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786484)
        
        
        //--TRIMMABLE-BOUNDARY-START(852020)
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv4InterfaceStatistics", ($self) => class IPv4InterfaceStatistics extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295819316)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295819316);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295819316)
            
            static $h = 852020;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590786612),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475688500,
        "f": 50331905
      },
      "n": "BytesReceived",
      "d": 852020,
      "h": 8590786612,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590786612),
//--TRIMMABLE-BOUNDARY-START(12885753908),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065623092,
        "f": 50331905
      },
      "n": "BytesSent",
      "d": 852020,
      "h": 12885753908,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885753908),
//--TRIMMABLE-BOUNDARY-START(120259936308),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655557684,
        "f": 50331905
      },
      "n": "IncomingPacketsDiscarded",
      "d": 852020,
      "h": 120259936308,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(120259936308),
//--TRIMMABLE-BOUNDARY-START(124554903604),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245492276,
        "f": 50331905
      },
      "n": "IncomingPacketsWithErrors",
      "d": 852020,
      "h": 124554903604,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(124554903604),
//--TRIMMABLE-BOUNDARY-START(128849870900),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835426868,
        "f": 50331905
      },
      "n": "IncomingUnknownProtocolPackets",
      "d": 852020,
      "h": 128849870900,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(128849870900),
//--TRIMMABLE-BOUNDARY-START(133144838196),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425361460,
        "f": 50331905
      },
      "n": "NonUnicastPacketsReceived",
      "d": 852020,
      "h": 133144838196,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(133144838196),
//--TRIMMABLE-BOUNDARY-START(137439805492),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015296052,
        "f": 50331905
      },
      "n": "NonUnicastPacketsSent",
      "d": 852020,
      "h": 137439805492,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(137439805492),
//--TRIMMABLE-BOUNDARY-START(141734772788),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605230644,
        "f": 50331905
      },
      "n": "OutgoingPacketsDiscarded",
      "d": 852020,
      "h": 141734772788,
      "f": 2097409,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "freebsd",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141734772788),
//--TRIMMABLE-BOUNDARY-START(146029740084),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195165236,
        "f": 50331905
      },
      "n": "OutgoingPacketsWithErrors",
      "d": 852020,
      "h": 146029740084,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(146029740084),
//--TRIMMABLE-BOUNDARY-START(150324707380),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785099828,
        "f": 50331905
      },
      "n": "OutputQueueLength",
      "d": 852020,
      "h": 150324707380,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(150324707380),
//--TRIMMABLE-BOUNDARY-START(154619674676),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375034420,
        "f": 50331905
      },
      "n": "UnicastPacketsReceived",
      "d": 852020,
      "h": 154619674676,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(154619674676),
//--TRIMMABLE-BOUNDARY-START(158914641972),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964969012,
        "f": 50331905
      },
      "n": "UnicastPacketsSent",
      "d": 852020,
      "h": 158914641972,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(158914641972)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819316),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 852020,
      "h": 4295819316,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295819316)
  ],
  "h": 852020
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv4InterfaceStatistics`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852020)
        
        
        //--TRIMMABLE-BOUNDARY-START(917556)
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv6InterfaceProperties", ($self) => class IPv6InterfaceProperties extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295884852)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295884852);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295884852)
            
            //--TRIMMABLE-BOUNDARY-START(25770721332)
            /*long */ GetScopeId(/*System.Net.NetworkInformation.ScopeLevel*/ scopeLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770721332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770721332)
            
            static $h = 917556;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065688628),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885819444,
        "f": 50331905
      },
      "n": "Index",
      "d": 917556,
      "h": 30065688628,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30065688628),
//--TRIMMABLE-BOUNDARY-START(34360655924),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475754036,
        "f": 50331905
      },
      "n": "Mtu",
      "d": 917556,
      "h": 34360655924,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34360655924)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25770721332),
    {
      "r": 917505,
      "p": [
        {
          "n": "scopeLevel",
          "p": 1900596
        }
      ],
      "n": "GetScopeId",
      "d": 917556,
      "h": 25770721332,
      "f": 16777345,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "freebsd",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "ios",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "tvos",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25770721332)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884852),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 917556,
      "h": 4295884852,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295884852)
  ],
  "h": 917556
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv6InterfaceProperties`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917556)
        
        
        //--TRIMMABLE-BOUNDARY-START(1507380)
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkInterface", ($self) => class NetworkInterface extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296474676)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296474676);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296474676)
            
            //--TRIMMABLE-BOUNDARY-START(8591441972)
            /*string */ get Description()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181376564);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8591441972)
            
            //--TRIMMABLE-BOUNDARY-START(124555558964)
            /*string */ get Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771311156);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(124555558964)
            
            //--TRIMMABLE-BOUNDARY-START(128850526260)
            static /*int */ get IPv6LoopbackInterfaceIndex()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361245748);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(128850526260)
            
            //--TRIMMABLE-BOUNDARY-START(133145493556)
            /*bool */ get IsReceiveOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951180340);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(133145493556)
            
            //--TRIMMABLE-BOUNDARY-START(137440460852)
            static /*int */ get LoopbackInterfaceIndex()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541114932);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(137440460852)
            
            //--TRIMMABLE-BOUNDARY-START(141735428148)
            /*string */ get Name()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131049524);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(141735428148)
            
            //--TRIMMABLE-BOUNDARY-START(146030395444)
            /*System.Net.NetworkInformation.NetworkInterfaceType */ get NetworkInterfaceType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720984116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(146030395444)
            
            //--TRIMMABLE-BOUNDARY-START(150325362740)
            /*System.Net.NetworkInformation.OperationalStatus */ get OperationalStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310918708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(150325362740)
            
            //--TRIMMABLE-BOUNDARY-START(154620330036)
            /*long */ get Speed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900853300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(154620330036)
            
            //--TRIMMABLE-BOUNDARY-START(163210264628)
            /*bool */ get SupportsMulticast()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490787892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(163210264628)
            
            //--TRIMMABLE-BOUNDARY-START(98785755188)
            static /*System.Net.NetworkInformation.NetworkInterface[] */ GetAllNetworkInterfaces()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785755188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(98785755188)
            
            //--TRIMMABLE-BOUNDARY-START(103080722484)
            /*System.Net.NetworkInformation.IPInterfaceProperties */ GetIPProperties()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080722484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103080722484)
            
            //--TRIMMABLE-BOUNDARY-START(107375689780)
            /*System.Net.NetworkInformation.IPInterfaceStatistics */ GetIPStatistics()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375689780);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(107375689780)
            
            //--TRIMMABLE-BOUNDARY-START(111670657076)
            /*System.Net.NetworkInformation.IPv4InterfaceStatistics */ GetIPv4Statistics()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670657076);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(111670657076)
            
            //--TRIMMABLE-BOUNDARY-START(115965624372)
            static /*bool */ GetIsNetworkAvailable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965624372);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115965624372)
            
            //--TRIMMABLE-BOUNDARY-START(120260591668)
            /*System.Net.NetworkInformation.PhysicalAddress */ GetPhysicalAddress()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260591668);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120260591668)
            
            //--TRIMMABLE-BOUNDARY-START(158915297332)
            /*bool */ Supports(/*System.Net.NetworkInformation.NetworkInterfaceComponent*/ networkInterfaceComponent)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915297332);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(158915297332)
            
            static $h = 1507380;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591441972),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17181376564,
        "f": 50331777
      },
      "n": "Description",
      "d": 1507380,
      "h": 8591441972,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(8591441972),
//--TRIMMABLE-BOUNDARY-START(124555558964),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25771311156,
        "f": 50331777
      },
      "n": "Id",
      "d": 1507380,
      "h": 124555558964,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(124555558964),
//--TRIMMABLE-BOUNDARY-START(128850526260),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34361245748,
        "f": 50331681
      },
      "n": "IPv6LoopbackInterfaceIndex",
      "d": 1507380,
      "h": 128850526260,
      "f": 2097185,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "illumos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "solaris",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(128850526260),
//--TRIMMABLE-BOUNDARY-START(133145493556),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42951180340,
        "f": 50331777
      },
      "n": "IsReceiveOnly",
      "d": 1507380,
      "h": 133145493556,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(133145493556),
//--TRIMMABLE-BOUNDARY-START(137440460852),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541114932,
        "f": 50331681
      },
      "n": "LoopbackInterfaceIndex",
      "d": 1507380,
      "h": 137440460852,
      "f": 2097185,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "illumos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "solaris",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(137440460852),
//--TRIMMABLE-BOUNDARY-START(141735428148),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60131049524,
        "f": 50331777
      },
      "n": "Name",
      "d": 1507380,
      "h": 141735428148,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(141735428148),
//--TRIMMABLE-BOUNDARY-START(146030395444),
    {
      "p": 1638452,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720984116,
        "f": 50331777
      },
      "n": "NetworkInterfaceType",
      "d": 1507380,
      "h": 146030395444,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(146030395444),
//--TRIMMABLE-BOUNDARY-START(150325362740),
    {
      "p": 1703988,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310918708,
        "f": 50331777
      },
      "n": "OperationalStatus",
      "d": 1507380,
      "h": 150325362740,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(150325362740),
//--TRIMMABLE-BOUNDARY-START(154620330036),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900853300,
        "f": 50331777
      },
      "n": "Speed",
      "d": 1507380,
      "h": 154620330036,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(154620330036),
//--TRIMMABLE-BOUNDARY-START(163210264628),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490787892,
        "f": 50331777
      },
      "n": "SupportsMulticast",
      "d": 1507380,
      "h": 163210264628,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(163210264628)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(98785755188),
    {
      "r": $.$typeArray($.$snn.System.Net.NetworkInformation.NetworkInterface).$h,
      "n": "GetAllNetworkInterfaces",
      "d": 1507380,
      "h": 98785755188,
      "f": 16777249,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "illumos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "solaris",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(98785755188),
//--TRIMMABLE-BOUNDARY-START(103080722484),
    {
      "r": 655412,
      "n": "GetIPProperties",
      "d": 1507380,
      "h": 103080722484,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(103080722484),
//--TRIMMABLE-BOUNDARY-START(107375689780),
    {
      "r": 720948,
      "n": "GetIPStatistics",
      "d": 1507380,
      "h": 107375689780,
      "f": 16777345,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107375689780),
//--TRIMMABLE-BOUNDARY-START(111670657076),
    {
      "r": 852020,
      "n": "GetIPv4Statistics",
      "d": 1507380,
      "h": 111670657076,
      "f": 16777345,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "android",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(111670657076),
//--TRIMMABLE-BOUNDARY-START(115965624372),
    {
      "r": 262145,
      "n": "GetIsNetworkAvailable",
      "d": 1507380,
      "h": 115965624372,
      "f": 16777249,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "illumos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "solaris",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(115965624372),
//--TRIMMABLE-BOUNDARY-START(120260591668),
    {
      "r": 1769524,
      "n": "GetPhysicalAddress",
      "d": 1507380,
      "h": 120260591668,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(120260591668),
//--TRIMMABLE-BOUNDARY-START(158915297332),
    {
      "r": 262145,
      "p": [
        {
          "n": "networkInterfaceComponent",
          "p": 1572916
        }
      ],
      "n": "Supports",
      "d": 1507380,
      "h": 158915297332,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(158915297332)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296474676),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1507380,
      "h": 4296474676,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296474676)
  ],
  "h": 1507380
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterface`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507380)
        
        
        //--TRIMMABLE-BOUNDARY-START(2031668)
        $asm.$cls("$snn.System.Net.NetworkInformation.TcpConnectionInformation", ($self) => class TcpConnectionInformation extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296998964)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296998964);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296998964)
            
            static $h = 2031668;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361770036),
    {
      "p": 3276847,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886933556,
        "f": 50331905
      },
      "n": "LocalEndPoint",
      "d": 2031668,
      "h": 34361770036,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(34361770036),
//--TRIMMABLE-BOUNDARY-START(38656737332),
    {
      "p": 3276847,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476868148,
        "f": 50331905
      },
      "n": "RemoteEndPoint",
      "d": 2031668,
      "h": 38656737332,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(38656737332),
//--TRIMMABLE-BOUNDARY-START(42951704628),
    {
      "p": 2097204,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066802740,
        "f": 50331905
      },
      "n": "State",
      "d": 2031668,
      "h": 42951704628,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(42951704628)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296998964),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2031668,
      "h": 4296998964,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296998964)
  ],
  "h": 2031668
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpConnectionInformation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2031668)
        
        
        //--TRIMMABLE-BOUNDARY-START(2162740)
        $asm.$cls("$snn.System.Net.NetworkInformation.TcpStatistics", ($self) => class TcpStatistics extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297130036)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297130036);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297130036)
            
            static $h = 2162740;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8592097332),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656868404,
        "f": 50331905
      },
      "n": "ConnectionsAccepted",
      "d": 2162740,
      "h": 8592097332,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8592097332),
//--TRIMMABLE-BOUNDARY-START(12887064628),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246802996,
        "f": 50331905
      },
      "n": "ConnectionsInitiated",
      "d": 2162740,
      "h": 12887064628,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12887064628),
//--TRIMMABLE-BOUNDARY-START(17182031924),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836737588,
        "f": 50331905
      },
      "n": "CumulativeConnections",
      "d": 2162740,
      "h": 17182031924,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(17182031924),
//--TRIMMABLE-BOUNDARY-START(21476999220),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426672180,
        "f": 50331905
      },
      "n": "CurrentConnections",
      "d": 2162740,
      "h": 21476999220,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(21476999220),
//--TRIMMABLE-BOUNDARY-START(25771966516),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016606772,
        "f": 50331905
      },
      "n": "ErrorsReceived",
      "d": 2162740,
      "h": 25771966516,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(25771966516),
//--TRIMMABLE-BOUNDARY-START(30066933812),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606541364,
        "f": 50331905
      },
      "n": "FailedConnectionAttempts",
      "d": 2162740,
      "h": 30066933812,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(30066933812),
//--TRIMMABLE-BOUNDARY-START(154620985396),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196475956,
        "f": 50331905
      },
      "n": "MaximumConnections",
      "d": 2162740,
      "h": 154620985396,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(154620985396),
//--TRIMMABLE-BOUNDARY-START(158915952692),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98786410548,
        "f": 50331905
      },
      "n": "MaximumTransmissionTimeout",
      "d": 2162740,
      "h": 158915952692,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(158915952692),
//--TRIMMABLE-BOUNDARY-START(163210919988),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107376345140,
        "f": 50331905
      },
      "n": "MinimumTransmissionTimeout",
      "d": 2162740,
      "h": 163210919988,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(163210919988),
//--TRIMMABLE-BOUNDARY-START(167505887284),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115966279732,
        "f": 50331905
      },
      "n": "ResetConnections",
      "d": 2162740,
      "h": 167505887284,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(167505887284),
//--TRIMMABLE-BOUNDARY-START(171800854580),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124556214324,
        "f": 50331905
      },
      "n": "ResetsSent",
      "d": 2162740,
      "h": 171800854580,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(171800854580),
//--TRIMMABLE-BOUNDARY-START(176095821876),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133146148916,
        "f": 50331905
      },
      "n": "SegmentsReceived",
      "d": 2162740,
      "h": 176095821876,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(176095821876),
//--TRIMMABLE-BOUNDARY-START(180390789172),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141736083508,
        "f": 50331905
      },
      "n": "SegmentsResent",
      "d": 2162740,
      "h": 180390789172,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(180390789172),
//--TRIMMABLE-BOUNDARY-START(184685756468),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150326018100,
        "f": 50331905
      },
      "n": "SegmentsSent",
      "d": 2162740,
      "h": 184685756468,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(184685756468)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297130036),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2162740,
      "h": 4297130036,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297130036)
  ],
  "h": 2162740
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpStatistics`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2162740)
        
        
        //--TRIMMABLE-BOUNDARY-START(2228276)
        $asm.$cls("$snn.System.Net.NetworkInformation.UdpStatistics", ($self) => class UdpStatistics extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297195572)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297195572);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297195572)
            
            static $h = 2228276;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8592162868),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21477064756,
        "f": 50331905
      },
      "n": "DatagramsReceived",
      "d": 2228276,
      "h": 8592162868,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8592162868),
//--TRIMMABLE-BOUNDARY-START(12887130164),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066999348,
        "f": 50331905
      },
      "n": "DatagramsSent",
      "d": 2228276,
      "h": 12887130164,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12887130164),
//--TRIMMABLE-BOUNDARY-START(60131770420),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656933940,
        "f": 50331905
      },
      "n": "IncomingDatagramsDiscarded",
      "d": 2228276,
      "h": 60131770420,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(60131770420),
//--TRIMMABLE-BOUNDARY-START(64426737716),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246868532,
        "f": 50331905
      },
      "n": "IncomingDatagramsWithErrors",
      "d": 2228276,
      "h": 64426737716,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(64426737716),
//--TRIMMABLE-BOUNDARY-START(68721705012),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836803124,
        "f": 50331905
      },
      "n": "UdpListeners",
      "d": 2228276,
      "h": 68721705012,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(68721705012)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297195572),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2228276,
      "h": 4297195572,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297195572)
  ],
  "h": 2228276
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.UdpStatistics`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2228276)
        
        
        //--TRIMMABLE-BOUNDARY-START(983092)
        $asm.$cls("$snn.System.Net.NetworkInformation.MulticastIPAddressInformation", ($self) => class MulticastIPAddressInformation extends $.$snn.System.Net.NetworkInformation.IPAddressInformation
        {
            //--TRIMMABLE-BOUNDARY-START(4295950388)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295950388);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295950388)
            
            static $h = 983092;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 393268,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590917684),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065754164,
        "f": 50331905
      },
      "n": "AddressPreferredLifetime",
      "d": 983092,
      "h": 8590917684,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590917684),
//--TRIMMABLE-BOUNDARY-START(12885884980),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655688756,
        "f": 50331905
      },
      "n": "AddressValidLifetime",
      "d": 983092,
      "h": 12885884980,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885884980),
//--TRIMMABLE-BOUNDARY-START(17180852276),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245623348,
        "f": 50331905
      },
      "n": "DhcpLeaseLifetime",
      "d": 983092,
      "h": 17180852276,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17180852276),
//--TRIMMABLE-BOUNDARY-START(21475819572),
    {
      "p": 65588,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835557940,
        "f": 50331905
      },
      "n": "DuplicateAddressDetectionState",
      "d": 983092,
      "h": 21475819572,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21475819572),
//--TRIMMABLE-BOUNDARY-START(77310394420),
    {
      "p": 1835060,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425492532,
        "f": 50331905
      },
      "n": "PrefixOrigin",
      "d": 983092,
      "h": 77310394420,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(77310394420),
//--TRIMMABLE-BOUNDARY-START(81605361716),
    {
      "p": 1966132,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015427124,
        "f": 50331905
      },
      "n": "SuffixOrigin",
      "d": 983092,
      "h": 81605361716,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(81605361716)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295950388),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 983092,
      "h": 4295950388,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295950388)
  ],
  "h": 983092
}; }
            static get $b() { return $.$snn.System.Net.NetworkInformation.IPAddressInformation; }
            static get $fullName() { return `System.Net.NetworkInformation.MulticastIPAddressInformation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983092)
        
        
        //--TRIMMABLE-BOUNDARY-START(2293812)
        $asm.$cls("$snn.System.Net.NetworkInformation.UnicastIPAddressInformation", ($self) => class UnicastIPAddressInformation extends $.$snn.System.Net.NetworkInformation.IPAddressInformation
        {
            //--TRIMMABLE-BOUNDARY-START(4297261108)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297261108);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297261108)
            
            //--TRIMMABLE-BOUNDARY-START(98786541620)
            /*int */ get PrefixLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016737844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(98786541620)
            
            static $h = 2293812;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 393268,
  "p": [
//--TRIMMABLE-BOUNDARY-START(8592228404),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30067064884,
        "f": 50331905
      },
      "n": "AddressPreferredLifetime",
      "d": 2293812,
      "h": 8592228404,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8592228404),
//--TRIMMABLE-BOUNDARY-START(12887195700),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656999476,
        "f": 50331905
      },
      "n": "AddressValidLifetime",
      "d": 2293812,
      "h": 12887195700,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12887195700),
//--TRIMMABLE-BOUNDARY-START(17182162996),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246934068,
        "f": 50331905
      },
      "n": "DhcpLeaseLifetime",
      "d": 2293812,
      "h": 17182162996,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(17182162996),
//--TRIMMABLE-BOUNDARY-START(21477130292),
    {
      "p": 65588,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836868660,
        "f": 50331905
      },
      "n": "DuplicateAddressDetectionState",
      "d": 2293812,
      "h": 21477130292,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(21477130292),
//--TRIMMABLE-BOUNDARY-START(94491574324),
    {
      "p": 3014703,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426803252,
        "f": 50331905
      },
      "n": "IPv4Mask",
      "d": 2293812,
      "h": 94491574324,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(94491574324),
//--TRIMMABLE-BOUNDARY-START(98786541620),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016737844,
        "f": 50331777
      },
      "n": "PrefixLength",
      "d": 2293812,
      "h": 98786541620,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(98786541620),
//--TRIMMABLE-BOUNDARY-START(103081508916),
    {
      "p": 1835060,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606672436,
        "f": 50331905
      },
      "n": "PrefixOrigin",
      "d": 2293812,
      "h": 103081508916,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(103081508916),
//--TRIMMABLE-BOUNDARY-START(107376476212),
    {
      "p": 1966132,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196607028,
        "f": 50331905
      },
      "n": "SuffixOrigin",
      "d": 2293812,
      "h": 107376476212,
      "f": 2097409,
      "a": [
        {
          "t": 159055873,
          "c": 4454023169,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107376476212)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297261108),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 2293812,
      "h": 4297261108,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4297261108)
  ],
  "h": 2293812
}; }
            static get $b() { return $.$snn.System.Net.NetworkInformation.IPAddressInformation; }
            static get $fullName() { return `System.Net.NetworkInformation.UnicastIPAddressInformation`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2293812)
        
        
        //--TRIMMABLE-BOUNDARY-START(1376308)
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkChange", ($self) => class NetworkChange extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296343604)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296343604);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296343604)
            
            //--TRIMMABLE-BOUNDARY-START(25771180084)
            /*System.Net.NetworkInformation.NetworkAddressChangedEventHandler?*/static  add_NetworkAddressChanged(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886278196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            /*System.Net.NetworkInformation.NetworkAddressChangedEventHandler?*/static  remove_NetworkAddressChanged(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951049268);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25771180084)
            
            //--TRIMMABLE-BOUNDARY-START(30066147380)
            /*System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler?*/static  add_NetworkAvailabilityChanged(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476212788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            /*System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler?*/static  remove_NetworkAvailabilityChanged(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540983860);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30066147380)
            
            //--TRIMMABLE-BOUNDARY-START(34361114676)
            static /*void */ RegisterNetworkChange(/*System.Net.NetworkInformation.NetworkChange*/ nc)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361114676);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(34361114676)
            
            static $h = 1376308;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(34361114676),
    {
      "r": 65537,
      "p": [
        {
          "n": "nc",
          "p": 1376308
        }
      ],
      "n": "RegisterNetworkChange",
      "d": 1376308,
      "h": 34361114676,
      "f": 16777249,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        },
        {
          "t": 103743489,
          "c": 25873547265,
          "a": [
            {
              "v": "This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.",
              "t": 1310721
            },
            {
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361114676)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343604),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376308,
      "h": 4296343604,
      "f": 16777217,
      "a": [
        {
          "t": 64290817,
          "c": 12949192705,
          "a": [
            {
              "v": 1,
              "t": 64356353
            }
          ]
        },
        {
          "t": 103743489,
          "c": 25873547265,
          "a": [
            {
              "v": "This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.",
              "t": 1310721
            },
            {
              "v": true,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4296343604)
  ],
  "e": [
//--TRIMMABLE-BOUNDARY-START(25771180084),
    {
      "e": 1179700,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1179700
          }
        ],
        "n": "add_NetworkAddressChanged",
        "d": 1376308,
        "h": 12886278196,
        "f": 150994977
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1179700
          }
        ],
        "n": "remove_NetworkAddressChanged",
        "d": 1376308,
        "h": 42951049268,
        "f": 285212705
      },
      "n": "NetworkAddressChanged",
      "d": 1376308,
      "h": 25771180084,
      "f": 8388641,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "illumos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "solaris",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(25771180084),
//--TRIMMABLE-BOUNDARY-START(30066147380),
    {
      "e": 1245236,
      "m": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1245236
          }
        ],
        "n": "add_NetworkAvailabilityChanged",
        "d": 1376308,
        "h": 21476212788,
        "f": 150994977
      },
      "r": {
        "r": 65537,
        "p": [
          {
            "n": "value",
            "p": 1245236
          }
        ],
        "n": "remove_NetworkAvailabilityChanged",
        "d": 1376308,
        "h": 51540983860,
        "f": 285212705
      },
      "n": "NetworkAvailabilityChanged",
      "d": 1376308,
      "h": 30066147380,
      "f": 8388641,
      "a": [
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "illumos",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159383553,
          "c": 13044285441,
          "a": [
            {
              "v": "solaris",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(30066147380)
  ],
  "h": 1376308
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkChange`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376308)
        
        
        //--TRIMMABLE-BOUNDARY-START(1769524)
        $asm.$cls("$snn.System.Net.NetworkInformation.PhysicalAddress", ($self) => class PhysicalAddress extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(21476606004)
            /*System.Net.NetworkInformation.PhysicalAddress*/ static None = null;
            //--TRIMMABLE-BOUNDARY-END(21476606004)
            
            //--TRIMMABLE-BOUNDARY-START(4296736820)
            $ctor$1(/*byte[]*/ address)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296736820);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296736820)
            
            //--TRIMMABLE-BOUNDARY-START(8591704116)
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ comparand)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591704116);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.Equals$1.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(8591704116)
            
            //--TRIMMABLE-BOUNDARY-START(12886671412)
            /*byte[] */ GetAddressBytes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886671412);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12886671412)
            
            //--TRIMMABLE-BOUNDARY-START(17181638708)
            static/*conventional*/ /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181638708);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.GetHashCode.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(17181638708)
            
            //--TRIMMABLE-BOUNDARY-START(25771573300)
            static /*System.Net.NetworkInformation.PhysicalAddress */ Parse(/*System.ReadOnlySpan<char>*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771573300);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25771573300)
            
            //--TRIMMABLE-BOUNDARY-START(30066540596)
            static /*System.Net.NetworkInformation.PhysicalAddress */ Parse$1(/*string?*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066540596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30066540596)
            
            //--TRIMMABLE-BOUNDARY-START(34361507892)
            static/*conventional*/ /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361507892);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.ToString.apply(this, arguments); }
            //--TRIMMABLE-BOUNDARY-END(34361507892)
            
            //--TRIMMABLE-BOUNDARY-START(38656475188)
            static /*bool */ TryParse(/*System.ReadOnlySpan<char>*/ address, /*out System.Net.NetworkInformation.PhysicalAddress?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656475188);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38656475188)
            
            //--TRIMMABLE-BOUNDARY-START(42951442484)
            static /*bool */ TryParse$1(/*string?*/ address, /*out System.Net.NetworkInformation.PhysicalAddress?*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951442484);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42951442484)
            
            static $h = 1769524;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591704116),
    {
      "r": 262145,
      "p": [
        {
          "n": "comparand",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 1769524,
      "h": 8591704116,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8591704116),
//--TRIMMABLE-BOUNDARY-START(12886671412),
    {
      "r": $.$typeArray($.$$.System.Byte).$h,
      "n": "GetAddressBytes",
      "d": 1769524,
      "h": 12886671412,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886671412),
//--TRIMMABLE-BOUNDARY-START(17181638708),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 1769524,
      "h": 17181638708,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17181638708),
//--TRIMMABLE-BOUNDARY-START(25771573300),
    {
      "r": 1769524,
      "p": [
        {
          "n": "address",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        }
      ],
      "n": "Parse",
      "d": 1769524,
      "h": 25771573300,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(25771573300),
//--TRIMMABLE-BOUNDARY-START(30066540596),
    {
      "r": 1769524,
      "p": [
        {
          "n": "address",
          "p": 1310721
        }
      ],
      "n": "Parse",
      "o": "@$1",
      "d": 1769524,
      "h": 30066540596,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(30066540596),
//--TRIMMABLE-BOUNDARY-START(34361507892),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1769524,
      "h": 34361507892,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(34361507892),
//--TRIMMABLE-BOUNDARY-START(38656475188),
    {
      "r": 262145,
      "p": [
        {
          "n": "address",
          "p": $.$$.System.ReadOnlySpan$$($.$$.System.Char).$h
        },
        {
          "n": "value",
          "p": 1769524,
          "f": 2
        }
      ],
      "n": "TryParse",
      "d": 1769524,
      "h": 38656475188,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38656475188),
//--TRIMMABLE-BOUNDARY-START(42951442484),
    {
      "r": 262145,
      "p": [
        {
          "n": "address",
          "p": 1310721
        },
        {
          "n": "value",
          "p": 1769524,
          "f": 2
        }
      ],
      "n": "TryParse",
      "o": "@$1",
      "d": 1769524,
      "h": 42951442484,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42951442484)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476606004),
    {
      "t": 1769524,
      "n": "None",
      "d": 1769524,
      "h": 21476606004,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476606004)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296736820),
    {
      "p": [
        {
          "n": "address",
          "p": $.$typeArray($.$$.System.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1769524,
      "h": 4296736820,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296736820)
  ],
  "h": 1769524
}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.PhysicalAddress`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769524)
        
        
        //--TRIMMABLE-BOUNDARY-START(196660)
        $asm.$cls("$snn.System.Net.NetworkInformation.GatewayIPAddressInformationCollection", ($self) => class GatewayIPAddressInformationCollection extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295163956)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295163956);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163956)
            
            //--TRIMMABLE-BOUNDARY-START(25770000436)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359935028);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770000436)
            
            //--TRIMMABLE-BOUNDARY-START(60129738804)
            /*bool */ get IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949869620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60129738804)
            
            //--TRIMMABLE-BOUNDARY-START(73014640692)
            /*System.Net.NetworkInformation.GatewayIPAddressInformation*/ get_Item$1(/*int*/ index)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73014640692)
            
            //--TRIMMABLE-BOUNDARY-START(8590131252)
            /*void */ Add(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131252);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590131252)
            
            //--TRIMMABLE-BOUNDARY-START(12885098548)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098548);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12885098548)
            
            //--TRIMMABLE-BOUNDARY-START(17180065844)
            /*bool */ Contains(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065844);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180065844)
            
            //--TRIMMABLE-BOUNDARY-START(21475033140)
            /*void */ CopyTo(/*System.Net.NetworkInformation.GatewayIPAddressInformation[]*/ array, /*int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033140);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21475033140)
            
            //--TRIMMABLE-BOUNDARY-START(55834771508)
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.GatewayIPAddressInformation> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834771508);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55834771508)
            
            //--TRIMMABLE-BOUNDARY-START(64424706100)
            /*bool */ Remove(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706100);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64424706100)
            
            //--TRIMMABLE-BOUNDARY-START(68719673396)
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719673396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68719673396)
            
            //--TRIMMABLE-BOUNDARY-START(30124081153)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534146561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30124081153)
            
            //--TRIMMABLE-BOUNDARY-START(38714015745)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43008983041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(38714015745)
            
            //--TRIMMABLE-BOUNDARY-START(4354277377)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Add(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354277377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354277377)
            
            //--TRIMMABLE-BOUNDARY-START(8649244673)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649244673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649244673)
            
            //--TRIMMABLE-BOUNDARY-START(12944211969)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Contains(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12944211969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12944211969)
            
            //--TRIMMABLE-BOUNDARY-START(17239179265)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.CopyTo(System.Net.NetworkInformation.GatewayIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17239179265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17239179265)
            
            //--TRIMMABLE-BOUNDARY-START(47303950337)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Remove(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47303950337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47303950337)
            
            //--TRIMMABLE-BOUNDARY-START(4354605057)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.GatewayIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354605057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354605057)
            
            static $h = 196660;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770000436),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359935028,
        "f": 50331777
      },
      "n": "Count",
      "d": 196660,
      "h": 25770000436,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(25770000436),
//--TRIMMABLE-BOUNDARY-START(60129738804),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949869620,
        "f": 50331777
      },
      "n": "IsReadOnly",
      "d": 196660,
      "h": 60129738804,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(60129738804),
//--TRIMMABLE-BOUNDARY-START(73014640692),
    {
      "p": 131124,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539804212,
        "f": 50331777
      },
      "n": "Item",
      "o": "@$1",
      "d": 196660,
      "h": 73014640692,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(73014640692)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590131252),
    {
      "r": 65537,
      "p": [
        {
          "n": "address",
          "p": 131124
        }
      ],
      "n": "Add",
      "d": 196660,
      "h": 8590131252,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590131252),
//--TRIMMABLE-BOUNDARY-START(12885098548),
    {
      "r": 65537,
      "n": "Clear",
      "d": 196660,
      "h": 12885098548,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885098548),
//--TRIMMABLE-BOUNDARY-START(17180065844),
    {
      "r": 262145,
      "p": [
        {
          "n": "address",
          "p": 131124
        }
      ],
      "n": "Contains",
      "d": 196660,
      "h": 17180065844,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180065844),
//--TRIMMABLE-BOUNDARY-START(21475033140),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 196660,
      "h": 21475033140,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475033140),
//--TRIMMABLE-BOUNDARY-START(55834771508),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,
      "n": "GetEnumerator",
      "d": 196660,
      "h": 55834771508,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(55834771508),
//--TRIMMABLE-BOUNDARY-START(64424706100),
    {
      "r": 262145,
      "p": [
        {
          "n": "address",
          "p": 131124
        }
      ],
      "n": "Remove",
      "d": 196660,
      "h": 64424706100,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64424706100)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163956),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196660,
      "h": 4295163956,
      "f": 16777232
    },
//--TRIMMABLE-BOUNDARY-END(4295163956)
  ],
  "i": [$.$$.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,62652417
  ],
  "h": 196660
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation), $.$$.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.GatewayIPAddressInformationCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196660)
        
        
        //--TRIMMABLE-BOUNDARY-START(458804)
        $asm.$cls("$snn.System.Net.NetworkInformation.IPAddressInformationCollection", ($self) => class IPAddressInformationCollection extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295426100)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295426100);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426100)
            
            //--TRIMMABLE-BOUNDARY-START(25770262580)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360197172);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770262580)
            
            //--TRIMMABLE-BOUNDARY-START(60130000948)
            /*bool */ get IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950131764);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60130000948)
            
            //--TRIMMABLE-BOUNDARY-START(73014902836)
            /*System.Net.NetworkInformation.IPAddressInformation*/ get_Item$1(/*int*/ index)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73014902836)
            
            //--TRIMMABLE-BOUNDARY-START(8590393396)
            /*void */ Add(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393396);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590393396)
            
            //--TRIMMABLE-BOUNDARY-START(12885360692)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360692);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12885360692)
            
            //--TRIMMABLE-BOUNDARY-START(17180327988)
            /*bool */ Contains(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180327988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180327988)
            
            //--TRIMMABLE-BOUNDARY-START(21475295284)
            /*void */ CopyTo(/*System.Net.NetworkInformation.IPAddressInformation[]*/ array, /*int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295284);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21475295284)
            
            //--TRIMMABLE-BOUNDARY-START(55835033652)
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.IPAddressInformation> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835033652);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55835033652)
            
            //--TRIMMABLE-BOUNDARY-START(64424968244)
            /*bool */ Remove(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424968244);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64424968244)
            
            //--TRIMMABLE-BOUNDARY-START(68719935540)
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935540);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68719935540)
            
            //--TRIMMABLE-BOUNDARY-START(30124081153)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534146561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30124081153)
            
            //--TRIMMABLE-BOUNDARY-START(38714015745)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43008983041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(38714015745)
            
            //--TRIMMABLE-BOUNDARY-START(4354277377)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Add(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354277377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354277377)
            
            //--TRIMMABLE-BOUNDARY-START(8649244673)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649244673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649244673)
            
            //--TRIMMABLE-BOUNDARY-START(12944211969)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Contains(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12944211969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12944211969)
            
            //--TRIMMABLE-BOUNDARY-START(17239179265)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.CopyTo(System.Net.NetworkInformation.IPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17239179265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17239179265)
            
            //--TRIMMABLE-BOUNDARY-START(47303950337)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Remove(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47303950337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47303950337)
            
            //--TRIMMABLE-BOUNDARY-START(4354605057)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.IPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354605057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354605057)
            
            static $h = 458804;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770262580),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360197172,
        "f": 50331777
      },
      "n": "Count",
      "d": 458804,
      "h": 25770262580,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(25770262580),
//--TRIMMABLE-BOUNDARY-START(60130000948),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950131764,
        "f": 50331777
      },
      "n": "IsReadOnly",
      "d": 458804,
      "h": 60130000948,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(60130000948),
//--TRIMMABLE-BOUNDARY-START(73014902836),
    {
      "p": 393268,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540066356,
        "f": 50331777
      },
      "n": "Item",
      "o": "@$1",
      "d": 458804,
      "h": 73014902836,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(73014902836)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590393396),
    {
      "r": 65537,
      "p": [
        {
          "n": "address",
          "p": 393268
        }
      ],
      "n": "Add",
      "d": 458804,
      "h": 8590393396,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590393396),
//--TRIMMABLE-BOUNDARY-START(12885360692),
    {
      "r": 65537,
      "n": "Clear",
      "d": 458804,
      "h": 12885360692,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885360692),
//--TRIMMABLE-BOUNDARY-START(17180327988),
    {
      "r": 262145,
      "p": [
        {
          "n": "address",
          "p": 393268
        }
      ],
      "n": "Contains",
      "d": 458804,
      "h": 17180327988,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180327988),
//--TRIMMABLE-BOUNDARY-START(21475295284),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 458804,
      "h": 21475295284,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475295284),
//--TRIMMABLE-BOUNDARY-START(55835033652),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,
      "n": "GetEnumerator",
      "d": 458804,
      "h": 55835033652,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(55835033652),
//--TRIMMABLE-BOUNDARY-START(64424968244),
    {
      "r": 262145,
      "p": [
        {
          "n": "address",
          "p": 393268
        }
      ],
      "n": "Remove",
      "d": 458804,
      "h": 64424968244,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64424968244)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426100),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458804,
      "h": 4295426100,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295426100)
  ],
  "i": [$.$$.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,62652417
  ],
  "h": 458804
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.IPAddressInformation), $.$$.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.IPAddressInformation), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressInformationCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458804)
        
        
        //--TRIMMABLE-BOUNDARY-START(1048628)
        $asm.$cls("$snn.System.Net.NetworkInformation.MulticastIPAddressInformationCollection", ($self) => class MulticastIPAddressInformationCollection extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296015924)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296015924);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296015924)
            
            //--TRIMMABLE-BOUNDARY-START(25770852404)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360786996);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770852404)
            
            //--TRIMMABLE-BOUNDARY-START(60130590772)
            /*bool */ get IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950721588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60130590772)
            
            //--TRIMMABLE-BOUNDARY-START(73015492660)
            /*System.Net.NetworkInformation.MulticastIPAddressInformation*/ get_Item$1(/*int*/ index)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73015492660)
            
            //--TRIMMABLE-BOUNDARY-START(8590983220)
            /*void */ Add(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590983220);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590983220)
            
            //--TRIMMABLE-BOUNDARY-START(12885950516)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885950516);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12885950516)
            
            //--TRIMMABLE-BOUNDARY-START(17180917812)
            /*bool */ Contains(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180917812);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180917812)
            
            //--TRIMMABLE-BOUNDARY-START(21475885108)
            /*void */ CopyTo(/*System.Net.NetworkInformation.MulticastIPAddressInformation[]*/ array, /*int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475885108);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21475885108)
            
            //--TRIMMABLE-BOUNDARY-START(55835623476)
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.MulticastIPAddressInformation> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835623476);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55835623476)
            
            //--TRIMMABLE-BOUNDARY-START(64425558068)
            /*bool */ Remove(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425558068);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64425558068)
            
            //--TRIMMABLE-BOUNDARY-START(68720525364)
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720525364);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68720525364)
            
            //--TRIMMABLE-BOUNDARY-START(30124081153)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534146561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30124081153)
            
            //--TRIMMABLE-BOUNDARY-START(38714015745)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43008983041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(38714015745)
            
            //--TRIMMABLE-BOUNDARY-START(4354277377)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Add(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354277377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354277377)
            
            //--TRIMMABLE-BOUNDARY-START(8649244673)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649244673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649244673)
            
            //--TRIMMABLE-BOUNDARY-START(12944211969)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Contains(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12944211969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12944211969)
            
            //--TRIMMABLE-BOUNDARY-START(17239179265)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.CopyTo(System.Net.NetworkInformation.MulticastIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17239179265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17239179265)
            
            //--TRIMMABLE-BOUNDARY-START(47303950337)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Remove(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47303950337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47303950337)
            
            //--TRIMMABLE-BOUNDARY-START(4354605057)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.MulticastIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354605057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354605057)
            
            static $h = 1048628;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25770852404),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360786996,
        "f": 50331777
      },
      "n": "Count",
      "d": 1048628,
      "h": 25770852404,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(25770852404),
//--TRIMMABLE-BOUNDARY-START(60130590772),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950721588,
        "f": 50331777
      },
      "n": "IsReadOnly",
      "d": 1048628,
      "h": 60130590772,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(60130590772),
//--TRIMMABLE-BOUNDARY-START(73015492660),
    {
      "p": 983092,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540656180,
        "f": 50331777
      },
      "n": "Item",
      "o": "@$1",
      "d": 1048628,
      "h": 73015492660,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(73015492660)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590983220),
    {
      "r": 65537,
      "p": [
        {
          "n": "address",
          "p": 983092
        }
      ],
      "n": "Add",
      "d": 1048628,
      "h": 8590983220,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590983220),
//--TRIMMABLE-BOUNDARY-START(12885950516),
    {
      "r": 65537,
      "n": "Clear",
      "d": 1048628,
      "h": 12885950516,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885950516),
//--TRIMMABLE-BOUNDARY-START(17180917812),
    {
      "r": 262145,
      "p": [
        {
          "n": "address",
          "p": 983092
        }
      ],
      "n": "Contains",
      "d": 1048628,
      "h": 17180917812,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180917812),
//--TRIMMABLE-BOUNDARY-START(21475885108),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 1048628,
      "h": 21475885108,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475885108),
//--TRIMMABLE-BOUNDARY-START(55835623476),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,
      "n": "GetEnumerator",
      "d": 1048628,
      "h": 55835623476,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(55835623476),
//--TRIMMABLE-BOUNDARY-START(64425558068),
    {
      "r": 262145,
      "p": [
        {
          "n": "address",
          "p": 983092
        }
      ],
      "n": "Remove",
      "d": 1048628,
      "h": 64425558068,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64425558068)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015924),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048628,
      "h": 4296015924,
      "f": 16777232
    },
//--TRIMMABLE-BOUNDARY-END(4296015924)
  ],
  "i": [$.$$.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,62652417
  ],
  "h": 1048628
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation), $.$$.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.MulticastIPAddressInformationCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048628)
        
        
        //--TRIMMABLE-BOUNDARY-START(2359348)
        $asm.$cls("$snn.System.Net.NetworkInformation.UnicastIPAddressInformationCollection", ($self) => class UnicastIPAddressInformationCollection extends $.$$.System.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4297326644)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4297326644);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4297326644)
            
            //--TRIMMABLE-BOUNDARY-START(25772163124)
            /*int */ get Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34362097716);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25772163124)
            
            //--TRIMMABLE-BOUNDARY-START(60131901492)
            /*bool */ get IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42952032308);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60131901492)
            
            //--TRIMMABLE-BOUNDARY-START(73016803380)
            /*System.Net.NetworkInformation.UnicastIPAddressInformation*/ get_Item$1(/*int*/ index)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73016803380)
            
            //--TRIMMABLE-BOUNDARY-START(8592293940)
            /*void */ Add(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8592293940);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8592293940)
            
            //--TRIMMABLE-BOUNDARY-START(12887261236)
            /*void */ Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12887261236);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12887261236)
            
            //--TRIMMABLE-BOUNDARY-START(17182228532)
            /*bool */ Contains(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17182228532);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17182228532)
            
            //--TRIMMABLE-BOUNDARY-START(21477195828)
            /*void */ CopyTo(/*System.Net.NetworkInformation.UnicastIPAddressInformation[]*/ array, /*int*/ offset)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21477195828);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21477195828)
            
            //--TRIMMABLE-BOUNDARY-START(55836934196)
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.UnicastIPAddressInformation> */ GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836934196);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55836934196)
            
            //--TRIMMABLE-BOUNDARY-START(64426868788)
            /*bool */ Remove(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426868788);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64426868788)
            
            //--TRIMMABLE-BOUNDARY-START(68721836084)
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68721836084);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68721836084)
            
            //--TRIMMABLE-BOUNDARY-START(30124081153)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21534146561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Count;
            }
            //--TRIMMABLE-BOUNDARY-END(30124081153)
            
            //--TRIMMABLE-BOUNDARY-START(38714015745)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(43008983041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.IsReadOnly;
            }
            //--TRIMMABLE-BOUNDARY-END(38714015745)
            
            //--TRIMMABLE-BOUNDARY-START(4354277377)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Add(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354277377);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Add(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354277377)
            
            //--TRIMMABLE-BOUNDARY-START(8649244673)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8649244673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Clear(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(8649244673)
            
            //--TRIMMABLE-BOUNDARY-START(12944211969)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Contains(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12944211969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Contains(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(12944211969)
            
            //--TRIMMABLE-BOUNDARY-START(17239179265)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.CopyTo(System.Net.NetworkInformation.UnicastIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17239179265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.CopyTo(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(17239179265)
            
            //--TRIMMABLE-BOUNDARY-START(47303950337)
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Remove(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47303950337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Remove(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(47303950337)
            
            //--TRIMMABLE-BOUNDARY-START(4354605057)
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.UnicastIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4354605057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.GetEnumerator(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4354605057)
            
            static $h = 2359348;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 131073,
  "p": [
//--TRIMMABLE-BOUNDARY-START(25772163124),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34362097716,
        "f": 50331777
      },
      "n": "Count",
      "d": 2359348,
      "h": 25772163124,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(25772163124),
//--TRIMMABLE-BOUNDARY-START(60131901492),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42952032308,
        "f": 50331777
      },
      "n": "IsReadOnly",
      "d": 2359348,
      "h": 60131901492,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(60131901492),
//--TRIMMABLE-BOUNDARY-START(73016803380),
    {
      "p": 2293812,
      "i": [
        {
          "n": "index",
          "p": 655361
        }
      ],
      "g": {
        "r": 0,
        "d": 0,
        "h": 51541966900,
        "f": 50331777
      },
      "n": "Item",
      "o": "@$1",
      "d": 2359348,
      "h": 73016803380,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(73016803380)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8592293940),
    {
      "r": 65537,
      "p": [
        {
          "n": "address",
          "p": 2293812
        }
      ],
      "n": "Add",
      "d": 2359348,
      "h": 8592293940,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8592293940),
//--TRIMMABLE-BOUNDARY-START(12887261236),
    {
      "r": 65537,
      "n": "Clear",
      "d": 2359348,
      "h": 12887261236,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12887261236),
//--TRIMMABLE-BOUNDARY-START(17182228532),
    {
      "r": 262145,
      "p": [
        {
          "n": "address",
          "p": 2293812
        }
      ],
      "n": "Contains",
      "d": 2359348,
      "h": 17182228532,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17182228532),
//--TRIMMABLE-BOUNDARY-START(21477195828),
    {
      "r": 65537,
      "p": [
        {
          "n": "array",
          "p": $.$typeArray($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h
        },
        {
          "n": "offset",
          "p": 655361
        }
      ],
      "n": "CopyTo",
      "d": 2359348,
      "h": 21477195828,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21477195828),
//--TRIMMABLE-BOUNDARY-START(55836934196),
    {
      "r": $.$$.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,
      "n": "GetEnumerator",
      "d": 2359348,
      "h": 55836934196,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(55836934196),
//--TRIMMABLE-BOUNDARY-START(64426868788),
    {
      "r": 262145,
      "p": [
        {
          "n": "address",
          "p": 2293812
        }
      ],
      "n": "Remove",
      "d": 2359348,
      "h": 64426868788,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64426868788)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297326644),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 2359348,
      "h": 4297326644,
      "f": 16777232
    },
//--TRIMMABLE-BOUNDARY-END(4297326644)
  ],
  "i": [$.$$.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,62652417
  ],
  "h": 2359348
}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation), $.$$.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.UnicastIPAddressInformationCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2359348)
        
        
        //--TRIMMABLE-BOUNDARY-START(1179700)
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAddressChangedEventHandler", ($self) => class NetworkAddressChangedEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Nullable$$*/ sender, /*$.$$.System.EventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 1179700;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 98959361,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181048884),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 79757313
        }
      ],
      "n": "Invoke",
      "d": 1179700,
      "h": 17181048884,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181048884),
//--TRIMMABLE-BOUNDARY-START(8591114292),
    {
      "r": 89784321,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 79757313
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 1179700,
      "h": 8591114292,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591114292),
//--TRIMMABLE-BOUNDARY-START(12886081588),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 89784321
        }
      ],
      "n": "EndInvoke",
      "d": 1179700,
      "h": 12886081588,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886081588)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296146996),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1179700,
      "h": 4296146996,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296146996)
  ],
  "i": [89980929,157483009
  ],
  "h": 1179700
}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAddressChangedEventHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179700)
        
        
        //--TRIMMABLE-BOUNDARY-START(1245236)
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler", ($self) => class NetworkAvailabilityChangedEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Nullable$$*/ sender, /*$.$snn.System.Net.NetworkInformation.NetworkAvailabilityEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 1245236;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 98959361,
  "m": [
//--TRIMMABLE-BOUNDARY-START(17181114420),
    {
      "r": 65537,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 1310772
        }
      ],
      "n": "Invoke",
      "d": 1245236,
      "h": 17181114420,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17181114420),
//--TRIMMABLE-BOUNDARY-START(8591179828),
    {
      "r": 89784321,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "e",
          "p": 1310772
        },
        {
          "n": "callback",
          "p": 45285377
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 1245236,
      "h": 8591179828,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8591179828),
//--TRIMMABLE-BOUNDARY-START(12886147124),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 89784321
        }
      ],
      "n": "EndInvoke",
      "d": 1245236,
      "h": 12886147124,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886147124)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296212532),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1245236,
      "h": 4296212532,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296212532)
  ],
  "i": [89980929,157483009
  ],
  "h": 1245236
}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245236)
        
        
        //--TRIMMABLE-BOUNDARY-START(65588)
        $asm.$str("$snn.System.Net.NetworkInformation.DuplicateAddressDetectionState", ($self) => class DuplicateAddressDetectionState extends $.$$.System.Enum
        {
            static Invalid = 0;
            static Tentative = 1;
            static Duplicate = 2;
            static Deprecated = 3;
            static Preferred = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(65588);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Invalid": 0n,
                    "Tentative": 1n,
                    "Duplicate": 2n,
                    "Deprecated": 3n,
                    "Preferred": 4n
                };
            }
            static $h = 65588;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17179934772),
    {
      "t": 65588,
      "n": "Invalid",
      "d": 65588,
      "h": 17179934772,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17179934772),
//--TRIMMABLE-BOUNDARY-START(25769869364),
    {
      "t": 65588,
      "n": "Tentative",
      "d": 65588,
      "h": 25769869364,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25769869364),
//--TRIMMABLE-BOUNDARY-START(12884967476),
    {
      "t": 65588,
      "n": "Duplicate",
      "d": 65588,
      "h": 12884967476,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12884967476),
//--TRIMMABLE-BOUNDARY-START(8590000180),
    {
      "t": 65588,
      "n": "Deprecated",
      "d": 65588,
      "h": 8590000180,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590000180),
//--TRIMMABLE-BOUNDARY-START(21474902068),
    {
      "t": 65588,
      "n": "Preferred",
      "d": 65588,
      "h": 21474902068,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21474902068)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032884),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65588,
      "h": 4295032884,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032884)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 65588
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.DuplicateAddressDetectionState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65588)
        
        
        //--TRIMMABLE-BOUNDARY-START(1114164)
        $asm.$str("$snn.System.Net.NetworkInformation.NetBiosNodeType", ($self) => class NetBiosNodeType extends $.$$.System.Enum
        {
            static Unknown = 0;
            static Broadcast = 1;
            static Peer2Peer = 2;
            static Mixed = 4;
            static Hybrid = 8;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1114164);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Broadcast": 1n,
                    "Peer2Peer": 2n,
                    "Mixed": 4n,
                    "Hybrid": 8n
                };
            }
            static $h = 1114164;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770917940),
    {
      "t": 1114164,
      "n": "Unknown",
      "d": 1114164,
      "h": 25770917940,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770917940),
//--TRIMMABLE-BOUNDARY-START(8591048756),
    {
      "t": 1114164,
      "n": "Broadcast",
      "d": 1114164,
      "h": 8591048756,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591048756),
//--TRIMMABLE-BOUNDARY-START(21475950644),
    {
      "t": 1114164,
      "n": "Peer2Peer",
      "d": 1114164,
      "h": 21475950644,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475950644),
//--TRIMMABLE-BOUNDARY-START(17180983348),
    {
      "t": 1114164,
      "n": "Mixed",
      "d": 1114164,
      "h": 17180983348,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180983348),
//--TRIMMABLE-BOUNDARY-START(12886016052),
    {
      "t": 1114164,
      "n": "Hybrid",
      "d": 1114164,
      "h": 12886016052,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886016052)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296081460),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1114164,
      "h": 4296081460,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296081460)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1114164
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetBiosNodeType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114164)
        
        
        //--TRIMMABLE-BOUNDARY-START(1572916)
        $asm.$str("$snn.System.Net.NetworkInformation.NetworkInterfaceComponent", ($self) => class NetworkInterfaceComponent extends $.$$.System.Enum
        {
            static IPv4 = 0;
            static IPv6 = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1572916);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "IPv4": 0n,
                    "IPv6": 1n
                };
            }
            static $h = 1572916;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591507508),
    {
      "t": 1572916,
      "n": "IPv4",
      "d": 1572916,
      "h": 8591507508,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591507508),
//--TRIMMABLE-BOUNDARY-START(12886474804),
    {
      "t": 1572916,
      "n": "IPv6",
      "d": 1572916,
      "h": 12886474804,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886474804)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540212),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1572916,
      "h": 4296540212,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296540212)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1572916
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterfaceComponent`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572916)
        
        
        //--TRIMMABLE-BOUNDARY-START(1638452)
        $asm.$str("$snn.System.Net.NetworkInformation.NetworkInterfaceType", ($self) => class NetworkInterfaceType extends $.$$.System.Enum
        {
            static Unknown = 1;
            static Ethernet = 6;
            static TokenRing = 9;
            static Fddi = 15;
            static BasicIsdn = 20;
            static PrimaryIsdn = 21;
            static Ppp = 23;
            static Loopback = 24;
            static Ethernet3Megabit = 26;
            static Slip = 28;
            static Atm = 37;
            static GenericModem = 48;
            static FastEthernetT = 62;
            static Isdn = 63;
            static FastEthernetFx = 69;
            static Wireless80211 = 71;
            static AsymmetricDsl = 94;
            static RateAdaptDsl = 95;
            static SymmetricDsl = 96;
            static VeryHighSpeedDsl = 97;
            static IPOverAtm = 114;
            static GigabitEthernet = 117;
            static Tunnel = 131;
            static MultiRateSymmetricDsl = 143;
            static HighPerformanceSerialBus = 144;
            static Wman = 237;
            static Wwanpp = 243;
            static Wwanpp2 = 244;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1638452);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unknown": 1n,
                    "Ethernet": 6n,
                    "TokenRing": 9n,
                    "Fddi": 15n,
                    "BasicIsdn": 20n,
                    "PrimaryIsdn": 21n,
                    "Ppp": 23n,
                    "Loopback": 24n,
                    "Ethernet3Megabit": 26n,
                    "Slip": 28n,
                    "Atm": 37n,
                    "GenericModem": 48n,
                    "FastEthernetT": 62n,
                    "Isdn": 63n,
                    "FastEthernetFx": 69n,
                    "Wireless80211": 71n,
                    "AsymmetricDsl": 94n,
                    "RateAdaptDsl": 95n,
                    "SymmetricDsl": 96n,
                    "VeryHighSpeedDsl": 97n,
                    "IPOverAtm": 114n,
                    "GigabitEthernet": 117n,
                    "Tunnel": 131n,
                    "MultiRateSymmetricDsl": 143n,
                    "HighPerformanceSerialBus": 144n,
                    "Wman": 237n,
                    "Wwanpp": 243n,
                    "Wwanpp2": 244n
                };
            }
            static $h = 1638452;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(103080853556),
    {
      "t": 1638452,
      "n": "Unknown",
      "d": 1638452,
      "h": 103080853556,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103080853556),
//--TRIMMABLE-BOUNDARY-START(21476474932),
    {
      "t": 1638452,
      "n": "Ethernet",
      "d": 1638452,
      "h": 21476474932,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476474932),
//--TRIMMABLE-BOUNDARY-START(94490918964),
    {
      "t": 1638452,
      "n": "TokenRing",
      "d": 1638452,
      "h": 94490918964,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94490918964),
//--TRIMMABLE-BOUNDARY-START(38656344116),
    {
      "t": 1638452,
      "n": "Fddi",
      "d": 1638452,
      "h": 38656344116,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656344116),
//--TRIMMABLE-BOUNDARY-START(17181507636),
    {
      "t": 1638452,
      "n": "BasicIsdn",
      "d": 1638452,
      "h": 17181507636,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181507636),
//--TRIMMABLE-BOUNDARY-START(77311049780),
    {
      "t": 1638452,
      "n": "PrimaryIsdn",
      "d": 1638452,
      "h": 77311049780,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77311049780),
//--TRIMMABLE-BOUNDARY-START(73016082484),
    {
      "t": 1638452,
      "n": "Ppp",
      "d": 1638452,
      "h": 73016082484,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73016082484),
//--TRIMMABLE-BOUNDARY-START(64426147892),
    {
      "t": 1638452,
      "n": "Loopback",
      "d": 1638452,
      "h": 64426147892,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64426147892),
//--TRIMMABLE-BOUNDARY-START(25771442228),
    {
      "t": 1638452,
      "n": "Ethernet3Megabit",
      "d": 1638452,
      "h": 25771442228,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771442228),
//--TRIMMABLE-BOUNDARY-START(85900984372),
    {
      "t": 1638452,
      "n": "Slip",
      "d": 1638452,
      "h": 85900984372,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85900984372),
//--TRIMMABLE-BOUNDARY-START(12886540340),
    {
      "t": 1638452,
      "n": "Atm",
      "d": 1638452,
      "h": 12886540340,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886540340),
//--TRIMMABLE-BOUNDARY-START(42951311412),
    {
      "t": 1638452,
      "n": "GenericModem",
      "d": 1638452,
      "h": 42951311412,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951311412),
//--TRIMMABLE-BOUNDARY-START(34361376820),
    {
      "t": 1638452,
      "n": "FastEthernetT",
      "d": 1638452,
      "h": 34361376820,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361376820),
//--TRIMMABLE-BOUNDARY-START(60131180596),
    {
      "t": 1638452,
      "n": "Isdn",
      "d": 1638452,
      "h": 60131180596,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60131180596),
//--TRIMMABLE-BOUNDARY-START(30066409524),
    {
      "t": 1638452,
      "n": "FastEthernetFx",
      "d": 1638452,
      "h": 30066409524,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066409524),
//--TRIMMABLE-BOUNDARY-START(111670788148),
    {
      "t": 1638452,
      "n": "Wireless80211",
      "d": 1638452,
      "h": 111670788148,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111670788148),
//--TRIMMABLE-BOUNDARY-START(8591573044),
    {
      "t": 1638452,
      "n": "AsymmetricDsl",
      "d": 1638452,
      "h": 8591573044,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591573044),
//--TRIMMABLE-BOUNDARY-START(81606017076),
    {
      "t": 1638452,
      "n": "RateAdaptDsl",
      "d": 1638452,
      "h": 81606017076,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81606017076),
//--TRIMMABLE-BOUNDARY-START(90195951668),
    {
      "t": 1638452,
      "n": "SymmetricDsl",
      "d": 1638452,
      "h": 90195951668,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90195951668),
//--TRIMMABLE-BOUNDARY-START(107375820852),
    {
      "t": 1638452,
      "n": "VeryHighSpeedDsl",
      "d": 1638452,
      "h": 107375820852,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107375820852),
//--TRIMMABLE-BOUNDARY-START(55836213300),
    {
      "t": 1638452,
      "n": "IPOverAtm",
      "d": 1638452,
      "h": 55836213300,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55836213300),
//--TRIMMABLE-BOUNDARY-START(47246278708),
    {
      "t": 1638452,
      "n": "GigabitEthernet",
      "d": 1638452,
      "h": 47246278708,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246278708),
//--TRIMMABLE-BOUNDARY-START(98785886260),
    {
      "t": 1638452,
      "n": "Tunnel",
      "d": 1638452,
      "h": 98785886260,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98785886260),
//--TRIMMABLE-BOUNDARY-START(68721115188),
    {
      "t": 1638452,
      "n": "MultiRateSymmetricDsl",
      "d": 1638452,
      "h": 68721115188,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68721115188),
//--TRIMMABLE-BOUNDARY-START(51541246004),
    {
      "t": 1638452,
      "n": "HighPerformanceSerialBus",
      "d": 1638452,
      "h": 51541246004,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541246004),
//--TRIMMABLE-BOUNDARY-START(115965755444),
    {
      "t": 1638452,
      "n": "Wman",
      "d": 1638452,
      "h": 115965755444,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115965755444),
//--TRIMMABLE-BOUNDARY-START(120260722740),
    {
      "t": 1638452,
      "n": "Wwanpp",
      "d": 1638452,
      "h": 120260722740,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120260722740),
//--TRIMMABLE-BOUNDARY-START(124555690036),
    {
      "t": 1638452,
      "n": "Wwanpp2",
      "d": 1638452,
      "h": 124555690036,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124555690036)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605748),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1638452,
      "h": 4296605748,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296605748)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1638452
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterfaceType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638452)
        
        
        //--TRIMMABLE-BOUNDARY-START(1703988)
        $asm.$str("$snn.System.Net.NetworkInformation.OperationalStatus", ($self) => class OperationalStatus extends $.$$.System.Enum
        {
            static Up = 1;
            static Down = 2;
            static Testing = 3;
            static Unknown = 4;
            static Dormant = 5;
            static NotPresent = 6;
            static LowerLayerDown = 7;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1703988);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Up": 1n,
                    "Down": 2n,
                    "Testing": 3n,
                    "Unknown": 4n,
                    "Dormant": 5n,
                    "NotPresent": 6n,
                    "LowerLayerDown": 7n
                };
            }
            static $h = 1703988;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(34361442356),
    {
      "t": 1703988,
      "n": "Up",
      "d": 1703988,
      "h": 34361442356,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361442356),
//--TRIMMABLE-BOUNDARY-START(12886605876),
    {
      "t": 1703988,
      "n": "Down",
      "d": 1703988,
      "h": 12886605876,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886605876),
//--TRIMMABLE-BOUNDARY-START(25771507764),
    {
      "t": 1703988,
      "n": "Testing",
      "d": 1703988,
      "h": 25771507764,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771507764),
//--TRIMMABLE-BOUNDARY-START(30066475060),
    {
      "t": 1703988,
      "n": "Unknown",
      "d": 1703988,
      "h": 30066475060,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066475060),
//--TRIMMABLE-BOUNDARY-START(8591638580),
    {
      "t": 1703988,
      "n": "Dormant",
      "d": 1703988,
      "h": 8591638580,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591638580),
//--TRIMMABLE-BOUNDARY-START(21476540468),
    {
      "t": 1703988,
      "n": "NotPresent",
      "d": 1703988,
      "h": 21476540468,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476540468),
//--TRIMMABLE-BOUNDARY-START(17181573172),
    {
      "t": 1703988,
      "n": "LowerLayerDown",
      "d": 1703988,
      "h": 17181573172,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181573172)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296671284),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1703988,
      "h": 4296671284,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296671284)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1703988
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.OperationalStatus`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1703988)
        
        
        //--TRIMMABLE-BOUNDARY-START(1835060)
        $asm.$str("$snn.System.Net.NetworkInformation.PrefixOrigin", ($self) => class PrefixOrigin extends $.$$.System.Enum
        {
            static Other = 0;
            static Manual = 1;
            static WellKnown = 2;
            static Dhcp = 3;
            static RouterAdvertisement = 4;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1835060);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Other": 0n,
                    "Manual": 1n,
                    "WellKnown": 2n,
                    "Dhcp": 3n,
                    "RouterAdvertisement": 4n
                };
            }
            static $h = 1835060;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181704244),
    {
      "t": 1835060,
      "n": "Other",
      "d": 1835060,
      "h": 17181704244,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181704244),
//--TRIMMABLE-BOUNDARY-START(12886736948),
    {
      "t": 1835060,
      "n": "Manual",
      "d": 1835060,
      "h": 12886736948,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886736948),
//--TRIMMABLE-BOUNDARY-START(25771638836),
    {
      "t": 1835060,
      "n": "WellKnown",
      "d": 1835060,
      "h": 25771638836,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771638836),
//--TRIMMABLE-BOUNDARY-START(8591769652),
    {
      "t": 1835060,
      "n": "Dhcp",
      "d": 1835060,
      "h": 8591769652,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591769652),
//--TRIMMABLE-BOUNDARY-START(21476671540),
    {
      "t": 1835060,
      "n": "RouterAdvertisement",
      "d": 1835060,
      "h": 21476671540,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476671540)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296802356),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1835060,
      "h": 4296802356,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296802356)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1835060
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.PrefixOrigin`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1835060)
        
        
        //--TRIMMABLE-BOUNDARY-START(1900596)
        $asm.$str("$snn.System.Net.NetworkInformation.ScopeLevel", ($self) => class ScopeLevel extends $.$$.System.Enum
        {
            static None = 0;
            static Interface = 1;
            static Link = 2;
            static Subnet = 3;
            static Admin = 4;
            static Site = 5;
            static Organization = 8;
            static Global = 14;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1900596);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Interface": 1n,
                    "Link": 2n,
                    "Subnet": 3n,
                    "Admin": 4n,
                    "Site": 5n,
                    "Organization": 8n,
                    "Global": 14n
                };
            }
            static $h = 1900596;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25771704372),
    {
      "t": 1900596,
      "n": "None",
      "d": 1900596,
      "h": 25771704372,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771704372),
//--TRIMMABLE-BOUNDARY-START(17181769780),
    {
      "t": 1900596,
      "n": "Interface",
      "d": 1900596,
      "h": 17181769780,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181769780),
//--TRIMMABLE-BOUNDARY-START(21476737076),
    {
      "t": 1900596,
      "n": "Link",
      "d": 1900596,
      "h": 21476737076,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476737076),
//--TRIMMABLE-BOUNDARY-START(38656606260),
    {
      "t": 1900596,
      "n": "Subnet",
      "d": 1900596,
      "h": 38656606260,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656606260),
//--TRIMMABLE-BOUNDARY-START(8591835188),
    {
      "t": 1900596,
      "n": "Admin",
      "d": 1900596,
      "h": 8591835188,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591835188),
//--TRIMMABLE-BOUNDARY-START(34361638964),
    {
      "t": 1900596,
      "n": "Site",
      "d": 1900596,
      "h": 34361638964,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361638964),
//--TRIMMABLE-BOUNDARY-START(30066671668),
    {
      "t": 1900596,
      "n": "Organization",
      "d": 1900596,
      "h": 30066671668,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066671668),
//--TRIMMABLE-BOUNDARY-START(12886802484),
    {
      "t": 1900596,
      "n": "Global",
      "d": 1900596,
      "h": 12886802484,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886802484)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296867892),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1900596,
      "h": 4296867892,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296867892)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1900596
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.ScopeLevel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1900596)
        
        
        //--TRIMMABLE-BOUNDARY-START(1966132)
        $asm.$str("$snn.System.Net.NetworkInformation.SuffixOrigin", ($self) => class SuffixOrigin extends $.$$.System.Enum
        {
            static Other = 0;
            static Manual = 1;
            static WellKnown = 2;
            static OriginDhcp = 3;
            static LinkLayerAddress = 4;
            static Random = 5;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1966132);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Other": 0n,
                    "Manual": 1n,
                    "WellKnown": 2n,
                    "OriginDhcp": 3n,
                    "LinkLayerAddress": 4n,
                    "Random": 5n
                };
            }
            static $h = 1966132;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(21476802612),
    {
      "t": 1966132,
      "n": "Other",
      "d": 1966132,
      "h": 21476802612,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476802612),
//--TRIMMABLE-BOUNDARY-START(12886868020),
    {
      "t": 1966132,
      "n": "Manual",
      "d": 1966132,
      "h": 12886868020,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886868020),
//--TRIMMABLE-BOUNDARY-START(30066737204),
    {
      "t": 1966132,
      "n": "WellKnown",
      "d": 1966132,
      "h": 30066737204,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066737204),
//--TRIMMABLE-BOUNDARY-START(17181835316),
    {
      "t": 1966132,
      "n": "OriginDhcp",
      "d": 1966132,
      "h": 17181835316,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181835316),
//--TRIMMABLE-BOUNDARY-START(8591900724),
    {
      "t": 1966132,
      "n": "LinkLayerAddress",
      "d": 1966132,
      "h": 8591900724,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591900724),
//--TRIMMABLE-BOUNDARY-START(25771769908),
    {
      "t": 1966132,
      "n": "Random",
      "d": 1966132,
      "h": 25771769908,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771769908)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296933428),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1966132,
      "h": 4296933428,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296933428)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 1966132
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.SuffixOrigin`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966132)
        
        
        //--TRIMMABLE-BOUNDARY-START(2097204)
        $asm.$str("$snn.System.Net.NetworkInformation.TcpState", ($self) => class TcpState extends $.$$.System.Enum
        {
            static Unknown = 0;
            static Closed = 1;
            static Listen = 2;
            static SynSent = 3;
            static SynReceived = 4;
            static Established = 5;
            static FinWait1 = 6;
            static FinWait2 = 7;
            static CloseWait = 8;
            static Closing = 9;
            static LastAck = 10;
            static TimeWait = 11;
            static DeleteTcb = 12;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(2097204);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Closed": 1n,
                    "Listen": 2n,
                    "SynSent": 3n,
                    "SynReceived": 4n,
                    "Established": 5n,
                    "FinWait1": 6n,
                    "FinWait2": 7n,
                    "CloseWait": 8n,
                    "Closing": 9n,
                    "LastAck": 10n,
                    "TimeWait": 11n,
                    "DeleteTcb": 12n
                };
            }
            static $h = 2097204;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 1048577,
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(60131639348),
    {
      "t": 2097204,
      "n": "Unknown",
      "d": 2097204,
      "h": 60131639348,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60131639348),
//--TRIMMABLE-BOUNDARY-START(8592031796),
    {
      "t": 2097204,
      "n": "Closed",
      "d": 2097204,
      "h": 8592031796,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8592031796),
//--TRIMMABLE-BOUNDARY-START(42951770164),
    {
      "t": 2097204,
      "n": "Listen",
      "d": 2097204,
      "h": 42951770164,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951770164),
//--TRIMMABLE-BOUNDARY-START(51541704756),
    {
      "t": 2097204,
      "n": "SynSent",
      "d": 2097204,
      "h": 51541704756,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541704756),
//--TRIMMABLE-BOUNDARY-START(47246737460),
    {
      "t": 2097204,
      "n": "SynReceived",
      "d": 2097204,
      "h": 47246737460,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246737460),
//--TRIMMABLE-BOUNDARY-START(25771900980),
    {
      "t": 2097204,
      "n": "Established",
      "d": 2097204,
      "h": 25771900980,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771900980),
//--TRIMMABLE-BOUNDARY-START(30066868276),
    {
      "t": 2097204,
      "n": "FinWait1",
      "d": 2097204,
      "h": 30066868276,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066868276),
//--TRIMMABLE-BOUNDARY-START(34361835572),
    {
      "t": 2097204,
      "n": "FinWait2",
      "d": 2097204,
      "h": 34361835572,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361835572),
//--TRIMMABLE-BOUNDARY-START(12886999092),
    {
      "t": 2097204,
      "n": "CloseWait",
      "d": 2097204,
      "h": 12886999092,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886999092),
//--TRIMMABLE-BOUNDARY-START(17181966388),
    {
      "t": 2097204,
      "n": "Closing",
      "d": 2097204,
      "h": 17181966388,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181966388),
//--TRIMMABLE-BOUNDARY-START(38656802868),
    {
      "t": 2097204,
      "n": "LastAck",
      "d": 2097204,
      "h": 38656802868,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656802868),
//--TRIMMABLE-BOUNDARY-START(55836672052),
    {
      "t": 2097204,
      "n": "TimeWait",
      "d": 2097204,
      "h": 55836672052,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55836672052),
//--TRIMMABLE-BOUNDARY-START(21476933684),
    {
      "t": 2097204,
      "n": "DeleteTcb",
      "d": 2097204,
      "h": 21476933684,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476933684)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4297064500),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 2097204,
      "h": 4297064500,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4297064500)
  ],
  "i": [90046465,96600065,90505217,90177537
  ],
  "h": 2097204
}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpState`; }
        });
        //--TRIMMABLE-BOUNDARY-END(2097204)
        
        
        //--TRIMMABLE-BOUNDARY-START(1310772)
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAvailabilityEventArgs", ($self) => class NetworkAvailabilityEventArgs extends $.$$.System.EventArgs
        {
            //--TRIMMABLE-BOUNDARY-START(4296278068)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296278068);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296278068)
            
            //--TRIMMABLE-BOUNDARY-START(17181179956)
            /*bool */ get IsAvailable()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886212660);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17181179956)
            
            static $h = 1310772;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 79757313,
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181179956),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12886212660,
        "f": 50331649
      },
      "n": "IsAvailable",
      "d": 1310772,
      "h": 17181179956,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181179956)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278068),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1310772,
      "h": 4296278068,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296278068)
  ],
  "h": 1310772
}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAvailabilityEventArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310772)
        
        
        //--TRIMMABLE-BOUNDARY-START(1441844)
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkInformationException", ($self) => class NetworkInformationException extends $.$$.System.ComponentModel.Win32Exception
        {
            //--TRIMMABLE-BOUNDARY-START(4296409140)
            $ctor$20()
            {
                super.$ctor$14();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296409140);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296409140)
            
            //--TRIMMABLE-BOUNDARY-START(8591376436)
            $ctor$21(/*int*/ errorCode)
            {
                super.$ctor$14();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591376436);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591376436)
            
            //--TRIMMABLE-BOUNDARY-START(12886343732)
            $ctor$22(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$14();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886343732);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886343732)
            
            //--TRIMMABLE-BOUNDARY-START(17181311028)
            /*int */ get ErrorCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771245620);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17181311028)
            
            static $h = 1441844;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {
  "b": 64421889,
  "h": 1441844
}; }
            static get $b() { return $.$$.System.ComponentModel.Win32Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInformationException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441844)
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets"))
//--TRIMMABLE-BOUNDARY-END(52)
