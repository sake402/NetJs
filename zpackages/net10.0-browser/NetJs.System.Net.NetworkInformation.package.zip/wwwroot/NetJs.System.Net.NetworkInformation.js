
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stee, $scsl, $snv, $sri, $sl, $stt, $sttp, $sdd, $snp, $ssc, $sspw, $sto, $snnr, $sns) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.NetworkInformation", 
    {"h":47347,"f":"System.Net.NetworkInformation","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.NetworkInformation","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.NetworkInformation","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snn.System.Net.NetworkInformation.GatewayIPAddressInformation", ($self) => class GatewayIPAddressInformation extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 178419;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3064565,"g":{"r":0,"d":0,"h":12885080307,"f":50331905},"n":"Address","d":178419,"h":8590113011,"f":2097409}],"c":[{"n":".ctor","o":"$ctor$1","d":178419,"h":4295145715,"f":16777220}],"h":178419}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.GatewayIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IcmpV4Statistics", ($self) => class IcmpV4Statistics extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 309491;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885211379,"f":50331905},"n":"AddressMaskRepliesReceived","d":309491,"h":8590244083,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":21475145971,"f":50331905},"n":"AddressMaskRepliesSent","d":309491,"h":17180178675,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":30065080563,"f":50331905},"n":"AddressMaskRequestsReceived","d":309491,"h":25770113267,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":38655015155,"f":50331905},"n":"AddressMaskRequestsSent","d":309491,"h":34360047859,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":47244949747,"f":50331905},"n":"DestinationUnreachableMessagesReceived","d":309491,"h":42949982451,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":55834884339,"f":50331905},"n":"DestinationUnreachableMessagesSent","d":309491,"h":51539917043,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":64424818931,"f":50331905},"n":"EchoRepliesReceived","d":309491,"h":60129851635,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":73014753523,"f":50331905},"n":"EchoRepliesSent","d":309491,"h":68719786227,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":81604688115,"f":50331905},"n":"EchoRequestsReceived","d":309491,"h":77309720819,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":90194622707,"f":50331905},"n":"EchoRequestsSent","d":309491,"h":85899655411,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":98784557299,"f":50331905},"n":"ErrorsReceived","d":309491,"h":94489590003,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"freebsd","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"osx","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":107374491891,"f":50331905},"n":"ErrorsSent","d":309491,"h":103079524595,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"freebsd","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"osx","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":115964426483,"f":50331905},"n":"MessagesReceived","d":309491,"h":111669459187,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"freebsd","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"osx","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":124554361075,"f":50331905},"n":"MessagesSent","d":309491,"h":120259393779,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"freebsd","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"osx","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":133144295667,"f":50331905},"n":"ParameterProblemsReceived","d":309491,"h":128849328371,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":141734230259,"f":50331905},"n":"ParameterProblemsSent","d":309491,"h":137439262963,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":150324164851,"f":50331905},"n":"RedirectsReceived","d":309491,"h":146029197555,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":158914099443,"f":50331905},"n":"RedirectsSent","d":309491,"h":154619132147,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":167504034035,"f":50331905},"n":"SourceQuenchesReceived","d":309491,"h":163209066739,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":176093968627,"f":50331905},"n":"SourceQuenchesSent","d":309491,"h":171799001331,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":184683903219,"f":50331905},"n":"TimeExceededMessagesReceived","d":309491,"h":180388935923,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":193273837811,"f":50331905},"n":"TimeExceededMessagesSent","d":309491,"h":188978870515,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":201863772403,"f":50331905},"n":"TimestampRepliesReceived","d":309491,"h":197568805107,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":210453706995,"f":50331905},"n":"TimestampRepliesSent","d":309491,"h":206158739699,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":219043641587,"f":50331905},"n":"TimestampRequestsReceived","d":309491,"h":214748674291,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":227633576179,"f":50331905},"n":"TimestampRequestsSent","d":309491,"h":223338608883,"f":2097409}],"c":[{"n":".ctor","o":"$ctor$1","d":309491,"h":4295276787,"f":16777220}],"h":309491}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IcmpV4Statistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IcmpV6Statistics", ($self) => class IcmpV6Statistics extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 375027;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885276915,"f":50331905},"n":"DestinationUnreachableMessagesReceived","d":375027,"h":8590309619,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":21475211507,"f":50331905},"n":"DestinationUnreachableMessagesSent","d":375027,"h":17180244211,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":30065146099,"f":50331905},"n":"EchoRepliesReceived","d":375027,"h":25770178803,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":38655080691,"f":50331905},"n":"EchoRepliesSent","d":375027,"h":34360113395,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":47245015283,"f":50331905},"n":"EchoRequestsReceived","d":375027,"h":42950047987,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":55834949875,"f":50331905},"n":"EchoRequestsSent","d":375027,"h":51539982579,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":64424884467,"f":50331905},"n":"ErrorsReceived","d":375027,"h":60129917171,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"freebsd","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"osx","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73014819059,"f":50331905},"n":"ErrorsSent","d":375027,"h":68719851763,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"freebsd","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"osx","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81604753651,"f":50331905},"n":"MembershipQueriesReceived","d":375027,"h":77309786355,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":90194688243,"f":50331905},"n":"MembershipQueriesSent","d":375027,"h":85899720947,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":98784622835,"f":50331905},"n":"MembershipReductionsReceived","d":375027,"h":94489655539,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":107374557427,"f":50331905},"n":"MembershipReductionsSent","d":375027,"h":103079590131,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":115964492019,"f":50331905},"n":"MembershipReportsReceived","d":375027,"h":111669524723,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":124554426611,"f":50331905},"n":"MembershipReportsSent","d":375027,"h":120259459315,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":133144361203,"f":50331905},"n":"MessagesReceived","d":375027,"h":128849393907,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"freebsd","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"osx","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":141734295795,"f":50331905},"n":"MessagesSent","d":375027,"h":137439328499,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"freebsd","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"osx","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":150324230387,"f":50331905},"n":"NeighborAdvertisementsReceived","d":375027,"h":146029263091,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":158914164979,"f":50331905},"n":"NeighborAdvertisementsSent","d":375027,"h":154619197683,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":167504099571,"f":50331905},"n":"NeighborSolicitsReceived","d":375027,"h":163209132275,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":176094034163,"f":50331905},"n":"NeighborSolicitsSent","d":375027,"h":171799066867,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":184683968755,"f":50331905},"n":"PacketTooBigMessagesReceived","d":375027,"h":180389001459,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":193273903347,"f":50331905},"n":"PacketTooBigMessagesSent","d":375027,"h":188978936051,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":201863837939,"f":50331905},"n":"ParameterProblemsReceived","d":375027,"h":197568870643,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":210453772531,"f":50331905},"n":"ParameterProblemsSent","d":375027,"h":206158805235,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":219043707123,"f":50331905},"n":"RedirectsReceived","d":375027,"h":214748739827,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":227633641715,"f":50331905},"n":"RedirectsSent","d":375027,"h":223338674419,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":236223576307,"f":50331905},"n":"RouterAdvertisementsReceived","d":375027,"h":231928609011,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":244813510899,"f":50331905},"n":"RouterAdvertisementsSent","d":375027,"h":240518543603,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":253403445491,"f":50331905},"n":"RouterSolicitsReceived","d":375027,"h":249108478195,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":261993380083,"f":50331905},"n":"RouterSolicitsSent","d":375027,"h":257698412787,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":270583314675,"f":50331905},"n":"TimeExceededMessagesReceived","d":375027,"h":266288347379,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":279173249267,"f":50331905},"n":"TimeExceededMessagesSent","d":375027,"h":274878281971,"f":2097409}],"c":[{"n":".ctor","o":"$ctor$1","d":375027,"h":4295342323,"f":16777220}],"h":375027}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IcmpV6Statistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPAddressInformation", ($self) => class IPAddressInformation extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 440563;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3064565,"g":{"r":0,"d":0,"h":12885342451,"f":50331905},"n":"Address","d":440563,"h":8590375155,"f":2097409},{"p":262145,"g":{"r":0,"d":0,"h":21475277043,"f":50331905},"n":"IsDnsEligible","d":440563,"h":17180309747,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":30065211635,"f":50331905},"n":"IsTransient","d":440563,"h":25770244339,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":440563,"h":4295407859,"f":16777220}],"h":440563}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPGlobalProperties", ($self) => class IPGlobalProperties extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.IAsyncResult */ BeginGetUnicastAddresses(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformationCollection */ EndGetUnicastAddresses(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.IPGlobalProperties */ GetIPGlobalProperties()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformationCollection */ GetUnicastAddresses()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.NetworkInformation.UnicastIPAddressInformationCollection> */ GetUnicastAddressesAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 571635;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885473523,"f":50331905},"n":"DhcpScopeName","d":571635,"h":8590506227,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":21475408115,"f":50331905},"n":"DomainName","d":571635,"h":17180440819,"f":2097409},{"p":1310721,"g":{"r":0,"d":0,"h":30065342707,"f":50331905},"n":"HostName","d":571635,"h":25770375411,"f":2097409},{"p":262145,"g":{"r":0,"d":0,"h":38655277299,"f":50331905},"n":"IsWinsProxy","d":571635,"h":34360310003,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":1161459,"g":{"r":0,"d":0,"h":47245211891,"f":50331905},"n":"NodeType","d":571635,"h":42950244595,"f":2097409}],"m":[{"r":57016321,"p":[{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginGetUnicastAddresses","d":571635,"h":51540179187,"f":16777345},{"r":2406643,"p":[{"n":"asyncResult","p":57016321}],"n":"EndGetUnicastAddresses","d":571635,"h":55835146483,"f":16777345},{"r":$.$typeArray($.$snn.System.Net.NetworkInformation.TcpConnectionInformation).$h,"n":"GetActiveTcpConnections","d":571635,"h":60130113779,"f":16777473,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"r":$.$typeArray($.$snp.System.Net.IPEndPoint).$h,"n":"GetActiveTcpListeners","d":571635,"h":64425081075,"f":16777473,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"r":$.$typeArray($.$snp.System.Net.IPEndPoint).$h,"n":"GetActiveUdpListeners","d":571635,"h":68720048371,"f":16777473,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"r":309491,"n":"GetIcmpV4Statistics","d":571635,"h":73015015667,"f":16777473,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"r":375027,"n":"GetIcmpV6Statistics","d":571635,"h":77309982963,"f":16777473,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"r":571635,"n":"GetIPGlobalProperties","d":571635,"h":81604950259,"f":16777249,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"illumos","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"solaris","t":1310721}]}]},{"r":637171,"n":"GetIPv4GlobalStatistics","d":571635,"h":85899917555,"f":16777473},{"r":637171,"n":"GetIPv6GlobalStatistics","d":571635,"h":90194884851,"f":16777473,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"freebsd","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"osx","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]}]},{"r":2210035,"n":"GetTcpIPv4Statistics","d":571635,"h":94489852147,"f":16777473,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"r":2210035,"n":"GetTcpIPv6Statistics","d":571635,"h":98784819443,"f":16777473,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"r":2275571,"n":"GetUdpIPv4Statistics","d":571635,"h":103079786739,"f":16777473,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"r":2275571,"n":"GetUdpIPv6Statistics","d":571635,"h":107374754035,"f":16777473,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"r":2406643,"n":"GetUnicastAddresses","d":571635,"h":111669721331,"f":16777345},{"r":$.$$.System.Threading.Tasks.Task$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformationCollection).$h,"n":"GetUnicastAddressesAsync","d":571635,"h":115964688627,"f":16777345}],"c":[{"n":".ctor","o":"$ctor$1","d":571635,"h":4295538931,"f":16777220}],"h":571635}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPGlobalProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPGlobalStatistics", ($self) => class IPGlobalStatistics extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 637171;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885539059,"f":50331905},"n":"DefaultTtl","d":637171,"h":8590571763,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":21475473651,"f":50331905},"n":"ForwardingEnabled","d":637171,"h":17180506355,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":30065408243,"f":50331905},"n":"NumberOfInterfaces","d":637171,"h":25770440947,"f":2097409},{"p":655361,"g":{"r":0,"d":0,"h":38655342835,"f":50331905},"n":"NumberOfIPAddresses","d":637171,"h":34360375539,"f":2097409},{"p":655361,"g":{"r":0,"d":0,"h":47245277427,"f":50331905},"n":"NumberOfRoutes","d":637171,"h":42950310131,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":55835212019,"f":50331905},"n":"OutputPacketRequests","d":637171,"h":51540244723,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":64425146611,"f":50331905},"n":"OutputPacketRoutingDiscards","d":637171,"h":60130179315,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73015081203,"f":50331905},"n":"OutputPacketsDiscarded","d":637171,"h":68720113907,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605015795,"f":50331905},"n":"OutputPacketsWithNoRoute","d":637171,"h":77310048499,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":90194950387,"f":50331905},"n":"PacketFragmentFailures","d":637171,"h":85899983091,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":98784884979,"f":50331905},"n":"PacketReassembliesRequired","d":637171,"h":94489917683,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":107374819571,"f":50331905},"n":"PacketReassemblyFailures","d":637171,"h":103079852275,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":115964754163,"f":50331905},"n":"PacketReassemblyTimeout","d":637171,"h":111669786867,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":124554688755,"f":50331905},"n":"PacketsFragmented","d":637171,"h":120259721459,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":133144623347,"f":50331905},"n":"PacketsReassembled","d":637171,"h":128849656051,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":141734557939,"f":50331905},"n":"ReceivedPackets","d":637171,"h":137439590643,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":150324492531,"f":50331905},"n":"ReceivedPacketsDelivered","d":637171,"h":146029525235,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":158914427123,"f":50331905},"n":"ReceivedPacketsDiscarded","d":637171,"h":154619459827,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":167504361715,"f":50331905},"n":"ReceivedPacketsForwarded","d":637171,"h":163209394419,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":176094296307,"f":50331905},"n":"ReceivedPacketsWithAddressErrors","d":637171,"h":171799329011,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":184684230899,"f":50331905},"n":"ReceivedPacketsWithHeadersErrors","d":637171,"h":180389263603,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":193274165491,"f":50331905},"n":"ReceivedPacketsWithUnknownProtocol","d":637171,"h":188979198195,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":637171,"h":4295604467,"f":16777220}],"h":637171}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPGlobalStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPInterfaceProperties", ($self) => class IPInterfaceProperties extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 702707;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":506099,"g":{"r":0,"d":0,"h":12885604595,"f":50331905},"n":"AnycastAddresses","d":702707,"h":8590637299,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":4047605,"g":{"r":0,"d":0,"h":21475539187,"f":50331905},"n":"DhcpServerAddresses","d":702707,"h":17180571891,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"freebsd","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"osx","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]}]},{"p":4047605,"g":{"r":0,"d":0,"h":30065473779,"f":50331905},"n":"DnsAddresses","d":702707,"h":25770506483,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":38655408371,"f":50331905},"n":"DnsSuffix","d":702707,"h":34360441075,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":243955,"g":{"r":0,"d":0,"h":47245342963,"f":50331905},"n":"GatewayAddresses","d":702707,"h":42950375667,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":55835277555,"f":50331905},"n":"IsDnsEnabled","d":702707,"h":51540310259,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"freebsd","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"osx","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":64425212147,"f":50331905},"n":"IsDynamicDnsEnabled","d":702707,"h":60130244851,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":1095923,"g":{"r":0,"d":0,"h":73015146739,"f":50331905},"n":"MulticastAddresses","d":702707,"h":68720179443,"f":2097409},{"p":2406643,"g":{"r":0,"d":0,"h":81605081331,"f":50331905},"n":"UnicastAddresses","d":702707,"h":77310114035,"f":2097409},{"p":4047605,"g":{"r":0,"d":0,"h":90195015923,"f":50331905},"n":"WinsServersAddresses","d":702707,"h":85900048627,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"freebsd","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"osx","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]}]}],"m":[{"r":833779,"n":"GetIPv4Properties","d":702707,"h":94489983219,"f":16777473},{"r":964851,"n":"GetIPv6Properties","d":702707,"h":98784950515,"f":16777473}],"c":[{"n":".ctor","o":"$ctor$1","d":702707,"h":4295670003,"f":16777220}],"h":702707}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPInterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPInterfaceStatistics", ($self) => class IPInterfaceStatistics extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 768243;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885670131,"f":50331905},"n":"BytesReceived","d":768243,"h":8590702835,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":21475604723,"f":50331905},"n":"BytesSent","d":768243,"h":17180637427,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":30065539315,"f":50331905},"n":"IncomingPacketsDiscarded","d":768243,"h":25770572019,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":38655473907,"f":50331905},"n":"IncomingPacketsWithErrors","d":768243,"h":34360506611,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":47245408499,"f":50331905},"n":"IncomingUnknownProtocolPackets","d":768243,"h":42950441203,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"linux","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":55835343091,"f":50331905},"n":"NonUnicastPacketsReceived","d":768243,"h":51540375795,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":64425277683,"f":50331905},"n":"NonUnicastPacketsSent","d":768243,"h":60130310387,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"linux","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73015212275,"f":50331905},"n":"OutgoingPacketsDiscarded","d":768243,"h":68720244979,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"freebsd","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"osx","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605146867,"f":50331905},"n":"OutgoingPacketsWithErrors","d":768243,"h":77310179571,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":90195081459,"f":50331905},"n":"OutputQueueLength","d":768243,"h":85900114163,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":98785016051,"f":50331905},"n":"UnicastPacketsReceived","d":768243,"h":94490048755,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":107374950643,"f":50331905},"n":"UnicastPacketsSent","d":768243,"h":103079983347,"f":2097409}],"c":[{"n":".ctor","o":"$ctor$1","d":768243,"h":4295735539,"f":16777220}],"h":768243}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPInterfaceStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv4InterfaceProperties", ($self) => class IPv4InterfaceProperties extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 833779;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885735667,"f":50331905},"n":"Index","d":833779,"h":8590768371,"f":2097409},{"p":262145,"g":{"r":0,"d":0,"h":21475670259,"f":50331905},"n":"IsAutomaticPrivateAddressingActive","d":833779,"h":17180702963,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":30065604851,"f":50331905},"n":"IsAutomaticPrivateAddressingEnabled","d":833779,"h":25770637555,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":38655539443,"f":50331905},"n":"IsDhcpEnabled","d":833779,"h":34360572147,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":47245474035,"f":50331905},"n":"IsForwardingEnabled","d":833779,"h":42950506739,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"linux","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":55835408627,"f":50331905},"n":"Mtu","d":833779,"h":51540441331,"f":2097409},{"p":262145,"g":{"r":0,"d":0,"h":64425343219,"f":50331905},"n":"UsesWins","d":833779,"h":60130375923,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"linux","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":833779,"h":4295801075,"f":16777220}],"h":833779}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv4InterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv4InterfaceStatistics", ($self) => class IPv4InterfaceStatistics extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 899315;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885801203,"f":50331905},"n":"BytesReceived","d":899315,"h":8590833907,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":21475735795,"f":50331905},"n":"BytesSent","d":899315,"h":17180768499,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":30065670387,"f":50331905},"n":"IncomingPacketsDiscarded","d":899315,"h":25770703091,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":38655604979,"f":50331905},"n":"IncomingPacketsWithErrors","d":899315,"h":34360637683,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":47245539571,"f":50331905},"n":"IncomingUnknownProtocolPackets","d":899315,"h":42950572275,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":55835474163,"f":50331905},"n":"NonUnicastPacketsReceived","d":899315,"h":51540506867,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":64425408755,"f":50331905},"n":"NonUnicastPacketsSent","d":899315,"h":60130441459,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":73015343347,"f":50331905},"n":"OutgoingPacketsDiscarded","d":899315,"h":68720376051,"f":2097409,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"freebsd","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"osx","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605277939,"f":50331905},"n":"OutgoingPacketsWithErrors","d":899315,"h":77310310643,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":90195212531,"f":50331905},"n":"OutputQueueLength","d":899315,"h":85900245235,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":98785147123,"f":50331905},"n":"UnicastPacketsReceived","d":899315,"h":94490179827,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":107375081715,"f":50331905},"n":"UnicastPacketsSent","d":899315,"h":103080114419,"f":2097409}],"c":[{"n":".ctor","o":"$ctor$1","d":899315,"h":4295866611,"f":16777220}],"h":899315}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv4InterfaceStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv6InterfaceProperties", ($self) => class IPv6InterfaceProperties extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*long */ GetScopeId(/*System.Net.NetworkInformation.ScopeLevel*/ scopeLevel)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 964851;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885866739,"f":50331905},"n":"Index","d":964851,"h":8590899443,"f":2097409},{"p":655361,"g":{"r":0,"d":0,"h":21475801331,"f":50331905},"n":"Mtu","d":964851,"h":17180834035,"f":2097409}],"m":[{"r":917505,"p":[{"n":"scopeLevel","p":1947891}],"n":"GetScopeId","d":964851,"h":25770768627,"f":16777345,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"freebsd","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"ios","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"osx","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"tvos","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":964851,"h":4295932147,"f":16777220}],"h":964851}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv6InterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkInterface", ($self) => class NetworkInterface extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string */ get Description()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Id()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get IPv6LoopbackInterfaceIndex()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReceiveOnly()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get LoopbackInterfaceIndex()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.NetworkInterfaceType */ get NetworkInterfaceType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.OperationalStatus */ get OperationalStatus()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Speed()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get SupportsMulticast()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.NetworkInterface[] */ GetAllNetworkInterfaces()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPInterfaceProperties */ GetIPProperties()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPInterfaceStatistics */ GetIPStatistics()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPv4InterfaceStatistics */ GetIPv4Statistics()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ GetIsNetworkAvailable()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.PhysicalAddress */ GetPhysicalAddress()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Supports(/*System.Net.NetworkInformation.NetworkInterfaceComponent*/ networkInterfaceComponent)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1554675;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12886456563,"f":50331777},"n":"Description","d":1554675,"h":8591489267,"f":2097281},{"p":1310721,"g":{"r":0,"d":0,"h":21476391155,"f":50331777},"n":"Id","d":1554675,"h":17181423859,"f":2097281},{"p":655361,"g":{"r":0,"d":0,"h":30066325747,"f":50331681},"n":"IPv6LoopbackInterfaceIndex","d":1554675,"h":25771358451,"f":2097185,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"illumos","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"solaris","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":38656260339,"f":50331777},"n":"IsReceiveOnly","d":1554675,"h":34361293043,"f":2097281},{"p":655361,"g":{"r":0,"d":0,"h":47246194931,"f":50331681},"n":"LoopbackInterfaceIndex","d":1554675,"h":42951227635,"f":2097185,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"illumos","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"solaris","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":55836129523,"f":50331777},"n":"Name","d":1554675,"h":51541162227,"f":2097281},{"p":1685747,"g":{"r":0,"d":0,"h":64426064115,"f":50331777},"n":"NetworkInterfaceType","d":1554675,"h":60131096819,"f":2097281},{"p":1751283,"g":{"r":0,"d":0,"h":73015998707,"f":50331777},"n":"OperationalStatus","d":1554675,"h":68721031411,"f":2097281},{"p":917505,"g":{"r":0,"d":0,"h":81605933299,"f":50331777},"n":"Speed","d":1554675,"h":77310966003,"f":2097281},{"p":262145,"g":{"r":0,"d":0,"h":90195867891,"f":50331777},"n":"SupportsMulticast","d":1554675,"h":85900900595,"f":2097281}],"m":[{"r":$.$typeArray($.$snn.System.Net.NetworkInformation.NetworkInterface).$h,"n":"GetAllNetworkInterfaces","d":1554675,"h":94490835187,"f":16777249,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"illumos","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"solaris","t":1310721}]}]},{"r":702707,"n":"GetIPProperties","d":1554675,"h":98785802483,"f":16777345},{"r":768243,"n":"GetIPStatistics","d":1554675,"h":103080769779,"f":16777345,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"r":899315,"n":"GetIPv4Statistics","d":1554675,"h":107375737075,"f":16777345,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]}]},{"r":262145,"n":"GetIsNetworkAvailable","d":1554675,"h":111670704371,"f":16777249,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"illumos","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"solaris","t":1310721}]}]},{"r":1816819,"n":"GetPhysicalAddress","d":1554675,"h":115965671667,"f":16777345},{"r":262145,"p":[{"n":"networkInterfaceComponent","p":1620211}],"n":"Supports","d":1554675,"h":120260638963,"f":16777345}],"c":[{"n":".ctor","o":"$ctor$1","d":1554675,"h":4296521971,"f":16777220}],"h":1554675}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterface`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.TcpConnectionInformation", ($self) => class TcpConnectionInformation extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2078963;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3326709,"g":{"r":0,"d":0,"h":12886980851,"f":50331905},"n":"LocalEndPoint","d":2078963,"h":8592013555,"f":2097409},{"p":3326709,"g":{"r":0,"d":0,"h":21476915443,"f":50331905},"n":"RemoteEndPoint","d":2078963,"h":17181948147,"f":2097409},{"p":2144499,"g":{"r":0,"d":0,"h":30066850035,"f":50331905},"n":"State","d":2078963,"h":25771882739,"f":2097409}],"c":[{"n":".ctor","o":"$ctor$1","d":2078963,"h":4297046259,"f":16777220}],"h":2078963}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpConnectionInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.TcpStatistics", ($self) => class TcpStatistics extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2210035;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887111923,"f":50331905},"n":"ConnectionsAccepted","d":2210035,"h":8592144627,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":21477046515,"f":50331905},"n":"ConnectionsInitiated","d":2210035,"h":17182079219,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":30066981107,"f":50331905},"n":"CumulativeConnections","d":2210035,"h":25772013811,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":38656915699,"f":50331905},"n":"CurrentConnections","d":2210035,"h":34361948403,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":47246850291,"f":50331905},"n":"ErrorsReceived","d":2210035,"h":42951882995,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":55836784883,"f":50331905},"n":"FailedConnectionAttempts","d":2210035,"h":51541817587,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":64426719475,"f":50331905},"n":"MaximumConnections","d":2210035,"h":60131752179,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":73016654067,"f":50331905},"n":"MaximumTransmissionTimeout","d":2210035,"h":68721686771,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":81606588659,"f":50331905},"n":"MinimumTransmissionTimeout","d":2210035,"h":77311621363,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":90196523251,"f":50331905},"n":"ResetConnections","d":2210035,"h":85901555955,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":98786457843,"f":50331905},"n":"ResetsSent","d":2210035,"h":94491490547,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":107376392435,"f":50331905},"n":"SegmentsReceived","d":2210035,"h":103081425139,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":115966327027,"f":50331905},"n":"SegmentsResent","d":2210035,"h":111671359731,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":124556261619,"f":50331905},"n":"SegmentsSent","d":2210035,"h":120261294323,"f":2097409}],"c":[{"n":".ctor","o":"$ctor$1","d":2210035,"h":4297177331,"f":16777220}],"h":2210035}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UdpStatistics", ($self) => class UdpStatistics extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2275571;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887177459,"f":50331905},"n":"DatagramsReceived","d":2275571,"h":8592210163,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":21477112051,"f":50331905},"n":"DatagramsSent","d":2275571,"h":17182144755,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":30067046643,"f":50331905},"n":"IncomingDatagramsDiscarded","d":2275571,"h":25772079347,"f":2097409},{"p":917505,"g":{"r":0,"d":0,"h":38656981235,"f":50331905},"n":"IncomingDatagramsWithErrors","d":2275571,"h":34362013939,"f":2097409},{"p":655361,"g":{"r":0,"d":0,"h":47246915827,"f":50331905},"n":"UdpListeners","d":2275571,"h":42951948531,"f":2097409}],"c":[{"n":".ctor","o":"$ctor$1","d":2275571,"h":4297242867,"f":16777220}],"h":2275571}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.UdpStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.MulticastIPAddressInformation", ($self) => class MulticastIPAddressInformation extends $.$snn.System.Net.NetworkInformation.IPAddressInformation
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 1030387;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":440563,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885932275,"f":50331905},"n":"AddressPreferredLifetime","d":1030387,"h":8590964979,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":21475866867,"f":50331905},"n":"AddressValidLifetime","d":1030387,"h":17180899571,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":30065801459,"f":50331905},"n":"DhcpLeaseLifetime","d":1030387,"h":25770834163,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":112883,"g":{"r":0,"d":0,"h":38655736051,"f":50331905},"n":"DuplicateAddressDetectionState","d":1030387,"h":34360768755,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":1882355,"g":{"r":0,"d":0,"h":47245670643,"f":50331905},"n":"PrefixOrigin","d":1030387,"h":42950703347,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":2013427,"g":{"r":0,"d":0,"h":55835605235,"f":50331905},"n":"SuffixOrigin","d":1030387,"h":51540637939,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":1030387,"h":4295997683,"f":16777220}],"h":1030387}; }
            static get $b() { return $.$snn.System.Net.NetworkInformation.IPAddressInformation; }
            static get $fullName() { return `System.Net.NetworkInformation.MulticastIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UnicastIPAddressInformation", ($self) => class UnicastIPAddressInformation extends $.$snn.System.Net.NetworkInformation.IPAddressInformation
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get PrefixLength()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2341107;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":440563,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887242995,"f":50331905},"n":"AddressPreferredLifetime","d":2341107,"h":8592275699,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":21477177587,"f":50331905},"n":"AddressValidLifetime","d":2341107,"h":17182210291,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":30067112179,"f":50331905},"n":"DhcpLeaseLifetime","d":2341107,"h":25772144883,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":112883,"g":{"r":0,"d":0,"h":38657046771,"f":50331905},"n":"DuplicateAddressDetectionState","d":2341107,"h":34362079475,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":3064565,"g":{"r":0,"d":0,"h":47246981363,"f":50331905},"n":"IPv4Mask","d":2341107,"h":42952014067,"f":2097409},{"p":655361,"g":{"r":0,"d":0,"h":55836915955,"f":50331777},"n":"PrefixLength","d":2341107,"h":51541948659,"f":2097281},{"p":1882355,"g":{"r":0,"d":0,"h":64426850547,"f":50331905},"n":"PrefixOrigin","d":2341107,"h":60131883251,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":2013427,"g":{"r":0,"d":0,"h":73016785139,"f":50331905},"n":"SuffixOrigin","d":2341107,"h":68721817843,"f":2097409,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":2341107,"h":4297308403,"f":16777220}],"h":2341107}; }
            static get $b() { return $.$snn.System.Net.NetworkInformation.IPAddressInformation; }
            static get $fullName() { return `System.Net.NetworkInformation.UnicastIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkChange", ($self) => class NetworkChange extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.NetworkInformation.NetworkAddressChangedEventHandler?*/static  add_NetworkAddressChanged(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAddressChangedEventHandler?*/static  remove_NetworkAddressChanged(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler?*/static  add_NetworkAvailabilityChanged(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler?*/static  remove_NetworkAvailabilityChanged(value)
            {
            }
            static /*void */ RegisterNetworkChange(/*System.Net.NetworkInformation.NetworkChange*/ nc)
            {
            }
            static $h = 1423603;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"nc","p":1423603}],"n":"RegisterNetworkChange","d":1423603,"h":34361161971,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]},{"t":70909953,"c":12955811841,"a":[{"v":"This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.","t":1310721},{"v":true,"t":262145}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":1423603,"h":4296390899,"f":16777217,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]},{"t":70909953,"c":12955811841,"a":[{"v":"This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.","t":1310721},{"v":true,"t":262145}]}]}],"e":[{"e":1226995,"m":{"r":65537,"p":[{"n":"value","p":1226995}],"n":"add_NetworkAddressChanged","d":1423603,"h":12886325491,"f":150994977},"r":{"r":65537,"p":[{"n":"value","p":1226995}],"n":"remove_NetworkAddressChanged","d":1423603,"h":17181292787,"f":285212705},"n":"NetworkAddressChanged","d":1423603,"h":8591358195,"f":8388641,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"illumos","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"solaris","t":1310721}]}]},{"e":1292531,"m":{"r":65537,"p":[{"n":"value","p":1292531}],"n":"add_NetworkAvailabilityChanged","d":1423603,"h":25771227379,"f":150994977},"r":{"r":65537,"p":[{"n":"value","p":1292531}],"n":"remove_NetworkAvailabilityChanged","d":1423603,"h":30066194675,"f":285212705},"n":"NetworkAvailabilityChanged","d":1423603,"h":21476260083,"f":8388641,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"illumos","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"solaris","t":1310721}]}]}],"h":1423603}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkChange`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.PhysicalAddress", ($self) => class PhysicalAddress extends $.$$.System.Object
        {
            /*System.Net.NetworkInformation.PhysicalAddress*/ static None = null;
            $ctor$1(/*byte[]*/ address)
            {
                super.$ctor();
                {
                }
                return this;
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ comparand)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.Equals$1.apply(this, arguments); }
            /*byte[] */ GetAddressBytes()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.GetHashCode.apply(this, arguments); }
            static /*System.Net.NetworkInformation.PhysicalAddress */ Parse(/*System.ReadOnlySpan<char>*/ address)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.PhysicalAddress */ Parse$1(/*string?*/ address)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.ToString.apply(this, arguments); }
            static /*bool */ TryParse(/*System.ReadOnlySpan<char>*/ address, /*out System.Net.NetworkInformation.PhysicalAddress?*/ value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ TryParse$1(/*string?*/ address, /*out System.Net.NetworkInformation.PhysicalAddress?*/ value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1816819;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","o":"@$1","d":1816819,"h":12886718707,"f":16809985},{"r":$.$typeArray($.$$.System.Byte).$h,"n":"GetAddressBytes","d":1816819,"h":17181686003,"f":16777217},{"r":655361,"n":"GetHashCode","d":1816819,"h":21476653299,"f":16809985},{"r":1816819,"p":[{"n":"address","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"Parse","d":1816819,"h":25771620595,"f":16777249},{"r":1816819,"p":[{"n":"address","p":1310721}],"n":"Parse","o":"@$1","d":1816819,"h":30066587891,"f":16777249},{"r":1310721,"n":"ToString","d":1816819,"h":34361555187,"f":16809985},{"r":262145,"p":[{"n":"address","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"value","p":1816819,"f":2}],"n":"TryParse","d":1816819,"h":38656522483,"f":16777249},{"r":262145,"p":[{"n":"address","p":1310721},{"n":"value","p":1816819,"f":2}],"n":"TryParse","o":"@$1","d":1816819,"h":42951489779,"f":16777249}],"l":[{"t":1816819,"n":"None","d":1816819,"h":4296784115,"f":4194337}],"c":[{"p":[{"n":"address","p":$.$typeArray($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$1","d":1816819,"h":8591751411,"f":16777217}],"h":1816819}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.PhysicalAddress`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.GatewayIPAddressInformationCollection", ($self) => class GatewayIPAddressInformationCollection extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.GatewayIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.GatewayIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.GatewayIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Add(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Contains(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.CopyTo(System.Net.NetworkInformation.GatewayIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Remove(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.GatewayIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 243955;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885145843,"f":50331777},"n":"Count","d":243955,"h":8590178547,"f":2097281},{"p":262145,"g":{"r":0,"d":0,"h":21475080435,"f":50331777},"n":"IsReadOnly","d":243955,"h":17180113139,"f":2097281},{"p":178419,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065015027,"f":50331777},"n":"Item","o":"@$2","d":243955,"h":25770047731,"f":2097281}],"m":[{"r":65537,"p":[{"n":"address","p":178419}],"n":"Add","d":243955,"h":34359982323,"f":16777345},{"r":65537,"n":"Clear","d":243955,"h":38654949619,"f":16777345},{"r":262145,"p":[{"n":"address","p":178419}],"n":"Contains","d":243955,"h":42949916915,"f":16777345},{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h},{"n":"offset","p":655361}],"n":"CopyTo","d":243955,"h":47244884211,"f":16777345},{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,"n":"GetEnumerator","d":243955,"h":51539851507,"f":16777345},{"r":262145,"p":[{"n":"address","p":178419}],"n":"Remove","d":243955,"h":55834818803,"f":16777345}],"c":[{"n":".ctor","o":"$ctor$1","d":243955,"h":4295211251,"f":16777232}],"i":[$.$$.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,31719425],"h":243955}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation), $.$$.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.GatewayIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPAddressInformationCollection", ($self) => class IPAddressInformationCollection extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.IPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.IPAddressInformation> */ GetEnumerator()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Add(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Contains(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.CopyTo(System.Net.NetworkInformation.IPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Remove(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.IPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 506099;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885407987,"f":50331777},"n":"Count","d":506099,"h":8590440691,"f":2097281},{"p":262145,"g":{"r":0,"d":0,"h":21475342579,"f":50331777},"n":"IsReadOnly","d":506099,"h":17180375283,"f":2097281},{"p":440563,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065277171,"f":50331777},"n":"Item","o":"@$2","d":506099,"h":25770309875,"f":2097281}],"m":[{"r":65537,"p":[{"n":"address","p":440563}],"n":"Add","d":506099,"h":34360244467,"f":16777345},{"r":65537,"n":"Clear","d":506099,"h":38655211763,"f":16777345},{"r":262145,"p":[{"n":"address","p":440563}],"n":"Contains","d":506099,"h":42950179059,"f":16777345},{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h},{"n":"offset","p":655361}],"n":"CopyTo","d":506099,"h":47245146355,"f":16777345},{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,"n":"GetEnumerator","d":506099,"h":51540113651,"f":16777345},{"r":262145,"p":[{"n":"address","p":440563}],"n":"Remove","d":506099,"h":55835080947,"f":16777345}],"c":[{"n":".ctor","o":"$ctor$1","d":506099,"h":4295473395,"f":16777224}],"i":[$.$$.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,31719425],"h":506099}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.IPAddressInformation), $.$$.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.IPAddressInformation), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.MulticastIPAddressInformationCollection", ($self) => class MulticastIPAddressInformationCollection extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.MulticastIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.MulticastIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.MulticastIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Add(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Contains(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.CopyTo(System.Net.NetworkInformation.MulticastIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Remove(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.MulticastIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 1095923;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885997811,"f":50331777},"n":"Count","d":1095923,"h":8591030515,"f":2097281},{"p":262145,"g":{"r":0,"d":0,"h":21475932403,"f":50331777},"n":"IsReadOnly","d":1095923,"h":17180965107,"f":2097281},{"p":1030387,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065866995,"f":50331777},"n":"Item","o":"@$2","d":1095923,"h":25770899699,"f":2097281}],"m":[{"r":65537,"p":[{"n":"address","p":1030387}],"n":"Add","d":1095923,"h":34360834291,"f":16777345},{"r":65537,"n":"Clear","d":1095923,"h":38655801587,"f":16777345},{"r":262145,"p":[{"n":"address","p":1030387}],"n":"Contains","d":1095923,"h":42950768883,"f":16777345},{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h},{"n":"offset","p":655361}],"n":"CopyTo","d":1095923,"h":47245736179,"f":16777345},{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,"n":"GetEnumerator","d":1095923,"h":51540703475,"f":16777345},{"r":262145,"p":[{"n":"address","p":1030387}],"n":"Remove","d":1095923,"h":55835670771,"f":16777345}],"c":[{"n":".ctor","o":"$ctor$1","d":1095923,"h":4296063219,"f":16777232}],"i":[$.$$.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,31719425],"h":1095923}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation), $.$$.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.MulticastIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UnicastIPAddressInformationCollection", ($self) => class UnicastIPAddressInformationCollection extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.UnicastIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.UnicastIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Add(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Contains(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.CopyTo(System.Net.NetworkInformation.UnicastIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Remove(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.UnicastIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 2406643;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12887308531,"f":50331777},"n":"Count","d":2406643,"h":8592341235,"f":2097281},{"p":262145,"g":{"r":0,"d":0,"h":21477243123,"f":50331777},"n":"IsReadOnly","d":2406643,"h":17182275827,"f":2097281},{"p":2341107,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30067177715,"f":50331777},"n":"Item","o":"@$2","d":2406643,"h":25772210419,"f":2097281}],"m":[{"r":65537,"p":[{"n":"address","p":2341107}],"n":"Add","d":2406643,"h":34362145011,"f":16777345},{"r":65537,"n":"Clear","d":2406643,"h":38657112307,"f":16777345},{"r":262145,"p":[{"n":"address","p":2341107}],"n":"Contains","d":2406643,"h":42952079603,"f":16777345},{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h},{"n":"offset","p":655361}],"n":"CopyTo","d":2406643,"h":47247046899,"f":16777345},{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,"n":"GetEnumerator","d":2406643,"h":51542014195,"f":16777345},{"r":262145,"p":[{"n":"address","p":2341107}],"n":"Remove","d":2406643,"h":55836981491,"f":16777345}],"c":[{"n":".ctor","o":"$ctor$1","d":2406643,"h":4297373939,"f":16777232}],"i":[$.$$.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,31719425],"h":2406643}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation), $.$$.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.UnicastIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAddressChangedEventHandler", ($self) => class NetworkAddressChangedEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Nullable$$*/ sender, /*$.$$.System.EventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 1226995;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":46989313}],"n":"Invoke","d":1226995,"h":8591161587,"f":16777345},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":46989313},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":1226995,"h":12886128883,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":1226995,"h":17181096179,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1226995,"h":4296194291,"f":16777217}],"i":[57212929,113246209],"h":1226995}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAddressChangedEventHandler`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler", ($self) => class NetworkAvailabilityChangedEventHandler extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.System.Nullable$$*/ sender, /*$.$snn.System.Net.NetworkInformation.NetworkAvailabilityEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 1292531;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":1358067}],"n":"Invoke","d":1292531,"h":8591227123,"f":16777345},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":1358067},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":1292531,"h":12886194419,"f":16777345},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":1292531,"h":17181161715,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1292531,"h":4296259827,"f":16777217}],"i":[57212929,113246209],"h":1292531}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.DuplicateAddressDetectionState", ($self) => class DuplicateAddressDetectionState extends $.$$.System.Enum
        {
            static Invalid = 0;
            static Tentative = 1;
            static Duplicate = 2;
            static Deprecated = 3;
            static Preferred = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Invalid": 0n,
                    "Tentative": 1n,
                    "Duplicate": 2n,
                    "Deprecated": 3n,
                    "Preferred": 4n
                };
            }
            static $h = 112883;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":112883,"n":"Invalid","d":112883,"h":4295080179,"f":4194337},{"t":112883,"n":"Tentative","d":112883,"h":8590047475,"f":4194337},{"t":112883,"n":"Duplicate","d":112883,"h":12885014771,"f":4194337},{"t":112883,"n":"Deprecated","d":112883,"h":17179982067,"f":4194337},{"t":112883,"n":"Preferred","d":112883,"h":21474949363,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":112883,"h":25769916659,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":112883}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.DuplicateAddressDetectionState`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetBiosNodeType", ($self) => class NetBiosNodeType extends $.$$.System.Enum
        {
            static Unknown = 0;
            static Broadcast = 1;
            static Peer2Peer = 2;
            static Mixed = 4;
            static Hybrid = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Broadcast": 1n,
                    "Peer2Peer": 2n,
                    "Mixed": 4n,
                    "Hybrid": 8n
                };
            }
            static $h = 1161459;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1161459,"n":"Unknown","d":1161459,"h":4296128755,"f":4194337},{"t":1161459,"n":"Broadcast","d":1161459,"h":8591096051,"f":4194337},{"t":1161459,"n":"Peer2Peer","d":1161459,"h":12886063347,"f":4194337},{"t":1161459,"n":"Mixed","d":1161459,"h":17181030643,"f":4194337},{"t":1161459,"n":"Hybrid","d":1161459,"h":21475997939,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1161459,"h":25770965235,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1161459}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetBiosNodeType`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetworkInterfaceComponent", ($self) => class NetworkInterfaceComponent extends $.$$.System.Enum
        {
            static IPv4 = 0;
            static IPv6 = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "IPv4": 0n,
                    "IPv6": 1n
                };
            }
            static $h = 1620211;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1620211,"n":"IPv4","d":1620211,"h":4296587507,"f":4194337},{"t":1620211,"n":"IPv6","d":1620211,"h":8591554803,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1620211,"h":12886522099,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1620211}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterfaceComponent`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetworkInterfaceType", ($self) => class NetworkInterfaceType extends $.$$.System.Enum
        {
            static Unknown = 1;
            static Ethernet = 6;
            static TokenRing = 9;
            static Fddi = 15;
            static BasicIsdn = 20;
            static PrimaryIsdn = 21;
            static Ppp = 23;
            static Loopback = 24;
            static Ethernet3Megabit = 26;
            static Slip = 28;
            static Atm = 37;
            static GenericModem = 48;
            static FastEthernetT = 62;
            static Isdn = 63;
            static FastEthernetFx = 69;
            static Wireless80211 = 71;
            static AsymmetricDsl = 94;
            static RateAdaptDsl = 95;
            static SymmetricDsl = 96;
            static VeryHighSpeedDsl = 97;
            static IPOverAtm = 114;
            static GigabitEthernet = 117;
            static Tunnel = 131;
            static MultiRateSymmetricDsl = 143;
            static HighPerformanceSerialBus = 144;
            static Wman = 237;
            static Wwanpp = 243;
            static Wwanpp2 = 244;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 1n,
                    "Ethernet": 6n,
                    "TokenRing": 9n,
                    "Fddi": 15n,
                    "BasicIsdn": 20n,
                    "PrimaryIsdn": 21n,
                    "Ppp": 23n,
                    "Loopback": 24n,
                    "Ethernet3Megabit": 26n,
                    "Slip": 28n,
                    "Atm": 37n,
                    "GenericModem": 48n,
                    "FastEthernetT": 62n,
                    "Isdn": 63n,
                    "FastEthernetFx": 69n,
                    "Wireless80211": 71n,
                    "AsymmetricDsl": 94n,
                    "RateAdaptDsl": 95n,
                    "SymmetricDsl": 96n,
                    "VeryHighSpeedDsl": 97n,
                    "IPOverAtm": 114n,
                    "GigabitEthernet": 117n,
                    "Tunnel": 131n,
                    "MultiRateSymmetricDsl": 143n,
                    "HighPerformanceSerialBus": 144n,
                    "Wman": 237n,
                    "Wwanpp": 243n,
                    "Wwanpp2": 244n
                };
            }
            static $h = 1685747;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1685747,"n":"Unknown","d":1685747,"h":4296653043,"f":4194337},{"t":1685747,"n":"Ethernet","d":1685747,"h":8591620339,"f":4194337},{"t":1685747,"n":"TokenRing","d":1685747,"h":12886587635,"f":4194337},{"t":1685747,"n":"Fddi","d":1685747,"h":17181554931,"f":4194337},{"t":1685747,"n":"BasicIsdn","d":1685747,"h":21476522227,"f":4194337},{"t":1685747,"n":"PrimaryIsdn","d":1685747,"h":25771489523,"f":4194337},{"t":1685747,"n":"Ppp","d":1685747,"h":30066456819,"f":4194337},{"t":1685747,"n":"Loopback","d":1685747,"h":34361424115,"f":4194337},{"t":1685747,"n":"Ethernet3Megabit","d":1685747,"h":38656391411,"f":4194337},{"t":1685747,"n":"Slip","d":1685747,"h":42951358707,"f":4194337},{"t":1685747,"n":"Atm","d":1685747,"h":47246326003,"f":4194337},{"t":1685747,"n":"GenericModem","d":1685747,"h":51541293299,"f":4194337},{"t":1685747,"n":"FastEthernetT","d":1685747,"h":55836260595,"f":4194337},{"t":1685747,"n":"Isdn","d":1685747,"h":60131227891,"f":4194337},{"t":1685747,"n":"FastEthernetFx","d":1685747,"h":64426195187,"f":4194337},{"t":1685747,"n":"Wireless80211","d":1685747,"h":68721162483,"f":4194337},{"t":1685747,"n":"AsymmetricDsl","d":1685747,"h":73016129779,"f":4194337},{"t":1685747,"n":"RateAdaptDsl","d":1685747,"h":77311097075,"f":4194337},{"t":1685747,"n":"SymmetricDsl","d":1685747,"h":81606064371,"f":4194337},{"t":1685747,"n":"VeryHighSpeedDsl","d":1685747,"h":85901031667,"f":4194337},{"t":1685747,"n":"IPOverAtm","d":1685747,"h":90195998963,"f":4194337},{"t":1685747,"n":"GigabitEthernet","d":1685747,"h":94490966259,"f":4194337},{"t":1685747,"n":"Tunnel","d":1685747,"h":98785933555,"f":4194337},{"t":1685747,"n":"MultiRateSymmetricDsl","d":1685747,"h":103080900851,"f":4194337},{"t":1685747,"n":"HighPerformanceSerialBus","d":1685747,"h":107375868147,"f":4194337},{"t":1685747,"n":"Wman","d":1685747,"h":111670835443,"f":4194337},{"t":1685747,"n":"Wwanpp","d":1685747,"h":115965802739,"f":4194337},{"t":1685747,"n":"Wwanpp2","d":1685747,"h":120260770035,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1685747,"h":124555737331,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1685747}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterfaceType`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.OperationalStatus", ($self) => class OperationalStatus extends $.$$.System.Enum
        {
            static Up = 1;
            static Down = 2;
            static Testing = 3;
            static Unknown = 4;
            static Dormant = 5;
            static NotPresent = 6;
            static LowerLayerDown = 7;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Up": 1n,
                    "Down": 2n,
                    "Testing": 3n,
                    "Unknown": 4n,
                    "Dormant": 5n,
                    "NotPresent": 6n,
                    "LowerLayerDown": 7n
                };
            }
            static $h = 1751283;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1751283,"n":"Up","d":1751283,"h":4296718579,"f":4194337},{"t":1751283,"n":"Down","d":1751283,"h":8591685875,"f":4194337},{"t":1751283,"n":"Testing","d":1751283,"h":12886653171,"f":4194337},{"t":1751283,"n":"Unknown","d":1751283,"h":17181620467,"f":4194337},{"t":1751283,"n":"Dormant","d":1751283,"h":21476587763,"f":4194337},{"t":1751283,"n":"NotPresent","d":1751283,"h":25771555059,"f":4194337},{"t":1751283,"n":"LowerLayerDown","d":1751283,"h":30066522355,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1751283,"h":34361489651,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1751283}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.OperationalStatus`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.PrefixOrigin", ($self) => class PrefixOrigin extends $.$$.System.Enum
        {
            static Other = 0;
            static Manual = 1;
            static WellKnown = 2;
            static Dhcp = 3;
            static RouterAdvertisement = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Other": 0n,
                    "Manual": 1n,
                    "WellKnown": 2n,
                    "Dhcp": 3n,
                    "RouterAdvertisement": 4n
                };
            }
            static $h = 1882355;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1882355,"n":"Other","d":1882355,"h":4296849651,"f":4194337},{"t":1882355,"n":"Manual","d":1882355,"h":8591816947,"f":4194337},{"t":1882355,"n":"WellKnown","d":1882355,"h":12886784243,"f":4194337},{"t":1882355,"n":"Dhcp","d":1882355,"h":17181751539,"f":4194337},{"t":1882355,"n":"RouterAdvertisement","d":1882355,"h":21476718835,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1882355,"h":25771686131,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1882355}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.PrefixOrigin`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.ScopeLevel", ($self) => class ScopeLevel extends $.$$.System.Enum
        {
            static None = 0;
            static Interface = 1;
            static Link = 2;
            static Subnet = 3;
            static Admin = 4;
            static Site = 5;
            static Organization = 8;
            static Global = 14;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Interface": 1n,
                    "Link": 2n,
                    "Subnet": 3n,
                    "Admin": 4n,
                    "Site": 5n,
                    "Organization": 8n,
                    "Global": 14n
                };
            }
            static $h = 1947891;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1947891,"n":"None","d":1947891,"h":4296915187,"f":4194337},{"t":1947891,"n":"Interface","d":1947891,"h":8591882483,"f":4194337},{"t":1947891,"n":"Link","d":1947891,"h":12886849779,"f":4194337},{"t":1947891,"n":"Subnet","d":1947891,"h":17181817075,"f":4194337},{"t":1947891,"n":"Admin","d":1947891,"h":21476784371,"f":4194337},{"t":1947891,"n":"Site","d":1947891,"h":25771751667,"f":4194337},{"t":1947891,"n":"Organization","d":1947891,"h":30066718963,"f":4194337},{"t":1947891,"n":"Global","d":1947891,"h":34361686259,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1947891,"h":38656653555,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1947891}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.ScopeLevel`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.SuffixOrigin", ($self) => class SuffixOrigin extends $.$$.System.Enum
        {
            static Other = 0;
            static Manual = 1;
            static WellKnown = 2;
            static OriginDhcp = 3;
            static LinkLayerAddress = 4;
            static Random = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Other": 0n,
                    "Manual": 1n,
                    "WellKnown": 2n,
                    "OriginDhcp": 3n,
                    "LinkLayerAddress": 4n,
                    "Random": 5n
                };
            }
            static $h = 2013427;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2013427,"n":"Other","d":2013427,"h":4296980723,"f":4194337},{"t":2013427,"n":"Manual","d":2013427,"h":8591948019,"f":4194337},{"t":2013427,"n":"WellKnown","d":2013427,"h":12886915315,"f":4194337},{"t":2013427,"n":"OriginDhcp","d":2013427,"h":17181882611,"f":4194337},{"t":2013427,"n":"LinkLayerAddress","d":2013427,"h":21476849907,"f":4194337},{"t":2013427,"n":"Random","d":2013427,"h":25771817203,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2013427,"h":30066784499,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2013427}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.SuffixOrigin`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.TcpState", ($self) => class TcpState extends $.$$.System.Enum
        {
            static Unknown = 0;
            static Closed = 1;
            static Listen = 2;
            static SynSent = 3;
            static SynReceived = 4;
            static Established = 5;
            static FinWait1 = 6;
            static FinWait2 = 7;
            static CloseWait = 8;
            static Closing = 9;
            static LastAck = 10;
            static TimeWait = 11;
            static DeleteTcb = 12;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Closed": 1n,
                    "Listen": 2n,
                    "SynSent": 3n,
                    "SynReceived": 4n,
                    "Established": 5n,
                    "FinWait1": 6n,
                    "FinWait2": 7n,
                    "CloseWait": 8n,
                    "Closing": 9n,
                    "LastAck": 10n,
                    "TimeWait": 11n,
                    "DeleteTcb": 12n
                };
            }
            static $h = 2144499;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2144499,"n":"Unknown","d":2144499,"h":4297111795,"f":4194337},{"t":2144499,"n":"Closed","d":2144499,"h":8592079091,"f":4194337},{"t":2144499,"n":"Listen","d":2144499,"h":12887046387,"f":4194337},{"t":2144499,"n":"SynSent","d":2144499,"h":17182013683,"f":4194337},{"t":2144499,"n":"SynReceived","d":2144499,"h":21476980979,"f":4194337},{"t":2144499,"n":"Established","d":2144499,"h":25771948275,"f":4194337},{"t":2144499,"n":"FinWait1","d":2144499,"h":30066915571,"f":4194337},{"t":2144499,"n":"FinWait2","d":2144499,"h":34361882867,"f":4194337},{"t":2144499,"n":"CloseWait","d":2144499,"h":38656850163,"f":4194337},{"t":2144499,"n":"Closing","d":2144499,"h":42951817459,"f":4194337},{"t":2144499,"n":"LastAck","d":2144499,"h":47246784755,"f":4194337},{"t":2144499,"n":"TimeWait","d":2144499,"h":51541752051,"f":4194337},{"t":2144499,"n":"DeleteTcb","d":2144499,"h":55836719347,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2144499,"h":60131686643,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2144499}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpState`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAvailabilityEventArgs", ($self) => class NetworkAvailabilityEventArgs extends $.$$.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ get IsAvailable()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1358067;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886259955,"f":50331649},"n":"IsAvailable","d":1358067,"h":8591292659,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":1358067,"h":4296325363,"f":16777224}],"h":1358067}; }
            static get $b() { return $.$$.System.EventArgs; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAvailabilityEventArgs`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkInformationException", ($self) => class NetworkInformationException extends $.$$.System.ComponentModel.Win32Exception
        {
            $ctor$20()
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            $ctor$21(/*int*/ errorCode)
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            $ctor$22(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            /*int */ get ErrorCode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1489139;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":33423361,"h":1489139}; }
            static get $b() { return $.$$.System.ComponentModel.Win32Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInformationException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets"))