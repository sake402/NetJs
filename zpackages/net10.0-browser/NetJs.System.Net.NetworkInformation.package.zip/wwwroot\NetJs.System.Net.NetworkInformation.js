
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $ssc, $sris, $scsl, $sl, $snp, $sspw, $sdd, $snnr, $sns) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.NetworkInformation", 
    {"h":64171,"f":"System.Net.NetworkInformation","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.NetworkInformation","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.NetworkInformation","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snn.System.Net.NetworkInformation.GatewayIPAddressInformation", ($self) => class GatewayIPAddressInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 195243;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3076570,"g":{"r":0,"d":0,"h":12885097131,"f":257},"n":"Address","d":195243,"h":8590129835,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":195243,"h":4295162539,"f":4}],"h":195243}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.GatewayIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IcmpV4Statistics", ($self) => class IcmpV4Statistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 326315;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885228203,"f":257},"n":"AddressMaskRepliesReceived","d":326315,"h":8590260907,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475162795,"f":257},"n":"AddressMaskRepliesSent","d":326315,"h":17180195499,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065097387,"f":257},"n":"AddressMaskRequestsReceived","d":326315,"h":25770130091,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655031979,"f":257},"n":"AddressMaskRequestsSent","d":326315,"h":34360064683,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47244966571,"f":257},"n":"DestinationUnreachableMessagesReceived","d":326315,"h":42949999275,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55834901163,"f":257},"n":"DestinationUnreachableMessagesSent","d":326315,"h":51539933867,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64424835755,"f":257},"n":"EchoRepliesReceived","d":326315,"h":60129868459,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73014770347,"f":257},"n":"EchoRepliesSent","d":326315,"h":68719803051,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":81604704939,"f":257},"n":"EchoRequestsReceived","d":326315,"h":77309737643,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90194639531,"f":257},"n":"EchoRequestsSent","d":326315,"h":85899672235,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98784574123,"f":257},"n":"ErrorsReceived","d":326315,"h":94489606827,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":107374508715,"f":257},"n":"ErrorsSent","d":326315,"h":103079541419,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":115964443307,"f":257},"n":"MessagesReceived","d":326315,"h":111669476011,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":124554377899,"f":257},"n":"MessagesSent","d":326315,"h":120259410603,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":133144312491,"f":257},"n":"ParameterProblemsReceived","d":326315,"h":128849345195,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":141734247083,"f":257},"n":"ParameterProblemsSent","d":326315,"h":137439279787,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":150324181675,"f":257},"n":"RedirectsReceived","d":326315,"h":146029214379,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":158914116267,"f":257},"n":"RedirectsSent","d":326315,"h":154619148971,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":167504050859,"f":257},"n":"SourceQuenchesReceived","d":326315,"h":163209083563,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":176093985451,"f":257},"n":"SourceQuenchesSent","d":326315,"h":171799018155,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":184683920043,"f":257},"n":"TimeExceededMessagesReceived","d":326315,"h":180388952747,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":193273854635,"f":257},"n":"TimeExceededMessagesSent","d":326315,"h":188978887339,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":201863789227,"f":257},"n":"TimestampRepliesReceived","d":326315,"h":197568821931,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":210453723819,"f":257},"n":"TimestampRepliesSent","d":326315,"h":206158756523,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":219043658411,"f":257},"n":"TimestampRequestsReceived","d":326315,"h":214748691115,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":227633593003,"f":257},"n":"TimestampRequestsSent","d":326315,"h":223338625707,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":326315,"h":4295293611,"f":4}],"h":326315}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IcmpV4Statistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IcmpV6Statistics", ($self) => class IcmpV6Statistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 391851;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885293739,"f":257},"n":"DestinationUnreachableMessagesReceived","d":391851,"h":8590326443,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475228331,"f":257},"n":"DestinationUnreachableMessagesSent","d":391851,"h":17180261035,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065162923,"f":257},"n":"EchoRepliesReceived","d":391851,"h":25770195627,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655097515,"f":257},"n":"EchoRepliesSent","d":391851,"h":34360130219,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245032107,"f":257},"n":"EchoRequestsReceived","d":391851,"h":42950064811,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55834966699,"f":257},"n":"EchoRequestsSent","d":391851,"h":51539999403,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64424901291,"f":257},"n":"ErrorsReceived","d":391851,"h":60129933995,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73014835883,"f":257},"n":"ErrorsSent","d":391851,"h":68719868587,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81604770475,"f":257},"n":"MembershipQueriesReceived","d":391851,"h":77309803179,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90194705067,"f":257},"n":"MembershipQueriesSent","d":391851,"h":85899737771,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98784639659,"f":257},"n":"MembershipReductionsReceived","d":391851,"h":94489672363,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107374574251,"f":257},"n":"MembershipReductionsSent","d":391851,"h":103079606955,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":115964508843,"f":257},"n":"MembershipReportsReceived","d":391851,"h":111669541547,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":124554443435,"f":257},"n":"MembershipReportsSent","d":391851,"h":120259476139,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":133144378027,"f":257},"n":"MessagesReceived","d":391851,"h":128849410731,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":141734312619,"f":257},"n":"MessagesSent","d":391851,"h":137439345323,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":150324247211,"f":257},"n":"NeighborAdvertisementsReceived","d":391851,"h":146029279915,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":158914181803,"f":257},"n":"NeighborAdvertisementsSent","d":391851,"h":154619214507,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":167504116395,"f":257},"n":"NeighborSolicitsReceived","d":391851,"h":163209149099,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":176094050987,"f":257},"n":"NeighborSolicitsSent","d":391851,"h":171799083691,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":184683985579,"f":257},"n":"PacketTooBigMessagesReceived","d":391851,"h":180389018283,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":193273920171,"f":257},"n":"PacketTooBigMessagesSent","d":391851,"h":188978952875,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":201863854763,"f":257},"n":"ParameterProblemsReceived","d":391851,"h":197568887467,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":210453789355,"f":257},"n":"ParameterProblemsSent","d":391851,"h":206158822059,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":219043723947,"f":257},"n":"RedirectsReceived","d":391851,"h":214748756651,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":227633658539,"f":257},"n":"RedirectsSent","d":391851,"h":223338691243,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":236223593131,"f":257},"n":"RouterAdvertisementsReceived","d":391851,"h":231928625835,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":244813527723,"f":257},"n":"RouterAdvertisementsSent","d":391851,"h":240518560427,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":253403462315,"f":257},"n":"RouterSolicitsReceived","d":391851,"h":249108495019,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":261993396907,"f":257},"n":"RouterSolicitsSent","d":391851,"h":257698429611,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":270583331499,"f":257},"n":"TimeExceededMessagesReceived","d":391851,"h":266288364203,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":279173266091,"f":257},"n":"TimeExceededMessagesSent","d":391851,"h":274878298795,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":391851,"h":4295359147,"f":4}],"h":391851}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IcmpV6Statistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPAddressInformation", ($self) => class IPAddressInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 457387;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3076570,"g":{"r":0,"d":0,"h":12885359275,"f":257},"n":"Address","d":457387,"h":8590391979,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":21475293867,"f":257},"n":"IsDnsEligible","d":457387,"h":17180326571,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":30065228459,"f":257},"n":"IsTransient","d":457387,"h":25770261163,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":457387,"h":4295424683,"f":4}],"h":457387}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPGlobalProperties", ($self) => class IPGlobalProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.IAsyncResult */ BeginGetUnicastAddresses(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformationCollection */ EndGetUnicastAddresses(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.IPGlobalProperties */ GetIPGlobalProperties()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformationCollection */ GetUnicastAddresses()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.NetworkInformation.UnicastIPAddressInformationCollection> */ GetUnicastAddressesAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 588459;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885490347,"f":257},"n":"DhcpScopeName","d":588459,"h":8590523051,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":21475424939,"f":257},"n":"DomainName","d":588459,"h":17180457643,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":30065359531,"f":257},"n":"HostName","d":588459,"h":25770392235,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":38655294123,"f":257},"n":"IsWinsProxy","d":588459,"h":34360326827,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1178283,"g":{"r":0,"d":0,"h":47245228715,"f":257},"n":"NodeType","d":588459,"h":42950261419,"f":257}],"m":[{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginGetUnicastAddresses","d":588459,"h":51540196011,"f":129},{"r":2423467,"p":[{"n":"asyncResult","p":56950785}],"n":"EndGetUnicastAddresses","d":588459,"h":55835163307,"f":129},{"r":0,"n":"GetActiveTcpConnections","d":588459,"h":60130130603,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":0,"n":"GetActiveTcpListeners","d":588459,"h":64425097899,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":0,"n":"GetActiveUdpListeners","d":588459,"h":68720065195,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":326315,"n":"GetIcmpV4Statistics","d":588459,"h":73015032491,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":391851,"n":"GetIcmpV6Statistics","d":588459,"h":77309999787,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":588459,"n":"GetIPGlobalProperties","d":588459,"h":81604967083,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":653995,"n":"GetIPv4GlobalStatistics","d":588459,"h":85899934379,"f":257},{"r":653995,"n":"GetIPv6GlobalStatistics","d":588459,"h":90194901675,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"r":2226859,"n":"GetTcpIPv4Statistics","d":588459,"h":94489868971,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2226859,"n":"GetTcpIPv6Statistics","d":588459,"h":98784836267,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2292395,"n":"GetUdpIPv4Statistics","d":588459,"h":103079803563,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2292395,"n":"GetUdpIPv6Statistics","d":588459,"h":107374770859,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2423467,"n":"GetUnicastAddresses","d":588459,"h":111669738155,"f":129},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformationCollection).$h,"n":"GetUnicastAddressesAsync","d":588459,"h":115964705451,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":588459,"h":4295555755,"f":4}],"h":588459}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPGlobalProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPGlobalStatistics", ($self) => class IPGlobalStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 653995;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885555883,"f":257},"n":"DefaultTtl","d":653995,"h":8590588587,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":21475490475,"f":257},"n":"ForwardingEnabled","d":653995,"h":17180523179,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":30065425067,"f":257},"n":"NumberOfInterfaces","d":653995,"h":25770457771,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":38655359659,"f":257},"n":"NumberOfIPAddresses","d":653995,"h":34360392363,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":47245294251,"f":257},"n":"NumberOfRoutes","d":653995,"h":42950326955,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":55835228843,"f":257},"n":"OutputPacketRequests","d":653995,"h":51540261547,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":64425163435,"f":257},"n":"OutputPacketRoutingDiscards","d":653995,"h":60130196139,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73015098027,"f":257},"n":"OutputPacketsDiscarded","d":653995,"h":68720130731,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605032619,"f":257},"n":"OutputPacketsWithNoRoute","d":653995,"h":77310065323,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":90194967211,"f":257},"n":"PacketFragmentFailures","d":653995,"h":85899999915,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":98784901803,"f":257},"n":"PacketReassembliesRequired","d":653995,"h":94489934507,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":107374836395,"f":257},"n":"PacketReassemblyFailures","d":653995,"h":103079869099,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":115964770987,"f":257},"n":"PacketReassemblyTimeout","d":653995,"h":111669803691,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":124554705579,"f":257},"n":"PacketsFragmented","d":653995,"h":120259738283,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":133144640171,"f":257},"n":"PacketsReassembled","d":653995,"h":128849672875,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":141734574763,"f":257},"n":"ReceivedPackets","d":653995,"h":137439607467,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":150324509355,"f":257},"n":"ReceivedPacketsDelivered","d":653995,"h":146029542059,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":158914443947,"f":257},"n":"ReceivedPacketsDiscarded","d":653995,"h":154619476651,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":167504378539,"f":257},"n":"ReceivedPacketsForwarded","d":653995,"h":163209411243,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":176094313131,"f":257},"n":"ReceivedPacketsWithAddressErrors","d":653995,"h":171799345835,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":184684247723,"f":257},"n":"ReceivedPacketsWithHeadersErrors","d":653995,"h":180389280427,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":193274182315,"f":257},"n":"ReceivedPacketsWithUnknownProtocol","d":653995,"h":188979215019,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":653995,"h":4295621291,"f":4}],"h":653995}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPGlobalStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPInterfaceProperties", ($self) => class IPInterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 719531;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":522923,"g":{"r":0,"d":0,"h":12885621419,"f":257},"n":"AnycastAddresses","d":719531,"h":8590654123,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":4059610,"g":{"r":0,"d":0,"h":21475556011,"f":257},"n":"DhcpServerAddresses","d":719531,"h":17180588715,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":4059610,"g":{"r":0,"d":0,"h":30065490603,"f":257},"n":"DnsAddresses","d":719531,"h":25770523307,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":38655425195,"f":257},"n":"DnsSuffix","d":719531,"h":34360457899,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":260779,"g":{"r":0,"d":0,"h":47245359787,"f":257},"n":"GatewayAddresses","d":719531,"h":42950392491,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":55835294379,"f":257},"n":"IsDnsEnabled","d":719531,"h":51540327083,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":64425228971,"f":257},"n":"IsDynamicDnsEnabled","d":719531,"h":60130261675,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1112747,"g":{"r":0,"d":0,"h":73015163563,"f":257},"n":"MulticastAddresses","d":719531,"h":68720196267,"f":257},{"p":2423467,"g":{"r":0,"d":0,"h":81605098155,"f":257},"n":"UnicastAddresses","d":719531,"h":77310130859,"f":257},{"p":4059610,"g":{"r":0,"d":0,"h":90195032747,"f":257},"n":"WinsServersAddresses","d":719531,"h":85900065451,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]}],"m":[{"r":850603,"n":"GetIPv4Properties","d":719531,"h":94490000043,"f":257},{"r":981675,"n":"GetIPv6Properties","d":719531,"h":98784967339,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":719531,"h":4295686827,"f":4}],"h":719531}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPInterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPInterfaceStatistics", ($self) => class IPInterfaceStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 785067;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885686955,"f":257},"n":"BytesReceived","d":785067,"h":8590719659,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475621547,"f":257},"n":"BytesSent","d":785067,"h":17180654251,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065556139,"f":257},"n":"IncomingPacketsDiscarded","d":785067,"h":25770588843,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655490731,"f":257},"n":"IncomingPacketsWithErrors","d":785067,"h":34360523435,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245425323,"f":257},"n":"IncomingUnknownProtocolPackets","d":785067,"h":42950458027,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"linux","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":55835359915,"f":257},"n":"NonUnicastPacketsReceived","d":785067,"h":51540392619,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64425294507,"f":257},"n":"NonUnicastPacketsSent","d":785067,"h":60130327211,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"linux","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73015229099,"f":257},"n":"OutgoingPacketsDiscarded","d":785067,"h":68720261803,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605163691,"f":257},"n":"OutgoingPacketsWithErrors","d":785067,"h":77310196395,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90195098283,"f":257},"n":"OutputQueueLength","d":785067,"h":85900130987,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98785032875,"f":257},"n":"UnicastPacketsReceived","d":785067,"h":94490065579,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107374967467,"f":257},"n":"UnicastPacketsSent","d":785067,"h":103080000171,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":785067,"h":4295752363,"f":4}],"h":785067}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPInterfaceStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv4InterfaceProperties", ($self) => class IPv4InterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 850603;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885752491,"f":257},"n":"Index","d":850603,"h":8590785195,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":21475687083,"f":257},"n":"IsAutomaticPrivateAddressingActive","d":850603,"h":17180719787,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":30065621675,"f":257},"n":"IsAutomaticPrivateAddressingEnabled","d":850603,"h":25770654379,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":38655556267,"f":257},"n":"IsDhcpEnabled","d":850603,"h":34360588971,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":47245490859,"f":257},"n":"IsForwardingEnabled","d":850603,"h":42950523563,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":55835425451,"f":257},"n":"Mtu","d":850603,"h":51540458155,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":64425360043,"f":257},"n":"UsesWins","d":850603,"h":60130392747,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":850603,"h":4295817899,"f":4}],"h":850603}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv4InterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv4InterfaceStatistics", ($self) => class IPv4InterfaceStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 916139;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885818027,"f":257},"n":"BytesReceived","d":916139,"h":8590850731,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475752619,"f":257},"n":"BytesSent","d":916139,"h":17180785323,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065687211,"f":257},"n":"IncomingPacketsDiscarded","d":916139,"h":25770719915,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655621803,"f":257},"n":"IncomingPacketsWithErrors","d":916139,"h":34360654507,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245556395,"f":257},"n":"IncomingUnknownProtocolPackets","d":916139,"h":42950589099,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55835490987,"f":257},"n":"NonUnicastPacketsReceived","d":916139,"h":51540523691,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64425425579,"f":257},"n":"NonUnicastPacketsSent","d":916139,"h":60130458283,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73015360171,"f":257},"n":"OutgoingPacketsDiscarded","d":916139,"h":68720392875,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605294763,"f":257},"n":"OutgoingPacketsWithErrors","d":916139,"h":77310327467,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90195229355,"f":257},"n":"OutputQueueLength","d":916139,"h":85900262059,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98785163947,"f":257},"n":"UnicastPacketsReceived","d":916139,"h":94490196651,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107375098539,"f":257},"n":"UnicastPacketsSent","d":916139,"h":103080131243,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":916139,"h":4295883435,"f":4}],"h":916139}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv4InterfaceStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv6InterfaceProperties", ($self) => class IPv6InterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*long */ GetScopeId(/*System.Net.NetworkInformation.ScopeLevel*/ scopeLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 981675;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885883563,"f":257},"n":"Index","d":981675,"h":8590916267,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":21475818155,"f":257},"n":"Mtu","d":981675,"h":17180850859,"f":257}],"m":[{"r":917505,"p":[{"n":"scopeLevel","p":1964715}],"n":"GetScopeId","d":981675,"h":25770785451,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":981675,"h":4295948971,"f":4}],"h":981675}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv6InterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkInterface", ($self) => class NetworkInterface extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string */ get Description()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get IPv6LoopbackInterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReceiveOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get LoopbackInterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.NetworkInterfaceType */ get NetworkInterfaceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.OperationalStatus */ get OperationalStatus()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Speed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get SupportsMulticast()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.NetworkInterface[] */ GetAllNetworkInterfaces()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPInterfaceProperties */ GetIPProperties()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPInterfaceStatistics */ GetIPStatistics()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPv4InterfaceStatistics */ GetIPv4Statistics()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ GetIsNetworkAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.PhysicalAddress */ GetPhysicalAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Supports(/*System.Net.NetworkInformation.NetworkInterfaceComponent*/ networkInterfaceComponent)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1571499;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12886473387,"f":129},"n":"Description","d":1571499,"h":8591506091,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":21476407979,"f":129},"n":"Id","d":1571499,"h":17181440683,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":30066342571,"f":33},"n":"IPv6LoopbackInterfaceIndex","d":1571499,"h":25771375275,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":38656277163,"f":129},"n":"IsReceiveOnly","d":1571499,"h":34361309867,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":47246211755,"f":33},"n":"LoopbackInterfaceIndex","d":1571499,"h":42951244459,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":55836146347,"f":129},"n":"Name","d":1571499,"h":51541179051,"f":129},{"p":1702571,"g":{"r":0,"d":0,"h":64426080939,"f":129},"n":"NetworkInterfaceType","d":1571499,"h":60131113643,"f":129},{"p":1768107,"g":{"r":0,"d":0,"h":73016015531,"f":129},"n":"OperationalStatus","d":1571499,"h":68721048235,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":81605950123,"f":129},"n":"Speed","d":1571499,"h":77310982827,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":90195884715,"f":129},"n":"SupportsMulticast","d":1571499,"h":85900917419,"f":129}],"m":[{"r":0,"n":"GetAllNetworkInterfaces","d":1571499,"h":94490852011,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":719531,"n":"GetIPProperties","d":1571499,"h":98785819307,"f":129},{"r":785067,"n":"GetIPStatistics","d":1571499,"h":103080786603,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":916139,"n":"GetIPv4Statistics","d":1571499,"h":107375753899,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":262145,"n":"GetIsNetworkAvailable","d":1571499,"h":111670721195,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":1833643,"n":"GetPhysicalAddress","d":1571499,"h":115965688491,"f":129},{"r":262145,"p":[{"n":"networkInterfaceComponent","p":1637035}],"n":"Supports","d":1571499,"h":120260655787,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":1571499,"h":4296538795,"f":4}],"h":1571499}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterface`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.TcpConnectionInformation", ($self) => class TcpConnectionInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2095787;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3338714,"g":{"r":0,"d":0,"h":12886997675,"f":257},"n":"LocalEndPoint","d":2095787,"h":8592030379,"f":257},{"p":3338714,"g":{"r":0,"d":0,"h":21476932267,"f":257},"n":"RemoteEndPoint","d":2095787,"h":17181964971,"f":257},{"p":2161323,"g":{"r":0,"d":0,"h":30066866859,"f":257},"n":"State","d":2095787,"h":25771899563,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2095787,"h":4297063083,"f":4}],"h":2095787}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpConnectionInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.TcpStatistics", ($self) => class TcpStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2226859;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887128747,"f":257},"n":"ConnectionsAccepted","d":2226859,"h":8592161451,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21477063339,"f":257},"n":"ConnectionsInitiated","d":2226859,"h":17182096043,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30066997931,"f":257},"n":"CumulativeConnections","d":2226859,"h":25772030635,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38656932523,"f":257},"n":"CurrentConnections","d":2226859,"h":34361965227,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47246867115,"f":257},"n":"ErrorsReceived","d":2226859,"h":42951899819,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55836801707,"f":257},"n":"FailedConnectionAttempts","d":2226859,"h":51541834411,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64426736299,"f":257},"n":"MaximumConnections","d":2226859,"h":60131769003,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73016670891,"f":257},"n":"MaximumTransmissionTimeout","d":2226859,"h":68721703595,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":81606605483,"f":257},"n":"MinimumTransmissionTimeout","d":2226859,"h":77311638187,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90196540075,"f":257},"n":"ResetConnections","d":2226859,"h":85901572779,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98786474667,"f":257},"n":"ResetsSent","d":2226859,"h":94491507371,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107376409259,"f":257},"n":"SegmentsReceived","d":2226859,"h":103081441963,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":115966343851,"f":257},"n":"SegmentsResent","d":2226859,"h":111671376555,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":124556278443,"f":257},"n":"SegmentsSent","d":2226859,"h":120261311147,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2226859,"h":4297194155,"f":4}],"h":2226859}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UdpStatistics", ($self) => class UdpStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2292395;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887194283,"f":257},"n":"DatagramsReceived","d":2292395,"h":8592226987,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21477128875,"f":257},"n":"DatagramsSent","d":2292395,"h":17182161579,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30067063467,"f":257},"n":"IncomingDatagramsDiscarded","d":2292395,"h":25772096171,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38656998059,"f":257},"n":"IncomingDatagramsWithErrors","d":2292395,"h":34362030763,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":47246932651,"f":257},"n":"UdpListeners","d":2292395,"h":42951965355,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2292395,"h":4297259691,"f":4}],"h":2292395}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.UdpStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.MulticastIPAddressInformation", ($self) => class MulticastIPAddressInformation extends $.$snn.System.Net.NetworkInformation.IPAddressInformation
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 1047211;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":457387,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885949099,"f":257},"n":"AddressPreferredLifetime","d":1047211,"h":8590981803,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":21475883691,"f":257},"n":"AddressValidLifetime","d":1047211,"h":17180916395,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":30065818283,"f":257},"n":"DhcpLeaseLifetime","d":1047211,"h":25770850987,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":129707,"g":{"r":0,"d":0,"h":38655752875,"f":257},"n":"DuplicateAddressDetectionState","d":1047211,"h":34360785579,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1899179,"g":{"r":0,"d":0,"h":47245687467,"f":257},"n":"PrefixOrigin","d":1047211,"h":42950720171,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":2030251,"g":{"r":0,"d":0,"h":55835622059,"f":257},"n":"SuffixOrigin","d":1047211,"h":51540654763,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":1047211,"h":4296014507,"f":4}],"h":1047211}; }
            static get $b() { return $.$snn.System.Net.NetworkInformation.IPAddressInformation; }
            static get $fullName() { return `System.Net.NetworkInformation.MulticastIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UnicastIPAddressInformation", ($self) => class UnicastIPAddressInformation extends $.$snn.System.Net.NetworkInformation.IPAddressInformation
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get PrefixLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2357931;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":457387,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887259819,"f":257},"n":"AddressPreferredLifetime","d":2357931,"h":8592292523,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":21477194411,"f":257},"n":"AddressValidLifetime","d":2357931,"h":17182227115,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":30067129003,"f":257},"n":"DhcpLeaseLifetime","d":2357931,"h":25772161707,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":129707,"g":{"r":0,"d":0,"h":38657063595,"f":257},"n":"DuplicateAddressDetectionState","d":2357931,"h":34362096299,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":3076570,"g":{"r":0,"d":0,"h":47246998187,"f":257},"n":"IPv4Mask","d":2357931,"h":42952030891,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":55836932779,"f":129},"n":"PrefixLength","d":2357931,"h":51541965483,"f":129},{"p":1899179,"g":{"r":0,"d":0,"h":64426867371,"f":257},"n":"PrefixOrigin","d":2357931,"h":60131900075,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":2030251,"g":{"r":0,"d":0,"h":73016801963,"f":257},"n":"SuffixOrigin","d":2357931,"h":68721834667,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":2357931,"h":4297325227,"f":4}],"h":2357931}; }
            static get $b() { return $.$snn.System.Net.NetworkInformation.IPAddressInformation; }
            static get $fullName() { return `System.Net.NetworkInformation.UnicastIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkChange", ($self) => class NetworkChange extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.NetworkInformation.NetworkAddressChangedEventHandler?*/static  add_NetworkAddressChanged(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAddressChangedEventHandler?*/static  remove_NetworkAddressChanged(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler?*/static  add_NetworkAvailabilityChanged(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler?*/static  remove_NetworkAvailabilityChanged(value)
            {
            }
            static /*void */ RegisterNetworkChange(/*System.Net.NetworkInformation.NetworkChange*/ nc)
            {
            }
            static $h = 1440427;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"nc","p":1440427}],"n":"RegisterNetworkChange","d":1440427,"h":34361178795,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":12955811841,"a":[{"v":"This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.","t":1310721},{"v":true,"t":262145}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":1440427,"h":4296407723,"f":1,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":12955811841,"a":[{"v":"This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.","t":1310721},{"v":true,"t":262145}]}]}],"e":[{"e":1243819,"m":{"r":65537,"p":[{"n":"value","p":1243819}],"n":"add_NetworkAddressChanged","d":1440427,"h":12886342315,"f":33},"r":{"r":65537,"p":[{"n":"value","p":1243819}],"n":"remove_NetworkAddressChanged","d":1440427,"h":17181309611,"f":33},"n":"NetworkAddressChanged","d":1440427,"h":8591375019,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"e":1309355,"m":{"r":65537,"p":[{"n":"value","p":1309355}],"n":"add_NetworkAvailabilityChanged","d":1440427,"h":25771244203,"f":33},"r":{"r":65537,"p":[{"n":"value","p":1309355}],"n":"remove_NetworkAvailabilityChanged","d":1440427,"h":30066211499,"f":33},"n":"NetworkAvailabilityChanged","d":1440427,"h":21476276907,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]}],"h":1440427}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkChange`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.PhysicalAddress", ($self) => class PhysicalAddress extends $.$spc.System.Object
        {
            /*System.Net.NetworkInformation.PhysicalAddress*/ static None = null;
            $ctor$1(/*byte[]*/ address)
            {
                super.$ctor();
                {
                }
                return this;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.Equals.apply(this, arguments); }
            /*byte[] */ GetAddressBytes()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.GetHashCode.apply(this, arguments); }
            static /*System.Net.NetworkInformation.PhysicalAddress */ Parse(/*System.ReadOnlySpan<char>*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.PhysicalAddress */ Parse$1(/*string?*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.ToString.apply(this, arguments); }
            static /*bool */ TryParse(/*System.ReadOnlySpan<char>*/ address, /*out System.Net.NetworkInformation.PhysicalAddress?*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ TryParse$1(/*string?*/ address, /*out System.Net.NetworkInformation.PhysicalAddress?*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1833643;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":1833643,"h":12886735531,"f":32769},{"r":0,"n":"GetAddressBytes","d":1833643,"h":17181702827,"f":1},{"r":655361,"n":"GetHashCode","d":1833643,"h":21476670123,"f":32769},{"r":1833643,"p":[{"n":"address","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Parse","d":1833643,"h":25771637419,"f":33},{"r":1833643,"p":[{"n":"address","p":1310721}],"n":"Parse","o":"@$1","d":1833643,"h":30066604715,"f":33},{"r":1310721,"n":"ToString","d":1833643,"h":34361572011,"f":32769},{"r":262145,"p":[{"n":"address","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"value","p":1833643,"f":2}],"n":"TryParse","d":1833643,"h":38656539307,"f":33},{"r":262145,"p":[{"n":"address","p":1310721},{"n":"value","p":1833643,"f":2}],"n":"TryParse","o":"@$1","d":1833643,"h":42951506603,"f":33}],"l":[{"t":1833643,"n":"None","d":1833643,"h":4296800939,"f":33}],"c":[{"p":[{"n":"address","p":0}],"n":".ctor","o":"$ctor$1","d":1833643,"h":8591768235,"f":1}],"h":1833643}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.PhysicalAddress`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.GatewayIPAddressInformationCollection", ($self) => class GatewayIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.GatewayIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.GatewayIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.GatewayIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Add(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Contains(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.CopyTo(System.Net.NetworkInformation.GatewayIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Remove(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.GatewayIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 260779;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885162667,"f":129},"n":"Count","d":260779,"h":8590195371,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475097259,"f":129},"n":"IsReadOnly","d":260779,"h":17180129963,"f":129},{"p":195243,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065031851,"f":129},"n":"Item","o":"@$2","d":260779,"h":25770064555,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":195243}],"n":"Add","d":260779,"h":34359999147,"f":129},{"r":65537,"n":"Clear","d":260779,"h":38654966443,"f":129},{"r":262145,"p":[{"n":"address","p":195243}],"n":"Contains","d":260779,"h":42949933739,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":260779,"h":47244901035,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,"n":"GetEnumerator","d":260779,"h":51539868331,"f":129},{"r":262145,"p":[{"n":"address","p":195243}],"n":"Remove","d":260779,"h":55834835627,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":260779,"h":4295228075,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,31588353],"h":260779}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.GatewayIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPAddressInformationCollection", ($self) => class IPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.IPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.IPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Add(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Contains(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.CopyTo(System.Net.NetworkInformation.IPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Remove(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.IPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 522923;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885424811,"f":129},"n":"Count","d":522923,"h":8590457515,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475359403,"f":129},"n":"IsReadOnly","d":522923,"h":17180392107,"f":129},{"p":457387,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065293995,"f":129},"n":"Item","o":"@$2","d":522923,"h":25770326699,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":457387}],"n":"Add","d":522923,"h":34360261291,"f":129},{"r":65537,"n":"Clear","d":522923,"h":38655228587,"f":129},{"r":262145,"p":[{"n":"address","p":457387}],"n":"Contains","d":522923,"h":42950195883,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":522923,"h":47245163179,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,"n":"GetEnumerator","d":522923,"h":51540130475,"f":129},{"r":262145,"p":[{"n":"address","p":457387}],"n":"Remove","d":522923,"h":55835097771,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":522923,"h":4295490219,"f":8}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,31588353],"h":522923}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.IPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.IPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.MulticastIPAddressInformationCollection", ($self) => class MulticastIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.MulticastIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.MulticastIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.MulticastIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Add(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Contains(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.CopyTo(System.Net.NetworkInformation.MulticastIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Remove(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.MulticastIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 1112747;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886014635,"f":129},"n":"Count","d":1112747,"h":8591047339,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475949227,"f":129},"n":"IsReadOnly","d":1112747,"h":17180981931,"f":129},{"p":1047211,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065883819,"f":129},"n":"Item","o":"@$2","d":1112747,"h":25770916523,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":1047211}],"n":"Add","d":1112747,"h":34360851115,"f":129},{"r":65537,"n":"Clear","d":1112747,"h":38655818411,"f":129},{"r":262145,"p":[{"n":"address","p":1047211}],"n":"Contains","d":1112747,"h":42950785707,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":1112747,"h":47245753003,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,"n":"GetEnumerator","d":1112747,"h":51540720299,"f":129},{"r":262145,"p":[{"n":"address","p":1047211}],"n":"Remove","d":1112747,"h":55835687595,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":1112747,"h":4296080043,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,31588353],"h":1112747}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.MulticastIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UnicastIPAddressInformationCollection", ($self) => class UnicastIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.UnicastIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.UnicastIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Add(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Contains(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.CopyTo(System.Net.NetworkInformation.UnicastIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Remove(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.UnicastIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 2423467;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12887325355,"f":129},"n":"Count","d":2423467,"h":8592358059,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21477259947,"f":129},"n":"IsReadOnly","d":2423467,"h":17182292651,"f":129},{"p":2357931,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30067194539,"f":129},"n":"Item","o":"@$2","d":2423467,"h":25772227243,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":2357931}],"n":"Add","d":2423467,"h":34362161835,"f":129},{"r":65537,"n":"Clear","d":2423467,"h":38657129131,"f":129},{"r":262145,"p":[{"n":"address","p":2357931}],"n":"Contains","d":2423467,"h":42952096427,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":2423467,"h":47247063723,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,"n":"GetEnumerator","d":2423467,"h":51542031019,"f":129},{"r":262145,"p":[{"n":"address","p":2357931}],"n":"Remove","d":2423467,"h":55836998315,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":2423467,"h":4297390763,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,31588353],"h":2423467}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.UnicastIPAddressInformationCollection`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.DuplicateAddressDetectionState", ($self) => class DuplicateAddressDetectionState extends $.$spc.System.Enum
        {
            static Invalid = 0;
            static Tentative = 1;
            static Duplicate = 2;
            static Deprecated = 3;
            static Preferred = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Invalid": 0n,
                    "Tentative": 1n,
                    "Duplicate": 2n,
                    "Deprecated": 3n,
                    "Preferred": 4n
                };
            }
            static $h = 129707;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":129707,"n":"Invalid","d":129707,"h":4295097003,"f":33},{"t":129707,"n":"Tentative","d":129707,"h":8590064299,"f":33},{"t":129707,"n":"Duplicate","d":129707,"h":12885031595,"f":33},{"t":129707,"n":"Deprecated","d":129707,"h":17179998891,"f":33},{"t":129707,"n":"Preferred","d":129707,"h":21474966187,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":129707,"h":25769933483,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":129707}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.DuplicateAddressDetectionState`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetBiosNodeType", ($self) => class NetBiosNodeType extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Broadcast = 1;
            static Peer2Peer = 2;
            static Mixed = 4;
            static Hybrid = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Broadcast": 1n,
                    "Peer2Peer": 2n,
                    "Mixed": 4n,
                    "Hybrid": 8n
                };
            }
            static $h = 1178283;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1178283,"n":"Unknown","d":1178283,"h":4296145579,"f":33},{"t":1178283,"n":"Broadcast","d":1178283,"h":8591112875,"f":33},{"t":1178283,"n":"Peer2Peer","d":1178283,"h":12886080171,"f":33},{"t":1178283,"n":"Mixed","d":1178283,"h":17181047467,"f":33},{"t":1178283,"n":"Hybrid","d":1178283,"h":21476014763,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1178283,"h":25770982059,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1178283}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetBiosNodeType`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetworkInterfaceComponent", ($self) => class NetworkInterfaceComponent extends $.$spc.System.Enum
        {
            static IPv4 = 0;
            static IPv6 = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "IPv4": 0n,
                    "IPv6": 1n
                };
            }
            static $h = 1637035;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1637035,"n":"IPv4","d":1637035,"h":4296604331,"f":33},{"t":1637035,"n":"IPv6","d":1637035,"h":8591571627,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1637035,"h":12886538923,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1637035}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterfaceComponent`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetworkInterfaceType", ($self) => class NetworkInterfaceType extends $.$spc.System.Enum
        {
            static Unknown = 1;
            static Ethernet = 6;
            static TokenRing = 9;
            static Fddi = 15;
            static BasicIsdn = 20;
            static PrimaryIsdn = 21;
            static Ppp = 23;
            static Loopback = 24;
            static Ethernet3Megabit = 26;
            static Slip = 28;
            static Atm = 37;
            static GenericModem = 48;
            static FastEthernetT = 62;
            static Isdn = 63;
            static FastEthernetFx = 69;
            static Wireless80211 = 71;
            static AsymmetricDsl = 94;
            static RateAdaptDsl = 95;
            static SymmetricDsl = 96;
            static VeryHighSpeedDsl = 97;
            static IPOverAtm = 114;
            static GigabitEthernet = 117;
            static Tunnel = 131;
            static MultiRateSymmetricDsl = 143;
            static HighPerformanceSerialBus = 144;
            static Wman = 237;
            static Wwanpp = 243;
            static Wwanpp2 = 244;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 1n,
                    "Ethernet": 6n,
                    "TokenRing": 9n,
                    "Fddi": 15n,
                    "BasicIsdn": 20n,
                    "PrimaryIsdn": 21n,
                    "Ppp": 23n,
                    "Loopback": 24n,
                    "Ethernet3Megabit": 26n,
                    "Slip": 28n,
                    "Atm": 37n,
                    "GenericModem": 48n,
                    "FastEthernetT": 62n,
                    "Isdn": 63n,
                    "FastEthernetFx": 69n,
                    "Wireless80211": 71n,
                    "AsymmetricDsl": 94n,
                    "RateAdaptDsl": 95n,
                    "SymmetricDsl": 96n,
                    "VeryHighSpeedDsl": 97n,
                    "IPOverAtm": 114n,
                    "GigabitEthernet": 117n,
                    "Tunnel": 131n,
                    "MultiRateSymmetricDsl": 143n,
                    "HighPerformanceSerialBus": 144n,
                    "Wman": 237n,
                    "Wwanpp": 243n,
                    "Wwanpp2": 244n
                };
            }
            static $h = 1702571;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1702571,"n":"Unknown","d":1702571,"h":4296669867,"f":33},{"t":1702571,"n":"Ethernet","d":1702571,"h":8591637163,"f":33},{"t":1702571,"n":"TokenRing","d":1702571,"h":12886604459,"f":33},{"t":1702571,"n":"Fddi","d":1702571,"h":17181571755,"f":33},{"t":1702571,"n":"BasicIsdn","d":1702571,"h":21476539051,"f":33},{"t":1702571,"n":"PrimaryIsdn","d":1702571,"h":25771506347,"f":33},{"t":1702571,"n":"Ppp","d":1702571,"h":30066473643,"f":33},{"t":1702571,"n":"Loopback","d":1702571,"h":34361440939,"f":33},{"t":1702571,"n":"Ethernet3Megabit","d":1702571,"h":38656408235,"f":33},{"t":1702571,"n":"Slip","d":1702571,"h":42951375531,"f":33},{"t":1702571,"n":"Atm","d":1702571,"h":47246342827,"f":33},{"t":1702571,"n":"GenericModem","d":1702571,"h":51541310123,"f":33},{"t":1702571,"n":"FastEthernetT","d":1702571,"h":55836277419,"f":33},{"t":1702571,"n":"Isdn","d":1702571,"h":60131244715,"f":33},{"t":1702571,"n":"FastEthernetFx","d":1702571,"h":64426212011,"f":33},{"t":1702571,"n":"Wireless80211","d":1702571,"h":68721179307,"f":33},{"t":1702571,"n":"AsymmetricDsl","d":1702571,"h":73016146603,"f":33},{"t":1702571,"n":"RateAdaptDsl","d":1702571,"h":77311113899,"f":33},{"t":1702571,"n":"SymmetricDsl","d":1702571,"h":81606081195,"f":33},{"t":1702571,"n":"VeryHighSpeedDsl","d":1702571,"h":85901048491,"f":33},{"t":1702571,"n":"IPOverAtm","d":1702571,"h":90196015787,"f":33},{"t":1702571,"n":"GigabitEthernet","d":1702571,"h":94490983083,"f":33},{"t":1702571,"n":"Tunnel","d":1702571,"h":98785950379,"f":33},{"t":1702571,"n":"MultiRateSymmetricDsl","d":1702571,"h":103080917675,"f":33},{"t":1702571,"n":"HighPerformanceSerialBus","d":1702571,"h":107375884971,"f":33},{"t":1702571,"n":"Wman","d":1702571,"h":111670852267,"f":33},{"t":1702571,"n":"Wwanpp","d":1702571,"h":115965819563,"f":33},{"t":1702571,"n":"Wwanpp2","d":1702571,"h":120260786859,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1702571,"h":124555754155,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1702571}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterfaceType`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.OperationalStatus", ($self) => class OperationalStatus extends $.$spc.System.Enum
        {
            static Up = 1;
            static Down = 2;
            static Testing = 3;
            static Unknown = 4;
            static Dormant = 5;
            static NotPresent = 6;
            static LowerLayerDown = 7;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Up": 1n,
                    "Down": 2n,
                    "Testing": 3n,
                    "Unknown": 4n,
                    "Dormant": 5n,
                    "NotPresent": 6n,
                    "LowerLayerDown": 7n
                };
            }
            static $h = 1768107;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1768107,"n":"Up","d":1768107,"h":4296735403,"f":33},{"t":1768107,"n":"Down","d":1768107,"h":8591702699,"f":33},{"t":1768107,"n":"Testing","d":1768107,"h":12886669995,"f":33},{"t":1768107,"n":"Unknown","d":1768107,"h":17181637291,"f":33},{"t":1768107,"n":"Dormant","d":1768107,"h":21476604587,"f":33},{"t":1768107,"n":"NotPresent","d":1768107,"h":25771571883,"f":33},{"t":1768107,"n":"LowerLayerDown","d":1768107,"h":30066539179,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1768107,"h":34361506475,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1768107}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.OperationalStatus`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.PrefixOrigin", ($self) => class PrefixOrigin extends $.$spc.System.Enum
        {
            static Other = 0;
            static Manual = 1;
            static WellKnown = 2;
            static Dhcp = 3;
            static RouterAdvertisement = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Other": 0n,
                    "Manual": 1n,
                    "WellKnown": 2n,
                    "Dhcp": 3n,
                    "RouterAdvertisement": 4n
                };
            }
            static $h = 1899179;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1899179,"n":"Other","d":1899179,"h":4296866475,"f":33},{"t":1899179,"n":"Manual","d":1899179,"h":8591833771,"f":33},{"t":1899179,"n":"WellKnown","d":1899179,"h":12886801067,"f":33},{"t":1899179,"n":"Dhcp","d":1899179,"h":17181768363,"f":33},{"t":1899179,"n":"RouterAdvertisement","d":1899179,"h":21476735659,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1899179,"h":25771702955,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1899179}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.PrefixOrigin`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.ScopeLevel", ($self) => class ScopeLevel extends $.$spc.System.Enum
        {
            static None = 0;
            static Interface = 1;
            static Link = 2;
            static Subnet = 3;
            static Admin = 4;
            static Site = 5;
            static Organization = 8;
            static Global = 14;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Interface": 1n,
                    "Link": 2n,
                    "Subnet": 3n,
                    "Admin": 4n,
                    "Site": 5n,
                    "Organization": 8n,
                    "Global": 14n
                };
            }
            static $h = 1964715;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1964715,"n":"None","d":1964715,"h":4296932011,"f":33},{"t":1964715,"n":"Interface","d":1964715,"h":8591899307,"f":33},{"t":1964715,"n":"Link","d":1964715,"h":12886866603,"f":33},{"t":1964715,"n":"Subnet","d":1964715,"h":17181833899,"f":33},{"t":1964715,"n":"Admin","d":1964715,"h":21476801195,"f":33},{"t":1964715,"n":"Site","d":1964715,"h":25771768491,"f":33},{"t":1964715,"n":"Organization","d":1964715,"h":30066735787,"f":33},{"t":1964715,"n":"Global","d":1964715,"h":34361703083,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1964715,"h":38656670379,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1964715}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.ScopeLevel`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.SuffixOrigin", ($self) => class SuffixOrigin extends $.$spc.System.Enum
        {
            static Other = 0;
            static Manual = 1;
            static WellKnown = 2;
            static OriginDhcp = 3;
            static LinkLayerAddress = 4;
            static Random = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Other": 0n,
                    "Manual": 1n,
                    "WellKnown": 2n,
                    "OriginDhcp": 3n,
                    "LinkLayerAddress": 4n,
                    "Random": 5n
                };
            }
            static $h = 2030251;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2030251,"n":"Other","d":2030251,"h":4296997547,"f":33},{"t":2030251,"n":"Manual","d":2030251,"h":8591964843,"f":33},{"t":2030251,"n":"WellKnown","d":2030251,"h":12886932139,"f":33},{"t":2030251,"n":"OriginDhcp","d":2030251,"h":17181899435,"f":33},{"t":2030251,"n":"LinkLayerAddress","d":2030251,"h":21476866731,"f":33},{"t":2030251,"n":"Random","d":2030251,"h":25771834027,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2030251,"h":30066801323,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2030251}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.SuffixOrigin`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.TcpState", ($self) => class TcpState extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Closed = 1;
            static Listen = 2;
            static SynSent = 3;
            static SynReceived = 4;
            static Established = 5;
            static FinWait1 = 6;
            static FinWait2 = 7;
            static CloseWait = 8;
            static Closing = 9;
            static LastAck = 10;
            static TimeWait = 11;
            static DeleteTcb = 12;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Closed": 1n,
                    "Listen": 2n,
                    "SynSent": 3n,
                    "SynReceived": 4n,
                    "Established": 5n,
                    "FinWait1": 6n,
                    "FinWait2": 7n,
                    "CloseWait": 8n,
                    "Closing": 9n,
                    "LastAck": 10n,
                    "TimeWait": 11n,
                    "DeleteTcb": 12n
                };
            }
            static $h = 2161323;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2161323,"n":"Unknown","d":2161323,"h":4297128619,"f":33},{"t":2161323,"n":"Closed","d":2161323,"h":8592095915,"f":33},{"t":2161323,"n":"Listen","d":2161323,"h":12887063211,"f":33},{"t":2161323,"n":"SynSent","d":2161323,"h":17182030507,"f":33},{"t":2161323,"n":"SynReceived","d":2161323,"h":21476997803,"f":33},{"t":2161323,"n":"Established","d":2161323,"h":25771965099,"f":33},{"t":2161323,"n":"FinWait1","d":2161323,"h":30066932395,"f":33},{"t":2161323,"n":"FinWait2","d":2161323,"h":34361899691,"f":33},{"t":2161323,"n":"CloseWait","d":2161323,"h":38656866987,"f":33},{"t":2161323,"n":"Closing","d":2161323,"h":42951834283,"f":33},{"t":2161323,"n":"LastAck","d":2161323,"h":47246801579,"f":33},{"t":2161323,"n":"TimeWait","d":2161323,"h":51541768875,"f":33},{"t":2161323,"n":"DeleteTcb","d":2161323,"h":55836736171,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2161323,"h":60131703467,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2161323}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpState`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAvailabilityEventArgs", ($self) => class NetworkAvailabilityEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ get IsAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1374891;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886276779,"f":1},"n":"IsAvailable","d":1374891,"h":8591309483,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1374891,"h":4296342187,"f":8}],"h":1374891}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAvailabilityEventArgs`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAddressChangedEventHandler", ($self) => class NetworkAddressChangedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ $sender, /*$.$spc.System.EventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 1243819;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":46923777}],"n":"Invoke","d":1243819,"h":8591178411,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":46923777},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":1243819,"h":12886145707,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":1243819,"h":17181113003,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1243819,"h":4296211115,"f":1}],"i":[57147393,113377281],"h":1243819}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAddressChangedEventHandler`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler", ($self) => class NetworkAvailabilityChangedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ $sender, /*$.$snn.System.Net.NetworkInformation.NetworkAvailabilityEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 1309355;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":1374891}],"n":"Invoke","d":1309355,"h":8591243947,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":1374891},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":1309355,"h":12886211243,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":1309355,"h":17181178539,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1309355,"h":4296276651,"f":1}],"i":[57147393,113377281],"h":1309355}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkInformationException", ($self) => class NetworkInformationException extends $.$spc.System.ComponentModel.Win32Exception
        {
            $ctor$20()
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            $ctor$21(/*int*/ errorCode)
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            $ctor$22(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            /*int */ get ErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1505963;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":33292289,"h":1505963}; }
            static get $b() { return $.$spc.System.ComponentModel.Win32Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInformationException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Console", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets"))