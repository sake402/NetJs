
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $ssc, $sris, $scsl, $sl, $snp, $sspw, $sdd, $snnr, $sns) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.NetworkInformation", 
    {"h":50288,"f":"System.Net.NetworkInformation","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.NetworkInformation","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.NetworkInformation","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snn.System.Net.NetworkInformation.GatewayIPAddressInformation", ($self) => class GatewayIPAddressInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 181360;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3053002,"g":{"r":0,"d":0,"h":12885083248,"f":257},"n":"Address","d":181360,"h":8590115952,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":181360,"h":4295148656,"f":4}],"h":181360}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.GatewayIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IcmpV4Statistics", ($self) => class IcmpV4Statistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 312432;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885214320,"f":257},"n":"AddressMaskRepliesReceived","d":312432,"h":8590247024,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475148912,"f":257},"n":"AddressMaskRepliesSent","d":312432,"h":17180181616,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065083504,"f":257},"n":"AddressMaskRequestsReceived","d":312432,"h":25770116208,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655018096,"f":257},"n":"AddressMaskRequestsSent","d":312432,"h":34360050800,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47244952688,"f":257},"n":"DestinationUnreachableMessagesReceived","d":312432,"h":42949985392,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55834887280,"f":257},"n":"DestinationUnreachableMessagesSent","d":312432,"h":51539919984,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64424821872,"f":257},"n":"EchoRepliesReceived","d":312432,"h":60129854576,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73014756464,"f":257},"n":"EchoRepliesSent","d":312432,"h":68719789168,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":81604691056,"f":257},"n":"EchoRequestsReceived","d":312432,"h":77309723760,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90194625648,"f":257},"n":"EchoRequestsSent","d":312432,"h":85899658352,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98784560240,"f":257},"n":"ErrorsReceived","d":312432,"h":94489592944,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":107374494832,"f":257},"n":"ErrorsSent","d":312432,"h":103079527536,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":115964429424,"f":257},"n":"MessagesReceived","d":312432,"h":111669462128,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":124554364016,"f":257},"n":"MessagesSent","d":312432,"h":120259396720,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":133144298608,"f":257},"n":"ParameterProblemsReceived","d":312432,"h":128849331312,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":141734233200,"f":257},"n":"ParameterProblemsSent","d":312432,"h":137439265904,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":150324167792,"f":257},"n":"RedirectsReceived","d":312432,"h":146029200496,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":158914102384,"f":257},"n":"RedirectsSent","d":312432,"h":154619135088,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":167504036976,"f":257},"n":"SourceQuenchesReceived","d":312432,"h":163209069680,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":176093971568,"f":257},"n":"SourceQuenchesSent","d":312432,"h":171799004272,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":184683906160,"f":257},"n":"TimeExceededMessagesReceived","d":312432,"h":180388938864,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":193273840752,"f":257},"n":"TimeExceededMessagesSent","d":312432,"h":188978873456,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":201863775344,"f":257},"n":"TimestampRepliesReceived","d":312432,"h":197568808048,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":210453709936,"f":257},"n":"TimestampRepliesSent","d":312432,"h":206158742640,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":219043644528,"f":257},"n":"TimestampRequestsReceived","d":312432,"h":214748677232,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":227633579120,"f":257},"n":"TimestampRequestsSent","d":312432,"h":223338611824,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":312432,"h":4295279728,"f":4}],"h":312432}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IcmpV4Statistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IcmpV6Statistics", ($self) => class IcmpV6Statistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 377968;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885279856,"f":257},"n":"DestinationUnreachableMessagesReceived","d":377968,"h":8590312560,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475214448,"f":257},"n":"DestinationUnreachableMessagesSent","d":377968,"h":17180247152,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065149040,"f":257},"n":"EchoRepliesReceived","d":377968,"h":25770181744,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655083632,"f":257},"n":"EchoRepliesSent","d":377968,"h":34360116336,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245018224,"f":257},"n":"EchoRequestsReceived","d":377968,"h":42950050928,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55834952816,"f":257},"n":"EchoRequestsSent","d":377968,"h":51539985520,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64424887408,"f":257},"n":"ErrorsReceived","d":377968,"h":60129920112,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73014822000,"f":257},"n":"ErrorsSent","d":377968,"h":68719854704,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81604756592,"f":257},"n":"MembershipQueriesReceived","d":377968,"h":77309789296,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90194691184,"f":257},"n":"MembershipQueriesSent","d":377968,"h":85899723888,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98784625776,"f":257},"n":"MembershipReductionsReceived","d":377968,"h":94489658480,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107374560368,"f":257},"n":"MembershipReductionsSent","d":377968,"h":103079593072,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":115964494960,"f":257},"n":"MembershipReportsReceived","d":377968,"h":111669527664,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":124554429552,"f":257},"n":"MembershipReportsSent","d":377968,"h":120259462256,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":133144364144,"f":257},"n":"MessagesReceived","d":377968,"h":128849396848,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":141734298736,"f":257},"n":"MessagesSent","d":377968,"h":137439331440,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":150324233328,"f":257},"n":"NeighborAdvertisementsReceived","d":377968,"h":146029266032,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":158914167920,"f":257},"n":"NeighborAdvertisementsSent","d":377968,"h":154619200624,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":167504102512,"f":257},"n":"NeighborSolicitsReceived","d":377968,"h":163209135216,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":176094037104,"f":257},"n":"NeighborSolicitsSent","d":377968,"h":171799069808,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":184683971696,"f":257},"n":"PacketTooBigMessagesReceived","d":377968,"h":180389004400,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":193273906288,"f":257},"n":"PacketTooBigMessagesSent","d":377968,"h":188978938992,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":201863840880,"f":257},"n":"ParameterProblemsReceived","d":377968,"h":197568873584,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":210453775472,"f":257},"n":"ParameterProblemsSent","d":377968,"h":206158808176,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":219043710064,"f":257},"n":"RedirectsReceived","d":377968,"h":214748742768,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":227633644656,"f":257},"n":"RedirectsSent","d":377968,"h":223338677360,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":236223579248,"f":257},"n":"RouterAdvertisementsReceived","d":377968,"h":231928611952,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":244813513840,"f":257},"n":"RouterAdvertisementsSent","d":377968,"h":240518546544,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":253403448432,"f":257},"n":"RouterSolicitsReceived","d":377968,"h":249108481136,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":261993383024,"f":257},"n":"RouterSolicitsSent","d":377968,"h":257698415728,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":270583317616,"f":257},"n":"TimeExceededMessagesReceived","d":377968,"h":266288350320,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":279173252208,"f":257},"n":"TimeExceededMessagesSent","d":377968,"h":274878284912,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":377968,"h":4295345264,"f":4}],"h":377968}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IcmpV6Statistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPAddressInformation", ($self) => class IPAddressInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 443504;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3053002,"g":{"r":0,"d":0,"h":12885345392,"f":257},"n":"Address","d":443504,"h":8590378096,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":21475279984,"f":257},"n":"IsDnsEligible","d":443504,"h":17180312688,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":30065214576,"f":257},"n":"IsTransient","d":443504,"h":25770247280,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":443504,"h":4295410800,"f":4}],"h":443504}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPGlobalProperties", ($self) => class IPGlobalProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.IAsyncResult */ BeginGetUnicastAddresses(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformationCollection */ EndGetUnicastAddresses(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.IPGlobalProperties */ GetIPGlobalProperties()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformationCollection */ GetUnicastAddresses()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.NetworkInformation.UnicastIPAddressInformationCollection> */ GetUnicastAddressesAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 574576;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885476464,"f":257},"n":"DhcpScopeName","d":574576,"h":8590509168,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":21475411056,"f":257},"n":"DomainName","d":574576,"h":17180443760,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":30065345648,"f":257},"n":"HostName","d":574576,"h":25770378352,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":38655280240,"f":257},"n":"IsWinsProxy","d":574576,"h":34360312944,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1164400,"g":{"r":0,"d":0,"h":47245214832,"f":257},"n":"NodeType","d":574576,"h":42950247536,"f":257}],"m":[{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginGetUnicastAddresses","d":574576,"h":51540182128,"f":129},{"r":2409584,"p":[{"n":"asyncResult","p":56950785}],"n":"EndGetUnicastAddresses","d":574576,"h":55835149424,"f":129},{"r":0,"n":"GetActiveTcpConnections","d":574576,"h":60130116720,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":0,"n":"GetActiveTcpListeners","d":574576,"h":64425084016,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":0,"n":"GetActiveUdpListeners","d":574576,"h":68720051312,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":312432,"n":"GetIcmpV4Statistics","d":574576,"h":73015018608,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":377968,"n":"GetIcmpV6Statistics","d":574576,"h":77309985904,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":574576,"n":"GetIPGlobalProperties","d":574576,"h":81604953200,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":640112,"n":"GetIPv4GlobalStatistics","d":574576,"h":85899920496,"f":257},{"r":640112,"n":"GetIPv6GlobalStatistics","d":574576,"h":90194887792,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"r":2212976,"n":"GetTcpIPv4Statistics","d":574576,"h":94489855088,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2212976,"n":"GetTcpIPv6Statistics","d":574576,"h":98784822384,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2278512,"n":"GetUdpIPv4Statistics","d":574576,"h":103079789680,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2278512,"n":"GetUdpIPv6Statistics","d":574576,"h":107374756976,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2409584,"n":"GetUnicastAddresses","d":574576,"h":111669724272,"f":129},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformationCollection).$h,"n":"GetUnicastAddressesAsync","d":574576,"h":115964691568,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":574576,"h":4295541872,"f":4}],"h":574576}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPGlobalProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPGlobalStatistics", ($self) => class IPGlobalStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 640112;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885542000,"f":257},"n":"DefaultTtl","d":640112,"h":8590574704,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":21475476592,"f":257},"n":"ForwardingEnabled","d":640112,"h":17180509296,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":30065411184,"f":257},"n":"NumberOfInterfaces","d":640112,"h":25770443888,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":38655345776,"f":257},"n":"NumberOfIPAddresses","d":640112,"h":34360378480,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":47245280368,"f":257},"n":"NumberOfRoutes","d":640112,"h":42950313072,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":55835214960,"f":257},"n":"OutputPacketRequests","d":640112,"h":51540247664,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":64425149552,"f":257},"n":"OutputPacketRoutingDiscards","d":640112,"h":60130182256,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73015084144,"f":257},"n":"OutputPacketsDiscarded","d":640112,"h":68720116848,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605018736,"f":257},"n":"OutputPacketsWithNoRoute","d":640112,"h":77310051440,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":90194953328,"f":257},"n":"PacketFragmentFailures","d":640112,"h":85899986032,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":98784887920,"f":257},"n":"PacketReassembliesRequired","d":640112,"h":94489920624,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":107374822512,"f":257},"n":"PacketReassemblyFailures","d":640112,"h":103079855216,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":115964757104,"f":257},"n":"PacketReassemblyTimeout","d":640112,"h":111669789808,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":124554691696,"f":257},"n":"PacketsFragmented","d":640112,"h":120259724400,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":133144626288,"f":257},"n":"PacketsReassembled","d":640112,"h":128849658992,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":141734560880,"f":257},"n":"ReceivedPackets","d":640112,"h":137439593584,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":150324495472,"f":257},"n":"ReceivedPacketsDelivered","d":640112,"h":146029528176,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":158914430064,"f":257},"n":"ReceivedPacketsDiscarded","d":640112,"h":154619462768,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":167504364656,"f":257},"n":"ReceivedPacketsForwarded","d":640112,"h":163209397360,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":176094299248,"f":257},"n":"ReceivedPacketsWithAddressErrors","d":640112,"h":171799331952,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":184684233840,"f":257},"n":"ReceivedPacketsWithHeadersErrors","d":640112,"h":180389266544,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":193274168432,"f":257},"n":"ReceivedPacketsWithUnknownProtocol","d":640112,"h":188979201136,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":640112,"h":4295607408,"f":4}],"h":640112}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPGlobalStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPInterfaceProperties", ($self) => class IPInterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 705648;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":509040,"g":{"r":0,"d":0,"h":12885607536,"f":257},"n":"AnycastAddresses","d":705648,"h":8590640240,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":4036042,"g":{"r":0,"d":0,"h":21475542128,"f":257},"n":"DhcpServerAddresses","d":705648,"h":17180574832,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":4036042,"g":{"r":0,"d":0,"h":30065476720,"f":257},"n":"DnsAddresses","d":705648,"h":25770509424,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":38655411312,"f":257},"n":"DnsSuffix","d":705648,"h":34360444016,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":246896,"g":{"r":0,"d":0,"h":47245345904,"f":257},"n":"GatewayAddresses","d":705648,"h":42950378608,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":55835280496,"f":257},"n":"IsDnsEnabled","d":705648,"h":51540313200,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":64425215088,"f":257},"n":"IsDynamicDnsEnabled","d":705648,"h":60130247792,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1098864,"g":{"r":0,"d":0,"h":73015149680,"f":257},"n":"MulticastAddresses","d":705648,"h":68720182384,"f":257},{"p":2409584,"g":{"r":0,"d":0,"h":81605084272,"f":257},"n":"UnicastAddresses","d":705648,"h":77310116976,"f":257},{"p":4036042,"g":{"r":0,"d":0,"h":90195018864,"f":257},"n":"WinsServersAddresses","d":705648,"h":85900051568,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]}],"m":[{"r":836720,"n":"GetIPv4Properties","d":705648,"h":94489986160,"f":257},{"r":967792,"n":"GetIPv6Properties","d":705648,"h":98784953456,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":705648,"h":4295672944,"f":4}],"h":705648}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPInterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPInterfaceStatistics", ($self) => class IPInterfaceStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 771184;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885673072,"f":257},"n":"BytesReceived","d":771184,"h":8590705776,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475607664,"f":257},"n":"BytesSent","d":771184,"h":17180640368,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065542256,"f":257},"n":"IncomingPacketsDiscarded","d":771184,"h":25770574960,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655476848,"f":257},"n":"IncomingPacketsWithErrors","d":771184,"h":34360509552,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245411440,"f":257},"n":"IncomingUnknownProtocolPackets","d":771184,"h":42950444144,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"linux","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":55835346032,"f":257},"n":"NonUnicastPacketsReceived","d":771184,"h":51540378736,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64425280624,"f":257},"n":"NonUnicastPacketsSent","d":771184,"h":60130313328,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"linux","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73015215216,"f":257},"n":"OutgoingPacketsDiscarded","d":771184,"h":68720247920,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605149808,"f":257},"n":"OutgoingPacketsWithErrors","d":771184,"h":77310182512,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90195084400,"f":257},"n":"OutputQueueLength","d":771184,"h":85900117104,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98785018992,"f":257},"n":"UnicastPacketsReceived","d":771184,"h":94490051696,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107374953584,"f":257},"n":"UnicastPacketsSent","d":771184,"h":103079986288,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":771184,"h":4295738480,"f":4}],"h":771184}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPInterfaceStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv4InterfaceProperties", ($self) => class IPv4InterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 836720;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885738608,"f":257},"n":"Index","d":836720,"h":8590771312,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":21475673200,"f":257},"n":"IsAutomaticPrivateAddressingActive","d":836720,"h":17180705904,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":30065607792,"f":257},"n":"IsAutomaticPrivateAddressingEnabled","d":836720,"h":25770640496,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":38655542384,"f":257},"n":"IsDhcpEnabled","d":836720,"h":34360575088,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":47245476976,"f":257},"n":"IsForwardingEnabled","d":836720,"h":42950509680,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":55835411568,"f":257},"n":"Mtu","d":836720,"h":51540444272,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":64425346160,"f":257},"n":"UsesWins","d":836720,"h":60130378864,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":836720,"h":4295804016,"f":4}],"h":836720}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv4InterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv4InterfaceStatistics", ($self) => class IPv4InterfaceStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 902256;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885804144,"f":257},"n":"BytesReceived","d":902256,"h":8590836848,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475738736,"f":257},"n":"BytesSent","d":902256,"h":17180771440,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065673328,"f":257},"n":"IncomingPacketsDiscarded","d":902256,"h":25770706032,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655607920,"f":257},"n":"IncomingPacketsWithErrors","d":902256,"h":34360640624,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245542512,"f":257},"n":"IncomingUnknownProtocolPackets","d":902256,"h":42950575216,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55835477104,"f":257},"n":"NonUnicastPacketsReceived","d":902256,"h":51540509808,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64425411696,"f":257},"n":"NonUnicastPacketsSent","d":902256,"h":60130444400,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73015346288,"f":257},"n":"OutgoingPacketsDiscarded","d":902256,"h":68720378992,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605280880,"f":257},"n":"OutgoingPacketsWithErrors","d":902256,"h":77310313584,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90195215472,"f":257},"n":"OutputQueueLength","d":902256,"h":85900248176,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98785150064,"f":257},"n":"UnicastPacketsReceived","d":902256,"h":94490182768,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107375084656,"f":257},"n":"UnicastPacketsSent","d":902256,"h":103080117360,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":902256,"h":4295869552,"f":4}],"h":902256}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv4InterfaceStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv6InterfaceProperties", ($self) => class IPv6InterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*long */ GetScopeId(/*System.Net.NetworkInformation.ScopeLevel*/ scopeLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 967792;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885869680,"f":257},"n":"Index","d":967792,"h":8590902384,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":21475804272,"f":257},"n":"Mtu","d":967792,"h":17180836976,"f":257}],"m":[{"r":917505,"p":[{"n":"scopeLevel","p":1950832}],"n":"GetScopeId","d":967792,"h":25770771568,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":967792,"h":4295935088,"f":4}],"h":967792}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv6InterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkInterface", ($self) => class NetworkInterface extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string */ get Description()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get IPv6LoopbackInterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReceiveOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get LoopbackInterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.NetworkInterfaceType */ get NetworkInterfaceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.OperationalStatus */ get OperationalStatus()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Speed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get SupportsMulticast()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.NetworkInterface[] */ GetAllNetworkInterfaces()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPInterfaceProperties */ GetIPProperties()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPInterfaceStatistics */ GetIPStatistics()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPv4InterfaceStatistics */ GetIPv4Statistics()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ GetIsNetworkAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.PhysicalAddress */ GetPhysicalAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Supports(/*System.Net.NetworkInformation.NetworkInterfaceComponent*/ networkInterfaceComponent)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1557616;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12886459504,"f":129},"n":"Description","d":1557616,"h":8591492208,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":21476394096,"f":129},"n":"Id","d":1557616,"h":17181426800,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":30066328688,"f":33},"n":"IPv6LoopbackInterfaceIndex","d":1557616,"h":25771361392,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":38656263280,"f":129},"n":"IsReceiveOnly","d":1557616,"h":34361295984,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":47246197872,"f":33},"n":"LoopbackInterfaceIndex","d":1557616,"h":42951230576,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":55836132464,"f":129},"n":"Name","d":1557616,"h":51541165168,"f":129},{"p":1688688,"g":{"r":0,"d":0,"h":64426067056,"f":129},"n":"NetworkInterfaceType","d":1557616,"h":60131099760,"f":129},{"p":1754224,"g":{"r":0,"d":0,"h":73016001648,"f":129},"n":"OperationalStatus","d":1557616,"h":68721034352,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":81605936240,"f":129},"n":"Speed","d":1557616,"h":77310968944,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":90195870832,"f":129},"n":"SupportsMulticast","d":1557616,"h":85900903536,"f":129}],"m":[{"r":0,"n":"GetAllNetworkInterfaces","d":1557616,"h":94490838128,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":705648,"n":"GetIPProperties","d":1557616,"h":98785805424,"f":129},{"r":771184,"n":"GetIPStatistics","d":1557616,"h":103080772720,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":902256,"n":"GetIPv4Statistics","d":1557616,"h":107375740016,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":262145,"n":"GetIsNetworkAvailable","d":1557616,"h":111670707312,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":1819760,"n":"GetPhysicalAddress","d":1557616,"h":115965674608,"f":129},{"r":262145,"p":[{"n":"networkInterfaceComponent","p":1623152}],"n":"Supports","d":1557616,"h":120260641904,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":1557616,"h":4296524912,"f":4}],"h":1557616}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterface`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.TcpConnectionInformation", ($self) => class TcpConnectionInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2081904;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3315146,"g":{"r":0,"d":0,"h":12886983792,"f":257},"n":"LocalEndPoint","d":2081904,"h":8592016496,"f":257},{"p":3315146,"g":{"r":0,"d":0,"h":21476918384,"f":257},"n":"RemoteEndPoint","d":2081904,"h":17181951088,"f":257},{"p":2147440,"g":{"r":0,"d":0,"h":30066852976,"f":257},"n":"State","d":2081904,"h":25771885680,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2081904,"h":4297049200,"f":4}],"h":2081904}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpConnectionInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.TcpStatistics", ($self) => class TcpStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2212976;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887114864,"f":257},"n":"ConnectionsAccepted","d":2212976,"h":8592147568,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21477049456,"f":257},"n":"ConnectionsInitiated","d":2212976,"h":17182082160,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30066984048,"f":257},"n":"CumulativeConnections","d":2212976,"h":25772016752,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38656918640,"f":257},"n":"CurrentConnections","d":2212976,"h":34361951344,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47246853232,"f":257},"n":"ErrorsReceived","d":2212976,"h":42951885936,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55836787824,"f":257},"n":"FailedConnectionAttempts","d":2212976,"h":51541820528,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64426722416,"f":257},"n":"MaximumConnections","d":2212976,"h":60131755120,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73016657008,"f":257},"n":"MaximumTransmissionTimeout","d":2212976,"h":68721689712,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":81606591600,"f":257},"n":"MinimumTransmissionTimeout","d":2212976,"h":77311624304,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90196526192,"f":257},"n":"ResetConnections","d":2212976,"h":85901558896,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98786460784,"f":257},"n":"ResetsSent","d":2212976,"h":94491493488,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107376395376,"f":257},"n":"SegmentsReceived","d":2212976,"h":103081428080,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":115966329968,"f":257},"n":"SegmentsResent","d":2212976,"h":111671362672,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":124556264560,"f":257},"n":"SegmentsSent","d":2212976,"h":120261297264,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2212976,"h":4297180272,"f":4}],"h":2212976}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UdpStatistics", ($self) => class UdpStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2278512;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887180400,"f":257},"n":"DatagramsReceived","d":2278512,"h":8592213104,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21477114992,"f":257},"n":"DatagramsSent","d":2278512,"h":17182147696,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30067049584,"f":257},"n":"IncomingDatagramsDiscarded","d":2278512,"h":25772082288,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38656984176,"f":257},"n":"IncomingDatagramsWithErrors","d":2278512,"h":34362016880,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":47246918768,"f":257},"n":"UdpListeners","d":2278512,"h":42951951472,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2278512,"h":4297245808,"f":4}],"h":2278512}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.UdpStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.MulticastIPAddressInformation", ($self) => class MulticastIPAddressInformation extends $.$snn.System.Net.NetworkInformation.IPAddressInformation
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 1033328;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":443504,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885935216,"f":257},"n":"AddressPreferredLifetime","d":1033328,"h":8590967920,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":21475869808,"f":257},"n":"AddressValidLifetime","d":1033328,"h":17180902512,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":30065804400,"f":257},"n":"DhcpLeaseLifetime","d":1033328,"h":25770837104,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":115824,"g":{"r":0,"d":0,"h":38655738992,"f":257},"n":"DuplicateAddressDetectionState","d":1033328,"h":34360771696,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1885296,"g":{"r":0,"d":0,"h":47245673584,"f":257},"n":"PrefixOrigin","d":1033328,"h":42950706288,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":2016368,"g":{"r":0,"d":0,"h":55835608176,"f":257},"n":"SuffixOrigin","d":1033328,"h":51540640880,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":1033328,"h":4296000624,"f":4}],"h":1033328}; }
            static get $b() { return $.$snn.System.Net.NetworkInformation.IPAddressInformation; }
            static get $fullName() { return `System.Net.NetworkInformation.MulticastIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UnicastIPAddressInformation", ($self) => class UnicastIPAddressInformation extends $.$snn.System.Net.NetworkInformation.IPAddressInformation
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get PrefixLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2344048;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":443504,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887245936,"f":257},"n":"AddressPreferredLifetime","d":2344048,"h":8592278640,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":21477180528,"f":257},"n":"AddressValidLifetime","d":2344048,"h":17182213232,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":30067115120,"f":257},"n":"DhcpLeaseLifetime","d":2344048,"h":25772147824,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":115824,"g":{"r":0,"d":0,"h":38657049712,"f":257},"n":"DuplicateAddressDetectionState","d":2344048,"h":34362082416,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":3053002,"g":{"r":0,"d":0,"h":47246984304,"f":257},"n":"IPv4Mask","d":2344048,"h":42952017008,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":55836918896,"f":129},"n":"PrefixLength","d":2344048,"h":51541951600,"f":129},{"p":1885296,"g":{"r":0,"d":0,"h":64426853488,"f":257},"n":"PrefixOrigin","d":2344048,"h":60131886192,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":2016368,"g":{"r":0,"d":0,"h":73016788080,"f":257},"n":"SuffixOrigin","d":2344048,"h":68721820784,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":2344048,"h":4297311344,"f":4}],"h":2344048}; }
            static get $b() { return $.$snn.System.Net.NetworkInformation.IPAddressInformation; }
            static get $fullName() { return `System.Net.NetworkInformation.UnicastIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkChange", ($self) => class NetworkChange extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.NetworkInformation.NetworkAddressChangedEventHandler?*/static  NetworkAddressChanged$add(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAddressChangedEventHandler?*/static  NetworkAddressChanged$remove(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler?*/static  NetworkAvailabilityChanged$add(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler?*/static  NetworkAvailabilityChanged$remove(value)
            {
            }
            static /*void */ RegisterNetworkChange(/*System.Net.NetworkInformation.NetworkChange*/ nc)
            {
            }
            static $h = 1426544;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"nc","p":1426544}],"n":"RegisterNetworkChange","d":1426544,"h":34361164912,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":12955811841,"a":[{"v":"This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.","t":1310721},{"v":true,"t":262145}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":1426544,"h":4296393840,"f":1,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":12955811841,"a":[{"v":"This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.","t":1310721},{"v":true,"t":262145}]}]}],"e":[{"e":1229936,"m":{"r":65537,"p":[{"n":"value","p":1229936}],"n":"add_NetworkAddressChanged","d":1426544,"h":12886328432,"f":33},"r":{"r":65537,"p":[{"n":"value","p":1229936}],"n":"remove_NetworkAddressChanged","d":1426544,"h":17181295728,"f":33},"n":"NetworkAddressChanged","d":1426544,"h":8591361136,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"e":1295472,"m":{"r":65537,"p":[{"n":"value","p":1295472}],"n":"add_NetworkAvailabilityChanged","d":1426544,"h":25771230320,"f":33},"r":{"r":65537,"p":[{"n":"value","p":1295472}],"n":"remove_NetworkAvailabilityChanged","d":1426544,"h":30066197616,"f":33},"n":"NetworkAvailabilityChanged","d":1426544,"h":21476263024,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]}],"h":1426544}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkChange`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.PhysicalAddress", ($self) => class PhysicalAddress extends $.$spc.System.Object
        {
            /*System.Net.NetworkInformation.PhysicalAddress*/ static None = null;
            $ctor$1(/*byte[]*/ address)
            {
                super.$ctor();
                {
                }
                return this;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.Equals.apply(this, arguments); }
            /*byte[] */ GetAddressBytes()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.GetHashCode.apply(this, arguments); }
            static /*System.Net.NetworkInformation.PhysicalAddress */ Parse(/*System.ReadOnlySpan<char>*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.PhysicalAddress */ Parse$1(/*string?*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.ToString.apply(this, arguments); }
            static /*bool */ TryParse(/*System.ReadOnlySpan<char>*/ address, /*out System.Net.NetworkInformation.PhysicalAddress?*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ TryParse$1(/*string?*/ address, /*out System.Net.NetworkInformation.PhysicalAddress?*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1819760;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":1819760,"h":12886721648,"f":32769},{"r":0,"n":"GetAddressBytes","d":1819760,"h":17181688944,"f":1},{"r":655361,"n":"GetHashCode","d":1819760,"h":21476656240,"f":32769},{"r":1819760,"p":[{"n":"address","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Parse","d":1819760,"h":25771623536,"f":33},{"r":1819760,"p":[{"n":"address","p":1310721}],"n":"Parse","o":"@$1","d":1819760,"h":30066590832,"f":33},{"r":1310721,"n":"ToString","d":1819760,"h":34361558128,"f":32769},{"r":262145,"p":[{"n":"address","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"value","p":1819760,"f":2}],"n":"TryParse","d":1819760,"h":38656525424,"f":33},{"r":262145,"p":[{"n":"address","p":1310721},{"n":"value","p":1819760,"f":2}],"n":"TryParse","o":"@$1","d":1819760,"h":42951492720,"f":33}],"l":[{"t":1819760,"n":"None","d":1819760,"h":4296787056,"f":33}],"c":[{"p":[{"n":"address","p":0}],"n":".ctor","o":"$ctor$1","d":1819760,"h":8591754352,"f":1}],"h":1819760}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.PhysicalAddress`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.GatewayIPAddressInformationCollection", ($self) => class GatewayIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.GatewayIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.GatewayIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.GatewayIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Add(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Contains(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.CopyTo(System.Net.NetworkInformation.GatewayIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Remove(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.GatewayIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 246896;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885148784,"f":129},"n":"Count","d":246896,"h":8590181488,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475083376,"f":129},"n":"IsReadOnly","d":246896,"h":17180116080,"f":129},{"p":181360,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065017968,"f":129},"n":"Item","o":"@$2","d":246896,"h":25770050672,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":181360}],"n":"Add","d":246896,"h":34359985264,"f":129},{"r":65537,"n":"Clear","d":246896,"h":38654952560,"f":129},{"r":262145,"p":[{"n":"address","p":181360}],"n":"Contains","d":246896,"h":42949919856,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":246896,"h":47244887152,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,"n":"GetEnumerator","d":246896,"h":51539854448,"f":129},{"r":262145,"p":[{"n":"address","p":181360}],"n":"Remove","d":246896,"h":55834821744,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":246896,"h":4295214192,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,31588353],"h":246896}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.GatewayIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPAddressInformationCollection", ($self) => class IPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.IPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.IPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Add(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Contains(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.CopyTo(System.Net.NetworkInformation.IPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Remove(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.IPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 509040;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885410928,"f":129},"n":"Count","d":509040,"h":8590443632,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475345520,"f":129},"n":"IsReadOnly","d":509040,"h":17180378224,"f":129},{"p":443504,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065280112,"f":129},"n":"Item","o":"@$2","d":509040,"h":25770312816,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":443504}],"n":"Add","d":509040,"h":34360247408,"f":129},{"r":65537,"n":"Clear","d":509040,"h":38655214704,"f":129},{"r":262145,"p":[{"n":"address","p":443504}],"n":"Contains","d":509040,"h":42950182000,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":509040,"h":47245149296,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,"n":"GetEnumerator","d":509040,"h":51540116592,"f":129},{"r":262145,"p":[{"n":"address","p":443504}],"n":"Remove","d":509040,"h":55835083888,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":509040,"h":4295476336,"f":8}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,31588353],"h":509040}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.IPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.IPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.MulticastIPAddressInformationCollection", ($self) => class MulticastIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.MulticastIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.MulticastIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.MulticastIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Add(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Contains(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.CopyTo(System.Net.NetworkInformation.MulticastIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Remove(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.MulticastIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 1098864;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886000752,"f":129},"n":"Count","d":1098864,"h":8591033456,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475935344,"f":129},"n":"IsReadOnly","d":1098864,"h":17180968048,"f":129},{"p":1033328,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065869936,"f":129},"n":"Item","o":"@$2","d":1098864,"h":25770902640,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":1033328}],"n":"Add","d":1098864,"h":34360837232,"f":129},{"r":65537,"n":"Clear","d":1098864,"h":38655804528,"f":129},{"r":262145,"p":[{"n":"address","p":1033328}],"n":"Contains","d":1098864,"h":42950771824,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":1098864,"h":47245739120,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,"n":"GetEnumerator","d":1098864,"h":51540706416,"f":129},{"r":262145,"p":[{"n":"address","p":1033328}],"n":"Remove","d":1098864,"h":55835673712,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":1098864,"h":4296066160,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,31588353],"h":1098864}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.MulticastIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UnicastIPAddressInformationCollection", ($self) => class UnicastIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.UnicastIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.UnicastIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Add(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Contains(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.CopyTo(System.Net.NetworkInformation.UnicastIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Remove(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.UnicastIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 2409584;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12887311472,"f":129},"n":"Count","d":2409584,"h":8592344176,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21477246064,"f":129},"n":"IsReadOnly","d":2409584,"h":17182278768,"f":129},{"p":2344048,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30067180656,"f":129},"n":"Item","o":"@$2","d":2409584,"h":25772213360,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":2344048}],"n":"Add","d":2409584,"h":34362147952,"f":129},{"r":65537,"n":"Clear","d":2409584,"h":38657115248,"f":129},{"r":262145,"p":[{"n":"address","p":2344048}],"n":"Contains","d":2409584,"h":42952082544,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":2409584,"h":47247049840,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,"n":"GetEnumerator","d":2409584,"h":51542017136,"f":129},{"r":262145,"p":[{"n":"address","p":2344048}],"n":"Remove","d":2409584,"h":55836984432,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":2409584,"h":4297376880,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,31588353],"h":2409584}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.UnicastIPAddressInformationCollection`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.DuplicateAddressDetectionState", ($self) => class DuplicateAddressDetectionState extends $.$spc.System.Enum
        {
            static Invalid = 0;
            static Tentative = 1;
            static Duplicate = 2;
            static Deprecated = 3;
            static Preferred = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Invalid": 0n,
                    "Tentative": 1n,
                    "Duplicate": 2n,
                    "Deprecated": 3n,
                    "Preferred": 4n
                };
            }
            static $h = 115824;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":115824,"n":"Invalid","d":115824,"h":4295083120,"f":33},{"t":115824,"n":"Tentative","d":115824,"h":8590050416,"f":33},{"t":115824,"n":"Duplicate","d":115824,"h":12885017712,"f":33},{"t":115824,"n":"Deprecated","d":115824,"h":17179985008,"f":33},{"t":115824,"n":"Preferred","d":115824,"h":21474952304,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":115824,"h":25769919600,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":115824}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.DuplicateAddressDetectionState`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetBiosNodeType", ($self) => class NetBiosNodeType extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Broadcast = 1;
            static Peer2Peer = 2;
            static Mixed = 4;
            static Hybrid = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Broadcast": 1n,
                    "Peer2Peer": 2n,
                    "Mixed": 4n,
                    "Hybrid": 8n
                };
            }
            static $h = 1164400;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1164400,"n":"Unknown","d":1164400,"h":4296131696,"f":33},{"t":1164400,"n":"Broadcast","d":1164400,"h":8591098992,"f":33},{"t":1164400,"n":"Peer2Peer","d":1164400,"h":12886066288,"f":33},{"t":1164400,"n":"Mixed","d":1164400,"h":17181033584,"f":33},{"t":1164400,"n":"Hybrid","d":1164400,"h":21476000880,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1164400,"h":25770968176,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1164400}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetBiosNodeType`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetworkInterfaceComponent", ($self) => class NetworkInterfaceComponent extends $.$spc.System.Enum
        {
            static IPv4 = 0;
            static IPv6 = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "IPv4": 0n,
                    "IPv6": 1n
                };
            }
            static $h = 1623152;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1623152,"n":"IPv4","d":1623152,"h":4296590448,"f":33},{"t":1623152,"n":"IPv6","d":1623152,"h":8591557744,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1623152,"h":12886525040,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1623152}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterfaceComponent`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetworkInterfaceType", ($self) => class NetworkInterfaceType extends $.$spc.System.Enum
        {
            static Unknown = 1;
            static Ethernet = 6;
            static TokenRing = 9;
            static Fddi = 15;
            static BasicIsdn = 20;
            static PrimaryIsdn = 21;
            static Ppp = 23;
            static Loopback = 24;
            static Ethernet3Megabit = 26;
            static Slip = 28;
            static Atm = 37;
            static GenericModem = 48;
            static FastEthernetT = 62;
            static Isdn = 63;
            static FastEthernetFx = 69;
            static Wireless80211 = 71;
            static AsymmetricDsl = 94;
            static RateAdaptDsl = 95;
            static SymmetricDsl = 96;
            static VeryHighSpeedDsl = 97;
            static IPOverAtm = 114;
            static GigabitEthernet = 117;
            static Tunnel = 131;
            static MultiRateSymmetricDsl = 143;
            static HighPerformanceSerialBus = 144;
            static Wman = 237;
            static Wwanpp = 243;
            static Wwanpp2 = 244;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 1n,
                    "Ethernet": 6n,
                    "TokenRing": 9n,
                    "Fddi": 15n,
                    "BasicIsdn": 20n,
                    "PrimaryIsdn": 21n,
                    "Ppp": 23n,
                    "Loopback": 24n,
                    "Ethernet3Megabit": 26n,
                    "Slip": 28n,
                    "Atm": 37n,
                    "GenericModem": 48n,
                    "FastEthernetT": 62n,
                    "Isdn": 63n,
                    "FastEthernetFx": 69n,
                    "Wireless80211": 71n,
                    "AsymmetricDsl": 94n,
                    "RateAdaptDsl": 95n,
                    "SymmetricDsl": 96n,
                    "VeryHighSpeedDsl": 97n,
                    "IPOverAtm": 114n,
                    "GigabitEthernet": 117n,
                    "Tunnel": 131n,
                    "MultiRateSymmetricDsl": 143n,
                    "HighPerformanceSerialBus": 144n,
                    "Wman": 237n,
                    "Wwanpp": 243n,
                    "Wwanpp2": 244n
                };
            }
            static $h = 1688688;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1688688,"n":"Unknown","d":1688688,"h":4296655984,"f":33},{"t":1688688,"n":"Ethernet","d":1688688,"h":8591623280,"f":33},{"t":1688688,"n":"TokenRing","d":1688688,"h":12886590576,"f":33},{"t":1688688,"n":"Fddi","d":1688688,"h":17181557872,"f":33},{"t":1688688,"n":"BasicIsdn","d":1688688,"h":21476525168,"f":33},{"t":1688688,"n":"PrimaryIsdn","d":1688688,"h":25771492464,"f":33},{"t":1688688,"n":"Ppp","d":1688688,"h":30066459760,"f":33},{"t":1688688,"n":"Loopback","d":1688688,"h":34361427056,"f":33},{"t":1688688,"n":"Ethernet3Megabit","d":1688688,"h":38656394352,"f":33},{"t":1688688,"n":"Slip","d":1688688,"h":42951361648,"f":33},{"t":1688688,"n":"Atm","d":1688688,"h":47246328944,"f":33},{"t":1688688,"n":"GenericModem","d":1688688,"h":51541296240,"f":33},{"t":1688688,"n":"FastEthernetT","d":1688688,"h":55836263536,"f":33},{"t":1688688,"n":"Isdn","d":1688688,"h":60131230832,"f":33},{"t":1688688,"n":"FastEthernetFx","d":1688688,"h":64426198128,"f":33},{"t":1688688,"n":"Wireless80211","d":1688688,"h":68721165424,"f":33},{"t":1688688,"n":"AsymmetricDsl","d":1688688,"h":73016132720,"f":33},{"t":1688688,"n":"RateAdaptDsl","d":1688688,"h":77311100016,"f":33},{"t":1688688,"n":"SymmetricDsl","d":1688688,"h":81606067312,"f":33},{"t":1688688,"n":"VeryHighSpeedDsl","d":1688688,"h":85901034608,"f":33},{"t":1688688,"n":"IPOverAtm","d":1688688,"h":90196001904,"f":33},{"t":1688688,"n":"GigabitEthernet","d":1688688,"h":94490969200,"f":33},{"t":1688688,"n":"Tunnel","d":1688688,"h":98785936496,"f":33},{"t":1688688,"n":"MultiRateSymmetricDsl","d":1688688,"h":103080903792,"f":33},{"t":1688688,"n":"HighPerformanceSerialBus","d":1688688,"h":107375871088,"f":33},{"t":1688688,"n":"Wman","d":1688688,"h":111670838384,"f":33},{"t":1688688,"n":"Wwanpp","d":1688688,"h":115965805680,"f":33},{"t":1688688,"n":"Wwanpp2","d":1688688,"h":120260772976,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1688688,"h":124555740272,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1688688}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterfaceType`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.OperationalStatus", ($self) => class OperationalStatus extends $.$spc.System.Enum
        {
            static Up = 1;
            static Down = 2;
            static Testing = 3;
            static Unknown = 4;
            static Dormant = 5;
            static NotPresent = 6;
            static LowerLayerDown = 7;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Up": 1n,
                    "Down": 2n,
                    "Testing": 3n,
                    "Unknown": 4n,
                    "Dormant": 5n,
                    "NotPresent": 6n,
                    "LowerLayerDown": 7n
                };
            }
            static $h = 1754224;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1754224,"n":"Up","d":1754224,"h":4296721520,"f":33},{"t":1754224,"n":"Down","d":1754224,"h":8591688816,"f":33},{"t":1754224,"n":"Testing","d":1754224,"h":12886656112,"f":33},{"t":1754224,"n":"Unknown","d":1754224,"h":17181623408,"f":33},{"t":1754224,"n":"Dormant","d":1754224,"h":21476590704,"f":33},{"t":1754224,"n":"NotPresent","d":1754224,"h":25771558000,"f":33},{"t":1754224,"n":"LowerLayerDown","d":1754224,"h":30066525296,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1754224,"h":34361492592,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1754224}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.OperationalStatus`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.PrefixOrigin", ($self) => class PrefixOrigin extends $.$spc.System.Enum
        {
            static Other = 0;
            static Manual = 1;
            static WellKnown = 2;
            static Dhcp = 3;
            static RouterAdvertisement = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Other": 0n,
                    "Manual": 1n,
                    "WellKnown": 2n,
                    "Dhcp": 3n,
                    "RouterAdvertisement": 4n
                };
            }
            static $h = 1885296;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1885296,"n":"Other","d":1885296,"h":4296852592,"f":33},{"t":1885296,"n":"Manual","d":1885296,"h":8591819888,"f":33},{"t":1885296,"n":"WellKnown","d":1885296,"h":12886787184,"f":33},{"t":1885296,"n":"Dhcp","d":1885296,"h":17181754480,"f":33},{"t":1885296,"n":"RouterAdvertisement","d":1885296,"h":21476721776,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1885296,"h":25771689072,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1885296}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.PrefixOrigin`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.ScopeLevel", ($self) => class ScopeLevel extends $.$spc.System.Enum
        {
            static None = 0;
            static Interface = 1;
            static Link = 2;
            static Subnet = 3;
            static Admin = 4;
            static Site = 5;
            static Organization = 8;
            static Global = 14;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Interface": 1n,
                    "Link": 2n,
                    "Subnet": 3n,
                    "Admin": 4n,
                    "Site": 5n,
                    "Organization": 8n,
                    "Global": 14n
                };
            }
            static $h = 1950832;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1950832,"n":"None","d":1950832,"h":4296918128,"f":33},{"t":1950832,"n":"Interface","d":1950832,"h":8591885424,"f":33},{"t":1950832,"n":"Link","d":1950832,"h":12886852720,"f":33},{"t":1950832,"n":"Subnet","d":1950832,"h":17181820016,"f":33},{"t":1950832,"n":"Admin","d":1950832,"h":21476787312,"f":33},{"t":1950832,"n":"Site","d":1950832,"h":25771754608,"f":33},{"t":1950832,"n":"Organization","d":1950832,"h":30066721904,"f":33},{"t":1950832,"n":"Global","d":1950832,"h":34361689200,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1950832,"h":38656656496,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1950832}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.ScopeLevel`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.SuffixOrigin", ($self) => class SuffixOrigin extends $.$spc.System.Enum
        {
            static Other = 0;
            static Manual = 1;
            static WellKnown = 2;
            static OriginDhcp = 3;
            static LinkLayerAddress = 4;
            static Random = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Other": 0n,
                    "Manual": 1n,
                    "WellKnown": 2n,
                    "OriginDhcp": 3n,
                    "LinkLayerAddress": 4n,
                    "Random": 5n
                };
            }
            static $h = 2016368;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2016368,"n":"Other","d":2016368,"h":4296983664,"f":33},{"t":2016368,"n":"Manual","d":2016368,"h":8591950960,"f":33},{"t":2016368,"n":"WellKnown","d":2016368,"h":12886918256,"f":33},{"t":2016368,"n":"OriginDhcp","d":2016368,"h":17181885552,"f":33},{"t":2016368,"n":"LinkLayerAddress","d":2016368,"h":21476852848,"f":33},{"t":2016368,"n":"Random","d":2016368,"h":25771820144,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2016368,"h":30066787440,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2016368}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.SuffixOrigin`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.TcpState", ($self) => class TcpState extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Closed = 1;
            static Listen = 2;
            static SynSent = 3;
            static SynReceived = 4;
            static Established = 5;
            static FinWait1 = 6;
            static FinWait2 = 7;
            static CloseWait = 8;
            static Closing = 9;
            static LastAck = 10;
            static TimeWait = 11;
            static DeleteTcb = 12;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Closed": 1n,
                    "Listen": 2n,
                    "SynSent": 3n,
                    "SynReceived": 4n,
                    "Established": 5n,
                    "FinWait1": 6n,
                    "FinWait2": 7n,
                    "CloseWait": 8n,
                    "Closing": 9n,
                    "LastAck": 10n,
                    "TimeWait": 11n,
                    "DeleteTcb": 12n
                };
            }
            static $h = 2147440;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2147440,"n":"Unknown","d":2147440,"h":4297114736,"f":33},{"t":2147440,"n":"Closed","d":2147440,"h":8592082032,"f":33},{"t":2147440,"n":"Listen","d":2147440,"h":12887049328,"f":33},{"t":2147440,"n":"SynSent","d":2147440,"h":17182016624,"f":33},{"t":2147440,"n":"SynReceived","d":2147440,"h":21476983920,"f":33},{"t":2147440,"n":"Established","d":2147440,"h":25771951216,"f":33},{"t":2147440,"n":"FinWait1","d":2147440,"h":30066918512,"f":33},{"t":2147440,"n":"FinWait2","d":2147440,"h":34361885808,"f":33},{"t":2147440,"n":"CloseWait","d":2147440,"h":38656853104,"f":33},{"t":2147440,"n":"Closing","d":2147440,"h":42951820400,"f":33},{"t":2147440,"n":"LastAck","d":2147440,"h":47246787696,"f":33},{"t":2147440,"n":"TimeWait","d":2147440,"h":51541754992,"f":33},{"t":2147440,"n":"DeleteTcb","d":2147440,"h":55836722288,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2147440,"h":60131689584,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2147440}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpState`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAvailabilityEventArgs", ($self) => class NetworkAvailabilityEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ get IsAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1361008;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886262896,"f":1},"n":"IsAvailable","d":1361008,"h":8591295600,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1361008,"h":4296328304,"f":8}],"h":1361008}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAvailabilityEventArgs`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAddressChangedEventHandler", ($self) => class NetworkAddressChangedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ $sender, /*$.$spc.System.EventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 1229936;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":46923777}],"n":"Invoke","d":1229936,"h":8591164528,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":46923777},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":1229936,"h":12886131824,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":1229936,"h":17181099120,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1229936,"h":4296197232,"f":1}],"i":[57147393,113377281],"h":1229936}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAddressChangedEventHandler`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler", ($self) => class NetworkAvailabilityChangedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ $sender, /*$.$snn.System.Net.NetworkInformation.NetworkAvailabilityEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 1295472;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":1361008}],"n":"Invoke","d":1295472,"h":8591230064,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":1361008},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":1295472,"h":12886197360,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":1295472,"h":17181164656,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1295472,"h":4296262768,"f":1}],"i":[57147393,113377281],"h":1295472}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkInformationException", ($self) => class NetworkInformationException extends $.$spc.System.ComponentModel.Win32Exception
        {
            $ctor$20()
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            $ctor$21(/*int*/ errorCode)
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            $ctor$22(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            /*int */ get ErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1492080;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":33292289,"h":1492080}; }
            static get $b() { return $.$spc.System.ComponentModel.Win32Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInformationException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Console", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets"))