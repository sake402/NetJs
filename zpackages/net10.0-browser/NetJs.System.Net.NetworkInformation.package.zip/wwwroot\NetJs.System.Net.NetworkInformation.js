
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stee, $scsl, $snv, $sri, $sl, $stt, $sttp, $sdd, $snp, $ssc, $sspw, $sto, $snnr, $sns) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.NetworkInformation", 
    {"h":61034,"f":"System.Net.NetworkInformation","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.NetworkInformation","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.NetworkInformation","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snn.System.Net.NetworkInformation.GatewayIPAddressInformation", ($self) => class GatewayIPAddressInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 192106;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3056114,"g":{"r":0,"d":0,"h":12885093994,"f":257},"n":"Address","d":192106,"h":8590126698,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":192106,"h":4295159402,"f":4}],"h":192106}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.GatewayIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IcmpV4Statistics", ($self) => class IcmpV4Statistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 323178;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885225066,"f":257},"n":"AddressMaskRepliesReceived","d":323178,"h":8590257770,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475159658,"f":257},"n":"AddressMaskRepliesSent","d":323178,"h":17180192362,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065094250,"f":257},"n":"AddressMaskRequestsReceived","d":323178,"h":25770126954,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655028842,"f":257},"n":"AddressMaskRequestsSent","d":323178,"h":34360061546,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47244963434,"f":257},"n":"DestinationUnreachableMessagesReceived","d":323178,"h":42949996138,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55834898026,"f":257},"n":"DestinationUnreachableMessagesSent","d":323178,"h":51539930730,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64424832618,"f":257},"n":"EchoRepliesReceived","d":323178,"h":60129865322,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73014767210,"f":257},"n":"EchoRepliesSent","d":323178,"h":68719799914,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":81604701802,"f":257},"n":"EchoRequestsReceived","d":323178,"h":77309734506,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90194636394,"f":257},"n":"EchoRequestsSent","d":323178,"h":85899669098,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98784570986,"f":257},"n":"ErrorsReceived","d":323178,"h":94489603690,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":107374505578,"f":257},"n":"ErrorsSent","d":323178,"h":103079538282,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":115964440170,"f":257},"n":"MessagesReceived","d":323178,"h":111669472874,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":124554374762,"f":257},"n":"MessagesSent","d":323178,"h":120259407466,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":133144309354,"f":257},"n":"ParameterProblemsReceived","d":323178,"h":128849342058,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":141734243946,"f":257},"n":"ParameterProblemsSent","d":323178,"h":137439276650,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":150324178538,"f":257},"n":"RedirectsReceived","d":323178,"h":146029211242,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":158914113130,"f":257},"n":"RedirectsSent","d":323178,"h":154619145834,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":167504047722,"f":257},"n":"SourceQuenchesReceived","d":323178,"h":163209080426,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":176093982314,"f":257},"n":"SourceQuenchesSent","d":323178,"h":171799015018,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":184683916906,"f":257},"n":"TimeExceededMessagesReceived","d":323178,"h":180388949610,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":193273851498,"f":257},"n":"TimeExceededMessagesSent","d":323178,"h":188978884202,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":201863786090,"f":257},"n":"TimestampRepliesReceived","d":323178,"h":197568818794,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":210453720682,"f":257},"n":"TimestampRepliesSent","d":323178,"h":206158753386,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":219043655274,"f":257},"n":"TimestampRequestsReceived","d":323178,"h":214748687978,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":227633589866,"f":257},"n":"TimestampRequestsSent","d":323178,"h":223338622570,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":323178,"h":4295290474,"f":4}],"h":323178}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IcmpV4Statistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IcmpV6Statistics", ($self) => class IcmpV6Statistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 388714;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885290602,"f":257},"n":"DestinationUnreachableMessagesReceived","d":388714,"h":8590323306,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475225194,"f":257},"n":"DestinationUnreachableMessagesSent","d":388714,"h":17180257898,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065159786,"f":257},"n":"EchoRepliesReceived","d":388714,"h":25770192490,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655094378,"f":257},"n":"EchoRepliesSent","d":388714,"h":34360127082,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245028970,"f":257},"n":"EchoRequestsReceived","d":388714,"h":42950061674,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55834963562,"f":257},"n":"EchoRequestsSent","d":388714,"h":51539996266,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64424898154,"f":257},"n":"ErrorsReceived","d":388714,"h":60129930858,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73014832746,"f":257},"n":"ErrorsSent","d":388714,"h":68719865450,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81604767338,"f":257},"n":"MembershipQueriesReceived","d":388714,"h":77309800042,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90194701930,"f":257},"n":"MembershipQueriesSent","d":388714,"h":85899734634,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98784636522,"f":257},"n":"MembershipReductionsReceived","d":388714,"h":94489669226,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107374571114,"f":257},"n":"MembershipReductionsSent","d":388714,"h":103079603818,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":115964505706,"f":257},"n":"MembershipReportsReceived","d":388714,"h":111669538410,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":124554440298,"f":257},"n":"MembershipReportsSent","d":388714,"h":120259473002,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":133144374890,"f":257},"n":"MessagesReceived","d":388714,"h":128849407594,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":141734309482,"f":257},"n":"MessagesSent","d":388714,"h":137439342186,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":150324244074,"f":257},"n":"NeighborAdvertisementsReceived","d":388714,"h":146029276778,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":158914178666,"f":257},"n":"NeighborAdvertisementsSent","d":388714,"h":154619211370,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":167504113258,"f":257},"n":"NeighborSolicitsReceived","d":388714,"h":163209145962,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":176094047850,"f":257},"n":"NeighborSolicitsSent","d":388714,"h":171799080554,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":184683982442,"f":257},"n":"PacketTooBigMessagesReceived","d":388714,"h":180389015146,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":193273917034,"f":257},"n":"PacketTooBigMessagesSent","d":388714,"h":188978949738,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":201863851626,"f":257},"n":"ParameterProblemsReceived","d":388714,"h":197568884330,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":210453786218,"f":257},"n":"ParameterProblemsSent","d":388714,"h":206158818922,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":219043720810,"f":257},"n":"RedirectsReceived","d":388714,"h":214748753514,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":227633655402,"f":257},"n":"RedirectsSent","d":388714,"h":223338688106,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":236223589994,"f":257},"n":"RouterAdvertisementsReceived","d":388714,"h":231928622698,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":244813524586,"f":257},"n":"RouterAdvertisementsSent","d":388714,"h":240518557290,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":253403459178,"f":257},"n":"RouterSolicitsReceived","d":388714,"h":249108491882,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":261993393770,"f":257},"n":"RouterSolicitsSent","d":388714,"h":257698426474,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":270583328362,"f":257},"n":"TimeExceededMessagesReceived","d":388714,"h":266288361066,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":279173262954,"f":257},"n":"TimeExceededMessagesSent","d":388714,"h":274878295658,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":388714,"h":4295356010,"f":4}],"h":388714}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IcmpV6Statistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPAddressInformation", ($self) => class IPAddressInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 454250;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3056114,"g":{"r":0,"d":0,"h":12885356138,"f":257},"n":"Address","d":454250,"h":8590388842,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":21475290730,"f":257},"n":"IsDnsEligible","d":454250,"h":17180323434,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":30065225322,"f":257},"n":"IsTransient","d":454250,"h":25770258026,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":454250,"h":4295421546,"f":4}],"h":454250}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPGlobalProperties", ($self) => class IPGlobalProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.IAsyncResult */ BeginGetUnicastAddresses(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformationCollection */ EndGetUnicastAddresses(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.IPGlobalProperties */ GetIPGlobalProperties()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformationCollection */ GetUnicastAddresses()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.NetworkInformation.UnicastIPAddressInformationCollection> */ GetUnicastAddressesAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 585322;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885487210,"f":257},"n":"DhcpScopeName","d":585322,"h":8590519914,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":21475421802,"f":257},"n":"DomainName","d":585322,"h":17180454506,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":30065356394,"f":257},"n":"HostName","d":585322,"h":25770389098,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":38655290986,"f":257},"n":"IsWinsProxy","d":585322,"h":34360323690,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1175146,"g":{"r":0,"d":0,"h":47245225578,"f":257},"n":"NodeType","d":585322,"h":42950258282,"f":257}],"m":[{"r":57016321,"p":[{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginGetUnicastAddresses","d":585322,"h":51540192874,"f":129},{"r":2420330,"p":[{"n":"asyncResult","p":57016321}],"n":"EndGetUnicastAddresses","d":585322,"h":55835160170,"f":129},{"r":0,"n":"GetActiveTcpConnections","d":585322,"h":60130127466,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":0,"n":"GetActiveTcpListeners","d":585322,"h":64425094762,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":0,"n":"GetActiveUdpListeners","d":585322,"h":68720062058,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":323178,"n":"GetIcmpV4Statistics","d":585322,"h":73015029354,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":388714,"n":"GetIcmpV6Statistics","d":585322,"h":77309996650,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":585322,"n":"GetIPGlobalProperties","d":585322,"h":81604963946,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":650858,"n":"GetIPv4GlobalStatistics","d":585322,"h":85899931242,"f":257},{"r":650858,"n":"GetIPv6GlobalStatistics","d":585322,"h":90194898538,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"r":2223722,"n":"GetTcpIPv4Statistics","d":585322,"h":94489865834,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2223722,"n":"GetTcpIPv6Statistics","d":585322,"h":98784833130,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2289258,"n":"GetUdpIPv4Statistics","d":585322,"h":103079800426,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2289258,"n":"GetUdpIPv6Statistics","d":585322,"h":107374767722,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2420330,"n":"GetUnicastAddresses","d":585322,"h":111669735018,"f":129},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformationCollection).$h,"n":"GetUnicastAddressesAsync","d":585322,"h":115964702314,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":585322,"h":4295552618,"f":4}],"h":585322}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPGlobalProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPGlobalStatistics", ($self) => class IPGlobalStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 650858;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885552746,"f":257},"n":"DefaultTtl","d":650858,"h":8590585450,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":21475487338,"f":257},"n":"ForwardingEnabled","d":650858,"h":17180520042,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":30065421930,"f":257},"n":"NumberOfInterfaces","d":650858,"h":25770454634,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":38655356522,"f":257},"n":"NumberOfIPAddresses","d":650858,"h":34360389226,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":47245291114,"f":257},"n":"NumberOfRoutes","d":650858,"h":42950323818,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":55835225706,"f":257},"n":"OutputPacketRequests","d":650858,"h":51540258410,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":64425160298,"f":257},"n":"OutputPacketRoutingDiscards","d":650858,"h":60130193002,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73015094890,"f":257},"n":"OutputPacketsDiscarded","d":650858,"h":68720127594,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605029482,"f":257},"n":"OutputPacketsWithNoRoute","d":650858,"h":77310062186,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":90194964074,"f":257},"n":"PacketFragmentFailures","d":650858,"h":85899996778,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":98784898666,"f":257},"n":"PacketReassembliesRequired","d":650858,"h":94489931370,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":107374833258,"f":257},"n":"PacketReassemblyFailures","d":650858,"h":103079865962,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":115964767850,"f":257},"n":"PacketReassemblyTimeout","d":650858,"h":111669800554,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":124554702442,"f":257},"n":"PacketsFragmented","d":650858,"h":120259735146,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":133144637034,"f":257},"n":"PacketsReassembled","d":650858,"h":128849669738,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":141734571626,"f":257},"n":"ReceivedPackets","d":650858,"h":137439604330,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":150324506218,"f":257},"n":"ReceivedPacketsDelivered","d":650858,"h":146029538922,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":158914440810,"f":257},"n":"ReceivedPacketsDiscarded","d":650858,"h":154619473514,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":167504375402,"f":257},"n":"ReceivedPacketsForwarded","d":650858,"h":163209408106,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":176094309994,"f":257},"n":"ReceivedPacketsWithAddressErrors","d":650858,"h":171799342698,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":184684244586,"f":257},"n":"ReceivedPacketsWithHeadersErrors","d":650858,"h":180389277290,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":193274179178,"f":257},"n":"ReceivedPacketsWithUnknownProtocol","d":650858,"h":188979211882,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":650858,"h":4295618154,"f":4}],"h":650858}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPGlobalStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPInterfaceProperties", ($self) => class IPInterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 716394;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":519786,"g":{"r":0,"d":0,"h":12885618282,"f":257},"n":"AnycastAddresses","d":716394,"h":8590650986,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":4039154,"g":{"r":0,"d":0,"h":21475552874,"f":257},"n":"DhcpServerAddresses","d":716394,"h":17180585578,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":4039154,"g":{"r":0,"d":0,"h":30065487466,"f":257},"n":"DnsAddresses","d":716394,"h":25770520170,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":38655422058,"f":257},"n":"DnsSuffix","d":716394,"h":34360454762,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":257642,"g":{"r":0,"d":0,"h":47245356650,"f":257},"n":"GatewayAddresses","d":716394,"h":42950389354,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":55835291242,"f":257},"n":"IsDnsEnabled","d":716394,"h":51540323946,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":64425225834,"f":257},"n":"IsDynamicDnsEnabled","d":716394,"h":60130258538,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1109610,"g":{"r":0,"d":0,"h":73015160426,"f":257},"n":"MulticastAddresses","d":716394,"h":68720193130,"f":257},{"p":2420330,"g":{"r":0,"d":0,"h":81605095018,"f":257},"n":"UnicastAddresses","d":716394,"h":77310127722,"f":257},{"p":4039154,"g":{"r":0,"d":0,"h":90195029610,"f":257},"n":"WinsServersAddresses","d":716394,"h":85900062314,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]}],"m":[{"r":847466,"n":"GetIPv4Properties","d":716394,"h":94489996906,"f":257},{"r":978538,"n":"GetIPv6Properties","d":716394,"h":98784964202,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":716394,"h":4295683690,"f":4}],"h":716394}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPInterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPInterfaceStatistics", ($self) => class IPInterfaceStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 781930;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885683818,"f":257},"n":"BytesReceived","d":781930,"h":8590716522,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475618410,"f":257},"n":"BytesSent","d":781930,"h":17180651114,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065553002,"f":257},"n":"IncomingPacketsDiscarded","d":781930,"h":25770585706,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655487594,"f":257},"n":"IncomingPacketsWithErrors","d":781930,"h":34360520298,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245422186,"f":257},"n":"IncomingUnknownProtocolPackets","d":781930,"h":42950454890,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"linux","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":55835356778,"f":257},"n":"NonUnicastPacketsReceived","d":781930,"h":51540389482,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64425291370,"f":257},"n":"NonUnicastPacketsSent","d":781930,"h":60130324074,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"linux","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73015225962,"f":257},"n":"OutgoingPacketsDiscarded","d":781930,"h":68720258666,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605160554,"f":257},"n":"OutgoingPacketsWithErrors","d":781930,"h":77310193258,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90195095146,"f":257},"n":"OutputQueueLength","d":781930,"h":85900127850,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98785029738,"f":257},"n":"UnicastPacketsReceived","d":781930,"h":94490062442,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107374964330,"f":257},"n":"UnicastPacketsSent","d":781930,"h":103079997034,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":781930,"h":4295749226,"f":4}],"h":781930}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPInterfaceStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv4InterfaceProperties", ($self) => class IPv4InterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 847466;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885749354,"f":257},"n":"Index","d":847466,"h":8590782058,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":21475683946,"f":257},"n":"IsAutomaticPrivateAddressingActive","d":847466,"h":17180716650,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":30065618538,"f":257},"n":"IsAutomaticPrivateAddressingEnabled","d":847466,"h":25770651242,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":38655553130,"f":257},"n":"IsDhcpEnabled","d":847466,"h":34360585834,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":47245487722,"f":257},"n":"IsForwardingEnabled","d":847466,"h":42950520426,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":55835422314,"f":257},"n":"Mtu","d":847466,"h":51540455018,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":64425356906,"f":257},"n":"UsesWins","d":847466,"h":60130389610,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":847466,"h":4295814762,"f":4}],"h":847466}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv4InterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv4InterfaceStatistics", ($self) => class IPv4InterfaceStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 913002;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885814890,"f":257},"n":"BytesReceived","d":913002,"h":8590847594,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475749482,"f":257},"n":"BytesSent","d":913002,"h":17180782186,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065684074,"f":257},"n":"IncomingPacketsDiscarded","d":913002,"h":25770716778,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655618666,"f":257},"n":"IncomingPacketsWithErrors","d":913002,"h":34360651370,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245553258,"f":257},"n":"IncomingUnknownProtocolPackets","d":913002,"h":42950585962,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55835487850,"f":257},"n":"NonUnicastPacketsReceived","d":913002,"h":51540520554,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64425422442,"f":257},"n":"NonUnicastPacketsSent","d":913002,"h":60130455146,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73015357034,"f":257},"n":"OutgoingPacketsDiscarded","d":913002,"h":68720389738,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605291626,"f":257},"n":"OutgoingPacketsWithErrors","d":913002,"h":77310324330,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90195226218,"f":257},"n":"OutputQueueLength","d":913002,"h":85900258922,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98785160810,"f":257},"n":"UnicastPacketsReceived","d":913002,"h":94490193514,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107375095402,"f":257},"n":"UnicastPacketsSent","d":913002,"h":103080128106,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":913002,"h":4295880298,"f":4}],"h":913002}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv4InterfaceStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv6InterfaceProperties", ($self) => class IPv6InterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*long */ GetScopeId(/*System.Net.NetworkInformation.ScopeLevel*/ scopeLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 978538;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885880426,"f":257},"n":"Index","d":978538,"h":8590913130,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":21475815018,"f":257},"n":"Mtu","d":978538,"h":17180847722,"f":257}],"m":[{"r":917505,"p":[{"n":"scopeLevel","p":1961578}],"n":"GetScopeId","d":978538,"h":25770782314,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":978538,"h":4295945834,"f":4}],"h":978538}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv6InterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkInterface", ($self) => class NetworkInterface extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string */ get Description()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get IPv6LoopbackInterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReceiveOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get LoopbackInterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.NetworkInterfaceType */ get NetworkInterfaceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.OperationalStatus */ get OperationalStatus()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Speed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get SupportsMulticast()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.NetworkInterface[] */ GetAllNetworkInterfaces()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPInterfaceProperties */ GetIPProperties()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPInterfaceStatistics */ GetIPStatistics()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPv4InterfaceStatistics */ GetIPv4Statistics()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ GetIsNetworkAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.PhysicalAddress */ GetPhysicalAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Supports(/*System.Net.NetworkInformation.NetworkInterfaceComponent*/ networkInterfaceComponent)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1568362;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12886470250,"f":129},"n":"Description","d":1568362,"h":8591502954,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":21476404842,"f":129},"n":"Id","d":1568362,"h":17181437546,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":30066339434,"f":33},"n":"IPv6LoopbackInterfaceIndex","d":1568362,"h":25771372138,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":38656274026,"f":129},"n":"IsReceiveOnly","d":1568362,"h":34361306730,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":47246208618,"f":33},"n":"LoopbackInterfaceIndex","d":1568362,"h":42951241322,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":55836143210,"f":129},"n":"Name","d":1568362,"h":51541175914,"f":129},{"p":1699434,"g":{"r":0,"d":0,"h":64426077802,"f":129},"n":"NetworkInterfaceType","d":1568362,"h":60131110506,"f":129},{"p":1764970,"g":{"r":0,"d":0,"h":73016012394,"f":129},"n":"OperationalStatus","d":1568362,"h":68721045098,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":81605946986,"f":129},"n":"Speed","d":1568362,"h":77310979690,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":90195881578,"f":129},"n":"SupportsMulticast","d":1568362,"h":85900914282,"f":129}],"m":[{"r":0,"n":"GetAllNetworkInterfaces","d":1568362,"h":94490848874,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":716394,"n":"GetIPProperties","d":1568362,"h":98785816170,"f":129},{"r":781930,"n":"GetIPStatistics","d":1568362,"h":103080783466,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":913002,"n":"GetIPv4Statistics","d":1568362,"h":107375750762,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":262145,"n":"GetIsNetworkAvailable","d":1568362,"h":111670718058,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":1830506,"n":"GetPhysicalAddress","d":1568362,"h":115965685354,"f":129},{"r":262145,"p":[{"n":"networkInterfaceComponent","p":1633898}],"n":"Supports","d":1568362,"h":120260652650,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":1568362,"h":4296535658,"f":4}],"h":1568362}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterface`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.TcpConnectionInformation", ($self) => class TcpConnectionInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2092650;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3318258,"g":{"r":0,"d":0,"h":12886994538,"f":257},"n":"LocalEndPoint","d":2092650,"h":8592027242,"f":257},{"p":3318258,"g":{"r":0,"d":0,"h":21476929130,"f":257},"n":"RemoteEndPoint","d":2092650,"h":17181961834,"f":257},{"p":2158186,"g":{"r":0,"d":0,"h":30066863722,"f":257},"n":"State","d":2092650,"h":25771896426,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2092650,"h":4297059946,"f":4}],"h":2092650}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpConnectionInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.TcpStatistics", ($self) => class TcpStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2223722;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887125610,"f":257},"n":"ConnectionsAccepted","d":2223722,"h":8592158314,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21477060202,"f":257},"n":"ConnectionsInitiated","d":2223722,"h":17182092906,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30066994794,"f":257},"n":"CumulativeConnections","d":2223722,"h":25772027498,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38656929386,"f":257},"n":"CurrentConnections","d":2223722,"h":34361962090,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47246863978,"f":257},"n":"ErrorsReceived","d":2223722,"h":42951896682,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55836798570,"f":257},"n":"FailedConnectionAttempts","d":2223722,"h":51541831274,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64426733162,"f":257},"n":"MaximumConnections","d":2223722,"h":60131765866,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73016667754,"f":257},"n":"MaximumTransmissionTimeout","d":2223722,"h":68721700458,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":81606602346,"f":257},"n":"MinimumTransmissionTimeout","d":2223722,"h":77311635050,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90196536938,"f":257},"n":"ResetConnections","d":2223722,"h":85901569642,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98786471530,"f":257},"n":"ResetsSent","d":2223722,"h":94491504234,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107376406122,"f":257},"n":"SegmentsReceived","d":2223722,"h":103081438826,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":115966340714,"f":257},"n":"SegmentsResent","d":2223722,"h":111671373418,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":124556275306,"f":257},"n":"SegmentsSent","d":2223722,"h":120261308010,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2223722,"h":4297191018,"f":4}],"h":2223722}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UdpStatistics", ($self) => class UdpStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2289258;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887191146,"f":257},"n":"DatagramsReceived","d":2289258,"h":8592223850,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21477125738,"f":257},"n":"DatagramsSent","d":2289258,"h":17182158442,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30067060330,"f":257},"n":"IncomingDatagramsDiscarded","d":2289258,"h":25772093034,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38656994922,"f":257},"n":"IncomingDatagramsWithErrors","d":2289258,"h":34362027626,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":47246929514,"f":257},"n":"UdpListeners","d":2289258,"h":42951962218,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2289258,"h":4297256554,"f":4}],"h":2289258}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.UdpStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.MulticastIPAddressInformation", ($self) => class MulticastIPAddressInformation extends $.$snn.System.Net.NetworkInformation.IPAddressInformation
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 1044074;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":454250,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885945962,"f":257},"n":"AddressPreferredLifetime","d":1044074,"h":8590978666,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":21475880554,"f":257},"n":"AddressValidLifetime","d":1044074,"h":17180913258,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":30065815146,"f":257},"n":"DhcpLeaseLifetime","d":1044074,"h":25770847850,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":126570,"g":{"r":0,"d":0,"h":38655749738,"f":257},"n":"DuplicateAddressDetectionState","d":1044074,"h":34360782442,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1896042,"g":{"r":0,"d":0,"h":47245684330,"f":257},"n":"PrefixOrigin","d":1044074,"h":42950717034,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":2027114,"g":{"r":0,"d":0,"h":55835618922,"f":257},"n":"SuffixOrigin","d":1044074,"h":51540651626,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":1044074,"h":4296011370,"f":4}],"h":1044074}; }
            static get $b() { return $.$snn.System.Net.NetworkInformation.IPAddressInformation; }
            static get $fullName() { return `System.Net.NetworkInformation.MulticastIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UnicastIPAddressInformation", ($self) => class UnicastIPAddressInformation extends $.$snn.System.Net.NetworkInformation.IPAddressInformation
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get PrefixLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2354794;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":454250,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887256682,"f":257},"n":"AddressPreferredLifetime","d":2354794,"h":8592289386,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":21477191274,"f":257},"n":"AddressValidLifetime","d":2354794,"h":17182223978,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":30067125866,"f":257},"n":"DhcpLeaseLifetime","d":2354794,"h":25772158570,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":126570,"g":{"r":0,"d":0,"h":38657060458,"f":257},"n":"DuplicateAddressDetectionState","d":2354794,"h":34362093162,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":3056114,"g":{"r":0,"d":0,"h":47246995050,"f":257},"n":"IPv4Mask","d":2354794,"h":42952027754,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":55836929642,"f":129},"n":"PrefixLength","d":2354794,"h":51541962346,"f":129},{"p":1896042,"g":{"r":0,"d":0,"h":64426864234,"f":257},"n":"PrefixOrigin","d":2354794,"h":60131896938,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":2027114,"g":{"r":0,"d":0,"h":73016798826,"f":257},"n":"SuffixOrigin","d":2354794,"h":68721831530,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":2354794,"h":4297322090,"f":4}],"h":2354794}; }
            static get $b() { return $.$snn.System.Net.NetworkInformation.IPAddressInformation; }
            static get $fullName() { return `System.Net.NetworkInformation.UnicastIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkChange", ($self) => class NetworkChange extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.NetworkInformation.NetworkAddressChangedEventHandler?*/static  add_NetworkAddressChanged(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAddressChangedEventHandler?*/static  remove_NetworkAddressChanged(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler?*/static  add_NetworkAvailabilityChanged(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler?*/static  remove_NetworkAvailabilityChanged(value)
            {
            }
            static /*void */ RegisterNetworkChange(/*System.Net.NetworkInformation.NetworkChange*/ nc)
            {
            }
            static $h = 1437290;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"nc","p":1437290}],"n":"RegisterNetworkChange","d":1437290,"h":34361175658,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]},{"t":70909953,"c":12955811841,"a":[{"v":"This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.","t":1310721},{"v":true,"t":262145}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":1437290,"h":4296404586,"f":1,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]},{"t":70909953,"c":12955811841,"a":[{"v":"This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.","t":1310721},{"v":true,"t":262145}]}]}],"e":[{"e":1240682,"m":{"r":65537,"p":[{"n":"value","p":1240682}],"n":"add_NetworkAddressChanged","d":1437290,"h":12886339178,"f":33},"r":{"r":65537,"p":[{"n":"value","p":1240682}],"n":"remove_NetworkAddressChanged","d":1437290,"h":17181306474,"f":33},"n":"NetworkAddressChanged","d":1437290,"h":8591371882,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"e":1306218,"m":{"r":65537,"p":[{"n":"value","p":1306218}],"n":"add_NetworkAvailabilityChanged","d":1437290,"h":25771241066,"f":33},"r":{"r":65537,"p":[{"n":"value","p":1306218}],"n":"remove_NetworkAvailabilityChanged","d":1437290,"h":30066208362,"f":33},"n":"NetworkAvailabilityChanged","d":1437290,"h":21476273770,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]}],"h":1437290}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkChange`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.PhysicalAddress", ($self) => class PhysicalAddress extends $.$spc.System.Object
        {
            /*System.Net.NetworkInformation.PhysicalAddress*/ static None = null;
            $ctor$1(/*byte[]*/ address)
            {
                super.$ctor();
                {
                }
                return this;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.Equals.apply(this, arguments); }
            /*byte[] */ GetAddressBytes()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.GetHashCode.apply(this, arguments); }
            static /*System.Net.NetworkInformation.PhysicalAddress */ Parse(/*System.ReadOnlySpan<char>*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.PhysicalAddress */ Parse$1(/*string?*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.ToString.apply(this, arguments); }
            static /*bool */ TryParse(/*System.ReadOnlySpan<char>*/ address, /*out System.Net.NetworkInformation.PhysicalAddress?*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ TryParse$1(/*string?*/ address, /*out System.Net.NetworkInformation.PhysicalAddress?*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1830506;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":1830506,"h":12886732394,"f":32769},{"r":0,"n":"GetAddressBytes","d":1830506,"h":17181699690,"f":1},{"r":655361,"n":"GetHashCode","d":1830506,"h":21476666986,"f":32769},{"r":1830506,"p":[{"n":"address","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Parse","d":1830506,"h":25771634282,"f":33},{"r":1830506,"p":[{"n":"address","p":1310721}],"n":"Parse","o":"@$1","d":1830506,"h":30066601578,"f":33},{"r":1310721,"n":"ToString","d":1830506,"h":34361568874,"f":32769},{"r":262145,"p":[{"n":"address","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"value","p":1830506,"f":2}],"n":"TryParse","d":1830506,"h":38656536170,"f":33},{"r":262145,"p":[{"n":"address","p":1310721},{"n":"value","p":1830506,"f":2}],"n":"TryParse","o":"@$1","d":1830506,"h":42951503466,"f":33}],"l":[{"t":1830506,"n":"None","d":1830506,"h":4296797802,"f":33}],"c":[{"p":[{"n":"address","p":0}],"n":".ctor","o":"$ctor$1","d":1830506,"h":8591765098,"f":1}],"h":1830506}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.PhysicalAddress`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.GatewayIPAddressInformationCollection", ($self) => class GatewayIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.GatewayIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.GatewayIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.GatewayIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Add(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Contains(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.CopyTo(System.Net.NetworkInformation.GatewayIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Remove(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.GatewayIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 257642;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885159530,"f":129},"n":"Count","d":257642,"h":8590192234,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475094122,"f":129},"n":"IsReadOnly","d":257642,"h":17180126826,"f":129},{"p":192106,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065028714,"f":129},"n":"Item","o":"@$2","d":257642,"h":25770061418,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":192106}],"n":"Add","d":257642,"h":34359996010,"f":129},{"r":65537,"n":"Clear","d":257642,"h":38654963306,"f":129},{"r":262145,"p":[{"n":"address","p":192106}],"n":"Contains","d":257642,"h":42949930602,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":257642,"h":47244897898,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,"n":"GetEnumerator","d":257642,"h":51539865194,"f":129},{"r":262145,"p":[{"n":"address","p":192106}],"n":"Remove","d":257642,"h":55834832490,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":257642,"h":4295224938,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,31653889],"h":257642}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.GatewayIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPAddressInformationCollection", ($self) => class IPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.IPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.IPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Add(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Contains(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.CopyTo(System.Net.NetworkInformation.IPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Remove(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.IPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 519786;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885421674,"f":129},"n":"Count","d":519786,"h":8590454378,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475356266,"f":129},"n":"IsReadOnly","d":519786,"h":17180388970,"f":129},{"p":454250,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065290858,"f":129},"n":"Item","o":"@$2","d":519786,"h":25770323562,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":454250}],"n":"Add","d":519786,"h":34360258154,"f":129},{"r":65537,"n":"Clear","d":519786,"h":38655225450,"f":129},{"r":262145,"p":[{"n":"address","p":454250}],"n":"Contains","d":519786,"h":42950192746,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":519786,"h":47245160042,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,"n":"GetEnumerator","d":519786,"h":51540127338,"f":129},{"r":262145,"p":[{"n":"address","p":454250}],"n":"Remove","d":519786,"h":55835094634,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":519786,"h":4295487082,"f":8}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,31653889],"h":519786}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.IPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.IPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.MulticastIPAddressInformationCollection", ($self) => class MulticastIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.MulticastIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.MulticastIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.MulticastIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Add(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Contains(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.CopyTo(System.Net.NetworkInformation.MulticastIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Remove(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.MulticastIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 1109610;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12886011498,"f":129},"n":"Count","d":1109610,"h":8591044202,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475946090,"f":129},"n":"IsReadOnly","d":1109610,"h":17180978794,"f":129},{"p":1044074,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065880682,"f":129},"n":"Item","o":"@$2","d":1109610,"h":25770913386,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":1044074}],"n":"Add","d":1109610,"h":34360847978,"f":129},{"r":65537,"n":"Clear","d":1109610,"h":38655815274,"f":129},{"r":262145,"p":[{"n":"address","p":1044074}],"n":"Contains","d":1109610,"h":42950782570,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":1109610,"h":47245749866,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,"n":"GetEnumerator","d":1109610,"h":51540717162,"f":129},{"r":262145,"p":[{"n":"address","p":1044074}],"n":"Remove","d":1109610,"h":55835684458,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":1109610,"h":4296076906,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,31653889],"h":1109610}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.MulticastIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UnicastIPAddressInformationCollection", ($self) => class UnicastIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.UnicastIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.UnicastIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Add(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Contains(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.CopyTo(System.Net.NetworkInformation.UnicastIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Remove(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.UnicastIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 2420330;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12887322218,"f":129},"n":"Count","d":2420330,"h":8592354922,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21477256810,"f":129},"n":"IsReadOnly","d":2420330,"h":17182289514,"f":129},{"p":2354794,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30067191402,"f":129},"n":"Item","o":"@$2","d":2420330,"h":25772224106,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":2354794}],"n":"Add","d":2420330,"h":34362158698,"f":129},{"r":65537,"n":"Clear","d":2420330,"h":38657125994,"f":129},{"r":262145,"p":[{"n":"address","p":2354794}],"n":"Contains","d":2420330,"h":42952093290,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":2420330,"h":47247060586,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,"n":"GetEnumerator","d":2420330,"h":51542027882,"f":129},{"r":262145,"p":[{"n":"address","p":2354794}],"n":"Remove","d":2420330,"h":55836995178,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":2420330,"h":4297387626,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,31653889],"h":2420330}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.UnicastIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAddressChangedEventHandler", ($self) => class NetworkAddressChangedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ sender, /*$.$spc.System.EventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 1240682;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":46989313}],"n":"Invoke","d":1240682,"h":8591175274,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":46989313},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":1240682,"h":12886142570,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":1240682,"h":17181109866,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1240682,"h":4296207978,"f":1}],"i":[57212929,113377281],"h":1240682}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAddressChangedEventHandler`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler", ($self) => class NetworkAvailabilityChangedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ sender, /*$.$snn.System.Net.NetworkInformation.NetworkAvailabilityEventArgs*/ e)
            {
                return this.$nativeFunction.call(this.$target, sender, e);
            }
            static $h = 1306218;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":1371754}],"n":"Invoke","d":1306218,"h":8591240810,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"e","p":1371754},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":1306218,"h":12886208106,"f":129},{"r":65537,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":1306218,"h":17181175402,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1306218,"h":4296273514,"f":1}],"i":[57212929,113377281],"h":1306218}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.DuplicateAddressDetectionState", ($self) => class DuplicateAddressDetectionState extends $.$spc.System.Enum
        {
            static Invalid = 0;
            static Tentative = 1;
            static Duplicate = 2;
            static Deprecated = 3;
            static Preferred = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Invalid": 0n,
                    "Tentative": 1n,
                    "Duplicate": 2n,
                    "Deprecated": 3n,
                    "Preferred": 4n
                };
            }
            static $h = 126570;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":126570,"n":"Invalid","d":126570,"h":4295093866,"f":33},{"t":126570,"n":"Tentative","d":126570,"h":8590061162,"f":33},{"t":126570,"n":"Duplicate","d":126570,"h":12885028458,"f":33},{"t":126570,"n":"Deprecated","d":126570,"h":17179995754,"f":33},{"t":126570,"n":"Preferred","d":126570,"h":21474963050,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":126570,"h":25769930346,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":126570}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.DuplicateAddressDetectionState`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetBiosNodeType", ($self) => class NetBiosNodeType extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Broadcast = 1;
            static Peer2Peer = 2;
            static Mixed = 4;
            static Hybrid = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Broadcast": 1n,
                    "Peer2Peer": 2n,
                    "Mixed": 4n,
                    "Hybrid": 8n
                };
            }
            static $h = 1175146;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1175146,"n":"Unknown","d":1175146,"h":4296142442,"f":33},{"t":1175146,"n":"Broadcast","d":1175146,"h":8591109738,"f":33},{"t":1175146,"n":"Peer2Peer","d":1175146,"h":12886077034,"f":33},{"t":1175146,"n":"Mixed","d":1175146,"h":17181044330,"f":33},{"t":1175146,"n":"Hybrid","d":1175146,"h":21476011626,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1175146,"h":25770978922,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1175146}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetBiosNodeType`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetworkInterfaceComponent", ($self) => class NetworkInterfaceComponent extends $.$spc.System.Enum
        {
            static IPv4 = 0;
            static IPv6 = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "IPv4": 0n,
                    "IPv6": 1n
                };
            }
            static $h = 1633898;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1633898,"n":"IPv4","d":1633898,"h":4296601194,"f":33},{"t":1633898,"n":"IPv6","d":1633898,"h":8591568490,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1633898,"h":12886535786,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1633898}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterfaceComponent`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetworkInterfaceType", ($self) => class NetworkInterfaceType extends $.$spc.System.Enum
        {
            static Unknown = 1;
            static Ethernet = 6;
            static TokenRing = 9;
            static Fddi = 15;
            static BasicIsdn = 20;
            static PrimaryIsdn = 21;
            static Ppp = 23;
            static Loopback = 24;
            static Ethernet3Megabit = 26;
            static Slip = 28;
            static Atm = 37;
            static GenericModem = 48;
            static FastEthernetT = 62;
            static Isdn = 63;
            static FastEthernetFx = 69;
            static Wireless80211 = 71;
            static AsymmetricDsl = 94;
            static RateAdaptDsl = 95;
            static SymmetricDsl = 96;
            static VeryHighSpeedDsl = 97;
            static IPOverAtm = 114;
            static GigabitEthernet = 117;
            static Tunnel = 131;
            static MultiRateSymmetricDsl = 143;
            static HighPerformanceSerialBus = 144;
            static Wman = 237;
            static Wwanpp = 243;
            static Wwanpp2 = 244;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 1n,
                    "Ethernet": 6n,
                    "TokenRing": 9n,
                    "Fddi": 15n,
                    "BasicIsdn": 20n,
                    "PrimaryIsdn": 21n,
                    "Ppp": 23n,
                    "Loopback": 24n,
                    "Ethernet3Megabit": 26n,
                    "Slip": 28n,
                    "Atm": 37n,
                    "GenericModem": 48n,
                    "FastEthernetT": 62n,
                    "Isdn": 63n,
                    "FastEthernetFx": 69n,
                    "Wireless80211": 71n,
                    "AsymmetricDsl": 94n,
                    "RateAdaptDsl": 95n,
                    "SymmetricDsl": 96n,
                    "VeryHighSpeedDsl": 97n,
                    "IPOverAtm": 114n,
                    "GigabitEthernet": 117n,
                    "Tunnel": 131n,
                    "MultiRateSymmetricDsl": 143n,
                    "HighPerformanceSerialBus": 144n,
                    "Wman": 237n,
                    "Wwanpp": 243n,
                    "Wwanpp2": 244n
                };
            }
            static $h = 1699434;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1699434,"n":"Unknown","d":1699434,"h":4296666730,"f":33},{"t":1699434,"n":"Ethernet","d":1699434,"h":8591634026,"f":33},{"t":1699434,"n":"TokenRing","d":1699434,"h":12886601322,"f":33},{"t":1699434,"n":"Fddi","d":1699434,"h":17181568618,"f":33},{"t":1699434,"n":"BasicIsdn","d":1699434,"h":21476535914,"f":33},{"t":1699434,"n":"PrimaryIsdn","d":1699434,"h":25771503210,"f":33},{"t":1699434,"n":"Ppp","d":1699434,"h":30066470506,"f":33},{"t":1699434,"n":"Loopback","d":1699434,"h":34361437802,"f":33},{"t":1699434,"n":"Ethernet3Megabit","d":1699434,"h":38656405098,"f":33},{"t":1699434,"n":"Slip","d":1699434,"h":42951372394,"f":33},{"t":1699434,"n":"Atm","d":1699434,"h":47246339690,"f":33},{"t":1699434,"n":"GenericModem","d":1699434,"h":51541306986,"f":33},{"t":1699434,"n":"FastEthernetT","d":1699434,"h":55836274282,"f":33},{"t":1699434,"n":"Isdn","d":1699434,"h":60131241578,"f":33},{"t":1699434,"n":"FastEthernetFx","d":1699434,"h":64426208874,"f":33},{"t":1699434,"n":"Wireless80211","d":1699434,"h":68721176170,"f":33},{"t":1699434,"n":"AsymmetricDsl","d":1699434,"h":73016143466,"f":33},{"t":1699434,"n":"RateAdaptDsl","d":1699434,"h":77311110762,"f":33},{"t":1699434,"n":"SymmetricDsl","d":1699434,"h":81606078058,"f":33},{"t":1699434,"n":"VeryHighSpeedDsl","d":1699434,"h":85901045354,"f":33},{"t":1699434,"n":"IPOverAtm","d":1699434,"h":90196012650,"f":33},{"t":1699434,"n":"GigabitEthernet","d":1699434,"h":94490979946,"f":33},{"t":1699434,"n":"Tunnel","d":1699434,"h":98785947242,"f":33},{"t":1699434,"n":"MultiRateSymmetricDsl","d":1699434,"h":103080914538,"f":33},{"t":1699434,"n":"HighPerformanceSerialBus","d":1699434,"h":107375881834,"f":33},{"t":1699434,"n":"Wman","d":1699434,"h":111670849130,"f":33},{"t":1699434,"n":"Wwanpp","d":1699434,"h":115965816426,"f":33},{"t":1699434,"n":"Wwanpp2","d":1699434,"h":120260783722,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1699434,"h":124555751018,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1699434}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterfaceType`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.OperationalStatus", ($self) => class OperationalStatus extends $.$spc.System.Enum
        {
            static Up = 1;
            static Down = 2;
            static Testing = 3;
            static Unknown = 4;
            static Dormant = 5;
            static NotPresent = 6;
            static LowerLayerDown = 7;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Up": 1n,
                    "Down": 2n,
                    "Testing": 3n,
                    "Unknown": 4n,
                    "Dormant": 5n,
                    "NotPresent": 6n,
                    "LowerLayerDown": 7n
                };
            }
            static $h = 1764970;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1764970,"n":"Up","d":1764970,"h":4296732266,"f":33},{"t":1764970,"n":"Down","d":1764970,"h":8591699562,"f":33},{"t":1764970,"n":"Testing","d":1764970,"h":12886666858,"f":33},{"t":1764970,"n":"Unknown","d":1764970,"h":17181634154,"f":33},{"t":1764970,"n":"Dormant","d":1764970,"h":21476601450,"f":33},{"t":1764970,"n":"NotPresent","d":1764970,"h":25771568746,"f":33},{"t":1764970,"n":"LowerLayerDown","d":1764970,"h":30066536042,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1764970,"h":34361503338,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1764970}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.OperationalStatus`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.PrefixOrigin", ($self) => class PrefixOrigin extends $.$spc.System.Enum
        {
            static Other = 0;
            static Manual = 1;
            static WellKnown = 2;
            static Dhcp = 3;
            static RouterAdvertisement = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Other": 0n,
                    "Manual": 1n,
                    "WellKnown": 2n,
                    "Dhcp": 3n,
                    "RouterAdvertisement": 4n
                };
            }
            static $h = 1896042;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1896042,"n":"Other","d":1896042,"h":4296863338,"f":33},{"t":1896042,"n":"Manual","d":1896042,"h":8591830634,"f":33},{"t":1896042,"n":"WellKnown","d":1896042,"h":12886797930,"f":33},{"t":1896042,"n":"Dhcp","d":1896042,"h":17181765226,"f":33},{"t":1896042,"n":"RouterAdvertisement","d":1896042,"h":21476732522,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1896042,"h":25771699818,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1896042}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.PrefixOrigin`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.ScopeLevel", ($self) => class ScopeLevel extends $.$spc.System.Enum
        {
            static None = 0;
            static Interface = 1;
            static Link = 2;
            static Subnet = 3;
            static Admin = 4;
            static Site = 5;
            static Organization = 8;
            static Global = 14;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Interface": 1n,
                    "Link": 2n,
                    "Subnet": 3n,
                    "Admin": 4n,
                    "Site": 5n,
                    "Organization": 8n,
                    "Global": 14n
                };
            }
            static $h = 1961578;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1961578,"n":"None","d":1961578,"h":4296928874,"f":33},{"t":1961578,"n":"Interface","d":1961578,"h":8591896170,"f":33},{"t":1961578,"n":"Link","d":1961578,"h":12886863466,"f":33},{"t":1961578,"n":"Subnet","d":1961578,"h":17181830762,"f":33},{"t":1961578,"n":"Admin","d":1961578,"h":21476798058,"f":33},{"t":1961578,"n":"Site","d":1961578,"h":25771765354,"f":33},{"t":1961578,"n":"Organization","d":1961578,"h":30066732650,"f":33},{"t":1961578,"n":"Global","d":1961578,"h":34361699946,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1961578,"h":38656667242,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1961578}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.ScopeLevel`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.SuffixOrigin", ($self) => class SuffixOrigin extends $.$spc.System.Enum
        {
            static Other = 0;
            static Manual = 1;
            static WellKnown = 2;
            static OriginDhcp = 3;
            static LinkLayerAddress = 4;
            static Random = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Other": 0n,
                    "Manual": 1n,
                    "WellKnown": 2n,
                    "OriginDhcp": 3n,
                    "LinkLayerAddress": 4n,
                    "Random": 5n
                };
            }
            static $h = 2027114;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2027114,"n":"Other","d":2027114,"h":4296994410,"f":33},{"t":2027114,"n":"Manual","d":2027114,"h":8591961706,"f":33},{"t":2027114,"n":"WellKnown","d":2027114,"h":12886929002,"f":33},{"t":2027114,"n":"OriginDhcp","d":2027114,"h":17181896298,"f":33},{"t":2027114,"n":"LinkLayerAddress","d":2027114,"h":21476863594,"f":33},{"t":2027114,"n":"Random","d":2027114,"h":25771830890,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2027114,"h":30066798186,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2027114}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.SuffixOrigin`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.TcpState", ($self) => class TcpState extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Closed = 1;
            static Listen = 2;
            static SynSent = 3;
            static SynReceived = 4;
            static Established = 5;
            static FinWait1 = 6;
            static FinWait2 = 7;
            static CloseWait = 8;
            static Closing = 9;
            static LastAck = 10;
            static TimeWait = 11;
            static DeleteTcb = 12;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Closed": 1n,
                    "Listen": 2n,
                    "SynSent": 3n,
                    "SynReceived": 4n,
                    "Established": 5n,
                    "FinWait1": 6n,
                    "FinWait2": 7n,
                    "CloseWait": 8n,
                    "Closing": 9n,
                    "LastAck": 10n,
                    "TimeWait": 11n,
                    "DeleteTcb": 12n
                };
            }
            static $h = 2158186;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2158186,"n":"Unknown","d":2158186,"h":4297125482,"f":33},{"t":2158186,"n":"Closed","d":2158186,"h":8592092778,"f":33},{"t":2158186,"n":"Listen","d":2158186,"h":12887060074,"f":33},{"t":2158186,"n":"SynSent","d":2158186,"h":17182027370,"f":33},{"t":2158186,"n":"SynReceived","d":2158186,"h":21476994666,"f":33},{"t":2158186,"n":"Established","d":2158186,"h":25771961962,"f":33},{"t":2158186,"n":"FinWait1","d":2158186,"h":30066929258,"f":33},{"t":2158186,"n":"FinWait2","d":2158186,"h":34361896554,"f":33},{"t":2158186,"n":"CloseWait","d":2158186,"h":38656863850,"f":33},{"t":2158186,"n":"Closing","d":2158186,"h":42951831146,"f":33},{"t":2158186,"n":"LastAck","d":2158186,"h":47246798442,"f":33},{"t":2158186,"n":"TimeWait","d":2158186,"h":51541765738,"f":33},{"t":2158186,"n":"DeleteTcb","d":2158186,"h":55836733034,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2158186,"h":60131700330,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":2158186}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpState`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAvailabilityEventArgs", ($self) => class NetworkAvailabilityEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ get IsAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1371754;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886273642,"f":1},"n":"IsAvailable","d":1371754,"h":8591306346,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1371754,"h":4296339050,"f":8}],"h":1371754}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAvailabilityEventArgs`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkInformationException", ($self) => class NetworkInformationException extends $.$spc.System.ComponentModel.Win32Exception
        {
            $ctor$20()
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            $ctor$21(/*int*/ errorCode)
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            $ctor$22(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            /*int */ get ErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1502826;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":33357825,"h":1502826}; }
            static get $b() { return $.$spc.System.ComponentModel.Win32Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInformationException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets"))