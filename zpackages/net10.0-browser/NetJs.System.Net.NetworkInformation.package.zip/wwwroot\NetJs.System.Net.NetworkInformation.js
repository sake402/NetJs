
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $ssc, $sris, $scsl, $sl, $snp, $sspw, $sdd, $snnr, $sns) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.NetworkInformation", 
    {"h":33644,"f":"System.Net.NetworkInformation","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.NetworkInformation","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.NetworkInformation","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snn.System.Net.NetworkInformation.GatewayIPAddressInformation", ($self) => class GatewayIPAddressInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 164716;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3055579,"g":{"r":0,"d":0,"h":12885066604,"f":257},"n":"Address","d":164716,"h":8590099308,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":164716,"h":4295132012,"f":4}],"h":164716}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.GatewayIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IcmpV4Statistics", ($self) => class IcmpV4Statistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 295788;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885197676,"f":257},"n":"AddressMaskRepliesReceived","d":295788,"h":8590230380,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475132268,"f":257},"n":"AddressMaskRepliesSent","d":295788,"h":17180164972,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065066860,"f":257},"n":"AddressMaskRequestsReceived","d":295788,"h":25770099564,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655001452,"f":257},"n":"AddressMaskRequestsSent","d":295788,"h":34360034156,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47244936044,"f":257},"n":"DestinationUnreachableMessagesReceived","d":295788,"h":42949968748,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55834870636,"f":257},"n":"DestinationUnreachableMessagesSent","d":295788,"h":51539903340,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64424805228,"f":257},"n":"EchoRepliesReceived","d":295788,"h":60129837932,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73014739820,"f":257},"n":"EchoRepliesSent","d":295788,"h":68719772524,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":81604674412,"f":257},"n":"EchoRequestsReceived","d":295788,"h":77309707116,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90194609004,"f":257},"n":"EchoRequestsSent","d":295788,"h":85899641708,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98784543596,"f":257},"n":"ErrorsReceived","d":295788,"h":94489576300,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":107374478188,"f":257},"n":"ErrorsSent","d":295788,"h":103079510892,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":115964412780,"f":257},"n":"MessagesReceived","d":295788,"h":111669445484,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":124554347372,"f":257},"n":"MessagesSent","d":295788,"h":120259380076,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":133144281964,"f":257},"n":"ParameterProblemsReceived","d":295788,"h":128849314668,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":141734216556,"f":257},"n":"ParameterProblemsSent","d":295788,"h":137439249260,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":150324151148,"f":257},"n":"RedirectsReceived","d":295788,"h":146029183852,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":158914085740,"f":257},"n":"RedirectsSent","d":295788,"h":154619118444,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":167504020332,"f":257},"n":"SourceQuenchesReceived","d":295788,"h":163209053036,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":176093954924,"f":257},"n":"SourceQuenchesSent","d":295788,"h":171798987628,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":184683889516,"f":257},"n":"TimeExceededMessagesReceived","d":295788,"h":180388922220,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":193273824108,"f":257},"n":"TimeExceededMessagesSent","d":295788,"h":188978856812,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":201863758700,"f":257},"n":"TimestampRepliesReceived","d":295788,"h":197568791404,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":210453693292,"f":257},"n":"TimestampRepliesSent","d":295788,"h":206158725996,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":219043627884,"f":257},"n":"TimestampRequestsReceived","d":295788,"h":214748660588,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":227633562476,"f":257},"n":"TimestampRequestsSent","d":295788,"h":223338595180,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":295788,"h":4295263084,"f":4}],"h":295788}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IcmpV4Statistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IcmpV6Statistics", ($self) => class IcmpV6Statistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 361324;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885263212,"f":257},"n":"DestinationUnreachableMessagesReceived","d":361324,"h":8590295916,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475197804,"f":257},"n":"DestinationUnreachableMessagesSent","d":361324,"h":17180230508,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065132396,"f":257},"n":"EchoRepliesReceived","d":361324,"h":25770165100,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655066988,"f":257},"n":"EchoRepliesSent","d":361324,"h":34360099692,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245001580,"f":257},"n":"EchoRequestsReceived","d":361324,"h":42950034284,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55834936172,"f":257},"n":"EchoRequestsSent","d":361324,"h":51539968876,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64424870764,"f":257},"n":"ErrorsReceived","d":361324,"h":60129903468,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73014805356,"f":257},"n":"ErrorsSent","d":361324,"h":68719838060,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81604739948,"f":257},"n":"MembershipQueriesReceived","d":361324,"h":77309772652,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90194674540,"f":257},"n":"MembershipQueriesSent","d":361324,"h":85899707244,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98784609132,"f":257},"n":"MembershipReductionsReceived","d":361324,"h":94489641836,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107374543724,"f":257},"n":"MembershipReductionsSent","d":361324,"h":103079576428,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":115964478316,"f":257},"n":"MembershipReportsReceived","d":361324,"h":111669511020,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":124554412908,"f":257},"n":"MembershipReportsSent","d":361324,"h":120259445612,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":133144347500,"f":257},"n":"MessagesReceived","d":361324,"h":128849380204,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":141734282092,"f":257},"n":"MessagesSent","d":361324,"h":137439314796,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":150324216684,"f":257},"n":"NeighborAdvertisementsReceived","d":361324,"h":146029249388,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":158914151276,"f":257},"n":"NeighborAdvertisementsSent","d":361324,"h":154619183980,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":167504085868,"f":257},"n":"NeighborSolicitsReceived","d":361324,"h":163209118572,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":176094020460,"f":257},"n":"NeighborSolicitsSent","d":361324,"h":171799053164,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":184683955052,"f":257},"n":"PacketTooBigMessagesReceived","d":361324,"h":180388987756,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":193273889644,"f":257},"n":"PacketTooBigMessagesSent","d":361324,"h":188978922348,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":201863824236,"f":257},"n":"ParameterProblemsReceived","d":361324,"h":197568856940,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":210453758828,"f":257},"n":"ParameterProblemsSent","d":361324,"h":206158791532,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":219043693420,"f":257},"n":"RedirectsReceived","d":361324,"h":214748726124,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":227633628012,"f":257},"n":"RedirectsSent","d":361324,"h":223338660716,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":236223562604,"f":257},"n":"RouterAdvertisementsReceived","d":361324,"h":231928595308,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":244813497196,"f":257},"n":"RouterAdvertisementsSent","d":361324,"h":240518529900,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":253403431788,"f":257},"n":"RouterSolicitsReceived","d":361324,"h":249108464492,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":261993366380,"f":257},"n":"RouterSolicitsSent","d":361324,"h":257698399084,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":270583300972,"f":257},"n":"TimeExceededMessagesReceived","d":361324,"h":266288333676,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":279173235564,"f":257},"n":"TimeExceededMessagesSent","d":361324,"h":274878268268,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":361324,"h":4295328620,"f":4}],"h":361324}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IcmpV6Statistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPAddressInformation", ($self) => class IPAddressInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 426860;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3055579,"g":{"r":0,"d":0,"h":12885328748,"f":257},"n":"Address","d":426860,"h":8590361452,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":21475263340,"f":257},"n":"IsDnsEligible","d":426860,"h":17180296044,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":30065197932,"f":257},"n":"IsTransient","d":426860,"h":25770230636,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":426860,"h":4295394156,"f":4}],"h":426860}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPGlobalProperties", ($self) => class IPGlobalProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.IAsyncResult */ BeginGetUnicastAddresses(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformationCollection */ EndGetUnicastAddresses(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.IPGlobalProperties */ GetIPGlobalProperties()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformationCollection */ GetUnicastAddresses()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.NetworkInformation.UnicastIPAddressInformationCollection> */ GetUnicastAddressesAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 557932;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885459820,"f":257},"n":"DhcpScopeName","d":557932,"h":8590492524,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":21475394412,"f":257},"n":"DomainName","d":557932,"h":17180427116,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":30065329004,"f":257},"n":"HostName","d":557932,"h":25770361708,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":38655263596,"f":257},"n":"IsWinsProxy","d":557932,"h":34360296300,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1147756,"g":{"r":0,"d":0,"h":47245198188,"f":257},"n":"NodeType","d":557932,"h":42950230892,"f":257}],"m":[{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginGetUnicastAddresses","d":557932,"h":51540165484,"f":129},{"r":2392940,"p":[{"n":"asyncResult","p":56950785}],"n":"EndGetUnicastAddresses","d":557932,"h":55835132780,"f":129},{"r":0,"n":"GetActiveTcpConnections","d":557932,"h":60130100076,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":0,"n":"GetActiveTcpListeners","d":557932,"h":64425067372,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":0,"n":"GetActiveUdpListeners","d":557932,"h":68720034668,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":295788,"n":"GetIcmpV4Statistics","d":557932,"h":73015001964,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":361324,"n":"GetIcmpV6Statistics","d":557932,"h":77309969260,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":557932,"n":"GetIPGlobalProperties","d":557932,"h":81604936556,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":623468,"n":"GetIPv4GlobalStatistics","d":557932,"h":85899903852,"f":257},{"r":623468,"n":"GetIPv6GlobalStatistics","d":557932,"h":90194871148,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"r":2196332,"n":"GetTcpIPv4Statistics","d":557932,"h":94489838444,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2196332,"n":"GetTcpIPv6Statistics","d":557932,"h":98784805740,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2261868,"n":"GetUdpIPv4Statistics","d":557932,"h":103079773036,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2261868,"n":"GetUdpIPv6Statistics","d":557932,"h":107374740332,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2392940,"n":"GetUnicastAddresses","d":557932,"h":111669707628,"f":129},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformationCollection).$h,"n":"GetUnicastAddressesAsync","d":557932,"h":115964674924,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":557932,"h":4295525228,"f":4}],"h":557932}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPGlobalProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPGlobalStatistics", ($self) => class IPGlobalStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 623468;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885525356,"f":257},"n":"DefaultTtl","d":623468,"h":8590558060,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":21475459948,"f":257},"n":"ForwardingEnabled","d":623468,"h":17180492652,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":30065394540,"f":257},"n":"NumberOfInterfaces","d":623468,"h":25770427244,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":38655329132,"f":257},"n":"NumberOfIPAddresses","d":623468,"h":34360361836,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":47245263724,"f":257},"n":"NumberOfRoutes","d":623468,"h":42950296428,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":55835198316,"f":257},"n":"OutputPacketRequests","d":623468,"h":51540231020,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":64425132908,"f":257},"n":"OutputPacketRoutingDiscards","d":623468,"h":60130165612,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73015067500,"f":257},"n":"OutputPacketsDiscarded","d":623468,"h":68720100204,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605002092,"f":257},"n":"OutputPacketsWithNoRoute","d":623468,"h":77310034796,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":90194936684,"f":257},"n":"PacketFragmentFailures","d":623468,"h":85899969388,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":98784871276,"f":257},"n":"PacketReassembliesRequired","d":623468,"h":94489903980,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":107374805868,"f":257},"n":"PacketReassemblyFailures","d":623468,"h":103079838572,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":115964740460,"f":257},"n":"PacketReassemblyTimeout","d":623468,"h":111669773164,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":124554675052,"f":257},"n":"PacketsFragmented","d":623468,"h":120259707756,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":133144609644,"f":257},"n":"PacketsReassembled","d":623468,"h":128849642348,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":141734544236,"f":257},"n":"ReceivedPackets","d":623468,"h":137439576940,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":150324478828,"f":257},"n":"ReceivedPacketsDelivered","d":623468,"h":146029511532,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":158914413420,"f":257},"n":"ReceivedPacketsDiscarded","d":623468,"h":154619446124,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":167504348012,"f":257},"n":"ReceivedPacketsForwarded","d":623468,"h":163209380716,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":176094282604,"f":257},"n":"ReceivedPacketsWithAddressErrors","d":623468,"h":171799315308,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":184684217196,"f":257},"n":"ReceivedPacketsWithHeadersErrors","d":623468,"h":180389249900,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":193274151788,"f":257},"n":"ReceivedPacketsWithUnknownProtocol","d":623468,"h":188979184492,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":623468,"h":4295590764,"f":4}],"h":623468}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPGlobalStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPInterfaceProperties", ($self) => class IPInterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 689004;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":492396,"g":{"r":0,"d":0,"h":12885590892,"f":257},"n":"AnycastAddresses","d":689004,"h":8590623596,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":4038619,"g":{"r":0,"d":0,"h":21475525484,"f":257},"n":"DhcpServerAddresses","d":689004,"h":17180558188,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":4038619,"g":{"r":0,"d":0,"h":30065460076,"f":257},"n":"DnsAddresses","d":689004,"h":25770492780,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":38655394668,"f":257},"n":"DnsSuffix","d":689004,"h":34360427372,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":230252,"g":{"r":0,"d":0,"h":47245329260,"f":257},"n":"GatewayAddresses","d":689004,"h":42950361964,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":55835263852,"f":257},"n":"IsDnsEnabled","d":689004,"h":51540296556,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":64425198444,"f":257},"n":"IsDynamicDnsEnabled","d":689004,"h":60130231148,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1082220,"g":{"r":0,"d":0,"h":73015133036,"f":257},"n":"MulticastAddresses","d":689004,"h":68720165740,"f":257},{"p":2392940,"g":{"r":0,"d":0,"h":81605067628,"f":257},"n":"UnicastAddresses","d":689004,"h":77310100332,"f":257},{"p":4038619,"g":{"r":0,"d":0,"h":90195002220,"f":257},"n":"WinsServersAddresses","d":689004,"h":85900034924,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]}],"m":[{"r":820076,"n":"GetIPv4Properties","d":689004,"h":94489969516,"f":257},{"r":951148,"n":"GetIPv6Properties","d":689004,"h":98784936812,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":689004,"h":4295656300,"f":4}],"h":689004}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPInterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPInterfaceStatistics", ($self) => class IPInterfaceStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 754540;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885656428,"f":257},"n":"BytesReceived","d":754540,"h":8590689132,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475591020,"f":257},"n":"BytesSent","d":754540,"h":17180623724,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065525612,"f":257},"n":"IncomingPacketsDiscarded","d":754540,"h":25770558316,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655460204,"f":257},"n":"IncomingPacketsWithErrors","d":754540,"h":34360492908,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245394796,"f":257},"n":"IncomingUnknownProtocolPackets","d":754540,"h":42950427500,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"linux","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":55835329388,"f":257},"n":"NonUnicastPacketsReceived","d":754540,"h":51540362092,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64425263980,"f":257},"n":"NonUnicastPacketsSent","d":754540,"h":60130296684,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"linux","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73015198572,"f":257},"n":"OutgoingPacketsDiscarded","d":754540,"h":68720231276,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605133164,"f":257},"n":"OutgoingPacketsWithErrors","d":754540,"h":77310165868,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90195067756,"f":257},"n":"OutputQueueLength","d":754540,"h":85900100460,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98785002348,"f":257},"n":"UnicastPacketsReceived","d":754540,"h":94490035052,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107374936940,"f":257},"n":"UnicastPacketsSent","d":754540,"h":103079969644,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":754540,"h":4295721836,"f":4}],"h":754540}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPInterfaceStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv4InterfaceProperties", ($self) => class IPv4InterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 820076;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885721964,"f":257},"n":"Index","d":820076,"h":8590754668,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":21475656556,"f":257},"n":"IsAutomaticPrivateAddressingActive","d":820076,"h":17180689260,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":30065591148,"f":257},"n":"IsAutomaticPrivateAddressingEnabled","d":820076,"h":25770623852,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":38655525740,"f":257},"n":"IsDhcpEnabled","d":820076,"h":34360558444,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":47245460332,"f":257},"n":"IsForwardingEnabled","d":820076,"h":42950493036,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":55835394924,"f":257},"n":"Mtu","d":820076,"h":51540427628,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":64425329516,"f":257},"n":"UsesWins","d":820076,"h":60130362220,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":820076,"h":4295787372,"f":4}],"h":820076}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv4InterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv4InterfaceStatistics", ($self) => class IPv4InterfaceStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 885612;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885787500,"f":257},"n":"BytesReceived","d":885612,"h":8590820204,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475722092,"f":257},"n":"BytesSent","d":885612,"h":17180754796,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065656684,"f":257},"n":"IncomingPacketsDiscarded","d":885612,"h":25770689388,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655591276,"f":257},"n":"IncomingPacketsWithErrors","d":885612,"h":34360623980,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245525868,"f":257},"n":"IncomingUnknownProtocolPackets","d":885612,"h":42950558572,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55835460460,"f":257},"n":"NonUnicastPacketsReceived","d":885612,"h":51540493164,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64425395052,"f":257},"n":"NonUnicastPacketsSent","d":885612,"h":60130427756,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73015329644,"f":257},"n":"OutgoingPacketsDiscarded","d":885612,"h":68720362348,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605264236,"f":257},"n":"OutgoingPacketsWithErrors","d":885612,"h":77310296940,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90195198828,"f":257},"n":"OutputQueueLength","d":885612,"h":85900231532,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98785133420,"f":257},"n":"UnicastPacketsReceived","d":885612,"h":94490166124,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107375068012,"f":257},"n":"UnicastPacketsSent","d":885612,"h":103080100716,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":885612,"h":4295852908,"f":4}],"h":885612}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv4InterfaceStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv6InterfaceProperties", ($self) => class IPv6InterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*long */ GetScopeId(/*System.Net.NetworkInformation.ScopeLevel*/ scopeLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 951148;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885853036,"f":257},"n":"Index","d":951148,"h":8590885740,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":21475787628,"f":257},"n":"Mtu","d":951148,"h":17180820332,"f":257}],"m":[{"r":917505,"p":[{"n":"scopeLevel","p":1934188}],"n":"GetScopeId","d":951148,"h":25770754924,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":951148,"h":4295918444,"f":4}],"h":951148}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv6InterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkInterface", ($self) => class NetworkInterface extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string */ get Description()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get IPv6LoopbackInterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReceiveOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get LoopbackInterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.NetworkInterfaceType */ get NetworkInterfaceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.OperationalStatus */ get OperationalStatus()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Speed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get SupportsMulticast()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.NetworkInterface[] */ GetAllNetworkInterfaces()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPInterfaceProperties */ GetIPProperties()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPInterfaceStatistics */ GetIPStatistics()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPv4InterfaceStatistics */ GetIPv4Statistics()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ GetIsNetworkAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.PhysicalAddress */ GetPhysicalAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Supports(/*System.Net.NetworkInformation.NetworkInterfaceComponent*/ networkInterfaceComponent)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1540972;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12886442860,"f":129},"n":"Description","d":1540972,"h":8591475564,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":21476377452,"f":129},"n":"Id","d":1540972,"h":17181410156,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":30066312044,"f":33},"n":"IPv6LoopbackInterfaceIndex","d":1540972,"h":25771344748,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":38656246636,"f":129},"n":"IsReceiveOnly","d":1540972,"h":34361279340,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":47246181228,"f":33},"n":"LoopbackInterfaceIndex","d":1540972,"h":42951213932,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":55836115820,"f":129},"n":"Name","d":1540972,"h":51541148524,"f":129},{"p":1672044,"g":{"r":0,"d":0,"h":64426050412,"f":129},"n":"NetworkInterfaceType","d":1540972,"h":60131083116,"f":129},{"p":1737580,"g":{"r":0,"d":0,"h":73015985004,"f":129},"n":"OperationalStatus","d":1540972,"h":68721017708,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":81605919596,"f":129},"n":"Speed","d":1540972,"h":77310952300,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":90195854188,"f":129},"n":"SupportsMulticast","d":1540972,"h":85900886892,"f":129}],"m":[{"r":0,"n":"GetAllNetworkInterfaces","d":1540972,"h":94490821484,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":689004,"n":"GetIPProperties","d":1540972,"h":98785788780,"f":129},{"r":754540,"n":"GetIPStatistics","d":1540972,"h":103080756076,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":885612,"n":"GetIPv4Statistics","d":1540972,"h":107375723372,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":262145,"n":"GetIsNetworkAvailable","d":1540972,"h":111670690668,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":1803116,"n":"GetPhysicalAddress","d":1540972,"h":115965657964,"f":129},{"r":262145,"p":[{"n":"networkInterfaceComponent","p":1606508}],"n":"Supports","d":1540972,"h":120260625260,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":1540972,"h":4296508268,"f":4}],"h":1540972}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterface`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.TcpConnectionInformation", ($self) => class TcpConnectionInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2065260;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3317723,"g":{"r":0,"d":0,"h":12886967148,"f":257},"n":"LocalEndPoint","d":2065260,"h":8591999852,"f":257},{"p":3317723,"g":{"r":0,"d":0,"h":21476901740,"f":257},"n":"RemoteEndPoint","d":2065260,"h":17181934444,"f":257},{"p":2130796,"g":{"r":0,"d":0,"h":30066836332,"f":257},"n":"State","d":2065260,"h":25771869036,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2065260,"h":4297032556,"f":4}],"h":2065260}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpConnectionInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.TcpStatistics", ($self) => class TcpStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2196332;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887098220,"f":257},"n":"ConnectionsAccepted","d":2196332,"h":8592130924,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21477032812,"f":257},"n":"ConnectionsInitiated","d":2196332,"h":17182065516,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30066967404,"f":257},"n":"CumulativeConnections","d":2196332,"h":25772000108,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38656901996,"f":257},"n":"CurrentConnections","d":2196332,"h":34361934700,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47246836588,"f":257},"n":"ErrorsReceived","d":2196332,"h":42951869292,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55836771180,"f":257},"n":"FailedConnectionAttempts","d":2196332,"h":51541803884,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64426705772,"f":257},"n":"MaximumConnections","d":2196332,"h":60131738476,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73016640364,"f":257},"n":"MaximumTransmissionTimeout","d":2196332,"h":68721673068,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":81606574956,"f":257},"n":"MinimumTransmissionTimeout","d":2196332,"h":77311607660,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90196509548,"f":257},"n":"ResetConnections","d":2196332,"h":85901542252,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98786444140,"f":257},"n":"ResetsSent","d":2196332,"h":94491476844,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107376378732,"f":257},"n":"SegmentsReceived","d":2196332,"h":103081411436,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":115966313324,"f":257},"n":"SegmentsResent","d":2196332,"h":111671346028,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":124556247916,"f":257},"n":"SegmentsSent","d":2196332,"h":120261280620,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2196332,"h":4297163628,"f":4}],"h":2196332}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UdpStatistics", ($self) => class UdpStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2261868;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887163756,"f":257},"n":"DatagramsReceived","d":2261868,"h":8592196460,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21477098348,"f":257},"n":"DatagramsSent","d":2261868,"h":17182131052,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30067032940,"f":257},"n":"IncomingDatagramsDiscarded","d":2261868,"h":25772065644,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38656967532,"f":257},"n":"IncomingDatagramsWithErrors","d":2261868,"h":34362000236,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":47246902124,"f":257},"n":"UdpListeners","d":2261868,"h":42951934828,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2261868,"h":4297229164,"f":4}],"h":2261868}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.UdpStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.MulticastIPAddressInformation", ($self) => class MulticastIPAddressInformation extends $.$snn.System.Net.NetworkInformation.IPAddressInformation
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 1016684;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":426860,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885918572,"f":257},"n":"AddressPreferredLifetime","d":1016684,"h":8590951276,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":21475853164,"f":257},"n":"AddressValidLifetime","d":1016684,"h":17180885868,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":30065787756,"f":257},"n":"DhcpLeaseLifetime","d":1016684,"h":25770820460,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":99180,"g":{"r":0,"d":0,"h":38655722348,"f":257},"n":"DuplicateAddressDetectionState","d":1016684,"h":34360755052,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1868652,"g":{"r":0,"d":0,"h":47245656940,"f":257},"n":"PrefixOrigin","d":1016684,"h":42950689644,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1999724,"g":{"r":0,"d":0,"h":55835591532,"f":257},"n":"SuffixOrigin","d":1016684,"h":51540624236,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":1016684,"h":4295983980,"f":4}],"h":1016684}; }
            static get $b() { return $.$snn.System.Net.NetworkInformation.IPAddressInformation; }
            static get $fullName() { return `System.Net.NetworkInformation.MulticastIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UnicastIPAddressInformation", ($self) => class UnicastIPAddressInformation extends $.$snn.System.Net.NetworkInformation.IPAddressInformation
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get PrefixLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2327404;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":426860,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887229292,"f":257},"n":"AddressPreferredLifetime","d":2327404,"h":8592261996,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":21477163884,"f":257},"n":"AddressValidLifetime","d":2327404,"h":17182196588,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":30067098476,"f":257},"n":"DhcpLeaseLifetime","d":2327404,"h":25772131180,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":99180,"g":{"r":0,"d":0,"h":38657033068,"f":257},"n":"DuplicateAddressDetectionState","d":2327404,"h":34362065772,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":3055579,"g":{"r":0,"d":0,"h":47246967660,"f":257},"n":"IPv4Mask","d":2327404,"h":42952000364,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":55836902252,"f":129},"n":"PrefixLength","d":2327404,"h":51541934956,"f":129},{"p":1868652,"g":{"r":0,"d":0,"h":64426836844,"f":257},"n":"PrefixOrigin","d":2327404,"h":60131869548,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1999724,"g":{"r":0,"d":0,"h":73016771436,"f":257},"n":"SuffixOrigin","d":2327404,"h":68721804140,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":2327404,"h":4297294700,"f":4}],"h":2327404}; }
            static get $b() { return $.$snn.System.Net.NetworkInformation.IPAddressInformation; }
            static get $fullName() { return `System.Net.NetworkInformation.UnicastIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkChange", ($self) => class NetworkChange extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.NetworkInformation.NetworkAddressChangedEventHandler?*/static  NetworkAddressChanged$add(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAddressChangedEventHandler?*/static  NetworkAddressChanged$remove(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler?*/static  NetworkAvailabilityChanged$add(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler?*/static  NetworkAvailabilityChanged$remove(value)
            {
            }
            static /*void */ RegisterNetworkChange(/*System.Net.NetworkInformation.NetworkChange*/ nc)
            {
            }
            static $h = 1409900;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"nc","p":1409900}],"n":"RegisterNetworkChange","d":1409900,"h":34361148268,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":12955811841,"a":[{"v":"This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.","t":1310721},{"v":true,"t":262145}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":1409900,"h":4296377196,"f":1,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":12955811841,"a":[{"v":"This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.","t":1310721},{"v":true,"t":262145}]}]}],"e":[{"e":1213292,"m":{"r":65537,"p":[{"n":"value","p":1213292}],"n":"add_NetworkAddressChanged","d":1409900,"h":12886311788,"f":33},"r":{"r":65537,"p":[{"n":"value","p":1213292}],"n":"remove_NetworkAddressChanged","d":1409900,"h":17181279084,"f":33},"n":"NetworkAddressChanged","d":1409900,"h":8591344492,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"e":1278828,"m":{"r":65537,"p":[{"n":"value","p":1278828}],"n":"add_NetworkAvailabilityChanged","d":1409900,"h":25771213676,"f":33},"r":{"r":65537,"p":[{"n":"value","p":1278828}],"n":"remove_NetworkAvailabilityChanged","d":1409900,"h":30066180972,"f":33},"n":"NetworkAvailabilityChanged","d":1409900,"h":21476246380,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]}],"h":1409900}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkChange`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.PhysicalAddress", ($self) => class PhysicalAddress extends $.$spc.System.Object
        {
            /*System.Net.NetworkInformation.PhysicalAddress*/ static None = null;
            $ctor$1(/*byte[]*/ address)
            {
                super.$ctor();
                {
                }
                return this;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.Equals.apply(this, arguments); }
            /*byte[] */ GetAddressBytes()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.GetHashCode.apply(this, arguments); }
            static /*System.Net.NetworkInformation.PhysicalAddress */ Parse(/*System.ReadOnlySpan<char>*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.PhysicalAddress */ Parse$1(/*string?*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.ToString.apply(this, arguments); }
            static /*bool */ TryParse(/*System.ReadOnlySpan<char>*/ address, /*out System.Net.NetworkInformation.PhysicalAddress?*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ TryParse$1(/*string?*/ address, /*out System.Net.NetworkInformation.PhysicalAddress?*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1803116;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":1803116,"h":12886705004,"f":32769},{"r":0,"n":"GetAddressBytes","d":1803116,"h":17181672300,"f":1},{"r":655361,"n":"GetHashCode","d":1803116,"h":21476639596,"f":32769},{"r":1803116,"p":[{"n":"address","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Parse","d":1803116,"h":25771606892,"f":33},{"r":1803116,"p":[{"n":"address","p":1310721}],"n":"Parse","o":"@$1","d":1803116,"h":30066574188,"f":33},{"r":1310721,"n":"ToString","d":1803116,"h":34361541484,"f":32769},{"r":262145,"p":[{"n":"address","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"value","p":1803116,"f":2}],"n":"TryParse","d":1803116,"h":38656508780,"f":33},{"r":262145,"p":[{"n":"address","p":1310721},{"n":"value","p":1803116,"f":2}],"n":"TryParse","o":"@$1","d":1803116,"h":42951476076,"f":33}],"l":[{"t":1803116,"n":"None","d":1803116,"h":4296770412,"f":33}],"c":[{"p":[{"n":"address","p":0}],"n":".ctor","o":"$ctor$1","d":1803116,"h":8591737708,"f":1}],"h":1803116}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.PhysicalAddress`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.GatewayIPAddressInformationCollection", ($self) => class GatewayIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.GatewayIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.GatewayIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.GatewayIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Add(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Contains(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.CopyTo(System.Net.NetworkInformation.GatewayIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Remove(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.GatewayIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 230252;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885132140,"f":129},"n":"Count","d":230252,"h":8590164844,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475066732,"f":129},"n":"IsReadOnly","d":230252,"h":17180099436,"f":129},{"p":164716,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065001324,"f":129},"n":"Item","o":"@$2","d":230252,"h":25770034028,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":164716}],"n":"Add","d":230252,"h":34359968620,"f":129},{"r":65537,"n":"Clear","d":230252,"h":38654935916,"f":129},{"r":262145,"p":[{"n":"address","p":164716}],"n":"Contains","d":230252,"h":42949903212,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":230252,"h":47244870508,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,"n":"GetEnumerator","d":230252,"h":51539837804,"f":129},{"r":262145,"p":[{"n":"address","p":164716}],"n":"Remove","d":230252,"h":55834805100,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":230252,"h":4295197548,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,31588353],"h":230252}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.GatewayIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPAddressInformationCollection", ($self) => class IPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.IPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.IPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Add(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Contains(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.CopyTo(System.Net.NetworkInformation.IPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Remove(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.IPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 492396;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885394284,"f":129},"n":"Count","d":492396,"h":8590426988,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475328876,"f":129},"n":"IsReadOnly","d":492396,"h":17180361580,"f":129},{"p":426860,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065263468,"f":129},"n":"Item","o":"@$2","d":492396,"h":25770296172,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":426860}],"n":"Add","d":492396,"h":34360230764,"f":129},{"r":65537,"n":"Clear","d":492396,"h":38655198060,"f":129},{"r":262145,"p":[{"n":"address","p":426860}],"n":"Contains","d":492396,"h":42950165356,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":492396,"h":47245132652,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,"n":"GetEnumerator","d":492396,"h":51540099948,"f":129},{"r":262145,"p":[{"n":"address","p":426860}],"n":"Remove","d":492396,"h":55835067244,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":492396,"h":4295459692,"f":8}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,31588353],"h":492396}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.IPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.IPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.MulticastIPAddressInformationCollection", ($self) => class MulticastIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.MulticastIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.MulticastIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.MulticastIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Add(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Contains(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.CopyTo(System.Net.NetworkInformation.MulticastIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Remove(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.MulticastIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 1082220;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885984108,"f":129},"n":"Count","d":1082220,"h":8591016812,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475918700,"f":129},"n":"IsReadOnly","d":1082220,"h":17180951404,"f":129},{"p":1016684,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065853292,"f":129},"n":"Item","o":"@$2","d":1082220,"h":25770885996,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":1016684}],"n":"Add","d":1082220,"h":34360820588,"f":129},{"r":65537,"n":"Clear","d":1082220,"h":38655787884,"f":129},{"r":262145,"p":[{"n":"address","p":1016684}],"n":"Contains","d":1082220,"h":42950755180,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":1082220,"h":47245722476,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,"n":"GetEnumerator","d":1082220,"h":51540689772,"f":129},{"r":262145,"p":[{"n":"address","p":1016684}],"n":"Remove","d":1082220,"h":55835657068,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":1082220,"h":4296049516,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,31588353],"h":1082220}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.MulticastIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UnicastIPAddressInformationCollection", ($self) => class UnicastIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.UnicastIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.UnicastIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Add(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Contains(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.CopyTo(System.Net.NetworkInformation.UnicastIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Remove(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.UnicastIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 2392940;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12887294828,"f":129},"n":"Count","d":2392940,"h":8592327532,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21477229420,"f":129},"n":"IsReadOnly","d":2392940,"h":17182262124,"f":129},{"p":2327404,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30067164012,"f":129},"n":"Item","o":"@$2","d":2392940,"h":25772196716,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":2327404}],"n":"Add","d":2392940,"h":34362131308,"f":129},{"r":65537,"n":"Clear","d":2392940,"h":38657098604,"f":129},{"r":262145,"p":[{"n":"address","p":2327404}],"n":"Contains","d":2392940,"h":42952065900,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":2392940,"h":47247033196,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,"n":"GetEnumerator","d":2392940,"h":51542000492,"f":129},{"r":262145,"p":[{"n":"address","p":2327404}],"n":"Remove","d":2392940,"h":55836967788,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":2392940,"h":4297360236,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,31588353],"h":2392940}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.UnicastIPAddressInformationCollection`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.DuplicateAddressDetectionState", ($self) => class DuplicateAddressDetectionState extends $.$spc.System.Enum
        {
            static Invalid = 0;
            static Tentative = 1;
            static Duplicate = 2;
            static Deprecated = 3;
            static Preferred = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Invalid": 0n,
                    "Tentative": 1n,
                    "Duplicate": 2n,
                    "Deprecated": 3n,
                    "Preferred": 4n
                };
            }
            static $h = 99180;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":99180,"n":"Invalid","d":99180,"h":4295066476,"f":33},{"t":99180,"n":"Tentative","d":99180,"h":8590033772,"f":33},{"t":99180,"n":"Duplicate","d":99180,"h":12885001068,"f":33},{"t":99180,"n":"Deprecated","d":99180,"h":17179968364,"f":33},{"t":99180,"n":"Preferred","d":99180,"h":21474935660,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":99180,"h":25769902956,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":99180}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.DuplicateAddressDetectionState`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetBiosNodeType", ($self) => class NetBiosNodeType extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Broadcast = 1;
            static Peer2Peer = 2;
            static Mixed = 4;
            static Hybrid = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Broadcast": 1n,
                    "Peer2Peer": 2n,
                    "Mixed": 4n,
                    "Hybrid": 8n
                };
            }
            static $h = 1147756;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1147756,"n":"Unknown","d":1147756,"h":4296115052,"f":33},{"t":1147756,"n":"Broadcast","d":1147756,"h":8591082348,"f":33},{"t":1147756,"n":"Peer2Peer","d":1147756,"h":12886049644,"f":33},{"t":1147756,"n":"Mixed","d":1147756,"h":17181016940,"f":33},{"t":1147756,"n":"Hybrid","d":1147756,"h":21475984236,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1147756,"h":25770951532,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1147756}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetBiosNodeType`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetworkInterfaceComponent", ($self) => class NetworkInterfaceComponent extends $.$spc.System.Enum
        {
            static IPv4 = 0;
            static IPv6 = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "IPv4": 0n,
                    "IPv6": 1n
                };
            }
            static $h = 1606508;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1606508,"n":"IPv4","d":1606508,"h":4296573804,"f":33},{"t":1606508,"n":"IPv6","d":1606508,"h":8591541100,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1606508,"h":12886508396,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1606508}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterfaceComponent`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetworkInterfaceType", ($self) => class NetworkInterfaceType extends $.$spc.System.Enum
        {
            static Unknown = 1;
            static Ethernet = 6;
            static TokenRing = 9;
            static Fddi = 15;
            static BasicIsdn = 20;
            static PrimaryIsdn = 21;
            static Ppp = 23;
            static Loopback = 24;
            static Ethernet3Megabit = 26;
            static Slip = 28;
            static Atm = 37;
            static GenericModem = 48;
            static FastEthernetT = 62;
            static Isdn = 63;
            static FastEthernetFx = 69;
            static Wireless80211 = 71;
            static AsymmetricDsl = 94;
            static RateAdaptDsl = 95;
            static SymmetricDsl = 96;
            static VeryHighSpeedDsl = 97;
            static IPOverAtm = 114;
            static GigabitEthernet = 117;
            static Tunnel = 131;
            static MultiRateSymmetricDsl = 143;
            static HighPerformanceSerialBus = 144;
            static Wman = 237;
            static Wwanpp = 243;
            static Wwanpp2 = 244;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 1n,
                    "Ethernet": 6n,
                    "TokenRing": 9n,
                    "Fddi": 15n,
                    "BasicIsdn": 20n,
                    "PrimaryIsdn": 21n,
                    "Ppp": 23n,
                    "Loopback": 24n,
                    "Ethernet3Megabit": 26n,
                    "Slip": 28n,
                    "Atm": 37n,
                    "GenericModem": 48n,
                    "FastEthernetT": 62n,
                    "Isdn": 63n,
                    "FastEthernetFx": 69n,
                    "Wireless80211": 71n,
                    "AsymmetricDsl": 94n,
                    "RateAdaptDsl": 95n,
                    "SymmetricDsl": 96n,
                    "VeryHighSpeedDsl": 97n,
                    "IPOverAtm": 114n,
                    "GigabitEthernet": 117n,
                    "Tunnel": 131n,
                    "MultiRateSymmetricDsl": 143n,
                    "HighPerformanceSerialBus": 144n,
                    "Wman": 237n,
                    "Wwanpp": 243n,
                    "Wwanpp2": 244n
                };
            }
            static $h = 1672044;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1672044,"n":"Unknown","d":1672044,"h":4296639340,"f":33},{"t":1672044,"n":"Ethernet","d":1672044,"h":8591606636,"f":33},{"t":1672044,"n":"TokenRing","d":1672044,"h":12886573932,"f":33},{"t":1672044,"n":"Fddi","d":1672044,"h":17181541228,"f":33},{"t":1672044,"n":"BasicIsdn","d":1672044,"h":21476508524,"f":33},{"t":1672044,"n":"PrimaryIsdn","d":1672044,"h":25771475820,"f":33},{"t":1672044,"n":"Ppp","d":1672044,"h":30066443116,"f":33},{"t":1672044,"n":"Loopback","d":1672044,"h":34361410412,"f":33},{"t":1672044,"n":"Ethernet3Megabit","d":1672044,"h":38656377708,"f":33},{"t":1672044,"n":"Slip","d":1672044,"h":42951345004,"f":33},{"t":1672044,"n":"Atm","d":1672044,"h":47246312300,"f":33},{"t":1672044,"n":"GenericModem","d":1672044,"h":51541279596,"f":33},{"t":1672044,"n":"FastEthernetT","d":1672044,"h":55836246892,"f":33},{"t":1672044,"n":"Isdn","d":1672044,"h":60131214188,"f":33},{"t":1672044,"n":"FastEthernetFx","d":1672044,"h":64426181484,"f":33},{"t":1672044,"n":"Wireless80211","d":1672044,"h":68721148780,"f":33},{"t":1672044,"n":"AsymmetricDsl","d":1672044,"h":73016116076,"f":33},{"t":1672044,"n":"RateAdaptDsl","d":1672044,"h":77311083372,"f":33},{"t":1672044,"n":"SymmetricDsl","d":1672044,"h":81606050668,"f":33},{"t":1672044,"n":"VeryHighSpeedDsl","d":1672044,"h":85901017964,"f":33},{"t":1672044,"n":"IPOverAtm","d":1672044,"h":90195985260,"f":33},{"t":1672044,"n":"GigabitEthernet","d":1672044,"h":94490952556,"f":33},{"t":1672044,"n":"Tunnel","d":1672044,"h":98785919852,"f":33},{"t":1672044,"n":"MultiRateSymmetricDsl","d":1672044,"h":103080887148,"f":33},{"t":1672044,"n":"HighPerformanceSerialBus","d":1672044,"h":107375854444,"f":33},{"t":1672044,"n":"Wman","d":1672044,"h":111670821740,"f":33},{"t":1672044,"n":"Wwanpp","d":1672044,"h":115965789036,"f":33},{"t":1672044,"n":"Wwanpp2","d":1672044,"h":120260756332,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1672044,"h":124555723628,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1672044}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterfaceType`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.OperationalStatus", ($self) => class OperationalStatus extends $.$spc.System.Enum
        {
            static Up = 1;
            static Down = 2;
            static Testing = 3;
            static Unknown = 4;
            static Dormant = 5;
            static NotPresent = 6;
            static LowerLayerDown = 7;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Up": 1n,
                    "Down": 2n,
                    "Testing": 3n,
                    "Unknown": 4n,
                    "Dormant": 5n,
                    "NotPresent": 6n,
                    "LowerLayerDown": 7n
                };
            }
            static $h = 1737580;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1737580,"n":"Up","d":1737580,"h":4296704876,"f":33},{"t":1737580,"n":"Down","d":1737580,"h":8591672172,"f":33},{"t":1737580,"n":"Testing","d":1737580,"h":12886639468,"f":33},{"t":1737580,"n":"Unknown","d":1737580,"h":17181606764,"f":33},{"t":1737580,"n":"Dormant","d":1737580,"h":21476574060,"f":33},{"t":1737580,"n":"NotPresent","d":1737580,"h":25771541356,"f":33},{"t":1737580,"n":"LowerLayerDown","d":1737580,"h":30066508652,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1737580,"h":34361475948,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1737580}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.OperationalStatus`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.PrefixOrigin", ($self) => class PrefixOrigin extends $.$spc.System.Enum
        {
            static Other = 0;
            static Manual = 1;
            static WellKnown = 2;
            static Dhcp = 3;
            static RouterAdvertisement = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Other": 0n,
                    "Manual": 1n,
                    "WellKnown": 2n,
                    "Dhcp": 3n,
                    "RouterAdvertisement": 4n
                };
            }
            static $h = 1868652;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1868652,"n":"Other","d":1868652,"h":4296835948,"f":33},{"t":1868652,"n":"Manual","d":1868652,"h":8591803244,"f":33},{"t":1868652,"n":"WellKnown","d":1868652,"h":12886770540,"f":33},{"t":1868652,"n":"Dhcp","d":1868652,"h":17181737836,"f":33},{"t":1868652,"n":"RouterAdvertisement","d":1868652,"h":21476705132,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1868652,"h":25771672428,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1868652}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.PrefixOrigin`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.ScopeLevel", ($self) => class ScopeLevel extends $.$spc.System.Enum
        {
            static None = 0;
            static Interface = 1;
            static Link = 2;
            static Subnet = 3;
            static Admin = 4;
            static Site = 5;
            static Organization = 8;
            static Global = 14;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Interface": 1n,
                    "Link": 2n,
                    "Subnet": 3n,
                    "Admin": 4n,
                    "Site": 5n,
                    "Organization": 8n,
                    "Global": 14n
                };
            }
            static $h = 1934188;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1934188,"n":"None","d":1934188,"h":4296901484,"f":33},{"t":1934188,"n":"Interface","d":1934188,"h":8591868780,"f":33},{"t":1934188,"n":"Link","d":1934188,"h":12886836076,"f":33},{"t":1934188,"n":"Subnet","d":1934188,"h":17181803372,"f":33},{"t":1934188,"n":"Admin","d":1934188,"h":21476770668,"f":33},{"t":1934188,"n":"Site","d":1934188,"h":25771737964,"f":33},{"t":1934188,"n":"Organization","d":1934188,"h":30066705260,"f":33},{"t":1934188,"n":"Global","d":1934188,"h":34361672556,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1934188,"h":38656639852,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1934188}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.ScopeLevel`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.SuffixOrigin", ($self) => class SuffixOrigin extends $.$spc.System.Enum
        {
            static Other = 0;
            static Manual = 1;
            static WellKnown = 2;
            static OriginDhcp = 3;
            static LinkLayerAddress = 4;
            static Random = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Other": 0n,
                    "Manual": 1n,
                    "WellKnown": 2n,
                    "OriginDhcp": 3n,
                    "LinkLayerAddress": 4n,
                    "Random": 5n
                };
            }
            static $h = 1999724;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1999724,"n":"Other","d":1999724,"h":4296967020,"f":33},{"t":1999724,"n":"Manual","d":1999724,"h":8591934316,"f":33},{"t":1999724,"n":"WellKnown","d":1999724,"h":12886901612,"f":33},{"t":1999724,"n":"OriginDhcp","d":1999724,"h":17181868908,"f":33},{"t":1999724,"n":"LinkLayerAddress","d":1999724,"h":21476836204,"f":33},{"t":1999724,"n":"Random","d":1999724,"h":25771803500,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1999724,"h":30066770796,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1999724}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.SuffixOrigin`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.TcpState", ($self) => class TcpState extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Closed = 1;
            static Listen = 2;
            static SynSent = 3;
            static SynReceived = 4;
            static Established = 5;
            static FinWait1 = 6;
            static FinWait2 = 7;
            static CloseWait = 8;
            static Closing = 9;
            static LastAck = 10;
            static TimeWait = 11;
            static DeleteTcb = 12;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Closed": 1n,
                    "Listen": 2n,
                    "SynSent": 3n,
                    "SynReceived": 4n,
                    "Established": 5n,
                    "FinWait1": 6n,
                    "FinWait2": 7n,
                    "CloseWait": 8n,
                    "Closing": 9n,
                    "LastAck": 10n,
                    "TimeWait": 11n,
                    "DeleteTcb": 12n
                };
            }
            static $h = 2130796;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2130796,"n":"Unknown","d":2130796,"h":4297098092,"f":33},{"t":2130796,"n":"Closed","d":2130796,"h":8592065388,"f":33},{"t":2130796,"n":"Listen","d":2130796,"h":12887032684,"f":33},{"t":2130796,"n":"SynSent","d":2130796,"h":17181999980,"f":33},{"t":2130796,"n":"SynReceived","d":2130796,"h":21476967276,"f":33},{"t":2130796,"n":"Established","d":2130796,"h":25771934572,"f":33},{"t":2130796,"n":"FinWait1","d":2130796,"h":30066901868,"f":33},{"t":2130796,"n":"FinWait2","d":2130796,"h":34361869164,"f":33},{"t":2130796,"n":"CloseWait","d":2130796,"h":38656836460,"f":33},{"t":2130796,"n":"Closing","d":2130796,"h":42951803756,"f":33},{"t":2130796,"n":"LastAck","d":2130796,"h":47246771052,"f":33},{"t":2130796,"n":"TimeWait","d":2130796,"h":51541738348,"f":33},{"t":2130796,"n":"DeleteTcb","d":2130796,"h":55836705644,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2130796,"h":60131672940,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2130796}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpState`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAvailabilityEventArgs", ($self) => class NetworkAvailabilityEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ get IsAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1344364;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886246252,"f":1},"n":"IsAvailable","d":1344364,"h":8591278956,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1344364,"h":4296311660,"f":8}],"h":1344364}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAvailabilityEventArgs`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAddressChangedEventHandler", ($self) => class NetworkAddressChangedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ $sender, /*$.$spc.System.EventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 1213292;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":46923777}],"n":"Invoke","d":1213292,"h":8591147884,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":46923777},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":1213292,"h":12886115180,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":1213292,"h":17181082476,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1213292,"h":4296180588,"f":1}],"i":[57147393,113377281],"h":1213292}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAddressChangedEventHandler`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler", ($self) => class NetworkAvailabilityChangedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ $sender, /*$.$snn.System.Net.NetworkInformation.NetworkAvailabilityEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 1278828;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":1344364}],"n":"Invoke","d":1278828,"h":8591213420,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":1344364},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":1278828,"h":12886180716,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":1278828,"h":17181148012,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1278828,"h":4296246124,"f":1}],"i":[57147393,113377281],"h":1278828}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkInformationException", ($self) => class NetworkInformationException extends $.$spc.System.ComponentModel.Win32Exception
        {
            $ctor$20()
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            $ctor$21(/*int*/ errorCode)
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            $ctor$22(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            /*int */ get ErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1475436;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":33292289,"h":1475436}; }
            static get $b() { return $.$spc.System.ComponentModel.Win32Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInformationException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Console", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets"))