
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $ssc, $sris, $scsl, $sl, $snp, $sspw, $sdd, $snnr, $sns) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.NetworkInformation", 
    {"h":48531,"f":"System.Net.NetworkInformation","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.NetworkInformation","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.NetworkInformation","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snn.System.Net.NetworkInformation.GatewayIPAddressInformation", ($self) => class GatewayIPAddressInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 179603;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3071756,"g":{"r":0,"d":0,"h":12885081491,"f":257},"n":"Address","d":179603,"h":8590114195,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":179603,"h":4295146899,"f":4}],"h":179603}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.GatewayIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IcmpV4Statistics", ($self) => class IcmpV4Statistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 310675;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885212563,"f":257},"n":"AddressMaskRepliesReceived","d":310675,"h":8590245267,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475147155,"f":257},"n":"AddressMaskRepliesSent","d":310675,"h":17180179859,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065081747,"f":257},"n":"AddressMaskRequestsReceived","d":310675,"h":25770114451,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655016339,"f":257},"n":"AddressMaskRequestsSent","d":310675,"h":34360049043,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47244950931,"f":257},"n":"DestinationUnreachableMessagesReceived","d":310675,"h":42949983635,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55834885523,"f":257},"n":"DestinationUnreachableMessagesSent","d":310675,"h":51539918227,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64424820115,"f":257},"n":"EchoRepliesReceived","d":310675,"h":60129852819,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73014754707,"f":257},"n":"EchoRepliesSent","d":310675,"h":68719787411,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":81604689299,"f":257},"n":"EchoRequestsReceived","d":310675,"h":77309722003,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90194623891,"f":257},"n":"EchoRequestsSent","d":310675,"h":85899656595,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98784558483,"f":257},"n":"ErrorsReceived","d":310675,"h":94489591187,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":107374493075,"f":257},"n":"ErrorsSent","d":310675,"h":103079525779,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":115964427667,"f":257},"n":"MessagesReceived","d":310675,"h":111669460371,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":124554362259,"f":257},"n":"MessagesSent","d":310675,"h":120259394963,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":133144296851,"f":257},"n":"ParameterProblemsReceived","d":310675,"h":128849329555,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":141734231443,"f":257},"n":"ParameterProblemsSent","d":310675,"h":137439264147,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":150324166035,"f":257},"n":"RedirectsReceived","d":310675,"h":146029198739,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":158914100627,"f":257},"n":"RedirectsSent","d":310675,"h":154619133331,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":167504035219,"f":257},"n":"SourceQuenchesReceived","d":310675,"h":163209067923,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":176093969811,"f":257},"n":"SourceQuenchesSent","d":310675,"h":171799002515,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":184683904403,"f":257},"n":"TimeExceededMessagesReceived","d":310675,"h":180388937107,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":193273838995,"f":257},"n":"TimeExceededMessagesSent","d":310675,"h":188978871699,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":201863773587,"f":257},"n":"TimestampRepliesReceived","d":310675,"h":197568806291,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":210453708179,"f":257},"n":"TimestampRepliesSent","d":310675,"h":206158740883,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":219043642771,"f":257},"n":"TimestampRequestsReceived","d":310675,"h":214748675475,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":227633577363,"f":257},"n":"TimestampRequestsSent","d":310675,"h":223338610067,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":310675,"h":4295277971,"f":4}],"h":310675}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IcmpV4Statistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IcmpV6Statistics", ($self) => class IcmpV6Statistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 376211;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885278099,"f":257},"n":"DestinationUnreachableMessagesReceived","d":376211,"h":8590310803,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475212691,"f":257},"n":"DestinationUnreachableMessagesSent","d":376211,"h":17180245395,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065147283,"f":257},"n":"EchoRepliesReceived","d":376211,"h":25770179987,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655081875,"f":257},"n":"EchoRepliesSent","d":376211,"h":34360114579,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245016467,"f":257},"n":"EchoRequestsReceived","d":376211,"h":42950049171,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55834951059,"f":257},"n":"EchoRequestsSent","d":376211,"h":51539983763,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64424885651,"f":257},"n":"ErrorsReceived","d":376211,"h":60129918355,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73014820243,"f":257},"n":"ErrorsSent","d":376211,"h":68719852947,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81604754835,"f":257},"n":"MembershipQueriesReceived","d":376211,"h":77309787539,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90194689427,"f":257},"n":"MembershipQueriesSent","d":376211,"h":85899722131,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98784624019,"f":257},"n":"MembershipReductionsReceived","d":376211,"h":94489656723,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107374558611,"f":257},"n":"MembershipReductionsSent","d":376211,"h":103079591315,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":115964493203,"f":257},"n":"MembershipReportsReceived","d":376211,"h":111669525907,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":124554427795,"f":257},"n":"MembershipReportsSent","d":376211,"h":120259460499,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":133144362387,"f":257},"n":"MessagesReceived","d":376211,"h":128849395091,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":141734296979,"f":257},"n":"MessagesSent","d":376211,"h":137439329683,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":150324231571,"f":257},"n":"NeighborAdvertisementsReceived","d":376211,"h":146029264275,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":158914166163,"f":257},"n":"NeighborAdvertisementsSent","d":376211,"h":154619198867,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":167504100755,"f":257},"n":"NeighborSolicitsReceived","d":376211,"h":163209133459,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":176094035347,"f":257},"n":"NeighborSolicitsSent","d":376211,"h":171799068051,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":184683969939,"f":257},"n":"PacketTooBigMessagesReceived","d":376211,"h":180389002643,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":193273904531,"f":257},"n":"PacketTooBigMessagesSent","d":376211,"h":188978937235,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":201863839123,"f":257},"n":"ParameterProblemsReceived","d":376211,"h":197568871827,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":210453773715,"f":257},"n":"ParameterProblemsSent","d":376211,"h":206158806419,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":219043708307,"f":257},"n":"RedirectsReceived","d":376211,"h":214748741011,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":227633642899,"f":257},"n":"RedirectsSent","d":376211,"h":223338675603,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":236223577491,"f":257},"n":"RouterAdvertisementsReceived","d":376211,"h":231928610195,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":244813512083,"f":257},"n":"RouterAdvertisementsSent","d":376211,"h":240518544787,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":253403446675,"f":257},"n":"RouterSolicitsReceived","d":376211,"h":249108479379,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":261993381267,"f":257},"n":"RouterSolicitsSent","d":376211,"h":257698413971,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":270583315859,"f":257},"n":"TimeExceededMessagesReceived","d":376211,"h":266288348563,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":279173250451,"f":257},"n":"TimeExceededMessagesSent","d":376211,"h":274878283155,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":376211,"h":4295343507,"f":4}],"h":376211}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IcmpV6Statistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPAddressInformation", ($self) => class IPAddressInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 441747;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3071756,"g":{"r":0,"d":0,"h":12885343635,"f":257},"n":"Address","d":441747,"h":8590376339,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":21475278227,"f":257},"n":"IsDnsEligible","d":441747,"h":17180310931,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":30065212819,"f":257},"n":"IsTransient","d":441747,"h":25770245523,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":441747,"h":4295409043,"f":4}],"h":441747}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPGlobalProperties", ($self) => class IPGlobalProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.IAsyncResult */ BeginGetUnicastAddresses(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformationCollection */ EndGetUnicastAddresses(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.IPGlobalProperties */ GetIPGlobalProperties()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformationCollection */ GetUnicastAddresses()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.NetworkInformation.UnicastIPAddressInformationCollection> */ GetUnicastAddressesAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 572819;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12885474707,"f":257},"n":"DhcpScopeName","d":572819,"h":8590507411,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":21475409299,"f":257},"n":"DomainName","d":572819,"h":17180442003,"f":257},{"p":1310721,"g":{"r":0,"d":0,"h":30065343891,"f":257},"n":"HostName","d":572819,"h":25770376595,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":38655278483,"f":257},"n":"IsWinsProxy","d":572819,"h":34360311187,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1162643,"g":{"r":0,"d":0,"h":47245213075,"f":257},"n":"NodeType","d":572819,"h":42950245779,"f":257}],"m":[{"r":56950785,"p":[{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginGetUnicastAddresses","d":572819,"h":51540180371,"f":129},{"r":2407827,"p":[{"n":"asyncResult","p":56950785}],"n":"EndGetUnicastAddresses","d":572819,"h":55835147667,"f":129},{"r":0,"n":"GetActiveTcpConnections","d":572819,"h":60130114963,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":0,"n":"GetActiveTcpListeners","d":572819,"h":64425082259,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":0,"n":"GetActiveUdpListeners","d":572819,"h":68720049555,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":310675,"n":"GetIcmpV4Statistics","d":572819,"h":73015016851,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":376211,"n":"GetIcmpV6Statistics","d":572819,"h":77309984147,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":572819,"n":"GetIPGlobalProperties","d":572819,"h":81604951443,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":638355,"n":"GetIPv4GlobalStatistics","d":572819,"h":85899918739,"f":257},{"r":638355,"n":"GetIPv6GlobalStatistics","d":572819,"h":90194886035,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"r":2211219,"n":"GetTcpIPv4Statistics","d":572819,"h":94489853331,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2211219,"n":"GetTcpIPv6Statistics","d":572819,"h":98784820627,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2276755,"n":"GetUdpIPv4Statistics","d":572819,"h":103079787923,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2276755,"n":"GetUdpIPv6Statistics","d":572819,"h":107374755219,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":2407827,"n":"GetUnicastAddresses","d":572819,"h":111669722515,"f":129},{"r":$.$spc.System.Threading.Tasks.Task$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformationCollection).$h,"n":"GetUnicastAddressesAsync","d":572819,"h":115964689811,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":572819,"h":4295540115,"f":4}],"h":572819}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPGlobalProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPGlobalStatistics", ($self) => class IPGlobalStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 638355;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885540243,"f":257},"n":"DefaultTtl","d":638355,"h":8590572947,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":21475474835,"f":257},"n":"ForwardingEnabled","d":638355,"h":17180507539,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":30065409427,"f":257},"n":"NumberOfInterfaces","d":638355,"h":25770442131,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":38655344019,"f":257},"n":"NumberOfIPAddresses","d":638355,"h":34360376723,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":47245278611,"f":257},"n":"NumberOfRoutes","d":638355,"h":42950311315,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":55835213203,"f":257},"n":"OutputPacketRequests","d":638355,"h":51540245907,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":64425147795,"f":257},"n":"OutputPacketRoutingDiscards","d":638355,"h":60130180499,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73015082387,"f":257},"n":"OutputPacketsDiscarded","d":638355,"h":68720115091,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605016979,"f":257},"n":"OutputPacketsWithNoRoute","d":638355,"h":77310049683,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":90194951571,"f":257},"n":"PacketFragmentFailures","d":638355,"h":85899984275,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":98784886163,"f":257},"n":"PacketReassembliesRequired","d":638355,"h":94489918867,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":107374820755,"f":257},"n":"PacketReassemblyFailures","d":638355,"h":103079853459,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":115964755347,"f":257},"n":"PacketReassemblyTimeout","d":638355,"h":111669788051,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":124554689939,"f":257},"n":"PacketsFragmented","d":638355,"h":120259722643,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":133144624531,"f":257},"n":"PacketsReassembled","d":638355,"h":128849657235,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":141734559123,"f":257},"n":"ReceivedPackets","d":638355,"h":137439591827,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":150324493715,"f":257},"n":"ReceivedPacketsDelivered","d":638355,"h":146029526419,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":158914428307,"f":257},"n":"ReceivedPacketsDiscarded","d":638355,"h":154619461011,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":167504362899,"f":257},"n":"ReceivedPacketsForwarded","d":638355,"h":163209395603,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":176094297491,"f":257},"n":"ReceivedPacketsWithAddressErrors","d":638355,"h":171799330195,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":184684232083,"f":257},"n":"ReceivedPacketsWithHeadersErrors","d":638355,"h":180389264787,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":193274166675,"f":257},"n":"ReceivedPacketsWithUnknownProtocol","d":638355,"h":188979199379,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":638355,"h":4295605651,"f":4}],"h":638355}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPGlobalStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPInterfaceProperties", ($self) => class IPInterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 703891;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":507283,"g":{"r":0,"d":0,"h":12885605779,"f":257},"n":"AnycastAddresses","d":703891,"h":8590638483,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":4054796,"g":{"r":0,"d":0,"h":21475540371,"f":257},"n":"DhcpServerAddresses","d":703891,"h":17180573075,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":4054796,"g":{"r":0,"d":0,"h":30065474963,"f":257},"n":"DnsAddresses","d":703891,"h":25770507667,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":38655409555,"f":257},"n":"DnsSuffix","d":703891,"h":34360442259,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":245139,"g":{"r":0,"d":0,"h":47245344147,"f":257},"n":"GatewayAddresses","d":703891,"h":42950376851,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":55835278739,"f":257},"n":"IsDnsEnabled","d":703891,"h":51540311443,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":64425213331,"f":257},"n":"IsDynamicDnsEnabled","d":703891,"h":60130246035,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1097107,"g":{"r":0,"d":0,"h":73015147923,"f":257},"n":"MulticastAddresses","d":703891,"h":68720180627,"f":257},{"p":2407827,"g":{"r":0,"d":0,"h":81605082515,"f":257},"n":"UnicastAddresses","d":703891,"h":77310115219,"f":257},{"p":4054796,"g":{"r":0,"d":0,"h":90195017107,"f":257},"n":"WinsServersAddresses","d":703891,"h":85900049811,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]}],"m":[{"r":834963,"n":"GetIPv4Properties","d":703891,"h":94489984403,"f":257},{"r":966035,"n":"GetIPv6Properties","d":703891,"h":98784951699,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":703891,"h":4295671187,"f":4}],"h":703891}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPInterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPInterfaceStatistics", ($self) => class IPInterfaceStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 769427;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885671315,"f":257},"n":"BytesReceived","d":769427,"h":8590704019,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475605907,"f":257},"n":"BytesSent","d":769427,"h":17180638611,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065540499,"f":257},"n":"IncomingPacketsDiscarded","d":769427,"h":25770573203,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655475091,"f":257},"n":"IncomingPacketsWithErrors","d":769427,"h":34360507795,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245409683,"f":257},"n":"IncomingUnknownProtocolPackets","d":769427,"h":42950442387,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"linux","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":55835344275,"f":257},"n":"NonUnicastPacketsReceived","d":769427,"h":51540376979,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64425278867,"f":257},"n":"NonUnicastPacketsSent","d":769427,"h":60130311571,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"linux","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":73015213459,"f":257},"n":"OutgoingPacketsDiscarded","d":769427,"h":68720246163,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605148051,"f":257},"n":"OutgoingPacketsWithErrors","d":769427,"h":77310180755,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90195082643,"f":257},"n":"OutputQueueLength","d":769427,"h":85900115347,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98785017235,"f":257},"n":"UnicastPacketsReceived","d":769427,"h":94490049939,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107374951827,"f":257},"n":"UnicastPacketsSent","d":769427,"h":103079984531,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":769427,"h":4295736723,"f":4}],"h":769427}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPInterfaceStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv4InterfaceProperties", ($self) => class IPv4InterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 834963;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885736851,"f":257},"n":"Index","d":834963,"h":8590769555,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":21475671443,"f":257},"n":"IsAutomaticPrivateAddressingActive","d":834963,"h":17180704147,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":30065606035,"f":257},"n":"IsAutomaticPrivateAddressingEnabled","d":834963,"h":25770638739,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":38655540627,"f":257},"n":"IsDhcpEnabled","d":834963,"h":34360573331,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":47245475219,"f":257},"n":"IsForwardingEnabled","d":834963,"h":42950507923,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":55835409811,"f":257},"n":"Mtu","d":834963,"h":51540442515,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":64425344403,"f":257},"n":"UsesWins","d":834963,"h":60130377107,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":834963,"h":4295802259,"f":4}],"h":834963}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv4InterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv4InterfaceStatistics", ($self) => class IPv4InterfaceStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 900499;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885802387,"f":257},"n":"BytesReceived","d":900499,"h":8590835091,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21475736979,"f":257},"n":"BytesSent","d":900499,"h":17180769683,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30065671571,"f":257},"n":"IncomingPacketsDiscarded","d":900499,"h":25770704275,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38655606163,"f":257},"n":"IncomingPacketsWithErrors","d":900499,"h":34360638867,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47245540755,"f":257},"n":"IncomingUnknownProtocolPackets","d":900499,"h":42950573459,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55835475347,"f":257},"n":"NonUnicastPacketsReceived","d":900499,"h":51540508051,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64425409939,"f":257},"n":"NonUnicastPacketsSent","d":900499,"h":60130442643,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73015344531,"f":257},"n":"OutgoingPacketsDiscarded","d":900499,"h":68720377235,"f":257,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":81605279123,"f":257},"n":"OutgoingPacketsWithErrors","d":900499,"h":77310311827,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90195213715,"f":257},"n":"OutputQueueLength","d":900499,"h":85900246419,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98785148307,"f":257},"n":"UnicastPacketsReceived","d":900499,"h":94490181011,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107375082899,"f":257},"n":"UnicastPacketsSent","d":900499,"h":103080115603,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":900499,"h":4295867795,"f":4}],"h":900499}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv4InterfaceStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPv6InterfaceProperties", ($self) => class IPv6InterfaceProperties extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*long */ GetScopeId(/*System.Net.NetworkInformation.ScopeLevel*/ scopeLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 966035;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885867923,"f":257},"n":"Index","d":966035,"h":8590900627,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":21475802515,"f":257},"n":"Mtu","d":966035,"h":17180835219,"f":257}],"m":[{"r":917505,"p":[{"n":"scopeLevel","p":1949075}],"n":"GetScopeId","d":966035,"h":25770769811,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"freebsd","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"ios","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"osx","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"tvos","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":966035,"h":4295933331,"f":4}],"h":966035}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.IPv6InterfaceProperties`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkInterface", ($self) => class NetworkInterface extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*string */ get Description()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get IPv6LoopbackInterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReceiveOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ get LoopbackInterfaceIndex()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Name()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.NetworkInterfaceType */ get NetworkInterfaceType()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.OperationalStatus */ get OperationalStatus()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Speed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get SupportsMulticast()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.NetworkInterface[] */ GetAllNetworkInterfaces()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPInterfaceProperties */ GetIPProperties()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPInterfaceStatistics */ GetIPStatistics()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPv4InterfaceStatistics */ GetIPv4Statistics()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ GetIsNetworkAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.PhysicalAddress */ GetPhysicalAddress()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Supports(/*System.Net.NetworkInformation.NetworkInterfaceComponent*/ networkInterfaceComponent)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1555859;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":12886457747,"f":129},"n":"Description","d":1555859,"h":8591490451,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":21476392339,"f":129},"n":"Id","d":1555859,"h":17181425043,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":30066326931,"f":33},"n":"IPv6LoopbackInterfaceIndex","d":1555859,"h":25771359635,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":38656261523,"f":129},"n":"IsReceiveOnly","d":1555859,"h":34361294227,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":47246196115,"f":33},"n":"LoopbackInterfaceIndex","d":1555859,"h":42951228819,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":55836130707,"f":129},"n":"Name","d":1555859,"h":51541163411,"f":129},{"p":1686931,"g":{"r":0,"d":0,"h":64426065299,"f":129},"n":"NetworkInterfaceType","d":1555859,"h":60131098003,"f":129},{"p":1752467,"g":{"r":0,"d":0,"h":73015999891,"f":129},"n":"OperationalStatus","d":1555859,"h":68721032595,"f":129},{"p":917505,"g":{"r":0,"d":0,"h":81605934483,"f":129},"n":"Speed","d":1555859,"h":77310967187,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":90195869075,"f":129},"n":"SupportsMulticast","d":1555859,"h":85900901779,"f":129}],"m":[{"r":0,"n":"GetAllNetworkInterfaces","d":1555859,"h":94490836371,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":703891,"n":"GetIPProperties","d":1555859,"h":98785803667,"f":129},{"r":769427,"n":"GetIPStatistics","d":1555859,"h":103080770963,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":900499,"n":"GetIPv4Statistics","d":1555859,"h":107375738259,"f":129,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]}]},{"r":262145,"n":"GetIsNetworkAvailable","d":1555859,"h":111670705555,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"r":1818003,"n":"GetPhysicalAddress","d":1555859,"h":115965672851,"f":129},{"r":262145,"p":[{"n":"networkInterfaceComponent","p":1621395}],"n":"Supports","d":1555859,"h":120260640147,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":1555859,"h":4296523155,"f":4}],"h":1555859}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterface`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.TcpConnectionInformation", ($self) => class TcpConnectionInformation extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2080147;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3333900,"g":{"r":0,"d":0,"h":12886982035,"f":257},"n":"LocalEndPoint","d":2080147,"h":8592014739,"f":257},{"p":3333900,"g":{"r":0,"d":0,"h":21476916627,"f":257},"n":"RemoteEndPoint","d":2080147,"h":17181949331,"f":257},{"p":2145683,"g":{"r":0,"d":0,"h":30066851219,"f":257},"n":"State","d":2080147,"h":25771883923,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2080147,"h":4297047443,"f":4}],"h":2080147}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpConnectionInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.TcpStatistics", ($self) => class TcpStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2211219;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887113107,"f":257},"n":"ConnectionsAccepted","d":2211219,"h":8592145811,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21477047699,"f":257},"n":"ConnectionsInitiated","d":2211219,"h":17182080403,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30066982291,"f":257},"n":"CumulativeConnections","d":2211219,"h":25772014995,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38656916883,"f":257},"n":"CurrentConnections","d":2211219,"h":34361949587,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":47246851475,"f":257},"n":"ErrorsReceived","d":2211219,"h":42951884179,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":55836786067,"f":257},"n":"FailedConnectionAttempts","d":2211219,"h":51541818771,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":64426720659,"f":257},"n":"MaximumConnections","d":2211219,"h":60131753363,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":73016655251,"f":257},"n":"MaximumTransmissionTimeout","d":2211219,"h":68721687955,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":81606589843,"f":257},"n":"MinimumTransmissionTimeout","d":2211219,"h":77311622547,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":90196524435,"f":257},"n":"ResetConnections","d":2211219,"h":85901557139,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":98786459027,"f":257},"n":"ResetsSent","d":2211219,"h":94491491731,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":107376393619,"f":257},"n":"SegmentsReceived","d":2211219,"h":103081426323,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":115966328211,"f":257},"n":"SegmentsResent","d":2211219,"h":111671360915,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":124556262803,"f":257},"n":"SegmentsSent","d":2211219,"h":120261295507,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2211219,"h":4297178515,"f":4}],"h":2211219}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UdpStatistics", ($self) => class UdpStatistics extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static $h = 2276755;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887178643,"f":257},"n":"DatagramsReceived","d":2276755,"h":8592211347,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":21477113235,"f":257},"n":"DatagramsSent","d":2276755,"h":17182145939,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":30067047827,"f":257},"n":"IncomingDatagramsDiscarded","d":2276755,"h":25772080531,"f":257},{"p":917505,"g":{"r":0,"d":0,"h":38656982419,"f":257},"n":"IncomingDatagramsWithErrors","d":2276755,"h":34362015123,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":47246917011,"f":257},"n":"UdpListeners","d":2276755,"h":42951949715,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":2276755,"h":4297244051,"f":4}],"h":2276755}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.UdpStatistics`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.MulticastIPAddressInformation", ($self) => class MulticastIPAddressInformation extends $.$snn.System.Net.NetworkInformation.IPAddressInformation
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            static $h = 1031571;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":441747,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885933459,"f":257},"n":"AddressPreferredLifetime","d":1031571,"h":8590966163,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":21475868051,"f":257},"n":"AddressValidLifetime","d":1031571,"h":17180900755,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":30065802643,"f":257},"n":"DhcpLeaseLifetime","d":1031571,"h":25770835347,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":114067,"g":{"r":0,"d":0,"h":38655737235,"f":257},"n":"DuplicateAddressDetectionState","d":1031571,"h":34360769939,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":1883539,"g":{"r":0,"d":0,"h":47245671827,"f":257},"n":"PrefixOrigin","d":1031571,"h":42950704531,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":2014611,"g":{"r":0,"d":0,"h":55835606419,"f":257},"n":"SuffixOrigin","d":1031571,"h":51540639123,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":1031571,"h":4295998867,"f":4}],"h":1031571}; }
            static get $b() { return $.$snn.System.Net.NetworkInformation.IPAddressInformation; }
            static get $fullName() { return `System.Net.NetworkInformation.MulticastIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UnicastIPAddressInformation", ($self) => class UnicastIPAddressInformation extends $.$snn.System.Net.NetworkInformation.IPAddressInformation
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*int */ get PrefixLength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 2342291;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":441747,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12887244179,"f":257},"n":"AddressPreferredLifetime","d":2342291,"h":8592276883,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":21477178771,"f":257},"n":"AddressValidLifetime","d":2342291,"h":17182211475,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":30067113363,"f":257},"n":"DhcpLeaseLifetime","d":2342291,"h":25772146067,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":114067,"g":{"r":0,"d":0,"h":38657047955,"f":257},"n":"DuplicateAddressDetectionState","d":2342291,"h":34362080659,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":3071756,"g":{"r":0,"d":0,"h":47246982547,"f":257},"n":"IPv4Mask","d":2342291,"h":42952015251,"f":257},{"p":655361,"g":{"r":0,"d":0,"h":55836917139,"f":129},"n":"PrefixLength","d":2342291,"h":51541949843,"f":129},{"p":1883539,"g":{"r":0,"d":0,"h":64426851731,"f":257},"n":"PrefixOrigin","d":2342291,"h":60131884435,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"p":2014611,"g":{"r":0,"d":0,"h":73016786323,"f":257},"n":"SuffixOrigin","d":2342291,"h":68721819027,"f":257,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$2","d":2342291,"h":4297309587,"f":4}],"h":2342291}; }
            static get $b() { return $.$snn.System.Net.NetworkInformation.IPAddressInformation; }
            static get $fullName() { return `System.Net.NetworkInformation.UnicastIPAddressInformation`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkChange", ($self) => class NetworkChange extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.NetworkInformation.NetworkAddressChangedEventHandler?*/static  NetworkAddressChanged$add(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAddressChangedEventHandler?*/static  NetworkAddressChanged$remove(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler?*/static  NetworkAvailabilityChanged$add(value)
            {
            }
            /*System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler?*/static  NetworkAvailabilityChanged$remove(value)
            {
            }
            static /*void */ RegisterNetworkChange(/*System.Net.NetworkInformation.NetworkChange*/ nc)
            {
            }
            static $h = 1424787;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"nc","p":1424787}],"n":"RegisterNetworkChange","d":1424787,"h":34361163155,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":12955811841,"a":[{"v":"This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.","t":1310721},{"v":true,"t":262145}]}]}],"c":[{"n":".ctor","o":"$ctor$1","d":1424787,"h":4296392083,"f":1,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":12955811841,"a":[{"v":"This API supports the .NET Framework infrastructure and is not intended to be used directly from your code.","t":1310721},{"v":true,"t":262145}]}]}],"e":[{"e":1228179,"m":{"r":65537,"p":[{"n":"value","p":1228179}],"n":"add_NetworkAddressChanged","d":1424787,"h":12886326675,"f":33},"r":{"r":65537,"p":[{"n":"value","p":1228179}],"n":"remove_NetworkAddressChanged","d":1424787,"h":17181293971,"f":33},"n":"NetworkAddressChanged","d":1424787,"h":8591359379,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]},{"e":1293715,"m":{"r":65537,"p":[{"n":"value","p":1293715}],"n":"add_NetworkAvailabilityChanged","d":1424787,"h":25771228563,"f":33},"r":{"r":65537,"p":[{"n":"value","p":1293715}],"n":"remove_NetworkAvailabilityChanged","d":1424787,"h":30066195859,"f":33},"n":"NetworkAvailabilityChanged","d":1424787,"h":21476261267,"f":33,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"illumos","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"solaris","t":1310721}]}]}],"h":1424787}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkChange`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.PhysicalAddress", ($self) => class PhysicalAddress extends $.$spc.System.Object
        {
            /*System.Net.NetworkInformation.PhysicalAddress*/ static None = null;
            $ctor$1(/*byte[]*/ address)
            {
                super.$ctor();
                {
                }
                return this;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.Equals.apply(this, arguments); }
            /*byte[] */ GetAddressBytes()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.GetHashCode.apply(this, arguments); }
            static /*System.Net.NetworkInformation.PhysicalAddress */ Parse(/*System.ReadOnlySpan<char>*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.NetworkInformation.PhysicalAddress */ Parse$1(/*string?*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snn.System.Net.NetworkInformation.PhysicalAddress.ToString.apply(this, arguments); }
            static /*bool */ TryParse(/*System.ReadOnlySpan<char>*/ address, /*out System.Net.NetworkInformation.PhysicalAddress?*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ TryParse$1(/*string?*/ address, /*out System.Net.NetworkInformation.PhysicalAddress?*/ value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1818003;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":1818003,"h":12886719891,"f":32769},{"r":0,"n":"GetAddressBytes","d":1818003,"h":17181687187,"f":1},{"r":655361,"n":"GetHashCode","d":1818003,"h":21476654483,"f":32769},{"r":1818003,"p":[{"n":"address","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Parse","d":1818003,"h":25771621779,"f":33},{"r":1818003,"p":[{"n":"address","p":1310721}],"n":"Parse","o":"@$1","d":1818003,"h":30066589075,"f":33},{"r":1310721,"n":"ToString","d":1818003,"h":34361556371,"f":32769},{"r":262145,"p":[{"n":"address","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"value","p":1818003,"f":2}],"n":"TryParse","d":1818003,"h":38656523667,"f":33},{"r":262145,"p":[{"n":"address","p":1310721},{"n":"value","p":1818003,"f":2}],"n":"TryParse","o":"@$1","d":1818003,"h":42951490963,"f":33}],"l":[{"t":1818003,"n":"None","d":1818003,"h":4296785299,"f":33}],"c":[{"p":[{"n":"address","p":0}],"n":".ctor","o":"$ctor$1","d":1818003,"h":8591752595,"f":1}],"h":1818003}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.PhysicalAddress`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.GatewayIPAddressInformationCollection", ($self) => class GatewayIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.GatewayIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.GatewayIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.GatewayIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.GatewayIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Add(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Contains(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.CopyTo(System.Net.NetworkInformation.GatewayIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.GatewayIPAddressInformation>.Remove(System.Net.NetworkInformation.GatewayIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.GatewayIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 245139;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885147027,"f":129},"n":"Count","d":245139,"h":8590179731,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475081619,"f":129},"n":"IsReadOnly","d":245139,"h":17180114323,"f":129},{"p":179603,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065016211,"f":129},"n":"Item","o":"@$2","d":245139,"h":25770048915,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":179603}],"n":"Add","d":245139,"h":34359983507,"f":129},{"r":65537,"n":"Clear","d":245139,"h":38654950803,"f":129},{"r":262145,"p":[{"n":"address","p":179603}],"n":"Contains","d":245139,"h":42949918099,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":245139,"h":47244885395,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,"n":"GetEnumerator","d":245139,"h":51539852691,"f":129},{"r":262145,"p":[{"n":"address","p":179603}],"n":"Remove","d":245139,"h":55834819987,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":245139,"h":4295212435,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation).$h,31588353],"h":245139}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.GatewayIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.GatewayIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.IPAddressInformationCollection", ($self) => class IPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.IPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.IPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.IPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.IPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Add(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Contains(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.CopyTo(System.Net.NetworkInformation.IPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.IPAddressInformation>.Remove(System.Net.NetworkInformation.IPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.IPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 507283;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885409171,"f":129},"n":"Count","d":507283,"h":8590441875,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475343763,"f":129},"n":"IsReadOnly","d":507283,"h":17180376467,"f":129},{"p":441747,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065278355,"f":129},"n":"Item","o":"@$2","d":507283,"h":25770311059,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":441747}],"n":"Add","d":507283,"h":34360245651,"f":129},{"r":65537,"n":"Clear","d":507283,"h":38655212947,"f":129},{"r":262145,"p":[{"n":"address","p":441747}],"n":"Contains","d":507283,"h":42950180243,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":507283,"h":47245147539,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,"n":"GetEnumerator","d":507283,"h":51540114835,"f":129},{"r":262145,"p":[{"n":"address","p":441747}],"n":"Remove","d":507283,"h":55835082131,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":507283,"h":4295474579,"f":8}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.IPAddressInformation).$h,31588353],"h":507283}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.IPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.IPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.MulticastIPAddressInformationCollection", ($self) => class MulticastIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.MulticastIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.MulticastIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.MulticastIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.MulticastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Add(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Contains(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.CopyTo(System.Net.NetworkInformation.MulticastIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.MulticastIPAddressInformation>.Remove(System.Net.NetworkInformation.MulticastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.MulticastIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 1097107;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885998995,"f":129},"n":"Count","d":1097107,"h":8591031699,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21475933587,"f":129},"n":"IsReadOnly","d":1097107,"h":17180966291,"f":129},{"p":1031571,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30065868179,"f":129},"n":"Item","o":"@$2","d":1097107,"h":25770900883,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":1031571}],"n":"Add","d":1097107,"h":34360835475,"f":129},{"r":65537,"n":"Clear","d":1097107,"h":38655802771,"f":129},{"r":262145,"p":[{"n":"address","p":1031571}],"n":"Contains","d":1097107,"h":42950770067,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":1097107,"h":47245737363,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,"n":"GetEnumerator","d":1097107,"h":51540704659,"f":129},{"r":262145,"p":[{"n":"address","p":1031571}],"n":"Remove","d":1097107,"h":55835671955,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":1097107,"h":4296064403,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation).$h,31588353],"h":1097107}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.MulticastIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.MulticastIPAddressInformationCollection`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.UnicastIPAddressInformationCollection", ($self) => class UnicastIPAddressInformationCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Count()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsReadOnly()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkInformation.UnicastIPAddressInformation*/ get_Item(/*int*/ index)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Add(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
            }
            /*void */ Clear()
            {
            }
            /*bool */ Contains(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CopyTo(/*System.Net.NetworkInformation.UnicastIPAddressInformation[]*/ array, /*int*/ offset)
            {
            }
            /*System.Collections.Generic.IEnumerator<System.Net.NetworkInformation.UnicastIPAddressInformation> */ GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Remove(/*System.Net.NetworkInformation.UnicastIPAddressInformation*/ address)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Add(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Contains(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.CopyTo(System.Net.NetworkInformation.UnicastIPAddressInformation[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.NetworkInformation.UnicastIPAddressInformation>.Remove(System.Net.NetworkInformation.UnicastIPAddressInformation)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.NetworkInformation.UnicastIPAddressInformation>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 2407827;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12887309715,"f":129},"n":"Count","d":2407827,"h":8592342419,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":21477244307,"f":129},"n":"IsReadOnly","d":2407827,"h":17182277011,"f":129},{"p":2342291,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":30067178899,"f":129},"n":"Item","o":"@$2","d":2407827,"h":25772211603,"f":129}],"m":[{"r":65537,"p":[{"n":"address","p":2342291}],"n":"Add","d":2407827,"h":34362146195,"f":129},{"r":65537,"n":"Clear","d":2407827,"h":38657113491,"f":129},{"r":262145,"p":[{"n":"address","p":2342291}],"n":"Contains","d":2407827,"h":42952080787,"f":129},{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":2407827,"h":47247048083,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,"n":"GetEnumerator","d":2407827,"h":51542015379,"f":129},{"r":262145,"p":[{"n":"address","p":2342291}],"n":"Remove","d":2407827,"h":55836982675,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":2407827,"h":4297375123,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation).$h,31588353],"h":2407827}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation), $.$spc.System.Collections.Generic.IEnumerable$$($.$snn.System.Net.NetworkInformation.UnicastIPAddressInformation), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.UnicastIPAddressInformationCollection`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.DuplicateAddressDetectionState", ($self) => class DuplicateAddressDetectionState extends $.$spc.System.Enum
        {
            static Invalid = 0;
            static Tentative = 1;
            static Duplicate = 2;
            static Deprecated = 3;
            static Preferred = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Invalid": 0n,
                    "Tentative": 1n,
                    "Duplicate": 2n,
                    "Deprecated": 3n,
                    "Preferred": 4n
                };
            }
            static $h = 114067;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":114067,"n":"Invalid","d":114067,"h":4295081363,"f":33},{"t":114067,"n":"Tentative","d":114067,"h":8590048659,"f":33},{"t":114067,"n":"Duplicate","d":114067,"h":12885015955,"f":33},{"t":114067,"n":"Deprecated","d":114067,"h":17179983251,"f":33},{"t":114067,"n":"Preferred","d":114067,"h":21474950547,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":114067,"h":25769917843,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":114067}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.DuplicateAddressDetectionState`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetBiosNodeType", ($self) => class NetBiosNodeType extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Broadcast = 1;
            static Peer2Peer = 2;
            static Mixed = 4;
            static Hybrid = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Broadcast": 1n,
                    "Peer2Peer": 2n,
                    "Mixed": 4n,
                    "Hybrid": 8n
                };
            }
            static $h = 1162643;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1162643,"n":"Unknown","d":1162643,"h":4296129939,"f":33},{"t":1162643,"n":"Broadcast","d":1162643,"h":8591097235,"f":33},{"t":1162643,"n":"Peer2Peer","d":1162643,"h":12886064531,"f":33},{"t":1162643,"n":"Mixed","d":1162643,"h":17181031827,"f":33},{"t":1162643,"n":"Hybrid","d":1162643,"h":21475999123,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1162643,"h":25770966419,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1162643}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetBiosNodeType`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetworkInterfaceComponent", ($self) => class NetworkInterfaceComponent extends $.$spc.System.Enum
        {
            static IPv4 = 0;
            static IPv6 = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "IPv4": 0n,
                    "IPv6": 1n
                };
            }
            static $h = 1621395;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1621395,"n":"IPv4","d":1621395,"h":4296588691,"f":33},{"t":1621395,"n":"IPv6","d":1621395,"h":8591555987,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1621395,"h":12886523283,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1621395}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterfaceComponent`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.NetworkInterfaceType", ($self) => class NetworkInterfaceType extends $.$spc.System.Enum
        {
            static Unknown = 1;
            static Ethernet = 6;
            static TokenRing = 9;
            static Fddi = 15;
            static BasicIsdn = 20;
            static PrimaryIsdn = 21;
            static Ppp = 23;
            static Loopback = 24;
            static Ethernet3Megabit = 26;
            static Slip = 28;
            static Atm = 37;
            static GenericModem = 48;
            static FastEthernetT = 62;
            static Isdn = 63;
            static FastEthernetFx = 69;
            static Wireless80211 = 71;
            static AsymmetricDsl = 94;
            static RateAdaptDsl = 95;
            static SymmetricDsl = 96;
            static VeryHighSpeedDsl = 97;
            static IPOverAtm = 114;
            static GigabitEthernet = 117;
            static Tunnel = 131;
            static MultiRateSymmetricDsl = 143;
            static HighPerformanceSerialBus = 144;
            static Wman = 237;
            static Wwanpp = 243;
            static Wwanpp2 = 244;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 1n,
                    "Ethernet": 6n,
                    "TokenRing": 9n,
                    "Fddi": 15n,
                    "BasicIsdn": 20n,
                    "PrimaryIsdn": 21n,
                    "Ppp": 23n,
                    "Loopback": 24n,
                    "Ethernet3Megabit": 26n,
                    "Slip": 28n,
                    "Atm": 37n,
                    "GenericModem": 48n,
                    "FastEthernetT": 62n,
                    "Isdn": 63n,
                    "FastEthernetFx": 69n,
                    "Wireless80211": 71n,
                    "AsymmetricDsl": 94n,
                    "RateAdaptDsl": 95n,
                    "SymmetricDsl": 96n,
                    "VeryHighSpeedDsl": 97n,
                    "IPOverAtm": 114n,
                    "GigabitEthernet": 117n,
                    "Tunnel": 131n,
                    "MultiRateSymmetricDsl": 143n,
                    "HighPerformanceSerialBus": 144n,
                    "Wman": 237n,
                    "Wwanpp": 243n,
                    "Wwanpp2": 244n
                };
            }
            static $h = 1686931;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1686931,"n":"Unknown","d":1686931,"h":4296654227,"f":33},{"t":1686931,"n":"Ethernet","d":1686931,"h":8591621523,"f":33},{"t":1686931,"n":"TokenRing","d":1686931,"h":12886588819,"f":33},{"t":1686931,"n":"Fddi","d":1686931,"h":17181556115,"f":33},{"t":1686931,"n":"BasicIsdn","d":1686931,"h":21476523411,"f":33},{"t":1686931,"n":"PrimaryIsdn","d":1686931,"h":25771490707,"f":33},{"t":1686931,"n":"Ppp","d":1686931,"h":30066458003,"f":33},{"t":1686931,"n":"Loopback","d":1686931,"h":34361425299,"f":33},{"t":1686931,"n":"Ethernet3Megabit","d":1686931,"h":38656392595,"f":33},{"t":1686931,"n":"Slip","d":1686931,"h":42951359891,"f":33},{"t":1686931,"n":"Atm","d":1686931,"h":47246327187,"f":33},{"t":1686931,"n":"GenericModem","d":1686931,"h":51541294483,"f":33},{"t":1686931,"n":"FastEthernetT","d":1686931,"h":55836261779,"f":33},{"t":1686931,"n":"Isdn","d":1686931,"h":60131229075,"f":33},{"t":1686931,"n":"FastEthernetFx","d":1686931,"h":64426196371,"f":33},{"t":1686931,"n":"Wireless80211","d":1686931,"h":68721163667,"f":33},{"t":1686931,"n":"AsymmetricDsl","d":1686931,"h":73016130963,"f":33},{"t":1686931,"n":"RateAdaptDsl","d":1686931,"h":77311098259,"f":33},{"t":1686931,"n":"SymmetricDsl","d":1686931,"h":81606065555,"f":33},{"t":1686931,"n":"VeryHighSpeedDsl","d":1686931,"h":85901032851,"f":33},{"t":1686931,"n":"IPOverAtm","d":1686931,"h":90196000147,"f":33},{"t":1686931,"n":"GigabitEthernet","d":1686931,"h":94490967443,"f":33},{"t":1686931,"n":"Tunnel","d":1686931,"h":98785934739,"f":33},{"t":1686931,"n":"MultiRateSymmetricDsl","d":1686931,"h":103080902035,"f":33},{"t":1686931,"n":"HighPerformanceSerialBus","d":1686931,"h":107375869331,"f":33},{"t":1686931,"n":"Wman","d":1686931,"h":111670836627,"f":33},{"t":1686931,"n":"Wwanpp","d":1686931,"h":115965803923,"f":33},{"t":1686931,"n":"Wwanpp2","d":1686931,"h":120260771219,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1686931,"h":124555738515,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1686931}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInterfaceType`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.OperationalStatus", ($self) => class OperationalStatus extends $.$spc.System.Enum
        {
            static Up = 1;
            static Down = 2;
            static Testing = 3;
            static Unknown = 4;
            static Dormant = 5;
            static NotPresent = 6;
            static LowerLayerDown = 7;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Up": 1n,
                    "Down": 2n,
                    "Testing": 3n,
                    "Unknown": 4n,
                    "Dormant": 5n,
                    "NotPresent": 6n,
                    "LowerLayerDown": 7n
                };
            }
            static $h = 1752467;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1752467,"n":"Up","d":1752467,"h":4296719763,"f":33},{"t":1752467,"n":"Down","d":1752467,"h":8591687059,"f":33},{"t":1752467,"n":"Testing","d":1752467,"h":12886654355,"f":33},{"t":1752467,"n":"Unknown","d":1752467,"h":17181621651,"f":33},{"t":1752467,"n":"Dormant","d":1752467,"h":21476588947,"f":33},{"t":1752467,"n":"NotPresent","d":1752467,"h":25771556243,"f":33},{"t":1752467,"n":"LowerLayerDown","d":1752467,"h":30066523539,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1752467,"h":34361490835,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1752467}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.OperationalStatus`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.PrefixOrigin", ($self) => class PrefixOrigin extends $.$spc.System.Enum
        {
            static Other = 0;
            static Manual = 1;
            static WellKnown = 2;
            static Dhcp = 3;
            static RouterAdvertisement = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Other": 0n,
                    "Manual": 1n,
                    "WellKnown": 2n,
                    "Dhcp": 3n,
                    "RouterAdvertisement": 4n
                };
            }
            static $h = 1883539;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1883539,"n":"Other","d":1883539,"h":4296850835,"f":33},{"t":1883539,"n":"Manual","d":1883539,"h":8591818131,"f":33},{"t":1883539,"n":"WellKnown","d":1883539,"h":12886785427,"f":33},{"t":1883539,"n":"Dhcp","d":1883539,"h":17181752723,"f":33},{"t":1883539,"n":"RouterAdvertisement","d":1883539,"h":21476720019,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1883539,"h":25771687315,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1883539}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.PrefixOrigin`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.ScopeLevel", ($self) => class ScopeLevel extends $.$spc.System.Enum
        {
            static None = 0;
            static Interface = 1;
            static Link = 2;
            static Subnet = 3;
            static Admin = 4;
            static Site = 5;
            static Organization = 8;
            static Global = 14;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Interface": 1n,
                    "Link": 2n,
                    "Subnet": 3n,
                    "Admin": 4n,
                    "Site": 5n,
                    "Organization": 8n,
                    "Global": 14n
                };
            }
            static $h = 1949075;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1949075,"n":"None","d":1949075,"h":4296916371,"f":33},{"t":1949075,"n":"Interface","d":1949075,"h":8591883667,"f":33},{"t":1949075,"n":"Link","d":1949075,"h":12886850963,"f":33},{"t":1949075,"n":"Subnet","d":1949075,"h":17181818259,"f":33},{"t":1949075,"n":"Admin","d":1949075,"h":21476785555,"f":33},{"t":1949075,"n":"Site","d":1949075,"h":25771752851,"f":33},{"t":1949075,"n":"Organization","d":1949075,"h":30066720147,"f":33},{"t":1949075,"n":"Global","d":1949075,"h":34361687443,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1949075,"h":38656654739,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1949075}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.ScopeLevel`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.SuffixOrigin", ($self) => class SuffixOrigin extends $.$spc.System.Enum
        {
            static Other = 0;
            static Manual = 1;
            static WellKnown = 2;
            static OriginDhcp = 3;
            static LinkLayerAddress = 4;
            static Random = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Other": 0n,
                    "Manual": 1n,
                    "WellKnown": 2n,
                    "OriginDhcp": 3n,
                    "LinkLayerAddress": 4n,
                    "Random": 5n
                };
            }
            static $h = 2014611;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2014611,"n":"Other","d":2014611,"h":4296981907,"f":33},{"t":2014611,"n":"Manual","d":2014611,"h":8591949203,"f":33},{"t":2014611,"n":"WellKnown","d":2014611,"h":12886916499,"f":33},{"t":2014611,"n":"OriginDhcp","d":2014611,"h":17181883795,"f":33},{"t":2014611,"n":"LinkLayerAddress","d":2014611,"h":21476851091,"f":33},{"t":2014611,"n":"Random","d":2014611,"h":25771818387,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2014611,"h":30066785683,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2014611}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.SuffixOrigin`; }
        });
        
        $asm.$str("$snn.System.Net.NetworkInformation.TcpState", ($self) => class TcpState extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Closed = 1;
            static Listen = 2;
            static SynSent = 3;
            static SynReceived = 4;
            static Established = 5;
            static FinWait1 = 6;
            static FinWait2 = 7;
            static CloseWait = 8;
            static Closing = 9;
            static LastAck = 10;
            static TimeWait = 11;
            static DeleteTcb = 12;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Closed": 1n,
                    "Listen": 2n,
                    "SynSent": 3n,
                    "SynReceived": 4n,
                    "Established": 5n,
                    "FinWait1": 6n,
                    "FinWait2": 7n,
                    "CloseWait": 8n,
                    "Closing": 9n,
                    "LastAck": 10n,
                    "TimeWait": 11n,
                    "DeleteTcb": 12n
                };
            }
            static $h = 2145683;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2145683,"n":"Unknown","d":2145683,"h":4297112979,"f":33},{"t":2145683,"n":"Closed","d":2145683,"h":8592080275,"f":33},{"t":2145683,"n":"Listen","d":2145683,"h":12887047571,"f":33},{"t":2145683,"n":"SynSent","d":2145683,"h":17182014867,"f":33},{"t":2145683,"n":"SynReceived","d":2145683,"h":21476982163,"f":33},{"t":2145683,"n":"Established","d":2145683,"h":25771949459,"f":33},{"t":2145683,"n":"FinWait1","d":2145683,"h":30066916755,"f":33},{"t":2145683,"n":"FinWait2","d":2145683,"h":34361884051,"f":33},{"t":2145683,"n":"CloseWait","d":2145683,"h":38656851347,"f":33},{"t":2145683,"n":"Closing","d":2145683,"h":42951818643,"f":33},{"t":2145683,"n":"LastAck","d":2145683,"h":47246785939,"f":33},{"t":2145683,"n":"TimeWait","d":2145683,"h":51541753235,"f":33},{"t":2145683,"n":"DeleteTcb","d":2145683,"h":55836720531,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2145683,"h":60131687827,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2145683}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.NetworkInformation.TcpState`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAvailabilityEventArgs", ($self) => class NetworkAvailabilityEventArgs extends $.$spc.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ get IsAvailable()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1359251;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46923777,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886261139,"f":1},"n":"IsAvailable","d":1359251,"h":8591293843,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":1359251,"h":4296326547,"f":8}],"h":1359251}; }
            static get $b() { return $.$spc.System.EventArgs; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAvailabilityEventArgs`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAddressChangedEventHandler", ($self) => class NetworkAddressChangedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ $sender, /*$.$spc.System.EventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 1228179;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":46923777}],"n":"Invoke","d":1228179,"h":8591162771,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":46923777},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":1228179,"h":12886130067,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":1228179,"h":17181097363,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1228179,"h":4296195475,"f":1}],"i":[57147393,113377281],"h":1228179}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAddressChangedEventHandler`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler", ($self) => class NetworkAvailabilityChangedEventHandler extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*void*/ Invoke(/*$.$spc.System.Nullable$$*/ $sender, /*$.$snn.System.Net.NetworkInformation.NetworkAvailabilityEventArgs*/ $e)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 1293715;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":65537,"p":[{"n":"sender","p":131073},{"n":"e","p":1359251}],"n":"Invoke","d":1293715,"h":8591228307,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"e","p":1359251},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":1293715,"h":12886195603,"f":129},{"r":65537,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":1293715,"h":17181162899,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":1293715,"h":4296261011,"f":1}],"i":[57147393,113377281],"h":1293715}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkAvailabilityChangedEventHandler`; }
        });
        
        $asm.$cls("$snn.System.Net.NetworkInformation.NetworkInformationException", ($self) => class NetworkInformationException extends $.$spc.System.ComponentModel.Win32Exception
        {
            $ctor$20()
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            $ctor$21(/*int*/ errorCode)
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            $ctor$22(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$14();
                {
                }
                return this;
            }
            /*int */ get ErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1490323;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":33292289,"h":1490323}; }
            static get $b() { return $.$spc.System.ComponentModel.Win32Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.NetworkInformationException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Console", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets"))