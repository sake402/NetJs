
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $sri) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Primitives", 
    {"h":49909,"f":"System.Net.Primitives","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Primitives","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Primitives","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snp.System.Net.IWebProxy", ($self) => class IWebProxy
        {
            static $h = 3588853;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":2933493,"g":{"r":0,"d":0,"h":17183458037,"f":50331905},"s":{"r":0,"d":0,"h":21478425333,"f":83886337},"n":"Credentials","o":"System$Net$IWebProxy$Credentials","d":3588853,"h":12888490741,"f":2097409}],"m":[{"r":1746220,"p":[{"n":"destination","p":1746220}],"n":"GetProxy","o":"System$Net$IWebProxy$GetProxy","d":3588853,"h":4298556149,"f":16777473},{"r":262145,"p":[{"n":"host","p":1746220}],"n":"IsBypassed","o":"System$Net$IWebProxy$IsBypassed","d":3588853,"h":8593523445,"f":16777473}],"h":3588853}; }
            static get $fullName() { return `System.Net.IWebProxy`; }
        });
        
        $asm.$cls("$snp.System.Net.ICredentials", ($self) => class ICredentials
        {
            static $h = 2933493;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3850997,"p":[{"n":"uri","p":1746220},{"n":"authType","p":1310721}],"n":"GetCredential","o":"System$Net$ICredentials$GetCredential","d":2933493,"h":4297900789,"f":16777473}],"h":2933493}; }
            static get $fullName() { return `System.Net.ICredentials`; }
        });
        
        $asm.$cls("$snp.System.Net.ICredentialsByHost", ($self) => class ICredentialsByHost
        {
            static $h = 2999029;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3850997,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"authenticationType","p":1310721}],"n":"GetCredential","o":"System$Net$ICredentialsByHost$GetCredential","d":2999029,"h":4297966325,"f":16777473}],"h":2999029}; }
            static get $fullName() { return `System.Net.ICredentialsByHost`; }
        });
        
        $asm.$cls("$snp.System.Net.EndPoint", ($self) => class EndPoint extends $.$$.System.Object
        {
            /*AddressFamily */ get AddressFamily()
            {
                throw $.$snp.System.NotImplemented.ByDesignWithMessage($.$snp.System.SR.net_PropertyNotImplementedException);
            }
            /*SocketAddress */ Serialize()
            {
                throw $.$snp.System.NotImplemented.ByDesignWithMessage($.$snp.System.SR.net_MethodNotImplementedException);
            }
            /*EndPoint */ Create(/*SocketAddress*/ socketAddress)
            {
                throw $.$snp.System.NotImplemented.ByDesignWithMessage($.$snp.System.SR.net_MethodNotImplementedException);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2605813;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":4506357,"g":{"r":0,"d":0,"h":8592540405,"f":50331777},"n":"AddressFamily","d":2605813,"h":4297573109,"f":2097281}],"m":[{"r":4375285,"n":"Serialize","d":2605813,"h":12887507701,"f":16777345},{"r":2605813,"p":[{"n":"socketAddress","p":4375285}],"n":"Create","d":2605813,"h":17182474997,"f":16777345}],"c":[{"n":".ctor","o":"$ctor$1","d":2605813,"h":21477442293,"f":16777220}],"h":2605813}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.EndPoint`; }
        });
        
        $asm.$cls("$snp.System.Net.TransportContext", ($self) => class TransportContext extends $.$$.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 5030645;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":5423861,"p":[{"n":"kind","p":5489397}],"n":"GetChannelBinding","d":5030645,"h":4299997941,"f":16777473}],"c":[{"n":".ctor","o":"$ctor$1","d":5030645,"h":8594965237,"f":16777220}],"h":5030645}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.TransportContext`; }
        });
        
        $asm.$cls("$snp.System.Security.Authentication.ExtendedProtection.ChannelBinding", ($self) => class ChannelBinding extends $.$$.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(true);
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ ownsHandle)
            {
                super.$ctor$3(ownsHandle);
                {
                }
                return this;
            }
            static $h = 5423861;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17185293045,"f":50331905},"n":"Size","d":5423861,"h":12890325749,"f":2097409}],"c":[{"n":".ctor","o":"$ctor$4","d":5423861,"h":4300391157,"f":16777220},{"p":[{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":5423861,"h":8595358453,"f":16777220}],"i":[57540609],"h":5423861}; }
            static get $b() { return $.$$.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ChannelBinding`; }
        });
        
        $asm.$cls("$snp.System.Net.HttpVersion", ($self) => class HttpVersion
        {
            /*Version*/ static Unknown = null;
            /*Version*/ static Version10 = null;
            /*Version*/ static Version11 = null;
            /*Version*/ static Version20 = null;
            /*Version*/ static Version30 = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.Unknown = new $.$$.System.Version().$ctor$4(0, 0);
                }
                {
                    this.Version10 = new $.$$.System.Version().$ctor$4(1, 0);
                }
                {
                    this.Version11 = new $.$$.System.Version().$ctor$4(1, 1);
                }
                {
                    this.Version20 = new $.$$.System.Version().$ctor$4(2, 0);
                }
                {
                    this.Version30 = new $.$$.System.Version().$ctor$4(3, 0);
                }
            }
            static $h = 2867957;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":144572417,"n":"Unknown","d":2867957,"h":4297835253,"f":4194337},{"t":144572417,"n":"Version10","d":2867957,"h":8592802549,"f":4194337},{"t":144572417,"n":"Version11","d":2867957,"h":12887769845,"f":4194337},{"t":144572417,"n":"Version20","d":2867957,"h":17182737141,"f":4194337},{"t":144572417,"n":"Version30","d":2867957,"h":21477704437,"f":4194337}],"h":2867957}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.HttpVersion`; }
        });
        
        $asm.$cls("$snp.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$$.System.Object.ReferenceEquals($.$snp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$$.System.Resources.ResourceManager().$ctor$3("System.Net.Primitives", $.$snp.System.SR.$type.Assembly);
                    $.$snp.System.SR.s_resourceManager = temp;
                }
                return $.$snp.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$snp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$snp.System.SR.resourceCulture = value;
            }
            static /*string */ get net_MethodNotImplementedException()
            {
                return "This method is not implemented by this class.";
            }
            static /*string */ get net_PropertyNotImplementedException()
            {
                return "This property is not implemented by this class.";
            }
            static /*string */ get net_InvalidAddressFamily()
            {
                return "The AddressFamily {0} is not valid for the {1} end point.";
            }
            static /*string */ Formatnet_InvalidAddressFamily(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("The AddressFamily {0} is not valid for the {1} end point.", arg1, arg2);
            }
            static /*string */ get net_InvalidSocketAddressSize()
            {
                return "The supplied {0} is an invalid size for the {1} end point.";
            }
            static /*string */ Formatnet_InvalidSocketAddressSize(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("The supplied {0} is an invalid size for the {1} end point.", arg1, arg2);
            }
            static /*string */ get net_sockets_invalid_optionValue_all()
            {
                return "The specified value is not valid.";
            }
            static /*string */ get net_emptystringcall()
            {
                return "The parameter '{0}' cannot be an empty string.";
            }
            static /*string */ Formatnet_emptystringcall(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("The parameter '{0}' cannot be an empty string.", arg1);
            }
            static /*string */ get dns_bad_ip_address()
            {
                return "An invalid IP address was specified.";
            }
            static /*string */ get net_bad_ip_network()
            {
                return "An invalid IP network was specified.";
            }
            static /*string */ get net_container_add_cookie()
            {
                return "An error occurred when adding a cookie to the container.";
            }
            static /*string */ get net_cookie_size()
            {
                return "The value size of the cookie is '{0}'. This exceeds the configured maximum size, which is '{1}'.";
            }
            static /*string */ Formatnet_cookie_size(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("The value size of the cookie is '{0}'. This exceeds the configured maximum size, which is '{1}'.", arg1, arg2);
            }
            static /*string */ get net_cookie_parse_header()
            {
                return "An error occurred when parsing the Cookie header for Uri '{0}'.";
            }
            static /*string */ Formatnet_cookie_parse_header(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("An error occurred when parsing the Cookie header for Uri '{0}'.", arg1);
            }
            static /*string */ get net_cookie_attribute()
            {
                return "The '{0}'='{1}' part of the cookie is invalid.";
            }
            static /*string */ Formatnet_cookie_attribute(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$$.System.String.Format$8("The '{0}'='{1}' part of the cookie is invalid.", arg1, arg2);
            }
            static /*string */ get net_cookie_format()
            {
                return "Cookie format error.";
            }
            static /*string */ get net_cookie_capacity_range()
            {
                return "'{0}' has to be greater than '{1}' and less than '{2}'.";
            }
            static /*string */ Formatnet_cookie_capacity_range(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$$.System.String.Format$7("'{0}' has to be greater than '{1}' and less than '{2}'.", arg1, arg2, arg3);
            }
            static /*string */ get net_collection_readonly()
            {
                return "The collection is read-only.";
            }
            static /*string */ get net_nodefaultcreds()
            {
                return "Default credentials cannot be supplied for the {0} authentication scheme.";
            }
            static /*string */ Formatnet_nodefaultcreds(/*object*/ arg1)
            {
                return $.$$.System.String.Format$9("Default credentials cannot be supplied for the {0} authentication scheme.", arg1);
            }
            static /*string */ get InvalidOperation_EnumFailedVersion()
            {
                return "Collection was modified after the enumerator was instantiated.";
            }
            static /*string */ get InvalidOperation_EnumOpCantHappen()
            {
                return "Enumeration has either not started or has already finished.";
            }
            static /*string */ get bad_endpoint_string()
            {
                return "An invalid IPEndPoint was specified.";
            }
            static /*string */ get PlatformNotSupported_NetPrimitives()
            {
                return "System.Net.Primitives is not supported on this platform.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$$.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$$.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$snp.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey)
            {
                if ($.$snp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$snp.System.SR.ResourceManager.GetString$1(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$snp.System.SR.GetResourceString$1(resourceKey);
                return $.$$.System.String.op_Equality(resourceKey, resourceString) || $.$$.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format$6(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$snp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$9(resourceFormat, p1);
            }
            static /*string */ Format$5(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$snp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$8(resourceFormat, p1, p2);
            }
            static /*string */ Format$4(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$snp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format$7(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$snp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$10(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$2(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$snp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1 ]));
                }
                return $.$$.System.String.Format$2(provider, resourceFormat, p1);
            }
            static /*string */ Format$1(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$snp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2 ]));
                }
                return $.$$.System.String.Format$1(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$snp.System.SR.UsingResourceKeys())
                {
                    return $.$$.System.String.Join$7(", ", $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$$.System.String.Format(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$snp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$$.System.String.Join$6(", ", args);
                    }
                    return $.$$.System.String.Format$3(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$snp.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 5686005;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":5686005}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$snp.System.Net.IPv4AddressHelper", ($self) => class IPv4AddressHelper
        {
            /*long*/ static Invalid = -1n;
            /*long*/ static MaxIPv4Value = 4294967295n;
            /*int*/ static Octal = 8;
            /*int*/ static Decimal = 10;
            /*int*/ static Hex = 16;
            /*int*/ static NumberOfLabels = 4;
            static /*ushort */ ToUShort(TChar, /*TChar*/ value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                return $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) ? $.$cast($.$box(value, TChar), $.$$.System.Char) : $.$cast($.$box(value, TChar), $.$$.System.Byte);
            }
            static /*int */ ParseHostNumber(TChar, /*ReadOnlySpan<TChar>*/ str, /*int*/ start, /*int*/ end)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*Span<byte>*/ let numbers = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 4/*NumberOfLabels*/, null);
                for(/*int*/ let i = 0; i < numbers.Length; ++i)
                {
                    /*int*/ let b = 0;
                    /*int*/ let ch;
                    for(; (start < end) && (ch = $.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, str.get_Item(start).$v)) !== /*.*/ 46 && ch !== /*:*/ 58; ++start)
                    {
                        b = (((((((b * 10) | 0)) + ch) | 0) - /*0*/ 48) | 0);
                    }
                    numbers.get_Item(i).$v = $.$cast(b, $.$$.System.Byte);
                    ++start;
                }
                return $.$$.System.Buffers.Binary.BinaryPrimitives.ReadInt32BigEndian($.$$.System.Span$$($.$$.System.Byte).op_Implicit(numbers));
            }
            static /*bool */ IsValid(TChar, /*TChar**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ allowIPv6, /*bool*/ notImplicitFile, /*bool*/ unknownScheme)
            {
                if (allowIPv6 || unknownScheme)
                {
                    return $.$snp.System.Net.IPv4AddressHelper.IsValidCanonical(TChar, name, start, end, allowIPv6, notImplicitFile);
                }
                else 
                {
                    return $.$snp.System.Net.IPv4AddressHelper.ParseNonCanonical(TChar, name, start, end, notImplicitFile) !== -1n;
                }
            }
            static /*bool */ IsValidCanonical(TChar, /*TChar**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ allowIPv6, /*bool*/ notImplicitFile)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let dots = 0;
                /*long*/ let number = 0n;
                /*bool*/ let haveNumber = false;
                /*bool*/ let firstCharIsZero = false;
                while(start < end.$v)
                {
                    /*int*/ let ch = $.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(start));
                    if (allowIPv6)
                    {
                        if (ch === /*]*/ 93 || ch === /*/*/ 47 || ch === /*%*/ 37)
                        {
                            break;
                        }
                    }
                    else if (ch === /*/*/ 47 || ch === /*\\*/ 92 || (notImplicitFile && (ch === /*:*/ 58 || ch === /*?*/ 63 || ch === /*#*/ 35)))
                    {
                        break;
                    }
                    /*uint*/ let parsedCharacter = ((((ch - /*0*/ 48) | 0)) >>> 0);
                    if (parsedCharacter < 10/*IPv4AddressHelper.Decimal*/)
                    {
                        if (!haveNumber && parsedCharacter === 0)
                        {
                            if ((((start + 1) | 0) < end.$v) && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((start + 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*0*/ 48)))
                            {
                                return false;
                            }
                            firstCharIsZero = true;
                        }
                        haveNumber = true;
                        number = number * BigInt(10/*IPv4AddressHelper.Decimal*/) + BigInt(parsedCharacter);
                        if (number > BigInt(255/*byte.MaxValue*/))
                        {
                            return false;
                        }
                    }
                    else if (ch === /*.*/ 46)
                    {
                        if (!haveNumber || (number > 0n && firstCharIsZero))
                        {
                            return false;
                        }
                        ++dots;
                        haveNumber = false;
                        number = 0n;
                        firstCharIsZero = false;
                    }
                    else 
                    {
                        return false;
                    }
                    ++start;
                }
                /*bool*/ let res = (dots === 3) && haveNumber;
                if (res)
                {
                    end.$v = start;
                }
                return res;
            }
            static /*long */ ParseNonCanonical(TChar, /*TChar**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ notImplicitFile)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let numberBase = 10/*IPv4AddressHelper.Decimal*/;
                /*int*/ let ch = 0;
                /*Span<long>*/ let parts = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Int64, 3, null);
                /*long*/ let currentValue = 0n;
                /*bool*/ let atLeastOneChar = false;
                /*int*/ let dotCount = 0;
                /*int*/ let current = start;
                for(; current < end.$v; current++)
                {
                    ch = $.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(current));
                    currentValue = 0n;
                    numberBase = 10/*IPv4AddressHelper.Decimal*/;
                    if (ch === /*0*/ 48)
                    {
                        current++;
                        atLeastOneChar = true;
                        if (current < end.$v)
                        {
                            ch = $.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(current));
                            if (ch === /*x*/ 120 || ch === /*X*/ 88)
                            {
                                numberBase = 16/*IPv4AddressHelper.Hex*/;
                                current++;
                                atLeastOneChar = false;
                            }
                            else 
                            {
                                numberBase = 8/*IPv4AddressHelper.Octal*/;
                            }
                        }
                    }
                    for(; current < end.$v; current++)
                    {
                        ch = $.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(current));
                        /*int*/ let digitValue = $.$snp.System.HexConverter.FromChar(ch);
                        if (digitValue >= numberBase)
                        {
                            break;
                        }
                        currentValue = (currentValue * BigInt(numberBase)) + BigInt(digitValue);
                        if (currentValue > 4294967295n)
                        {
                            return -1n;
                        }
                        atLeastOneChar = true;
                    }
                    if (current < end.$v && ch === /*.*/ 46)
                    {
                        if (dotCount >= 3 || !atLeastOneChar || currentValue > 255n)
                        {
                            return -1n;
                        }
                        parts.get_Item(dotCount).$v = currentValue;
                        dotCount++;
                        atLeastOneChar = false;
                        continue;
                    }
                    break;
                }
                if (!atLeastOneChar)
                {
                    return -1n;
                }
                else if (current >= end.$v)
                {
                }
                else if (ch === /*/*/ 47 || ch === /*\\*/ 92 || (notImplicitFile && (ch === /*:*/ 58 || ch === /*?*/ 63 || ch === /*#*/ 35)))
                {
                    end.$v = current;
                }
                else 
                {
                    return -1n;
                }
                switch(dotCount)
                {
                    case 0:
                    return currentValue;
                    case 1:
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(0).$v <= 255n, "parts[0] <= 0xFF");
                    if (currentValue > 16777215n)
                    {
                        return -1n;
                    }
                    return (BigInt.asIntN(64, parts.get_Item(0).$v << 24n)) | currentValue;
                    case 2:
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(0).$v <= 255n, "parts[0] <= 0xFF");
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(1).$v <= 255n, "parts[1] <= 0xFF");
                    if (currentValue > 65535n)
                    {
                        return -1n;
                    }
                    return (BigInt.asIntN(64, parts.get_Item(0).$v << 24n)) | (BigInt.asIntN(64, parts.get_Item(1).$v << 16n)) | currentValue;
                    case 3:
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(0).$v <= 255n, "parts[0] <= 0xFF");
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(1).$v <= 255n, "parts[1] <= 0xFF");
                    $.$$.System.Diagnostics.Debug.Assert$2(parts.get_Item(2).$v <= 255n, "parts[2] <= 0xFF");
                    if (currentValue > 255n)
                    {
                        return -1n;
                    }
                    return (BigInt.asIntN(64, parts.get_Item(0).$v << 24n)) | (BigInt.asIntN(64, parts.get_Item(1).$v << 16n)) | (BigInt.asIntN(64, parts.get_Item(2).$v << 8n)) | currentValue;
                    default:
                    return -1n;
                }
            }
            static $h = 3457781;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":589825,"p":[{"n":"value","p":(TChar) => TChar.$h}],"g":["TChar"],"n":"ToUShort","d":3457781,"h":30068228853,"f":16908328},{"r":655361,"p":[{"n":"str","p":(TChar) => $.$$.System.ReadOnlySpan$$(TChar).$h},{"n":"start","p":655361},{"n":"end","p":655361}],"g":["TChar"],"n":"ParseHostNumber","d":3457781,"h":34363196149,"f":16908328},{"r":262145,"p":[{"n":"name","p":(TChar) => $.$typePointer(TChar).$h},{"n":"start","p":655361},{"n":"end","p":655361,"f":4},{"n":"allowIPv6","p":262145},{"n":"notImplicitFile","p":262145},{"n":"unknownScheme","p":262145}],"g":["TChar"],"n":"IsValid","d":3457781,"h":38658163445,"f":16908328},{"r":262145,"p":[{"n":"name","p":(TChar) => $.$typePointer(TChar).$h},{"n":"start","p":655361},{"n":"end","p":655361,"f":4},{"n":"allowIPv6","p":262145},{"n":"notImplicitFile","p":262145}],"g":["TChar"],"n":"IsValidCanonical","d":3457781,"h":42953130741,"f":16908328},{"r":917505,"p":[{"n":"name","p":(TChar) => $.$typePointer(TChar).$h},{"n":"start","p":655361},{"n":"end","p":655361,"f":4},{"n":"notImplicitFile","p":262145}],"g":["TChar"],"n":"ParseNonCanonical","d":3457781,"h":47248098037,"f":16908328}],"l":[{"t":917505,"n":"Invalid","d":3457781,"h":4298425077,"f":4194344},{"t":917505,"n":"MaxIPv4Value","d":3457781,"h":8593392373,"f":4194338},{"t":655361,"n":"Octal","d":3457781,"h":12888359669,"f":4194338},{"t":655361,"n":"Decimal","d":3457781,"h":17183326965,"f":4194338},{"t":655361,"n":"Hex","d":3457781,"h":21478294261,"f":4194338},{"t":655361,"n":"NumberOfLabels","d":3457781,"h":25773261557,"f":4194338}],"h":3457781}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.IPv4AddressHelper`; }
        });
        
        $asm.$cls("$snp.System.Net.Cache.RequestCachePolicy", ($self) => class RequestCachePolicy extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                    this.Level = 0/*RequestCacheLevel.Default*/;
                }
                return this;
            }
            $ctor$2(/*RequestCacheLevel*/ level)
            {
                super.$ctor();
                {
                    if (level < 0/*RequestCacheLevel.Default*/ || level > 6/*RequestCacheLevel.NoCacheNoStore*/)
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("level");
                    }
                    this.Level = level;
                }
                return this;
            }
            /*RequestCacheLevel*/ Level = 0;
            static/*conventional*/ /*string */ ToString()
            {
                return "Level:" + $.$$.System.Enum.ToStringT($.$snp.System.Net.Cache.RequestCacheLevel, $.$$.System.UInt32, this.Level);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.Cache.RequestCachePolicy.ToString.apply(this, arguments); }
            //default member initializer
            constructor()
            {
                super();
                this.Level = 0;
            }
            static $h = 1098485;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1032949,"g":{"r":0,"d":0,"h":21475934965,"f":50331649},"n":"Level","d":1098485,"h":17180967669,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":1098485,"h":25770902261,"f":16809985}],"c":[{"n":".ctor","o":"$ctor$1","d":1098485,"h":4296065781,"f":16777217},{"p":[{"n":"level","p":1032949}],"n":".ctor","o":"$ctor$2","d":1098485,"h":8591033077,"f":16777217}],"h":1098485}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Cache.RequestCachePolicy`; }
        });
        
        $asm.$cls("$snp.System.Net.CookieComparer", ($self) => class CookieComparer
        {
            static /*bool */ Equals$2(/*Cookie*/ left, /*Cookie*/ right)
            {
                if (!$.$$.System.String.Equals$2(left.Name, right.Name, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                if (!$.$snp.System.Net.CookieComparer.EqualDomains($.$$.System.String.op_Implicit(left.Domain), $.$$.System.String.op_Implicit(right.Domain)))
                {
                    return false;
                }
                return $.$$.System.String.Equals$2(left.Path, right.Path, 4/*StringComparison.Ordinal*/);
            }
            static /*bool */ EqualDomains(/*ReadOnlySpan<char>*/ left, /*ReadOnlySpan<char>*/ right)
            {
                return $.$$.System.MemoryExtensions.Equals$2($.$snp.System.Net.CookieComparer.StripLeadingDot(left), $.$snp.System.Net.CookieComparer.StripLeadingDot(right), 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            static /*ReadOnlySpan<char> */ StripLeadingDot(/*ReadOnlySpan<char>*/ s)
            {
                let $t1 = s;
                return $.$$.System.MemoryExtensions.StartsWith$4($.$$.System.Char, s, /*.*/ 46) ? $t1.Slice(1, $t1.Length - 1) : s;
            }
            static $h = 1360629;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"left","p":1164021},{"n":"right","p":1164021}],"n":"Equals","o":"@$2","d":1360629,"h":4296327925,"f":16777256},{"r":262145,"p":[{"n":"left","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"right","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"EqualDomains","d":1360629,"h":8591295221,"f":16777256},{"r":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h,"p":[{"n":"s","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"StripLeadingDot","d":1360629,"h":12886262517,"f":16777256}],"h":1360629}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.CookieComparer`; }
        });
        
        $asm.$cls("$snp.System.Net.CookieFields", ($self) => class CookieFields
        {
            /*string*/ static CommentAttributeName = null;
            /*string*/ static CommentUrlAttributeName = null;
            /*string*/ static DiscardAttributeName = null;
            /*string*/ static DomainAttributeName = null;
            /*string*/ static ExpiresAttributeName = null;
            /*string*/ static MaxAgeAttributeName = null;
            /*string*/ static PathAttributeName = null;
            /*string*/ static PortAttributeName = null;
            /*string*/ static SecureAttributeName = null;
            /*string*/ static VersionAttributeName = null;
            /*string*/ static HttpOnlyAttributeName = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.CommentAttributeName = "Comment";
                }
                {
                    this.CommentUrlAttributeName = "CommentURL";
                }
                {
                    this.DiscardAttributeName = "Discard";
                }
                {
                    this.DomainAttributeName = "Domain";
                }
                {
                    this.ExpiresAttributeName = "Expires";
                }
                {
                    this.MaxAgeAttributeName = "Max-Age";
                }
                {
                    this.PathAttributeName = "Path";
                }
                {
                    this.PortAttributeName = "Port";
                }
                {
                    this.SecureAttributeName = "Secure";
                }
                {
                    this.VersionAttributeName = "Version";
                }
                {
                    this.HttpOnlyAttributeName = "HttpOnly";
                }
            }
            static $h = 1557237;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"CommentAttributeName","d":1557237,"h":4296524533,"f":4194344},{"t":1310721,"n":"CommentUrlAttributeName","d":1557237,"h":8591491829,"f":4194344},{"t":1310721,"n":"DiscardAttributeName","d":1557237,"h":12886459125,"f":4194344},{"t":1310721,"n":"DomainAttributeName","d":1557237,"h":17181426421,"f":4194344},{"t":1310721,"n":"ExpiresAttributeName","d":1557237,"h":21476393717,"f":4194344},{"t":1310721,"n":"MaxAgeAttributeName","d":1557237,"h":25771361013,"f":4194344},{"t":1310721,"n":"PathAttributeName","d":1557237,"h":30066328309,"f":4194344},{"t":1310721,"n":"PortAttributeName","d":1557237,"h":34361295605,"f":4194344},{"t":1310721,"n":"SecureAttributeName","d":1557237,"h":38656262901,"f":4194344},{"t":1310721,"n":"VersionAttributeName","d":1557237,"h":42951230197,"f":4194344},{"t":1310721,"n":"HttpOnlyAttributeName","d":1557237,"h":47246197493,"f":4194344}],"h":1557237}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.CookieFields`; }
        });
        
        $asm.$cls("$snp.System.Net.IPAddressParser", ($self) => class IPAddressParser
        {
            /*int*/ static MaxIPv4StringLength = 15;
            /*int*/ static MaxIPv6StringLength = 65;
            static /*bool */ IsValid(TChar, /*ReadOnlySpan<TChar>*/ ipSpan)
            {
                /*fixed*/ 
                {
                    /*TChar**/ let ipStringPtr = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference(TChar, ipSpan);
                    if ($.$$.System.MemoryExtensions.Contains$2(TChar, ipSpan, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58)))
                    {
                        return $.$snp.System.Net.IPv6AddressHelper.IsValidStrict(TChar, ipStringPtr, 0, ipSpan.Length);
                    }
                    else 
                    {
                        /*int*/ let end = ipSpan.Length;
                        /*long*/ let address = $.$snp.System.Net.IPv4AddressHelper.ParseNonCanonical(TChar, ipStringPtr, 0, $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32), true);
                        return address !== -1n && end === ipSpan.Length;
                    }
                }
            }
            static /*IPAddress? */ Parse(TChar, /*ReadOnlySpan<TChar>*/ ipSpan, /*bool*/ tryParse)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type), "typeof(TChar) == typeof(byte) || typeof(TChar) == typeof(char)");
                /*long*/ let address;
                if ($.$$.System.MemoryExtensions.Contains$2(TChar, ipSpan, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58)))
                {
                    /*Span<ushort>*/ let numbers = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.UInt16, 8/*IPAddressParserStatics.IPv6AddressShorts*/, null);
                    numbers.Clear();
                    /*uint*/ let scope;
                    if ($.$snp.System.Net.IPAddressParser.TryParseIPv6(TChar, ipSpan, numbers, 8/*IPAddressParserStatics.IPv6AddressShorts*/, $.$ref(() => scope, ($v) => scope = $v, $.$$.System.UInt32)))
                    {
                        return new $.$snp.System.Net.IPAddress().$ctor$7($.$$.System.Span$$($.$$.System.UInt16).op_Implicit(numbers), scope);
                    }
                }
                else if ($.$snp.System.Net.IPAddressParser.TryParseIpv4(TChar, ipSpan, $.$ref(() => address, ($v) => address = $v, $.$$.System.Int64)))
                {
                    return new $.$snp.System.Net.IPAddress().$ctor$4(address);
                }
                if (tryParse)
                {
                    return null;
                }
                throw new $.$$.System.FormatException().$ctor$11($.$snp.System.SR.dns_bad_ip_address, new $.$snp.System.Net.Sockets.SocketException().$ctor$27(10022/*SocketError.InvalidArgument*/));
            }
            static /*bool */ TryParseIpv4(TChar, /*ReadOnlySpan<TChar>*/ ipSpan, /*out long*/ address)
            {
                /*int*/ let end = ipSpan.Length;
                /*long*/ let tmpAddr;
                /*fixed*/ 
                {
                    /*TChar**/ let ipStringPtr = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference(TChar, ipSpan);
                    tmpAddr = $.$snp.System.Net.IPv4AddressHelper.ParseNonCanonical(TChar, ipStringPtr, 0, $.$ref(() => end, ($v) => end = $v, $.$$.System.Int32), true);
                }
                if (tmpAddr !== -1n && end === ipSpan.Length)
                {
                    address.$v = BigInt(($.$snp.System.Net.IPAddress.HostToNetworkOrder$1($.$cast(tmpAddr, $.$$.System.Int32)) >>> 0));
                    return true;
                }
                address.$v = 0n;
                return false;
            }
            static /*bool */ TryParseIPv6(TChar, /*ReadOnlySpan<TChar>*/ ipSpan, /*Span<ushort>*/ numbers, /*int*/ numbersLength, /*out uint*/ scope)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                $.$$.System.Diagnostics.Debug.Assert$2(numbersLength >= 8/*IPAddressParserStatics.IPv6AddressShorts*/, "numbersLength >= IPAddressParserStatics.IPv6AddressShorts");
                /*fixed*/ 
                {
                    /*TChar**/ let ipStringPtr = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference(TChar, ipSpan);
                    if (!$.$snp.System.Net.IPv6AddressHelper.IsValidStrict(TChar, ipStringPtr, 0, ipSpan.Length))
                    {
                        scope.$v = 0;
                        return false;
                    }
                }
                /*ReadOnlySpan<TChar>*/ let scopeIdSpan;
                $.$snp.System.Net.IPv6AddressHelper.Parse(TChar, ipSpan, numbers, $.$ref(() => scopeIdSpan, ($v) => scopeIdSpan = $v, $.$$.System.ReadOnlySpan$$(TChar)));
                if (scopeIdSpan.Length > 1)
                {
                    /*bool*/ let parsedNumericScope;
                    scopeIdSpan = scopeIdSpan.Slice$1(1);
                    if ($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type))
                    {
                        /*ReadOnlySpan<byte>*/ let castScopeIdSpan = $.$$.System.Runtime.InteropServices.MemoryMarshal.Cast(TChar, $.$$.System.Byte, scopeIdSpan);
                        parsedNumericScope = $.$$.System.UInt32.TryParse(castScopeIdSpan, 0/*NumberStyles.None*/, $.$$.System.Globalization.CultureInfo.InvariantCulture, scope);
                    }
                    else 
                    {
                        /*ReadOnlySpan<char>*/ let castScopeIdSpan = $.$$.System.Runtime.InteropServices.MemoryMarshal.Cast(TChar, $.$$.System.Char, scopeIdSpan);
                        parsedNumericScope = $.$$.System.UInt32.TryParse$3(castScopeIdSpan, 0/*NumberStyles.None*/, $.$$.System.Globalization.CultureInfo.InvariantCulture, scope);
                    }
                    if (parsedNumericScope)
                    {
                        return true;
                    }
                    else 
                    {
                        /*uint*/ let interfaceIndex = $.$snp.System.Net.NetworkInformation.InterfaceInfoPal.InterfaceNameToIndex(TChar, scopeIdSpan);
                        if (interfaceIndex > 0)
                        {
                            scope.$v = interfaceIndex;
                            return true;
                        }
                    }
                }
                scope.$v = 0;
                return true;
            }
            static /*int */ FormatIPv4Address(TChar, /*uint*/ address, /*Span<TChar>*/ addressString)
            {
                address = ($.$snp.System.Net.IPAddress.NetworkToHostOrder$1((address | 0)) >>> 0);
                /*int*/ let pos = FormatByte(address >>> 24, addressString);
                addressString.get_Item(pos++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*.*/ 46);
                pos += FormatByte(address >>> 16, addressString.Slice$1(pos));
                addressString.get_Item(pos++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*.*/ 46);
                pos += FormatByte(address >>> 8, addressString.Slice$1(pos));
                addressString.get_Item(pos++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*.*/ 46);
                pos += FormatByte(address, addressString.Slice$1(pos));
                return pos;
                /*static int*/  function FormatByte(/*uint*/ number, /*Span<TChar>*/ addressString)
                {
                    number &= 255;
                    if (number >= 10)
                    {
                        /*uint*/ let hundreds, tens;
                        if (number >= 100)
                        {
                            /*uint*/ let hundredsAndTens;
        $.$tupleUnpack(($tp) =>
                            {
                                hundredsAndTens = $tp.Item1;
                                number = $tp.Item2;
                            }).$v = $.$$.System.Math.DivRem$9(number, 10);
                            $.$tupleUnpack(($tp) =>
                            {
                                hundreds = $tp.Item1;
                                tens = $tp.Item2;
                            }).$v = $.$$.System.Math.DivRem$9(hundredsAndTens, 10);
                            addressString.get_Item(2).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.UInt32, ((/*0*/ 48 + number) >>> 0));
                            addressString.get_Item(1).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.UInt32, ((/*0*/ 48 + tens) >>> 0));
                            addressString.get_Item(0).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.UInt32, ((/*0*/ 48 + hundreds) >>> 0));
                            return 3;
                        }
                        $.$tupleUnpack(($tp) =>
                        {
                            tens = $tp.Item1;
                            number = $tp.Item2;
                        }).$v = $.$$.System.Math.DivRem$9(number, 10);
                        addressString.get_Item(1).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.UInt32, ((/*0*/ 48 + number) >>> 0));
                        addressString.get_Item(0).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.UInt32, ((/*0*/ 48 + tens) >>> 0));
                        return 2;
                    }
                    addressString.get_Item(0).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.UInt32, ((/*0*/ 48 + number) >>> 0));
                    return 1;
                }
            }
            static /*int */ FormatIPv6Address(TChar, /*ushort[]*/ address, /*uint*/ scopeId, /*Span<TChar>*/ destination)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type), "typeof(TChar) == typeof(byte) || typeof(TChar) == typeof(char)");
                /*int*/ let pos = 0;
                if ($.$snp.System.Net.IPv6AddressHelper.ShouldHaveIpv4Embedded($.$$.System.ReadOnlySpan$$($.$$.System.UInt16).op_Implicit$1(address)))
                {
                    AppendSections($.$$.System.Span$$($.$$.System.UInt16).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.UInt16, address, 0, 6)), destination, $.$ref(() => pos, ($v) => pos = $v, $.$$.System.Int32));
                    if (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(destination.get_Item(((pos - 1) | 0)).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58)))
                    {
                        destination.get_Item(pos++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58);
                    }
                    pos += $.$snp.System.Net.IPAddressParser.FormatIPv4Address(TChar, $.$snp.System.Net.IPAddressParser.ExtractIPv4Address(address), destination.Slice$1(pos));
                }
                else 
                {
                    AppendSections($.$$.System.Span$$($.$$.System.UInt16).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.UInt16, address, 0, 8)), destination, $.$ref(() => pos, ($v) => pos = $v, $.$$.System.Int32));
                }
                if (scopeId !== 0)
                {
                    destination.get_Item(pos++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*%*/ 37);
                    /*int*/ let bytesWritten;
                    /*bool*/ let formatted = $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type) ? $.$$.System.UInt32.TryFormat.call(scopeId, $.$$.System.Runtime.InteropServices.MemoryMarshal.Cast$1(TChar, $.$$.System.Byte, destination).Slice$1(pos), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null) : $.$$.System.UInt32.TryFormat$1.call(scopeId, $.$$.System.Runtime.InteropServices.MemoryMarshal.Cast$1(TChar, $.$$.System.Char, destination).Slice$1(pos), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                    $.$$.System.Diagnostics.Debug.Assert$2(formatted, "formatted");
                    pos += bytesWritten;
                }
                return pos;
                /*static void*/  function AppendSections(/*ReadOnlySpan<ushort>*/ address, /*Span<TChar>*/ destination, /*ref int*/ offset)
                {
                    const { Item1: zeroStart, Item2: zeroEnd } = $.$snp.System.Net.IPv6AddressHelper.FindCompressionRange(address);
                    /*bool*/ let needsColon = false;
                    if (zeroStart >= 0)
                    {
                        for(/*int*/ let i = 0; i < zeroStart; i++)
                        {
                            if (needsColon)
                            {
                                destination.get_Item(offset.$v++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58);
                            }
                            needsColon = true;
                            AppendHex(address.get_Item(i).$v, destination, offset);
                        }
                        destination.get_Item(offset.$v++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58);
                        destination.get_Item(offset.$v++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58);
                        needsColon = false;
                    }
                    for(/*int*/ let i = zeroEnd; i < address.Length; i++)
                    {
                        if (needsColon)
                        {
                            destination.get_Item(offset.$v++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58);
                        }
                        needsColon = true;
                        AppendHex(address.get_Item(i).$v, destination, offset);
                    }
                }
                /*static void*/  function AppendHex(/*ushort*/ value, /*Span<TChar>*/ destination, /*ref int*/ offset)
                {
                    if ((value & 65520) !== 0)
                    {
                        if ((value & 65280) !== 0)
                        {
                            if ((value & 61440) !== 0)
                            {
                                destination.get_Item(offset.$v++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, $.$snp.System.HexConverter.ToCharLower(value >>> 12));
                            }
                            destination.get_Item(offset.$v++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, $.$snp.System.HexConverter.ToCharLower(value >>> 8));
                        }
                        destination.get_Item(offset.$v++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, $.$snp.System.HexConverter.ToCharLower(value >>> 4));
                    }
                    destination.get_Item(offset.$v++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, $.$snp.System.HexConverter.ToCharLower(value));
                }
            }
            static /*uint */ ExtractIPv4Address(/*ushort[]*/ address)
            {
                /*uint*/ let ipv4address = ($.$$.System.Array.$ReadT1.call(address, 6) << 16) >>> 0 | $.$$.System.Array.$ReadT1.call(address, 7);
                return ($.$snp.System.Net.IPAddress.HostToNetworkOrder$1((ipv4address | 0)) >>> 0);
            }
            static $h = 3195637;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"ipSpan","p":(TChar) => $.$$.System.ReadOnlySpan$$(TChar).$h}],"g":["TChar"],"n":"IsValid","d":3195637,"h":12888097525,"f":16908321},{"r":3064565,"p":[{"n":"ipSpan","p":(TChar) => $.$$.System.ReadOnlySpan$$(TChar).$h},{"n":"tryParse","p":262145}],"g":["TChar"],"n":"Parse","d":3195637,"h":17183064821,"f":16908328},{"r":262145,"p":[{"n":"ipSpan","p":(TChar) => $.$$.System.ReadOnlySpan$$(TChar).$h},{"n":"address","p":917505,"f":2}],"g":["TChar"],"n":"TryParseIpv4","d":3195637,"h":21478032117,"f":16908322},{"r":262145,"p":[{"n":"ipSpan","p":(TChar) => $.$$.System.ReadOnlySpan$$(TChar).$h},{"n":"numbers","p":$.$$.System.Span$$($.$$.System.UInt16).$h},{"n":"numbersLength","p":655361},{"n":"scope","p":720897,"f":2}],"g":["TChar"],"n":"TryParseIPv6","d":3195637,"h":25772999413,"f":16908322},{"r":655361,"p":[{"n":"address","p":720897},{"n":"addressString","p":(TChar) => $.$$.System.Span$$(TChar).$h}],"g":["TChar"],"n":"FormatIPv4Address","d":3195637,"h":30067966709,"f":16908328},{"r":655361,"p":[{"n":"address","p":$.$typeArray($.$$.System.UInt16).$h},{"n":"scopeId","p":720897},{"n":"destination","p":(TChar) => $.$$.System.Span$$(TChar).$h}],"g":["TChar"],"n":"FormatIPv6Address","d":3195637,"h":34362934005,"f":16908328},{"r":720897,"p":[{"n":"address","p":$.$typeArray($.$$.System.UInt16).$h}],"n":"ExtractIPv4Address","d":3195637,"h":38657901301,"f":16777250}],"l":[{"t":655361,"n":"MaxIPv4StringLength","d":3195637,"h":4298162933,"f":4194344},{"t":655361,"n":"MaxIPv6StringLength","d":3195637,"h":8593130229,"f":4194344}],"h":3195637}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.IPAddressParser`; }
        });
        
        $asm.$cls("$snp.System.Net.IPv6AddressHelper", ($self) => class IPv6AddressHelper
        {
            /*int*/ static Hex = 16;
            /*int*/ static NumberOfLabels = 8;
            static /*(int longestSequenceStart, int longestSequenceLength) */ FindCompressionRange(/*ReadOnlySpan<ushort>*/ numbers)
            {
                /*int*/ let longestSequenceLength = 0, longestSequenceStart = -1, currentSequenceLength = 0;
                for(/*int*/ let i = 0; i < numbers.Length; i++)
                {
                    if (numbers.get_Item(i).$v === 0)
                    {
                        currentSequenceLength++;
                        if (currentSequenceLength > longestSequenceLength)
                        {
                            longestSequenceLength = currentSequenceLength;
                            longestSequenceStart = ((((i - currentSequenceLength) | 0) + 1) | 0);
                        }
                    }
                    else 
                    {
                        currentSequenceLength = 0;
                    }
                }
                return longestSequenceLength > 1 ? new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(longestSequenceStart, ((longestSequenceStart + longestSequenceLength) | 0)) : new ($.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32))().$ctor$3(-1, 0);
            }
            static /*bool */ ShouldHaveIpv4Embedded(/*ReadOnlySpan<ushort>*/ numbers)
            {
                if (numbers.get_Item(0).$v === 0 && numbers.get_Item(1).$v === 0 && numbers.get_Item(2).$v === 0 && numbers.get_Item(3).$v === 0 && numbers.get_Item(6).$v !== 0)
                {
                    if (numbers.get_Item(4).$v === 0 && (numbers.get_Item(5).$v === 0 || numbers.get_Item(5).$v === 65535))
                    {
                        return true;
                    }
                    else if (numbers.get_Item(4).$v === 65535 && numbers.get_Item(5).$v === 0)
                    {
                        return true;
                    }
                }
                return numbers.get_Item(4).$v === 0 && numbers.get_Item(5).$v === 24318;
            }
            static /*bool */ IsValidStrict(TChar, /*TChar**/ name, /*int*/ start, /*int*/ end)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let sequenceCount = 0;
                /*int*/ let sequenceLength = 0;
                /*bool*/ let haveCompressor = false;
                /*bool*/ let haveIPv4Address = false;
                /*bool*/ let expectingNumber = true;
                /*int*/ let lastSequence = 1;
                /*bool*/ let needsClosingBracket = false;
                if (start < end && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(start), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*[*/ 91)))
                {
                    start++;
                    needsClosingBracket = true;
                    $.$$.System.Diagnostics.Debug.Assert$2(start < end, "start < end");
                }
                if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(start), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58)) && (((start + 1) | 0) >= end || TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(name.GetAt(((start + 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58))))
                {
                    return false;
                }
                /*int*/ let i;
                for(i = start; i < end; ++i)
                {
                    /*int*/ let currentCh = $.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(i));
                    if ($.$snp.System.HexConverter.IsHexChar(currentCh))
                    {
                        ++sequenceLength;
                        expectingNumber = false;
                    }
                    else 
                    {
                        if (sequenceLength > 4)
                        {
                            return false;
                        }
                        if (sequenceLength !== 0)
                        {
                            ++sequenceCount;
                            lastSequence = ((i - sequenceLength) | 0);
                            sequenceLength = 0;
                        }
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? currentCh)
                            {
                                case /*%*/ 37:
                                while(((i + 1) | 0) < end)
                                {
                                    i++;
                                    if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(i), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93)))
                                    {
                                        $switchJumpState1 = /*]*/ 93; /*goto case ']'*/
                                        continue $switchJumpStart1;
                                    }
                                    else if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(i), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*/*/ 47)))
                                    {
                                        $switchJumpState1 = /*/*/ 47; /*goto case '/'*/
                                        continue $switchJumpStart1;
                                    }
                                }
                                break;
                                case /*]*/ 93:
                                if (!needsClosingBracket)
                                {
                                    return false;
                                }
                                needsClosingBracket = false;
                                if (((i + 1) | 0) < end && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(name.GetAt(((i + 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58)))
                                {
                                    return false;
                                }
                                if (((i + 3) | 0) < end && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((i + 2) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*0*/ 48)) && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((i + 3) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*x*/ 120)))
                                {
                                    i += 4;
                                    for(; i < end; i++)
                                    {
                                        /*int*/ let ch = $.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(i));
                                        if (!$.$snp.System.HexConverter.IsHexChar(ch))
                                        {
                                            return false;
                                        }
                                    }
                                }
                                else 
                                {
                                    i += 2;
                                    for(; i < end; i++)
                                    {
                                        if (!$.$$.System.Char.IsAsciiDigit($.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(i))))
                                        {
                                            return false;
                                        }
                                    }
                                }
                                continue;
                                case /*:*/ 58:
                                if ((i > 0) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((i - 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58))))
                                {
                                    if (haveCompressor)
                                    {
                                        return false;
                                    }
                                    haveCompressor = true;
                                    expectingNumber = false;
                                }
                                else 
                                {
                                    expectingNumber = true;
                                }
                                break;
                                case /*/*/ 47:
                                return false;
                                case /*.*/ 46:
                                if (haveIPv4Address)
                                {
                                    return false;
                                }
                                i = end;
                                if (!$.$snp.System.Net.IPv4AddressHelper.IsValid(TChar, name, lastSequence, $.$ref(() => i, ($v) => i = $v, $.$$.System.Int32), true, false, false))
                                {
                                    return false;
                                }
                                ++sequenceCount;
                                lastSequence = ((i - sequenceLength) | 0);
                                sequenceLength = 0;
                                haveIPv4Address = true;
                                --i;
                                break;
                                default:
                                return false;
                            }
                            break;
                        }
                        sequenceLength = 0;
                    }
                }
                if (sequenceLength !== 0)
                {
                    if (sequenceLength > 4)
                    {
                        return false;
                    }
                    ++sequenceCount;
                }
                /*int*/ let ExpectedSequenceCount = 8;
                return !expectingNumber && (haveCompressor ? (sequenceCount < ExpectedSequenceCount) : (sequenceCount === ExpectedSequenceCount)) && !needsClosingBracket;
            }
            static /*void */ Parse(TChar, /*ReadOnlySpan<TChar>*/ address, /*scoped Span<ushort>*/ numbers, /*out ReadOnlySpan<TChar>*/ scopeId)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Char.$type) || $.$$.System.Type.op_Equality$1(TChar.$type, $.$$.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let number = 0;
                /*int*/ let currentCh;
                /*int*/ let index = 0;
                /*int*/ let compressorIndex = -1;
                /*bool*/ let numberIsValid = true;
                scopeId.$v = $.$$.System.ReadOnlySpan$$(TChar).Empty;
                for(/*int*/ let i = (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(address.get_Item(0).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*[*/ 91)) ? 1 : 0); i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93)); )
                {
                    currentCh = $.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, address.get_Item(i).$v);
                    switch(currentCh)
                    {
                        case /*%*/ 37:
                        if (numberIsValid)
                        {
                            numbers.get_Item(index++).$v = $.$cast(number, $.$$.System.UInt16);
                            numberIsValid = false;
                        }
                        /*int*/ let scopeStart = i;
                        for(++i; i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93)) && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*/*/ 47)); ++i)
                        {
                        }
                        scopeId.$v = address.Slice(scopeStart, ((i - scopeStart) | 0));
                        for(; i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93)); ++i)
                        {
                        }
                        break;
                        case /*:*/ 58:
                        numbers.get_Item(index++).$v = $.$cast(number, $.$$.System.UInt16);
                        number = 0;
                        ++i;
                        if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58)))
                        {
                            compressorIndex = index;
                            ++i;
                        }
                        else if ((compressorIndex < 0) && (index < 6))
                        {
                            break;
                        }
                        for(/*int*/ let j = i; j < address.Length && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*:*/ 58))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*%*/ 37))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*/*/ 47))) && (j < ((i + 4) | 0)); ++j)
                        {
                            if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*.*/ 46)))
                            {
                                while(j < address.Length && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*/*/ 47))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*%*/ 37))))
                                {
                                    ++j;
                                }
                                /*int*/ let ipv4Address = $.$snp.System.Net.IPv4AddressHelper.ParseHostNumber(TChar, address, i, j);
                                numbers.get_Item(index++).$v = $.$cast((ipv4Address >> 16), $.$$.System.UInt16);
                                numbers.get_Item(index++).$v = $.$cast((ipv4Address & 65535), $.$$.System.UInt16);
                                i = j;
                                number = 0;
                                numberIsValid = false;
                                break;
                            }
                        }
                        break;
                        case /*/*/ 47:
                        if (numberIsValid)
                        {
                            numbers.get_Item(index++).$v = $.$cast(number, $.$$.System.UInt16);
                            numberIsValid = false;
                        }
                        for(++i; i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$$.System.Char, /*]*/ 93)); i++)
                        {
                        }
                        break;
                        default:
                        /*int*/ let characterValue = $.$snp.System.HexConverter.FromChar(currentCh);
                        number = ((((number * 16/*IPv6AddressHelper.Hex*/) | 0) + characterValue) | 0);
                        i++;
                        break;
                    }
                }
                if (numberIsValid)
                {
                    numbers.get_Item(index++).$v = $.$cast(number, $.$$.System.UInt16);
                }
                if (compressorIndex > 0)
                {
                    /*int*/ let toIndex = ((8/*NumberOfLabels*/ - 1) | 0);
                    /*int*/ let fromIndex = ((index - 1) | 0);
                    if (fromIndex !== toIndex)
                    {
                        for(/*int*/ let i = ((index - compressorIndex) | 0); i > 0; --i)
                        {
                            numbers.get_Item(toIndex--).$v = numbers.get_Item(fromIndex).$v;
                            numbers.get_Item(fromIndex--).$v = 0;
                        }
                    }
                }
            }
            static $h = 3523317;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.ValueTuple$$$($.$$.System.Int32, $.$$.System.Int32).$h,"p":[{"n":"numbers","p":$.$$.System.ReadOnlySpan$$($.$$.System.UInt16).$h}],"n":"FindCompressionRange","d":3523317,"h":12888425205,"f":16777256},{"r":262145,"p":[{"n":"numbers","p":$.$$.System.ReadOnlySpan$$($.$$.System.UInt16).$h}],"n":"ShouldHaveIpv4Embedded","d":3523317,"h":17183392501,"f":16777256},{"r":262145,"p":[{"n":"name","p":(TChar) => $.$typePointer(TChar).$h},{"n":"start","p":655361},{"n":"end","p":655361}],"g":["TChar"],"n":"IsValidStrict","d":3523317,"h":21478359797,"f":16908328},{"r":65537,"p":[{"n":"address","p":(TChar) => $.$$.System.ReadOnlySpan$$(TChar).$h},{"n":"numbers","p":$.$$.System.Span$$($.$$.System.UInt16).$h},{"n":"scopeId","p":(TChar) => $.$$.System.ReadOnlySpan$$(TChar).$h,"f":2}],"g":["TChar"],"n":"Parse","d":3523317,"h":25773327093,"f":16908328}],"l":[{"t":655361,"n":"Hex","d":3523317,"h":4298490613,"f":4194338},{"t":655361,"n":"NumberOfLabels","d":3523317,"h":8593457909,"f":4194338}],"h":3523317}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.IPv6AddressHelper`; }
        });
        
        $asm.$cls("$snp.System.NotImplemented", ($self) => class NotImplemented
        {
            static /*Exception */ get ByDesign()
            {
                return new $.$$.System.NotImplementedException().$ctor$9();
            }
            static /*Exception */ ByDesignWithMessage(/*string*/ message)
            {
                return new $.$$.System.NotImplementedException().$ctor$12(message);
            }
            static $h = 5161717;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":47251457,"g":{"r":0,"d":0,"h":8595096309,"f":50331688},"n":"ByDesign","d":5161717,"h":4300129013,"f":2097192}],"m":[{"r":47251457,"p":[{"n":"message","p":1310721}],"n":"ByDesignWithMessage","d":5161717,"h":12890063605,"f":16777256}],"h":5161717}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.NotImplemented`; }
        });
        
        $asm.$cls("$snp.Interop", ($self) => class Interop
        {
            static $_SChannel;
            static get SChannel()
            {
                let $cls = $.$snp.Interop;
                return $cls.$_SChannel ??= $asm.$ncls("$snp.Interop.SChannel", ($self) => class SChannel
                {
                    /*int*/ static SP_PROT_SSL2_SERVER = 4;
                    /*int*/ static SP_PROT_SSL2_CLIENT = 8;
                    /*int*/ static SP_PROT_SSL2 = 12;
                    /*int*/ static SP_PROT_SSL3_SERVER = 16;
                    /*int*/ static SP_PROT_SSL3_CLIENT = 32;
                    /*int*/ static SP_PROT_SSL3 = 48;
                    /*int*/ static SP_PROT_TLS1_0_SERVER = 64;
                    /*int*/ static SP_PROT_TLS1_0_CLIENT = 128;
                    /*int*/ static SP_PROT_TLS1_0 = 192;
                    /*int*/ static SP_PROT_TLS1_1_SERVER = 256;
                    /*int*/ static SP_PROT_TLS1_1_CLIENT = 512;
                    /*int*/ static SP_PROT_TLS1_1 = 768;
                    /*int*/ static SP_PROT_TLS1_2_SERVER = 1024;
                    /*int*/ static SP_PROT_TLS1_2_CLIENT = 2048;
                    /*int*/ static SP_PROT_TLS1_2 = 3072;
                    /*int*/ static SP_PROT_TLS1_3_SERVER = 4096;
                    /*int*/ static SP_PROT_TLS1_3_CLIENT = 8192;
                    /*int*/ static SP_PROT_TLS1_3 = 12288;
                    /*int*/ static SP_PROT_NONE = 0;
                    /*int*/ static ClientProtocolMask = 10920;
                    /*int*/ static ServerProtocolMask = 5460;
                    static $h = 443125;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"SP_PROT_SSL2_SERVER","d":443125,"h":4295410421,"f":4194337},{"t":655361,"n":"SP_PROT_SSL2_CLIENT","d":443125,"h":8590377717,"f":4194337},{"t":655361,"n":"SP_PROT_SSL2","d":443125,"h":12885345013,"f":4194337},{"t":655361,"n":"SP_PROT_SSL3_SERVER","d":443125,"h":17180312309,"f":4194337},{"t":655361,"n":"SP_PROT_SSL3_CLIENT","d":443125,"h":21475279605,"f":4194337},{"t":655361,"n":"SP_PROT_SSL3","d":443125,"h":25770246901,"f":4194337},{"t":655361,"n":"SP_PROT_TLS1_0_SERVER","d":443125,"h":30065214197,"f":4194337},{"t":655361,"n":"SP_PROT_TLS1_0_CLIENT","d":443125,"h":34360181493,"f":4194337},{"t":655361,"n":"SP_PROT_TLS1_0","d":443125,"h":38655148789,"f":4194337},{"t":655361,"n":"SP_PROT_TLS1_1_SERVER","d":443125,"h":42950116085,"f":4194337},{"t":655361,"n":"SP_PROT_TLS1_1_CLIENT","d":443125,"h":47245083381,"f":4194337},{"t":655361,"n":"SP_PROT_TLS1_1","d":443125,"h":51540050677,"f":4194337},{"t":655361,"n":"SP_PROT_TLS1_2_SERVER","d":443125,"h":55835017973,"f":4194337},{"t":655361,"n":"SP_PROT_TLS1_2_CLIENT","d":443125,"h":60129985269,"f":4194337},{"t":655361,"n":"SP_PROT_TLS1_2","d":443125,"h":64424952565,"f":4194337},{"t":655361,"n":"SP_PROT_TLS1_3_SERVER","d":443125,"h":68719919861,"f":4194337},{"t":655361,"n":"SP_PROT_TLS1_3_CLIENT","d":443125,"h":73014887157,"f":4194337},{"t":655361,"n":"SP_PROT_TLS1_3","d":443125,"h":77309854453,"f":4194337},{"t":655361,"n":"SP_PROT_NONE","d":443125,"h":81604821749,"f":4194337},{"t":655361,"n":"ClientProtocolMask","d":443125,"h":85899789045,"f":4194337},{"t":655361,"n":"ServerProtocolMask","d":443125,"h":90194756341,"f":4194337}],"d":115445,"h":443125}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Interop.SChannel`; }
                }, $cls, ($v) => $cls.$_SChannel = $v);
            }
            static $_Winsock;
            static get Winsock()
            {
                let $cls = $.$snp.Interop;
                return $cls.$_Winsock ??= $asm.$ncls("$snp.Interop.Winsock", ($self) => class Winsock
                {
                    /*uint*/ static ERROR_SUCCESS = 0;
                    /*uint*/ static ERROR_HANDLE_EOF = 38;
                    /*uint*/ static ERROR_NOT_SUPPORTED = 50;
                    /*uint*/ static ERROR_INVALID_PARAMETER = 87;
                    /*uint*/ static ERROR_ALREADY_EXISTS = 183;
                    /*uint*/ static ERROR_MORE_DATA = 234;
                    /*uint*/ static ERROR_OPERATION_ABORTED = 995;
                    /*uint*/ static ERROR_IO_PENDING = 997;
                    /*uint*/ static ERROR_NOT_FOUND = 1168;
                    /*uint*/ static ERROR_CONNECTION_INVALID = 1229;
                    static $h = 639733;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":720897,"n":"ERROR_SUCCESS","d":639733,"h":4295607029,"f":4194337},{"t":720897,"n":"ERROR_HANDLE_EOF","d":639733,"h":8590574325,"f":4194337},{"t":720897,"n":"ERROR_NOT_SUPPORTED","d":639733,"h":12885541621,"f":4194337},{"t":720897,"n":"ERROR_INVALID_PARAMETER","d":639733,"h":17180508917,"f":4194337},{"t":720897,"n":"ERROR_ALREADY_EXISTS","d":639733,"h":21475476213,"f":4194337},{"t":720897,"n":"ERROR_MORE_DATA","d":639733,"h":25770443509,"f":4194337},{"t":720897,"n":"ERROR_OPERATION_ABORTED","d":639733,"h":30065410805,"f":4194337},{"t":720897,"n":"ERROR_IO_PENDING","d":639733,"h":34360378101,"f":4194337},{"t":720897,"n":"ERROR_NOT_FOUND","d":639733,"h":38655345397,"f":4194337},{"t":720897,"n":"ERROR_CONNECTION_INVALID","d":639733,"h":42950312693,"f":4194337}],"d":115445,"h":639733}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Interop.Winsock`; }
                }, $cls, ($v) => $cls.$_Winsock = $v);
            }
            static $_Sys;
            static get Sys()
            {
                let $cls = $.$snp.Interop;
                return $cls.$_Sys ??= $asm.$ncls("$snp.Interop.Sys", ($self) => class Sys
                {
                    static /*Error */ ConvertErrorPlatformToPal(/*int*/ platformErrno)
                    {
                        return $.$cast(platformErrno, $.$snp.Interop.Error);
                    }
                    static /*int */ ConvertErrorPalToPlatform(/*Error*/ error)
                    {
                        return error;
                    }
                    static /*byte* */ StrErrorR(/*int*/ platformErrno, /*byte**/ buffer, /*int*/ bufferSize)
                    {
                        return null;
                    }
                    static /*Error */ GetSocketAddressSizes(/*int**/ ipv4SocketAddressSize, /*int**/ ipv6SocketAddressSize, /*int**/ udsSocketAddressSize, /*int**/ maxSocketAddressSize)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ GetAddressFamily(/*byte**/ socketAddress, /*int*/ socketAddressLen, /*int**/ addressFamily)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ SetAddressFamily(/*byte**/ socketAddress, /*int*/ socketAddressLen, /*int*/ addressFamily)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ GetPort(/*byte**/ socketAddress, /*int*/ socketAddressLen, /*ushort**/ port)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ SetPort(/*byte**/ socketAddress, /*int*/ socketAddressLen, /*ushort*/ port)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ GetIPv4Address(/*byte**/ socketAddress, /*int*/ socketAddressLen, /*uint**/ address)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ SetIPv4Address(/*byte**/ socketAddress, /*int*/ socketAddressLen, /*uint*/ address)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ GetIPv6Address(/*byte**/ socketAddress, /*int*/ socketAddressLen, /*byte**/ address, /*int*/ addressLen, /*uint**/ scopeId)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ SetIPv6Address(/*byte**/ socketAddress, /*int*/ socketAddressLen, /*byte**/ address, /*int*/ addressLen, /*uint*/ scopeId)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ GetLastError()
                    {
                        return $.$snp.Interop.Sys.ConvertErrorPlatformToPal($.$$.System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
                    }
                    static /*ErrorInfo */ GetLastErrorInfo()
                    {
                        return new $.$snp.Interop.ErrorInfo().$ctor$3($.$$.System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
                    }
                    static /*string */ StrError(/*int*/ platformErrno)
                    {
                        /*int*/ let MaxBufferLength = 1024;
                        /*byte**/ let buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$$.System.Byte, MaxBufferLength, null);
                        /*byte**/ let message = $.$snp.Interop.Sys.StrErrorR(platformErrno, buffer, MaxBufferLength);
                        if (message === null)
                        {
                            message = buffer;
                        }
                        return $.$$.System.Runtime.InteropServices.Marshal.PtrToStringUTF8$1($.$cast(message, $.$$.System.IntPtr));
                    }
                    /*int*/ static IPv4AddressBytes = 4;
                    /*int*/ static IPv6AddressBytes = 16;
                    /*int*/ static MAX_IP_ADDRESS_BYTES = 16;
                    /*int*/ static INET_ADDRSTRLEN = 22;
                    /*int*/ static INET6_ADDRSTRLEN = 65;
                    static $_IPAddress;
                    static get IPAddress()
                    {
                        let $cls = $.$snp.Interop.Sys;
                        return $cls.$_IPAddress ??= $asm.$nstr("$snp.Interop.Sys.IPAddress", ($self) => class IPAddress extends $.$$.System.ValueType
                        {
                            /*bool */ get IsIPv6()
                            {
                                return this._isIPv6 !== 0;
                            }
                            /*bool */ set IsIPv6(value)
                            {
                                this._isIPv6 = value ? 1 : 0;
                            }
                            /*byte[16]*/  get Address() { return this.$getField(0, 0x80000000|16); }
                            /*byte[16]*/  set Address(value) { this.$setField(0, 0x80000000|16, value); }
                            /*uint*/  get _isIPv6() { return this.$getField(16, 4); }
                            /*uint*/  set _isIPv6(value) { this.$setField(16, 4, value); }
                            /*uint*/  get ScopeId() { return this.$getField(20, 4); }
                            /*uint*/  set ScopeId(value) { this.$setField(20, 4, value); }
                            static/*conventional*/ /*int */ GetHashCode()
                            {
                                /*HashCode*/ let h = new $.$$.System.HashCode();
                                h.AddBytes($.$$.System.Runtime.InteropServices.MemoryMarshal.CreateReadOnlySpan($.$$.System.Byte, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$$.System.Byte, this.Address, 0, false, true), this.IsIPv6 ? 16/*IPv6AddressBytes*/ : 4/*IPv4AddressBytes*/));
                                return h.ToHashCode();
                            }
                            //Static convention instance redirect
                            /*int */ GetHashCode() { return $.$snp.Interop.Sys.IPAddress.GetHashCode.apply(this, arguments); }
                            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
                            {
                                let other;
                                return $.$is(obj, $.$snp.Interop.Sys.IPAddress, { set $v(v){ other = v; } }) && this.Equals$2(other.Clone());
                            }
                            //Static convention instance redirect
                            /*bool */ Equals$1() { return $.$snp.Interop.Sys.IPAddress.Equals$1.apply(this, arguments); }
                            /*bool */ Equals$2(/*IPAddress*/ other)
                            {
                                /*int*/ let addressByteCount;
                                if (this.IsIPv6)
                                {
                                    if (!other.IsIPv6)
                                    {
                                        return false;
                                    }
                                    if (this.ScopeId !== other.ScopeId)
                                    {
                                        return false;
                                    }
                                    addressByteCount = 16/*IPv6AddressBytes*/;
                                }
                                else 
                                {
                                    if (other.IsIPv6)
                                    {
                                        return false;
                                    }
                                    addressByteCount = 4/*IPv4AddressBytes*/;
                                }
                                return $.$$.System.MemoryExtensions.SequenceEqual$1($.$$.System.Byte, $.$$.System.Runtime.InteropServices.MemoryMarshal.CreateReadOnlySpan($.$$.System.Byte, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$$.System.Byte, this.Address, 0, false, true), addressByteCount), new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$5(other.Address, addressByteCount));
                            }
                            //Generated interface implemetation for System.IEquatable<Interop.Sys.IPAddress>.Equals(Interop.Sys.IPAddress)
                            System$IEquatable$$$Equals()
                            {
                                return this.Equals$2(...arguments);
                            }
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                //InlineArray(16)
                                copy.Address = [...this.Address];
                                $.$$.System.Array.CopyMetadata(copy.Address, this.Address)
                                copy._isIPv6 = this._isIPv6;
                                copy.ScopeId = this.ScopeId;
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                //FixedSizeArray(byte*, 16)
                                let $t1 = this.Address;
                                $.$$.System.Array.AddMetadata($t1, $.$$.System.Byte.$type, null, null);
                                for (let $i = 0; $i < 16; $i++)
                                {
                                    $t1[$i] = 0;
                                }
                                this._isIPv6 = 0;
                                this.ScopeId = 0;
                            }
                            static $h = 574197;
                            static $z = 24;
                            static $f = 0b100010000001010000000;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":8590508789,"f":50331649},"s":{"r":0,"d":0,"h":12885476085,"f":83886081},"n":"IsIPv6","d":574197,"h":4295541493,"f":2097153}],"m":[{"r":655361,"n":"GetHashCode","d":574197,"h":30065345269,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":574197,"h":34360312565,"f":16809985},{"r":262145,"p":[{"n":"other","p":574197}],"n":"Equals","o":"@$2","d":574197,"h":38655279861,"f":16777217}],"l":[{"t":$.$typePointer($.$$.System.Byte).$h,"n":"Address","d":574197,"h":17180443381,"f":4194312},{"t":720897,"n":"_isIPv6","d":574197,"h":21475410677,"f":4194306},{"t":720897,"n":"ScopeId","d":574197,"h":25770377973,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$2","d":574197,"h":42950247157,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$snp.Interop.Sys.IPAddress).$h],"d":508661,"h":574197,"a":[{"t":109772801,"c":4404740097,"a":[{"v":0,"t":105250817}]}]}; }
                            static get $b() { return $.$$.System.ValueType; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$snp.Interop.Sys.IPAddress) ]; }
                            static get $fullName() { return `Interop.Sys.IPAddress`; }
                        }, $cls, ($v) => $cls.$_IPAddress = $v);
                    }
                    static $h = 508661;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":246517,"n":"GetLastError","d":508661,"h":4295475957,"f":16777256},{"r":312053,"n":"GetLastErrorInfo","d":508661,"h":8590443253,"f":16777256},{"r":1310721,"p":[{"n":"platformErrno","p":655361}],"n":"StrError","d":508661,"h":12885410549,"f":16777256},{"r":246517,"p":[{"n":"platformErrno","p":655361}],"n":"ConvertErrorPlatformToPal","d":508661,"h":17180377845,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_ConvertErrorPlatformToPal","t":1310721}]},{"t":109838337,"c":4404805633}]},{"r":655361,"p":[{"n":"error","p":246517}],"n":"ConvertErrorPalToPlatform","d":508661,"h":21475345141,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_ConvertErrorPalToPlatform","t":1310721}]},{"t":109838337,"c":4404805633}]},{"r":$.$typePointer($.$$.System.Byte).$h,"p":[{"n":"platformErrno","p":655361},{"n":"buffer","p":$.$typePointer($.$$.System.Byte).$h},{"n":"bufferSize","p":655361}],"n":"StrErrorR","d":508661,"h":25770312437,"f":16777250,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_StrErrorR","t":1310721}]}]},{"r":246517,"p":[{"n":"ipv4SocketAddressSize","p":$.$typePointer($.$$.System.Int32).$h},{"n":"ipv6SocketAddressSize","p":$.$typePointer($.$$.System.Int32).$h},{"n":"udsSocketAddressSize","p":$.$typePointer($.$$.System.Int32).$h},{"n":"maxSocketAddressSize","p":$.$typePointer($.$$.System.Int32).$h}],"n":"GetSocketAddressSizes","d":508661,"h":55835083509,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_GetSocketAddressSizes","t":1310721}]},{"t":109838337,"c":4404805633}]},{"r":246517,"p":[{"n":"socketAddress","p":$.$typePointer($.$$.System.Byte).$h},{"n":"socketAddressLen","p":655361},{"n":"addressFamily","p":$.$typePointer($.$$.System.Int32).$h}],"n":"GetAddressFamily","d":508661,"h":60130050805,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_GetAddressFamily","t":1310721}]},{"t":109838337,"c":4404805633}]},{"r":246517,"p":[{"n":"socketAddress","p":$.$typePointer($.$$.System.Byte).$h},{"n":"socketAddressLen","p":655361},{"n":"addressFamily","p":655361}],"n":"SetAddressFamily","d":508661,"h":64425018101,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_SetAddressFamily","t":1310721}]},{"t":109838337,"c":4404805633}]},{"r":246517,"p":[{"n":"socketAddress","p":$.$typePointer($.$$.System.Byte).$h},{"n":"socketAddressLen","p":655361},{"n":"port","p":$.$typePointer($.$$.System.UInt16).$h}],"n":"GetPort","d":508661,"h":68719985397,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_GetPort","t":1310721}]},{"t":109838337,"c":4404805633}]},{"r":246517,"p":[{"n":"socketAddress","p":$.$typePointer($.$$.System.Byte).$h},{"n":"socketAddressLen","p":655361},{"n":"port","p":589825}],"n":"SetPort","d":508661,"h":73014952693,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_SetPort","t":1310721}]},{"t":109838337,"c":4404805633}]},{"r":246517,"p":[{"n":"socketAddress","p":$.$typePointer($.$$.System.Byte).$h},{"n":"socketAddressLen","p":655361},{"n":"address","p":$.$typePointer($.$$.System.UInt32).$h}],"n":"GetIPv4Address","d":508661,"h":77309919989,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_GetIPv4Address","t":1310721}]},{"t":109838337,"c":4404805633}]},{"r":246517,"p":[{"n":"socketAddress","p":$.$typePointer($.$$.System.Byte).$h},{"n":"socketAddressLen","p":655361},{"n":"address","p":720897}],"n":"SetIPv4Address","d":508661,"h":81604887285,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_SetIPv4Address","t":1310721}]},{"t":109838337,"c":4404805633}]},{"r":246517,"p":[{"n":"socketAddress","p":$.$typePointer($.$$.System.Byte).$h},{"n":"socketAddressLen","p":655361},{"n":"address","p":$.$typePointer($.$$.System.Byte).$h},{"n":"addressLen","p":655361},{"n":"scopeId","p":$.$typePointer($.$$.System.UInt32).$h}],"n":"GetIPv6Address","d":508661,"h":85899854581,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_GetIPv6Address","t":1310721}]}]},{"r":246517,"p":[{"n":"socketAddress","p":$.$typePointer($.$$.System.Byte).$h},{"n":"socketAddressLen","p":655361},{"n":"address","p":$.$typePointer($.$$.System.Byte).$h},{"n":"addressLen","p":655361},{"n":"scopeId","p":720897}],"n":"SetIPv6Address","d":508661,"h":90194821877,"f":16777256,"a":[{"t":105381889,"c":4400349185,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_SetIPv6Address","t":1310721}]}]}],"l":[{"t":655361,"n":"IPv4AddressBytes","d":508661,"h":30065279733,"f":4194344},{"t":655361,"n":"IPv6AddressBytes","d":508661,"h":34360247029,"f":4194344},{"t":655361,"n":"MAX_IP_ADDRESS_BYTES","d":508661,"h":38655214325,"f":4194344},{"t":655361,"n":"INET_ADDRSTRLEN","d":508661,"h":42950181621,"f":4194344},{"t":655361,"n":"INET6_ADDRSTRLEN","d":508661,"h":47245148917,"f":4194344}],"j":[574197],"d":115445,"h":508661}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Interop.Sys`; }
                }, $cls, ($v) => $cls.$_Sys = $v);
            }
            static $_Crypt32;
            static get Crypt32()
            {
                let $cls = $.$snp.Interop;
                return $cls.$_Crypt32 ??= $asm.$ncls("$snp.Interop.Crypt32", ($self) => class Crypt32
                {
                    /*int*/ static ALG_CLASS_ANY = 0;
                    /*int*/ static ALG_CLASS_SIGNATURE = 8192;
                    /*int*/ static ALG_CLASS_ENCRYPT = 24576;
                    /*int*/ static ALG_CLASS_HASH = 32768;
                    /*int*/ static ALG_CLASS_KEY_EXCHANGE = 40960;
                    /*int*/ static ALG_TYPE_RSA = 1024;
                    /*int*/ static ALG_TYPE_BLOCK = 1536;
                    /*int*/ static ALG_TYPE_STREAM = 2048;
                    /*int*/ static ALG_TYPE_DH = 2560;
                    /*int*/ static ALG_SID_DES = 1;
                    /*int*/ static ALG_SID_3DES = 3;
                    /*int*/ static ALG_SID_AES_128 = 14;
                    /*int*/ static ALG_SID_AES_192 = 15;
                    /*int*/ static ALG_SID_AES_256 = 16;
                    /*int*/ static ALG_SID_AES = 17;
                    /*int*/ static ALG_SID_RC2 = 2;
                    /*int*/ static ALG_SID_RC4 = 1;
                    /*int*/ static ALG_SID_DH_EPHEM = 2;
                    /*int*/ static ALG_SID_MD5 = 3;
                    /*int*/ static ALG_SID_SHA = 4;
                    /*int*/ static ALG_SID_SHA_256 = 12;
                    /*int*/ static ALG_SID_SHA_384 = 13;
                    /*int*/ static ALG_SID_SHA_512 = 14;
                    static $h = 180981;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"ALG_CLASS_ANY","d":180981,"h":4295148277,"f":4194337},{"t":655361,"n":"ALG_CLASS_SIGNATURE","d":180981,"h":8590115573,"f":4194337},{"t":655361,"n":"ALG_CLASS_ENCRYPT","d":180981,"h":12885082869,"f":4194337},{"t":655361,"n":"ALG_CLASS_HASH","d":180981,"h":17180050165,"f":4194337},{"t":655361,"n":"ALG_CLASS_KEY_EXCHANGE","d":180981,"h":21475017461,"f":4194337},{"t":655361,"n":"ALG_TYPE_RSA","d":180981,"h":25769984757,"f":4194337},{"t":655361,"n":"ALG_TYPE_BLOCK","d":180981,"h":30064952053,"f":4194337},{"t":655361,"n":"ALG_TYPE_STREAM","d":180981,"h":34359919349,"f":4194337},{"t":655361,"n":"ALG_TYPE_DH","d":180981,"h":38654886645,"f":4194337},{"t":655361,"n":"ALG_SID_DES","d":180981,"h":42949853941,"f":4194337},{"t":655361,"n":"ALG_SID_3DES","d":180981,"h":47244821237,"f":4194337},{"t":655361,"n":"ALG_SID_AES_128","d":180981,"h":51539788533,"f":4194337},{"t":655361,"n":"ALG_SID_AES_192","d":180981,"h":55834755829,"f":4194337},{"t":655361,"n":"ALG_SID_AES_256","d":180981,"h":60129723125,"f":4194337},{"t":655361,"n":"ALG_SID_AES","d":180981,"h":64424690421,"f":4194337},{"t":655361,"n":"ALG_SID_RC2","d":180981,"h":68719657717,"f":4194337},{"t":655361,"n":"ALG_SID_RC4","d":180981,"h":73014625013,"f":4194337},{"t":655361,"n":"ALG_SID_DH_EPHEM","d":180981,"h":77309592309,"f":4194337},{"t":655361,"n":"ALG_SID_MD5","d":180981,"h":81604559605,"f":4194337},{"t":655361,"n":"ALG_SID_SHA","d":180981,"h":85899526901,"f":4194337},{"t":655361,"n":"ALG_SID_SHA_256","d":180981,"h":90194494197,"f":4194337},{"t":655361,"n":"ALG_SID_SHA_384","d":180981,"h":94489461493,"f":4194337},{"t":655361,"n":"ALG_SID_SHA_512","d":180981,"h":98784428789,"f":4194337}],"d":115445,"h":180981}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Interop.Crypt32`; }
                }, $cls, ($v) => $cls.$_Crypt32 = $v);
            }
            static $_Error;
            static get Error()
            {
                let $cls = $.$snp.Interop;
                return $cls.$_Error ??= $asm.$nstr("$snp.Interop.Error", ($self) => class Error extends $.$$.System.Enum
                {
                    static SUCCESS = 0;
                    static E2BIG = 65537;
                    static EACCES = 65538;
                    static EADDRINUSE = 65539;
                    static EADDRNOTAVAIL = 65540;
                    static EAFNOSUPPORT = 65541;
                    static EAGAIN = 65542;
                    static EALREADY = 65543;
                    static EBADF = 65544;
                    static EBADMSG = 65545;
                    static EBUSY = 65546;
                    static ECANCELED = 65547;
                    static ECHILD = 65548;
                    static ECONNABORTED = 65549;
                    static ECONNREFUSED = 65550;
                    static ECONNRESET = 65551;
                    static EDEADLK = 65552;
                    static EDESTADDRREQ = 65553;
                    static EDOM = 65554;
                    static EDQUOT = 65555;
                    static EEXIST = 65556;
                    static EFAULT = 65557;
                    static EFBIG = 65558;
                    static EHOSTUNREACH = 65559;
                    static EIDRM = 65560;
                    static EILSEQ = 65561;
                    static EINPROGRESS = 65562;
                    static EINTR = 65563;
                    static EINVAL = 65564;
                    static EIO = 65565;
                    static EISCONN = 65566;
                    static EISDIR = 65567;
                    static ELOOP = 65568;
                    static EMFILE = 65569;
                    static EMLINK = 65570;
                    static EMSGSIZE = 65571;
                    static EMULTIHOP = 65572;
                    static ENAMETOOLONG = 65573;
                    static ENETDOWN = 65574;
                    static ENETRESET = 65575;
                    static ENETUNREACH = 65576;
                    static ENFILE = 65577;
                    static ENOBUFS = 65578;
                    static ENODEV = 65580;
                    static ENOENT = 65581;
                    static ENOEXEC = 65582;
                    static ENOLCK = 65583;
                    static ENOLINK = 65584;
                    static ENOMEM = 65585;
                    static ENOMSG = 65586;
                    static ENOPROTOOPT = 65587;
                    static ENOSPC = 65588;
                    static ENOSYS = 65591;
                    static ENOTCONN = 65592;
                    static ENOTDIR = 65593;
                    static ENOTEMPTY = 65594;
                    static ENOTRECOVERABLE = 65595;
                    static ENOTSOCK = 65596;
                    static ENOTSUP = 65597;
                    static ENOTTY = 65598;
                    static ENXIO = 65599;
                    static EOVERFLOW = 65600;
                    static EOWNERDEAD = 65601;
                    static EPERM = 65602;
                    static EPIPE = 65603;
                    static EPROTO = 65604;
                    static EPROTONOSUPPORT = 65605;
                    static EPROTOTYPE = 65606;
                    static ERANGE = 65607;
                    static EROFS = 65608;
                    static ESPIPE = 65609;
                    static ESRCH = 65610;
                    static ESTALE = 65611;
                    static ETIMEDOUT = 65613;
                    static ETXTBSY = 65614;
                    static EXDEV = 65615;
                    static ESOCKTNOSUPPORT = 65630;
                    static EPFNOSUPPORT = 65632;
                    static ESHUTDOWN = 65644;
                    static EHOSTDOWN = 65648;
                    static ENODATA = 65649;
                    static EHOSTNOTFOUND = 131073;
                    static ESOCKETERROR = 131074;
                    static EOPNOTSUPP = 65597;
                    static EWOULDBLOCK = 65542;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "SUCCESS": 0n,
                            "E2BIG": 65537n,
                            "EACCES": 65538n,
                            "EADDRINUSE": 65539n,
                            "EADDRNOTAVAIL": 65540n,
                            "EAFNOSUPPORT": 65541n,
                            "EAGAIN": 65542n,
                            "EALREADY": 65543n,
                            "EBADF": 65544n,
                            "EBADMSG": 65545n,
                            "EBUSY": 65546n,
                            "ECANCELED": 65547n,
                            "ECHILD": 65548n,
                            "ECONNABORTED": 65549n,
                            "ECONNREFUSED": 65550n,
                            "ECONNRESET": 65551n,
                            "EDEADLK": 65552n,
                            "EDESTADDRREQ": 65553n,
                            "EDOM": 65554n,
                            "EDQUOT": 65555n,
                            "EEXIST": 65556n,
                            "EFAULT": 65557n,
                            "EFBIG": 65558n,
                            "EHOSTUNREACH": 65559n,
                            "EIDRM": 65560n,
                            "EILSEQ": 65561n,
                            "EINPROGRESS": 65562n,
                            "EINTR": 65563n,
                            "EINVAL": 65564n,
                            "EIO": 65565n,
                            "EISCONN": 65566n,
                            "EISDIR": 65567n,
                            "ELOOP": 65568n,
                            "EMFILE": 65569n,
                            "EMLINK": 65570n,
                            "EMSGSIZE": 65571n,
                            "EMULTIHOP": 65572n,
                            "ENAMETOOLONG": 65573n,
                            "ENETDOWN": 65574n,
                            "ENETRESET": 65575n,
                            "ENETUNREACH": 65576n,
                            "ENFILE": 65577n,
                            "ENOBUFS": 65578n,
                            "ENODEV": 65580n,
                            "ENOENT": 65581n,
                            "ENOEXEC": 65582n,
                            "ENOLCK": 65583n,
                            "ENOLINK": 65584n,
                            "ENOMEM": 65585n,
                            "ENOMSG": 65586n,
                            "ENOPROTOOPT": 65587n,
                            "ENOSPC": 65588n,
                            "ENOSYS": 65591n,
                            "ENOTCONN": 65592n,
                            "ENOTDIR": 65593n,
                            "ENOTEMPTY": 65594n,
                            "ENOTRECOVERABLE": 65595n,
                            "ENOTSOCK": 65596n,
                            "ENOTSUP": 65597n,
                            "ENOTTY": 65598n,
                            "ENXIO": 65599n,
                            "EOVERFLOW": 65600n,
                            "EOWNERDEAD": 65601n,
                            "EPERM": 65602n,
                            "EPIPE": 65603n,
                            "EPROTO": 65604n,
                            "EPROTONOSUPPORT": 65605n,
                            "EPROTOTYPE": 65606n,
                            "ERANGE": 65607n,
                            "EROFS": 65608n,
                            "ESPIPE": 65609n,
                            "ESRCH": 65610n,
                            "ESTALE": 65611n,
                            "ETIMEDOUT": 65613n,
                            "ETXTBSY": 65614n,
                            "EXDEV": 65615n,
                            "ESOCKTNOSUPPORT": 65630n,
                            "EPFNOSUPPORT": 65632n,
                            "ESHUTDOWN": 65644n,
                            "EHOSTDOWN": 65648n,
                            "ENODATA": 65649n,
                            "EHOSTNOTFOUND": 131073n,
                            "ESOCKETERROR": 131074n,
                            "EOPNOTSUPP": 65597n,
                            "EWOULDBLOCK": 65542n
                        };
                    }
                    static $h = 246517;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":246517,"n":"SUCCESS","d":246517,"h":4295213813,"f":4194337},{"t":246517,"n":"E2BIG","d":246517,"h":8590181109,"f":4194337},{"t":246517,"n":"EACCES","d":246517,"h":12885148405,"f":4194337},{"t":246517,"n":"EADDRINUSE","d":246517,"h":17180115701,"f":4194337},{"t":246517,"n":"EADDRNOTAVAIL","d":246517,"h":21475082997,"f":4194337},{"t":246517,"n":"EAFNOSUPPORT","d":246517,"h":25770050293,"f":4194337},{"t":246517,"n":"EAGAIN","d":246517,"h":30065017589,"f":4194337},{"t":246517,"n":"EALREADY","d":246517,"h":34359984885,"f":4194337},{"t":246517,"n":"EBADF","d":246517,"h":38654952181,"f":4194337},{"t":246517,"n":"EBADMSG","d":246517,"h":42949919477,"f":4194337},{"t":246517,"n":"EBUSY","d":246517,"h":47244886773,"f":4194337},{"t":246517,"n":"ECANCELED","d":246517,"h":51539854069,"f":4194337},{"t":246517,"n":"ECHILD","d":246517,"h":55834821365,"f":4194337},{"t":246517,"n":"ECONNABORTED","d":246517,"h":60129788661,"f":4194337},{"t":246517,"n":"ECONNREFUSED","d":246517,"h":64424755957,"f":4194337},{"t":246517,"n":"ECONNRESET","d":246517,"h":68719723253,"f":4194337},{"t":246517,"n":"EDEADLK","d":246517,"h":73014690549,"f":4194337},{"t":246517,"n":"EDESTADDRREQ","d":246517,"h":77309657845,"f":4194337},{"t":246517,"n":"EDOM","d":246517,"h":81604625141,"f":4194337},{"t":246517,"n":"EDQUOT","d":246517,"h":85899592437,"f":4194337},{"t":246517,"n":"EEXIST","d":246517,"h":90194559733,"f":4194337},{"t":246517,"n":"EFAULT","d":246517,"h":94489527029,"f":4194337},{"t":246517,"n":"EFBIG","d":246517,"h":98784494325,"f":4194337},{"t":246517,"n":"EHOSTUNREACH","d":246517,"h":103079461621,"f":4194337},{"t":246517,"n":"EIDRM","d":246517,"h":107374428917,"f":4194337},{"t":246517,"n":"EILSEQ","d":246517,"h":111669396213,"f":4194337},{"t":246517,"n":"EINPROGRESS","d":246517,"h":115964363509,"f":4194337},{"t":246517,"n":"EINTR","d":246517,"h":120259330805,"f":4194337},{"t":246517,"n":"EINVAL","d":246517,"h":124554298101,"f":4194337},{"t":246517,"n":"EIO","d":246517,"h":128849265397,"f":4194337},{"t":246517,"n":"EISCONN","d":246517,"h":133144232693,"f":4194337},{"t":246517,"n":"EISDIR","d":246517,"h":137439199989,"f":4194337},{"t":246517,"n":"ELOOP","d":246517,"h":141734167285,"f":4194337},{"t":246517,"n":"EMFILE","d":246517,"h":146029134581,"f":4194337},{"t":246517,"n":"EMLINK","d":246517,"h":150324101877,"f":4194337},{"t":246517,"n":"EMSGSIZE","d":246517,"h":154619069173,"f":4194337},{"t":246517,"n":"EMULTIHOP","d":246517,"h":158914036469,"f":4194337},{"t":246517,"n":"ENAMETOOLONG","d":246517,"h":163209003765,"f":4194337},{"t":246517,"n":"ENETDOWN","d":246517,"h":167503971061,"f":4194337},{"t":246517,"n":"ENETRESET","d":246517,"h":171798938357,"f":4194337},{"t":246517,"n":"ENETUNREACH","d":246517,"h":176093905653,"f":4194337},{"t":246517,"n":"ENFILE","d":246517,"h":180388872949,"f":4194337},{"t":246517,"n":"ENOBUFS","d":246517,"h":184683840245,"f":4194337},{"t":246517,"n":"ENODEV","d":246517,"h":188978807541,"f":4194337},{"t":246517,"n":"ENOENT","d":246517,"h":193273774837,"f":4194337},{"t":246517,"n":"ENOEXEC","d":246517,"h":197568742133,"f":4194337},{"t":246517,"n":"ENOLCK","d":246517,"h":201863709429,"f":4194337},{"t":246517,"n":"ENOLINK","d":246517,"h":206158676725,"f":4194337},{"t":246517,"n":"ENOMEM","d":246517,"h":210453644021,"f":4194337},{"t":246517,"n":"ENOMSG","d":246517,"h":214748611317,"f":4194337},{"t":246517,"n":"ENOPROTOOPT","d":246517,"h":219043578613,"f":4194337},{"t":246517,"n":"ENOSPC","d":246517,"h":223338545909,"f":4194337},{"t":246517,"n":"ENOSYS","d":246517,"h":227633513205,"f":4194337},{"t":246517,"n":"ENOTCONN","d":246517,"h":231928480501,"f":4194337},{"t":246517,"n":"ENOTDIR","d":246517,"h":236223447797,"f":4194337},{"t":246517,"n":"ENOTEMPTY","d":246517,"h":240518415093,"f":4194337},{"t":246517,"n":"ENOTRECOVERABLE","d":246517,"h":244813382389,"f":4194337},{"t":246517,"n":"ENOTSOCK","d":246517,"h":249108349685,"f":4194337},{"t":246517,"n":"ENOTSUP","d":246517,"h":253403316981,"f":4194337},{"t":246517,"n":"ENOTTY","d":246517,"h":257698284277,"f":4194337},{"t":246517,"n":"ENXIO","d":246517,"h":261993251573,"f":4194337},{"t":246517,"n":"EOVERFLOW","d":246517,"h":266288218869,"f":4194337},{"t":246517,"n":"EOWNERDEAD","d":246517,"h":270583186165,"f":4194337},{"t":246517,"n":"EPERM","d":246517,"h":274878153461,"f":4194337},{"t":246517,"n":"EPIPE","d":246517,"h":279173120757,"f":4194337},{"t":246517,"n":"EPROTO","d":246517,"h":283468088053,"f":4194337},{"t":246517,"n":"EPROTONOSUPPORT","d":246517,"h":287763055349,"f":4194337},{"t":246517,"n":"EPROTOTYPE","d":246517,"h":292058022645,"f":4194337},{"t":246517,"n":"ERANGE","d":246517,"h":296352989941,"f":4194337},{"t":246517,"n":"EROFS","d":246517,"h":300647957237,"f":4194337},{"t":246517,"n":"ESPIPE","d":246517,"h":304942924533,"f":4194337},{"t":246517,"n":"ESRCH","d":246517,"h":309237891829,"f":4194337},{"t":246517,"n":"ESTALE","d":246517,"h":313532859125,"f":4194337},{"t":246517,"n":"ETIMEDOUT","d":246517,"h":317827826421,"f":4194337},{"t":246517,"n":"ETXTBSY","d":246517,"h":322122793717,"f":4194337},{"t":246517,"n":"EXDEV","d":246517,"h":326417761013,"f":4194337},{"t":246517,"n":"ESOCKTNOSUPPORT","d":246517,"h":330712728309,"f":4194337},{"t":246517,"n":"EPFNOSUPPORT","d":246517,"h":335007695605,"f":4194337},{"t":246517,"n":"ESHUTDOWN","d":246517,"h":339302662901,"f":4194337},{"t":246517,"n":"EHOSTDOWN","d":246517,"h":343597630197,"f":4194337},{"t":246517,"n":"ENODATA","d":246517,"h":347892597493,"f":4194337},{"t":246517,"n":"EHOSTNOTFOUND","d":246517,"h":352187564789,"f":4194337},{"t":246517,"n":"ESOCKETERROR","d":246517,"h":356482532085,"f":4194337},{"t":246517,"n":"EOPNOTSUPP","d":246517,"h":360777499381,"f":4194337},{"t":246517,"n":"EWOULDBLOCK","d":246517,"h":365072466677,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":246517,"h":369367433973,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":115445,"h":246517}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `Interop.Error`; }
                }, $cls, ($v) => $cls.$_Error = $v);
            }
            static $_ErrorInfo;
            static get ErrorInfo()
            {
                let $cls = $.$snp.Interop;
                return $cls.$_ErrorInfo ??= $asm.$nstr("$snp.Interop.ErrorInfo", ($self) => class ErrorInfo extends $.$$.System.ValueType
                {
                    /*Error*/  get _error() { return this.$getField(0, $.$snp.Interop.Error); }
                    /*Error*/  set _error(value) { this.$setField(0, $.$snp.Interop.Error, value); }
                    /*int*/  get _rawErrno() { return this.$getField(4, $.$$.System.Int32); }
                    /*int*/  set _rawErrno(value) { this.$setField(4, $.$$.System.Int32, value); }
                    $ctor$3(/*int*/ errno)
                    {
                        super.$ctor$1();
                        {
                            this._error = $.$snp.Interop.Sys.ConvertErrorPlatformToPal(errno);
                            this._rawErrno = errno;
                        }
                        return this;
                    }
                    $ctor$4(/*Error*/ error)
                    {
                        super.$ctor$1();
                        {
                            this._error = error;
                            this._rawErrno = -1;
                        }
                        return this;
                    }
                    /*Error */ get Error()
                    {
                        return this._error;
                    }
                    /*int */ get RawErrno()
                    {
                        return this._rawErrno === -1 ? (this._rawErrno = $.$snp.Interop.Sys.ConvertErrorPalToPlatform(this._error)) : this._rawErrno;
                    }
                    /*string */ GetErrorMessage()
                    {
                        return $.$snp.Interop.Sys.StrError(this.RawErrno);
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        return `RawErrno: ${this.RawErrno} Error: ${this.Error} GetErrorMessage: ${this.GetErrorMessage()}`;
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$snp.Interop.ErrorInfo.ToString.apply(this, arguments); }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._error = this._error;
                        copy._rawErrno = this._rawErrno;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._error = 0;
                        this._rawErrno = 0;
                    }
                    static $h = 312053;
                    static $z = 8;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":246517,"g":{"r":0,"d":0,"h":25770115829,"f":50331656},"n":"Error","d":312053,"h":21475148533,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":34360050421,"f":50331656},"n":"RawErrno","d":312053,"h":30065083125,"f":2097160}],"m":[{"r":1310721,"n":"GetErrorMessage","d":312053,"h":38655017717,"f":16777224},{"r":1310721,"n":"ToString","d":312053,"h":42949985013,"f":16809985}],"l":[{"t":246517,"n":"_error","d":312053,"h":4295279349,"f":4194306},{"t":655361,"n":"_rawErrno","d":312053,"h":8590246645,"f":4194306}],"c":[{"p":[{"n":"errno","p":655361}],"n":".ctor","o":"$ctor$3","d":312053,"h":12885213941,"f":16777224},{"p":[{"n":"error","p":246517}],"n":".ctor","o":"$ctor$4","d":312053,"h":17180181237,"f":16777224},{"n":".ctor","o":"$ctor$2","d":312053,"h":47244952309,"f":16777217}],"d":115445,"h":312053}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `Interop.ErrorInfo`; }
                }, $cls, ($v) => $cls.$_ErrorInfo = $v);
            }
            static $_Libraries;
            static get Libraries()
            {
                let $cls = $.$snp.Interop;
                return $cls.$_Libraries ??= $asm.$ncls("$snp.Interop.Libraries", ($self) => class Libraries
                {
                    /*string*/ static libc = null;
                    /*string*/ static SystemNative = null;
                    /*string*/ static NetSecurityNative = null;
                    /*string*/ static CryptoNative = null;
                    /*string*/ static CompressionNative = null;
                    /*string*/ static GlobalizationNative = null;
                    /*string*/ static IOPortsNative = null;
                    /*string*/ static HostPolicy = null;
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.libc = "libc";
                        }
                        {
                            this.SystemNative = "libSystem.Native";
                        }
                        {
                            this.NetSecurityNative = "libSystem.Net.Security.Native";
                        }
                        {
                            this.CryptoNative = "libSystem.Security.Cryptography.Native.OpenSsl";
                        }
                        {
                            this.CompressionNative = "libSystem.IO.Compression.Native";
                        }
                        {
                            this.GlobalizationNative = "libSystem.Globalization.Native";
                        }
                        {
                            this.IOPortsNative = "libSystem.IO.Ports.Native";
                        }
                        {
                            this.HostPolicy = "libhostpolicy";
                        }
                    }
                    static $h = 377589;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"libc","d":377589,"h":4295344885,"f":4194344},{"t":1310721,"n":"SystemNative","d":377589,"h":8590312181,"f":4194344},{"t":1310721,"n":"NetSecurityNative","d":377589,"h":12885279477,"f":4194344},{"t":1310721,"n":"CryptoNative","d":377589,"h":17180246773,"f":4194344},{"t":1310721,"n":"CompressionNative","d":377589,"h":21475214069,"f":4194344},{"t":1310721,"n":"GlobalizationNative","d":377589,"h":25770181365,"f":4194344},{"t":1310721,"n":"IOPortsNative","d":377589,"h":30065148661,"f":4194344},{"t":1310721,"n":"HostPolicy","d":377589,"h":34360115957,"f":4194344}],"d":115445,"h":377589}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `Interop.Libraries`; }
                }, $cls, ($v) => $cls.$_Libraries = $v);
            }
            static $h = 115445;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"j":[443125,639733,508661,180981,246517,312053,377589],"h":115445}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `Interop`; }
        });
        
        $asm.$cls("$snp.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 5227253;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":5227253,"h":4300194549,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":5227253,"h":8595161845,"f":4194344},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":5227253,"h":12890129141,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":5227253,"h":17185096437,"f":4194344},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":5227253,"h":21480063733,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityMessage","d":5227253,"h":25775031029,"f":4194344},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":5227253,"h":30069998325,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":5227253,"h":34364965621,"f":4194344},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":5227253,"h":38659932917,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":5227253,"h":42954900213,"f":4194344},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":5227253,"h":47249867509,"f":4194344},{"t":1310721,"n":"ThreadAbortMessage","d":5227253,"h":51544834805,"f":4194344},{"t":1310721,"n":"ThreadResetAbortMessage","d":5227253,"h":55839802101,"f":4194344},{"t":1310721,"n":"ThreadAbortDiagId","d":5227253,"h":60134769397,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":5227253,"h":64429736693,"f":4194344},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":5227253,"h":68724703989,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":5227253,"h":73019671285,"f":4194344},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":5227253,"h":77314638581,"f":4194344},{"t":1310721,"n":"AuthenticationManagerMessage","d":5227253,"h":81609605877,"f":4194344},{"t":1310721,"n":"AuthenticationManagerDiagId","d":5227253,"h":85904573173,"f":4194344},{"t":1310721,"n":"RemotingApisMessage","d":5227253,"h":90199540469,"f":4194344},{"t":1310721,"n":"RemotingApisDiagId","d":5227253,"h":94494507765,"f":4194344},{"t":1310721,"n":"BinaryFormatterMessage","d":5227253,"h":98789475061,"f":4194344},{"t":1310721,"n":"BinaryFormatterDiagId","d":5227253,"h":103084442357,"f":4194344},{"t":1310721,"n":"CodeBaseMessage","d":5227253,"h":107379409653,"f":4194344},{"t":1310721,"n":"CodeBaseDiagId","d":5227253,"h":111674376949,"f":4194344},{"t":1310721,"n":"EscapeUriStringMessage","d":5227253,"h":115969344245,"f":4194344},{"t":1310721,"n":"EscapeUriStringDiagId","d":5227253,"h":120264311541,"f":4194344},{"t":1310721,"n":"WebRequestMessage","d":5227253,"h":124559278837,"f":4194344},{"t":1310721,"n":"WebRequestDiagId","d":5227253,"h":128854246133,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":5227253,"h":133149213429,"f":4194344},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":5227253,"h":137444180725,"f":4194344},{"t":1310721,"n":"GetContextInfoMessage","d":5227253,"h":141739148021,"f":4194344},{"t":1310721,"n":"GetContextInfoDiagId","d":5227253,"h":146034115317,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairMessage","d":5227253,"h":150329082613,"f":4194344},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":5227253,"h":154624049909,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":5227253,"h":158919017205,"f":4194344},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":5227253,"h":163213984501,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":5227253,"h":167508951797,"f":4194344},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":5227253,"h":171803919093,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":5227253,"h":176098886389,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":5227253,"h":180393853685,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":5227253,"h":184688820981,"f":4194344},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":5227253,"h":188983788277,"f":4194344},{"t":1310721,"n":"RijndaelMessage","d":5227253,"h":193278755573,"f":4194344},{"t":1310721,"n":"RijndaelDiagId","d":5227253,"h":197573722869,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":5227253,"h":201868690165,"f":4194344},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":5227253,"h":206163657461,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":5227253,"h":210458624757,"f":4194344},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":5227253,"h":214753592053,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":5227253,"h":219048559349,"f":4194344},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":5227253,"h":223343526645,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableMessage","d":5227253,"h":227638493941,"f":4194344},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":5227253,"h":231933461237,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyMessage","d":5227253,"h":236228428533,"f":4194344},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":5227253,"h":240523395829,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":5227253,"h":244818363125,"f":4194344},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":5227253,"h":249113330421,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":5227253,"h":253408297717,"f":4194344},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":5227253,"h":257703265013,"f":4194344},{"t":1310721,"n":"UseManagedSha1Message","d":5227253,"h":261998232309,"f":4194344},{"t":1310721,"n":"UseManagedSha1DiagId","d":5227253,"h":266293199605,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":5227253,"h":270588166901,"f":4194344},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":5227253,"h":274883134197,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":5227253,"h":279178101493,"f":4194344},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":5227253,"h":283473068789,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":5227253,"h":287768036085,"f":4194344},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":5227253,"h":292063003381,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":5227253,"h":296357970677,"f":4194344},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":5227253,"h":300652937973,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":5227253,"h":304947905269,"f":4194344},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":5227253,"h":309242872565,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":5227253,"h":313537839861,"f":4194344},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":5227253,"h":317832807157,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersMessage","d":5227253,"h":322127774453,"f":4194344},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":5227253,"h":326422741749,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":5227253,"h":330717709045,"f":4194344},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":5227253,"h":335012676341,"f":4194344},{"t":1310721,"n":"TlsVersion10and11Message","d":5227253,"h":339307643637,"f":4194344},{"t":1310721,"n":"TlsVersion10and11DiagId","d":5227253,"h":343602610933,"f":4194344},{"t":1310721,"n":"EncryptionPolicyMessage","d":5227253,"h":347897578229,"f":4194344},{"t":1310721,"n":"EncryptionPolicyDiagId","d":5227253,"h":352192545525,"f":4194344},{"t":1310721,"n":"EccXmlExportImportMessage","d":5227253,"h":356487512821,"f":4194344},{"t":1310721,"n":"EccXmlExportImportDiagId","d":5227253,"h":360782480117,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":5227253,"h":365077447413,"f":4194344},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":5227253,"h":369372414709,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":5227253,"h":373667382005,"f":4194344},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":5227253,"h":377962349301,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryMessage","d":5227253,"h":382257316597,"f":4194344},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":5227253,"h":386552283893,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunMessage","d":5227253,"h":390847251189,"f":4194344},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":5227253,"h":395142218485,"f":4194344},{"t":1310721,"n":"XmlSecureResolverMessage","d":5227253,"h":399437185781,"f":4194344},{"t":1310721,"n":"XmlSecureResolverDiagId","d":5227253,"h":403732153077,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":5227253,"h":408027120373,"f":4194344},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":5227253,"h":412322087669,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":5227253,"h":416617054965,"f":4194344},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":5227253,"h":420912022261,"f":4194344},{"t":1310721,"n":"LegacyFormatterMessage","d":5227253,"h":425206989557,"f":4194344},{"t":1310721,"n":"LegacyFormatterDiagId","d":5227253,"h":429501956853,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplMessage","d":5227253,"h":433796924149,"f":4194344},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":5227253,"h":438091891445,"f":4194344},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":5227253,"h":442386858741,"f":4194344},{"t":1310721,"n":"RegexExtensibilityDiagId","d":5227253,"h":446681826037,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":5227253,"h":450976793333,"f":4194344},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":5227253,"h":455271760629,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":5227253,"h":459566727925,"f":4194344},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":5227253,"h":463861695221,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":5227253,"h":468156662517,"f":4194344},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":5227253,"h":472451629813,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":5227253,"h":476746597109,"f":4194344},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":5227253,"h":481041564405,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":5227253,"h":485336531701,"f":4194344},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":5227253,"h":489631498997,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":5227253,"h":493926466293,"f":4194344},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":5227253,"h":498221433589,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":5227253,"h":502516400885,"f":4194344},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":5227253,"h":506811368181,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":5227253,"h":511106335477,"f":4194344},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":5227253,"h":515401302773,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":5227253,"h":519696270069,"f":4194344},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":5227253,"h":523991237365,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":5227253,"h":528286204661,"f":4194344},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":5227253,"h":532581171957,"f":4194344}],"h":5227253}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$snp.System.Net.IPAddressParserStatics", ($self) => class IPAddressParserStatics
        {
            /*int*/ static IPv4AddressBytes = 4;
            /*int*/ static IPv6AddressBytes = 16;
            /*int*/ static IPv6AddressShorts = 8;
            static $h = 3261173;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"IPv4AddressBytes","d":3261173,"h":4298228469,"f":4194337},{"t":655361,"n":"IPv6AddressBytes","d":3261173,"h":8593195765,"f":4194337},{"t":655361,"n":"IPv6AddressShorts","d":3261173,"h":12888163061,"f":4194337}],"h":3261173}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.IPAddressParserStatics`; }
        });
        
        $asm.$cls("$snp.System.Net.SocketAddressPal", ($self) => class SocketAddressPal
        {
            /*int*/ static IPv4AddressSize = 0;
            /*int*/ static IPv6AddressSize = 0;
            /*int*/ static UdsAddressSize = 0;
            /*int*/ static MaxAddressSize = 0;
            /*Static constructor*/ static $cctor()
            {
                /*int*/ let ipv4 = 0;
                /*int*/ let ipv6 = 0;
                /*int*/ let uds = 0;
                /*int*/ let max = 0;
                /*Interop.Error*/ let err = $.$snp.Interop.Sys.GetSocketAddressSizes($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Int32, () => ipv4, ($v) => ipv4 = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Int32, () => ipv6, ($v) => ipv6 = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Int32, () => uds, ($v) => uds = $v, null), $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Int32, () => max, ($v) => max = $v, null));
                $.$$.System.Diagnostics.Debug.Assert$4(err === 0/*Interop.Error.SUCCESS*/, `Unexpected err: ${err}`);
                $.$$.System.Diagnostics.Debug.Assert$2(ipv4 > 0, "ipv4 > 0");
                $.$$.System.Diagnostics.Debug.Assert$2(ipv6 > 0, "ipv6 > 0");
                $.$$.System.Diagnostics.Debug.Assert$2(uds > 0, "uds > 0");
                $.$$.System.Diagnostics.Debug.Assert$2(max >= ipv4 && max >= ipv6 && max >= uds, "max >= ipv4 && max >= ipv6 && max >= uds");
                $.$snp.System.Net.SocketAddressPal.IPv4AddressSize = ipv4;
                $.$snp.System.Net.SocketAddressPal.IPv6AddressSize = ipv6;
                $.$snp.System.Net.SocketAddressPal.UdsAddressSize = uds;
                $.$snp.System.Net.SocketAddressPal.MaxAddressSize = max;
            }
            static /*void */ ThrowOnFailure(/*Interop.Error*/ err)
            {
                switch(err)
                {
                    case 0/*Interop.Error.SUCCESS*/:
                    return;
                    case 65557/*Interop.Error.EFAULT*/:
                    throw new $.$$.System.IndexOutOfRangeException().$ctor$9();
                    case 65541/*Interop.Error.EAFNOSUPPORT*/:
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                    default:
                    $.$$.System.Diagnostics.Debug.Fail$1("Unexpected failure in GetAddressFamily");
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            static /*AddressFamily */ GetAddressFamily(/*ReadOnlySpan<byte>*/ buffer)
            {
                /*AddressFamily*/ let family;
                /*Interop.Error*/ let err;
                /*fixed*/ 
                {
                    /*byte**/ let rawAddress = buffer.GetPinnableReference();
                    err = $.$snp.Interop.Sys.GetAddressFamily(rawAddress, buffer.Length, $.$cast($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$snp.System.Net.Sockets.AddressFamily, () => family, ($v) => family = $v, null), $.$typePointer($.$$.System.Int32)));
                }
                $.$snp.System.Net.SocketAddressPal.ThrowOnFailure(err);
                return family;
            }
            static /*void */ SetAddressFamily(/*Span<byte>*/ buffer, /*AddressFamily*/ family)
            {
                /*Interop.Error*/ let err;
                if (family !== -1/*AddressFamily.Unknown*/)
                {
                    /*fixed*/ 
                    {
                        /*byte**/ let rawAddress = buffer.GetPinnableReference();
                        err = $.$snp.Interop.Sys.SetAddressFamily(rawAddress, buffer.Length, family);
                    }
                    $.$snp.System.Net.SocketAddressPal.ThrowOnFailure(err);
                }
            }
            static /*ushort */ GetPort(/*ReadOnlySpan<byte>*/ buffer)
            {
                /*ushort*/ let port;
                /*Interop.Error*/ let err;
                /*fixed*/ 
                {
                    /*byte**/ let rawAddress = buffer.GetPinnableReference();
                    err = $.$snp.Interop.Sys.GetPort(rawAddress, buffer.Length, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.UInt16, () => port, ($v) => port = $v, null));
                }
                $.$snp.System.Net.SocketAddressPal.ThrowOnFailure(err);
                return port;
            }
            static /*void */ SetPort(/*Span<byte>*/ buffer, /*ushort*/ port)
            {
                /*Interop.Error*/ let err;
                /*fixed*/ 
                {
                    /*byte**/ let rawAddress = buffer.GetPinnableReference();
                    err = $.$snp.Interop.Sys.SetPort(rawAddress, buffer.Length, port);
                }
                $.$snp.System.Net.SocketAddressPal.ThrowOnFailure(err);
            }
            static /*uint */ GetIPv4Address(/*ReadOnlySpan<byte>*/ buffer)
            {
                /*uint*/ let ipAddress;
                /*Interop.Error*/ let err;
                /*fixed*/ 
                {
                    /*byte**/ let rawAddress = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Byte, buffer);
                    err = $.$snp.Interop.Sys.GetIPv4Address(rawAddress, buffer.Length, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.UInt32, () => ipAddress, ($v) => ipAddress = $v, null));
                }
                $.$snp.System.Net.SocketAddressPal.ThrowOnFailure(err);
                return ipAddress;
            }
            static /*void */ GetIPv6Address(/*ReadOnlySpan<byte>*/ buffer, /*Span<byte>*/ address, /*out uint*/ scope)
            {
                /*uint*/ let localScope;
                /*Interop.Error*/ let err;
                /*fixed*/ 
                {
                    /*byte**/ let rawAddress = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$$.System.Byte, buffer);
                    /*fixed*/ 
                    {
                        /*byte**/ let ipAddress = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Byte, address);
                        err = $.$snp.Interop.Sys.GetIPv6Address(rawAddress, buffer.Length, ipAddress, address.Length, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.UInt32, () => localScope, ($v) => localScope = $v, null));
                    }
                }
                $.$snp.System.Net.SocketAddressPal.ThrowOnFailure(err);
                scope.$v = localScope;
            }
            static /*void */ SetIPv4Address$1(/*Span<byte>*/ buffer, /*uint*/ address)
            {
                /*Interop.Error*/ let err;
                /*fixed*/ 
                {
                    /*byte**/ let rawAddress = buffer.GetPinnableReference();
                    err = $.$snp.Interop.Sys.SetIPv4Address(rawAddress, buffer.Length, address);
                }
                $.$snp.System.Net.SocketAddressPal.ThrowOnFailure(err);
            }
            static /*void */ SetIPv4Address(/*Span<byte>*/ buffer, /*byte**/ address)
            {
                /*uint*/ let addr = ($.$$.System.Runtime.InteropServices.Marshal.ReadInt32$1($.$cast(address, $.$$.System.IntPtr)) >>> 0);
                $.$snp.System.Net.SocketAddressPal.SetIPv4Address$1(buffer, addr);
            }
            static /*void */ SetIPv6Address$1(/*Span<byte>*/ buffer, /*Span<byte>*/ address, /*uint*/ scope)
            {
                /*fixed*/ 
                {
                    /*byte**/ let rawInput = $.$$.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$$.System.Byte, address);
                    $.$snp.System.Net.SocketAddressPal.SetIPv6Address(buffer, rawInput, address.Length, scope);
                }
            }
            static /*void */ SetIPv6Address(/*Span<byte>*/ buffer, /*byte**/ address, /*int*/ addressLength, /*uint*/ scope)
            {
                /*Interop.Error*/ let err;
                /*fixed*/ 
                {
                    /*byte**/ let rawAddress = buffer.GetPinnableReference();
                    err = $.$snp.Interop.Sys.SetIPv6Address(rawAddress, buffer.Length, address, addressLength, scope);
                }
                $.$snp.System.Net.SocketAddressPal.ThrowOnFailure(err);
            }
            static /*void */ Clear(/*Span<byte>*/ buffer)
            {
                /*AddressFamily*/ let family = $.$snp.System.Net.SocketAddressPal.GetAddressFamily($.$$.System.Span$$($.$$.System.Byte).op_Implicit(buffer));
                buffer.Clear();
                buffer.get_Item(0).$v = $.$cast($.$$.System.Math.Min$4(buffer.Length, 255), $.$$.System.Byte);
                $.$snp.System.Net.SocketAddressPal.SetAddressFamily(buffer, family);
            }
            static $h = 4440821;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"err","p":246517}],"n":"ThrowOnFailure","d":4440821,"h":25774244597,"f":16777250},{"r":4506357,"p":[{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"GetAddressFamily","d":4440821,"h":30069211893,"f":16777249},{"r":65537,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"family","p":4506357}],"n":"SetAddressFamily","d":4440821,"h":34364179189,"f":16777249},{"r":589825,"p":[{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"GetPort","d":4440821,"h":38659146485,"f":16777249},{"r":65537,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"port","p":589825}],"n":"SetPort","d":4440821,"h":42954113781,"f":16777249},{"r":720897,"p":[{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"GetIPv4Address","d":4440821,"h":47249081077,"f":16777249},{"r":65537,"p":[{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"address","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"scope","p":720897,"f":2}],"n":"GetIPv6Address","d":4440821,"h":51544048373,"f":16777249},{"r":65537,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"address","p":720897}],"n":"SetIPv4Address","o":"@$1","d":4440821,"h":55839015669,"f":16777249},{"r":65537,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"address","p":$.$typePointer($.$$.System.Byte).$h}],"n":"SetIPv4Address","d":4440821,"h":60133982965,"f":16777249},{"r":65537,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"address","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"scope","p":720897}],"n":"SetIPv6Address","o":"@$1","d":4440821,"h":64428950261,"f":16777249},{"r":65537,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"address","p":$.$typePointer($.$$.System.Byte).$h},{"n":"addressLength","p":655361},{"n":"scope","p":720897}],"n":"SetIPv6Address","d":4440821,"h":68723917557,"f":16777249},{"r":65537,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"Clear","d":4440821,"h":73018884853,"f":16777249}],"l":[{"t":655361,"n":"IPv4AddressSize","d":4440821,"h":4299408117,"f":4194337},{"t":655361,"n":"IPv6AddressSize","d":4440821,"h":8594375413,"f":4194337},{"t":655361,"n":"UdsAddressSize","d":4440821,"h":12889342709,"f":4194337},{"t":655361,"n":"MaxAddressSize","d":4440821,"h":17184310005,"f":4194337}],"h":4440821}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.SocketAddressPal`; }
        });
        
        $asm.$cls("$snp.System.Net.CookieContainer", ($self) => class CookieContainer extends $.$$.System.Object
        {
            /*int*/ static DefaultCookieLimit = 300;
            /*int*/ static DefaultPerDomainCookieLimit = 20;
            /*int*/ static DefaultCookieLengthLimit = 4096;
            /*HeaderVariantInfo[]*/ static s_headerInfo = null;
            /*Hashtable*/ m_domainTable = null;
            /*int*/ m_maxCookieSize = 4096;
            /*int*/ m_maxCookies = 300;
            /*int*/ m_maxCookiesPerDomain = 20;
            /*int*/ m_count = 0;
            /*string*/ m_fqdnMyDomain = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*int*/ capacity)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, capacity, "capacity");
                    this.m_maxCookies = capacity;
                }
                return this;
            }
            $ctor$2(/*int*/ capacity, /*int*/ perDomainCapacity, /*int*/ maxCookieSize)
            {
                this.$ctor$3(capacity);
                {
                    if (perDomainCapacity !== 2147483647/*int.MaxValue*/ && (perDomainCapacity <= 0 || perDomainCapacity > capacity))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("perDomainCapacity", $.$snp.System.SR.Format$4($.$snp.System.SR.net_cookie_capacity_range, "PerDomainCapacity", $.$box(0, $.$$.System.Int32), $.$box(capacity, $.$$.System.Int32)));
                    }
                    this.m_maxCookiesPerDomain = perDomainCapacity;
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, maxCookieSize, "maxCookieSize");
                    this.m_maxCookieSize = maxCookieSize;
                }
                return this;
            }
            /*int */ get Capacity()
            {
                return this.m_maxCookies;
            }
            /*int */ set Capacity(value)
            {
                if (value <= 0 || (value < this.m_maxCookiesPerDomain && this.m_maxCookiesPerDomain !== 2147483647/*int.MaxValue*/))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$19("value", $.$snp.System.SR.Format$4($.$snp.System.SR.net_cookie_capacity_range, "Capacity", $.$box(0, $.$$.System.Int32), $.$box(this.m_maxCookiesPerDomain, $.$$.System.Int32)));
                }
                if (value < this.m_maxCookies)
                {
                    this.m_maxCookies = value;
                    this.AgeCookies(null);
                }
                this.m_maxCookies = value;
            }
            /*int */ get Count()
            {
                return this.m_count;
            }
            /*int */ get MaxCookieSize()
            {
                return this.m_maxCookieSize;
            }
            /*int */ set MaxCookieSize(value)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, value, "value");
                this.m_maxCookieSize = value;
            }
            /*int */ get PerDomainCapacity()
            {
                return this.m_maxCookiesPerDomain;
            }
            /*int */ set PerDomainCapacity(value)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$$.System.Int32, value, "value");
                if (value !== 2147483647/*int.MaxValue*/)
                {
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, value, this.m_maxCookies, "value");
                }
                if (value < this.m_maxCookiesPerDomain)
                {
                    this.m_maxCookiesPerDomain = value;
                    this.AgeCookies(null);
                }
                this.m_maxCookiesPerDomain = value;
            }
            /*void */ Add(/*Cookie*/ cookie)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(cookie, "cookie");
                if (cookie.Domain.length === 0)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$snp.System.SR.Format$6($.$snp.System.SR.net_emptystringcall, "cookie" + "." + "Domain"), "cookie");
                }
                /*Uri?*/ let uri;
                /*var*/ let uriSb = new $.$$.System.Text.StringBuilder().$ctor$1();
                uriSb.Append$19(cookie.Secure ? "https"/*UriScheme.Https*/ : "http"/*UriScheme.Http*/).Append$19("://"/*UriScheme.SchemeDelimiter*/);
                if (!cookie.DomainImplicit)
                {
                    if ($.$$.System.String.get_Chars.call(cookie.Domain, 0) === /*.*/ 46)
                    {
                        uriSb.Append$3(/*0*/ 48);
                    }
                }
                uriSb.Append$19(cookie.Domain);
                if (cookie.PortList !== null)
                {
                    uriSb.Append$3(/*:*/ 58).Append$11($.$$.System.Array.$ReadT1.call(cookie.PortList, 0));
                }
                uriSb.Append$19(cookie.Path);
                if (!$.$spu.System.Uri.TryCreate($.$$.System.Text.StringBuilder.ToString.call(uriSb), 1/*UriKind.Absolute*/, $.$ref(() => uri, ($v) => uri = $v, $.$spu.System.Uri)))
                {
                    throw new $.$snp.System.Net.CookieException().$ctor$16($.$snp.System.SR.Format$5($.$snp.System.SR.net_cookie_attribute, "Domain", cookie.Domain));
                }
                /*Cookie*/ let new_cookie = cookie.Clone();
                new_cookie.VerifyAndSetDefaults(new_cookie.Variant, uri);
                this.InternalAdd(new_cookie);
            }
            /*void */ InternalAdd(/*Cookie*/ cookie)
            {
                /*PathList?*/ let pathList;
                if (cookie.Value.length > this.m_maxCookieSize)
                {
                    throw new $.$snp.System.Net.CookieException().$ctor$16($.$snp.System.SR.Format$5($.$snp.System.SR.net_cookie_size, cookie, $.$box(this.m_maxCookieSize, $.$$.System.Int32)));
                }
                try
                {
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this.m_domainTable.SyncRoot)
                        {
                            pathList = $.$cast(this.m_domainTable.get_Item(cookie.DomainKey), $.$snp.System.Net.PathList);
                            if (pathList === null)
                            {
                                this.m_domainTable.set_Item(cookie.DomainKey, (pathList = new $.$snp.System.Net.PathList().$ctor$1()));
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this.m_domainTable.SyncRoot)
                    }
                    /*int*/ let domain_count = pathList.GetCookiesCount();
                    /*CookieCollection?*/ let cookies;
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(pathList.SyncRoot)
                        {
                            cookies = $.$cast(pathList.get_Item(cookie.Path), $.$snp.System.Net.CookieCollection);
                            if (cookies === null)
                            {
                                cookies = new $.$snp.System.Net.CookieCollection().$ctor$1();
                                pathList.set_Item(cookie.Path, cookies);
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(pathList.SyncRoot)
                    }
                    if (cookie.Expired)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(cookies)
                            {
                                /*int*/ let idx = cookies.IndexOf(cookie);
                                if (idx !== -1)
                                {
                                    cookies.RemoveAt(idx);
                                    --this.m_count;
                                }
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(cookies)
                        }
                    }
                    else 
                    {
                        if (domain_count >= this.m_maxCookiesPerDomain && !this.AgeCookies(cookie.DomainKey))
                        {
                            return;
                        }
                        else if (this.m_count >= this.m_maxCookies && !this.AgeCookies(null))
                        {
                            return;
                        }
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(cookies)
                            {
                                this.m_count += cookies.InternalAdd(cookie, true);
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(cookies)
                        }
                    }
                    if (this.m_domainTable.Count > this.m_count || pathList.Count > this.m_maxCookiesPerDomain)
                    {
                        this.DomainTableCleanup();
                    }
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.OutOfMemoryException)
                    {
                        throw $e;
                    }
                    else if ($e instanceof $.$$.System.Exception)
                    {
                        let e = $e;
                        throw new $.$snp.System.Net.CookieException().$ctor$15($.$snp.System.SR.net_container_add_cookie, e);
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            /*bool */ AgeCookies(/*string?*/ domain)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this.m_maxCookies !== 0, "m_maxCookies != 0");
                $.$$.System.Diagnostics.Debug.Assert$2(this.m_maxCookiesPerDomain !== 0, "m_maxCookiesPerDomain != 0");
                /*int*/ let removed = 0;
                /*DateTime*/ let oldUsed = $.$$.System.DateTime.MaxValue;
                /*DateTime*/ let tempUsed;
                /*CookieCollection?*/ let lruCc = null;
                /*string?*/ let lruDomain;
                /*string*/ let tempDomain;
                /*PathList*/ let pathList;
                /*int*/ let domain_count;
                /*int*/ let itemp = 0;
                /*float*/ let remainingFraction = 1;
                if (this.m_count > this.m_maxCookies)
                {
                    remainingFraction = $.$cast(this.m_maxCookies, $.$$.System.Single) / $.$cast(this.m_count, $.$$.System.Single);
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.m_domainTable.SyncRoot)
                    {
                        var $en4 = this.m_domainTable.GetEnumerator();
                        while ($en4.System$Collections$IEnumerator$MoveNext())
                        {
                            var item = $en4.System$Collections$IEnumerator$Current;
                            {
                                /*DictionaryEntry*/ let entry = $.$cast(item, $.$$.System.Collections.DictionaryEntry);
                                if ($.$$.System.String.op_Equality(domain, null))
                                {
                                    tempDomain = $.$cast(entry.Key, $.$$.System.String);
                                    pathList = $.$cast(entry.Value, $.$snp.System.Net.PathList);
                                }
                                else 
                                {
                                    tempDomain = domain;
                                    pathList = $.$cast(this.m_domainTable.get_Item(domain), $.$snp.System.Net.PathList);
                                }
                                domain_count = 0;
                                //lock
                                try
                                {
                                    $.$$.System.Threading.Monitor.Enter$1(pathList.SyncRoot)
                                    {
                                        var $en8 = pathList.Values.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                        while ($en8.System$Collections$IEnumerator$MoveNext())
                                        {
                                            var cc = $en8.System$Collections$Generic$IEnumerator$$$Current;
                                            {
                                                $.$$.System.Diagnostics.Debug.Assert$2(cc !== null, "cc != null");
                                                itemp = $.$snp.System.Net.CookieContainer.ExpireCollection(cc);
                                                removed += itemp;
                                                this.m_count -= itemp;
                                                domain_count += cc.Count;
                                                if (cc.Count > 0 && $.$$.System.DateTime.op_LessThan((tempUsed = cc.TimeStamp(0/*CookieCollection.Stamp.Check*/)), oldUsed))
                                                {
                                                    lruDomain = tempDomain;
                                                    lruCc = cc;
                                                    oldUsed = tempUsed;
                                                }
                                            }
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$$.System.Threading.Monitor.Exit(pathList.SyncRoot)
                                }
                                /*int*/ let min_count = $.$$.System.Math.Min$4($.$cast((domain_count * remainingFraction), $.$$.System.Int32), (($.$$.System.Math.Min$4(this.m_maxCookiesPerDomain, this.m_maxCookies) - 1) | 0));
                                if (domain_count > min_count)
                                {
                                    /*CookieCollection[]*/ let cookies;
                                    /*DateTime[]*/ let stamps;
                                    //lock
                                    try
                                    {
                                        $.$$.System.Threading.Monitor.Enter$1(pathList.SyncRoot)
                                        {
                                            cookies = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$snp.System.Net.CookieCollection), null, [pathList.Count], null);
                                            stamps = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.DateTime), null, [pathList.Count], null);
                                            var $en9 = pathList.Values.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                            while ($en9.System$Collections$IEnumerator$MoveNext())
                                            {
                                                var cc = $en9.System$Collections$Generic$IEnumerator$$$Current;
                                                {
                                                    $.$$.System.Array.$WriteT1.call(stamps, cc.TimeStamp(0/*CookieCollection.Stamp.Check*/), itemp);
                                                    $.$$.System.Array.$WriteT1.call(cookies, cc, itemp);
                                                    ++itemp;
                                                }
                                            }
                                        }
                                    }
                                    finally
                                    {
                                        $.$$.System.Threading.Monitor.Exit(pathList.SyncRoot)
                                    }
                                    $.$$.System.Array.Sort$16($.$$.System.DateTime, $.$snp.System.Net.CookieCollection, stamps, cookies);
                                    itemp = 0;
                                    for(/*int*/ let i = 0; i < cookies.length; ++i)
                                    {
                                        /*CookieCollection*/ let cc = $.$$.System.Array.$ReadT1.call(cookies, i);
                                        //lock
                                        try
                                        {
                                            $.$$.System.Threading.Monitor.Enter$1(cc)
                                            {
                                                while(domain_count > min_count && cc.Count > 0)
                                                {
                                                    cc.RemoveAt(0);
                                                    --domain_count;
                                                    --this.m_count;
                                                    ++removed;
                                                }
                                            }
                                        }
                                        finally
                                        {
                                            $.$$.System.Threading.Monitor.Exit(cc)
                                        }
                                        if (domain_count <= min_count)
                                        {
                                            break;
                                        }
                                    }
                                    if (domain_count > min_count && $.$$.System.String.op_Inequality(domain, null))
                                    {
                                        return false;
                                    }
                                }
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.m_domainTable.SyncRoot)
                }
                if ($.$$.System.String.op_Inequality(domain, null))
                {
                    return true;
                }
                if (removed !== 0)
                {
                    return true;
                }
                if ($.$$.System.DateTime.op_Equality(oldUsed, $.$$.System.DateTime.MaxValue))
                {
                    return false;
                }
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(lruCc)
                    {
                        while(this.m_count >= this.m_maxCookies && lruCc.Count > 0)
                        {
                            lruCc.RemoveAt(0);
                            --this.m_count;
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(lruCc)
                }
                return true;
            }
            /*void */ DomainTableCleanup()
            {
                /*var*/ let removePathList = new ($.$$.System.Collections.Generic.List$$($.$$.System.Object))().$ctor$1();
                /*var*/ let removeDomainList = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                /*string*/ let currentDomain;
                /*PathList*/ let pathList;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.m_domainTable.SyncRoot)
                    {
                        /*IDictionaryEnumerator*/ let enumerator = this.m_domainTable.GetEnumerator();
                        while(enumerator.System$Collections$IEnumerator$MoveNext())
                        {
                            currentDomain = $.$cast(enumerator.System$Collections$IDictionaryEnumerator$Key, $.$$.System.String);
                            pathList = $.$cast(enumerator.System$Collections$IDictionaryEnumerator$Value, $.$snp.System.Net.PathList);
                            //lock
                            try
                            {
                                $.$$.System.Threading.Monitor.Enter$1(pathList.SyncRoot)
                                {
                                    /*IDictionaryEnumerator*/ let e = pathList.GetEnumerator();
                                    while(e.System$Collections$IEnumerator$MoveNext())
                                    {
                                        /*CookieCollection*/ let cc = $.$cast(e.System$Collections$IDictionaryEnumerator$Value, $.$snp.System.Net.CookieCollection);
                                        if (cc.Count === 0)
                                        {
                                            removePathList.Add(e.System$Collections$IDictionaryEnumerator$Key);
                                        }
                                    }
                                    var $en7 = removePathList.GetEnumerator();
                                    while ($en7.MoveNext())
                                    {
                                        var key = $en7.Current;
                                        {
                                            pathList.Remove(key);
                                        }
                                    }
                                    removePathList.Clear();
                                    if (pathList.Count === 0)
                                    {
                                        removeDomainList.Add(currentDomain);
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.System.Threading.Monitor.Exit(pathList.SyncRoot)
                            }
                        }
                        var $en4 = removeDomainList.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var key = $en4.Current;
                            {
                                this.m_domainTable.Remove(key);
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.m_domainTable.SyncRoot)
                }
            }
            static /*int */ ExpireCollection(/*CookieCollection*/ cc)
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(cc)
                    {
                        /*int*/ let oldCount = cc.Count;
                        /*int*/ let idx = ((oldCount - 1) | 0);
                        while(idx >= 0)
                        {
                            /*Cookie*/ let cookie = cc.get_Item(idx);
                            if (cookie.Expired)
                            {
                                cc.RemoveAt(idx);
                            }
                            --idx;
                        }
                        return ((oldCount - cc.Count) | 0);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(cc)
                }
            }
            /*void */ Add$1(/*CookieCollection*/ cookies)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(cookies, "cookies");
                var $en2 = cookies.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var c = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.Add(c);
                    }
                }
            }
            /*void */ Add$2(/*Uri*/ uri, /*Cookie*/ cookie)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(cookie, "cookie");
                /*Cookie*/ let new_cookie = cookie.Clone();
                new_cookie.VerifyAndSetDefaults(new_cookie.Variant, uri);
                this.InternalAdd(new_cookie);
            }
            /*void */ Add$3(/*Uri*/ uri, /*CookieCollection*/ cookies)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(cookies, "cookies");
                var $en2 = cookies.GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var c = $en2.System$Collections$IEnumerator$Current;
                    {
                        /*Cookie*/ let new_cookie = c.Clone();
                        new_cookie.VerifyAndSetDefaults(new_cookie.Variant, uri);
                        this.InternalAdd(new_cookie);
                    }
                }
            }
            /*CookieCollection */ CookieCutter(/*Uri*/ uri, /*string?*/ headerName, /*string*/ setCookieHeader)
            {
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `uri:${$.$spu.System.Uri.ToString.call(uri)} headerName:${headerName} setCookieHeader:${setCookieHeader}`, "CookieCutter");
                }
                /*CookieCollection*/ let cookies = new $.$snp.System.Net.CookieCollection().$ctor$1();
                /*CookieVariant*/ let variant = 0/*CookieVariant.Unknown*/;
                if ($.$$.System.String.op_Equality(headerName, null))
                {
                    variant = 2/*CookieVariant.Default*/;
                }
                else 
                {
                    for(/*int*/ let i = 0; i < $.$snp.System.Net.CookieContainer.s_headerInfo.length; ++i)
                    {
                        if ($.$$.System.String.Equals$2(headerName, $.$$.System.Array.$ReadT1.call($.$snp.System.Net.CookieContainer.s_headerInfo, i).Name, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            variant = $.$$.System.Array.$ReadT1.call($.$snp.System.Net.CookieContainer.s_headerInfo, i).Variant;
                        }
                    }
                }
                try
                {
                    /*CookieParser*/ let parser = new $.$snp.System.Net.CookieParser().$ctor$3(setCookieHeader);
                    do
                    {
                        /*Cookie?*/ let cookie = parser.Get();
                        if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                        {
                            $.$snp.System.Net.NetEventSource.Info(this, `CookieParser returned cookie:${$.$snp.System.Net.Cookie.ToString.call(cookie)}`, "CookieCutter");
                        }
                        if (cookie === null)
                        {
                            if (parser.EndofHeader())
                            {
                                break;
                            }
                            continue;
                        }
                        if ($.$$.System.String.IsNullOrEmpty(cookie.Name))
                        {
                            throw new $.$snp.System.Net.CookieException().$ctor$16($.$snp.System.SR.net_cookie_format);
                        }
                        cookie.VerifyAndSetDefaults(variant, uri);
                        cookies.InternalAdd(cookie, true);
                    }
                    while(true);
                }
                catch($e)
                {
                    if ($e instanceof $.$$.System.OutOfMemoryException)
                    {
                        throw $e;
                    }
                    else if ($e instanceof $.$$.System.Exception)
                    {
                        let e = $e;
                        throw new $.$snp.System.Net.CookieException().$ctor$15($.$snp.System.SR.Format$6($.$snp.System.SR.net_cookie_parse_header, uri.AbsoluteUri), e);
                    }
                    else
                    {
                        throw $e;
                    }
                }
                /*int*/ let cookiesCount = cookies.Count;
                for(/*int*/ let i = 0; i < cookiesCount; i++)
                {
                    this.InternalAdd(cookies.get_Item(i));
                }
                return cookies;
            }
            /*CookieCollection */ GetCookies(/*Uri*/ uri)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                return this.InternalGetCookies(uri) ?? new $.$snp.System.Net.CookieCollection().$ctor$1();
            }
            /*CookieCollection */ GetAllCookies()
            {
                /*var*/ let result = new $.$snp.System.Net.CookieCollection().$ctor$1();
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.m_domainTable.SyncRoot)
                    {
                        /*IDictionaryEnumerator*/ let lists = this.m_domainTable.GetEnumerator();
                        while(lists.System$Collections$IEnumerator$MoveNext())
                        {
                            /*PathList*/ let list = $.$cast(lists.System$Collections$IDictionaryEnumerator$Value, $.$snp.System.Net.PathList);
                            //lock
                            try
                            {
                                $.$$.System.Threading.Monitor.Enter$1(list.SyncRoot)
                                {
                                    /*IDictionaryEnumerator*/ let collections = list.List.GetEnumerator();
                                    while(collections.System$Collections$IEnumerator$MoveNext())
                                    {
                                        result.Add$1($.$cast(collections.System$Collections$IDictionaryEnumerator$Value, $.$snp.System.Net.CookieCollection));
                                    }
                                }
                            }
                            finally
                            {
                                $.$$.System.Threading.Monitor.Exit(list.SyncRoot)
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.m_domainTable.SyncRoot)
                }
                return result;
            }
            /*CookieCollection? */ InternalGetCookies(/*Uri*/ uri)
            {
                if (this.m_count === 0)
                {
                    return null;
                }
                /*bool*/ let isSecure = ($.$$.System.String.op_Equality(uri.Scheme, "https"/*UriScheme.Https*/) || $.$$.System.String.op_Equality(uri.Scheme, "wss"/*UriScheme.Wss*/));
                /*int*/ let port = uri.Port;
                /*CookieCollection?*/ let cookies = null;
                /*List<string>*/ let matchingDomainKeys = (() =>
                {
                    let $t1 = new ($.$$.System.Collections.Generic.List$$($.$$.System.String))().$ctor$1();
                    $t1.Add(uri.Host);
                    return $t1;
                })();
                /*ReadOnlySpan<char>*/ let host = $.$$.System.String.op_Implicit(uri.Host);
                /*int*/ let lastDot = $.$$.System.MemoryExtensions.LastIndexOf$4($.$$.System.Char, host, /*.*/ 46);
                while(lastDot > 0)
                {
                    let $t1 = host;
                    /*int*/ let dot = $.$$.System.MemoryExtensions.LastIndexOf$4($.$$.System.Char, $t1.Slice(0, lastDot), /*.*/ 46);
                    if (dot > 0)
                    {
                        let $t2 = host;
                        /*string*/ let match = $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call($t2.Slice((((dot + 1) | 0)), $t2.Length - (((dot + 1) | 0))));
                        matchingDomainKeys.Add(match);
                    }
                    lastDot = dot;
                }
                this.BuildCookieCollectionFromDomainMatches(uri, isSecure, port, $.$ref(() => cookies, ($v) => cookies = $v, $.$snp.System.Net.CookieCollection), matchingDomainKeys);
                return cookies;
            }
            /*void */ BuildCookieCollectionFromDomainMatches(/*Uri*/ uri, /*bool*/ isSecure, /*int*/ port, /*ref CookieCollection?*/ cookies, /*List<string>*/ matchingDomainKeys)
            {
                for(/*int*/ let i = 0; i < matchingDomainKeys.Count; i++)
                {
                    /*PathList*/ let pathList;
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(this.m_domainTable.SyncRoot)
                        {
                            pathList = $.$cast(this.m_domainTable.get_Item(matchingDomainKeys.get_Item(i)), $.$snp.System.Net.PathList);
                            if (pathList === null)
                            {
                                continue;
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(this.m_domainTable.SyncRoot)
                    }
                    //lock
                    try
                    {
                        $.$$.System.Threading.Monitor.Enter$1(pathList.SyncRoot)
                        {
                            /*SortedList*/ let list = pathList.List;
                            /*int*/ let listCount = list.Count;
                            for(/*int*/ let e = 0; e < listCount; e++)
                            {
                                /*string*/ let path = $.$cast(list.GetKey(e), $.$$.System.String);
                                if ($.$snp.System.Net.CookieContainer.PathMatch(uri.AbsolutePath, path))
                                {
                                    /*CookieCollection*/ let cc = $.$cast(list.GetByIndex(e), $.$snp.System.Net.CookieCollection);
                                    cc.TimeStamp(1/*CookieCollection.Stamp.Set*/);
                                    this.MergeUpdateCollections(cookies, uri.Host, cc, port, isSecure);
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$$.System.Threading.Monitor.Exit(pathList.SyncRoot)
                    }
                    if (pathList.Count === 0)
                    {
                        //lock
                        try
                        {
                            $.$$.System.Threading.Monitor.Enter$1(this.m_domainTable.SyncRoot)
                            {
                                this.m_domainTable.Remove(matchingDomainKeys.get_Item(i));
                            }
                        }
                        finally
                        {
                            $.$$.System.Threading.Monitor.Exit(this.m_domainTable.SyncRoot)
                        }
                    }
                }
            }
            static /*bool */ PathMatch(/*string*/ requestPath, /*string*/ cookiePath)
            {
                cookiePath = $.$snp.System.Net.CookieParser.CheckQuoted(cookiePath);
                if (!$.$$.System.String.StartsWith$2.call(requestPath, cookiePath, 4/*StringComparison.Ordinal*/))
                {
                    return false;
                }
                return requestPath.length === cookiePath.length || $.$$.System.String.EndsWith.call(cookiePath, /*/*/ 47) || $.$$.System.String.get_Chars.call(requestPath, cookiePath.length) === /*/*/ 47;
            }
            /*void */ MergeUpdateCollections(/*ref CookieCollection?*/ destination, /*string*/ host, /*CookieCollection*/ source, /*int*/ port, /*bool*/ isSecure)
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(source)
                    {
                        for(/*int*/ let idx = 0; idx < source.Count; ++idx)
                        {
                            /*bool*/ let to_add = false;
                            /*Cookie*/ let cookie = source.get_Item(idx);
                            if (cookie.Expired)
                            {
                                source.RemoveAt(idx);
                                --this.m_count;
                                --idx;
                            }
                            else 
                            {
                                if (cookie.PortList !== null)
                                {
                                    let $i1 = 0;
                                    let $arr1 = cookie.PortList;
                                    while ($i1 < $arr1.length)
                                    {
                                        let p = $arr1[$i1++];
                                        if (p === port)
                                        {
                                            to_add = true;
                                            break;
                                        }
                                    }
                                }
                                else 
                                {
                                    to_add = true;
                                }
                                if (cookie.Secure && !isSecure)
                                {
                                    to_add = false;
                                }
                                if (cookie.DomainImplicit && !$.$$.System.String.Equals$2(host, cookie.Domain, 5/*StringComparison.OrdinalIgnoreCase*/))
                                {
                                    to_add = false;
                                }
                                if (to_add)
                                {
                                    destination.$v ??= new $.$snp.System.Net.CookieCollection().$ctor$1();
                                    destination.$v.InternalAdd(cookie, false);
                                }
                            }
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(source)
                }
            }
            /*string */ GetCookieHeader$1(/*Uri*/ uri)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                return this.GetCookieHeader(uri, $.$discardRef());
            }
            /*string */ GetCookieHeader(/*Uri*/ uri, /*out string*/ optCookie2)
            {
                /*CookieCollection?*/ let cookies = this.InternalGetCookies(uri);
                if (cookies === null)
                {
                    optCookie2.$v = $.$$.System.String.Empty;
                    return $.$$.System.String.Empty;
                }
                /*string*/ let delimiter = $.$$.System.String.Empty;
                /*StringBuilder*/ let builder = $.$snp.System.Text.StringBuilderCache.Acquire(16);
                for(/*int*/ let i = 0; i < cookies.Count; i++)
                {
                    builder.Append$19(delimiter);
                    cookies.get_Item(i).ToString$1(builder);
                    delimiter = "; ";
                }
                optCookie2.$v = cookies.IsOtherVersionSeen ? ("$"/*Cookie.SpecialAttributeLiteral*/ + "Version"/*CookieFields.VersionAttributeName*/ + /*=*/ 61 + "1"/*Cookie.MaxSupportedVersionString*/) : $.$$.System.String.Empty;
                return $.$snp.System.Text.StringBuilderCache.GetStringAndRelease(builder);
            }
            /*void */ SetCookies(/*Uri*/ uri, /*string*/ cookieHeader)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uri, "uri");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(cookieHeader, "cookieHeader");
                this.CookieCutter(uri, null, cookieHeader);
            }
            //default member initializer
            constructor()
            {
                super();
                this.m_domainTable = new $.$$.System.Collections.Hashtable().$ctor$1();
                this.m_fqdnMyDomain = $.$$.System.String.Empty;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_headerInfo = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$snp.System.Net.HeaderVariantInfo), [new $.$snp.System.Net.HeaderVariantInfo().$ctor$3("Set-Cookie"/*HttpKnownHeaderNames.SetCookie*/, 2/*CookieVariant.Rfc2109*/), new $.$snp.System.Net.HeaderVariantInfo().$ctor$3("Set-Cookie2"/*HttpKnownHeaderNames.SetCookie2*/, 3/*CookieVariant.Rfc2965*/)], null, null);
                }
            }
            static $h = 1426165;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":64425935605,"f":50331649},"s":{"r":0,"d":0,"h":68720902901,"f":83886081},"n":"Capacity","d":1426165,"h":60130968309,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":77310837493,"f":50331649},"n":"Count","d":1426165,"h":73015870197,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":85900772085,"f":50331649},"s":{"r":0,"d":0,"h":90195739381,"f":83886081},"n":"MaxCookieSize","d":1426165,"h":81605804789,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":98785673973,"f":50331649},"s":{"r":0,"d":0,"h":103080641269,"f":83886081},"n":"PerDomainCapacity","d":1426165,"h":94490706677,"f":2097153}],"m":[{"r":65537,"p":[{"n":"cookie","p":1164021}],"n":"Add","d":1426165,"h":107375608565,"f":16777217},{"r":65537,"p":[{"n":"cookie","p":1164021}],"n":"InternalAdd","d":1426165,"h":111670575861,"f":16777224},{"r":262145,"p":[{"n":"domain","p":1310721}],"n":"AgeCookies","d":1426165,"h":115965543157,"f":16777218},{"r":65537,"n":"DomainTableCleanup","d":1426165,"h":120260510453,"f":16777218},{"r":655361,"p":[{"n":"cc","p":1229557}],"n":"ExpireCollection","d":1426165,"h":124555477749,"f":16777250},{"r":65537,"p":[{"n":"cookies","p":1229557}],"n":"Add","o":"@$1","d":1426165,"h":128850445045,"f":16777217},{"r":65537,"p":[{"n":"uri","p":1746220},{"n":"cookie","p":1164021}],"n":"Add","o":"@$2","d":1426165,"h":133145412341,"f":16777217},{"r":65537,"p":[{"n":"uri","p":1746220},{"n":"cookies","p":1229557}],"n":"Add","o":"@$3","d":1426165,"h":137440379637,"f":16777217},{"r":1229557,"p":[{"n":"uri","p":1746220},{"n":"headerName","p":1310721},{"n":"setCookieHeader","p":1310721}],"n":"CookieCutter","d":1426165,"h":141735346933,"f":16777224},{"r":1229557,"p":[{"n":"uri","p":1746220}],"n":"GetCookies","d":1426165,"h":146030314229,"f":16777217},{"r":1229557,"n":"GetAllCookies","d":1426165,"h":150325281525,"f":16777217},{"r":1229557,"p":[{"n":"uri","p":1746220}],"n":"InternalGetCookies","d":1426165,"h":154620248821,"f":16777224},{"r":65537,"p":[{"n":"uri","p":1746220},{"n":"isSecure","p":262145},{"n":"port","p":655361},{"n":"cookies","p":1229557,"f":4},{"n":"matchingDomainKeys","p":$.$$.System.Collections.Generic.List$$($.$$.System.String).$h}],"n":"BuildCookieCollectionFromDomainMatches","d":1426165,"h":158915216117,"f":16777218},{"r":262145,"p":[{"n":"requestPath","p":1310721},{"n":"cookiePath","p":1310721}],"n":"PathMatch","d":1426165,"h":163210183413,"f":16777250},{"r":65537,"p":[{"n":"destination","p":1229557,"f":4},{"n":"host","p":1310721},{"n":"source","p":1229557},{"n":"port","p":655361},{"n":"isSecure","p":262145}],"n":"MergeUpdateCollections","d":1426165,"h":167505150709,"f":16777218},{"r":1310721,"p":[{"n":"uri","p":1746220}],"n":"GetCookieHeader","o":"@$1","d":1426165,"h":171800118005,"f":16777217},{"r":1310721,"p":[{"n":"uri","p":1746220},{"n":"optCookie2","p":1310721,"f":2}],"n":"GetCookieHeader","d":1426165,"h":176095085301,"f":16777224},{"r":65537,"p":[{"n":"uri","p":1746220},{"n":"cookieHeader","p":1310721}],"n":"SetCookies","d":1426165,"h":180390052597,"f":16777217}],"l":[{"t":655361,"n":"DefaultCookieLimit","d":1426165,"h":4296393461,"f":4194337},{"t":655361,"n":"DefaultPerDomainCookieLimit","d":1426165,"h":8591360757,"f":4194337},{"t":655361,"n":"DefaultCookieLengthLimit","d":1426165,"h":12886328053,"f":4194337},{"t":$.$typeArray($.$snp.System.Net.HeaderVariantInfo).$h,"n":"s_headerInfo","d":1426165,"h":17181295349,"f":4194338},{"t":31064065,"n":"m_domainTable","d":1426165,"h":21476262645,"f":4194306},{"t":655361,"n":"m_maxCookieSize","d":1426165,"h":25771229941,"f":4194306},{"t":655361,"n":"m_maxCookies","d":1426165,"h":30066197237,"f":4194306},{"t":655361,"n":"m_maxCookiesPerDomain","d":1426165,"h":34361164533,"f":4194306},{"t":655361,"n":"m_count","d":1426165,"h":38656131829,"f":4194306},{"t":1310721,"n":"m_fqdnMyDomain","d":1426165,"h":42951099125,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1426165,"h":47246066421,"f":16777217},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$3","d":1426165,"h":51541033717,"f":16777217},{"p":[{"n":"capacity","p":655361},{"n":"perDomainCapacity","p":655361},{"n":"maxCookieSize","p":655361}],"n":".ctor","o":"$ctor$2","d":1426165,"h":55836001013,"f":16777217}],"h":1426165,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.CookieContainer`; }
        });
        
        $asm.$cls("$snp.System.Net.CredentialCacheHelper", ($self) => class CredentialCacheHelper
        {
            static /*bool */ TryGetCredential(/*Dictionary<CredentialCacheKey, NetworkCredential>*/ cache, /*Uri*/ uriPrefix, /*string*/ authType, /*out Uri?*/ mostSpecificMatchUri, /*out NetworkCredential?*/ mostSpecificMatch)
            {
                /*int*/ let longestMatchPrefix = -1;
                mostSpecificMatch.$v = null;
                mostSpecificMatchUri.$v = null;
                if (cache.Count === 0)
                {
                    return false;
                }
                /*int*/ let uriPrefixLength = $.$$.System.String.LastIndexOf$2.call(uriPrefix.AbsolutePath, /*/*/ 47);
                var $en2 = cache.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var $t1 = $en2.Current;
                    /*CredentialCacheKey*/ let key = $t1.Item1;
                    /*NetworkCredential*/ let value = $t1.Item2;
                    {
                        /*int*/ let prefixLen = key.UriPrefixLength;
                        if (prefixLen <= longestMatchPrefix)
                        {
                            continue;
                        }
                        if (key.Match(uriPrefix, uriPrefixLength, authType))
                        {
                            longestMatchPrefix = prefixLen;
                            mostSpecificMatch.$v = value;
                            mostSpecificMatchUri.$v = key.UriPrefix;
                            if (uriPrefixLength === prefixLen)
                            {
                                break;
                            }
                        }
                    }
                }
                return mostSpecificMatch.$v !== null;
            }
            static $h = 2278133;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"cache","p":$.$$.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialCacheKey, $.$snp.System.Net.NetworkCredential).$h},{"n":"uriPrefix","p":1746220},{"n":"authType","p":1310721},{"n":"mostSpecificMatchUri","p":1746220,"f":2},{"n":"mostSpecificMatch","p":3850997,"f":2}],"n":"TryGetCredential","d":2278133,"h":4297245429,"f":16777249}],"h":2278133}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.CredentialCacheHelper`; }
        });
        
        $asm.$cls("$snp.System.Net.HttpKnownHeaderNames", ($self) => class HttpKnownHeaderNames
        {
            /*string*/ static Accept = null;
            /*string*/ static AcceptCharset = null;
            /*string*/ static AcceptEncoding = null;
            /*string*/ static AcceptLanguage = null;
            /*string*/ static AcceptPatch = null;
            /*string*/ static AcceptRanges = null;
            /*string*/ static AccessControlAllowCredentials = null;
            /*string*/ static AccessControlAllowHeaders = null;
            /*string*/ static AccessControlAllowMethods = null;
            /*string*/ static AccessControlAllowOrigin = null;
            /*string*/ static AccessControlExposeHeaders = null;
            /*string*/ static AccessControlMaxAge = null;
            /*string*/ static Age = null;
            /*string*/ static Allow = null;
            /*string*/ static AltSvc = null;
            /*string*/ static Authorization = null;
            /*string*/ static CacheControl = null;
            /*string*/ static Connection = null;
            /*string*/ static ContentDisposition = null;
            /*string*/ static ContentEncoding = null;
            /*string*/ static ContentLanguage = null;
            /*string*/ static ContentLength = null;
            /*string*/ static ContentLocation = null;
            /*string*/ static ContentMD5 = null;
            /*string*/ static ContentRange = null;
            /*string*/ static ContentSecurityPolicy = null;
            /*string*/ static ContentType = null;
            /*string*/ static Cookie = null;
            /*string*/ static Cookie2 = null;
            /*string*/ static Date = null;
            /*string*/ static ETag = null;
            /*string*/ static Expect = null;
            /*string*/ static Expires = null;
            /*string*/ static From = null;
            /*string*/ static Host = null;
            /*string*/ static IfMatch = null;
            /*string*/ static IfModifiedSince = null;
            /*string*/ static IfNoneMatch = null;
            /*string*/ static IfRange = null;
            /*string*/ static IfUnmodifiedSince = null;
            /*string*/ static KeepAlive = null;
            /*string*/ static LastModified = null;
            /*string*/ static Link = null;
            /*string*/ static Location = null;
            /*string*/ static MaxForwards = null;
            /*string*/ static Origin = null;
            /*string*/ static P3P = null;
            /*string*/ static Pragma = null;
            /*string*/ static ProxyAuthenticate = null;
            /*string*/ static ProxyAuthorization = null;
            /*string*/ static ProxyConnection = null;
            /*string*/ static PublicKeyPins = null;
            /*string*/ static Range = null;
            /*string*/ static Referer = null;
            /*string*/ static RetryAfter = null;
            /*string*/ static SecWebSocketAccept = null;
            /*string*/ static SecWebSocketExtensions = null;
            /*string*/ static SecWebSocketKey = null;
            /*string*/ static SecWebSocketProtocol = null;
            /*string*/ static SecWebSocketVersion = null;
            /*string*/ static Server = null;
            /*string*/ static SetCookie = null;
            /*string*/ static SetCookie2 = null;
            /*string*/ static StrictTransportSecurity = null;
            /*string*/ static TE = null;
            /*string*/ static TSV = null;
            /*string*/ static Trailer = null;
            /*string*/ static TransferEncoding = null;
            /*string*/ static Upgrade = null;
            /*string*/ static UpgradeInsecureRequests = null;
            /*string*/ static UserAgent = null;
            /*string*/ static Vary = null;
            /*string*/ static Via = null;
            /*string*/ static WWWAuthenticate = null;
            /*string*/ static Warning = null;
            /*string*/ static XAspNetVersion = null;
            /*string*/ static XContentDuration = null;
            /*string*/ static XContentTypeOptions = null;
            /*string*/ static XFrameOptions = null;
            /*string*/ static XMSEdgeRef = null;
            /*string*/ static XPoweredBy = null;
            /*string*/ static XRequestID = null;
            /*string*/ static XUACompatible = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.Accept = "Accept";
                }
                {
                    this.AcceptCharset = "Accept-Charset";
                }
                {
                    this.AcceptEncoding = "Accept-Encoding";
                }
                {
                    this.AcceptLanguage = "Accept-Language";
                }
                {
                    this.AcceptPatch = "Accept-Patch";
                }
                {
                    this.AcceptRanges = "Accept-Ranges";
                }
                {
                    this.AccessControlAllowCredentials = "Access-Control-Allow-Credentials";
                }
                {
                    this.AccessControlAllowHeaders = "Access-Control-Allow-Headers";
                }
                {
                    this.AccessControlAllowMethods = "Access-Control-Allow-Methods";
                }
                {
                    this.AccessControlAllowOrigin = "Access-Control-Allow-Origin";
                }
                {
                    this.AccessControlExposeHeaders = "Access-Control-Expose-Headers";
                }
                {
                    this.AccessControlMaxAge = "Access-Control-Max-Age";
                }
                {
                    this.Age = "Age";
                }
                {
                    this.Allow = "Allow";
                }
                {
                    this.AltSvc = "Alt-Svc";
                }
                {
                    this.Authorization = "Authorization";
                }
                {
                    this.CacheControl = "Cache-Control";
                }
                {
                    this.Connection = "Connection";
                }
                {
                    this.ContentDisposition = "Content-Disposition";
                }
                {
                    this.ContentEncoding = "Content-Encoding";
                }
                {
                    this.ContentLanguage = "Content-Language";
                }
                {
                    this.ContentLength = "Content-Length";
                }
                {
                    this.ContentLocation = "Content-Location";
                }
                {
                    this.ContentMD5 = "Content-MD5";
                }
                {
                    this.ContentRange = "Content-Range";
                }
                {
                    this.ContentSecurityPolicy = "Content-Security-Policy";
                }
                {
                    this.ContentType = "Content-Type";
                }
                {
                    this.Cookie = "Cookie";
                }
                {
                    this.Cookie2 = "Cookie2";
                }
                {
                    this.Date = "Date";
                }
                {
                    this.ETag = "ETag";
                }
                {
                    this.Expect = "Expect";
                }
                {
                    this.Expires = "Expires";
                }
                {
                    this.From = "From";
                }
                {
                    this.Host = "Host";
                }
                {
                    this.IfMatch = "If-Match";
                }
                {
                    this.IfModifiedSince = "If-Modified-Since";
                }
                {
                    this.IfNoneMatch = "If-None-Match";
                }
                {
                    this.IfRange = "If-Range";
                }
                {
                    this.IfUnmodifiedSince = "If-Unmodified-Since";
                }
                {
                    this.KeepAlive = "Keep-Alive";
                }
                {
                    this.LastModified = "Last-Modified";
                }
                {
                    this.Link = "Link";
                }
                {
                    this.Location = "Location";
                }
                {
                    this.MaxForwards = "Max-Forwards";
                }
                {
                    this.Origin = "Origin";
                }
                {
                    this.P3P = "P3P";
                }
                {
                    this.Pragma = "Pragma";
                }
                {
                    this.ProxyAuthenticate = "Proxy-Authenticate";
                }
                {
                    this.ProxyAuthorization = "Proxy-Authorization";
                }
                {
                    this.ProxyConnection = "Proxy-Connection";
                }
                {
                    this.PublicKeyPins = "Public-Key-Pins";
                }
                {
                    this.Range = "Range";
                }
                {
                    this.Referer = "Referer";
                }
                {
                    this.RetryAfter = "Retry-After";
                }
                {
                    this.SecWebSocketAccept = "Sec-WebSocket-Accept";
                }
                {
                    this.SecWebSocketExtensions = "Sec-WebSocket-Extensions";
                }
                {
                    this.SecWebSocketKey = "Sec-WebSocket-Key";
                }
                {
                    this.SecWebSocketProtocol = "Sec-WebSocket-Protocol";
                }
                {
                    this.SecWebSocketVersion = "Sec-WebSocket-Version";
                }
                {
                    this.Server = "Server";
                }
                {
                    this.SetCookie = "Set-Cookie";
                }
                {
                    this.SetCookie2 = "Set-Cookie2";
                }
                {
                    this.StrictTransportSecurity = "Strict-Transport-Security";
                }
                {
                    this.TE = "TE";
                }
                {
                    this.TSV = "TSV";
                }
                {
                    this.Trailer = "Trailer";
                }
                {
                    this.TransferEncoding = "Transfer-Encoding";
                }
                {
                    this.Upgrade = "Upgrade";
                }
                {
                    this.UpgradeInsecureRequests = "Upgrade-Insecure-Requests";
                }
                {
                    this.UserAgent = "User-Agent";
                }
                {
                    this.Vary = "Vary";
                }
                {
                    this.Via = "Via";
                }
                {
                    this.WWWAuthenticate = "WWW-Authenticate";
                }
                {
                    this.Warning = "Warning";
                }
                {
                    this.XAspNetVersion = "X-AspNet-Version";
                }
                {
                    this.XContentDuration = "X-Content-Duration";
                }
                {
                    this.XContentTypeOptions = "X-Content-Type-Options";
                }
                {
                    this.XFrameOptions = "X-Frame-Options";
                }
                {
                    this.XMSEdgeRef = "X-MSEdge-Ref";
                }
                {
                    this.XPoweredBy = "X-Powered-By";
                }
                {
                    this.XRequestID = "X-Request-ID";
                }
                {
                    this.XUACompatible = "X-UA-Compatible";
                }
            }
            static $h = 2736885;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"Accept","d":2736885,"h":4297704181,"f":4194337},{"t":1310721,"n":"AcceptCharset","d":2736885,"h":8592671477,"f":4194337},{"t":1310721,"n":"AcceptEncoding","d":2736885,"h":12887638773,"f":4194337},{"t":1310721,"n":"AcceptLanguage","d":2736885,"h":17182606069,"f":4194337},{"t":1310721,"n":"AcceptPatch","d":2736885,"h":21477573365,"f":4194337},{"t":1310721,"n":"AcceptRanges","d":2736885,"h":25772540661,"f":4194337},{"t":1310721,"n":"AccessControlAllowCredentials","d":2736885,"h":30067507957,"f":4194337},{"t":1310721,"n":"AccessControlAllowHeaders","d":2736885,"h":34362475253,"f":4194337},{"t":1310721,"n":"AccessControlAllowMethods","d":2736885,"h":38657442549,"f":4194337},{"t":1310721,"n":"AccessControlAllowOrigin","d":2736885,"h":42952409845,"f":4194337},{"t":1310721,"n":"AccessControlExposeHeaders","d":2736885,"h":47247377141,"f":4194337},{"t":1310721,"n":"AccessControlMaxAge","d":2736885,"h":51542344437,"f":4194337},{"t":1310721,"n":"Age","d":2736885,"h":55837311733,"f":4194337},{"t":1310721,"n":"Allow","d":2736885,"h":60132279029,"f":4194337},{"t":1310721,"n":"AltSvc","d":2736885,"h":64427246325,"f":4194337},{"t":1310721,"n":"Authorization","d":2736885,"h":68722213621,"f":4194337},{"t":1310721,"n":"CacheControl","d":2736885,"h":73017180917,"f":4194337},{"t":1310721,"n":"Connection","d":2736885,"h":77312148213,"f":4194337},{"t":1310721,"n":"ContentDisposition","d":2736885,"h":81607115509,"f":4194337},{"t":1310721,"n":"ContentEncoding","d":2736885,"h":85902082805,"f":4194337},{"t":1310721,"n":"ContentLanguage","d":2736885,"h":90197050101,"f":4194337},{"t":1310721,"n":"ContentLength","d":2736885,"h":94492017397,"f":4194337},{"t":1310721,"n":"ContentLocation","d":2736885,"h":98786984693,"f":4194337},{"t":1310721,"n":"ContentMD5","d":2736885,"h":103081951989,"f":4194337},{"t":1310721,"n":"ContentRange","d":2736885,"h":107376919285,"f":4194337},{"t":1310721,"n":"ContentSecurityPolicy","d":2736885,"h":111671886581,"f":4194337},{"t":1310721,"n":"ContentType","d":2736885,"h":115966853877,"f":4194337},{"t":1310721,"n":"Cookie","d":2736885,"h":120261821173,"f":4194337},{"t":1310721,"n":"Cookie2","d":2736885,"h":124556788469,"f":4194337},{"t":1310721,"n":"Date","d":2736885,"h":128851755765,"f":4194337},{"t":1310721,"n":"ETag","d":2736885,"h":133146723061,"f":4194337},{"t":1310721,"n":"Expect","d":2736885,"h":137441690357,"f":4194337},{"t":1310721,"n":"Expires","d":2736885,"h":141736657653,"f":4194337},{"t":1310721,"n":"From","d":2736885,"h":146031624949,"f":4194337},{"t":1310721,"n":"Host","d":2736885,"h":150326592245,"f":4194337},{"t":1310721,"n":"IfMatch","d":2736885,"h":154621559541,"f":4194337},{"t":1310721,"n":"IfModifiedSince","d":2736885,"h":158916526837,"f":4194337},{"t":1310721,"n":"IfNoneMatch","d":2736885,"h":163211494133,"f":4194337},{"t":1310721,"n":"IfRange","d":2736885,"h":167506461429,"f":4194337},{"t":1310721,"n":"IfUnmodifiedSince","d":2736885,"h":171801428725,"f":4194337},{"t":1310721,"n":"KeepAlive","d":2736885,"h":176096396021,"f":4194337},{"t":1310721,"n":"LastModified","d":2736885,"h":180391363317,"f":4194337},{"t":1310721,"n":"Link","d":2736885,"h":184686330613,"f":4194337},{"t":1310721,"n":"Location","d":2736885,"h":188981297909,"f":4194337},{"t":1310721,"n":"MaxForwards","d":2736885,"h":193276265205,"f":4194337},{"t":1310721,"n":"Origin","d":2736885,"h":197571232501,"f":4194337},{"t":1310721,"n":"P3P","d":2736885,"h":201866199797,"f":4194337},{"t":1310721,"n":"Pragma","d":2736885,"h":206161167093,"f":4194337},{"t":1310721,"n":"ProxyAuthenticate","d":2736885,"h":210456134389,"f":4194337},{"t":1310721,"n":"ProxyAuthorization","d":2736885,"h":214751101685,"f":4194337},{"t":1310721,"n":"ProxyConnection","d":2736885,"h":219046068981,"f":4194337},{"t":1310721,"n":"PublicKeyPins","d":2736885,"h":223341036277,"f":4194337},{"t":1310721,"n":"Range","d":2736885,"h":227636003573,"f":4194337},{"t":1310721,"n":"Referer","d":2736885,"h":231930970869,"f":4194337},{"t":1310721,"n":"RetryAfter","d":2736885,"h":236225938165,"f":4194337},{"t":1310721,"n":"SecWebSocketAccept","d":2736885,"h":240520905461,"f":4194337},{"t":1310721,"n":"SecWebSocketExtensions","d":2736885,"h":244815872757,"f":4194337},{"t":1310721,"n":"SecWebSocketKey","d":2736885,"h":249110840053,"f":4194337},{"t":1310721,"n":"SecWebSocketProtocol","d":2736885,"h":253405807349,"f":4194337},{"t":1310721,"n":"SecWebSocketVersion","d":2736885,"h":257700774645,"f":4194337},{"t":1310721,"n":"Server","d":2736885,"h":261995741941,"f":4194337},{"t":1310721,"n":"SetCookie","d":2736885,"h":266290709237,"f":4194337},{"t":1310721,"n":"SetCookie2","d":2736885,"h":270585676533,"f":4194337},{"t":1310721,"n":"StrictTransportSecurity","d":2736885,"h":274880643829,"f":4194337},{"t":1310721,"n":"TE","d":2736885,"h":279175611125,"f":4194337},{"t":1310721,"n":"TSV","d":2736885,"h":283470578421,"f":4194337},{"t":1310721,"n":"Trailer","d":2736885,"h":287765545717,"f":4194337},{"t":1310721,"n":"TransferEncoding","d":2736885,"h":292060513013,"f":4194337},{"t":1310721,"n":"Upgrade","d":2736885,"h":296355480309,"f":4194337},{"t":1310721,"n":"UpgradeInsecureRequests","d":2736885,"h":300650447605,"f":4194337},{"t":1310721,"n":"UserAgent","d":2736885,"h":304945414901,"f":4194337},{"t":1310721,"n":"Vary","d":2736885,"h":309240382197,"f":4194337},{"t":1310721,"n":"Via","d":2736885,"h":313535349493,"f":4194337},{"t":1310721,"n":"WWWAuthenticate","d":2736885,"h":317830316789,"f":4194337},{"t":1310721,"n":"Warning","d":2736885,"h":322125284085,"f":4194337},{"t":1310721,"n":"XAspNetVersion","d":2736885,"h":326420251381,"f":4194337},{"t":1310721,"n":"XContentDuration","d":2736885,"h":330715218677,"f":4194337},{"t":1310721,"n":"XContentTypeOptions","d":2736885,"h":335010185973,"f":4194337},{"t":1310721,"n":"XFrameOptions","d":2736885,"h":339305153269,"f":4194337},{"t":1310721,"n":"XMSEdgeRef","d":2736885,"h":343600120565,"f":4194337},{"t":1310721,"n":"XPoweredBy","d":2736885,"h":347895087861,"f":4194337},{"t":1310721,"n":"XRequestID","d":2736885,"h":352190055157,"f":4194337},{"t":1310721,"n":"XUACompatible","d":2736885,"h":356485022453,"f":4194337}],"h":2736885}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.HttpKnownHeaderNames`; }
        });
        
        $asm.$cls("$snp.System.Net.NegotiationInfoClass", ($self) => class NegotiationInfoClass
        {
            /*string*/ static NTLM = null;
            /*string*/ static Kerberos = null;
            /*string*/ static Negotiate = null;
            /*string*/ static Basic = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.NTLM = "NTLM";
                }
                {
                    this.Kerberos = "Kerberos";
                }
                {
                    this.Negotiate = "Negotiate";
                }
                {
                    this.Basic = "Basic";
                }
            }
            static $h = 3654389;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"NTLM","d":3654389,"h":4298621685,"f":4194344},{"t":1310721,"n":"Kerberos","d":3654389,"h":8593588981,"f":4194344},{"t":1310721,"n":"Negotiate","d":3654389,"h":12888556277,"f":4194344},{"t":1310721,"n":"Basic","d":3654389,"h":17183523573,"f":4194344}],"h":3654389}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NegotiationInfoClass`; }
        });
        
        $asm.$cls("$snp.System.Text.StringBuilderCache", ($self) => class StringBuilderCache
        {
            /*int*/ static MaxBuilderSize = 360;
            /*int*/ static DefaultCapacity = 16;
            /*StringBuilder?*/ static t_cachedInstance = null;
            static /*StringBuilder */ Acquire(/*int*/ capacity)
            {
                if (capacity <= 360/*MaxBuilderSize*/)
                {
                    /*StringBuilder?*/ let sb = $.$snp.System.Text.StringBuilderCache.t_cachedInstance;
                    if (sb !== null)
                    {
                        if (capacity <= sb.Capacity)
                        {
                            $.$snp.System.Text.StringBuilderCache.t_cachedInstance = null;
                            sb.Clear();
                            return sb;
                        }
                    }
                }
                return new $.$$.System.Text.StringBuilder().$ctor$4(capacity);
            }
            static /*void */ Release(/*StringBuilder*/ sb)
            {
                if (sb.Capacity <= 360/*MaxBuilderSize*/)
                {
                    $.$snp.System.Text.StringBuilderCache.t_cachedInstance = sb;
                }
            }
            static /*string */ GetStringAndRelease(/*StringBuilder*/ sb)
            {
                /*string*/ let result = $.$$.System.Text.StringBuilder.ToString.call(sb);
                $.$snp.System.Text.StringBuilderCache.Release(sb);
                return result;
            }
            static $h = 5751541;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":122814465,"p":[{"n":"capacity","p":655361,"f":65,"v":16}],"n":"Acquire","d":5751541,"h":17185620725,"f":16777249},{"r":65537,"p":[{"n":"sb","p":122814465}],"n":"Release","d":5751541,"h":21480588021,"f":16777249},{"r":1310721,"p":[{"n":"sb","p":122814465}],"n":"GetStringAndRelease","d":5751541,"h":25775555317,"f":16777249}],"l":[{"t":655361,"n":"MaxBuilderSize","d":5751541,"h":4300718837,"f":4194344},{"t":655361,"n":"DefaultCapacity","d":5751541,"h":8595686133,"f":4194338},{"t":122814465,"n":"t_cachedInstance","d":5751541,"h":12890653429,"f":4194338,"a":[{"t":140050433,"c":4435017729}]}],"h":5751541}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Text.StringBuilderCache`; }
        });
        
        $asm.$cls("$snp.System.Net.Sockets.SocketErrorPal", ($self) => class SocketErrorPal
        {
            /*Static constructor*/ static $cctor()
            {
                $.$$.System.Diagnostics.Debug.Assert$4($.$snp.System.Net.Sockets.SocketErrorPal.s_nativeErrorToSocketError.Count === 42/*NativeErrorToSocketErrorCount*/, `Expected s_nativeErrorToSocketError to have ${42/*NativeErrorToSocketErrorCount*/} count instead of ${$.$snp.System.Net.Sockets.SocketErrorPal.s_nativeErrorToSocketError.Count}.`);
                $.$$.System.Diagnostics.Debug.Assert$4($.$snp.System.Net.Sockets.SocketErrorPal.s_socketErrorToNativeError.Count === 41/*SocketErrorToNativeErrorCount*/, `Expected s_socketErrorToNativeError to have ${41/*SocketErrorToNativeErrorCount*/} count instead of ${$.$snp.System.Net.Sockets.SocketErrorPal.s_socketErrorToNativeError.Count}.`);
            }
            /*int*/ static NativeErrorToSocketErrorCount = 42;
            /*int*/ static SocketErrorToNativeErrorCount = 41;
            /*Dictionary<Interop.Error, SocketError>*/ static s_nativeErrorToSocketError = null;
            /*Dictionary<SocketError, Interop.Error>*/ static s_socketErrorToNativeError = null;
            static /*SocketError */ GetSocketErrorForNativeError(/*Interop.Error*/ errno)
            {
                /*SocketError*/ let result;
                return $.$snp.System.Net.Sockets.SocketErrorPal.s_nativeErrorToSocketError.TryGetValue(errno, $.$ref(() => result, ($v) => result = $v, $.$snp.System.Net.Sockets.SocketError)) ? result : -1/*SocketError.SocketError*/;
            }
            static /*Interop.Error */ GetNativeErrorForSocketError(/*SocketError*/ error)
            {
                /*Interop.Error*/ let errno;
                if (!$.$snp.System.Net.Sockets.SocketErrorPal.TryGetNativeErrorForSocketError(error, $.$ref(() => errno, ($v) => errno = $v, $.$snp.Interop.Error)))
                {
                    errno = $.$cast(error, $.$snp.Interop.Error);
                }
                return errno;
            }
            static /*bool */ TryGetNativeErrorForSocketError(/*SocketError*/ error, /*out Interop.Error*/ errno)
            {
                return $.$snp.System.Net.Sockets.SocketErrorPal.s_socketErrorToNativeError.TryGetValue(error, errno);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_nativeErrorToSocketError = (() =>
                    {
                        //new $.$$.System.Collections.Generic.Dictionary$$$($.$snp.Interop.Error, $.$snp.System.Net.Sockets.SocketError)()
                        const $t1 = $.$$.System.Collections.Generic.Dictionary$$$($.$snp.Interop.Error, $.$snp.System.Net.Sockets.SocketError);
                        const $i1 = new $t1();
                        $i1.$ctor$8(42/*NativeErrorToSocketErrorCount*/);
                        $i1.Add(65538/*Interop.Error.EACCES*/, 10013/*SocketError.AccessDenied*/);
                        $i1.Add(65539/*Interop.Error.EADDRINUSE*/, 10048/*SocketError.AddressAlreadyInUse*/);
                        $i1.Add(65540/*Interop.Error.EADDRNOTAVAIL*/, 10049/*SocketError.AddressNotAvailable*/);
                        $i1.Add(65541/*Interop.Error.EAFNOSUPPORT*/, 10047/*SocketError.AddressFamilyNotSupported*/);
                        $i1.Add(65542/*Interop.Error.EAGAIN*/, 10035/*SocketError.WouldBlock*/);
                        $i1.Add(65543/*Interop.Error.EALREADY*/, 10037/*SocketError.AlreadyInProgress*/);
                        $i1.Add(65544/*Interop.Error.EBADF*/, 995/*SocketError.OperationAborted*/);
                        $i1.Add(65547/*Interop.Error.ECANCELED*/, 995/*SocketError.OperationAborted*/);
                        $i1.Add(65549/*Interop.Error.ECONNABORTED*/, 10053/*SocketError.ConnectionAborted*/);
                        $i1.Add(65550/*Interop.Error.ECONNREFUSED*/, 10061/*SocketError.ConnectionRefused*/);
                        $i1.Add(65551/*Interop.Error.ECONNRESET*/, 10054/*SocketError.ConnectionReset*/);
                        $i1.Add(65553/*Interop.Error.EDESTADDRREQ*/, 10039/*SocketError.DestinationAddressRequired*/);
                        $i1.Add(65557/*Interop.Error.EFAULT*/, 10014/*SocketError.Fault*/);
                        $i1.Add(65648/*Interop.Error.EHOSTDOWN*/, 10064/*SocketError.HostDown*/);
                        $i1.Add(65599/*Interop.Error.ENXIO*/, 11001/*SocketError.HostNotFound*/);
                        $i1.Add(65559/*Interop.Error.EHOSTUNREACH*/, 10065/*SocketError.HostUnreachable*/);
                        $i1.Add(65562/*Interop.Error.EINPROGRESS*/, 10036/*SocketError.InProgress*/);
                        $i1.Add(65563/*Interop.Error.EINTR*/, 10004/*SocketError.Interrupted*/);
                        $i1.Add(65564/*Interop.Error.EINVAL*/, 10022/*SocketError.InvalidArgument*/);
                        $i1.Add(65566/*Interop.Error.EISCONN*/, 10056/*SocketError.IsConnected*/);
                        $i1.Add(65569/*Interop.Error.EMFILE*/, 10024/*SocketError.TooManyOpenSockets*/);
                        $i1.Add(65571/*Interop.Error.EMSGSIZE*/, 10040/*SocketError.MessageSize*/);
                        $i1.Add(65574/*Interop.Error.ENETDOWN*/, 10050/*SocketError.NetworkDown*/);
                        $i1.Add(65575/*Interop.Error.ENETRESET*/, 10052/*SocketError.NetworkReset*/);
                        $i1.Add(65576/*Interop.Error.ENETUNREACH*/, 10051/*SocketError.NetworkUnreachable*/);
                        $i1.Add(65577/*Interop.Error.ENFILE*/, 10024/*SocketError.TooManyOpenSockets*/);
                        $i1.Add(65578/*Interop.Error.ENOBUFS*/, 10055/*SocketError.NoBufferSpaceAvailable*/);
                        $i1.Add(65649/*Interop.Error.ENODATA*/, 11004/*SocketError.NoData*/);
                        $i1.Add(65581/*Interop.Error.ENOENT*/, 10049/*SocketError.AddressNotAvailable*/);
                        $i1.Add(65587/*Interop.Error.ENOPROTOOPT*/, 10042/*SocketError.ProtocolOption*/);
                        $i1.Add(65592/*Interop.Error.ENOTCONN*/, 10057/*SocketError.NotConnected*/);
                        $i1.Add(65596/*Interop.Error.ENOTSOCK*/, 10038/*SocketError.NotSocket*/);
                        $i1.Add(65597/*Interop.Error.ENOTSUP*/, 10045/*SocketError.OperationNotSupported*/);
                        $i1.Add(65602/*Interop.Error.EPERM*/, 10013/*SocketError.AccessDenied*/);
                        $i1.Add(65603/*Interop.Error.EPIPE*/, 10058/*SocketError.Shutdown*/);
                        $i1.Add(65632/*Interop.Error.EPFNOSUPPORT*/, 10046/*SocketError.ProtocolFamilyNotSupported*/);
                        $i1.Add(65605/*Interop.Error.EPROTONOSUPPORT*/, 10043/*SocketError.ProtocolNotSupported*/);
                        $i1.Add(65606/*Interop.Error.EPROTOTYPE*/, 10041/*SocketError.ProtocolType*/);
                        $i1.Add(65630/*Interop.Error.ESOCKTNOSUPPORT*/, 10044/*SocketError.SocketNotSupported*/);
                        $i1.Add(65644/*Interop.Error.ESHUTDOWN*/, 10101/*SocketError.Disconnecting*/);
                        $i1.Add(0/*Interop.Error.SUCCESS*/, 0/*SocketError.Success*/);
                        $i1.Add(65613/*Interop.Error.ETIMEDOUT*/, 10060/*SocketError.TimedOut*/);
                        return $i1;
                    })();
                }
                {
                    this.s_socketErrorToNativeError = (() =>
                    {
                        //new $.$$.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.Sockets.SocketError, $.$snp.Interop.Error)()
                        const $t1 = $.$$.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.Sockets.SocketError, $.$snp.Interop.Error);
                        const $i1 = new $t1();
                        $i1.$ctor$8(41/*SocketErrorToNativeErrorCount*/);
                        $i1.Add(10013/*SocketError.AccessDenied*/, 65538/*Interop.Error.EACCES*/);
                        $i1.Add(10048/*SocketError.AddressAlreadyInUse*/, 65539/*Interop.Error.EADDRINUSE*/);
                        $i1.Add(10049/*SocketError.AddressNotAvailable*/, 65540/*Interop.Error.EADDRNOTAVAIL*/);
                        $i1.Add(10047/*SocketError.AddressFamilyNotSupported*/, 65541/*Interop.Error.EAFNOSUPPORT*/);
                        $i1.Add(10037/*SocketError.AlreadyInProgress*/, 65543/*Interop.Error.EALREADY*/);
                        $i1.Add(10053/*SocketError.ConnectionAborted*/, 65549/*Interop.Error.ECONNABORTED*/);
                        $i1.Add(10061/*SocketError.ConnectionRefused*/, 65550/*Interop.Error.ECONNREFUSED*/);
                        $i1.Add(10054/*SocketError.ConnectionReset*/, 65551/*Interop.Error.ECONNRESET*/);
                        $i1.Add(10039/*SocketError.DestinationAddressRequired*/, 65553/*Interop.Error.EDESTADDRREQ*/);
                        $i1.Add(10101/*SocketError.Disconnecting*/, 65644/*Interop.Error.ESHUTDOWN*/);
                        $i1.Add(10014/*SocketError.Fault*/, 65557/*Interop.Error.EFAULT*/);
                        $i1.Add(10064/*SocketError.HostDown*/, 65648/*Interop.Error.EHOSTDOWN*/);
                        $i1.Add(11001/*SocketError.HostNotFound*/, 131073/*Interop.Error.EHOSTNOTFOUND*/);
                        $i1.Add(10065/*SocketError.HostUnreachable*/, 65559/*Interop.Error.EHOSTUNREACH*/);
                        $i1.Add(10036/*SocketError.InProgress*/, 65562/*Interop.Error.EINPROGRESS*/);
                        $i1.Add(10004/*SocketError.Interrupted*/, 65563/*Interop.Error.EINTR*/);
                        $i1.Add(10022/*SocketError.InvalidArgument*/, 65564/*Interop.Error.EINVAL*/);
                        $i1.Add(997/*SocketError.IOPending*/, 65562/*Interop.Error.EINPROGRESS*/);
                        $i1.Add(10056/*SocketError.IsConnected*/, 65566/*Interop.Error.EISCONN*/);
                        $i1.Add(10040/*SocketError.MessageSize*/, 65571/*Interop.Error.EMSGSIZE*/);
                        $i1.Add(10050/*SocketError.NetworkDown*/, 65574/*Interop.Error.ENETDOWN*/);
                        $i1.Add(10052/*SocketError.NetworkReset*/, 65575/*Interop.Error.ENETRESET*/);
                        $i1.Add(10051/*SocketError.NetworkUnreachable*/, 65576/*Interop.Error.ENETUNREACH*/);
                        $i1.Add(10055/*SocketError.NoBufferSpaceAvailable*/, 65578/*Interop.Error.ENOBUFS*/);
                        $i1.Add(11004/*SocketError.NoData*/, 65649/*Interop.Error.ENODATA*/);
                        $i1.Add(10057/*SocketError.NotConnected*/, 65592/*Interop.Error.ENOTCONN*/);
                        $i1.Add(10038/*SocketError.NotSocket*/, 65596/*Interop.Error.ENOTSOCK*/);
                        $i1.Add(995/*SocketError.OperationAborted*/, 65547/*Interop.Error.ECANCELED*/);
                        $i1.Add(10045/*SocketError.OperationNotSupported*/, 65597/*Interop.Error.ENOTSUP*/);
                        $i1.Add(10046/*SocketError.ProtocolFamilyNotSupported*/, 65632/*Interop.Error.EPFNOSUPPORT*/);
                        $i1.Add(10043/*SocketError.ProtocolNotSupported*/, 65605/*Interop.Error.EPROTONOSUPPORT*/);
                        $i1.Add(10042/*SocketError.ProtocolOption*/, 65587/*Interop.Error.ENOPROTOOPT*/);
                        $i1.Add(10041/*SocketError.ProtocolType*/, 65606/*Interop.Error.EPROTOTYPE*/);
                        $i1.Add(10058/*SocketError.Shutdown*/, 65603/*Interop.Error.EPIPE*/);
                        $i1.Add(10044/*SocketError.SocketNotSupported*/, 65630/*Interop.Error.ESOCKTNOSUPPORT*/);
                        $i1.Add(0/*SocketError.Success*/, 0/*Interop.Error.SUCCESS*/);
                        $i1.Add(10060/*SocketError.TimedOut*/, 65613/*Interop.Error.ETIMEDOUT*/);
                        $i1.Add(10024/*SocketError.TooManyOpenSockets*/, 65577/*Interop.Error.ENFILE*/);
                        $i1.Add(11002/*SocketError.TryAgain*/, 65542/*Interop.Error.EAGAIN*/);
                        $i1.Add(10035/*SocketError.WouldBlock*/, 65542/*Interop.Error.EAGAIN*/);
                        $i1.Add(-1/*SocketError.SocketError*/, 131074/*Interop.Error.ESOCKETERROR*/);
                        return $i1;
                    })();
                }
            }
            static $h = 4768501;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":4702965,"p":[{"n":"errno","p":246517}],"n":"GetSocketErrorForNativeError","d":4768501,"h":25774572277,"f":16777256},{"r":246517,"p":[{"n":"error","p":4702965}],"n":"GetNativeErrorForSocketError","d":4768501,"h":30069539573,"f":16777256},{"r":262145,"p":[{"n":"error","p":4702965},{"n":"errno","p":246517,"f":2}],"n":"TryGetNativeErrorForSocketError","d":4768501,"h":34364506869,"f":16777256}],"l":[{"t":655361,"n":"NativeErrorToSocketErrorCount","d":4768501,"h":8594703093,"f":4194338},{"t":655361,"n":"SocketErrorToNativeErrorCount","d":4768501,"h":12889670389,"f":4194338},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$snp.Interop.Error, $.$snp.System.Net.Sockets.SocketError).$h,"n":"s_nativeErrorToSocketError","d":4768501,"h":17184637685,"f":4194338},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.Sockets.SocketError, $.$snp.Interop.Error).$h,"n":"s_socketErrorToNativeError","d":4768501,"h":21479604981,"f":4194338}],"h":4768501}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SocketErrorPal`; }
        });
        
        $asm.$cls("$snp.System.Net.NetworkInformation.HostInformationPal", ($self) => class HostInformationPal
        {
            static /*string */ GetHostName()
            {
                return $.$$.System.Environment.MachineName;
            }
            static /*string */ GetDomainName()
            {
                return $.$$.System.Environment.UserDomainName;
            }
            static $h = 3916533;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"n":"GetHostName","d":3916533,"h":4298883829,"f":16777249},{"r":1310721,"n":"GetDomainName","d":3916533,"h":8593851125,"f":16777249}],"h":3916533}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.HostInformationPal`; }
        });
        
        $asm.$cls("$snp.InteropErrorExtensions", ($self) => class InteropErrorExtensions
        {
            static /*Interop.ErrorInfo */ Info(/*this Interop.Error*/ error)
            {
                return new $.$snp.Interop.ErrorInfo().$ctor$4(error);
            }
            static $h = 705269;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":312053,"p":[{"n":"error","p":246517}],"n":"Info","d":705269,"h":4295672565,"f":16777249}],"h":705269}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `InteropErrorExtensions`; }
        });
        
        $asm.$cls("$snp.System.Net.UriScheme", ($self) => class UriScheme
        {
            /*string*/ static File = null;
            /*string*/ static Ftp = null;
            /*string*/ static Gopher = null;
            /*string*/ static Http = null;
            /*string*/ static Https = null;
            /*string*/ static News = null;
            /*string*/ static NetPipe = null;
            /*string*/ static NetTcp = null;
            /*string*/ static Nntp = null;
            /*string*/ static Mailto = null;
            /*string*/ static Ws = null;
            /*string*/ static Wss = null;
            /*string*/ static SchemeDelimiter = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.File = "file";
                }
                {
                    this.Ftp = "ftp";
                }
                {
                    this.Gopher = "gopher";
                }
                {
                    this.Http = "http";
                }
                {
                    this.Https = "https";
                }
                {
                    this.News = "news";
                }
                {
                    this.NetPipe = "net.pipe";
                }
                {
                    this.NetTcp = "net.tcp";
                }
                {
                    this.Nntp = "nntp";
                }
                {
                    this.Mailto = "mailto";
                }
                {
                    this.Ws = "ws";
                }
                {
                    this.Wss = "wss";
                }
                {
                    this.SchemeDelimiter = "://";
                }
            }
            static $h = 5096181;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"File","d":5096181,"h":4300063477,"f":4194337},{"t":1310721,"n":"Ftp","d":5096181,"h":8595030773,"f":4194337},{"t":1310721,"n":"Gopher","d":5096181,"h":12889998069,"f":4194337},{"t":1310721,"n":"Http","d":5096181,"h":17184965365,"f":4194337},{"t":1310721,"n":"Https","d":5096181,"h":21479932661,"f":4194337},{"t":1310721,"n":"News","d":5096181,"h":25774899957,"f":4194337},{"t":1310721,"n":"NetPipe","d":5096181,"h":30069867253,"f":4194337},{"t":1310721,"n":"NetTcp","d":5096181,"h":34364834549,"f":4194337},{"t":1310721,"n":"Nntp","d":5096181,"h":38659801845,"f":4194337},{"t":1310721,"n":"Mailto","d":5096181,"h":42954769141,"f":4194337},{"t":1310721,"n":"Ws","d":5096181,"h":47249736437,"f":4194337},{"t":1310721,"n":"Wss","d":5096181,"h":51544703733,"f":4194337},{"t":1310721,"n":"SchemeDelimiter","d":5096181,"h":55839671029,"f":4194337}],"h":5096181}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.UriScheme`; }
        });
        
        $asm.$cls("$snp.System.Net.NetworkInformation.InterfaceInfoPal", ($self) => class InterfaceInfoPal
        {
            static /*uint */ InterfaceNameToIndex(TChar, /*ReadOnlySpan<TChar>*/ _)
            {
                return 0;
            }
            static $h = 3982069;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":720897,"p":[{"n":"_","p":(TChar) => $.$$.System.ReadOnlySpan$$(TChar).$h}],"g":["TChar"],"n":"InterfaceNameToIndex","d":3982069,"h":4298949365,"f":16908321}],"h":3982069}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.InterfaceInfoPal`; }
        });
        
        $asm.$cls("$snp.System.Net.Sockets.SocketAddressExtensions", ($self) => class SocketAddressExtensions
        {
            static /*IPAddress */ GetIPAddress(/*this SocketAddress*/ socketAddress)
            {
                return $.$snp.System.Net.Sockets.IPEndPointExtensions.GetIPAddress($.$$.System.Span$$($.$$.System.Byte).op_Implicit(socketAddress.Buffer.Span));
            }
            static /*int */ GetPort(/*this SocketAddress*/ socketAddress)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(socketAddress.Family === 2/*AddressFamily.InterNetwork*/ || socketAddress.Family === 23/*AddressFamily.InterNetworkV6*/, "socketAddress.Family == AddressFamily.InterNetwork || socketAddress.Family == AddressFamily.InterNetworkV6");
                return $.$cast($.$snp.System.Net.SocketAddressPal.GetPort($.$$.System.Span$$($.$$.System.Byte).op_Implicit(socketAddress.Buffer.Span)), $.$$.System.Int32);
            }
            static /*IPEndPoint */ GetIPEndPoint(/*this SocketAddress*/ socketAddress)
            {
                return new $.$snp.System.Net.IPEndPoint().$ctor$3($.$snp.System.Net.Sockets.SocketAddressExtensions.GetIPAddress(socketAddress), $.$snp.System.Net.Sockets.SocketAddressExtensions.GetPort(socketAddress));
            }
            static /*bool */ Equals$2(/*this SocketAddress*/ socketAddress, /*EndPoint?*/ endPoint)
            {
                let ipe;
                if (socketAddress.Family === (endPoint?.AddressFamily ?? null) && $.$is(endPoint, $.$snp.System.Net.IPEndPoint, { set $v(v){ ipe = v; } }))
                {
                    return $.$snp.System.Net.Sockets.IPEndPointExtensions.Equals$2(ipe, $.$$.System.Span$$($.$$.System.Byte).op_Implicit(socketAddress.Buffer.Span));
                }
                return false;
            }
            static $h = 4637429;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3064565,"p":[{"n":"socketAddress","p":4375285}],"n":"GetIPAddress","d":4637429,"h":4299604725,"f":16777249},{"r":655361,"p":[{"n":"socketAddress","p":4375285}],"n":"GetPort","d":4637429,"h":8594572021,"f":16777249},{"r":3326709,"p":[{"n":"socketAddress","p":4375285}],"n":"GetIPEndPoint","d":4637429,"h":12889539317,"f":16777249},{"r":262145,"p":[{"n":"socketAddress","p":4375285},{"n":"endPoint","p":2605813}],"n":"Equals","o":"@$2","d":4637429,"h":17184506613,"f":16777249}],"h":4637429}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SocketAddressExtensions`; }
        });
        
        $asm.$cls("$snp.System.Net.Cookie", ($self) => class Cookie extends $.$$.System.Object
        {
            /*int*/ static MaxSupportedVersion = 1;
            /*string*/ static MaxSupportedVersionString = null;
            /*string*/ static SeparatorLiteral = null;
            /*char*/ static EqualsLiteral = /*=*/ 61;
            /*string*/ static QuotesLiteral = null;
            /*string*/ static SpecialAttributeLiteral = null;
            /*char[]*/ static PortSplitDelimiters = null;
            /*SearchValues<char>*/ static s_reservedToNameChars = null;
            /*SearchValues<char>*/ static s_domainChars = null;
            /*string*/ m_comment = null;
            /*Uri?*/ m_commentUri = null;
            /*CookieVariant*/ m_cookieVariant = 1;
            /*bool*/ m_discard = false;
            /*string*/ m_domain = null;
            /*bool*/ m_domain_implicit = true;
            /*DateTime*/ m_expires;
            /*string*/ m_name = null;
            /*string*/ m_path = null;
            /*bool*/ m_path_implicit = true;
            /*string*/ m_port = null;
            /*bool*/ m_port_implicit = true;
            /*int[]?*/ m_port_list = null;
            /*bool*/ m_secure = false;
            /*bool*/ m_httpOnly = false;
            /*DateTime*/ m_timeStamp;
            /*string*/ m_value = null;
            /*int*/ m_version = 0;
            /*string?*/ m_domainKey = null;
            /*bool*/ IsQuotedVersion = false;
            /*bool*/ IsQuotedDomain = false;
            /*Static constructor*/ static $cctor()
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.Equals$4.call($.$$.System.Int32.ToString$1.call(1/*MaxSupportedVersion*/, $.$$.System.Globalization.NumberFormatInfo.InvariantInfo), "1"/*MaxSupportedVersionString*/, 4/*StringComparison.Ordinal*/), "MaxSupportedVersion.ToString(NumberFormatInfo.InvariantInfo).Equals(MaxSupportedVersionString, StringComparison.Ordinal)");
            }
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ name, /*string?*/ value)
            {
                super.$ctor();
                {
                    this.Name = name;
                    this.Value = value;
                }
                return this;
            }
            $ctor$3(/*string*/ name, /*string?*/ value, /*string?*/ path)
            {
                this.$ctor$4(name, value);
                {
                    this.Path = path;
                }
                return this;
            }
            $ctor$2(/*string*/ name, /*string?*/ value, /*string?*/ path, /*string?*/ domain)
            {
                this.$ctor$3(name, value, path);
                {
                    this.Domain = domain;
                }
                return this;
            }
            /*string */ get Comment()
            {
                return this.m_comment;
            }
            /*string */ set Comment(value)
            {
                this.m_comment = value ?? $.$$.System.String.Empty;
            }
            /*Uri? */ get CommentUri()
            {
                return this.m_commentUri;
            }
            /*Uri? */ set CommentUri(value)
            {
                this.m_commentUri = value;
            }
            /*bool */ get HttpOnly()
            {
                return this.m_httpOnly;
            }
            /*bool */ set HttpOnly(value)
            {
                this.m_httpOnly = value;
            }
            /*bool */ get Discard()
            {
                return this.m_discard;
            }
            /*bool */ set Discard(value)
            {
                this.m_discard = value;
            }
            /*string */ get Domain()
            {
                return this.m_domain;
            }
            /*string */ set Domain(value)
            {
                this.SetDomainAndKey(value ?? $.$$.System.String.Empty);
                this.m_domain_implicit = false;
            }
            /*bool */ get DomainImplicit()
            {
                return this.m_domain_implicit;
            }
            /*bool */ set DomainImplicit(value)
            {
                this.m_domain_implicit = value;
            }
            /*bool */ get Expired()
            {
                return ($.$$.System.DateTime.op_Inequality(this.m_expires, $.$$.System.DateTime.MinValue)) && ($.$$.System.DateTime.op_LessThanOrEqual(this.m_expires.ToUniversalTime(), $.$$.System.DateTime.UtcNow));
            }
            /*bool */ set Expired(value)
            {
                if (value)
                {
                    this.m_expires = $.$$.System.DateTime.UtcNow;
                }
            }
            /*DateTime */ get Expires()
            {
                return this.m_expires;
            }
            /*DateTime */ set Expires(value)
            {
                this.m_expires = value;
            }
            /*string */ get Name()
            {
                return this.m_name;
            }
            /*string */ set Name(value)
            {
                if ($.$$.System.String.IsNullOrEmpty(value) || !this.InternalSetName(value))
                {
                    throw new $.$snp.System.Net.CookieException().$ctor$16($.$snp.System.SR.Format$5($.$snp.System.SR.net_cookie_attribute, "Name", value ?? "<null>"));
                }
            }
            /*bool */ InternalSetName(/*string?*/ value)
            {
                if ($.$$.System.String.IsNullOrEmpty(value) || $.$$.System.String.StartsWith.call(value, /*$*/ 36) || $.$$.System.String.StartsWith.call(value, /* */ 32) || $.$$.System.String.EndsWith.call(value, /* */ 32) || $.$$.System.MemoryExtensions.ContainsAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(value), $.$snp.System.Net.Cookie.s_reservedToNameChars))
                {
                    this.m_name = $.$$.System.String.Empty;
                    return false;
                }
                this.m_name = value;
                return true;
            }
            /*string */ get Path()
            {
                return this.m_path;
            }
            /*string */ set Path(value)
            {
                this.m_path = value ?? $.$$.System.String.Empty;
                this.m_path_implicit = false;
            }
            /*bool */ get Plain()
            {
                return this.Variant === 1/*CookieVariant.Plain*/;
            }
            /*Cookie */ Clone()
            {
                /*Cookie*/ let clonedCookie = new $.$snp.System.Net.Cookie().$ctor$4(this.m_name, this.m_value);
                if (!this.m_port_implicit)
                {
                    clonedCookie.Port = this.m_port;
                }
                if (!this.m_path_implicit)
                {
                    clonedCookie.Path = this.m_path;
                }
                clonedCookie.m_domain = this.m_domain;
                clonedCookie.DomainImplicit = this.m_domain_implicit;
                clonedCookie.m_domainKey = this.m_domainKey;
                clonedCookie.m_timeStamp = this.m_timeStamp;
                clonedCookie.Comment = this.m_comment;
                clonedCookie.CommentUri = this.m_commentUri;
                clonedCookie.HttpOnly = this.m_httpOnly;
                clonedCookie.Discard = this.m_discard;
                clonedCookie.Expires = this.m_expires;
                clonedCookie.Version = this.m_version;
                clonedCookie.Secure = this.m_secure;
                clonedCookie.m_cookieVariant = this.m_cookieVariant;
                return clonedCookie;
            }
            /*void */ SetDomainAndKey(/*string*/ domain)
            {
                this.m_domain = domain;
                this.m_domainKey = $.$$.System.String.ToLowerInvariant.call($.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call($.$snp.System.Net.CookieComparer.StripLeadingDot($.$$.System.String.op_Implicit(this.m_domain))));
            }
            static /*bool */ HostMatchesDomain(/*ReadOnlySpan<char>*/ host, /*ReadOnlySpan<char>*/ domain)
            {
                if (!$.$$.System.MemoryExtensions.EndsWith(host, domain, 4/*StringComparison.Ordinal*/))
                {
                    return false;
                }
                /*int*/ let idxOfSeparator = ((((host.Length - domain.Length) | 0) - 1) | 0);
                if (idxOfSeparator < 0)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(idxOfSeparator === -1, "idxOfSeparator == -1");
                    return true;
                }
                return host.get_Item(idxOfSeparator).$v === /*.*/ 46 && $.$$.System.MemoryExtensions.Contains$2($.$$.System.Char, domain, /*.*/ 46) && !$.$snp.System.Net.IPAddress.IsValid(host);
            }
            /*void */ VerifyAndSetDefaults(/*CookieVariant*/ variant, /*Uri*/ uri)
            {
                /*string*/ let host = uri.Host;
                /*int*/ let port = uri.Port;
                /*string*/ let path = uri.AbsolutePath;
                if (this.Version === 0)
                {
                    variant = 1/*CookieVariant.Plain*/;
                }
                else if (this.Version === 1 && variant === 0/*CookieVariant.Unknown*/)
                {
                    variant = 2/*CookieVariant.Default*/;
                }
                this.m_cookieVariant = variant;
                if ($.$$.System.String.IsNullOrEmpty(this.m_name) || $.$$.System.String.StartsWith.call(this.m_name, /*$*/ 36) || $.$$.System.String.StartsWith.call(this.m_name, /* */ 32) || $.$$.System.String.EndsWith.call(this.m_name, /* */ 32) || $.$$.System.MemoryExtensions.ContainsAny$2($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(this.m_name), $.$snp.System.Net.Cookie.s_reservedToNameChars))
                {
                    throw new $.$snp.System.Net.CookieException().$ctor$16($.$snp.System.SR.Format$5($.$snp.System.SR.net_cookie_attribute, "Name", this.m_name ?? "<null>"));
                }
                if ($.$$.System.String.op_Equality(this.m_value, null) || $.$$.System.MemoryExtensions.ContainsAny$7($.$$.System.Char, $.$$.System.String.op_Implicit(this.m_value), /*\r*/ 13, /*\n*/ 10, /*\u0000*/ 0) || (!(this.m_value.length > 2 && $.$$.System.String.StartsWith.call(this.m_value, /*\"*/ 34) && $.$$.System.String.EndsWith.call(this.m_value, /*\"*/ 34)) && $.$$.System.MemoryExtensions.ContainsAny$8($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(this.m_value), /*;*/ 59, /*,*/ 44)))
                {
                    throw new $.$snp.System.Net.CookieException().$ctor$16($.$snp.System.SR.Format$5($.$snp.System.SR.net_cookie_attribute, "Value", this.m_value ?? "<null>"));
                }
                if ($.$$.System.String.op_Inequality(this.Comment, null) && !(this.Comment.length > 2 && $.$$.System.String.StartsWith.call(this.Comment, /*\"*/ 34) && $.$$.System.String.EndsWith.call(this.Comment, /*\"*/ 34)) && ($.$$.System.MemoryExtensions.ContainsAny$8($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(this.Comment), /*;*/ 59, /*,*/ 44)))
                {
                    throw new $.$snp.System.Net.CookieException().$ctor$16($.$snp.System.SR.Format$5($.$snp.System.SR.net_cookie_attribute, "Comment"/*CookieFields.CommentAttributeName*/, this.Comment));
                }
                if ($.$$.System.String.op_Inequality(this.Path, null) && !(this.Path.length > 2 && $.$$.System.String.StartsWith.call(this.Path, /*\"*/ 34) && $.$$.System.String.EndsWith.call(this.Path, /*\"*/ 34)) && ($.$$.System.MemoryExtensions.ContainsAny$8($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(this.Path), /*;*/ 59, /*,*/ 44)))
                {
                    throw new $.$snp.System.Net.CookieException().$ctor$16($.$snp.System.SR.Format$5($.$snp.System.SR.net_cookie_attribute, "Path"/*CookieFields.PathAttributeName*/, this.Path));
                }
                if (this.m_domain_implicit)
                {
                    this.SetDomainAndKey(host);
                }
                else 
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!(this.m_domainKey === null), "m_domainKey is not null");
                    if (!$.$snp.System.Net.Cookie.IsValidDomainName($.$$.System.String.op_Implicit(this.m_domainKey)) || !$.$snp.System.Net.Cookie.HostMatchesDomain($.$$.System.String.op_Implicit(host), $.$$.System.String.op_Implicit(this.m_domainKey)))
                    {
                        throw new $.$snp.System.Net.CookieException().$ctor$16($.$snp.System.SR.Format$5($.$snp.System.SR.net_cookie_attribute, "Domain"/*CookieFields.DomainAttributeName*/, this.m_domain));
                    }
                }
                if (this.m_path_implicit)
                {
                    switch(this.m_cookieVariant)
                    {
                        case 1/*CookieVariant.Plain*/:
                        /*int*/ let lastSlash;
                        if (!$.$$.System.String.StartsWith.call(path, /*/*/ 47) || (lastSlash = $.$$.System.String.LastIndexOf$2.call(path, /*/*/ 47)) === 0)
                        {
                            this.m_path = "/";
                            break;
                        }
                        this.m_path = $.$$.System.String.Substring.call(path, 0, lastSlash);
                        break;
                        case 2/*CookieVariant.Rfc2109*/:
                        this.m_path = $.$$.System.String.Substring.call(path, 0, $.$$.System.String.LastIndexOf$2.call(path, /*/*/ 47));
                        break;
                        case 3/*CookieVariant.Rfc2965*/:
                        default:
                        this.m_path = $.$$.System.String.Substring.call(path, 0, (($.$$.System.String.LastIndexOf$2.call(path, /*/*/ 47) + 1) | 0));
                        break;
                    }
                }
                if (this.m_port_implicit === false && this.m_port.length === 0)
                {
                    this.m_port_list = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), [port], [1], null);
                }
                if (this.m_port_implicit === false)
                {
                    /*bool*/ let valid = false;
                    let $i1 = 0;
                    let $arr1 = this.m_port_list;
                    while ($i1 < $arr1.length)
                    {
                        let p = $arr1[$i1++];
                        if (p === port)
                        {
                            valid = true;
                            break;
                        }
                    }
                    if (!valid)
                    {
                        throw new $.$snp.System.Net.CookieException().$ctor$16($.$snp.System.SR.Format$5($.$snp.System.SR.net_cookie_attribute, "Port"/*CookieFields.PortAttributeName*/, this.m_port));
                    }
                }
            }
            static /*bool */ IsValidDomainName(/*ReadOnlySpan<char>*/ name)
            {
                return !name.IsEmpty && !$.$$.System.MemoryExtensions.ContainsAnyExcept($.$$.System.Char, name, $.$snp.System.Net.Cookie.s_domainChars);
            }
            /*string */ get Port()
            {
                return this.m_port;
            }
            /*string */ set Port(value)
            {
                if ($.$$.System.String.IsNullOrEmpty(value))
                {
                    this.m_port_implicit = true;
                    this.m_port = $.$$.System.String.Empty;
                }
                else 
                {
                    this.m_port_implicit = false;
                    if (!$.$$.System.String.StartsWith.call(value, /*\"*/ 34) || !$.$$.System.String.EndsWith.call(value, /*\"*/ 34))
                    {
                        throw new $.$snp.System.Net.CookieException().$ctor$16($.$snp.System.SR.Format$5($.$snp.System.SR.net_cookie_attribute, "Port"/*CookieFields.PortAttributeName*/, value));
                    }
                    /*string[]*/ let ports = $.$$.System.String.Split$4.call(value, $.$snp.System.Net.Cookie.PortSplitDelimiters, 1/*StringSplitOptions.RemoveEmptyEntries*/);
                    /*int[]*/ let parsedPorts = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Int32), null, [ports.length], null);
                    for(/*int*/ let i = 0; i < ports.length; ++i)
                    {
                        /*int*/ let port;
                        if (!$.$$.System.Int32.TryParse$8($.$$.System.Array.$ReadT1.call(ports, i), $.$ref(() => port, ($v) => port = $v, $.$$.System.Int32)))
                        {
                            throw new $.$snp.System.Net.CookieException().$ctor$16($.$snp.System.SR.Format$5($.$snp.System.SR.net_cookie_attribute, "Port"/*CookieFields.PortAttributeName*/, value));
                        }
                        if ((port < 0) || (port > 65535))
                        {
                            throw new $.$snp.System.Net.CookieException().$ctor$16($.$snp.System.SR.Format$5($.$snp.System.SR.net_cookie_attribute, "Port"/*CookieFields.PortAttributeName*/, value));
                        }
                        $.$$.System.Array.$WriteT1.call(parsedPorts, port, i);
                    }
                    this.m_port_list = parsedPorts;
                    this.m_port = value;
                    this.m_version = 1/*MaxSupportedVersion*/;
                    this.m_cookieVariant = 3/*CookieVariant.Rfc2965*/;
                }
            }
            /*int[]? */ get PortList()
            {
                return this.m_port_list;
            }
            /*bool */ get Secure()
            {
                return this.m_secure;
            }
            /*bool */ set Secure(value)
            {
                this.m_secure = value;
            }
            /*DateTime */ get TimeStamp()
            {
                return this.m_timeStamp;
            }
            /*string */ get Value()
            {
                return this.m_value;
            }
            /*string */ set Value(value)
            {
                this.m_value = value ?? $.$$.System.String.Empty;
            }
            /*CookieVariant */ get Variant()
            {
                return this.m_cookieVariant;
            }
            /*string */ get DomainKey()
            {
                return this.m_domain_implicit ? this.Domain : this.m_domainKey;
            }
            /*int */ get Version()
            {
                return this.m_version;
            }
            /*int */ set Version(value)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, value, "value");
                this.m_version = value;
                if (value > 0 && this.m_cookieVariant < 2/*CookieVariant.Rfc2109*/)
                {
                    this.m_cookieVariant = 2/*CookieVariant.Rfc2109*/;
                }
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ comparand)
            {
                let other;
                return $.$is(comparand, $.$snp.System.Net.Cookie, { set $v(v){ other = v; } }) && $.$$.System.String.Equals$2(this.Name, other.Name, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$$.System.String.Equals$2(this.Value, other.Value, 4/*StringComparison.Ordinal*/) && $.$$.System.String.Equals$2(this.Path, other.Path, 4/*StringComparison.Ordinal*/) && $.$snp.System.Net.CookieComparer.EqualDomains($.$$.System.String.op_Implicit(this.Domain), $.$$.System.String.op_Implicit(other.Domain)) && (this.Version === other.Version);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$snp.System.Net.Cookie.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.HashCode.Combine$3($.$$.System.Int32, $.$$.System.Int32, $.$$.System.Int32, $.$$.System.Int32, $.$$.System.Int32, $.$$.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(this.Name), $.$$.System.StringComparer.Ordinal.GetHashCode$2(this.Value), $.$$.System.StringComparer.Ordinal.GetHashCode$2(this.Path), $.$$.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(this.DomainKey), this.Version);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snp.System.Net.Cookie.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                /*StringBuilder*/ let sb = $.$snp.System.Text.StringBuilderCache.Acquire(16);
                this.ToString$1(sb);
                return $.$snp.System.Text.StringBuilderCache.GetStringAndRelease(sb);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.Cookie.ToString.apply(this, arguments); }
            /*void */ ToString$1(/*StringBuilder*/ sb)
            {
                /*int*/ let beforeLength = sb.Length;
                if (this.Version !== 0)
                {
                    sb.Append$19("$"/*SpecialAttributeLiteral*/ + "Version"/*CookieFields.VersionAttributeName*/ + /*=*/ 61);
                    if (this.IsQuotedVersion)
                    {
                        sb.Append$3(/*\"*/ 34);
                    }
                    sb.Append$9($.$$.System.Globalization.NumberFormatInfo.InvariantInfo, `${this.m_version}`);
                    if (this.IsQuotedVersion)
                    {
                        sb.Append$3(/*\"*/ 34);
                    }
                    sb.Append$19("; "/*SeparatorLiteral*/);
                }
                sb.Append$19(this.Name).Append$3(/*=*/ 61).Append$19(this.Value);
                if (!this.Plain)
                {
                    if (!this.m_path_implicit && this.m_path.length > 0)
                    {
                        sb.Append$19("; "/*SeparatorLiteral*/ + "$"/*SpecialAttributeLiteral*/ + "Path"/*CookieFields.PathAttributeName*/ + /*=*/ 61);
                        sb.Append$19(this.m_path);
                    }
                    if (!this.m_domain_implicit && this.m_domain.length > 0)
                    {
                        sb.Append$19("; "/*SeparatorLiteral*/ + "$"/*SpecialAttributeLiteral*/ + "Domain"/*CookieFields.DomainAttributeName*/ + /*=*/ 61);
                        if (this.IsQuotedDomain)
                        {
                            sb.Append$3(/*\"*/ 34);
                        }
                        sb.Append$19(this.m_domain);
                        if (this.IsQuotedDomain)
                        {
                            sb.Append$3(/*\"*/ 34);
                        }
                    }
                }
                if (!this.m_port_implicit)
                {
                    sb.Append$19("; "/*SeparatorLiteral*/ + "$"/*SpecialAttributeLiteral*/ + "Port"/*CookieFields.PortAttributeName*/);
                    if (this.m_port.length > 0)
                    {
                        sb.Append$3(/*=*/ 61);
                        sb.Append$19(this.m_port);
                    }
                }
                /*int*/ let afterLength = sb.Length;
                if (afterLength === (((1 + beforeLength) | 0)) && sb.get_Chars(beforeLength) === /*=*/ 61)
                {
                    sb.Length = beforeLength;
                }
            }
            /*string? */ ToServerString()
            {
                /*string*/ let result = this.Name + /*=*/ 61 + this.Value;
                if ($.$$.System.String.op_Inequality(this.m_comment, null) && this.m_comment.length > 0)
                {
                    result += "; "/*SeparatorLiteral*/ + "Comment"/*CookieFields.CommentAttributeName*/ + /*=*/ 61 + this.m_comment;
                }
                if ($.$spu.System.Uri.op_Inequality(this.m_commentUri, null))
                {
                    result += "; "/*SeparatorLiteral*/ + "CommentURL"/*CookieFields.CommentUrlAttributeName*/ + /*=*/ 61 + "\""/*QuotesLiteral*/ + $.$spu.System.Uri.ToString.call(this.m_commentUri) + "\""/*QuotesLiteral*/;
                }
                if (this.m_discard)
                {
                    result += "; "/*SeparatorLiteral*/ + "Discard"/*CookieFields.DiscardAttributeName*/;
                }
                if (!this.m_domain_implicit && $.$$.System.String.op_Inequality(this.m_domain, null) && this.m_domain.length > 0)
                {
                    result += "; "/*SeparatorLiteral*/ + "Domain"/*CookieFields.DomainAttributeName*/ + /*=*/ 61 + this.m_domain;
                }
                if ($.$$.System.DateTime.op_Inequality(this.Expires, $.$$.System.DateTime.MinValue))
                {
                    /*int*/ let seconds = $.$cast(($.$$.System.DateTime.op_Subtraction(this.Expires.ToUniversalTime(), $.$$.System.DateTime.UtcNow)).TotalSeconds, $.$$.System.Int32);
                    if (seconds < 0)
                    {
                        seconds = 0;
                    }
                    result += "; "/*SeparatorLiteral*/ + "Max-Age"/*CookieFields.MaxAgeAttributeName*/ + /*=*/ 61 + $.$$.System.Int32.ToString$1.call(seconds, $.$$.System.Globalization.NumberFormatInfo.InvariantInfo);
                }
                if (!this.m_path_implicit && $.$$.System.String.op_Inequality(this.m_path, null) && this.m_path.length > 0)
                {
                    result += "; "/*SeparatorLiteral*/ + "Path"/*CookieFields.PathAttributeName*/ + /*=*/ 61 + this.m_path;
                }
                if (!this.Plain && !this.m_port_implicit && $.$$.System.String.op_Inequality(this.m_port, null) && this.m_port.length > 0)
                {
                    result += "; "/*SeparatorLiteral*/ + "Port"/*CookieFields.PortAttributeName*/ + /*=*/ 61 + this.m_port;
                }
                if (this.m_version > 0)
                {
                    result += "; "/*SeparatorLiteral*/ + "Version"/*CookieFields.VersionAttributeName*/ + /*=*/ 61 + $.$$.System.Int32.ToString$1.call(this.m_version, $.$$.System.Globalization.NumberFormatInfo.InvariantInfo);
                }
                return $.$$.System.String.op_Equality(result, "=") ? null : result;
            }
            //default member initializer
            constructor()
            {
                super();
                this.m_comment = $.$$.System.String.Empty;
                this.m_domain = $.$$.System.String.Empty;
                this.m_expires = $.$$.System.DateTime.MinValue;
                this.m_name = $.$$.System.String.Empty;
                this.m_path = $.$$.System.String.Empty;
                this.m_port = $.$$.System.String.Empty;
                this.m_timeStamp = $.$$.System.DateTime.UtcNow;
                this.m_value = $.$$.System.String.Empty;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.MaxSupportedVersionString = "1";
                }
                {
                    this.SeparatorLiteral = "; ";
                }
                {
                    this.QuotesLiteral = "\"";
                }
                {
                    this.SpecialAttributeLiteral = "$";
                }
                {
                    this.PortSplitDelimiters = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), [/* */ 32, /*,*/ 44, /*\"*/ 34], [-1], null);
                }
                {
                    this.s_reservedToNameChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("\t\u0000\r\n=;,"));
                }
                {
                    this.s_domainChars = $.$$.System.Buffers.SearchValues.Create$1($.$$.System.String.op_Implicit("-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz"));
                }
            }
            static $h = 1164021;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":158914953973,"f":50331649},"s":{"r":0,"d":0,"h":163209921269,"f":83886081},"n":"Comment","d":1164021,"h":154619986677,"f":2097153},{"p":1746220,"g":{"r":0,"d":0,"h":171799855861,"f":50331649},"s":{"r":0,"d":0,"h":176094823157,"f":83886081},"n":"CommentUri","d":1164021,"h":167504888565,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":184684757749,"f":50331649},"s":{"r":0,"d":0,"h":188979725045,"f":83886081},"n":"HttpOnly","d":1164021,"h":180389790453,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":197569659637,"f":50331649},"s":{"r":0,"d":0,"h":201864626933,"f":83886081},"n":"Discard","d":1164021,"h":193274692341,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":210454561525,"f":50331649},"s":{"r":0,"d":0,"h":214749528821,"f":83886081},"n":"Domain","d":1164021,"h":206159594229,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":223339463413,"f":50331656},"s":{"r":0,"d":0,"h":227634430709,"f":83886088},"n":"DomainImplicit","d":1164021,"h":219044496117,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":236224365301,"f":50331649},"s":{"r":0,"d":0,"h":240519332597,"f":83886081},"n":"Expired","d":1164021,"h":231929398005,"f":2097153},{"p":34275329,"g":{"r":0,"d":0,"h":249109267189,"f":50331649},"s":{"r":0,"d":0,"h":253404234485,"f":83886081},"n":"Expires","d":1164021,"h":244814299893,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":261994169077,"f":50331649},"s":{"r":0,"d":0,"h":266289136373,"f":83886081},"n":"Name","d":1164021,"h":257699201781,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":279174038261,"f":50331649},"s":{"r":0,"d":0,"h":283469005557,"f":83886081},"n":"Path","d":1164021,"h":274879070965,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":292058940149,"f":50331656},"n":"Plain","d":1164021,"h":287763972853,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":322123711221,"f":50331649},"s":{"r":0,"d":0,"h":326418678517,"f":83886081},"n":"Port","d":1164021,"h":317828743925,"f":2097153},{"p":$.$typeArray($.$$.System.Int32).$h,"g":{"r":0,"d":0,"h":335008613109,"f":50331656},"n":"PortList","d":1164021,"h":330713645813,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":343598547701,"f":50331649},"s":{"r":0,"d":0,"h":347893514997,"f":83886081},"n":"Secure","d":1164021,"h":339303580405,"f":2097153},{"p":34275329,"g":{"r":0,"d":0,"h":356483449589,"f":50331649},"n":"TimeStamp","d":1164021,"h":352188482293,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":365073384181,"f":50331649},"s":{"r":0,"d":0,"h":369368351477,"f":83886081},"n":"Value","d":1164021,"h":360778416885,"f":2097153},{"p":1884917,"g":{"r":0,"d":0,"h":377958286069,"f":50331656},"n":"Variant","d":1164021,"h":373663318773,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":386548220661,"f":50331656},"n":"DomainKey","d":1164021,"h":382253253365,"f":2097160},{"p":655361,"g":{"r":0,"d":0,"h":395138155253,"f":50331649},"s":{"r":0,"d":0,"h":399433122549,"f":83886081},"n":"Version","d":1164021,"h":390843187957,"f":2097153}],"m":[{"r":262145,"p":[{"n":"value","p":1310721}],"n":"InternalSetName","d":1164021,"h":270584103669,"f":16777224},{"r":1164021,"n":"Clone","d":1164021,"h":296353907445,"f":16777224},{"r":65537,"p":[{"n":"domain","p":1310721}],"n":"SetDomainAndKey","d":1164021,"h":300648874741,"f":16777218},{"r":262145,"p":[{"n":"host","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"domain","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"HostMatchesDomain","d":1164021,"h":304943842037,"f":16777250},{"r":65537,"p":[{"n":"variant","p":1884917},{"n":"uri","p":1746220}],"n":"VerifyAndSetDefaults","d":1164021,"h":309238809333,"f":16777224},{"r":262145,"p":[{"n":"name","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"IsValidDomainName","d":1164021,"h":313533776629,"f":16777250},{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","o":"@$1","d":1164021,"h":403728089845,"f":16809985},{"r":655361,"n":"GetHashCode","d":1164021,"h":408023057141,"f":16809985},{"r":1310721,"n":"ToString","d":1164021,"h":412318024437,"f":16809985},{"r":65537,"p":[{"n":"sb","p":122814465}],"n":"ToString","o":"@$1","d":1164021,"h":416612991733,"f":16777224},{"r":1310721,"n":"ToServerString","d":1164021,"h":420907959029,"f":16777224}],"l":[{"t":655361,"n":"MaxSupportedVersion","d":1164021,"h":4296131317,"f":4194344},{"t":1310721,"n":"MaxSupportedVersionString","d":1164021,"h":8591098613,"f":4194344},{"t":1310721,"n":"SeparatorLiteral","d":1164021,"h":12886065909,"f":4194344},{"t":458753,"n":"EqualsLiteral","d":1164021,"h":17181033205,"f":4194344},{"t":1310721,"n":"QuotesLiteral","d":1164021,"h":21476000501,"f":4194344},{"t":1310721,"n":"SpecialAttributeLiteral","d":1164021,"h":25770967797,"f":4194344},{"t":$.$typeArray($.$$.System.Char).$h,"n":"PortSplitDelimiters","d":1164021,"h":30065935093,"f":4194344},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"s_reservedToNameChars","d":1164021,"h":34360902389,"f":4194338},{"t":$.$$.System.Buffers.SearchValues$$($.$$.System.Char).$h,"n":"s_domainChars","d":1164021,"h":38655869685,"f":4194338},{"t":1310721,"n":"m_comment","d":1164021,"h":42950836981,"f":4194306},{"t":1746220,"n":"m_commentUri","d":1164021,"h":47245804277,"f":4194306},{"t":1884917,"n":"m_cookieVariant","d":1164021,"h":51540771573,"f":4194306},{"t":262145,"n":"m_discard","d":1164021,"h":55835738869,"f":4194306},{"t":1310721,"n":"m_domain","d":1164021,"h":60130706165,"f":4194306},{"t":262145,"n":"m_domain_implicit","d":1164021,"h":64425673461,"f":4194306},{"t":34275329,"n":"m_expires","d":1164021,"h":68720640757,"f":4194306},{"t":1310721,"n":"m_name","d":1164021,"h":73015608053,"f":4194306},{"t":1310721,"n":"m_path","d":1164021,"h":77310575349,"f":4194306},{"t":262145,"n":"m_path_implicit","d":1164021,"h":81605542645,"f":4194306},{"t":1310721,"n":"m_port","d":1164021,"h":85900509941,"f":4194306},{"t":262145,"n":"m_port_implicit","d":1164021,"h":90195477237,"f":4194306},{"t":$.$typeArray($.$$.System.Int32).$h,"n":"m_port_list","d":1164021,"h":94490444533,"f":4194306},{"t":262145,"n":"m_secure","d":1164021,"h":98785411829,"f":4194306},{"t":262145,"n":"m_httpOnly","d":1164021,"h":103080379125,"f":4194306,"a":[{"t":113573889,"c":21588410369}]},{"t":34275329,"n":"m_timeStamp","d":1164021,"h":107375346421,"f":4194306},{"t":1310721,"n":"m_value","d":1164021,"h":111670313717,"f":4194306},{"t":655361,"n":"m_version","d":1164021,"h":115965281013,"f":4194306},{"t":1310721,"n":"m_domainKey","d":1164021,"h":120260248309,"f":4194306},{"t":262145,"n":"IsQuotedVersion","d":1164021,"h":124555215605,"f":4194312},{"t":262145,"n":"IsQuotedDomain","d":1164021,"h":128850182901,"f":4194312}],"c":[{"n":".ctor","o":"$ctor$1","d":1164021,"h":137440117493,"f":16777217},{"p":[{"n":"name","p":1310721},{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$4","d":1164021,"h":141735084789,"f":16777217},{"p":[{"n":"name","p":1310721},{"n":"value","p":1310721},{"n":"path","p":1310721}],"n":".ctor","o":"$ctor$3","d":1164021,"h":146030052085,"f":16777217},{"p":[{"n":"name","p":1310721},{"n":"value","p":1310721},{"n":"path","p":1310721},{"n":"domain","p":1310721}],"n":".ctor","o":"$ctor$2","d":1164021,"h":150325019381,"f":16777217}],"h":1164021,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Cookie`; }
        });
        
        $asm.$cls("$snp.System.HexConverter", ($self) => class HexConverter
        {
            static $_Casing;
            static get Casing()
            {
                let $cls = $.$snp.System.HexConverter;
                return $cls.$_Casing ??= $asm.$nstr("$snp.System.HexConverter.Casing", ($self) => class Casing extends $.$$.System.Enum
                {
                    static Upper = 0;
                    static Lower = 8224;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Upper": 0n,
                            "Lower": 8224n
                        };
                    }
                    static $h = 836341;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$$.System.UInt32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":720897,"l":[{"t":836341,"n":"Upper","d":836341,"h":4295803637,"f":4194337},{"t":836341,"n":"Lower","d":836341,"h":8590770933,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":836341,"h":12885738229,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":770805,"h":836341}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.HexConverter.Casing`; }
                }, $cls, ($v) => $cls.$_Casing = $v);
            }
            static /*void */ ToBytesBuffer(/*byte*/ value, /*Span<byte>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast(packedResult, $.$$.System.Byte);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$$.System.Byte);
            }
            static /*void */ ToCharsBuffer(/*byte*/ value, /*Span<char>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast((packedResult & 255), $.$$.System.Char);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$$.System.Char);
            }
            static /*void */ EncodeToUtf8(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ utf8Destination, /*Casing*/ casing)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(utf8Destination.Length >= (((source.Length * 2) | 0)), "utf8Destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$snp.System.HexConverter.ToBytesBuffer(source.get_Item(pos).$v, utf8Destination, ((pos * 2) | 0), casing);
                }
            }
            static /*void */ EncodeToUtf16(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*Casing*/ casing)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(destination.Length >= (((source.Length * 2) | 0)), "destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$snp.System.HexConverter.ToCharsBuffer(source.get_Item(pos).$v, destination, ((pos * 2) | 0), casing);
                }
            }
            static /*string */ ToString$1(/*ReadOnlySpan<byte>*/ bytes, /*Casing*/ casing)
            {
                /*SpanCasingPair*/ let args = (() =>
                {
                    //new $.$snp.System.HexConverter.SpanCasingPair()
                    const $t1 = $.$snp.System.HexConverter.SpanCasingPair;
                    const $i1 = new $t1();
                    $i1.Bytes = bytes;
                    $i1.Casing = casing;
                    return $i1;
                })();
                return $.$$.System.String.Create$10($.$snp.System.HexConverter.SpanCasingPair, ((bytes.Length * 2) | 0), args.Clone(), new ($.$$.System.Buffers.SpanAction$$$($.$$.System.Char, $.$snp.System.HexConverter.SpanCasingPair))().$ctor($.$snp.System.HexConverter, /*static*/ (/*chars*/ chars, /*args*/ args) =>
                {
                    return $.$snp.System.HexConverter.EncodeToUtf16(args.Bytes, chars, args.Casing);
                }, {"r":65537,"p":[{"n":"chars","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"args","p":901877}],"n":"","d":770805,"h":0,"f":17825826}));
            }
            static $_SpanCasingPair;
            static get SpanCasingPair()
            {
                let $cls = $.$snp.System.HexConverter;
                return $cls.$_SpanCasingPair ??= $asm.$nstr("$snp.System.HexConverter.SpanCasingPair", ($self) => class SpanCasingPair extends $.$$.System.ValueType
                {
                    /*ReadOnlySpan<byte>*/ Bytes;
                    /*Casing*/ Casing = 0;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Bytes = this.Bytes.Clone();
                        copy.Casing = this.Casing;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Bytes = $.$default($.$$.System.ReadOnlySpan$$($.$$.System.Byte));
                        this.Casing = 0;
                    }
                    static $h = 901877;
                    static $z = 9;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":12885803765,"f":50331649},"s":{"r":0,"d":0,"h":17180771061,"f":83886081},"n":"Bytes","d":901877,"h":8590836469,"f":2097153},{"p":836341,"g":{"r":0,"d":0,"h":30065672949,"f":50331649},"s":{"r":0,"d":0,"h":34360640245,"f":83886081},"n":"Casing","d":901877,"h":25770705653,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":901877,"h":38655607541,"f":16777217}],"d":770805,"h":901877}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.HexConverter.SpanCasingPair`; }
                }, $cls, ($v) => $cls.$_SpanCasingPair = $v);
            }
            static /*char */ ToCharUpper(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*A*/ 65 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$$.System.Char);
            }
            static /*char */ ToCharLower(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*a*/ 97 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$$.System.Char);
            }
            static /*bool */ TryDecodeFromUtf8(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                return $.$snp.System.HexConverter.TryDecodeFromUtf8_Scalar(utf8Source, destination, bytesProcessed);
            }
            static /*bool */ TryDecodeFromUtf16(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                return $.$snp.System.HexConverter.TryDecodeFromUtf16_Scalar(source, destination, charsProcessed);
            }
            static /*bool */ TryDecodeFromUtf8_Scalar(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                $.$$.System.Diagnostics.Debug.Assert$2((utf8Source.Length % 2) === 0, "Un-even number of characters provided");
                $.$$.System.Diagnostics.Debug.Assert$2(($.trunc(utf8Source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$snp.System.HexConverter.FromChar(utf8Source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$snp.System.HexConverter.FromChar(utf8Source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$$.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                bytesProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*bool */ TryDecodeFromUtf16_Scalar(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                $.$$.System.Diagnostics.Debug.Assert$2((source.Length % 2) === 0, "Un-even number of characters provided");
                $.$$.System.Diagnostics.Debug.Assert$2(($.trunc(source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$snp.System.HexConverter.FromChar(source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$snp.System.HexConverter.FromChar(source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$$.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                charsProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*int */ FromChar(/*int*/ c)
            {
                return (c >= $.$snp.System.HexConverter.CharToHexLookup.Length) ? 255 : $.$snp.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromUpperChar(/*int*/ c)
            {
                return (c > 71) ? 255 : $.$snp.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromLowerChar(/*int*/ c)
            {
                if (((((c - /*0*/ 48) | 0)) >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                {
                    return ((c - /*0*/ 48) | 0);
                }
                if (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97))
                {
                    return ((((c - /*a*/ 97) | 0) + 10) | 0);
                }
                return 255;
            }
            static /*bool */ IsHexChar(/*int*/ c)
            {
                //if (IntPtr.Size == 8) { ... }
                return $.$snp.System.HexConverter.FromChar(c) !== 255;
            }
            static /*bool */ IsHexUpperChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*A*/ 65) | 0)) >>> 0) <= (/*F*/ 70 - /*A*/ 65));
            }
            static /*bool */ IsHexLowerChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97));
            }
            static /*ReadOnlySpan<byte> */ get CharToHexLookup()
            {
                return this.$cacheCharToHexLookup ??= new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4([ 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255 ]);
            }
            static $h = 770805;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":90195084021,"f":50331681},"n":"CharToHexLookup","d":770805,"h":85900116725,"f":2097185}],"m":[{"r":65537,"p":[{"n":"value","p":393217},{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"startingIndex","p":655361,"f":65,"v":0},{"n":"casing","p":836341,"f":65,"v":0}],"n":"ToBytesBuffer","d":770805,"h":8590705397,"f":16777249},{"r":65537,"p":[{"n":"value","p":393217},{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"startingIndex","p":655361,"f":65,"v":0},{"n":"casing","p":836341,"f":65,"v":0}],"n":"ToCharsBuffer","d":770805,"h":12885672693,"f":16777249},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"utf8Destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"casing","p":836341,"f":65,"v":0}],"n":"EncodeToUtf8","d":770805,"h":17180639989,"f":16777249},{"r":65537,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"casing","p":836341,"f":65,"v":0}],"n":"EncodeToUtf16","d":770805,"h":21475607285,"f":16777249},{"r":1310721,"p":[{"n":"bytes","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"casing","p":836341,"f":65,"v":0}],"n":"ToString","o":"@$1","d":770805,"h":25770574581,"f":16777249},{"r":458753,"p":[{"n":"value","p":655361}],"n":"ToCharUpper","d":770805,"h":34360509173,"f":16777249},{"r":458753,"p":[{"n":"value","p":655361}],"n":"ToCharLower","d":770805,"h":38655476469,"f":16777249},{"r":262145,"p":[{"n":"utf8Source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf8","d":770805,"h":42950443765,"f":16777249},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"charsProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf16","d":770805,"h":47245411061,"f":16777249},{"r":262145,"p":[{"n":"utf8Source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf8_Scalar","d":770805,"h":51540378357,"f":16777250},{"r":262145,"p":[{"n":"source","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"charsProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf16_Scalar","d":770805,"h":55835345653,"f":16777250},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromChar","d":770805,"h":60130312949,"f":16777249},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromUpperChar","d":770805,"h":64425280245,"f":16777249},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromLowerChar","d":770805,"h":68720247541,"f":16777249},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexChar","d":770805,"h":73015214837,"f":16777249},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexUpperChar","d":770805,"h":77310182133,"f":16777249},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexLowerChar","d":770805,"h":81605149429,"f":16777249}],"j":[836341,901877],"h":770805}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.HexConverter`; }
        });
        
        $asm.$cls("$snp.System.Net.TcpValidationHelpers", ($self) => class TcpValidationHelpers
        {
            static /*bool */ ValidatePortNumber(/*int*/ port)
            {
                return port >= 0/*IPEndPoint.MinPort*/ && port <= 65535/*IPEndPoint.MaxPort*/;
            }
            static $h = 4965109;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"port","p":655361}],"n":"ValidatePortNumber","d":4965109,"h":4299932405,"f":16777249}],"h":4965109}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.TcpValidationHelpers`; }
        });
        
        $asm.$cls("$snp.System.Net.PathList", ($self) => class PathList extends $.$$.System.Object
        {
            /*SortedList*/ m_list = null;
            /*int */ get Count()
            {
                return this.m_list.Count;
            }
            /*int */ GetCookiesCount()
            {
                /*int*/ let count = 0;
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncRoot)
                    {
                        /*IList*/ let list = this.m_list.GetValueList();
                        /*int*/ let listCount = list.System$Collections$ICollection$Count;
                        for(/*int*/ let i = 0; i < listCount; i++)
                        {
                            count += ($.$cast(list.System$Collections$IList$get_Item(i), $.$snp.System.Net.CookieCollection)).Count;
                        }
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncRoot)
                }
                return count;
            }
            /*ICollection */ get Values()
            {
                return this.m_list.Values;
            }
            /*object?*/ get_Item(/*string*/ s)
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncRoot)
                    {
                        return this.m_list.get_Item(s);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncRoot)
                }
            }
            /*void*/ set_Item(/*string*/ s, /*object?*/ value)
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncRoot)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(value !== null, "value != null");
                        this.m_list.set_Item(s, value);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncRoot)
                }
            }
            /*IDictionaryEnumerator */ GetEnumerator()
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncRoot)
                    {
                        return this.m_list.GetEnumerator();
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncRoot)
                }
            }
            /*void */ Remove(/*object*/ key)
            {
                //lock
                try
                {
                    $.$$.System.Threading.Monitor.Enter$1(this.SyncRoot)
                    {
                        this.m_list.Remove(key);
                    }
                }
                finally
                {
                    $.$$.System.Threading.Monitor.Exit(this.SyncRoot)
                }
            }
            /*SortedList */ get List()
            {
                return this.m_list;
            }
            /*object */ get SyncRoot()
            {
                return this.m_list.SyncRoot;
            }
            static $_PathListComparer;
            static get PathListComparer()
            {
                let $cls = $.$snp.System.Net.PathList;
                return $cls.$_PathListComparer ??= $asm.$ncls("$snp.System.Net.PathList.PathListComparer", ($self) => class PathListComparer extends $.$$.System.Object
                {
                    /*PathListComparer*/ static StaticInstance = null;
                    /*int */ System$Collections$IComparer$Compare(/*object?*/ ol, /*object?*/ or)
                    {
                        /*string*/ let pathLeft = $.$snp.System.Net.CookieParser.CheckQuoted($.$cast(ol, $.$$.System.String));
                        /*string*/ let pathRight = $.$snp.System.Net.CookieParser.CheckQuoted($.$cast(or, $.$$.System.String));
                        /*int*/ let ll = pathLeft.length;
                        /*int*/ let lr = pathRight.length;
                        /*int*/ let length = $.$$.System.Math.Min$4(ll, lr);
                        for(/*int*/ let i = 0; i < length; ++i)
                        {
                            if ($.$$.System.String.get_Chars.call(pathLeft, i) !== $.$$.System.String.get_Chars.call(pathRight, i))
                            {
                                return $.$$.System.String.get_Chars.call(pathLeft, i) - $.$$.System.String.get_Chars.call(pathRight, i);
                            }
                        }
                        return ((lr - ll) | 0);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.StaticInstance = new $.$snp.System.Net.PathList.PathListComparer().$ctor$1();
                        }
                    }
                    static $h = 4178677;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":4178677,"n":"StaticInstance","d":4178677,"h":4299145973,"f":4194344}],"c":[{"n":".ctor","o":"$ctor$1","d":4178677,"h":12889080565,"f":16777217}],"i":[31522817],"d":4113141,"h":4178677,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IComparer ]; }
                    static get $fullName() { return `System.Net.PathList.PathListComparer`; }
                }, $cls, ($v) => $cls.$_PathListComparer = $v);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.m_list = $.$scn.System.Collections.SortedList.Synchronized(new $.$scn.System.Collections.SortedList().$ctor$3($.$snp.System.Net.PathList.PathListComparer.StaticInstance));
            }
            static $h = 4113141;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12889015029,"f":50331656},"n":"Count","d":4113141,"h":8594047733,"f":2097160},{"p":31457281,"g":{"r":0,"d":0,"h":25773916917,"f":50331656},"n":"Values","d":4113141,"h":21478949621,"f":2097160},{"p":131073,"i":[{"n":"s","p":1310721}],"g":{"r":0,"d":0,"h":34363851509,"f":50331656},"s":{"r":0,"d":0,"h":38658818805,"f":83886088},"n":"Item","o":"@$2","d":4113141,"h":30068884213,"f":2097160},{"p":655395,"g":{"r":0,"d":0,"h":55838687989,"f":50331656},"n":"List","d":4113141,"h":51543720693,"f":2097160},{"p":131073,"g":{"r":0,"d":0,"h":64428622581,"f":50331656},"n":"SyncRoot","d":4113141,"h":60133655285,"f":2097160}],"m":[{"r":655361,"n":"GetCookiesCount","d":4113141,"h":17183982325,"f":16777224},{"r":31653889,"n":"GetEnumerator","d":4113141,"h":42953786101,"f":16777224},{"r":65537,"p":[{"n":"key","p":131073}],"n":"Remove","d":4113141,"h":47248753397,"f":16777224}],"l":[{"t":655395,"n":"m_list","d":4113141,"h":4299080437,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":4113141,"h":73018557173,"f":16777217}],"j":[4178677],"h":4113141,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.PathList`; }
        });
        
        $asm.$cls("$snp.System.Net.Sockets.IPEndPointExtensions", ($self) => class IPEndPointExtensions
        {
            static /*IPAddress */ GetIPAddress(/*ReadOnlySpan<byte>*/ socketAddressBuffer)
            {
                /*AddressFamily*/ let family = $.$snp.System.Net.SocketAddressPal.GetAddressFamily(socketAddressBuffer);
                if (family === 23/*AddressFamily.InterNetworkV6*/)
                {
                    /*Span<byte>*/ let address = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 16/*IPAddressParserStatics.IPv6AddressBytes*/, null);
                    /*uint*/ let scope;
                    $.$snp.System.Net.SocketAddressPal.GetIPv6Address(socketAddressBuffer, address, $.$ref(() => scope, ($v) => scope = $v, $.$$.System.UInt32));
                    return new $.$snp.System.Net.IPAddress().$ctor$5($.$$.System.Span$$($.$$.System.Byte).op_Implicit(address), (address.get_Item(0).$v === 254 && (address.get_Item(1).$v & 192) === 128) ? $.$cast(scope, $.$$.System.Int64) : 0n);
                }
                else if (family === 2/*AddressFamily.InterNetwork*/)
                {
                    return new $.$snp.System.Net.IPAddress().$ctor$4($.$cast($.$snp.System.Net.SocketAddressPal.GetIPv4Address(socketAddressBuffer), $.$$.System.Int64) & 4294967295n);
                }
                throw new $.$snp.System.Net.Sockets.SocketException().$ctor$22(10047/*SocketError.AddressFamilyNotSupported*/);
            }
            static /*void */ SetIPAddress(/*Span<byte>*/ socketAddressBuffer, /*IPAddress*/ address)
            {
                $.$snp.System.Net.SocketAddressPal.SetAddressFamily(socketAddressBuffer, address.AddressFamily);
                $.$snp.System.Net.SocketAddressPal.SetPort(socketAddressBuffer, 0);
                if (address.AddressFamily === 2/*AddressFamily.InterNetwork*/)
                {
                    $.$snp.System.Net.SocketAddressPal.SetIPv4Address$1(socketAddressBuffer, $.$cast(address.Address, $.$$.System.UInt32));
                }
                else 
                {
                    /*Span<byte>*/ let addressBuffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 16/*IPAddressParserStatics.IPv6AddressBytes*/, null);
                    /*int*/ let written;
                    address.TryWriteBytes(addressBuffer, $.$ref(() => written, ($v) => written = $v, $.$$.System.Int32));
                    $.$$.System.Diagnostics.Debug.Assert$2(written === 16/*IPAddressParserStatics.IPv6AddressBytes*/, "written == IPAddressParserStatics.IPv6AddressBytes");
                    $.$snp.System.Net.SocketAddressPal.SetIPv6Address$1(socketAddressBuffer, addressBuffer, $.$cast(address.ScopeId, $.$$.System.UInt32));
                }
            }
            static /*IPEndPoint */ CreateIPEndPoint(/*ReadOnlySpan<byte>*/ socketAddressBuffer)
            {
                return new $.$snp.System.Net.IPEndPoint().$ctor$3($.$snp.System.Net.Sockets.IPEndPointExtensions.GetIPAddress(socketAddressBuffer), $.$snp.System.Net.SocketAddressPal.GetPort(socketAddressBuffer));
            }
            static /*void */ Serialize(/*this IPEndPoint*/ endPoint, /*Span<byte>*/ destination)
            {
                $.$snp.System.Net.SocketAddressPal.SetAddressFamily(destination, endPoint.AddressFamily);
                $.$snp.System.Net.Sockets.IPEndPointExtensions.SetIPAddress(destination, endPoint.Address);
                $.$snp.System.Net.SocketAddressPal.SetPort(destination, $.$cast(endPoint.Port, $.$$.System.UInt16));
            }
            static /*bool */ Equals$2(/*this IPEndPoint*/ endPoint, /*ReadOnlySpan<byte>*/ socketAddressBuffer)
            {
                if (socketAddressBuffer.Length >= $.$snp.System.Net.SocketAddress.GetMaximumAddressSize(endPoint.AddressFamily) && endPoint.AddressFamily === $.$snp.System.Net.SocketAddressPal.GetAddressFamily(socketAddressBuffer) && endPoint.Port === $.$cast($.$snp.System.Net.SocketAddressPal.GetPort(socketAddressBuffer), $.$$.System.Int32))
                {
                    if (endPoint.AddressFamily === 2/*AddressFamily.InterNetwork*/)
                    {
                        return endPoint.Address.Address === $.$cast($.$snp.System.Net.SocketAddressPal.GetIPv4Address(socketAddressBuffer), $.$$.System.Int64);
                    }
                    else 
                    {
                        /*Span<byte>*/ let addressBuffer1 = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 16/*IPAddressParserStatics.IPv6AddressBytes*/, null);
                        /*Span<byte>*/ let addressBuffer2 = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 16/*IPAddressParserStatics.IPv6AddressBytes*/, null);
                        /*uint*/ let scopeid;
                        $.$snp.System.Net.SocketAddressPal.GetIPv6Address(socketAddressBuffer, addressBuffer1, $.$ref(() => scopeid, ($v) => scopeid = $v, $.$$.System.UInt32));
                        if (endPoint.Address.ScopeId !== $.$cast(scopeid, $.$$.System.Int64))
                        {
                            return false;
                        }
                        endPoint.Address.TryWriteBytes(addressBuffer2, $.$discardRef());
                        return $.$$.System.MemoryExtensions.SequenceEqual$1($.$$.System.Byte, $.$$.System.Span$$($.$$.System.Byte).op_Implicit(addressBuffer1), $.$$.System.Span$$($.$$.System.Byte).op_Implicit(addressBuffer2));
                    }
                }
                return false;
            }
            static $h = 4571893;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3064565,"p":[{"n":"socketAddressBuffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"GetIPAddress","d":4571893,"h":4299539189,"f":16777249},{"r":65537,"p":[{"n":"socketAddressBuffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"address","p":3064565}],"n":"SetIPAddress","d":4571893,"h":8594506485,"f":16777249},{"r":3326709,"p":[{"n":"socketAddressBuffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"CreateIPEndPoint","d":4571893,"h":12889473781,"f":16777249},{"r":65537,"p":[{"n":"endPoint","p":3326709},{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"Serialize","d":4571893,"h":17184441077,"f":16777249},{"r":262145,"p":[{"n":"endPoint","p":3326709},{"n":"socketAddressBuffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"Equals","o":"@$2","d":4571893,"h":21479408373,"f":16777249}],"h":4571893}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Sockets.IPEndPointExtensions`; }
        });
        
        $asm.$cls("$snp.System.Net.CredentialCacheKey", ($self) => class CredentialCacheKey extends $.$$.System.Object
        {
            /*Uri*/ UriPrefix = null;
            /*int*/ UriPrefixLength = -1;
            /*string*/ AuthenticationType = null;
            $ctor$1(/*Uri*/ uriPrefix, /*string*/ authenticationType)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2($.$spu.System.Uri.op_Inequality(uriPrefix, null), "uriPrefix != null");
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.op_Inequality(authenticationType, null), "authenticationType != null");
                    this.UriPrefix = uriPrefix;
                    this.UriPrefixLength = $.$$.System.String.LastIndexOf$2.call(this.UriPrefix.AbsolutePath, /*/*/ 47);
                    this.AuthenticationType = authenticationType;
                }
                return this;
            }
            /*bool */ Match(/*Uri*/ uri, /*int*/ prefixLen, /*string*/ authenticationType)
            {
                if ($.$spu.System.Uri.op_Equality(uri, null) || $.$$.System.String.op_Equality(authenticationType, null))
                {
                    return false;
                }
                if (!$.$$.System.String.Equals$2(authenticationType, this.AuthenticationType, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Match(${$.$spu.System.Uri.ToString.call(this.UriPrefix)} & ${$.$spu.System.Uri.ToString.call(uri)})`, "Match");
                }
                return this.IsPrefix(uri, prefixLen);
            }
            /*bool */ IsPrefix(/*Uri*/ uri, /*int*/ prefixLen)
            {
                $.$$.System.Diagnostics.Debug.Assert$2($.$spu.System.Uri.op_Inequality(uri, null), "uri != null");
                /*Uri*/ let uriPrefix = this.UriPrefix;
                if ($.$$.System.String.op_Inequality(uriPrefix.Scheme, uri.Scheme) || $.$$.System.String.op_Inequality(uriPrefix.Host, uri.Host) || uriPrefix.Port !== uri.Port)
                {
                    return false;
                }
                if (this.UriPrefixLength > prefixLen)
                {
                    return false;
                }
                return $.$$.System.String.Compare$3(uri.AbsolutePath, 0, uriPrefix.AbsolutePath, 0, this.UriPrefixLength, 5/*StringComparison.OrdinalIgnoreCase*/) === 0;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(this.AuthenticationType) ^ $.$spu.System.Uri.GetHashCode.call(this.UriPrefix);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snp.System.Net.CredentialCacheKey.GetHashCode.apply(this, arguments); }
            /*bool */ Equals$2(/*CredentialCacheKey?*/ other)
            {
                if (other === null)
                {
                    return false;
                }
                /*bool*/ let equals = $.$$.System.String.Equals$2(this.AuthenticationType, other.AuthenticationType, 5/*StringComparison.OrdinalIgnoreCase*/) && this.UriPrefix.Equals$2(other.UriPrefix);
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Equals(${$.$snp.System.Net.CredentialCacheKey.ToString.call(this)},${$.$snp.System.Net.CredentialCacheKey.ToString.call(other)}) returns ${equals}`, "Equals");
                }
                return equals;
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                return this.Equals$2($.$as(obj, $.$snp.System.Net.CredentialCacheKey));
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$snp.System.Net.CredentialCacheKey.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return $.$$.System.String.Create$6($.$$.System.Globalization.CultureInfo.InvariantCulture, `[${this.UriPrefixLength}]:${$.$spu.System.Uri.ToString.call(this.UriPrefix)}:${this.AuthenticationType}`);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.CredentialCacheKey.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Net.CredentialCacheKey?>.Equals(System.Net.CredentialCacheKey?)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            static $h = 2343669;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"uri","p":1746220},{"n":"prefixLen","p":655361},{"n":"authenticationType","p":1310721}],"n":"Match","d":2343669,"h":21477180149,"f":16777224},{"r":262145,"p":[{"n":"uri","p":1746220},{"n":"prefixLen","p":655361}],"n":"IsPrefix","d":2343669,"h":25772147445,"f":16777218},{"r":655361,"n":"GetHashCode","d":2343669,"h":30067114741,"f":16809985},{"r":262145,"p":[{"n":"other","p":2343669}],"n":"Equals","o":"@$2","d":2343669,"h":34362082037,"f":16777217},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":2343669,"h":38657049333,"f":16809985},{"r":1310721,"n":"ToString","d":2343669,"h":42952016629,"f":16809985}],"l":[{"t":1746220,"n":"UriPrefix","d":2343669,"h":4297310965,"f":4194305},{"t":655361,"n":"UriPrefixLength","d":2343669,"h":8592278261,"f":4194305},{"t":1310721,"n":"AuthenticationType","d":2343669,"h":12887245557,"f":4194305}],"c":[{"p":[{"n":"uriPrefix","p":1746220},{"n":"authenticationType","p":1310721}],"n":".ctor","o":"$ctor$1","d":2343669,"h":17182212853,"f":16777224}],"i":[$.$$.System.IEquatable$$($.$snp.System.Net.CredentialCacheKey).$h],"h":2343669}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$snp.System.Net.CredentialCacheKey) ]; }
            static get $fullName() { return `System.Net.CredentialCacheKey`; }
        });
        
        $asm.$cls("$snp.System.Net.SocketAddress", ($self) => class SocketAddress extends $.$$.System.Object
        {
            /*int*/ static IPv6AddressSize = 0;
            /*int*/ static IPv4AddressSize = 0;
            /*int*/ static UdsAddressSize = 0;
            /*int*/ static MaxAddressSize = 0;
            /*int*/ _size = 0;
            /*byte[]*/ _buffer = null;
            /*int*/ static MinSize = 2;
            /*int*/ static DataOffset = 2;
            /*AddressFamily */ get Family()
            {
                return $.$snp.System.Net.SocketAddressPal.GetAddressFamily($.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1(this._buffer));
            }
            /*int */ get Size()
            {
                return this._size;
            }
            /*int */ set Size(value)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, value, this._buffer.length, "value");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, value, 0, "value");
                this._size = value;
            }
            /*byte*/ get_Item(/*int*/ offset)
            {
                if ((offset >>> 0) >= (this.Size >>> 0))
                {
                    throw new $.$$.System.IndexOutOfRangeException().$ctor$9();
                }
                return $.$$.System.Array.$ReadT1.call(this._buffer, offset);
            }
            /*void*/ set_Item(/*int*/ offset, /*byte*/ value)
            {
                if ((offset >>> 0) >= (this.Size >>> 0))
                {
                    throw new $.$$.System.IndexOutOfRangeException().$ctor$9();
                }
                $.$$.System.Array.$WriteT1.call(this._buffer, value, offset);
            }
            static /*int */ GetMaximumAddressSize(/*AddressFamily*/ addressFamily)
            {
                return (() =>
                {
                    if (addressFamily === 2/*AddressFamily.InterNetwork*/)
                    {
                        return $.$snp.System.Net.SocketAddress.IPv4AddressSize;
                    }
                    if (addressFamily === 23/*AddressFamily.InterNetworkV6*/)
                    {
                        return $.$snp.System.Net.SocketAddress.IPv6AddressSize;
                    }
                    if (addressFamily === 1/*AddressFamily.Unix*/)
                    {
                        return $.$snp.System.Net.SocketAddress.UdsAddressSize;
                    }
                    return $.$snp.System.Net.SocketAddress.MaxAddressSize;
                })();
            }
            $ctor$4(/*AddressFamily*/ family)
            {
                this.$ctor$3(family, $.$snp.System.Net.SocketAddress.GetMaximumAddressSize(family));
                {
                }
                return this;
            }
            $ctor$3(/*AddressFamily*/ family, /*int*/ size)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, size, 2/*MinSize*/, "size");
                    this._size = size;
                    this._buffer = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [size], null);
                    $.$$.System.Array.$WriteT1.call(this._buffer, $.$cast(this._size, $.$$.System.Byte), 0);
                    $.$snp.System.Net.SocketAddressPal.SetAddressFamily($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(this._buffer), family);
                }
                return this;
            }
            $ctor$2(/*IPAddress*/ ipAddress)
            {
                this.$ctor$3(ipAddress.AddressFamily, ((ipAddress.AddressFamily === 2/*AddressFamily.InterNetwork*/) ? $.$snp.System.Net.SocketAddress.IPv4AddressSize : $.$snp.System.Net.SocketAddress.IPv6AddressSize));
                {
                    $.$snp.System.Net.SocketAddressPal.SetPort($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(this._buffer), 0);
                    if (ipAddress.AddressFamily === 23/*AddressFamily.InterNetworkV6*/)
                    {
                        /*Span<byte>*/ let addressBytes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Byte, 16/*IPAddressParserStatics.IPv6AddressBytes*/, null);
                        /*int*/ let bytesWritten;
                        ipAddress.TryWriteBytes(addressBytes, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32));
                        $.$$.System.Diagnostics.Debug.Assert$2(bytesWritten === 16/*IPAddressParserStatics.IPv6AddressBytes*/, "bytesWritten == IPAddressParserStatics.IPv6AddressBytes");
                        $.$snp.System.Net.SocketAddressPal.SetIPv6Address$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(this._buffer), addressBytes, $.$cast(ipAddress.ScopeId, $.$$.System.UInt32));
                    }
                    else 
                    {
                        /*uint*/ let address = $.$cast(ipAddress.Address, $.$$.System.UInt32);
                        $.$$.System.Diagnostics.Debug.Assert$2(ipAddress.AddressFamily === 2/*AddressFamily.InterNetwork*/, "ipAddress.AddressFamily == AddressFamily.InterNetwork");
                        $.$snp.System.Net.SocketAddressPal.SetIPv4Address$1($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(this._buffer), address);
                    }
                }
                return this;
            }
            $ctor$1(/*IPAddress*/ ipaddress, /*int*/ port)
            {
                this.$ctor$2(ipaddress);
                {
                    $.$snp.System.Net.SocketAddressPal.SetPort($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(this._buffer), $.$cast(port, $.$$.System.UInt16));
                }
                return this;
            }
            /*Memory<byte> */ get Buffer()
            {
                return new ($.$$.System.Memory$$($.$$.System.Byte))().$ctor$7(this._buffer);
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ comparand)
            {
                let other;
                return $.$is(comparand, $.$snp.System.Net.SocketAddress, { set $v(v){ other = v; } }) && this.Equals$2(other);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$snp.System.Net.SocketAddress.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*SocketAddress?*/ comparand)
            {
                return comparand !== null && $.$$.System.MemoryExtensions.SequenceEqual$1($.$$.System.Byte, $.$$.System.Span$$($.$$.System.Byte).op_Implicit(this.Buffer.Span), $.$$.System.Span$$($.$$.System.Byte).op_Implicit(comparand.Buffer.Span));
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                /*HashCode*/ let hash = new $.$$.System.HashCode();
                hash.AddBytes(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$3(this._buffer, 0, this._size));
                return hash.ToHashCode();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snp.System.Net.SocketAddress.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                /*string*/ let familyString = $.$$.System.Enum.ToStringT($.$snp.System.Net.Sockets.AddressFamily, $.$$.System.UInt32, this.Family);
                /*int*/ let maxLength = $.$checked($.$checked($.$checked($.$checked($.$checked(familyString.length + 1, 1) + 10, 1) + 2, 1) + $.$checked(($.$checked(this.Size - 2/*DataOffset*/, 1)) * 4, 1), 1) + 1, 1);
                /*Span<char>*/ let result = (maxLength >>> 0) <= 256 ? $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 256, null) : $.$$.System.Span$$($.$$.System.Char).op_Implicit$2($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Char), null, [maxLength], null));
                $.$$.System.String.CopyTo$1.call(familyString, result);
                /*int*/ let length = familyString.length;
                result.get_Item(length++).$v = /*:*/ 58;
                /*int*/ let charsWritten;
                /*bool*/ let formatted = $.$$.System.Int32.TryFormat$1.call(this.Size, result.Slice$1(length), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                $.$$.System.Diagnostics.Debug.Assert$2(formatted, "formatted");
                length += charsWritten;
                result.get_Item(length++).$v = /*:*/ 58;
                result.get_Item(length++).$v = /*{*/ 123;
                /*byte[]*/ let buffer = this._buffer;
                for(/*int*/ let i = 2/*DataOffset*/; i < this.Size; i++)
                {
                    if (i > 2/*DataOffset*/)
                    {
                        result.get_Item(length++).$v = /*,*/ 44;
                    }
                    formatted = $.$$.System.Byte.TryFormat$1.call($.$$.System.Array.$ReadT1.call(buffer, i), result.Slice$1(length), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$$.System.Int32), new ($.$$.System.ReadOnlySpan$$($.$$.System.Char))(), null);
                    $.$$.System.Diagnostics.Debug.Assert$2(formatted, "formatted");
                    length += charsWritten;
                }
                result.get_Item(length++).$v = /*}*/ 125;
                return $.$$.System.Span$$($.$$.System.Char).ToString.call(result.Slice(0, length));
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.SocketAddress.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Net.SocketAddress>.Equals(System.Net.SocketAddress?)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.IPv6AddressSize = $.$snp.System.Net.SocketAddressPal.IPv6AddressSize;
                }
                {
                    this.IPv4AddressSize = $.$snp.System.Net.SocketAddressPal.IPv4AddressSize;
                }
                {
                    this.UdsAddressSize = $.$snp.System.Net.SocketAddressPal.UdsAddressSize;
                }
                {
                    this.MaxAddressSize = $.$snp.System.Net.SocketAddressPal.MaxAddressSize;
                }
            }
            static $h = 4375285;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":4506357,"g":{"r":0,"d":0,"h":42954048245,"f":50331649},"n":"Family","d":4375285,"h":38659080949,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":51543982837,"f":50331649},"s":{"r":0,"d":0,"h":55838950133,"f":83886081},"n":"Size","d":4375285,"h":47249015541,"f":2097153},{"p":393217,"i":[{"n":"offset","p":655361}],"g":{"r":0,"d":0,"h":64428884725,"f":50331649},"s":{"r":0,"d":0,"h":68723852021,"f":83886081},"n":"Item","o":"@$2","d":4375285,"h":60133917429,"f":2097153},{"p":$.$$.System.Memory$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":98788623093,"f":50331649},"n":"Buffer","d":4375285,"h":94493655797,"f":2097153}],"m":[{"r":655361,"p":[{"n":"addressFamily","p":4506357}],"n":"GetMaximumAddressSize","d":4375285,"h":73018819317,"f":16777249},{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","o":"@$1","d":4375285,"h":103083590389,"f":16809985},{"r":262145,"p":[{"n":"comparand","p":4375285}],"n":"Equals","o":"@$2","d":4375285,"h":107378557685,"f":16777217},{"r":655361,"n":"GetHashCode","d":4375285,"h":111673524981,"f":16809985},{"r":1310721,"n":"ToString","d":4375285,"h":115968492277,"f":16809985}],"l":[{"t":655361,"n":"IPv6AddressSize","d":4375285,"h":4299342581,"f":4194344},{"t":655361,"n":"IPv4AddressSize","d":4375285,"h":8594309877,"f":4194344},{"t":655361,"n":"UdsAddressSize","d":4375285,"h":12889277173,"f":4194344},{"t":655361,"n":"MaxAddressSize","d":4375285,"h":17184244469,"f":4194344},{"t":655361,"n":"_size","d":4375285,"h":21479211765,"f":4194306},{"t":$.$typeArray($.$$.System.Byte).$h,"n":"_buffer","d":4375285,"h":25774179061,"f":4194306},{"t":655361,"n":"MinSize","d":4375285,"h":30069146357,"f":4194338},{"t":655361,"n":"DataOffset","d":4375285,"h":34364113653,"f":4194338}],"c":[{"p":[{"n":"family","p":4506357}],"n":".ctor","o":"$ctor$4","d":4375285,"h":77313786613,"f":16777217},{"p":[{"n":"family","p":4506357},{"n":"size","p":655361}],"n":".ctor","o":"$ctor$3","d":4375285,"h":81608753909,"f":16777217},{"p":[{"n":"ipAddress","p":3064565}],"n":".ctor","o":"$ctor$2","d":4375285,"h":85903721205,"f":16777224},{"p":[{"n":"ipaddress","p":3064565},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$1","d":4375285,"h":90198688501,"f":16777224}],"i":[$.$$.System.IEquatable$$($.$snp.System.Net.SocketAddress).$h],"h":4375285}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$snp.System.Net.SocketAddress) ]; }
            static get $fullName() { return `System.Net.SocketAddress`; }
        });
        
        $asm.$cls("$snp.System.Net.NetworkCredential", ($self) => class NetworkCredential extends $.$$.System.Object
        {
            /*string*/ _domain = null;
            /*string*/ _userName = null;
            /*object?*/ _password = null;
            $ctor$1()
            {
                this.$ctor$4($.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty);
                {
                }
                return this;
            }
            $ctor$5(/*string?*/ userName, /*string?*/ password)
            {
                this.$ctor$4(userName, password, $.$$.System.String.Empty);
                {
                }
                return this;
            }
            $ctor$4(/*string?*/ userName, /*string?*/ password, /*string?*/ domain)
            {
                super.$ctor();
                {
                    this.UserName = userName;
                    this.Password = password;
                    this.Domain = domain;
                }
                return this;
            }
            $ctor$3(/*string?*/ userName, /*SecureString?*/ password)
            {
                this.$ctor$2(userName, password, $.$$.System.String.Empty);
                {
                }
                return this;
            }
            $ctor$2(/*string?*/ userName, /*SecureString?*/ password, /*string?*/ domain)
            {
                super.$ctor();
                {
                    this.UserName = userName;
                    this.SecurePassword = password;
                    this.Domain = domain;
                }
                return this;
            }
            /*string */ get UserName()
            {
                return this._userName;
            }
            /*string */ set UserName(value)
            {
                this._userName = value ?? $.$$.System.String.Empty;
            }
            /*string */ get Password()
            {
                /*SecureString?*/ let sstr = $.$as(this._password, $.$$.System.Security.SecureString);
                if (sstr !== null)
                {
                    return $.$snp.System.Net.NetworkCredential.MarshalToString(sstr);
                }
                return $.$cast(this._password, $.$$.System.String) ?? $.$$.System.String.Empty;
            }
            /*string */ set Password(value)
            {
                /*SecureString?*/ let old = $.$as(this._password, $.$$.System.Security.SecureString);
                this._password = value;
                old?.Dispose();
            }
            /*SecureString */ get SecurePassword()
            {
                /*string?*/ let str = $.$as(this._password, $.$$.System.String);
                if ($.$$.System.String.op_Inequality(str, null))
                {
                    return this.MarshalToSecureString(str);
                }
                /*SecureString?*/ let sstr = $.$as(this._password, $.$$.System.Security.SecureString);
                return sstr !== null ? sstr.Copy() : new $.$$.System.Security.SecureString().$ctor$1();
            }
            /*SecureString */ set SecurePassword(value)
            {
                /*SecureString?*/ let old = $.$as(this._password, $.$$.System.Security.SecureString);
                this._password = (value?.Copy() ?? null);
                old?.Dispose();
            }
            /*string */ get Domain()
            {
                return this._domain;
            }
            /*string */ set Domain(value)
            {
                this._domain = value ?? $.$$.System.String.Empty;
            }
            /*NetworkCredential */ GetCredential$1(/*Uri?*/ uri, /*string?*/ authenticationType)
            {
                return this;
            }
            /*NetworkCredential */ GetCredential(/*string?*/ host, /*int*/ port, /*string?*/ authenticationType)
            {
                return this;
            }
            static /*string */ MarshalToString(/*SecureString*/ sstr)
            {
                if (sstr === null || sstr.Length === 0)
                {
                    return $.$$.System.String.Empty;
                }
                /*IntPtr*/ let ptr = $.$$.System.IntPtr.Zero;
                /*string*/ let result = $.$$.System.String.Empty;
                try
                {
                    ptr = $.$$.System.Runtime.InteropServices.Marshal.SecureStringToGlobalAllocUnicode(sstr);
                    result = $.$$.System.Runtime.InteropServices.Marshal.PtrToStringUni$1(ptr);
                }
                finally
                {
                    {
                        if (ptr !== $.$$.System.IntPtr.Zero)
                        {
                            $.$$.System.Runtime.InteropServices.Marshal.ZeroFreeGlobalAllocUnicode(ptr);
                        }
                    }
                }
                return result;
            }
            /*SecureString */ MarshalToSecureString(/*string*/ str)
            {
                if ($.$$.System.String.IsNullOrEmpty(str))
                {
                    return new $.$$.System.Security.SecureString().$ctor$1();
                }
                /*fixed*/ 
                {
                    /*char**/ let ptr = $.$$.System.String.GetPinnableReference.call(str);
                    return new $.$$.System.Security.SecureString().$ctor$2(ptr, str.length);
                }
            }
            //Generated interface implemetation for System.Net.ICredentials.GetCredential(System.Uri, string)
            System$Net$ICredentials$GetCredential()
            {
                return this.GetCredential$1(...arguments);
            }
            //Generated interface implemetation for System.Net.ICredentialsByHost.GetCredential(string, int, string)
            System$Net$ICredentialsByHost$GetCredential()
            {
                return this.GetCredential(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._userName = $.$$.System.String.Empty;
            }
            static $h = 3850997;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":42953523957,"f":50331649},"s":{"r":0,"d":0,"h":47248491253,"f":83886081},"n":"UserName","d":3850997,"h":38658556661,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":55838425845,"f":50331649},"s":{"r":0,"d":0,"h":60133393141,"f":83886081},"n":"Password","d":3850997,"h":51543458549,"f":2097153},{"p":117178369,"g":{"r":0,"d":0,"h":68723327733,"f":50331649},"s":{"r":0,"d":0,"h":73018295029,"f":83886081},"n":"SecurePassword","d":3850997,"h":64428360437,"f":2097153,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":81608229621,"f":50331649},"s":{"r":0,"d":0,"h":85903196917,"f":83886081},"n":"Domain","d":3850997,"h":77313262325,"f":2097153}],"m":[{"r":3850997,"p":[{"n":"uri","p":1746220},{"n":"authenticationType","p":1310721}],"n":"GetCredential","o":"@$1","d":3850997,"h":90198164213,"f":16777217},{"r":3850997,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"authenticationType","p":1310721}],"n":"GetCredential","d":3850997,"h":94493131509,"f":16777217},{"r":1310721,"p":[{"n":"sstr","p":117178369}],"n":"MarshalToString","d":3850997,"h":98788098805,"f":16777250},{"r":117178369,"p":[{"n":"str","p":1310721}],"n":"MarshalToSecureString","d":3850997,"h":103083066101,"f":16777218}],"l":[{"t":1310721,"n":"_domain","d":3850997,"h":4298818293,"f":4194306},{"t":1310721,"n":"_userName","d":3850997,"h":8593785589,"f":4194306},{"t":131073,"n":"_password","d":3850997,"h":12888752885,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":3850997,"h":17183720181,"f":16777217},{"p":[{"n":"userName","p":1310721},{"n":"password","p":1310721}],"n":".ctor","o":"$ctor$5","d":3850997,"h":21478687477,"f":16777217},{"p":[{"n":"userName","p":1310721},{"n":"password","p":1310721},{"n":"domain","p":1310721}],"n":".ctor","o":"$ctor$4","d":3850997,"h":25773654773,"f":16777217},{"p":[{"n":"userName","p":1310721},{"n":"password","p":117178369}],"n":".ctor","o":"$ctor$3","d":3850997,"h":30068622069,"f":16777217,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"p":[{"n":"userName","p":1310721},{"n":"password","p":117178369},{"n":"domain","p":1310721}],"n":".ctor","o":"$ctor$2","d":3850997,"h":34363589365,"f":16777217,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]}],"i":[2933493,2999029],"h":3850997}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$snp.System.Net.ICredentials, $.$snp.System.Net.ICredentialsByHost ]; }
            static get $fullName() { return `System.Net.NetworkCredential`; }
        });
        
        $asm.$cls("$snp.System.Net.CredentialCache", ($self) => class CredentialCache extends $.$$.System.Object
        {
            /*Dictionary<CredentialCacheKey, NetworkCredential>?*/ _cache = null;
            /*Dictionary<CredentialHostKey, NetworkCredential>?*/ _cacheForHosts = null;
            /*int*/ _version = 0;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*void */ Add$1(/*Uri*/ uriPrefix, /*string*/ authType, /*NetworkCredential*/ cred)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uriPrefix, "uriPrefix");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(authType, "authType");
                if (($.$is(cred, $.$snp.System.Net.SystemNetworkCredential)) && !(($.$$.System.String.Equals$2(authType, "NTLM"/*NegotiationInfoClass.NTLM*/, 5/*StringComparison.OrdinalIgnoreCase*/)) || ($.$$.System.String.Equals$2(authType, "Kerberos"/*NegotiationInfoClass.Kerberos*/, 5/*StringComparison.OrdinalIgnoreCase*/)) || ($.$$.System.String.Equals$2(authType, "Negotiate"/*NegotiationInfoClass.Negotiate*/, 5/*StringComparison.OrdinalIgnoreCase*/))))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$snp.System.SR.Format$6($.$snp.System.SR.net_nodefaultcreds, authType), "authType");
                }
                ++this._version;
                /*var*/ let key = new $.$snp.System.Net.CredentialCacheKey().$ctor$1(uriPrefix, authType);
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Adding key:[${$.$snp.System.Net.CredentialCacheKey.ToString.call(key)}], cred:[${cred.Domain}],[${cred.UserName}]`, "Add");
                }
                this._cache ??= new ($.$$.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialCacheKey, $.$snp.System.Net.NetworkCredential))().$ctor$1();
                this._cache.Add(key, cred);
            }
            /*void */ Add(/*string*/ host, /*int*/ port, /*string*/ authenticationType, /*NetworkCredential*/ credential)
            {
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(host, "host");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(authenticationType, "authenticationType");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, port, "port");
                if (($.$is(credential, $.$snp.System.Net.SystemNetworkCredential)) && !(($.$$.System.String.Equals$2(authenticationType, "NTLM"/*NegotiationInfoClass.NTLM*/, 5/*StringComparison.OrdinalIgnoreCase*/)) || ($.$$.System.String.Equals$2(authenticationType, "Kerberos"/*NegotiationInfoClass.Kerberos*/, 5/*StringComparison.OrdinalIgnoreCase*/)) || ($.$$.System.String.Equals$2(authenticationType, "Negotiate"/*NegotiationInfoClass.Negotiate*/, 5/*StringComparison.OrdinalIgnoreCase*/))))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$snp.System.SR.Format$6($.$snp.System.SR.net_nodefaultcreds, authenticationType), "authenticationType");
                }
                ++this._version;
                /*var*/ let key = new $.$snp.System.Net.CredentialHostKey().$ctor$3(host, port, authenticationType);
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Adding key:[${$.$snp.System.Net.CredentialHostKey.ToString.call(key)}], cred:[${credential.Domain}],[${credential.UserName}]`, "Add");
                }
                this._cacheForHosts ??= new ($.$$.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialHostKey, $.$snp.System.Net.NetworkCredential))().$ctor$1();
                this._cacheForHosts.Add(key, credential);
            }
            /*void */ Remove$1(/*Uri?*/ uriPrefix, /*string?*/ authType)
            {
                if ($.$spu.System.Uri.op_Equality(uriPrefix, null) || $.$$.System.String.op_Equality(authType, null))
                {
                    return;
                }
                if (this._cache === null)
                {
                    if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                    {
                        $.$snp.System.Net.NetEventSource.Info$1(this, "Short-circuiting because the dictionary is null.", "Remove");
                    }
                    return;
                }
                ++this._version;
                /*var*/ let key = new $.$snp.System.Net.CredentialCacheKey().$ctor$1(uriPrefix, authType);
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Removing key:[${$.$snp.System.Net.CredentialCacheKey.ToString.call(key)}]`, "Remove");
                }
                this._cache.Remove$1(key);
            }
            /*void */ Remove(/*string?*/ host, /*int*/ port, /*string?*/ authenticationType)
            {
                if ($.$$.System.String.op_Equality(host, null) || $.$$.System.String.op_Equality(authenticationType, null))
                {
                    return;
                }
                if (port < 0)
                {
                    return;
                }
                if (this._cacheForHosts === null)
                {
                    if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                    {
                        $.$snp.System.Net.NetEventSource.Info$1(this, "Short-circuiting because the dictionary is null.", "Remove");
                    }
                    return;
                }
                ++this._version;
                /*var*/ let key = new $.$snp.System.Net.CredentialHostKey().$ctor$3(host, port, authenticationType);
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Removing key:[${$.$snp.System.Net.CredentialHostKey.ToString.call(key)}]`, "Remove");
                }
                this._cacheForHosts.Remove$1(key);
            }
            /*NetworkCredential? */ GetCredential$1(/*Uri*/ uriPrefix, /*string*/ authType)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(uriPrefix, "uriPrefix");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(authType, "authType");
                if (this._cache === null)
                {
                    if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                    {
                        $.$snp.System.Net.NetEventSource.Info$1(this, "CredentialCache::GetCredential short-circuiting because the dictionary is null.", "GetCredential");
                    }
                    return null;
                }
                /*NetworkCredential?*/ let mostSpecificMatch;
                $.$snp.System.Net.CredentialCacheHelper.TryGetCredential(this._cache, uriPrefix, authType, $.$discardRef(), $.$ref(() => mostSpecificMatch, ($v) => mostSpecificMatch = $v, $.$snp.System.Net.NetworkCredential));
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Returning ${(mostSpecificMatch === null ? "null" : "(" + mostSpecificMatch.UserName + ":" + mostSpecificMatch.Domain + ")")}`, "GetCredential");
                }
                return mostSpecificMatch;
            }
            /*NetworkCredential? */ GetCredential(/*string*/ host, /*int*/ port, /*string*/ authenticationType)
            {
                $.$$.System.ArgumentException.ThrowIfNullOrEmpty(host, "host");
                $.$$.System.ArgumentNullException.ThrowIfNull$2(authenticationType, "authenticationType");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, port, "port");
                if (this._cacheForHosts === null)
                {
                    if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                    {
                        $.$snp.System.Net.NetEventSource.Info$1(this, "CredentialCache::GetCredential short-circuiting because the dictionary is null.", "GetCredential");
                    }
                    return null;
                }
                /*var*/ let key = new $.$snp.System.Net.CredentialHostKey().$ctor$3(host, port, authenticationType);
                /*NetworkCredential?*/ let match;
                this._cacheForHosts.TryGetValue(key, $.$ref(() => match, ($v) => match = $v, $.$snp.System.Net.NetworkCredential));
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Returning ${((match === null) ? "null" : "(" + match.UserName + ":" + match.Domain + ")")}`, "GetCredential");
                }
                return match;
            }
            /*IEnumerator */ GetEnumerator()
            {
                return $.$snp.System.Net.CredentialCache.CredentialEnumerator.Create(this);
            }
            static /*ICredentials */ get DefaultCredentials()
            {
                return $.$snp.System.Net.SystemNetworkCredential.s_defaultCredential;
            }
            static /*NetworkCredential */ get DefaultNetworkCredentials()
            {
                return $.$snp.System.Net.SystemNetworkCredential.s_defaultCredential;
            }
            static $_CredentialEnumerator;
            static get CredentialEnumerator()
            {
                let $cls = $.$snp.System.Net.CredentialCache;
                return $cls.$_CredentialEnumerator ??= $asm.$ncls("$snp.System.Net.CredentialCache.CredentialEnumerator", ($self) => class CredentialEnumerator extends $.$$.System.Object
                {
                    static /*CredentialEnumerator */ Create(/*CredentialCache*/ cache)
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(cache !== null, "cache != null");
                        if (cache._cache !== null)
                        {
                            return cache._cacheForHosts !== null ? new $.$snp.System.Net.CredentialCache.CredentialEnumerator.DoubleTableCredentialEnumerator().$ctor$3(cache) : new ($.$snp.System.Net.CredentialCache.CredentialEnumerator.SingleTableCredentialEnumerator$$($.$snp.System.Net.CredentialCacheKey))().$ctor$2(cache, cache._cache);
                        }
                        else 
                        {
                            return cache._cacheForHosts !== null ? new ($.$snp.System.Net.CredentialCache.CredentialEnumerator.SingleTableCredentialEnumerator$$($.$snp.System.Net.CredentialHostKey))().$ctor$2(cache, cache._cacheForHosts) : new $.$snp.System.Net.CredentialCache.CredentialEnumerator().$ctor$1(cache);
                        }
                    }
                    /*CredentialCache*/ _cache = null;
                    /*int*/ _version = 0;
                    /*bool*/ _enumerating = false;
                    /*NetworkCredential?*/ _current = null;
                    $ctor$1(/*CredentialCache*/ cache)
                    {
                        super.$ctor();
                        {
                            $.$$.System.Diagnostics.Debug.Assert$2(cache !== null, "cache != null");
                            this._cache = cache;
                            this._version = cache._version;
                        }
                        return this;
                    }
                    /*object */ get Current()
                    {
                        if (!this._enumerating)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$snp.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        if (this._version !== this._cache._version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$snp.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        return this._current;
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._version !== this._cache._version)
                        {
                            throw new $.$$.System.InvalidOperationException().$ctor$12($.$snp.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        return this._enumerating = this.MoveNext$1($.$ref(() => this._current, ($v) => this._current = $v, $.$snp.System.Net.NetworkCredential));
                    }
                    /*bool */ MoveNext$1(/*out NetworkCredential?*/ current)
                    {
                        current.$v = null;
                        return false;
                    }
                    /*void */ Reset()
                    {
                        this._enumerating = false;
                    }
                    static $_SingleTableCredentialEnumerator$$;
                    static SingleTableCredentialEnumerator$$(TKey)
                    {
                        let $cls = $.$snp.System.Net.CredentialCache.CredentialEnumerator;
                        return ($cls.$_SingleTableCredentialEnumerator$$ ??= $asm.$ncls("$snp.System.Net.CredentialCache.CredentialEnumerator.SingleTableCredentialEnumerator<>", (TKey) => $asm.$gt("$snp.System.Net.CredentialCache.CredentialEnumerator.SingleTableCredentialEnumerator<>", [TKey], ($self) => class SingleTableCredentialEnumerator$$ extends $.$snp.System.Net.CredentialCache.CredentialEnumerator
                        {
                            /*Dictionary<TKey, NetworkCredential>.ValueCollection.Enumerator*/ _enumerator;
                            $ctor$2(/*CredentialCache*/ cache, /*Dictionary<TKey, NetworkCredential>*/ table)
                            {
                                super.$ctor$1(cache);
                                {
                                    $.$$.System.Diagnostics.Debug.Assert$2(table !== null, "table != null");
                                    this._enumerator = table.Values.GetEnumerator();
                                }
                                return this;
                            }
                            /*bool */ MoveNext$1(/*out NetworkCredential*/ current)
                            {
                                return $.$snp.System.Net.CredentialCache.CredentialEnumerator.DictionaryEnumeratorHelper.MoveNext(TKey, $.$snp.System.Net.NetworkCredential, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Collections.Generic.Dictionary$$$(TKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator, () => this._enumerator, ($v) => this._enumerator = $v, null), current);
                            }
                            /*void */ Reset()
                            {
                                $.$snp.System.Net.CredentialCache.CredentialEnumerator.DictionaryEnumeratorHelper.Reset($.$$.System.Collections.Generic.Dictionary$$$(TKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Collections.Generic.Dictionary$$$(TKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator, () => this._enumerator, ($v) => this._enumerator = $v, null));
                                super.Reset();
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this._enumerator = $.$default($.$$.System.Collections.Generic.Dictionary$$$(TKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator);
                            }
                            static $h = 2212597;
                            static $g = 1;
                            static $f = 0b10000000001010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":2015989,"m":[{"r":262145,"p":[{"n":"current","p":3850997,"f":2}],"n":"MoveNext","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":16809988},{"r":65537,"n":"Reset","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":16809985}],"l":[{"t":$.$$.System.Collections.Generic.Dictionary$$$(TKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator.$h,"n":"_enumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":4194306}],"c":[{"p":[{"n":"cache","p":1950453},{"n":"table","p":$.$$.System.Collections.Generic.Dictionary$$$(TKey, $.$snp.System.Net.NetworkCredential).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":16777217}],"i":[31850497],"g":[TKey?.$h??1507328],"s":[{"n":"TKey","f":64}],"r":1,"d":2015989,"h":this.$h}; }
                            static get $b() { return $.$snp.System.Net.CredentialCache.CredentialEnumerator; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Net.CredentialCache.CredentialEnumerator.SingleTableCredentialEnumerator<${TKey?.$fullName}>`; }
                        }), $cls, ($v) => $cls.$_SingleTableCredentialEnumerator$$ = $v))(TKey);
                    }
                    static $_DoubleTableCredentialEnumerator;
                    static get DoubleTableCredentialEnumerator()
                    {
                        let $cls = $.$snp.System.Net.CredentialCache.CredentialEnumerator;
                        return $cls.$_DoubleTableCredentialEnumerator ??= $asm.$ncls("$snp.System.Net.CredentialCache.CredentialEnumerator.DoubleTableCredentialEnumerator", ($self) => class DoubleTableCredentialEnumerator extends $.$snp.System.Net.CredentialCache.CredentialEnumerator.SingleTableCredentialEnumerator$$($.$snp.System.Net.CredentialCacheKey)
                        {
                            /*Dictionary<CredentialHostKey, NetworkCredential>.ValueCollection.Enumerator*/ _enumerator$1;
                            /*bool*/ _onThisEnumerator = false;
                            $ctor$3(/*CredentialCache*/ cache)
                            {
                                super.$ctor$2(cache, cache._cache);
                                {
                                    $.$$.System.Diagnostics.Debug.Assert$2(cache._cacheForHosts !== null, "cache._cacheForHosts != null");
                                    this._enumerator$1 = cache._cacheForHosts.Values.GetEnumerator();
                                }
                                return this;
                            }
                            /*bool */ MoveNext$1(/*out NetworkCredential*/ current)
                            {
                                if (!this._onThisEnumerator)
                                {
                                    if (super.MoveNext$1(current))
                                    {
                                        return true;
                                    }
                                    else 
                                    {
                                        this._onThisEnumerator = true;
                                    }
                                }
                                return $.$snp.System.Net.CredentialCache.CredentialEnumerator.DictionaryEnumeratorHelper.MoveNext($.$snp.System.Net.CredentialHostKey, $.$snp.System.Net.NetworkCredential, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialHostKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator, () => this._enumerator$1, ($v) => this._enumerator$1 = $v, null), current);
                            }
                            /*void */ Reset()
                            {
                                this._onThisEnumerator = false;
                                $.$snp.System.Net.CredentialCache.CredentialEnumerator.DictionaryEnumeratorHelper.Reset($.$$.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialHostKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialHostKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator, () => this._enumerator$1, ($v) => this._enumerator$1 = $v, null));
                                super.Reset();
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this._enumerator$1 = $.$default($.$$.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialHostKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator);
                            }
                            static $h = 2147061;
                            static $f = 0b10000000010010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":2212597,"m":[{"r":262145,"p":[{"n":"current","p":3850997,"f":2}],"n":"MoveNext","o":"@$1","d":2147061,"h":17182016245,"f":16809988},{"r":65537,"n":"Reset","d":2147061,"h":21476983541,"f":16809985}],"l":[{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialHostKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator.$h,"n":"_enumerator","o":"@$1","d":2147061,"h":4297114357,"f":4194306},{"t":262145,"n":"_onThisEnumerator","d":2147061,"h":8592081653,"f":4194306}],"c":[{"p":[{"n":"cache","p":1950453}],"n":".ctor","o":"$ctor$3","d":2147061,"h":12887048949,"f":16777217}],"i":[31850497],"d":2015989,"h":2147061}; }
                            static get $b() { return $.$snp.System.Net.CredentialCache.CredentialEnumerator.SingleTableCredentialEnumerator$$($.$snp.System.Net.CredentialCacheKey); }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Net.CredentialCache.CredentialEnumerator.DoubleTableCredentialEnumerator`; }
                        }, $cls, ($v) => $cls.$_DoubleTableCredentialEnumerator = $v);
                    }
                    static $_DictionaryEnumeratorHelper;
                    static get DictionaryEnumeratorHelper()
                    {
                        let $cls = $.$snp.System.Net.CredentialCache.CredentialEnumerator;
                        return $cls.$_DictionaryEnumeratorHelper ??= $asm.$ncls("$snp.System.Net.CredentialCache.CredentialEnumerator.DictionaryEnumeratorHelper", ($self) => class DictionaryEnumeratorHelper
                        {
                            static /*bool */ MoveNext(TKey, TValue, /*ref Dictionary<TKey, TValue>.ValueCollection.Enumerator*/ enumerator, /*out TValue*/ current)
                            {
                                /*bool*/ let result = enumerator.$v.MoveNext();
                                current.$v = enumerator.$v.Current;
                                return result;
                            }
                            static /*void */ Reset(TEnumerator, /*ref TEnumerator*/ enumerator)
                            {
                                try
                                {
                                    $.$dsp(enumerator.$v, TEnumerator, ($t) => $t.System$Collections$IEnumerator$Reset,);
                                }
                                catch($e)
                                {
                                }
                            }
                            static $h = 2081525;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"enumerator","p":(TKey, TValue) => $.$$.System.Collections.Generic.Dictionary$$$(TKey, TValue).ValueCollection.Enumerator.$h,"f":4},{"n":"current","p":(TKey, TValue) => TValue.$h,"f":2}],"g":["TKey","TValue"],"n":"MoveNext","d":2081525,"h":4297048821,"f":16908328},{"r":65537,"p":[{"n":"enumerator","p":(TEnumerator) => TEnumerator.$h,"f":4}],"g":["TEnumerator"],"n":"Reset","d":2081525,"h":8592016117,"f":16908328}],"d":2015989,"h":2081525}; }
                            static get $b() { return $.$$.System.Object; }
                            static get $fullName() { return `System.Net.CredentialCache.CredentialEnumerator.DictionaryEnumeratorHelper`; }
                        }, $cls, ($v) => $cls.$_DictionaryEnumeratorHelper = $v);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get System$Collections$IEnumerator$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        return this.Reset(...arguments);
                    }
                    static $h = 2015989;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":34361754357,"f":50331649},"n":"Current","d":2015989,"h":30066787061,"f":2097153}],"m":[{"r":2015989,"p":[{"n":"cache","p":1950453}],"n":"Create","d":2015989,"h":4296983285,"f":16777256},{"r":262145,"n":"MoveNext","d":2015989,"h":38656721653,"f":16777217},{"r":262145,"p":[{"n":"current","p":3850997,"f":2}],"n":"MoveNext","o":"@$1","d":2015989,"h":42951688949,"f":16777348},{"r":65537,"n":"Reset","d":2015989,"h":47246656245,"f":16777345}],"l":[{"t":1950453,"n":"_cache","d":2015989,"h":8591950581,"f":4194306},{"t":655361,"n":"_version","d":2015989,"h":12886917877,"f":4194306},{"t":262145,"n":"_enumerating","d":2015989,"h":17181885173,"f":4194306},{"t":3850997,"n":"_current","d":2015989,"h":21476852469,"f":4194306}],"c":[{"p":[{"n":"cache","p":1950453}],"n":".ctor","o":"$ctor$1","d":2015989,"h":25771819765,"f":16777218}],"i":[31850497],"j":[2212597,2147061,2081525],"d":1950453,"h":2015989}; }
                    static get $b() { return $.$$.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Net.CredentialCache.CredentialEnumerator`; }
                }, $cls, ($v) => $cls.$_CredentialEnumerator = $v);
            }
            //Generated interface implemetation for System.Net.ICredentials.GetCredential(System.Uri, string)
            System$Net$ICredentials$GetCredential()
            {
                return this.GetCredential$1(...arguments);
            }
            //Generated interface implemetation for System.Net.ICredentialsByHost.GetCredential(string, int, string)
            System$Net$ICredentialsByHost$GetCredential()
            {
                return this.GetCredential(...arguments);
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 1950453;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2933493,"g":{"r":0,"d":0,"h":55836525301,"f":50331681},"n":"DefaultCredentials","d":1950453,"h":51541558005,"f":2097185},{"p":3850997,"g":{"r":0,"d":0,"h":64426459893,"f":50331681},"n":"DefaultNetworkCredentials","d":1950453,"h":60131492597,"f":2097185}],"m":[{"r":65537,"p":[{"n":"uriPrefix","p":1746220},{"n":"authType","p":1310721},{"n":"cred","p":3850997}],"n":"Add","o":"@$1","d":1950453,"h":21476786933,"f":16777217},{"r":65537,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"authenticationType","p":1310721},{"n":"credential","p":3850997}],"n":"Add","d":1950453,"h":25771754229,"f":16777217},{"r":65537,"p":[{"n":"uriPrefix","p":1746220},{"n":"authType","p":1310721}],"n":"Remove","o":"@$1","d":1950453,"h":30066721525,"f":16777217},{"r":65537,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"authenticationType","p":1310721}],"n":"Remove","d":1950453,"h":34361688821,"f":16777217},{"r":3850997,"p":[{"n":"uriPrefix","p":1746220},{"n":"authType","p":1310721}],"n":"GetCredential","o":"@$1","d":1950453,"h":38656656117,"f":16777217},{"r":3850997,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"authenticationType","p":1310721}],"n":"GetCredential","d":1950453,"h":42951623413,"f":16777217},{"r":31850497,"n":"GetEnumerator","d":1950453,"h":47246590709,"f":16777217}],"l":[{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialCacheKey, $.$snp.System.Net.NetworkCredential).$h,"n":"_cache","d":1950453,"h":4296917749,"f":4194306},{"t":$.$$.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialHostKey, $.$snp.System.Net.NetworkCredential).$h,"n":"_cacheForHosts","d":1950453,"h":8591885045,"f":4194306},{"t":655361,"n":"_version","d":1950453,"h":12886852341,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1950453,"h":17181819637,"f":16777217}],"i":[2933493,2999029,31719425],"j":[2015989],"h":1950453}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$snp.System.Net.ICredentials, $.$snp.System.Net.ICredentialsByHost, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.CredentialCache`; }
        });
        
        $asm.$cls("$snp.System.Net.IPAddress", ($self) => class IPAddress extends $.$$.System.Object
        {
            /*IPAddress*/ static Any = null;
            /*IPAddress*/ static Loopback = null;
            /*IPAddress*/ static Broadcast = null;
            /*IPAddress*/ static None = null;
            /*uint*/ static LoopbackMaskHostOrder = 4278190080;
            /*IPAddress*/ static IPv6Any = null;
            /*IPAddress*/ static IPv6Loopback = null;
            /*IPAddress*/ static IPv6None = null;
            /*IPAddress*/ static s_loopbackMappedToIPv6 = null;
            /*uint*/ _addressOrScopeId = 0;
            /*ushort[]?*/ _numbers = null;
            /*string?*/ _toString = null;
            /*int*/ _hashCode = 0;
            /*int*/ static NumberOfLabels = 8;
            /*bool */ get IsIPv4()
            {
                return this._numbers === null;
            }
            /*bool */ get IsIPv6()
            {
                return this._numbers !== null;
            }
            /*uint */ get PrivateAddress()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this.IsIPv4, "IsIPv4");
                return this._addressOrScopeId;
            }
            /*uint */ set PrivateAddress(value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this.IsIPv4, "IsIPv4");
                this._toString = null;
                this._hashCode = 0;
                this._addressOrScopeId = value;
            }
            /*uint */ get PrivateIPv4Address()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this.IsIPv4 || this.IsIPv4MappedToIPv6, "IsIPv4 || IsIPv4MappedToIPv6");
                if (this.IsIPv4)
                {
                    return this._addressOrScopeId;
                }
                /*uint*/ let address = ($.$$.System.Array.$ReadT1.call(this._numbers, 6) << 16) >>> 0 | $.$$.System.Array.$ReadT1.call(this._numbers, 7);
                return ($.$snp.System.Net.IPAddress.HostToNetworkOrder$1((address | 0)) >>> 0);
            }
            /*uint */ get PrivateScopeId()
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this.IsIPv6, "IsIPv6");
                return this._addressOrScopeId;
            }
            /*uint */ set PrivateScopeId(value)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this.IsIPv6, "IsIPv6");
                this._toString = null;
                this._hashCode = 0;
                this._addressOrScopeId = value;
            }
            $ctor$4(/*long*/ newAddress)
            {
                super.$ctor();
                {
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.UInt64, $.$cast(newAddress, $.$$.System.UInt64), 4294967295n, "newAddress");
                    this.PrivateAddress = $.$cast(newAddress, $.$$.System.UInt32);
                }
                return this;
            }
            $ctor$1(/*byte[]*/ address, /*long*/ scopeid)
            {
                this.$ctor$5(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4(address ?? $.$snp.System.Net.IPAddress.ThrowAddressNullException()), scopeid);
                {
                }
                return this;
            }
            $ctor$5(/*ReadOnlySpan<byte>*/ address, /*long*/ scopeid)
            {
                super.$ctor();
                {
                    if (address.Length !== 16/*IPAddressParserStatics.IPv6AddressBytes*/)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$snp.System.SR.dns_bad_ip_address, "address");
                    }
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.UInt64, $.$cast(scopeid, $.$$.System.UInt64), 4294967295n, "scopeid");
                    this._numbers = $.$snp.System.Net.IPAddress.ReadUInt16NumbersFromBytes(address);
                    this.PrivateScopeId = $.$cast(scopeid, $.$$.System.UInt32);
                }
                return this;
            }
            $ctor$7(/*ReadOnlySpan<ushort>*/ numbers, /*uint*/ scopeid)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(numbers.Length === 8/*NumberOfLabels*/, "numbers.Length == NumberOfLabels");
                    this._numbers = numbers.ToArray();
                    this.PrivateScopeId = scopeid;
                }
                return this;
            }
            $ctor$8(/*ushort[]*/ numbers, /*uint*/ scopeid)
            {
                super.$ctor();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(numbers !== null, "numbers != null");
                    $.$$.System.Diagnostics.Debug.Assert$2(numbers.length === 8/*NumberOfLabels*/, "numbers.Length == NumberOfLabels");
                    this._numbers = numbers;
                    this.PrivateScopeId = scopeid;
                }
                return this;
            }
            $ctor$2(/*byte[]*/ address)
            {
                this.$ctor$6(new ($.$$.System.ReadOnlySpan$$($.$$.System.Byte))().$ctor$4(address ?? $.$snp.System.Net.IPAddress.ThrowAddressNullException()));
                {
                }
                return this;
            }
            $ctor$6(/*ReadOnlySpan<byte>*/ address)
            {
                super.$ctor();
                {
                    if (address.Length === 4/*IPAddressParserStatics.IPv4AddressBytes*/)
                    {
                        this.PrivateAddress = $.$$.System.Runtime.InteropServices.MemoryMarshal.Read($.$$.System.UInt32, address);
                    }
                    else if (address.Length === 16/*IPAddressParserStatics.IPv6AddressBytes*/)
                    {
                        this._numbers = $.$snp.System.Net.IPAddress.ReadUInt16NumbersFromBytes(address);
                    }
                    else 
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$snp.System.SR.dns_bad_ip_address, "address");
                    }
                }
                return this;
            }
            static /*ushort[] */ ReadUInt16NumbersFromBytes(/*ReadOnlySpan<byte>*/ address)
            {
                /*ushort[]*/ let numbers = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.UInt16), null, [8/*NumberOfLabels*/], null);
                //if (Vector128.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                //else 
                {
                    for(/*int*/ let i = 0; i < numbers.length; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(numbers, $.$$.System.Buffers.Binary.BinaryPrimitives.ReadUInt16BigEndian(address.Slice$1(((i * 2) | 0))), i);
                    }
                }
                return numbers;
            }
            $ctor$3(/*int*/ newAddress)
            {
                super.$ctor();
                {
                    this.PrivateAddress = (newAddress >>> 0);
                }
                return this;
            }
            static /*bool */ IsValid(/*ReadOnlySpan<char>*/ ipSpan)
            {
                return $.$snp.System.Net.IPAddressParser.IsValid($.$$.System.Char, ipSpan);
            }
            static /*bool */ IsValidUtf8(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                return $.$snp.System.Net.IPAddressParser.IsValid($.$$.System.Byte, utf8Text);
            }
            static /*bool */ TryParse$2(/*string?*/ ipString, /*out IPAddress?*/ address)
            {
                if ($.$$.System.String.op_Equality(ipString, null))
                {
                    address.$v = null;
                    return false;
                }
                address.$v = $.$snp.System.Net.IPAddressParser.Parse($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(ipString), true);
                return (address.$v !== null);
            }
            static /*bool */ TryParse(/*ReadOnlySpan<byte>*/ utf8Text, /*out IPAddress?*/ result)
            {
                result.$v = $.$snp.System.Net.IPAddressParser.Parse($.$$.System.Byte, utf8Text, true);
                return (result.$v !== null);
            }
            static /*bool */ TryParse$1(/*ReadOnlySpan<char>*/ ipSpan, /*out IPAddress?*/ address)
            {
                address.$v = $.$snp.System.Net.IPAddressParser.Parse($.$$.System.Char, ipSpan, true);
                return (address.$v !== null);
            }
            static /*bool */ System$IUtf8SpanParsable$$$TryParse(/*ReadOnlySpan<byte>*/ utf8Text, /*IFormatProvider?*/ provider, /*out IPAddress?*/ result)
            {
                return $.$snp.System.Net.IPAddress.TryParse(utf8Text, result);
            }
            static /*bool */ System$IParsable$$$TryParse(/*string?*/ s, /*IFormatProvider?*/ provider, /*out IPAddress?*/ result)
            {
                return $.$snp.System.Net.IPAddress.TryParse$2(s, result);
            }
            static /*bool */ System$ISpanParsable$$$TryParse(/*ReadOnlySpan<char>*/ s, /*IFormatProvider?*/ provider, /*out IPAddress?*/ result)
            {
                return $.$snp.System.Net.IPAddress.TryParse$1(s, result);
            }
            static /*IPAddress */ Parse$2(/*string*/ ipString)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(ipString, "ipString");
                return $.$snp.System.Net.IPAddressParser.Parse($.$$.System.Char, $.$$.System.MemoryExtensions.AsSpan$4(ipString), false);
            }
            static /*IPAddress */ Parse(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                return $.$snp.System.Net.IPAddressParser.Parse($.$$.System.Byte, utf8Text, false);
            }
            static /*IPAddress */ Parse$1(/*ReadOnlySpan<char>*/ ipSpan)
            {
                return $.$snp.System.Net.IPAddressParser.Parse($.$$.System.Char, ipSpan, false);
            }
            static /*IPAddress */ System$IUtf8SpanParsable$$$Parse(/*ReadOnlySpan<byte>*/ utf8Text, /*IFormatProvider?*/ provider)
            {
                return $.$snp.System.Net.IPAddress.Parse(utf8Text);
            }
            static /*IPAddress */ System$ISpanParsable$$$Parse(/*ReadOnlySpan<char>*/ s, /*IFormatProvider?*/ provider)
            {
                return $.$snp.System.Net.IPAddress.Parse$1(s);
            }
            static /*IPAddress */ System$IParsable$$$Parse(/*string*/ s, /*IFormatProvider?*/ provider)
            {
                return $.$snp.System.Net.IPAddress.Parse$2(s);
            }
            /*bool */ TryWriteBytes(/*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                if (this.IsIPv6)
                {
                    if (destination.Length < 16/*IPAddressParserStatics.IPv6AddressBytes*/)
                    {
                        bytesWritten.$v = 0;
                        return false;
                    }
                    this.WriteIPv6Bytes(destination);
                    bytesWritten.$v = 16/*IPAddressParserStatics.IPv6AddressBytes*/;
                }
                else 
                {
                    if (destination.Length < 4/*IPAddressParserStatics.IPv4AddressBytes*/)
                    {
                        bytesWritten.$v = 0;
                        return false;
                    }
                    this.WriteIPv4Bytes(destination);
                    bytesWritten.$v = 4/*IPAddressParserStatics.IPv4AddressBytes*/;
                }
                return true;
            }
            /*void */ WriteIPv6Bytes(/*Span<byte>*/ destination)
            {
                /*ushort[]?*/ let numbers = this._numbers;
                $.$$.System.Diagnostics.Debug.Assert$2(numbers !== null && (numbers.length === 8/*NumberOfLabels*/), "numbers is { Length: NumberOfLabels }");
                if ($.$$.System.BitConverter.IsLittleEndian)
                {
                    //if (Vector128.IsHardwareAccelerated) { ... }
                    //else 
                    {
                        for(/*int*/ let i = 0; i < numbers.length; i++)
                        {
                            $.$$.System.Buffers.Binary.BinaryPrimitives.WriteUInt16BigEndian(destination.Slice$1(((i * 2) | 0)), $.$$.System.Array.$ReadT1.call(numbers, i));
                        }
                    }
                }
                else 
                {
                    $.$$.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$$.System.UInt16, $.$$.System.ReadOnlySpan$$($.$$.System.UInt16).op_Implicit$1(numbers)).CopyTo(destination);
                }
            }
            /*void */ WriteIPv4Bytes(/*Span<byte>*/ destination)
            {
                /*uint*/ let address = this.PrivateAddress;
                $.$$.System.Runtime.InteropServices.MemoryMarshal.Write($.$$.System.UInt32, destination, $.$ref(() => address, undefined, $.$$.System.UInt32));
            }
            /*byte[] */ GetAddressBytes()
            {
                if (this.IsIPv6)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._numbers !== null && (this._numbers.length === 8/*NumberOfLabels*/), "_numbers is { Length: NumberOfLabels }");
                    /*byte[]*/ let bytes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [16/*IPAddressParserStatics.IPv6AddressBytes*/], null);
                    this.WriteIPv6Bytes($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(bytes));
                    return bytes;
                }
                else 
                {
                    /*byte[]*/ let bytes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), null, [4/*IPAddressParserStatics.IPv4AddressBytes*/], null);
                    this.WriteIPv4Bytes($.$$.System.Span$$($.$$.System.Byte).op_Implicit$2(bytes));
                    return bytes;
                }
            }
            /*AddressFamily */ get AddressFamily()
            {
                return this.IsIPv4 ? 2/*AddressFamily.InterNetwork*/ : 23/*AddressFamily.InterNetworkV6*/;
            }
            /*long */ get ScopeId()
            {
                if (this.IsIPv4)
                {
                    $.$snp.System.Net.IPAddress.ThrowSocketOperationNotSupported();
                }
                return BigInt(this.PrivateScopeId);
            }
            /*long */ set ScopeId(value)
            {
                if (this.IsIPv4)
                {
                    $.$snp.System.Net.IPAddress.ThrowSocketOperationNotSupported();
                }
                if ($.$is(this, $.$snp.System.Net.IPAddress.ReadOnlyIPAddress))
                {
                    $.$snp.System.Net.IPAddress.ThrowSocketOperationNotSupported();
                }
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int64, value, "value");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int64, value, 4294967295n, "value");
                this.PrivateScopeId = $.$cast(value, $.$$.System.UInt32);
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*string?*/ let toString = this._toString;
                if (toString === null)
                {
                    /*Span<char>*/ let span = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 65/*IPAddressParser.MaxIPv6StringLength*/, null);
                    /*int*/ let length = this.IsIPv4 ? $.$snp.System.Net.IPAddressParser.FormatIPv4Address($.$$.System.Char, this._addressOrScopeId, span) : $.$snp.System.Net.IPAddressParser.FormatIPv6Address($.$$.System.Char, this._numbers, this._addressOrScopeId, span);
                    this._toString = toString = $.$$.System.String.Create$2($.$$.System.Span$$($.$$.System.Char).op_Implicit(span.Slice(0, length)));
                }
                return toString;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.IPAddress.ToString.apply(this, arguments); }
            /*string */ System$IFormattable$ToString(/*string?*/ format, /*IFormatProvider?*/ formatProvider)
            {
                return $.$snp.System.Net.IPAddress.ToString.call(this);
            }
            /*bool */ TryFormat$1(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                return this.TryFormatCore($.$$.System.Char, destination, charsWritten);
            }
            /*bool */ TryFormat(/*Span<byte>*/ utf8Destination, /*out int*/ bytesWritten)
            {
                return this.TryFormatCore($.$$.System.Byte, utf8Destination, bytesWritten);
            }
            /*bool */ System$ISpanFormattable$TryFormat(/*Span<char>*/ destination, /*out int*/ charsWritten, /*ReadOnlySpan<char>*/ format, /*IFormatProvider?*/ provider)
            {
                return this.TryFormatCore($.$$.System.Char, destination, charsWritten);
            }
            /*bool */ System$IUtf8SpanFormattable$TryFormat(/*Span<byte>*/ utf8Destination, /*out int*/ bytesWritten, /*ReadOnlySpan<char>*/ format, /*IFormatProvider?*/ provider)
            {
                return this.TryFormatCore($.$$.System.Byte, utf8Destination, bytesWritten);
            }
            /*bool */ TryFormatCore(TChar, /*Span<TChar>*/ destination, /*out int*/ charsWritten)
            {
                if (this.IsIPv4)
                {
                    if (destination.Length >= 15/*IPAddressParser.MaxIPv4StringLength*/)
                    {
                        charsWritten.$v = $.$snp.System.Net.IPAddressParser.FormatIPv4Address(TChar, this._addressOrScopeId, destination);
                        return true;
                    }
                }
                else 
                {
                    if (destination.Length >= 65/*IPAddressParser.MaxIPv6StringLength*/)
                    {
                        charsWritten.$v = $.$snp.System.Net.IPAddressParser.FormatIPv6Address(TChar, this._numbers, this._addressOrScopeId, destination);
                        return true;
                    }
                }
                /*Span<TChar>*/ let tmpDestination = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan(TChar, 65/*IPAddressParser.MaxIPv6StringLength*/, null);
                $.$$.System.Diagnostics.Debug.Assert$2(tmpDestination.Length >= 15/*IPAddressParser.MaxIPv4StringLength*/, "tmpDestination.Length >= IPAddressParser.MaxIPv4StringLength");
                /*int*/ let written = this.IsIPv4 ? $.$snp.System.Net.IPAddressParser.FormatIPv4Address(TChar, this.PrivateAddress, tmpDestination) : $.$snp.System.Net.IPAddressParser.FormatIPv6Address(TChar, this._numbers, this.PrivateScopeId, tmpDestination);
                if (tmpDestination.Slice(0, written).TryCopyTo(destination))
                {
                    charsWritten.$v = written;
                    return true;
                }
                charsWritten.$v = 0;
                return false;
            }
            static /*long */ HostToNetworkOrder$2(/*long*/ host)
            {
                return $.$$.System.BitConverter.IsLittleEndian ? $.$$.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$5(host) : host;
            }
            static /*int */ HostToNetworkOrder$1(/*int*/ host)
            {
                return $.$$.System.BitConverter.IsLittleEndian ? $.$$.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$4(host) : host;
            }
            static /*short */ HostToNetworkOrder(/*short*/ host)
            {
                return $.$$.System.BitConverter.IsLittleEndian ? $.$$.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$3(host) : host;
            }
            static /*long */ NetworkToHostOrder$2(/*long*/ network)
            {
                return $.$snp.System.Net.IPAddress.HostToNetworkOrder$2(network);
            }
            static /*int */ NetworkToHostOrder$1(/*int*/ network)
            {
                return $.$snp.System.Net.IPAddress.HostToNetworkOrder$1(network);
            }
            static /*short */ NetworkToHostOrder(/*short*/ network)
            {
                return $.$snp.System.Net.IPAddress.HostToNetworkOrder(network);
            }
            static /*bool */ IsLoopback(/*IPAddress*/ address)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(address, "address");
                if (address.IsIPv6)
                {
                    return address.Equals$2($.$snp.System.Net.IPAddress.IPv6Loopback) || address.Equals$2($.$snp.System.Net.IPAddress.s_loopbackMappedToIPv6);
                }
                else 
                {
                    /*long*/ let LoopbackMask = BigInt(($.$snp.System.Net.IPAddress.HostToNetworkOrder$1((4278190080/*LoopbackMaskHostOrder*/ | 0)) >>> 0));
                    return ((BigInt(address.PrivateAddress) & LoopbackMask) === (BigInt($.$snp.System.Net.IPAddress.Loopback.PrivateAddress) & LoopbackMask));
                }
            }
            /*bool */ get IsIPv6Multicast()
            {
                return this.IsIPv6 && (($.$$.System.Array.$ReadT1.call(this._numbers, 0) & 65280) === 65280);
            }
            /*bool */ get IsIPv6LinkLocal()
            {
                return this.IsIPv6 && (($.$$.System.Array.$ReadT1.call(this._numbers, 0) & 65472) === 65152);
            }
            /*bool */ get IsIPv6SiteLocal()
            {
                return this.IsIPv6 && (($.$$.System.Array.$ReadT1.call(this._numbers, 0) & 65472) === 65216);
            }
            /*bool */ get IsIPv6Teredo()
            {
                return this.IsIPv6 && ($.$$.System.Array.$ReadT1.call(this._numbers, 0) === 8193) && ($.$$.System.Array.$ReadT1.call(this._numbers, 1) === 0);
            }
            /*bool */ get IsIPv6UniqueLocal()
            {
                return this.IsIPv6 && (($.$$.System.Array.$ReadT1.call(this._numbers, 0) & 65024) === 64512);
            }
            /*bool */ get IsIPv4MappedToIPv6()
            {
                return !this.IsIPv4 && $.$$.System.MemoryExtensions.SequenceEqual$1($.$$.System.UInt16, $.$$.System.Span$$($.$$.System.UInt16).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.UInt16, this._numbers, 0, 6)), $.$$.System.ReadOnlySpan$$($.$$.System.UInt16).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$$.System.UInt16.$type, [ 0, 0, 0, 0, 0, 65535 ], null, null)));
            }
            /*long */ get Address()
            {
                if (this.AddressFamily === 23/*AddressFamily.InterNetworkV6*/)
                {
                    $.$snp.System.Net.IPAddress.ThrowSocketOperationNotSupported();
                }
                return BigInt(this.PrivateAddress);
            }
            /*long */ set Address(value)
            {
                if (this.AddressFamily === 23/*AddressFamily.InterNetworkV6*/)
                {
                    $.$snp.System.Net.IPAddress.ThrowSocketOperationNotSupported();
                }
                if (BigInt(this.PrivateAddress) !== value)
                {
                    if ($.$is(this, $.$snp.System.Net.IPAddress.ReadOnlyIPAddress))
                    {
                        $.$snp.System.Net.IPAddress.ThrowSocketOperationNotSupported();
                    }
                    this.PrivateAddress = $.$cast(value, $.$$.System.UInt32);
                }
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ comparand)
            {
                let address;
                return $.$is(comparand, $.$snp.System.Net.IPAddress, { set $v(v){ address = v; } }) && this.Equals$2(address);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$snp.System.Net.IPAddress.Equals$1.apply(this, arguments); }
            /*bool */ Equals$2(/*IPAddress*/ comparand)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(comparand !== null, "comparand != null");
                if (this.AddressFamily !== comparand.AddressFamily)
                {
                    return false;
                }
                if (this.IsIPv6)
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(this._numbers.length === 8/*IPAddressParserStatics.IPv6AddressShorts*/, "_numbers.Length == IPAddressParserStatics.IPv6AddressShorts");
                    $.$$.System.Diagnostics.Debug.Assert$2(comparand._numbers.length === 8/*IPAddressParserStatics.IPv6AddressShorts*/, "comparand._numbers!.Length == IPAddressParserStatics.IPv6AddressShorts");
                    /*ReadOnlySpan<ushort>*/ let left = $.$$.System.Span$$($.$$.System.UInt16).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.UInt16, this._numbers, 0, 8/*IPAddressParserStatics.IPv6AddressShorts*/));
                    /*ReadOnlySpan<ushort>*/ let right = $.$$.System.Span$$($.$$.System.UInt16).op_Implicit($.$$.System.MemoryExtensions.AsSpan$11($.$$.System.UInt16, comparand._numbers, 0, 8/*IPAddressParserStatics.IPv6AddressShorts*/));
                    return $.$$.System.MemoryExtensions.SequenceEqual$1($.$$.System.UInt16, left, right) && this.PrivateScopeId === comparand.PrivateScopeId;
                }
                return comparand.PrivateAddress === this.PrivateAddress;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                if (this._hashCode === 0)
                {
                    if (this.IsIPv6)
                    {
                        /*ReadOnlySpan<byte>*/ let numbers = $.$$.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$$.System.UInt16, $.$$.System.ReadOnlySpan$$($.$$.System.UInt16).op_Implicit$1(this._numbers));
                        this._hashCode = $.$$.System.HashCode.Combine$3($.$$.System.UInt32, $.$$.System.UInt32, $.$$.System.UInt32, $.$$.System.UInt32, $.$$.System.UInt32, $.$$.System.Runtime.InteropServices.MemoryMarshal.Read($.$$.System.UInt32, numbers), $.$$.System.Runtime.InteropServices.MemoryMarshal.Read($.$$.System.UInt32, numbers.Slice$1(4)), $.$$.System.Runtime.InteropServices.MemoryMarshal.Read($.$$.System.UInt32, numbers.Slice$1(8)), $.$$.System.Runtime.InteropServices.MemoryMarshal.Read($.$$.System.UInt32, numbers.Slice$1(12)), this._addressOrScopeId);
                    }
                    else 
                    {
                        this._hashCode = $.$$.System.HashCode.Combine$7($.$$.System.UInt32, this._addressOrScopeId);
                    }
                }
                return this._hashCode;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snp.System.Net.IPAddress.GetHashCode.apply(this, arguments); }
            /*IPAddress */ MapToIPv6()
            {
                if (this.IsIPv6)
                {
                    return this;
                }
                /*uint*/ let address = ($.$snp.System.Net.IPAddress.NetworkToHostOrder$1((this.PrivateAddress | 0)) >>> 0);
                /*ushort[]*/ let labels = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.UInt16), null, [8/*NumberOfLabels*/], null);
                $.$$.System.Array.$WriteT1.call(labels, 65535, 5);
                $.$$.System.Array.$WriteT1.call(labels, $.$cast((address >>> 16), $.$$.System.UInt16), 6);
                $.$$.System.Array.$WriteT1.call(labels, $.$cast(address, $.$$.System.UInt16), 7);
                return new $.$snp.System.Net.IPAddress().$ctor$8(labels, 0);
            }
            /*IPAddress */ MapToIPv4()
            {
                if (this.IsIPv4)
                {
                    return this;
                }
                /*uint*/ let address = ($.$$.System.Array.$ReadT1.call(this._numbers, 6) << 16) >>> 0 | $.$$.System.Array.$ReadT1.call(this._numbers, 7);
                return new $.$snp.System.Net.IPAddress().$ctor$4(BigInt(($.$snp.System.Net.IPAddress.HostToNetworkOrder$1((address | 0)) >>> 0)));
            }
            static /*byte[] */ ThrowAddressNullException()
            {
                throw new $.$$.System.ArgumentNullException().$ctor$19("address");
            }
            static /*void */ ThrowSocketOperationNotSupported()
            {
                throw new $.$snp.System.Net.Sockets.SocketException().$ctor$27(10045/*SocketError.OperationNotSupported*/);
            }
            static $_ReadOnlyIPAddress;
            static get ReadOnlyIPAddress()
            {
                let $cls = $.$snp.System.Net.IPAddress;
                return $cls.$_ReadOnlyIPAddress ??= $asm.$ncls("$snp.System.Net.IPAddress.ReadOnlyIPAddress", ($self) => class ReadOnlyIPAddress extends $.$snp.System.Net.IPAddress
                {
                    $ctor$10(/*ReadOnlySpan<byte>*/ newAddress)
                    {
                        super.$ctor$6(newAddress);
                        {
                        }
                        return this;
                    }
                    $ctor$9(/*ReadOnlySpan<byte>*/ address, /*long*/ scopeid)
                    {
                        super.$ctor$5(address, scopeid);
                        {
                        }
                        return this;
                    }
                    static $h = 3130101;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":3064565,"c":[{"p":[{"n":"newAddress","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$10","d":3130101,"h":4298097397,"f":16777217},{"p":[{"n":"address","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"scopeid","p":917505}],"n":".ctor","o":"$ctor$9","d":3130101,"h":8593064693,"f":16777217}],"i":[63832065,57737217,$.$$.System.ISpanParsable$$($.$snp.System.Net.IPAddress).$h,$.$$.System.IParsable$$($.$snp.System.Net.IPAddress).$h,64159745,$.$$.System.IUtf8SpanParsable$$($.$snp.System.Net.IPAddress).$h],"d":3064565,"h":3130101}; }
                    static get $b() { return $.$snp.System.Net.IPAddress; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.ISpanParsable$$($.$snp.System.Net.IPAddress), $.$$.System.IParsable$$($.$snp.System.Net.IPAddress), $.$$.System.IUtf8SpanFormattable, $.$$.System.IUtf8SpanParsable$$($.$snp.System.Net.IPAddress) ]; }
                    static get $fullName() { return `System.Net.IPAddress.ReadOnlyIPAddress`; }
                }, $cls, ($v) => $cls.$_ReadOnlyIPAddress = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Any = new $.$snp.System.Net.IPAddress.ReadOnlyIPAddress().$ctor$10($.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), [0, 0, 0, 0], null, null)));
                }
                {
                    this.Loopback = new $.$snp.System.Net.IPAddress.ReadOnlyIPAddress().$ctor$10($.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), [127, 0, 0, 1], null, null)));
                }
                {
                    this.Broadcast = new $.$snp.System.Net.IPAddress.ReadOnlyIPAddress().$ctor$10($.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), [255, 255, 255, 255], null, null)));
                }
                {
                    this.None = $.$snp.System.Net.IPAddress.Broadcast;
                }
                {
                    this.IPv6Any = new $.$snp.System.Net.IPAddress.ReadOnlyIPAddress().$ctor$9($.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], null, null)), 0n);
                }
                {
                    this.IPv6Loopback = new $.$snp.System.Net.IPAddress.ReadOnlyIPAddress().$ctor$9($.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1], null, null)), 0n);
                }
                {
                    this.IPv6None = $.$snp.System.Net.IPAddress.IPv6Any;
                }
                {
                    this.s_loopbackMappedToIPv6 = new $.$snp.System.Net.IPAddress.ReadOnlyIPAddress().$ctor$9($.$$.System.ReadOnlySpan$$($.$$.System.Byte).op_Implicit$1($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.Byte), [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 127, 0, 0, 1], null, null)), 0n);
                }
            }
            static $h = 3064565;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":68722541301,"f":50331650},"n":"IsIPv4","d":3064565,"h":64427574005,"f":2097154},{"p":262145,"g":{"r":0,"d":0,"h":77312475893,"f":50331650},"n":"IsIPv6","d":3064565,"h":73017508597,"f":2097154},{"p":720897,"g":{"r":0,"d":0,"h":85902410485,"f":50331656},"s":{"r":0,"d":0,"h":90197377781,"f":83886082},"n":"PrivateAddress","d":3064565,"h":81607443189,"f":2097160},{"p":720897,"g":{"r":0,"d":0,"h":98787312373,"f":50331656},"n":"PrivateIPv4Address","d":3064565,"h":94492345077,"f":2097160},{"p":720897,"g":{"r":0,"d":0,"h":107377246965,"f":50331650},"s":{"r":0,"d":0,"h":111672214261,"f":83886082},"n":"PrivateScopeId","d":3064565,"h":103082279669,"f":2097154},{"p":4506357,"g":{"r":0,"d":0,"h":236226265845,"f":50331649},"n":"AddressFamily","d":3064565,"h":231931298549,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":244816200437,"f":50331649},"s":{"r":0,"d":0,"h":249111167733,"f":83886081},"n":"ScopeId","d":3064565,"h":240521233141,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":317830644469,"f":50331649},"n":"IsIPv6Multicast","d":3064565,"h":313535677173,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":326420579061,"f":50331649},"n":"IsIPv6LinkLocal","d":3064565,"h":322125611765,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":335010513653,"f":50331649},"n":"IsIPv6SiteLocal","d":3064565,"h":330715546357,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":343600448245,"f":50331649},"n":"IsIPv6Teredo","d":3064565,"h":339305480949,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":352190382837,"f":50331649},"n":"IsIPv6UniqueLocal","d":3064565,"h":347895415541,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":360780317429,"f":50331649},"n":"IsIPv4MappedToIPv6","d":3064565,"h":356485350133,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":369370252021,"f":50331649},"s":{"r":0,"d":0,"h":373665219317,"f":83886081},"n":"Address","d":3064565,"h":365075284725,"f":2097153,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"IPAddress.Address is address family dependent and has been deprecated. Use IPAddress.Equals to perform comparisons instead.","t":1310721}]}]}],"m":[{"r":$.$typeArray($.$$.System.UInt16).$h,"p":[{"n":"address","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"ReadUInt16NumbersFromBytes","d":3064565,"h":146031952629,"f":16777250},{"r":262145,"p":[{"n":"ipSpan","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"IsValid","d":3064565,"h":154621887221,"f":16777249},{"r":262145,"p":[{"n":"utf8Text","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"IsValidUtf8","d":3064565,"h":158916854517,"f":16777249},{"r":262145,"p":[{"n":"ipString","p":1310721},{"n":"address","p":3064565,"f":2}],"n":"TryParse","o":"@$2","d":3064565,"h":163211821813,"f":16777249},{"r":262145,"p":[{"n":"utf8Text","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"result","p":3064565,"f":2}],"n":"TryParse","d":3064565,"h":167506789109,"f":16777249},{"r":262145,"p":[{"n":"ipSpan","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"address","p":3064565,"f":2}],"n":"TryParse","o":"@$1","d":3064565,"h":171801756405,"f":16777249},{"r":3064565,"p":[{"n":"ipString","p":1310721}],"n":"Parse","o":"@$2","d":3064565,"h":188981625589,"f":16777249},{"r":3064565,"p":[{"n":"utf8Text","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"Parse","d":3064565,"h":193276592885,"f":16777249},{"r":3064565,"p":[{"n":"ipSpan","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"Parse","o":"@$1","d":3064565,"h":197571560181,"f":16777249},{"r":262145,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryWriteBytes","d":3064565,"h":214751429365,"f":16777217},{"r":65537,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"WriteIPv6Bytes","d":3064565,"h":219046396661,"f":16777218},{"r":65537,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"WriteIPv4Bytes","d":3064565,"h":223341363957,"f":16777218},{"r":$.$typeArray($.$$.System.Byte).$h,"n":"GetAddressBytes","d":3064565,"h":227636331253,"f":16777217},{"r":1310721,"n":"ToString","d":3064565,"h":253406135029,"f":16809985},{"r":262145,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryFormat","o":"@$1","d":3064565,"h":261996069621,"f":16777217},{"r":262145,"p":[{"n":"utf8Destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryFormat","d":3064565,"h":266291036917,"f":16777217},{"r":262145,"p":[{"n":"destination","p":(TChar) => $.$$.System.Span$$(TChar).$h},{"n":"charsWritten","p":655361,"f":2}],"g":["TChar"],"n":"TryFormatCore","d":3064565,"h":279175938805,"f":16908290},{"r":917505,"p":[{"n":"host","p":917505}],"n":"HostToNetworkOrder","o":"@$2","d":3064565,"h":283470906101,"f":16777249},{"r":655361,"p":[{"n":"host","p":655361}],"n":"HostToNetworkOrder","o":"@$1","d":3064565,"h":287765873397,"f":16777249},{"r":524289,"p":[{"n":"host","p":524289}],"n":"HostToNetworkOrder","d":3064565,"h":292060840693,"f":16777249},{"r":917505,"p":[{"n":"network","p":917505}],"n":"NetworkToHostOrder","o":"@$2","d":3064565,"h":296355807989,"f":16777249},{"r":655361,"p":[{"n":"network","p":655361}],"n":"NetworkToHostOrder","o":"@$1","d":3064565,"h":300650775285,"f":16777249},{"r":524289,"p":[{"n":"network","p":524289}],"n":"NetworkToHostOrder","d":3064565,"h":304945742581,"f":16777249},{"r":262145,"p":[{"n":"address","p":3064565}],"n":"IsLoopback","d":3064565,"h":309240709877,"f":16777249},{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","o":"@$1","d":3064565,"h":377960186613,"f":16809985},{"r":262145,"p":[{"n":"comparand","p":3064565}],"n":"Equals","o":"@$2","d":3064565,"h":382255153909,"f":16777224},{"r":655361,"n":"GetHashCode","d":3064565,"h":386550121205,"f":16809985},{"r":3064565,"n":"MapToIPv6","d":3064565,"h":390845088501,"f":16777217},{"r":3064565,"n":"MapToIPv4","d":3064565,"h":395140055797,"f":16777217},{"r":$.$typeArray($.$$.System.Byte).$h,"n":"ThrowAddressNullException","d":3064565,"h":399435023093,"f":16777250},{"r":65537,"n":"ThrowSocketOperationNotSupported","d":3064565,"h":403729990389,"f":16777250}],"l":[{"t":3064565,"n":"Any","d":3064565,"h":4298031861,"f":4194337},{"t":3064565,"n":"Loopback","d":3064565,"h":8592999157,"f":4194337},{"t":3064565,"n":"Broadcast","d":3064565,"h":12887966453,"f":4194337},{"t":3064565,"n":"None","d":3064565,"h":17182933749,"f":4194337},{"t":720897,"n":"LoopbackMaskHostOrder","d":3064565,"h":21477901045,"f":4194344},{"t":3064565,"n":"IPv6Any","d":3064565,"h":25772868341,"f":4194337},{"t":3064565,"n":"IPv6Loopback","d":3064565,"h":30067835637,"f":4194337},{"t":3064565,"n":"IPv6None","d":3064565,"h":34362802933,"f":4194337},{"t":3064565,"n":"s_loopbackMappedToIPv6","d":3064565,"h":38657770229,"f":4194338},{"t":720897,"n":"_addressOrScopeId","d":3064565,"h":42952737525,"f":4194306},{"t":$.$typeArray($.$$.System.UInt16).$h,"n":"_numbers","d":3064565,"h":47247704821,"f":4194306},{"t":1310721,"n":"_toString","d":3064565,"h":51542672117,"f":4194306},{"t":655361,"n":"_hashCode","d":3064565,"h":55837639413,"f":4194306},{"t":655361,"n":"NumberOfLabels","d":3064565,"h":60132606709,"f":4194344}],"c":[{"p":[{"n":"newAddress","p":917505}],"n":".ctor","o":"$ctor$4","d":3064565,"h":115967181557,"f":16777217},{"p":[{"n":"address","p":$.$typeArray($.$$.System.Byte).$h},{"n":"scopeid","p":917505}],"n":".ctor","o":"$ctor$1","d":3064565,"h":120262148853,"f":16777217},{"p":[{"n":"address","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"scopeid","p":917505}],"n":".ctor","o":"$ctor$5","d":3064565,"h":124557116149,"f":16777217},{"p":[{"n":"numbers","p":$.$$.System.ReadOnlySpan$$($.$$.System.UInt16).$h},{"n":"scopeid","p":720897}],"n":".ctor","o":"$ctor$7","d":3064565,"h":128852083445,"f":16777224},{"p":[{"n":"numbers","p":$.$typeArray($.$$.System.UInt16).$h},{"n":"scopeid","p":720897}],"n":".ctor","o":"$ctor$8","d":3064565,"h":133147050741,"f":16777218},{"p":[{"n":"address","p":$.$typeArray($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$2","d":3064565,"h":137442018037,"f":16777217},{"p":[{"n":"address","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$6","d":3064565,"h":141736985333,"f":16777217},{"p":[{"n":"newAddress","p":655361}],"n":".ctor","o":"$ctor$3","d":3064565,"h":150326919925,"f":16777224}],"i":[63832065,57737217,$.$$.System.ISpanParsable$$($.$snp.System.Net.IPAddress).$h,$.$$.System.IParsable$$($.$snp.System.Net.IPAddress).$h,64159745,$.$$.System.IUtf8SpanParsable$$($.$snp.System.Net.IPAddress).$h],"j":[3130101],"h":3064565}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.ISpanParsable$$($.$snp.System.Net.IPAddress), $.$$.System.IParsable$$($.$snp.System.Net.IPAddress), $.$$.System.IUtf8SpanFormattable, $.$$.System.IUtf8SpanParsable$$($.$snp.System.Net.IPAddress) ]; }
            static get $fullName() { return `System.Net.IPAddress`; }
        });
        
        $asm.$cls("$snp.System.Net.IPEndPoint", ($self) => class IPEndPoint extends $.$snp.System.Net.EndPoint
        {
            /*int*/ static MinPort = 0;
            /*int*/ static MaxPort = 65535;
            /*IPAddress*/ _address = null;
            /*int*/ _port = 0;
            /*AddressFamily */ get AddressFamily()
            {
                return this._address.AddressFamily;
            }
            $ctor$2(/*long*/ address, /*int*/ port)
            {
                super.$ctor$1();
                {
                    if (!$.$snp.System.Net.TcpValidationHelpers.ValidatePortNumber(port))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("port");
                    }
                    this._port = port;
                    this._address = new $.$snp.System.Net.IPAddress().$ctor$4(address);
                }
                return this;
            }
            $ctor$3(/*IPAddress*/ address, /*int*/ port)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(address, "address");
                    if (!$.$snp.System.Net.TcpValidationHelpers.ValidatePortNumber(port))
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("port");
                    }
                    this._port = port;
                    this._address = address;
                }
                return this;
            }
            /*IPAddress */ get Address()
            {
                return this._address;
            }
            /*IPAddress */ set Address(value)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(value, "value");
                this._address = value;
            }
            /*int */ get Port()
            {
                return this._port;
            }
            /*int */ set Port(value)
            {
                if (!$.$snp.System.Net.TcpValidationHelpers.ValidatePortNumber(value))
                {
                    throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("value");
                }
                this._port = value;
            }
            static /*bool */ TryParse$1(/*string*/ s, /*out IPEndPoint?*/ result)
            {
                return $.$snp.System.Net.IPEndPoint.TryParse($.$$.System.MemoryExtensions.AsSpan$4(s), result);
            }
            static /*bool */ TryParse(/*ReadOnlySpan<char>*/ s, /*out IPEndPoint?*/ result)
            {
                /*int*/ let addressLength = s.Length;
                /*int*/ let lastColonPos = $.$$.System.MemoryExtensions.LastIndexOf$4($.$$.System.Char, s, /*:*/ 58);
                if (lastColonPos > 0)
                {
                    if (s.get_Item(((lastColonPos - 1) | 0)).$v === /*]*/ 93)
                    {
                        addressLength = lastColonPos;
                    }
                    else if ($.$$.System.MemoryExtensions.LastIndexOf$4($.$$.System.Char, s.Slice(0, lastColonPos), /*:*/ 58) === -1)
                    {
                        addressLength = lastColonPos;
                    }
                }
                /*IPAddress?*/ let address;
                if ($.$snp.System.Net.IPAddress.TryParse$1(s.Slice(0, addressLength), $.$ref(() => address, ($v) => address = $v, $.$snp.System.Net.IPAddress)))
                {
                    /*uint*/ let port = 0;
                    if (addressLength === s.Length || ($.$$.System.UInt32.TryParse$3(s.Slice$1(((addressLength + 1) | 0)), 0/*NumberStyles.None*/, $.$$.System.Globalization.CultureInfo.InvariantCulture, $.$ref(() => port, ($v) => port = $v, $.$$.System.UInt32)) && port <= 65535/*MaxPort*/))
                    {
                        result.$v = new $.$snp.System.Net.IPEndPoint().$ctor$3(address, (port | 0));
                        return true;
                    }
                }
                result.$v = null;
                return false;
            }
            static /*IPEndPoint */ Parse$1(/*string*/ s)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(s, "s");
                return $.$snp.System.Net.IPEndPoint.Parse($.$$.System.MemoryExtensions.AsSpan$4(s));
            }
            static /*IPEndPoint */ Parse(/*ReadOnlySpan<char>*/ s)
            {
                /*IPEndPoint?*/ let result;
                if ($.$snp.System.Net.IPEndPoint.TryParse(s, $.$ref(() => result, ($v) => result = $v, $.$snp.System.Net.IPEndPoint)))
                {
                    return result;
                }
                throw new $.$$.System.FormatException().$ctor$12($.$snp.System.SR.bad_endpoint_string);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this._address.AddressFamily === 23/*AddressFamily.InterNetworkV6*/ ? $.$$.System.String.Create$6($.$$.System.Globalization.NumberFormatInfo.InvariantInfo, `[${$.$snp.System.Net.IPAddress.ToString.call(this._address)}]:${this._port}`) : $.$$.System.String.Create$6($.$$.System.Globalization.NumberFormatInfo.InvariantInfo, `${$.$snp.System.Net.IPAddress.ToString.call(this._address)}:${this._port}`);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.IPEndPoint.ToString.apply(this, arguments); }
            /*SocketAddress */ Serialize()
            {
                return new $.$snp.System.Net.SocketAddress().$ctor$1(this.Address, this.Port);
            }
            /*EndPoint */ Create(/*SocketAddress*/ socketAddress)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(socketAddress, "socketAddress");
                if (!((socketAddress.Family === 2/*AddressFamily.InterNetwork*/) || (socketAddress.Family === 23/*AddressFamily.InterNetworkV6*/)))
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$snp.System.SR.Format$5($.$snp.System.SR.net_InvalidAddressFamily, $.$$.System.Enum.ToStringT($.$snp.System.Net.Sockets.AddressFamily, $.$$.System.UInt32, socketAddress.Family), $.$$.System.Object.GetType.call(this).FullName), "socketAddress");
                }
                /*int*/ let minSize = this.AddressFamily === 23/*AddressFamily.InterNetworkV6*/ ? $.$snp.System.Net.SocketAddress.IPv6AddressSize : $.$snp.System.Net.SocketAddress.IPv4AddressSize;
                if (socketAddress.Size < minSize)
                {
                    throw new $.$$.System.ArgumentException().$ctor$13($.$snp.System.SR.Format$5($.$snp.System.SR.net_InvalidSocketAddressSize, $.$$.System.Object.GetType.call(socketAddress).FullName, $.$$.System.Object.GetType.call(this).FullName), "socketAddress");
                }
                return $.$snp.System.Net.Sockets.SocketAddressExtensions.GetIPEndPoint(socketAddress);
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ comparand)
            {
                let other;
                return $.$is(comparand, $.$snp.System.Net.IPEndPoint, { set $v(v){ other = v; } }) && other._address.Equals$2(this._address) && other._port === this._port;
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$snp.System.Net.IPEndPoint.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$snp.System.Net.IPAddress.GetHashCode.call(this._address) ^ this._port;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snp.System.Net.IPEndPoint.GetHashCode.apply(this, arguments); }
            static $h = 3326709;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2605813,"p":[{"p":4506357,"g":{"r":0,"d":0,"h":25773130485,"f":50364417},"n":"AddressFamily","d":3326709,"h":21478163189,"f":2129921},{"p":3064565,"g":{"r":0,"d":0,"h":42952999669,"f":50331649},"s":{"r":0,"d":0,"h":47247966965,"f":83886081},"n":"Address","d":3326709,"h":38658032373,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":55837901557,"f":50331649},"s":{"r":0,"d":0,"h":60132868853,"f":83886081},"n":"Port","d":3326709,"h":51542934261,"f":2097153}],"m":[{"r":262145,"p":[{"n":"s","p":1310721},{"n":"result","p":3326709,"f":2}],"n":"TryParse","o":"@$1","d":3326709,"h":64427836149,"f":16777249},{"r":262145,"p":[{"n":"s","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"result","p":3326709,"f":2}],"n":"TryParse","d":3326709,"h":68722803445,"f":16777249},{"r":3326709,"p":[{"n":"s","p":1310721}],"n":"Parse","o":"@$1","d":3326709,"h":73017770741,"f":16777249},{"r":3326709,"p":[{"n":"s","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"Parse","d":3326709,"h":77312738037,"f":16777249},{"r":1310721,"n":"ToString","d":3326709,"h":81607705333,"f":16809985},{"r":4375285,"n":"Serialize","d":3326709,"h":85902672629,"f":16809985},{"r":2605813,"p":[{"n":"socketAddress","p":4375285}],"n":"Create","d":3326709,"h":90197639925,"f":16809985},{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","o":"@$1","d":3326709,"h":94492607221,"f":16809985},{"r":655361,"n":"GetHashCode","d":3326709,"h":98787574517,"f":16809985}],"l":[{"t":655361,"n":"MinPort","d":3326709,"h":4298294005,"f":4194337},{"t":655361,"n":"MaxPort","d":3326709,"h":8593261301,"f":4194337},{"t":3064565,"n":"_address","d":3326709,"h":12888228597,"f":4194306},{"t":655361,"n":"_port","d":3326709,"h":17183195893,"f":4194306}],"c":[{"p":[{"n":"address","p":917505},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$2","d":3326709,"h":30068097781,"f":16777217},{"p":[{"n":"address","p":3064565},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$3","d":3326709,"h":34363065077,"f":16777217}],"h":3326709}; }
            static get $b() { return $.$snp.System.Net.EndPoint; }
            static get $fullName() { return `System.Net.IPEndPoint`; }
        });
        
        $asm.$str("$snp.System.Net.CookieTokenizer", ($self) => class CookieTokenizer extends $.$$.System.ValueType
        {
            /*bool*/  get _eofCookie() { return this.$getField(0, 1); }
            /*bool*/  set _eofCookie(value) { this.$setField(0, 1, value); }
            /*int*/  get _index() { return this.$getField(1, 4); }
            /*int*/  set _index(value) { this.$setField(1, 4, value); }
            /*int*/  get _length() { return this.$getField(5, 4); }
            /*int*/  set _length(value) { this.$setField(5, 4, value); }
            /*string?*/  get _name() { return this.$getField(9, 4); }
            /*string?*/  set _name(value) { this.$setField(9, 4, value); }
            /*bool*/  get _quoted() { return this.$getField(13, 1); }
            /*bool*/  set _quoted(value) { this.$setField(13, 1, value); }
            /*int*/  get _start() { return this.$getField(14, 4); }
            /*int*/  set _start(value) { this.$setField(14, 4, value); }
            /*CookieToken*/  get _token() { return this.$getField(18, 4); }
            /*CookieToken*/  set _token(value) { this.$setField(18, 4, value); }
            /*int*/  get _tokenLength() { return this.$getField(22, 4); }
            /*int*/  set _tokenLength(value) { this.$setField(22, 4, value); }
            /*string*/  get _tokenStream() { return this.$getField(26, 4); }
            /*string*/  set _tokenStream(value) { this.$setField(26, 4, value); }
            /*string*/  get _value() { return this.$getField(30, 4); }
            /*string*/  set _value(value) { this.$setField(30, 4, value); }
            /*int*/  get _cookieStartIndex() { return this.$getField(34, 4); }
            /*int*/  set _cookieStartIndex(value) { this.$setField(34, 4, value); }
            /*int*/  get _cookieLength() { return this.$getField(38, 4); }
            /*int*/  set _cookieLength(value) { this.$setField(38, 4, value); }
            $ctor$3(/*string*/ tokenStream)
            {
                this.$ctor$2();
                {
                    this._length = tokenStream.length;
                    this._tokenStream = tokenStream;
                    this._value = $.$$.System.String.Empty;
                }
                return this;
            }
            /*bool */ get EndOfCookie()
            {
                return this._eofCookie;
            }
            /*bool */ set EndOfCookie(value)
            {
                this._eofCookie = value;
            }
            /*bool */ get Eof()
            {
                return this._index >= this._length;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
            }
            /*bool */ get Quoted()
            {
                return this._quoted;
            }
            /*bool */ set Quoted(value)
            {
                this._quoted = value;
            }
            /*CookieToken */ get Token()
            {
                return this._token;
            }
            /*CookieToken */ set Token(value)
            {
                this._token = value;
            }
            /*string */ get Value()
            {
                return this._value;
            }
            /*string */ set Value(value)
            {
                this._value = value;
            }
            /*string */ Extract()
            {
                /*string*/ let tokenString = $.$$.System.String.Empty;
                if (this._tokenLength !== 0)
                {
                    tokenString = this.Quoted ? $.$$.System.String.Substring.call(this._tokenStream, this._start, this._tokenLength) : $.$$.System.ReadOnlySpan$$($.$$.System.Char).ToString.call($.$$.System.MemoryExtensions.Trim$4($.$$.System.MemoryExtensions.AsSpan$1(this._tokenStream, this._start, this._tokenLength)));
                }
                return tokenString;
            }
            /*CookieToken */ FindNext(/*bool*/ ignoreComma, /*bool*/ ignoreEquals)
            {
                this._tokenLength = 0;
                this._start = this._index;
                while((this._index < this._length) && $.$$.System.Char.IsWhiteSpace($.$$.System.String.get_Chars.call(this._tokenStream, this._index)))
                {
                    ++this._index;
                    ++this._start;
                }
                /*CookieToken*/ let token = 5/*CookieToken.End*/;
                /*int*/ let increment = 1;
                if (!this.Eof)
                {
                    if ($.$$.System.String.get_Chars.call(this._tokenStream, this._index) === /*\"*/ 34)
                    {
                        this.Quoted = true;
                        ++this._index;
                        /*bool*/ let quoteOn = false;
                        while(this._index < this._length)
                        {
                            /*char*/ let currChar = $.$$.System.String.get_Chars.call(this._tokenStream, this._index);
                            if (!quoteOn && currChar === /*\"*/ 34)
                            {
                                break;
                            }
                            if (quoteOn)
                            {
                                quoteOn = false;
                            }
                            else if (currChar === /*\\*/ 92)
                            {
                                quoteOn = true;
                            }
                            ++this._index;
                        }
                        if (this._index < this._length)
                        {
                            ++this._index;
                        }
                        this._tokenLength = ((this._index - this._start) | 0);
                        increment = 0;
                        ignoreComma = false;
                    }
                    while((this._index < this._length) && ($.$$.System.String.get_Chars.call(this._tokenStream, this._index) !== /*;*/ 59) && (ignoreEquals || ($.$$.System.String.get_Chars.call(this._tokenStream, this._index) !== /*=*/ 61)) && (ignoreComma || ($.$$.System.String.get_Chars.call(this._tokenStream, this._index) !== /*,*/ 44)))
                    {
                        if ($.$$.System.String.get_Chars.call(this._tokenStream, this._index) === /*,*/ 44)
                        {
                            this._start = ((this._index + 1) | 0);
                            this._tokenLength = -1;
                            ignoreComma = false;
                        }
                        ++this._index;
                        this._tokenLength += increment;
                    }
                    if (!this.Eof)
                    {
                        let $switch1 = $.$$.System.String.get_Chars.call(this._tokenStream, this._index);
                        switch($switch1)
                        {
                            case /*;*/ 59:
                            token = 3/*CookieToken.EndToken*/;
                            break;
                            case /*=*/ 61:
                            token = 6/*CookieToken.Equals*/;
                            break;
                            default:
                            this._cookieLength = ((this._index - this._cookieStartIndex) | 0);
                            token = 4/*CookieToken.EndCookie*/;
                            break;
                        }
                        ++this._index;
                    }
                    if (this.Eof)
                    {
                        this._cookieLength = ((this._index - this._cookieStartIndex) | 0);
                    }
                }
                return token;
            }
            /*CookieToken */ Next(/*bool*/ first, /*bool*/ parseResponseCookies)
            {
                this.Reset();
                if (first)
                {
                    this._cookieStartIndex = this._index;
                    this._cookieLength = 0;
                }
                /*CookieToken*/ let terminator = this.FindNext(false, false);
                if (terminator === 4/*CookieToken.EndCookie*/)
                {
                    this.EndOfCookie = true;
                }
                if ((terminator === 5/*CookieToken.End*/) || (terminator === 4/*CookieToken.EndCookie*/))
                {
                    if ((this.Name = this.Extract()).length !== 0)
                    {
                        this.Token = this.TokenFromName(parseResponseCookies);
                        return 2/*CookieToken.Attribute*/;
                    }
                    return terminator;
                }
                this.Name = this.Extract();
                if (first)
                {
                    this.Token = 9/*CookieToken.CookieName*/;
                }
                else 
                {
                    this.Token = this.TokenFromName(parseResponseCookies);
                }
                if (terminator === 6/*CookieToken.Equals*/)
                {
                    terminator = this.FindNext(!first && (this.Token === 12/*CookieToken.Expires*/), true);
                    if (terminator === 4/*CookieToken.EndCookie*/)
                    {
                        this.EndOfCookie = true;
                    }
                    this.Value = this.Extract();
                    return 1/*CookieToken.NameValuePair*/;
                }
                else 
                {
                    return 2/*CookieToken.Attribute*/;
                }
            }
            /*void */ Reset()
            {
                this._eofCookie = false;
                this._name = $.$$.System.String.Empty;
                this._quoted = false;
                this._start = this._index;
                this._token = 0/*CookieToken.Nothing*/;
                this._tokenLength = 0;
                this._value = $.$$.System.String.Empty;
            }
            static $_RecognizedAttribute;
            static get RecognizedAttribute()
            {
                let $cls = $.$snp.System.Net.CookieTokenizer;
                return $cls.$_RecognizedAttribute ??= $asm.$nstr("$snp.System.Net.CookieTokenizer.RecognizedAttribute", ($self) => class RecognizedAttribute extends $.$$.System.ValueType
                {
                    /*string*/  get _name() { return this.$getField(0, 4); }
                    /*string*/  set _name(value) { this.$setField(0, 4, value); }
                    /*CookieToken*/  get _token() { return this.$getField(4, 4); }
                    /*CookieToken*/  set _token(value) { this.$setField(4, 4, value); }
                    $ctor$3(/*string*/ name, /*CookieToken*/ token)
                    {
                        super.$ctor$1();
                        {
                            this._name = name;
                            this._token = token;
                        }
                        return this;
                    }
                    /*CookieToken */ get Token()
                    {
                        return this._token;
                    }
                    /*bool */ IsEqualTo(/*string?*/ value)
                    {
                        return $.$$.System.String.Equals$2(this._name, value, 5/*StringComparison.OrdinalIgnoreCase*/);
                    }
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._name = this._name;
                        copy._token = this._token;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._name = null;
                        this._token = 0;
                    }
                    static $h = 1819381;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1688309,"g":{"r":0,"d":0,"h":21476655861,"f":50331656},"n":"Token","d":1819381,"h":17181688565,"f":2097160}],"m":[{"r":262145,"p":[{"n":"value","p":1310721}],"n":"IsEqualTo","d":1819381,"h":25771623157,"f":16777224}],"l":[{"t":1310721,"n":"_name","d":1819381,"h":4296786677,"f":4194306},{"t":1688309,"n":"_token","d":1819381,"h":8591753973,"f":4194306}],"c":[{"p":[{"n":"name","p":1310721},{"n":"token","p":1688309}],"n":".ctor","o":"$ctor$3","d":1819381,"h":12886721269,"f":16777224},{"n":".ctor","o":"$ctor$2","d":1819381,"h":30066590453,"f":16777217}],"d":1753845,"h":1819381}; }
                    static get $b() { return $.$$.System.ValueType; }
                    static get $fullName() { return `System.Net.CookieTokenizer.RecognizedAttribute`; }
                }, $cls, ($v) => $cls.$_RecognizedAttribute = $v);
            }
            /*RecognizedAttribute[]*/ static s_recognizedAttributes = null;
            /*RecognizedAttribute[]*/ static s_recognizedServerAttributes = null;
            /*CookieToken */ TokenFromName(/*bool*/ parseResponseCookies)
            {
                if (!parseResponseCookies)
                {
                    for(/*int*/ let i = 0; i < $.$snp.System.Net.CookieTokenizer.s_recognizedServerAttributes.length; ++i)
                    {
                        if ($.$$.System.Array.$ReadT1.call($.$snp.System.Net.CookieTokenizer.s_recognizedServerAttributes, i).IsEqualTo(this.Name))
                        {
                            return $.$$.System.Array.$ReadT1.call($.$snp.System.Net.CookieTokenizer.s_recognizedServerAttributes, i).Token;
                        }
                    }
                }
                else 
                {
                    for(/*int*/ let i = 0; i < $.$snp.System.Net.CookieTokenizer.s_recognizedAttributes.length; ++i)
                    {
                        if ($.$$.System.Array.$ReadT1.call($.$snp.System.Net.CookieTokenizer.s_recognizedAttributes, i).IsEqualTo(this.Name))
                        {
                            return $.$$.System.Array.$ReadT1.call($.$snp.System.Net.CookieTokenizer.s_recognizedAttributes, i).Token;
                        }
                    }
                }
                return 18/*CookieToken.Unknown*/;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._eofCookie = this._eofCookie;
                copy._index = this._index;
                copy._length = this._length;
                copy._name = this._name;
                copy._quoted = this._quoted;
                copy._start = this._start;
                copy._token = this._token;
                copy._tokenLength = this._tokenLength;
                copy._tokenStream = this._tokenStream;
                copy._value = this._value;
                copy._cookieStartIndex = this._cookieStartIndex;
                copy._cookieLength = this._cookieLength;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._eofCookie = false;
                this._index = 0;
                this._length = 0;
                this._name = null;
                this._quoted = false;
                this._start = 0;
                this._token = 0;
                this._tokenLength = 0;
                this._tokenStream = null;
                this._value = null;
                this._cookieStartIndex = 0;
                this._cookieLength = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_recognizedAttributes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$snp.System.Net.CookieTokenizer.RecognizedAttribute), [new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$3("Path"/*CookieFields.PathAttributeName*/, 14/*CookieToken.Path*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$3("Max-Age"/*CookieFields.MaxAgeAttributeName*/, 13/*CookieToken.MaxAge*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$3("Expires"/*CookieFields.ExpiresAttributeName*/, 12/*CookieToken.Expires*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$3("Version"/*CookieFields.VersionAttributeName*/, 19/*CookieToken.Version*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$3("Domain"/*CookieFields.DomainAttributeName*/, 11/*CookieToken.Domain*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$3("Secure"/*CookieFields.SecureAttributeName*/, 16/*CookieToken.Secure*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$3("Discard"/*CookieFields.DiscardAttributeName*/, 10/*CookieToken.Discard*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$3("Port"/*CookieFields.PortAttributeName*/, 15/*CookieToken.Port*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$3("Comment"/*CookieFields.CommentAttributeName*/, 7/*CookieToken.Comment*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$3("CommentURL"/*CookieFields.CommentUrlAttributeName*/, 8/*CookieToken.CommentUrl*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$3("HttpOnly"/*CookieFields.HttpOnlyAttributeName*/, 17/*CookieToken.HttpOnly*/)], null, null);
                }
                {
                    this.s_recognizedServerAttributes = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$snp.System.Net.CookieTokenizer.RecognizedAttribute), [new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$3(/*$*/ 36 + "Path"/*CookieFields.PathAttributeName*/, 14/*CookieToken.Path*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$3(/*$*/ 36 + "Version"/*CookieFields.VersionAttributeName*/, 19/*CookieToken.Version*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$3(/*$*/ 36 + "Domain"/*CookieFields.DomainAttributeName*/, 11/*CookieToken.Domain*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$3(/*$*/ 36 + "Port"/*CookieFields.PortAttributeName*/, 15/*CookieToken.Port*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$3(/*$*/ 36 + "HttpOnly"/*CookieFields.HttpOnlyAttributeName*/, 17/*CookieToken.HttpOnly*/)], null, null);
                }
            }
            static $h = 1753845;
            static $z = 42;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":64426263285,"f":50331656},"s":{"r":0,"d":0,"h":68721230581,"f":83886088},"n":"EndOfCookie","d":1753845,"h":60131295989,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":77311165173,"f":50331656},"n":"Eof","d":1753845,"h":73016197877,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":85901099765,"f":50331656},"s":{"r":0,"d":0,"h":90196067061,"f":83886088},"n":"Name","d":1753845,"h":81606132469,"f":2097160},{"p":262145,"g":{"r":0,"d":0,"h":98786001653,"f":50331656},"s":{"r":0,"d":0,"h":103080968949,"f":83886088},"n":"Quoted","d":1753845,"h":94491034357,"f":2097160},{"p":1688309,"g":{"r":0,"d":0,"h":111670903541,"f":50331656},"s":{"r":0,"d":0,"h":115965870837,"f":83886088},"n":"Token","d":1753845,"h":107375936245,"f":2097160},{"p":1310721,"g":{"r":0,"d":0,"h":124555805429,"f":50331656},"s":{"r":0,"d":0,"h":128850772725,"f":83886088},"n":"Value","d":1753845,"h":120260838133,"f":2097160}],"m":[{"r":1310721,"n":"Extract","d":1753845,"h":133145740021,"f":16777224},{"r":1688309,"p":[{"n":"ignoreComma","p":262145},{"n":"ignoreEquals","p":262145}],"n":"FindNext","d":1753845,"h":137440707317,"f":16777224},{"r":1688309,"p":[{"n":"first","p":262145},{"n":"parseResponseCookies","p":262145}],"n":"Next","d":1753845,"h":141735674613,"f":16777224},{"r":65537,"n":"Reset","d":1753845,"h":146030641909,"f":16777224},{"r":1688309,"p":[{"n":"parseResponseCookies","p":262145}],"n":"TokenFromName","d":1753845,"h":163210511093,"f":16777224}],"l":[{"t":262145,"n":"_eofCookie","d":1753845,"h":4296721141,"f":4194306},{"t":655361,"n":"_index","d":1753845,"h":8591688437,"f":4194306},{"t":655361,"n":"_length","d":1753845,"h":12886655733,"f":4194306},{"t":1310721,"n":"_name","d":1753845,"h":17181623029,"f":4194306},{"t":262145,"n":"_quoted","d":1753845,"h":21476590325,"f":4194306},{"t":655361,"n":"_start","d":1753845,"h":25771557621,"f":4194306},{"t":1688309,"n":"_token","d":1753845,"h":30066524917,"f":4194306},{"t":655361,"n":"_tokenLength","d":1753845,"h":34361492213,"f":4194306},{"t":1310721,"n":"_tokenStream","d":1753845,"h":38656459509,"f":4194306},{"t":1310721,"n":"_value","d":1753845,"h":42951426805,"f":4194306},{"t":655361,"n":"_cookieStartIndex","d":1753845,"h":47246394101,"f":4194306},{"t":655361,"n":"_cookieLength","d":1753845,"h":51541361397,"f":4194306},{"t":$.$typeArray($.$snp.System.Net.CookieTokenizer.RecognizedAttribute).$h,"n":"s_recognizedAttributes","d":1753845,"h":154620576501,"f":4194338},{"t":$.$typeArray($.$snp.System.Net.CookieTokenizer.RecognizedAttribute).$h,"n":"s_recognizedServerAttributes","d":1753845,"h":158915543797,"f":4194338}],"c":[{"p":[{"n":"tokenStream","p":1310721}],"n":".ctor","o":"$ctor$3","d":1753845,"h":55836328693,"f":16777224},{"n":".ctor","o":"$ctor$2","d":1753845,"h":167505478389,"f":16777217}],"j":[1819381],"h":1753845}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Net.CookieTokenizer`; }
        });
        
        $asm.$cls("$snp.System.Net.DnsEndPoint", ($self) => class DnsEndPoint extends $.$snp.System.Net.EndPoint
        {
            /*string*/ _host = null;
            /*int*/ _port = 0;
            /*AddressFamily*/ _family = 0;
            $ctor$3(/*string*/ host, /*int*/ port)
            {
                this.$ctor$2(host, port, 0/*AddressFamily.Unspecified*/);
                {
                }
                return this;
            }
            $ctor$2(/*string*/ host, /*int*/ port, /*AddressFamily*/ addressFamily)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentException.ThrowIfNullOrEmpty(host, "host");
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$$.System.Int32, port, 0/*IPEndPoint.MinPort*/, "port");
                    $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$$.System.Int32, port, 65535/*IPEndPoint.MaxPort*/, "port");
                    if (addressFamily !== 2/*AddressFamily.InterNetwork*/ && addressFamily !== 23/*AddressFamily.InterNetworkV6*/ && addressFamily !== 0/*AddressFamily.Unspecified*/)
                    {
                        throw new $.$$.System.ArgumentException().$ctor$13($.$snp.System.SR.net_sockets_invalid_optionValue_all, "addressFamily");
                    }
                    this._host = host;
                    this._port = port;
                    this._family = addressFamily;
                }
                return this;
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ comparand)
            {
                let dnsComparand;
                return $.$is(comparand, $.$snp.System.Net.DnsEndPoint, { set $v(v){ dnsComparand = v; } }) && this._family === dnsComparand._family && this._port === dnsComparand._port && $.$$.System.StringComparer.OrdinalIgnoreCase.Equals$3(this._host, dnsComparand._host);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$snp.System.Net.DnsEndPoint.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.HashCode.Combine$5($.$$.System.Int32, $.$$.System.Int32, $.$$.System.Int32, this._family, this._port, $.$$.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(this._host));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snp.System.Net.DnsEndPoint.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return `${this._family}/${this._host}:${this._port}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.DnsEndPoint.ToString.apply(this, arguments); }
            /*string */ get Host()
            {
                return this._host;
            }
            /*AddressFamily */ get AddressFamily()
            {
                return this._family;
            }
            /*int */ get Port()
            {
                return this._port;
            }
            static $h = 2540277;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2605813,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":42952213237,"f":50331649},"n":"Host","d":2540277,"h":38657245941,"f":2097153},{"p":4506357,"g":{"r":0,"d":0,"h":51542147829,"f":50364417},"n":"AddressFamily","d":2540277,"h":47247180533,"f":2129921},{"p":655361,"g":{"r":0,"d":0,"h":60132082421,"f":50331649},"n":"Port","d":2540277,"h":55837115125,"f":2097153}],"m":[{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","o":"@$1","d":2540277,"h":25772344053,"f":16809985},{"r":655361,"n":"GetHashCode","d":2540277,"h":30067311349,"f":16809985},{"r":1310721,"n":"ToString","d":2540277,"h":34362278645,"f":16809985}],"l":[{"t":1310721,"n":"_host","d":2540277,"h":4297507573,"f":4194306},{"t":655361,"n":"_port","d":2540277,"h":8592474869,"f":4194306},{"t":4506357,"n":"_family","d":2540277,"h":12887442165,"f":4194306}],"c":[{"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$3","d":2540277,"h":17182409461,"f":16777217},{"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"addressFamily","p":4506357}],"n":".ctor","o":"$ctor$2","d":2540277,"h":21477376757,"f":16777217}],"h":2540277}; }
            static get $b() { return $.$snp.System.Net.EndPoint; }
            static get $fullName() { return `System.Net.DnsEndPoint`; }
        });
        
        $asm.$str("$snp.System.Net.HeaderVariantInfo", ($self) => class HeaderVariantInfo extends $.$$.System.ValueType
        {
            /*string*/  get _name() { return this.$getField(0, 4); }
            /*string*/  set _name(value) { this.$setField(0, 4, value); }
            /*CookieVariant*/  get _variant() { return this.$getField(4, 4); }
            /*CookieVariant*/  set _variant(value) { this.$setField(4, 4, value); }
            $ctor$3(/*string*/ name, /*CookieVariant*/ variant)
            {
                super.$ctor$1();
                {
                    this._name = name;
                    this._variant = variant;
                }
                return this;
            }
            /*string */ get Name()
            {
                return this._name;
            }
            /*CookieVariant */ get Variant()
            {
                return this._variant;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._name = this._name;
                copy._variant = this._variant;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._name = null;
                this._variant = 0;
            }
            static $h = 2671349;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21477507829,"f":50331656},"n":"Name","d":2671349,"h":17182540533,"f":2097160},{"p":1884917,"g":{"r":0,"d":0,"h":30067442421,"f":50331656},"n":"Variant","d":2671349,"h":25772475125,"f":2097160}],"l":[{"t":1310721,"n":"_name","d":2671349,"h":4297638645,"f":4194306},{"t":1884917,"n":"_variant","d":2671349,"h":8592605941,"f":4194306}],"c":[{"p":[{"n":"name","p":1310721},{"n":"variant","p":1884917}],"n":".ctor","o":"$ctor$3","d":2671349,"h":12887573237,"f":16777224},{"n":".ctor","o":"$ctor$2","d":2671349,"h":34362409717,"f":16777217}],"h":2671349}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Net.HeaderVariantInfo`; }
        });
        
        $asm.$str("$snp.System.Net.CookieParser", ($self) => class CookieParser extends $.$$.System.ValueType
        {
            /*CookieTokenizer*/  get _tokenizer() { return this.$getField(0, 42); }
            /*CookieTokenizer*/  set _tokenizer(value) { this.$setField(0, 42, value); }
            /*Cookie?*/  get _savedCookie() { return this.$getField(42, 4); }
            /*Cookie?*/  set _savedCookie(value) { this.$setField(42, 4, value); }
            $ctor$3(/*string*/ cookieString)
            {
                super.$ctor$1();
                {
                    this._tokenizer = new $.$snp.System.Net.CookieTokenizer().$ctor$3(cookieString);
                    this._savedCookie = null;
                }
                return this;
            }
            static /*bool */ InternalSetNameMethod(/*Cookie*/ cookie, /*string?*/ value)
            {
                return cookie.InternalSetName(value);
            }
            /*FieldInfo?*/ static s_isQuotedDomainField = null;
            static /*FieldInfo */ get IsQuotedDomainField()
            {
                if ($.$$.System.Reflection.FieldInfo.op_Equality$1($.$snp.System.Net.CookieParser.s_isQuotedDomainField, null))
                {
                    /*FieldInfo?*/ let fieldInfo = $.$snp.System.Net.Cookie.$type.GetField$1("IsQuotedDomain", 4/*BindingFlags.Instance*/ | 32/*BindingFlags.NonPublic*/);
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Reflection.FieldInfo.op_Inequality$1(fieldInfo, null), "We need to use an internal field named IsQuotedDomain that is declared on Cookie.");
                    $.$snp.System.Net.CookieParser.s_isQuotedDomainField = fieldInfo;
                }
                return $.$snp.System.Net.CookieParser.s_isQuotedDomainField;
            }
            /*FieldInfo?*/ static s_isQuotedVersionField = null;
            static /*FieldInfo */ get IsQuotedVersionField()
            {
                if ($.$$.System.Reflection.FieldInfo.op_Equality$1($.$snp.System.Net.CookieParser.s_isQuotedVersionField, null))
                {
                    /*FieldInfo?*/ let fieldInfo = $.$snp.System.Net.Cookie.$type.GetField$1("IsQuotedVersion", 4/*BindingFlags.Instance*/ | 32/*BindingFlags.NonPublic*/);
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.Reflection.FieldInfo.op_Inequality$1(fieldInfo, null), "We need to use an internal field named IsQuotedVersion that is declared on Cookie.");
                    $.$snp.System.Net.CookieParser.s_isQuotedVersionField = fieldInfo;
                }
                return $.$snp.System.Net.CookieParser.s_isQuotedVersionField;
            }
            /*Cookie? */ Get()
            {
                /*Cookie?*/ let cookie = null;
                /*bool*/ let commentSet = false;
                /*bool*/ let commentUriSet = false;
                /*bool*/ let domainSet = false;
                /*bool*/ let expiresSet = false;
                /*bool*/ let pathSet = false;
                /*bool*/ let portSet = false;
                /*bool*/ let versionSet = false;
                /*bool*/ let secureSet = false;
                /*bool*/ let discardSet = false;
                do
                {
                    /*CookieToken*/ let token = this._tokenizer.Next(cookie === null, true);
                    if (cookie === null && (token === 1/*CookieToken.NameValuePair*/ || token === 2/*CookieToken.Attribute*/))
                    {
                        cookie = new $.$snp.System.Net.Cookie().$ctor$1();
                        $.$snp.System.Net.CookieParser.InternalSetNameMethod(cookie, this._tokenizer.Name);
                        cookie.Value = this._tokenizer.Value;
                    }
                    else 
                    {
                        switch(token)
                        {
                            case 1/*CookieToken.NameValuePair*/:
                            let $switch2 = this._tokenizer.Token;
                            switch($switch2)
                            {
                                case 7/*CookieToken.Comment*/:
                                if (!commentSet)
                                {
                                    commentSet = true;
                                    cookie.Comment = this._tokenizer.Value;
                                }
                                break;
                                case 8/*CookieToken.CommentUrl*/:
                                if (!commentUriSet)
                                {
                                    commentUriSet = true;
                                    /*Uri?*/ let parsed;
                                    if ($.$spu.System.Uri.TryCreate($.$snp.System.Net.CookieParser.CheckQuoted(this._tokenizer.Value), 1/*UriKind.Absolute*/, $.$ref(() => parsed, ($v) => parsed = $v, $.$spu.System.Uri)))
                                    {
                                        cookie.CommentUri = parsed;
                                    }
                                }
                                break;
                                case 11/*CookieToken.Domain*/:
                                if (!domainSet)
                                {
                                    domainSet = true;
                                    cookie.Domain = $.$snp.System.Net.CookieParser.CheckQuoted(this._tokenizer.Value);
                                    $.$snp.System.Net.CookieParser.IsQuotedDomainField.SetValue$1(cookie, $.$box(this._tokenizer.Quoted, $.$$.System.Boolean));
                                }
                                break;
                                case 12/*CookieToken.Expires*/:
                                if (!expiresSet)
                                {
                                    expiresSet = true;
                                    /*DateTime*/ let expires;
                                    if ($.$$.System.DateTime.TryParse$3($.$snp.System.Net.CookieParser.CheckQuoted(this._tokenizer.Value), $.$$.System.Globalization.CultureInfo.InvariantCulture, 7/*DateTimeStyles.AllowWhiteSpaces*/ | 16/*DateTimeStyles.AdjustToUniversal*/, $.$ref(() => expires, ($v) => expires = $v, $.$$.System.DateTime)))
                                    {
                                        cookie.Expires = expires;
                                    }
                                    else 
                                    {
                                        $.$snp.System.Net.CookieParser.InternalSetNameMethod(cookie, $.$$.System.String.Empty);
                                    }
                                }
                                break;
                                case 13/*CookieToken.MaxAge*/:
                                if (!expiresSet)
                                {
                                    expiresSet = true;
                                    /*int*/ let parsed;
                                    if ($.$$.System.Int32.TryParse$8($.$snp.System.Net.CookieParser.CheckQuoted(this._tokenizer.Value), $.$ref(() => parsed, ($v) => parsed = $v, $.$$.System.Int32)))
                                    {
                                        cookie.Expires = $.$$.System.DateTime.UtcNow.AddSeconds(parsed);
                                    }
                                    else 
                                    {
                                        $.$snp.System.Net.CookieParser.InternalSetNameMethod(cookie, $.$$.System.String.Empty);
                                    }
                                }
                                break;
                                case 14/*CookieToken.Path*/:
                                if (!pathSet)
                                {
                                    pathSet = true;
                                    cookie.Path = this._tokenizer.Value;
                                }
                                break;
                                case 15/*CookieToken.Port*/:
                                if (!portSet)
                                {
                                    portSet = true;
                                    try
                                    {
                                        cookie.Port = this._tokenizer.Value;
                                    }
                                    catch($e)
                                    {
                                        $.$snp.System.Net.CookieParser.InternalSetNameMethod(cookie, $.$$.System.String.Empty);
                                    }
                                }
                                break;
                                case 19/*CookieToken.Version*/:
                                if (!versionSet)
                                {
                                    versionSet = true;
                                    /*int*/ let parsed;
                                    if ($.$$.System.Int32.TryParse$8($.$snp.System.Net.CookieParser.CheckQuoted(this._tokenizer.Value), $.$ref(() => parsed, ($v) => parsed = $v, $.$$.System.Int32)))
                                    {
                                        cookie.Version = parsed;
                                        $.$snp.System.Net.CookieParser.IsQuotedVersionField.SetValue$1(cookie, $.$box(this._tokenizer.Quoted, $.$$.System.Boolean));
                                    }
                                    else 
                                    {
                                        $.$snp.System.Net.CookieParser.InternalSetNameMethod(cookie, $.$$.System.String.Empty);
                                    }
                                }
                                break;
                            }
                            break;
                            case 2/*CookieToken.Attribute*/:
                            let $switch3 = this._tokenizer.Token;
                            switch($switch3)
                            {
                                case 10/*CookieToken.Discard*/:
                                if (!discardSet)
                                {
                                    discardSet = true;
                                    cookie.Discard = true;
                                }
                                break;
                                case 16/*CookieToken.Secure*/:
                                if (!secureSet)
                                {
                                    secureSet = true;
                                    cookie.Secure = true;
                                }
                                break;
                                case 17/*CookieToken.HttpOnly*/:
                                cookie.HttpOnly = true;
                                break;
                                case 15/*CookieToken.Port*/:
                                if (!portSet)
                                {
                                    portSet = true;
                                    cookie.Port = $.$$.System.String.Empty;
                                }
                                break;
                            }
                            break;
                        }
                    }
                }
                while(!this._tokenizer.Eof && !this._tokenizer.EndOfCookie);
                return cookie;
            }
            /*Cookie? */ GetServer()
            {
                /*Cookie?*/ let cookie = this._savedCookie;
                this._savedCookie = null;
                /*bool*/ let domainSet = false;
                /*bool*/ let pathSet = false;
                /*bool*/ let portSet = false;
                do
                {
                    /*bool*/ let first = cookie === null || $.$$.System.String.IsNullOrEmpty(cookie.Name);
                    /*CookieToken*/ let token = this._tokenizer.Next(first, false);
                    if (first && (token === 1/*CookieToken.NameValuePair*/ || token === 2/*CookieToken.Attribute*/))
                    {
                        cookie ??= new $.$snp.System.Net.Cookie().$ctor$1();
                        $.$snp.System.Net.CookieParser.InternalSetNameMethod(cookie, this._tokenizer.Name);
                        cookie.Value = this._tokenizer.Value;
                    }
                    else 
                    {
                        switch(token)
                        {
                            case 1/*CookieToken.NameValuePair*/:
                            let $switch2 = this._tokenizer.Token;
                            switch($switch2)
                            {
                                case 11/*CookieToken.Domain*/:
                                if (!domainSet)
                                {
                                    domainSet = true;
                                    cookie.Domain = $.$snp.System.Net.CookieParser.CheckQuoted(this._tokenizer.Value);
                                    $.$snp.System.Net.CookieParser.IsQuotedDomainField.SetValue$1(cookie, $.$box(this._tokenizer.Quoted, $.$$.System.Boolean));
                                }
                                break;
                                case 14/*CookieToken.Path*/:
                                if (!pathSet)
                                {
                                    pathSet = true;
                                    cookie.Path = this._tokenizer.Value;
                                }
                                break;
                                case 15/*CookieToken.Port*/:
                                if (!portSet)
                                {
                                    portSet = true;
                                    try
                                    {
                                        cookie.Port = this._tokenizer.Value;
                                    }
                                    catch($e)
                                    {
                                        $.$snp.System.Net.CookieParser.InternalSetNameMethod(cookie, $.$$.System.String.Empty);
                                    }
                                }
                                break;
                                case 19/*CookieToken.Version*/:
                                this._savedCookie = new $.$snp.System.Net.Cookie().$ctor$1();
                                /*int*/ let parsed;
                                if ($.$$.System.Int32.TryParse$8(this._tokenizer.Value, $.$ref(() => parsed, ($v) => parsed = $v, $.$$.System.Int32)))
                                {
                                    this._savedCookie.Version = parsed;
                                }
                                return cookie;
                                case 18/*CookieToken.Unknown*/:
                                this._savedCookie = new $.$snp.System.Net.Cookie().$ctor$1();
                                $.$snp.System.Net.CookieParser.InternalSetNameMethod(this._savedCookie, this._tokenizer.Name);
                                this._savedCookie.Value = this._tokenizer.Value;
                                return cookie;
                            }
                            break;
                            case 2/*CookieToken.Attribute*/:
                            if (this._tokenizer.Token === 15/*CookieToken.Port*/ && !portSet)
                            {
                                portSet = true;
                                cookie.Port = $.$$.System.String.Empty;
                            }
                            break;
                        }
                    }
                }
                while(!this._tokenizer.Eof && !this._tokenizer.EndOfCookie);
                return cookie;
            }
            static /*string */ CheckQuoted(/*string*/ value)
            {
                return (value.length >= 2 && $.$$.System.String.StartsWith.call(value, /*\"*/ 34) && $.$$.System.String.EndsWith.call(value, /*\"*/ 34)) ? $.$$.System.String.Substring.call(value, 1, ((value.length - 2) | 0)) : value;
            }
            /*bool */ EndofHeader()
            {
                return this._tokenizer.Eof;
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._tokenizer = this._tokenizer.Clone();
                copy._savedCookie = this._savedCookie;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._tokenizer = $.$default($.$snp.System.Net.CookieTokenizer);
                this._savedCookie = null;
            }
            static $h = 1622773;
            static $z = 46;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":76677121,"g":{"r":0,"d":0,"h":30066393845,"f":50331682},"n":"IsQuotedDomainField","d":1622773,"h":25771426549,"f":2097186},{"p":76677121,"g":{"r":0,"d":0,"h":42951295733,"f":50331682},"n":"IsQuotedVersionField","d":1622773,"h":38656328437,"f":2097186}],"m":[{"r":262145,"p":[{"n":"cookie","p":1164021},{"n":"value","p":1310721}],"n":"InternalSetNameMethod","d":1622773,"h":17181491957,"f":16777250},{"r":1164021,"n":"Get","d":1622773,"h":47246263029,"f":16777224},{"r":1164021,"n":"GetServer","d":1622773,"h":51541230325,"f":16777224},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"CheckQuoted","d":1622773,"h":55836197621,"f":16777256},{"r":262145,"n":"EndofHeader","d":1622773,"h":60131164917,"f":16777224}],"l":[{"t":1753845,"n":"_tokenizer","d":1622773,"h":4296590069,"f":4194306},{"t":1164021,"n":"_savedCookie","d":1622773,"h":8591557365,"f":4194306},{"t":76677121,"n":"s_isQuotedDomainField","d":1622773,"h":21476459253,"f":4194338},{"t":76677121,"n":"s_isQuotedVersionField","d":1622773,"h":34361361141,"f":4194338}],"c":[{"p":[{"n":"cookieString","p":1310721}],"n":".ctor","o":"$ctor$3","d":1622773,"h":12886524661,"f":16777224},{"n":".ctor","o":"$ctor$2","d":1622773,"h":64426132213,"f":16777217}],"h":1622773}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Net.CookieParser`; }
        });
        
        $asm.$str("$snp.System.Net.CredentialHostKey", ($self) => class CredentialHostKey extends $.$$.System.ValueType
        {
            /*string*/  get Host() { return this.$getField(0, 4); }
            /*string*/  set Host(value) { this.$setField(0, 4, value); }
            /*string*/  get AuthenticationType() { return this.$getField(4, 4); }
            /*string*/  set AuthenticationType(value) { this.$setField(4, 4, value); }
            /*int*/  get Port() { return this.$getField(8, 4); }
            /*int*/  set Port(value) { this.$setField(8, 4, value); }
            $ctor$3(/*string*/ host, /*int*/ port, /*string*/ authenticationType)
            {
                super.$ctor$1();
                {
                    $.$$.System.Diagnostics.Debug.Assert$2(!$.$$.System.String.IsNullOrEmpty(host), "!string.IsNullOrEmpty(host)");
                    $.$$.System.Diagnostics.Debug.Assert$2(port >= 0, "port >= 0");
                    $.$$.System.Diagnostics.Debug.Assert$2($.$$.System.String.op_Inequality(authenticationType, null), "authenticationType != null");
                    this.Host = host;
                    this.Port = port;
                    this.AuthenticationType = authenticationType;
                }
                return this;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(this.AuthenticationType) ^ $.$$.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(this.Host) ^ $.$$.System.Int32.GetHashCode.call(this.Port);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snp.System.Net.CredentialHostKey.GetHashCode.apply(this, arguments); }
            /*bool */ Equals$2(/*CredentialHostKey*/ other)
            {
                /*bool*/ let equals = $.$$.System.String.Equals$2(this.AuthenticationType, other.AuthenticationType, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$$.System.String.Equals$2(this.Host, other.Host, 5/*StringComparison.OrdinalIgnoreCase*/) && this.Port === other.Port;
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Equals(${$.$snp.System.Net.CredentialHostKey.ToString.call(this)},${$.$snp.System.Net.CredentialHostKey.ToString.call(other)}) returns ${equals}`, "Equals");
                }
                return equals;
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                return $.$is(obj, $.$snp.System.Net.CredentialHostKey) && this.Equals$2($.$cast(obj, $.$snp.System.Net.CredentialHostKey));
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$snp.System.Net.CredentialHostKey.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return $.$$.System.String.Create$6($.$$.System.Globalization.CultureInfo.InvariantCulture, `${this.Host}:${this.Port}:${this.AuthenticationType}`);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.CredentialHostKey.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Net.CredentialHostKey>.Equals(System.Net.CredentialHostKey)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Host = this.Host;
                copy.AuthenticationType = this.AuthenticationType;
                copy.Port = this.Port;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Host = null;
                this.AuthenticationType = null;
                this.Port = 0;
            }
            static $h = 2409205;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":655361,"n":"GetHashCode","d":2409205,"h":21477245685,"f":16809985},{"r":262145,"p":[{"n":"other","p":2409205}],"n":"Equals","o":"@$2","d":2409205,"h":25772212981,"f":16777217},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":2409205,"h":30067180277,"f":16809985},{"r":1310721,"n":"ToString","d":2409205,"h":34362147573,"f":16809985}],"l":[{"t":1310721,"n":"Host","d":2409205,"h":4297376501,"f":4194305},{"t":1310721,"n":"AuthenticationType","d":2409205,"h":8592343797,"f":4194305},{"t":655361,"n":"Port","d":2409205,"h":12887311093,"f":4194305}],"c":[{"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"authenticationType","p":1310721}],"n":".ctor","o":"$ctor$3","d":2409205,"h":17182278389,"f":16777224},{"n":".ctor","o":"$ctor$2","d":2409205,"h":38657114869,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$snp.System.Net.CredentialHostKey).$h],"h":2409205}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$snp.System.Net.CredentialHostKey) ]; }
            static get $fullName() { return `System.Net.CredentialHostKey`; }
        });
        
        $asm.$str("$snp.System.Net.IPNetwork", ($self) => class IPNetwork extends $.$$.System.ValueType
        {
            /*IPAddress?*/  get _baseAddress() { return this.$getField(0, 4); }
            /*IPAddress?*/  set _baseAddress(value) { this.$setField(0, 4, value); }
            /*IPAddress */ get BaseAddress()
            {
                return this._baseAddress ?? $.$snp.System.Net.IPAddress.Any;
            }
            /*int*/ PrefixLength = 0;
            $ctor$3(/*IPAddress*/ baseAddress, /*int*/ prefixLength)
            {
                super.$ctor$1();
                {
                    $.$$.System.ArgumentNullException.ThrowIfNull$2(baseAddress, "baseAddress");
                    if (prefixLength < 0 || prefixLength > $.$snp.System.Net.IPNetwork.GetMaxPrefixLength(baseAddress))
                    {
                        ThrowArgumentOutOfRangeException();
                    }
                    this._baseAddress = $.$snp.System.Net.IPNetwork.ClearNonZeroBitsAfterNetworkPrefix(baseAddress, prefixLength);
                    this.PrefixLength = prefixLength;
                    /*static void*/  function ThrowArgumentOutOfRangeException()
                    {
                        throw new $.$$.System.ArgumentOutOfRangeException().$ctor$20("prefixLength");
                    }
                }
                return this;
            }
            /*bool */ Contains(/*IPAddress*/ address)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(address, "address");
                if (address.AddressFamily !== this.BaseAddress.AddressFamily && (this.BaseAddress.AddressFamily !== 2/*AddressFamily.InterNetwork*/ || !address.IsIPv4MappedToIPv6))
                {
                    return false;
                }
                if (this.PrefixLength === 0)
                {
                    return true;
                }
                if (address.AddressFamily === 2/*AddressFamily.InterNetwork*/ || address.IsIPv4MappedToIPv6)
                {
                    /*uint*/ let mask = (4294967295/*uint.MaxValue*/ << (((32 - this.PrefixLength) | 0))) >>> 0;
                    if ($.$$.System.BitConverter.IsLittleEndian)
                    {
                        mask = $.$$.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$20(mask);
                    }
                    return this.BaseAddress.PrivateIPv4Address === (address.PrivateIPv4Address & mask);
                }
                else 
                {
                    /*UInt128*/ let baseAddressValue = new $.$$.System.UInt128();
                    /*UInt128*/ let otherAddressValue = new $.$$.System.UInt128();
                    /*int*/ let bytesWritten;
                    this.BaseAddress.TryWriteBytes($.$$.System.Runtime.InteropServices.MemoryMarshal.AsBytes$1($.$$.System.UInt128, new ($.$$.System.Span$$($.$$.System.UInt128))().$ctor$7($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.UInt128, () => baseAddressValue, ($v) => baseAddressValue = $v, null))), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32));
                    $.$$.System.Diagnostics.Debug.Assert$2(bytesWritten === 16/*IPAddressParserStatics.IPv6AddressBytes*/, "bytesWritten == IPAddressParserStatics.IPv6AddressBytes");
                    address.TryWriteBytes($.$$.System.Runtime.InteropServices.MemoryMarshal.AsBytes$1($.$$.System.UInt128, new ($.$$.System.Span$$($.$$.System.UInt128))().$ctor$7($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.UInt128, () => otherAddressValue, ($v) => otherAddressValue = $v, null))), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32));
                    $.$$.System.Diagnostics.Debug.Assert$2(bytesWritten === 16/*IPAddressParserStatics.IPv6AddressBytes*/, "bytesWritten == IPAddressParserStatics.IPv6AddressBytes");
                    /*UInt128*/ let mask = $.$$.System.UInt128.op_LeftShift($.$$.System.UInt128.MaxValue, (((128 - this.PrefixLength) | 0)));
                    if ($.$$.System.BitConverter.IsLittleEndian)
                    {
                        mask = $.$$.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$18(mask);
                    }
                    return $.$$.System.UInt128.op_Equality(baseAddressValue, ($.$$.System.UInt128.op_BitwiseAnd(otherAddressValue, mask)));
                }
            }
            static /*IPNetwork */ Parse$2(/*string*/ s)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(s, "s");
                return $.$snp.System.Net.IPNetwork.Parse$1($.$$.System.MemoryExtensions.AsSpan$4(s));
            }
            static /*IPNetwork */ Parse$1(/*ReadOnlySpan<char>*/ s)
            {
                /*IPNetwork*/ let result;
                if (!$.$snp.System.Net.IPNetwork.TryParse$1(s, $.$ref(() => result, ($v) => result = $v, $.$snp.System.Net.IPNetwork)))
                {
                    throw new $.$$.System.FormatException().$ctor$12($.$snp.System.SR.net_bad_ip_network);
                }
                return result;
            }
            static /*IPNetwork */ Parse(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                /*IPNetwork*/ let result;
                if (!$.$snp.System.Net.IPNetwork.TryParse(utf8Text, $.$ref(() => result, ($v) => result = $v, $.$snp.System.Net.IPNetwork)))
                {
                    throw new $.$$.System.FormatException().$ctor$12($.$snp.System.SR.net_bad_ip_network);
                }
                return result;
            }
            static /*bool */ TryParse$2(/*string?*/ s, /*out IPNetwork*/ result)
            {
                if ($.$$.System.String.op_Equality(s, null))
                {
                    result.$v = new $.$snp.System.Net.IPNetwork();
                    return false;
                }
                return $.$snp.System.Net.IPNetwork.TryParse$1($.$$.System.MemoryExtensions.AsSpan$4(s), result);
            }
            static /*bool */ TryParse$1(/*ReadOnlySpan<char>*/ s, /*out IPNetwork*/ result)
            {
                /*int*/ let separatorIndex = $.$$.System.MemoryExtensions.LastIndexOf$4($.$$.System.Char, s, /*/*/ 47);
                if (separatorIndex >= 0)
                {
                    /*ReadOnlySpan<char>*/ let ipAddressSpan = s.Slice(0, separatorIndex);
                    /*ReadOnlySpan<char>*/ let prefixLengthSpan = s.Slice$1(((separatorIndex + 1) | 0));
                    /*IPAddress?*/ let address;
                    /*int*/ let prefixLength;
                    if ($.$snp.System.Net.IPAddress.TryParse$1(ipAddressSpan, $.$ref(() => address, ($v) => address = $v, $.$snp.System.Net.IPAddress)) && $.$$.System.Int32.TryParse$3(prefixLengthSpan, 0/*NumberStyles.None*/, $.$$.System.Globalization.CultureInfo.InvariantCulture, $.$ref(() => prefixLength, ($v) => prefixLength = $v, $.$$.System.Int32)) && prefixLength <= $.$snp.System.Net.IPNetwork.GetMaxPrefixLength(address))
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(prefixLength >= 0, "prefixLength >= 0");
                        result.$v = new $.$snp.System.Net.IPNetwork().$ctor$3(address, prefixLength);
                        return true;
                    }
                }
                result.$v = new $.$snp.System.Net.IPNetwork();
                return false;
            }
            static /*bool */ TryParse(/*ReadOnlySpan<byte>*/ utf8Text, /*out IPNetwork*/ result)
            {
                /*int*/ let separatorIndex = $.$$.System.MemoryExtensions.LastIndexOf$4($.$$.System.Byte, utf8Text, /*/*/ 47);
                if (separatorIndex >= 0)
                {
                    /*ReadOnlySpan<byte>*/ let ipAddressSpan = utf8Text.Slice(0, separatorIndex);
                    /*ReadOnlySpan<byte>*/ let prefixLengthSpan = utf8Text.Slice$1(((separatorIndex + 1) | 0));
                    /*IPAddress?*/ let address;
                    /*int*/ let prefixLength;
                    if ($.$snp.System.Net.IPAddress.TryParse(ipAddressSpan, $.$ref(() => address, ($v) => address = $v, $.$snp.System.Net.IPAddress)) && $.$$.System.Int32.TryParse(prefixLengthSpan, 0/*NumberStyles.None*/, $.$$.System.Globalization.CultureInfo.InvariantCulture, $.$ref(() => prefixLength, ($v) => prefixLength = $v, $.$$.System.Int32)) && prefixLength <= $.$snp.System.Net.IPNetwork.GetMaxPrefixLength(address))
                    {
                        $.$$.System.Diagnostics.Debug.Assert$2(prefixLength >= 0, "prefixLength >= 0");
                        result.$v = new $.$snp.System.Net.IPNetwork().$ctor$3(address, prefixLength);
                        return true;
                    }
                }
                result.$v = new $.$snp.System.Net.IPNetwork();
                return false;
            }
            static /*int */ GetMaxPrefixLength(/*IPAddress*/ baseAddress)
            {
                return baseAddress.AddressFamily === 2/*AddressFamily.InterNetwork*/ ? 32 : 128;
            }
            static /*IPAddress */ ClearNonZeroBitsAfterNetworkPrefix(/*IPAddress*/ baseAddress, /*int*/ prefixLength)
            {
                if (baseAddress.AddressFamily === 2/*AddressFamily.InterNetwork*/)
                {
                    if (prefixLength === 0)
                    {
                        return $.$snp.System.Net.IPAddress.Any;
                    }
                    /*uint*/ let mask = (4294967295/*uint.MaxValue*/ << (((32 - prefixLength) | 0))) >>> 0;
                    if ($.$$.System.BitConverter.IsLittleEndian)
                    {
                        mask = $.$$.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$20(mask);
                    }
                    /*uint*/ let newAddress = baseAddress.PrivateAddress & mask;
                    return newAddress === baseAddress.PrivateAddress ? baseAddress : new $.$snp.System.Net.IPAddress().$ctor$4(BigInt(newAddress));
                }
                else 
                {
                    if (prefixLength === 0)
                    {
                        return $.$snp.System.Net.IPAddress.IPv6Any;
                    }
                    /*UInt128*/ let value = new $.$$.System.UInt128();
                    /*int*/ let bytesWritten;
                    baseAddress.TryWriteBytes($.$$.System.Runtime.InteropServices.MemoryMarshal.AsBytes$1($.$$.System.UInt128, new ($.$$.System.Span$$($.$$.System.UInt128))().$ctor$7($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.UInt128, () => value, ($v) => value = $v, null))), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$$.System.Int32));
                    $.$$.System.Diagnostics.Debug.Assert$2(bytesWritten === 16/*IPAddressParserStatics.IPv6AddressBytes*/, "bytesWritten == IPAddressParserStatics.IPv6AddressBytes");
                    /*UInt128*/ let mask = $.$$.System.UInt128.op_LeftShift($.$$.System.UInt128.MaxValue, (((128 - prefixLength) | 0)));
                    if ($.$$.System.BitConverter.IsLittleEndian)
                    {
                        mask = $.$$.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$18(mask);
                    }
                    /*UInt128*/ let newAddress = $.$$.System.UInt128.op_BitwiseAnd(value, mask);
                    return $.$$.System.UInt128.op_Equality(newAddress, value) ? baseAddress : new $.$snp.System.Net.IPAddress().$ctor$6($.$$.System.Span$$($.$$.System.Byte).op_Implicit($.$$.System.Runtime.InteropServices.MemoryMarshal.AsBytes$1($.$$.System.UInt128, new ($.$$.System.Span$$($.$$.System.UInt128))().$ctor$7($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.UInt128, () => newAddress, ($v) => newAddress = $v, null)))));
                }
            }
            static/*conventional*/ /*string */ ToString()
            {
                return $.$$.System.String.Create$5($.$$.System.Globalization.CultureInfo.InvariantCulture, $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$$.System.Char, 128, null), `${$.$snp.System.Net.IPAddress.ToString.call(this.BaseAddress)}/${(this.PrefixLength >>> 0)}`);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.IPNetwork.ToString.apply(this, arguments); }
            /*bool */ TryFormat$1(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                return $.$$.System.MemoryExtensions.TryWrite$2(destination, $.$$.System.Globalization.CultureInfo.InvariantCulture, `${$.$snp.System.Net.IPAddress.ToString.call(this.BaseAddress)}/${(this.PrefixLength >>> 0)}`, charsWritten);
            }
            /*bool */ TryFormat(/*Span<byte>*/ utf8Destination, /*out int*/ bytesWritten)
            {
                return $.$$.System.Text.Unicode.Utf8.TryWrite(utf8Destination, $.$$.System.Globalization.CultureInfo.InvariantCulture, `${$.$snp.System.Net.IPAddress.ToString.call(this.BaseAddress)}/${(this.PrefixLength >>> 0)}`, bytesWritten);
            }
            /*bool */ Equals$2(/*IPNetwork*/ other)
            {
                return this.PrefixLength === other.PrefixLength && this.BaseAddress.Equals$2(other.BaseAddress);
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$snp.System.Net.IPNetwork, { set $v(v){ other = v; } }) && this.Equals$2(other);
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$snp.System.Net.IPNetwork.Equals$1.apply(this, arguments); }
            static /*bool */ op_Equality(/*IPNetwork*/ left, /*IPNetwork*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality(/*IPNetwork*/ left, /*IPNetwork*/ right)
            {
                return !($.$snp.System.Net.IPNetwork.op_Equality(left, right));
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$$.System.HashCode.Combine$6($.$snp.System.Net.IPAddress, $.$$.System.Int32, this.BaseAddress, this.PrefixLength);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snp.System.Net.IPNetwork.GetHashCode.apply(this, arguments); }
            /*string */ System$IFormattable$ToString(/*string?*/ format, /*IFormatProvider?*/ provider)
            {
                return $.$snp.System.Net.IPNetwork.ToString.call(this);
            }
            /*bool */ System$ISpanFormattable$TryFormat(/*Span<char>*/ destination, /*out int*/ charsWritten, /*ReadOnlySpan<char>*/ format, /*IFormatProvider?*/ provider)
            {
                return this.TryFormat$1(destination, charsWritten);
            }
            /*bool */ System$IUtf8SpanFormattable$TryFormat(/*Span<byte>*/ utf8Destination, /*out int*/ bytesWritten, /*ReadOnlySpan<char>*/ format, /*IFormatProvider?*/ provider)
            {
                return this.TryFormat(utf8Destination, bytesWritten);
            }
            static /*IPNetwork */ System$IParsable$$$Parse(/*string*/ s, /*IFormatProvider?*/ provider)
            {
                return $.$snp.System.Net.IPNetwork.Parse$2(s);
            }
            static /*bool */ System$IParsable$$$TryParse(/*string?*/ s, /*IFormatProvider?*/ provider, /*out IPNetwork*/ result)
            {
                return $.$snp.System.Net.IPNetwork.TryParse$2(s, result);
            }
            static /*IPNetwork */ System$ISpanParsable$$$Parse(/*ReadOnlySpan<char>*/ s, /*IFormatProvider?*/ provider)
            {
                return $.$snp.System.Net.IPNetwork.Parse$1(s);
            }
            static /*IPNetwork */ System$IUtf8SpanParsable$$$Parse(/*ReadOnlySpan<byte>*/ utf8Text, /*IFormatProvider?*/ provider)
            {
                return $.$snp.System.Net.IPNetwork.Parse(utf8Text);
            }
            static /*bool */ System$ISpanParsable$$$TryParse(/*ReadOnlySpan<char>*/ s, /*IFormatProvider?*/ provider, /*out IPNetwork*/ result)
            {
                return $.$snp.System.Net.IPNetwork.TryParse$1(s, result);
            }
            static /*bool */ System$IUtf8SpanParsable$$$TryParse(/*ReadOnlySpan<byte>*/ utf8Text, /*IFormatProvider?*/ provider, /*out IPNetwork*/ result)
            {
                return $.$snp.System.Net.IPNetwork.TryParse(utf8Text, result);
            }
            //Generated interface implemetation for System.IEquatable<System.Net.IPNetwork>.Equals(System.Net.IPNetwork)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._baseAddress = this._baseAddress;
                copy.PrefixLength = this.PrefixLength;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._baseAddress = null;
            }
            static $h = 3392245;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":3064565,"g":{"r":0,"d":0,"h":12888294133,"f":50331649},"n":"BaseAddress","d":3392245,"h":8593326837,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":25773196021,"f":50331649},"n":"PrefixLength","d":3392245,"h":21478228725,"f":2097153}],"m":[{"r":262145,"p":[{"n":"address","p":3064565}],"n":"Contains","d":3392245,"h":34363130613,"f":16777217},{"r":3392245,"p":[{"n":"s","p":1310721}],"n":"Parse","o":"@$2","d":3392245,"h":38658097909,"f":16777249},{"r":3392245,"p":[{"n":"s","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h}],"n":"Parse","o":"@$1","d":3392245,"h":42953065205,"f":16777249},{"r":3392245,"p":[{"n":"utf8Text","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"Parse","d":3392245,"h":47248032501,"f":16777249},{"r":262145,"p":[{"n":"s","p":1310721},{"n":"result","p":3392245,"f":2}],"n":"TryParse","o":"@$2","d":3392245,"h":51542999797,"f":16777249},{"r":262145,"p":[{"n":"s","p":$.$$.System.ReadOnlySpan$$($.$$.System.Char).$h},{"n":"result","p":3392245,"f":2}],"n":"TryParse","o":"@$1","d":3392245,"h":55837967093,"f":16777249},{"r":262145,"p":[{"n":"utf8Text","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"result","p":3392245,"f":2}],"n":"TryParse","d":3392245,"h":60132934389,"f":16777249},{"r":655361,"p":[{"n":"baseAddress","p":3064565}],"n":"GetMaxPrefixLength","d":3392245,"h":64427901685,"f":16777250},{"r":3064565,"p":[{"n":"baseAddress","p":3064565},{"n":"prefixLength","p":655361}],"n":"ClearNonZeroBitsAfterNetworkPrefix","d":3392245,"h":68722868981,"f":16777250},{"r":1310721,"n":"ToString","d":3392245,"h":73017836277,"f":16809985},{"r":262145,"p":[{"n":"destination","p":$.$$.System.Span$$($.$$.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryFormat","o":"@$1","d":3392245,"h":77312803573,"f":16777217},{"r":262145,"p":[{"n":"utf8Destination","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryFormat","d":3392245,"h":81607770869,"f":16777217},{"r":262145,"p":[{"n":"other","p":3392245}],"n":"Equals","o":"@$2","d":3392245,"h":85902738165,"f":16777217},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":3392245,"h":90197705461,"f":16809985},{"r":655361,"n":"GetHashCode","d":3392245,"h":103082607349,"f":16809985}],"l":[{"t":3064565,"n":"_baseAddress","d":3392245,"h":4298359541,"f":4194306}],"c":[{"p":[{"n":"baseAddress","p":3064565},{"n":"prefixLength","p":655361}],"n":".ctor","o":"$ctor$3","d":3392245,"h":30068163317,"f":16777217},{"n":".ctor","o":"$ctor$2","d":3392245,"h":146032280309,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$snp.System.Net.IPNetwork).$h,63832065,57737217,$.$$.System.ISpanParsable$$($.$snp.System.Net.IPNetwork).$h,$.$$.System.IParsable$$($.$snp.System.Net.IPNetwork).$h,64159745,$.$$.System.IUtf8SpanParsable$$($.$snp.System.Net.IPNetwork).$h],"h":3392245}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$snp.System.Net.IPNetwork), $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.ISpanParsable$$($.$snp.System.Net.IPNetwork), $.$$.System.IParsable$$($.$snp.System.Net.IPNetwork), $.$$.System.IUtf8SpanFormattable, $.$$.System.IUtf8SpanParsable$$($.$snp.System.Net.IPNetwork) ]; }
            static get $fullName() { return `System.Net.IPNetwork`; }
        });
        
        $asm.$str("$snp.System.Net.AuthenticationSchemes", ($self) => class AuthenticationSchemes extends $.$$.System.Enum
        {
            static None = 0;
            static Digest = 1;
            static Negotiate = 2;
            static Ntlm = 4;
            static Basic = 8;
            static Anonymous = 32768;
            static IntegratedWindowsAuthentication = 6;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Digest": 1n,
                    "Negotiate": 2n,
                    "Ntlm": 4n,
                    "Basic": 8n,
                    "Anonymous": 32768n,
                    "IntegratedWindowsAuthentication": 6n
                };
            }
            static $h = 967413;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":967413,"n":"None","d":967413,"h":4295934709,"f":4194337},{"t":967413,"n":"Digest","d":967413,"h":8590902005,"f":4194337},{"t":967413,"n":"Negotiate","d":967413,"h":12885869301,"f":4194337},{"t":967413,"n":"Ntlm","d":967413,"h":17180836597,"f":4194337},{"t":967413,"n":"Basic","d":967413,"h":21475803893,"f":4194337},{"t":967413,"n":"Anonymous","d":967413,"h":25770771189,"f":4194337},{"t":967413,"n":"IntegratedWindowsAuthentication","d":967413,"h":30065738485,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":967413,"h":34360705781,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":967413,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.AuthenticationSchemes`; }
        });
        
        $asm.$str("$snp.System.Net.DecompressionMethods", ($self) => class DecompressionMethods extends $.$$.System.Enum
        {
            static None = 0;
            static GZip = 1;
            static Deflate = 2;
            static Brotli = 4;
            static All = -1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "GZip": 1n,
                    "Deflate": 2n,
                    "Brotli": 4n,
                    "All": -1n
                };
            }
            static $h = 2474741;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2474741,"n":"None","d":2474741,"h":4297442037,"f":4194337},{"t":2474741,"n":"GZip","d":2474741,"h":8592409333,"f":4194337},{"t":2474741,"n":"Deflate","d":2474741,"h":12887376629,"f":4194337},{"t":2474741,"n":"Brotli","d":2474741,"h":17182343925,"f":4194337},{"t":2474741,"n":"All","d":2474741,"h":21477311221,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2474741,"h":25772278517,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2474741,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.DecompressionMethods`; }
        });
        
        $asm.$str("$snp.System.Net.HttpStatusCode", ($self) => class HttpStatusCode extends $.$$.System.Enum
        {
            static Continue = 100;
            static SwitchingProtocols = 101;
            static Processing = 102;
            static EarlyHints = 103;
            static OK = 200;
            static Created = 201;
            static Accepted = 202;
            static NonAuthoritativeInformation = 203;
            static NoContent = 204;
            static ResetContent = 205;
            static PartialContent = 206;
            static MultiStatus = 207;
            static AlreadyReported = 208;
            static IMUsed = 226;
            static MultipleChoices = 300;
            static Ambiguous = 300;
            static MovedPermanently = 301;
            static Moved = 301;
            static Found = 302;
            static Redirect = 302;
            static SeeOther = 303;
            static RedirectMethod = 303;
            static NotModified = 304;
            static UseProxy = 305;
            static Unused = 306;
            static TemporaryRedirect = 307;
            static RedirectKeepVerb = 307;
            static PermanentRedirect = 308;
            static BadRequest = 400;
            static Unauthorized = 401;
            static PaymentRequired = 402;
            static Forbidden = 403;
            static NotFound = 404;
            static MethodNotAllowed = 405;
            static NotAcceptable = 406;
            static ProxyAuthenticationRequired = 407;
            static RequestTimeout = 408;
            static Conflict = 409;
            static Gone = 410;
            static LengthRequired = 411;
            static PreconditionFailed = 412;
            static RequestEntityTooLarge = 413;
            static RequestUriTooLong = 414;
            static UnsupportedMediaType = 415;
            static RequestedRangeNotSatisfiable = 416;
            static ExpectationFailed = 417;
            static MisdirectedRequest = 421;
            static UnprocessableEntity = 422;
            static UnprocessableContent = 422;
            static Locked = 423;
            static FailedDependency = 424;
            static UpgradeRequired = 426;
            static PreconditionRequired = 428;
            static TooManyRequests = 429;
            static RequestHeaderFieldsTooLarge = 431;
            static UnavailableForLegalReasons = 451;
            static InternalServerError = 500;
            static NotImplemented = 501;
            static BadGateway = 502;
            static ServiceUnavailable = 503;
            static GatewayTimeout = 504;
            static HttpVersionNotSupported = 505;
            static VariantAlsoNegotiates = 506;
            static InsufficientStorage = 507;
            static LoopDetected = 508;
            static NotExtended = 510;
            static NetworkAuthenticationRequired = 511;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Continue": 100n,
                    "SwitchingProtocols": 101n,
                    "Processing": 102n,
                    "EarlyHints": 103n,
                    "OK": 200n,
                    "Created": 201n,
                    "Accepted": 202n,
                    "NonAuthoritativeInformation": 203n,
                    "NoContent": 204n,
                    "ResetContent": 205n,
                    "PartialContent": 206n,
                    "MultiStatus": 207n,
                    "AlreadyReported": 208n,
                    "IMUsed": 226n,
                    "MultipleChoices": 300n,
                    "Ambiguous": 300n,
                    "MovedPermanently": 301n,
                    "Moved": 301n,
                    "Found": 302n,
                    "Redirect": 302n,
                    "SeeOther": 303n,
                    "RedirectMethod": 303n,
                    "NotModified": 304n,
                    "UseProxy": 305n,
                    "Unused": 306n,
                    "TemporaryRedirect": 307n,
                    "RedirectKeepVerb": 307n,
                    "PermanentRedirect": 308n,
                    "BadRequest": 400n,
                    "Unauthorized": 401n,
                    "PaymentRequired": 402n,
                    "Forbidden": 403n,
                    "NotFound": 404n,
                    "MethodNotAllowed": 405n,
                    "NotAcceptable": 406n,
                    "ProxyAuthenticationRequired": 407n,
                    "RequestTimeout": 408n,
                    "Conflict": 409n,
                    "Gone": 410n,
                    "LengthRequired": 411n,
                    "PreconditionFailed": 412n,
                    "RequestEntityTooLarge": 413n,
                    "RequestUriTooLong": 414n,
                    "UnsupportedMediaType": 415n,
                    "RequestedRangeNotSatisfiable": 416n,
                    "ExpectationFailed": 417n,
                    "MisdirectedRequest": 421n,
                    "UnprocessableEntity": 422n,
                    "UnprocessableContent": 422n,
                    "Locked": 423n,
                    "FailedDependency": 424n,
                    "UpgradeRequired": 426n,
                    "PreconditionRequired": 428n,
                    "TooManyRequests": 429n,
                    "RequestHeaderFieldsTooLarge": 431n,
                    "UnavailableForLegalReasons": 451n,
                    "InternalServerError": 500n,
                    "NotImplemented": 501n,
                    "BadGateway": 502n,
                    "ServiceUnavailable": 503n,
                    "GatewayTimeout": 504n,
                    "HttpVersionNotSupported": 505n,
                    "VariantAlsoNegotiates": 506n,
                    "InsufficientStorage": 507n,
                    "LoopDetected": 508n,
                    "NotExtended": 510n,
                    "NetworkAuthenticationRequired": 511n
                };
            }
            static $h = 2802421;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2802421,"n":"Continue","d":2802421,"h":4297769717,"f":4194337},{"t":2802421,"n":"SwitchingProtocols","d":2802421,"h":8592737013,"f":4194337},{"t":2802421,"n":"Processing","d":2802421,"h":12887704309,"f":4194337},{"t":2802421,"n":"EarlyHints","d":2802421,"h":17182671605,"f":4194337},{"t":2802421,"n":"OK","d":2802421,"h":21477638901,"f":4194337},{"t":2802421,"n":"Created","d":2802421,"h":25772606197,"f":4194337},{"t":2802421,"n":"Accepted","d":2802421,"h":30067573493,"f":4194337},{"t":2802421,"n":"NonAuthoritativeInformation","d":2802421,"h":34362540789,"f":4194337},{"t":2802421,"n":"NoContent","d":2802421,"h":38657508085,"f":4194337},{"t":2802421,"n":"ResetContent","d":2802421,"h":42952475381,"f":4194337},{"t":2802421,"n":"PartialContent","d":2802421,"h":47247442677,"f":4194337},{"t":2802421,"n":"MultiStatus","d":2802421,"h":51542409973,"f":4194337},{"t":2802421,"n":"AlreadyReported","d":2802421,"h":55837377269,"f":4194337},{"t":2802421,"n":"IMUsed","d":2802421,"h":60132344565,"f":4194337},{"t":2802421,"n":"MultipleChoices","d":2802421,"h":64427311861,"f":4194337},{"t":2802421,"n":"Ambiguous","d":2802421,"h":68722279157,"f":4194337},{"t":2802421,"n":"MovedPermanently","d":2802421,"h":73017246453,"f":4194337},{"t":2802421,"n":"Moved","d":2802421,"h":77312213749,"f":4194337},{"t":2802421,"n":"Found","d":2802421,"h":81607181045,"f":4194337},{"t":2802421,"n":"Redirect","d":2802421,"h":85902148341,"f":4194337},{"t":2802421,"n":"SeeOther","d":2802421,"h":90197115637,"f":4194337},{"t":2802421,"n":"RedirectMethod","d":2802421,"h":94492082933,"f":4194337},{"t":2802421,"n":"NotModified","d":2802421,"h":98787050229,"f":4194337},{"t":2802421,"n":"UseProxy","d":2802421,"h":103082017525,"f":4194337},{"t":2802421,"n":"Unused","d":2802421,"h":107376984821,"f":4194337},{"t":2802421,"n":"TemporaryRedirect","d":2802421,"h":111671952117,"f":4194337},{"t":2802421,"n":"RedirectKeepVerb","d":2802421,"h":115966919413,"f":4194337},{"t":2802421,"n":"PermanentRedirect","d":2802421,"h":120261886709,"f":4194337},{"t":2802421,"n":"BadRequest","d":2802421,"h":124556854005,"f":4194337},{"t":2802421,"n":"Unauthorized","d":2802421,"h":128851821301,"f":4194337},{"t":2802421,"n":"PaymentRequired","d":2802421,"h":133146788597,"f":4194337},{"t":2802421,"n":"Forbidden","d":2802421,"h":137441755893,"f":4194337},{"t":2802421,"n":"NotFound","d":2802421,"h":141736723189,"f":4194337},{"t":2802421,"n":"MethodNotAllowed","d":2802421,"h":146031690485,"f":4194337},{"t":2802421,"n":"NotAcceptable","d":2802421,"h":150326657781,"f":4194337},{"t":2802421,"n":"ProxyAuthenticationRequired","d":2802421,"h":154621625077,"f":4194337},{"t":2802421,"n":"RequestTimeout","d":2802421,"h":158916592373,"f":4194337},{"t":2802421,"n":"Conflict","d":2802421,"h":163211559669,"f":4194337},{"t":2802421,"n":"Gone","d":2802421,"h":167506526965,"f":4194337},{"t":2802421,"n":"LengthRequired","d":2802421,"h":171801494261,"f":4194337},{"t":2802421,"n":"PreconditionFailed","d":2802421,"h":176096461557,"f":4194337},{"t":2802421,"n":"RequestEntityTooLarge","d":2802421,"h":180391428853,"f":4194337},{"t":2802421,"n":"RequestUriTooLong","d":2802421,"h":184686396149,"f":4194337},{"t":2802421,"n":"UnsupportedMediaType","d":2802421,"h":188981363445,"f":4194337},{"t":2802421,"n":"RequestedRangeNotSatisfiable","d":2802421,"h":193276330741,"f":4194337},{"t":2802421,"n":"ExpectationFailed","d":2802421,"h":197571298037,"f":4194337},{"t":2802421,"n":"MisdirectedRequest","d":2802421,"h":201866265333,"f":4194337},{"t":2802421,"n":"UnprocessableEntity","d":2802421,"h":206161232629,"f":4194337},{"t":2802421,"n":"UnprocessableContent","d":2802421,"h":210456199925,"f":4194337},{"t":2802421,"n":"Locked","d":2802421,"h":214751167221,"f":4194337},{"t":2802421,"n":"FailedDependency","d":2802421,"h":219046134517,"f":4194337},{"t":2802421,"n":"UpgradeRequired","d":2802421,"h":223341101813,"f":4194337},{"t":2802421,"n":"PreconditionRequired","d":2802421,"h":227636069109,"f":4194337},{"t":2802421,"n":"TooManyRequests","d":2802421,"h":231931036405,"f":4194337},{"t":2802421,"n":"RequestHeaderFieldsTooLarge","d":2802421,"h":236226003701,"f":4194337},{"t":2802421,"n":"UnavailableForLegalReasons","d":2802421,"h":240520970997,"f":4194337},{"t":2802421,"n":"InternalServerError","d":2802421,"h":244815938293,"f":4194337},{"t":2802421,"n":"NotImplemented","d":2802421,"h":249110905589,"f":4194337},{"t":2802421,"n":"BadGateway","d":2802421,"h":253405872885,"f":4194337},{"t":2802421,"n":"ServiceUnavailable","d":2802421,"h":257700840181,"f":4194337},{"t":2802421,"n":"GatewayTimeout","d":2802421,"h":261995807477,"f":4194337},{"t":2802421,"n":"HttpVersionNotSupported","d":2802421,"h":266290774773,"f":4194337},{"t":2802421,"n":"VariantAlsoNegotiates","d":2802421,"h":270585742069,"f":4194337},{"t":2802421,"n":"InsufficientStorage","d":2802421,"h":274880709365,"f":4194337},{"t":2802421,"n":"LoopDetected","d":2802421,"h":279175676661,"f":4194337},{"t":2802421,"n":"NotExtended","d":2802421,"h":283470643957,"f":4194337},{"t":2802421,"n":"NetworkAuthenticationRequired","d":2802421,"h":287765611253,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":2802421,"h":292060578549,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":2802421}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.HttpStatusCode`; }
        });
        
        $asm.$str("$snp.System.Security.Authentication.SslProtocols", ($self) => class SslProtocols extends $.$$.System.Enum
        {
            static None = 0;
            static Ssl2 = 12;
            static Ssl3 = 48;
            static Tls = 192;
            static Tls11 = 768;
            static Tls12 = 3072;
            static Tls13 = 12288;
            static Default = 240;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Ssl2": 12n,
                    "Ssl3": 48n,
                    "Tls": 192n,
                    "Tls11": 768n,
                    "Tls12": 3072n,
                    "Tls13": 12288n,
                    "Default": 240n
                };
            }
            static $h = 5620469;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5620469,"n":"None","d":5620469,"h":4300587765,"f":4194337},{"t":5620469,"n":"Ssl2","d":5620469,"h":8595555061,"f":4194337,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SslProtocols.Ssl2 has been deprecated and is not supported.","t":1310721}]}]},{"t":5620469,"n":"Ssl3","d":5620469,"h":12890522357,"f":4194337,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SslProtocols.Ssl3 has been deprecated and is not supported.","t":1310721}]}]},{"t":5620469,"n":"Tls","d":5620469,"h":17185489653,"f":4194337,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0039","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"t":5620469,"n":"Tls11","d":5620469,"h":21480456949,"f":4194337,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0039","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"t":5620469,"n":"Tls12","d":5620469,"h":25775424245,"f":4194337},{"t":5620469,"n":"Tls13","d":5620469,"h":30070391541,"f":4194337},{"t":5620469,"n":"Default","d":5620469,"h":34365358837,"f":4194337,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SslProtocols.Default has been deprecated and is not supported.","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":5620469,"h":38660326133,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":5620469,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.SslProtocols`; }
        });
        
        $asm.$str("$snp.System.Net.Security.SslPolicyErrors", ($self) => class SslPolicyErrors extends $.$$.System.Enum
        {
            static None = 0;
            static RemoteCertificateNotAvailable = 1;
            static RemoteCertificateNameMismatch = 2;
            static RemoteCertificateChainErrors = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "RemoteCertificateNotAvailable": 1n,
                    "RemoteCertificateNameMismatch": 2n,
                    "RemoteCertificateChainErrors": 4n
                };
            }
            static $h = 4309749;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4309749,"n":"None","d":4309749,"h":4299277045,"f":4194337},{"t":4309749,"n":"RemoteCertificateNotAvailable","d":4309749,"h":8594244341,"f":4194337},{"t":4309749,"n":"RemoteCertificateNameMismatch","d":4309749,"h":12889211637,"f":4194337},{"t":4309749,"n":"RemoteCertificateChainErrors","d":4309749,"h":17184178933,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":4309749,"h":21479146229,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":4309749,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.SslPolicyErrors`; }
        });
        
        $asm.$str("$snp.System.Net.Sockets.AddressFamily", ($self) => class AddressFamily extends $.$$.System.Enum
        {
            static Unknown = -1;
            static Unspecified = 0;
            static Unix = 1;
            static InterNetwork = 2;
            static ImpLink = 3;
            static Pup = 4;
            static Chaos = 5;
            static NS = 6;
            static Ipx = 6;
            static Iso = 7;
            static Osi = 7;
            static Ecma = 8;
            static DataKit = 9;
            static Ccitt = 10;
            static Sna = 11;
            static DecNet = 12;
            static DataLink = 13;
            static Lat = 14;
            static HyperChannel = 15;
            static AppleTalk = 16;
            static NetBios = 17;
            static VoiceView = 18;
            static FireFox = 19;
            static Banyan = 21;
            static Atm = 22;
            static InterNetworkV6 = 23;
            static Cluster = 24;
            static Ieee12844 = 25;
            static Irda = 26;
            static NetworkDesigners = 28;
            static Max = 29;
            static Packet = 65536;
            static ControllerAreaNetwork = 65537;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "Unspecified": 0n,
                    "Unix": 1n,
                    "InterNetwork": 2n,
                    "ImpLink": 3n,
                    "Pup": 4n,
                    "Chaos": 5n,
                    "NS": 6n,
                    "Ipx": 6n,
                    "Iso": 7n,
                    "Osi": 7n,
                    "Ecma": 8n,
                    "DataKit": 9n,
                    "Ccitt": 10n,
                    "Sna": 11n,
                    "DecNet": 12n,
                    "DataLink": 13n,
                    "Lat": 14n,
                    "HyperChannel": 15n,
                    "AppleTalk": 16n,
                    "NetBios": 17n,
                    "VoiceView": 18n,
                    "FireFox": 19n,
                    "Banyan": 21n,
                    "Atm": 22n,
                    "InterNetworkV6": 23n,
                    "Cluster": 24n,
                    "Ieee12844": 25n,
                    "Irda": 26n,
                    "NetworkDesigners": 28n,
                    "Max": 29n,
                    "Packet": 65536n,
                    "ControllerAreaNetwork": 65537n
                };
            }
            static $h = 4506357;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4506357,"n":"Unknown","d":4506357,"h":4299473653,"f":4194337},{"t":4506357,"n":"Unspecified","d":4506357,"h":8594440949,"f":4194337},{"t":4506357,"n":"Unix","d":4506357,"h":12889408245,"f":4194337},{"t":4506357,"n":"InterNetwork","d":4506357,"h":17184375541,"f":4194337},{"t":4506357,"n":"ImpLink","d":4506357,"h":21479342837,"f":4194337},{"t":4506357,"n":"Pup","d":4506357,"h":25774310133,"f":4194337},{"t":4506357,"n":"Chaos","d":4506357,"h":30069277429,"f":4194337},{"t":4506357,"n":"NS","d":4506357,"h":34364244725,"f":4194337},{"t":4506357,"n":"Ipx","d":4506357,"h":38659212021,"f":4194337},{"t":4506357,"n":"Iso","d":4506357,"h":42954179317,"f":4194337},{"t":4506357,"n":"Osi","d":4506357,"h":47249146613,"f":4194337},{"t":4506357,"n":"Ecma","d":4506357,"h":51544113909,"f":4194337},{"t":4506357,"n":"DataKit","d":4506357,"h":55839081205,"f":4194337},{"t":4506357,"n":"Ccitt","d":4506357,"h":60134048501,"f":4194337},{"t":4506357,"n":"Sna","d":4506357,"h":64429015797,"f":4194337},{"t":4506357,"n":"DecNet","d":4506357,"h":68723983093,"f":4194337},{"t":4506357,"n":"DataLink","d":4506357,"h":73018950389,"f":4194337},{"t":4506357,"n":"Lat","d":4506357,"h":77313917685,"f":4194337},{"t":4506357,"n":"HyperChannel","d":4506357,"h":81608884981,"f":4194337},{"t":4506357,"n":"AppleTalk","d":4506357,"h":85903852277,"f":4194337},{"t":4506357,"n":"NetBios","d":4506357,"h":90198819573,"f":4194337},{"t":4506357,"n":"VoiceView","d":4506357,"h":94493786869,"f":4194337},{"t":4506357,"n":"FireFox","d":4506357,"h":98788754165,"f":4194337},{"t":4506357,"n":"Banyan","d":4506357,"h":103083721461,"f":4194337},{"t":4506357,"n":"Atm","d":4506357,"h":107378688757,"f":4194337},{"t":4506357,"n":"InterNetworkV6","d":4506357,"h":111673656053,"f":4194337},{"t":4506357,"n":"Cluster","d":4506357,"h":115968623349,"f":4194337},{"t":4506357,"n":"Ieee12844","d":4506357,"h":120263590645,"f":4194337},{"t":4506357,"n":"Irda","d":4506357,"h":124558557941,"f":4194337},{"t":4506357,"n":"NetworkDesigners","d":4506357,"h":128853525237,"f":4194337},{"t":4506357,"n":"Max","d":4506357,"h":133148492533,"f":4194337},{"t":4506357,"n":"Packet","d":4506357,"h":137443459829,"f":4194337},{"t":4506357,"n":"ControllerAreaNetwork","d":4506357,"h":141738427125,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":4506357,"h":146033394421,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":4506357}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.AddressFamily`; }
        });
        
        $asm.$str("$snp.System.Net.Sockets.SocketError", ($self) => class SocketError extends $.$$.System.Enum
        {
            static Success = 0;
            static SocketError = -1;
            static Interrupted = 10004;
            static AccessDenied = 10013;
            static Fault = 10014;
            static InvalidArgument = 10022;
            static TooManyOpenSockets = 10024;
            static WouldBlock = 10035;
            static InProgress = 10036;
            static AlreadyInProgress = 10037;
            static NotSocket = 10038;
            static DestinationAddressRequired = 10039;
            static MessageSize = 10040;
            static ProtocolType = 10041;
            static ProtocolOption = 10042;
            static ProtocolNotSupported = 10043;
            static SocketNotSupported = 10044;
            static OperationNotSupported = 10045;
            static ProtocolFamilyNotSupported = 10046;
            static AddressFamilyNotSupported = 10047;
            static AddressAlreadyInUse = 10048;
            static AddressNotAvailable = 10049;
            static NetworkDown = 10050;
            static NetworkUnreachable = 10051;
            static NetworkReset = 10052;
            static ConnectionAborted = 10053;
            static ConnectionReset = 10054;
            static NoBufferSpaceAvailable = 10055;
            static IsConnected = 10056;
            static NotConnected = 10057;
            static Shutdown = 10058;
            static TimedOut = 10060;
            static ConnectionRefused = 10061;
            static HostDown = 10064;
            static HostUnreachable = 10065;
            static ProcessLimit = 10067;
            static SystemNotReady = 10091;
            static VersionNotSupported = 10092;
            static NotInitialized = 10093;
            static Disconnecting = 10101;
            static TypeNotFound = 10109;
            static HostNotFound = 11001;
            static TryAgain = 11002;
            static NoRecovery = 11003;
            static NoData = 11004;
            static IOPending = 997;
            static OperationAborted = 995;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Success": 0n,
                    "SocketError": -1n,
                    "Interrupted": 10004n,
                    "AccessDenied": 10013n,
                    "Fault": 10014n,
                    "InvalidArgument": 10022n,
                    "TooManyOpenSockets": 10024n,
                    "WouldBlock": 10035n,
                    "InProgress": 10036n,
                    "AlreadyInProgress": 10037n,
                    "NotSocket": 10038n,
                    "DestinationAddressRequired": 10039n,
                    "MessageSize": 10040n,
                    "ProtocolType": 10041n,
                    "ProtocolOption": 10042n,
                    "ProtocolNotSupported": 10043n,
                    "SocketNotSupported": 10044n,
                    "OperationNotSupported": 10045n,
                    "ProtocolFamilyNotSupported": 10046n,
                    "AddressFamilyNotSupported": 10047n,
                    "AddressAlreadyInUse": 10048n,
                    "AddressNotAvailable": 10049n,
                    "NetworkDown": 10050n,
                    "NetworkUnreachable": 10051n,
                    "NetworkReset": 10052n,
                    "ConnectionAborted": 10053n,
                    "ConnectionReset": 10054n,
                    "NoBufferSpaceAvailable": 10055n,
                    "IsConnected": 10056n,
                    "NotConnected": 10057n,
                    "Shutdown": 10058n,
                    "TimedOut": 10060n,
                    "ConnectionRefused": 10061n,
                    "HostDown": 10064n,
                    "HostUnreachable": 10065n,
                    "ProcessLimit": 10067n,
                    "SystemNotReady": 10091n,
                    "VersionNotSupported": 10092n,
                    "NotInitialized": 10093n,
                    "Disconnecting": 10101n,
                    "TypeNotFound": 10109n,
                    "HostNotFound": 11001n,
                    "TryAgain": 11002n,
                    "NoRecovery": 11003n,
                    "NoData": 11004n,
                    "IOPending": 997n,
                    "OperationAborted": 995n
                };
            }
            static $h = 4702965;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4702965,"n":"Success","d":4702965,"h":4299670261,"f":4194337},{"t":4702965,"n":"SocketError","d":4702965,"h":8594637557,"f":4194337},{"t":4702965,"n":"Interrupted","d":4702965,"h":12889604853,"f":4194337},{"t":4702965,"n":"AccessDenied","d":4702965,"h":17184572149,"f":4194337},{"t":4702965,"n":"Fault","d":4702965,"h":21479539445,"f":4194337},{"t":4702965,"n":"InvalidArgument","d":4702965,"h":25774506741,"f":4194337},{"t":4702965,"n":"TooManyOpenSockets","d":4702965,"h":30069474037,"f":4194337},{"t":4702965,"n":"WouldBlock","d":4702965,"h":34364441333,"f":4194337},{"t":4702965,"n":"InProgress","d":4702965,"h":38659408629,"f":4194337},{"t":4702965,"n":"AlreadyInProgress","d":4702965,"h":42954375925,"f":4194337},{"t":4702965,"n":"NotSocket","d":4702965,"h":47249343221,"f":4194337},{"t":4702965,"n":"DestinationAddressRequired","d":4702965,"h":51544310517,"f":4194337},{"t":4702965,"n":"MessageSize","d":4702965,"h":55839277813,"f":4194337},{"t":4702965,"n":"ProtocolType","d":4702965,"h":60134245109,"f":4194337},{"t":4702965,"n":"ProtocolOption","d":4702965,"h":64429212405,"f":4194337},{"t":4702965,"n":"ProtocolNotSupported","d":4702965,"h":68724179701,"f":4194337},{"t":4702965,"n":"SocketNotSupported","d":4702965,"h":73019146997,"f":4194337},{"t":4702965,"n":"OperationNotSupported","d":4702965,"h":77314114293,"f":4194337},{"t":4702965,"n":"ProtocolFamilyNotSupported","d":4702965,"h":81609081589,"f":4194337},{"t":4702965,"n":"AddressFamilyNotSupported","d":4702965,"h":85904048885,"f":4194337},{"t":4702965,"n":"AddressAlreadyInUse","d":4702965,"h":90199016181,"f":4194337},{"t":4702965,"n":"AddressNotAvailable","d":4702965,"h":94493983477,"f":4194337},{"t":4702965,"n":"NetworkDown","d":4702965,"h":98788950773,"f":4194337},{"t":4702965,"n":"NetworkUnreachable","d":4702965,"h":103083918069,"f":4194337},{"t":4702965,"n":"NetworkReset","d":4702965,"h":107378885365,"f":4194337},{"t":4702965,"n":"ConnectionAborted","d":4702965,"h":111673852661,"f":4194337},{"t":4702965,"n":"ConnectionReset","d":4702965,"h":115968819957,"f":4194337},{"t":4702965,"n":"NoBufferSpaceAvailable","d":4702965,"h":120263787253,"f":4194337},{"t":4702965,"n":"IsConnected","d":4702965,"h":124558754549,"f":4194337},{"t":4702965,"n":"NotConnected","d":4702965,"h":128853721845,"f":4194337},{"t":4702965,"n":"Shutdown","d":4702965,"h":133148689141,"f":4194337},{"t":4702965,"n":"TimedOut","d":4702965,"h":137443656437,"f":4194337},{"t":4702965,"n":"ConnectionRefused","d":4702965,"h":141738623733,"f":4194337},{"t":4702965,"n":"HostDown","d":4702965,"h":146033591029,"f":4194337},{"t":4702965,"n":"HostUnreachable","d":4702965,"h":150328558325,"f":4194337},{"t":4702965,"n":"ProcessLimit","d":4702965,"h":154623525621,"f":4194337},{"t":4702965,"n":"SystemNotReady","d":4702965,"h":158918492917,"f":4194337},{"t":4702965,"n":"VersionNotSupported","d":4702965,"h":163213460213,"f":4194337},{"t":4702965,"n":"NotInitialized","d":4702965,"h":167508427509,"f":4194337},{"t":4702965,"n":"Disconnecting","d":4702965,"h":171803394805,"f":4194337},{"t":4702965,"n":"TypeNotFound","d":4702965,"h":176098362101,"f":4194337},{"t":4702965,"n":"HostNotFound","d":4702965,"h":180393329397,"f":4194337},{"t":4702965,"n":"TryAgain","d":4702965,"h":184688296693,"f":4194337},{"t":4702965,"n":"NoRecovery","d":4702965,"h":188983263989,"f":4194337},{"t":4702965,"n":"NoData","d":4702965,"h":193278231285,"f":4194337},{"t":4702965,"n":"IOPending","d":4702965,"h":197573198581,"f":4194337},{"t":4702965,"n":"OperationAborted","d":4702965,"h":201868165877,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":4702965,"h":206163133173,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":4702965}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketError`; }
        });
        
        $asm.$str("$snp.System.Net.Cache.RequestCacheLevel", ($self) => class RequestCacheLevel extends $.$$.System.Enum
        {
            static Default = 0;
            static BypassCache = 1;
            static CacheOnly = 2;
            static CacheIfAvailable = 3;
            static Revalidate = 4;
            static Reload = 5;
            static NoCacheNoStore = 6;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "BypassCache": 1n,
                    "CacheOnly": 2n,
                    "CacheIfAvailable": 3n,
                    "Revalidate": 4n,
                    "Reload": 5n,
                    "NoCacheNoStore": 6n
                };
            }
            static $h = 1032949;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1032949,"n":"Default","d":1032949,"h":4296000245,"f":4194337},{"t":1032949,"n":"BypassCache","d":1032949,"h":8590967541,"f":4194337},{"t":1032949,"n":"CacheOnly","d":1032949,"h":12885934837,"f":4194337},{"t":1032949,"n":"CacheIfAvailable","d":1032949,"h":17180902133,"f":4194337},{"t":1032949,"n":"Revalidate","d":1032949,"h":21475869429,"f":4194337},{"t":1032949,"n":"Reload","d":1032949,"h":25770836725,"f":4194337},{"t":1032949,"n":"NoCacheNoStore","d":1032949,"h":30065804021,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1032949,"h":34360771317,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1032949}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Cache.RequestCacheLevel`; }
        });
        
        $asm.$str("$snp.System.Security.Authentication.ExchangeAlgorithmType", ($self) => class ExchangeAlgorithmType extends $.$$.System.Enum
        {
            static None = 0;
            static RsaSign = 9216;
            static RsaKeyX = 41984;
            static DiffieHellman = 43522;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "RsaSign": 9216n,
                    "RsaKeyX": 41984n,
                    "DiffieHellman": 43522n
                };
            }
            static $h = 5358325;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5358325,"n":"None","d":5358325,"h":4300325621,"f":4194337},{"t":5358325,"n":"RsaSign","d":5358325,"h":8595292917,"f":4194337},{"t":5358325,"n":"RsaKeyX","d":5358325,"h":12890260213,"f":4194337},{"t":5358325,"n":"DiffieHellman","d":5358325,"h":17185227509,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":5358325,"h":21480194805,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":5358325,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExchangeAlgorithmType`; }
        });
        
        $asm.$str("$snp.System.Security.Authentication.CipherAlgorithmType", ($self) => class CipherAlgorithmType extends $.$$.System.Enum
        {
            static None = 0;
            static Rc2 = 26114;
            static Rc4 = 26625;
            static Des = 26113;
            static TripleDes = 26115;
            static Aes = 26129;
            static Aes128 = 26126;
            static Aes192 = 26127;
            static Aes256 = 26128;
            static Null = 24576;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Rc2": 26114n,
                    "Rc4": 26625n,
                    "Des": 26113n,
                    "TripleDes": 26115n,
                    "Aes": 26129n,
                    "Aes128": 26126n,
                    "Aes192": 26127n,
                    "Aes256": 26128n,
                    "Null": 24576n
                };
            }
            static $h = 5292789;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5292789,"n":"None","d":5292789,"h":4300260085,"f":4194337},{"t":5292789,"n":"Rc2","d":5292789,"h":8595227381,"f":4194337},{"t":5292789,"n":"Rc4","d":5292789,"h":12890194677,"f":4194337},{"t":5292789,"n":"Des","d":5292789,"h":17185161973,"f":4194337},{"t":5292789,"n":"TripleDes","d":5292789,"h":21480129269,"f":4194337},{"t":5292789,"n":"Aes","d":5292789,"h":25775096565,"f":4194337},{"t":5292789,"n":"Aes128","d":5292789,"h":30070063861,"f":4194337},{"t":5292789,"n":"Aes192","d":5292789,"h":34365031157,"f":4194337},{"t":5292789,"n":"Aes256","d":5292789,"h":38659998453,"f":4194337},{"t":5292789,"n":"Null","d":5292789,"h":42954965749,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":5292789,"h":47249933045,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":5292789,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.CipherAlgorithmType`; }
        });
        
        $asm.$str("$snp.System.Security.Authentication.HashAlgorithmType", ($self) => class HashAlgorithmType extends $.$$.System.Enum
        {
            static None = 0;
            static Md5 = 32771;
            static Sha1 = 32772;
            static Sha256 = 32780;
            static Sha384 = 32781;
            static Sha512 = 32782;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Md5": 32771n,
                    "Sha1": 32772n,
                    "Sha256": 32780n,
                    "Sha384": 32781n,
                    "Sha512": 32782n
                };
            }
            static $h = 5554933;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5554933,"n":"None","d":5554933,"h":4300522229,"f":4194337},{"t":5554933,"n":"Md5","d":5554933,"h":8595489525,"f":4194337},{"t":5554933,"n":"Sha1","d":5554933,"h":12890456821,"f":4194337},{"t":5554933,"n":"Sha256","d":5554933,"h":17185424117,"f":4194337},{"t":5554933,"n":"Sha384","d":5554933,"h":21480391413,"f":4194337},{"t":5554933,"n":"Sha512","d":5554933,"h":25775358709,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":5554933,"h":30070326005,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":5554933,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.HashAlgorithmType`; }
        });
        
        $asm.$str("$snp.System.Security.Authentication.ExtendedProtection.ChannelBindingKind", ($self) => class ChannelBindingKind extends $.$$.System.Enum
        {
            static Unknown = 0;
            static Unique = 25;
            static Endpoint = 26;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Unique": 25n,
                    "Endpoint": 26n
                };
            }
            static $h = 5489397;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5489397,"n":"Unknown","d":5489397,"h":4300456693,"f":4194337},{"t":5489397,"n":"Unique","d":5489397,"h":8595423989,"f":4194337},{"t":5489397,"n":"Endpoint","d":5489397,"h":12890391285,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":5489397,"h":17185358581,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":5489397}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ChannelBindingKind`; }
        });
        
        $asm.$str("$snp.System.Net.CookieToken", ($self) => class CookieToken extends $.$$.System.Enum
        {
            static Nothing = 0;
            static NameValuePair = 1;
            static Attribute = 2;
            static EndToken = 3;
            static EndCookie = 4;
            static End = 5;
            static Equals = 6;
            static Comment = 7;
            static CommentUrl = 8;
            static CookieName = 9;
            static Discard = 10;
            static Domain = 11;
            static Expires = 12;
            static MaxAge = 13;
            static Path = 14;
            static Port = 15;
            static Secure = 16;
            static HttpOnly = 17;
            static Unknown = 18;
            static Version = 19;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Nothing": 0n,
                    "NameValuePair": 1n,
                    "Attribute": 2n,
                    "EndToken": 3n,
                    "EndCookie": 4n,
                    "End": 5n,
                    "Equals": 6n,
                    "Comment": 7n,
                    "CommentUrl": 8n,
                    "CookieName": 9n,
                    "Discard": 10n,
                    "Domain": 11n,
                    "Expires": 12n,
                    "MaxAge": 13n,
                    "Path": 14n,
                    "Port": 15n,
                    "Secure": 16n,
                    "HttpOnly": 17n,
                    "Unknown": 18n,
                    "Version": 19n
                };
            }
            static $h = 1688309;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1688309,"n":"Nothing","d":1688309,"h":4296655605,"f":4194337},{"t":1688309,"n":"NameValuePair","d":1688309,"h":8591622901,"f":4194337},{"t":1688309,"n":"Attribute","d":1688309,"h":12886590197,"f":4194337},{"t":1688309,"n":"EndToken","d":1688309,"h":17181557493,"f":4194337},{"t":1688309,"n":"EndCookie","d":1688309,"h":21476524789,"f":4194337},{"t":1688309,"n":"End","d":1688309,"h":25771492085,"f":4194337},{"t":1688309,"n":"Equals","o":"@$2","d":1688309,"h":30066459381,"f":4194337},{"t":1688309,"n":"Comment","d":1688309,"h":34361426677,"f":4194337},{"t":1688309,"n":"CommentUrl","d":1688309,"h":38656393973,"f":4194337},{"t":1688309,"n":"CookieName","d":1688309,"h":42951361269,"f":4194337},{"t":1688309,"n":"Discard","d":1688309,"h":47246328565,"f":4194337},{"t":1688309,"n":"Domain","d":1688309,"h":51541295861,"f":4194337},{"t":1688309,"n":"Expires","d":1688309,"h":55836263157,"f":4194337},{"t":1688309,"n":"MaxAge","d":1688309,"h":60131230453,"f":4194337},{"t":1688309,"n":"Path","d":1688309,"h":64426197749,"f":4194337},{"t":1688309,"n":"Port","d":1688309,"h":68721165045,"f":4194337},{"t":1688309,"n":"Secure","d":1688309,"h":73016132341,"f":4194337},{"t":1688309,"n":"HttpOnly","d":1688309,"h":77311099637,"f":4194337},{"t":1688309,"n":"Unknown","d":1688309,"h":81606066933,"f":4194337},{"t":1688309,"n":"Version","d":1688309,"h":85901034229,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1688309,"h":90196001525,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1688309}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.CookieToken`; }
        });
        
        $asm.$str("$snp.System.Net.Security.AuthenticationLevel", ($self) => class AuthenticationLevel extends $.$$.System.Enum
        {
            static None = 0;
            static MutualAuthRequested = 1;
            static MutualAuthRequired = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "MutualAuthRequested": 1n,
                    "MutualAuthRequired": 2n
                };
            }
            static $h = 4244213;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4244213,"n":"None","d":4244213,"h":4299211509,"f":4194337},{"t":4244213,"n":"MutualAuthRequested","d":4244213,"h":8594178805,"f":4194337},{"t":4244213,"n":"MutualAuthRequired","d":4244213,"h":12889146101,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":4244213,"h":17184113397,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":4244213}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.AuthenticationLevel`; }
        });
        
        $asm.$str("$snp.System.Net.CookieVariant", ($self) => class CookieVariant extends $.$$.System.Enum
        {
            static Unknown = 0;
            static Plain = 1;
            static Rfc2109 = 2;
            static Rfc2965 = 3;
            static Default = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Plain": 1n,
                    "Rfc2109": 2n,
                    "Rfc2965": 3n,
                    "Default": 2n
                };
            }
            static $h = 1884917;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1884917,"n":"Unknown","d":1884917,"h":4296852213,"f":4194337},{"t":1884917,"n":"Plain","d":1884917,"h":8591819509,"f":4194337},{"t":1884917,"n":"Rfc2109","d":1884917,"h":12886786805,"f":4194337},{"t":1884917,"n":"Rfc2965","d":1884917,"h":17181754101,"f":4194337},{"t":1884917,"n":"Default","d":1884917,"h":21476721397,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1884917,"h":25771688693,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1884917,"a":[{"t":96141313,"c":4391108609,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.CookieVariant`; }
        });
        
        $asm.$cls("$snp.System.Net.NetworkInformation.IPAddressCollection", ($self) => class IPAddressCollection extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*void */ CopyTo(/*IPAddress[]*/ array, /*int*/ offset)
            {
                throw $.$snp.System.NotImplemented.ByDesign;
            }
            /*int */ get Count()
            {
                throw $.$snp.System.NotImplemented.ByDesign;
            }
            /*bool */ get IsReadOnly()
            {
                return true;
            }
            /*void */ Add(/*IPAddress*/ address)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$snp.System.SR.net_collection_readonly);
            }
            /*bool */ Contains(/*IPAddress*/ address)
            {
                throw $.$snp.System.NotImplemented.ByDesign;
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            /*IEnumerator<IPAddress> */ GetEnumerator()
            {
                throw $.$snp.System.NotImplemented.ByDesign;
            }
            /*IPAddress*/ get_Item(/*int*/ index)
            {
                throw $.$snp.System.NotImplemented.ByDesign;
            }
            /*bool */ Remove(/*IPAddress*/ address)
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$snp.System.SR.net_collection_readonly);
            }
            /*void */ Clear()
            {
                throw new $.$$.System.NotSupportedException().$ctor$12($.$snp.System.SR.net_collection_readonly);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.IPAddress>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.IPAddress>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.IPAddress>.Add(System.Net.IPAddress)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.IPAddress>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.IPAddress>.Contains(System.Net.IPAddress)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.IPAddress>.CopyTo(System.Net.IPAddress[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.IPAddress>.Remove(System.Net.IPAddress)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.IPAddress>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 4047605;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17183916789,"f":50331777},"n":"Count","d":4047605,"h":12888949493,"f":2097281},{"p":262145,"g":{"r":0,"d":0,"h":25773851381,"f":50331777},"n":"IsReadOnly","d":4047605,"h":21478884085,"f":2097281},{"p":3064565,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":51543655157,"f":50331777},"n":"Item","o":"@$2","d":4047605,"h":47248687861,"f":2097281}],"m":[{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$snp.System.Net.IPAddress).$h},{"n":"offset","p":655361}],"n":"CopyTo","d":4047605,"h":8593982197,"f":16777345},{"r":65537,"p":[{"n":"address","p":3064565}],"n":"Add","d":4047605,"h":30068818677,"f":16777345},{"r":262145,"p":[{"n":"address","p":3064565}],"n":"Contains","d":4047605,"h":34363785973,"f":16777345},{"r":$.$$.System.Collections.Generic.IEnumerator$$($.$snp.System.Net.IPAddress).$h,"n":"GetEnumerator","d":4047605,"h":42953720565,"f":16777345},{"r":262145,"p":[{"n":"address","p":3064565}],"n":"Remove","d":4047605,"h":55838622453,"f":16777345},{"r":65537,"n":"Clear","d":4047605,"h":60133589749,"f":16777345}],"c":[{"n":".ctor","o":"$ctor$1","d":4047605,"h":4299014901,"f":16777232}],"i":[$.$$.System.Collections.Generic.ICollection$$($.$snp.System.Net.IPAddress).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$snp.System.Net.IPAddress).$h,31719425],"h":4047605}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$($.$snp.System.Net.IPAddress), $.$$.System.Collections.Generic.IEnumerable$$($.$snp.System.Net.IPAddress), $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressCollection`; }
        });
        
        $asm.$cls("$snp.System.Net.CookieCollection", ($self) => class CookieCollection extends $.$$.System.Object
        {
            static $_Stamp;
            static get Stamp()
            {
                let $cls = $.$snp.System.Net.CookieCollection;
                return $cls.$_Stamp ??= $asm.$nstr("$snp.System.Net.CookieCollection.Stamp", ($self) => class Stamp extends $.$$.System.Enum
                {
                    static Check = 0;
                    static Set = 1;
                    static SetToUnused = 2;
                    static SetToMaxUsed = 3;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Check": 0n,
                            "Set": 1n,
                            "SetToUnused": 2n,
                            "SetToMaxUsed": 3n
                        };
                    }
                    static $h = 1295093;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$$.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1295093,"n":"Check","d":1295093,"h":4296262389,"f":4194337},{"t":1295093,"n":"Set","d":1295093,"h":8591229685,"f":4194337},{"t":1295093,"n":"SetToUnused","d":1295093,"h":12886196981,"f":4194337},{"t":1295093,"n":"SetToMaxUsed","d":1295093,"h":17181164277,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1295093,"h":21476131573,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"d":1229557,"h":1295093}; }
                    static get $b() { return $.$$.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
                    static get $fullName() { return `System.Net.CookieCollection.Stamp`; }
                }, $cls, ($v) => $cls.$_Stamp = $v);
            }
            /*ArrayList*/ m_list = null;
            /*int*/ m_version = 0;
            /*DateTime*/ m_TimeStamp;
            /*bool*/ m_has_other_versions = false;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*Cookie*/ get_Item(/*int*/ index)
            {
                $.$$.System.ArgumentOutOfRangeException.ThrowIfNegative($.$$.System.Int32, index, "index");
                $.$$.System.ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual($.$$.System.Int32, index, this.m_list.Count, "index");
                return ($.$as(this.m_list.get_Item(index), $.$snp.System.Net.Cookie));
            }
            /*Cookie?*/ get_Item$1(/*string*/ name)
            {
                var $en2 = this.m_list.GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var c = $en2.System$Collections$IEnumerator$Current;
                    {
                        if ($.$$.System.String.Equals$2(c.Name, name, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            return c;
                        }
                    }
                }
                return null;
            }
            /*void */ OnSerializing(/*StreamingContext*/ context)
            {
                this.m_version = this.m_list.Count;
            }
            /*void */ Add(/*Cookie*/ cookie)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(cookie, "cookie");
                /*int*/ let idx = this.IndexOf(cookie);
                if (idx === -1)
                {
                    this.m_list.Add(cookie);
                }
                else 
                {
                    this.m_list.set_Item(idx, cookie);
                }
            }
            /*void */ Add$1(/*CookieCollection*/ cookies)
            {
                $.$$.System.ArgumentNullException.ThrowIfNull$2(cookies, "cookies");
                var $en2 = cookies.m_list.GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var cookie = $en2.System$Collections$IEnumerator$Current;
                    {
                        this.Add(cookie);
                    }
                }
            }
            /*void */ Clear()
            {
                this.m_list.Clear();
            }
            /*bool */ Contains(/*Cookie*/ cookie)
            {
                return this.IndexOf(cookie) >= 0;
            }
            /*bool */ Remove(/*Cookie*/ cookie)
            {
                /*int*/ let idx = this.IndexOf(cookie);
                if (idx === -1)
                {
                    return false;
                }
                this.m_list.RemoveAt(idx);
                return true;
            }
            /*bool */ get IsReadOnly()
            {
                return false;
            }
            /*int */ get Count()
            {
                return this.m_list.Count;
            }
            /*bool */ get IsSynchronized()
            {
                return false;
            }
            /*object */ get SyncRoot()
            {
                return this;
            }
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                (this.m_list).System$Collections$ICollection$CopyTo(array, index);
            }
            /*void */ CopyTo$1(/*Cookie[]*/ array, /*int*/ index)
            {
                this.m_list.CopyTo(array, index);
            }
            /*DateTime */ TimeStamp(/*Stamp*/ how)
            {
                switch(how)
                {
                    case 1/*Stamp.Set*/:
                    this.m_TimeStamp = $.$$.System.DateTime.Now;
                    break;
                    case 3/*Stamp.SetToMaxUsed*/:
                    this.m_TimeStamp = $.$$.System.DateTime.MaxValue;
                    break;
                    case 2/*Stamp.SetToUnused*/:
                    this.m_TimeStamp = $.$$.System.DateTime.MinValue;
                    break;
                    case 0/*Stamp.Check*/:
                    default:
                    break;
                }
                return this.m_TimeStamp;
            }
            /*bool */ get IsOtherVersionSeen()
            {
                return this.m_has_other_versions;
            }
            /*int */ InternalAdd(/*Cookie*/ cookie, /*bool*/ isStrict)
            {
                /*int*/ let ret = 1;
                if (isStrict)
                {
                    /*int*/ let idx = 0;
                    /*int*/ let listCount = this.m_list.Count;
                    for(/*int*/ let i = 0; i < listCount; i++)
                    {
                        /*Cookie*/ let c = $.$cast(this.m_list.get_Item(i), $.$snp.System.Net.Cookie);
                        if ($.$snp.System.Net.CookieComparer.Equals$2(cookie, c))
                        {
                            ret = 0;
                            if (c.Variant <= cookie.Variant)
                            {
                                this.m_list.set_Item(idx, cookie);
                            }
                            break;
                        }
                        ++idx;
                    }
                    if (idx === this.m_list.Count)
                    {
                        this.m_list.Add(cookie);
                    }
                }
                else 
                {
                    this.m_list.Add(cookie);
                }
                if (cookie.Version !== 1/*Cookie.MaxSupportedVersion*/)
                {
                    this.m_has_other_versions = true;
                }
                return ret;
            }
            /*int */ IndexOf(/*Cookie*/ cookie)
            {
                /*int*/ let idx = 0;
                var $en2 = this.m_list.GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var c = $en2.System$Collections$IEnumerator$Current;
                    {
                        if ($.$snp.System.Net.CookieComparer.Equals$2(cookie, c))
                        {
                            return idx;
                        }
                        ++idx;
                    }
                }
                return -1;
            }
            /*void */ RemoveAt(/*int*/ idx)
            {
                this.m_list.RemoveAt(idx);
            }
            /*IEnumerator<Cookie> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return new ($.$$.NetJs.YieldToIterator$$($.$snp.System.Net.Cookie))().$ctor$1(function*()
                {
                    var $en3 = this.m_list.GetEnumerator();
                    while ($en3.System$Collections$IEnumerator$MoveNext())
                    {
                        var cookie = $en3.System$Collections$IEnumerator$Current;
                        {
                            yield cookie;
                        }
                    }
                }.bind(this)).GetEnumerator();
            }
            /*IEnumerator */ GetEnumerator()
            {
                return this.m_list.GetEnumerator();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.Cookie>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.Cookie>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.Cookie>.Add(System.Net.Cookie)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.Cookie>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.Cookie>.Contains(System.Net.Cookie)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.Cookie>.CopyTo(System.Net.Cookie[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo$1(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.Cookie>.Remove(System.Net.Cookie)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Net.Cookie>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.m_list = new $.$$.System.Collections.ArrayList().$ctor$1();
                this.m_TimeStamp = $.$$.System.DateTime.MinValue;
            }
            static $h = 1229557;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1164021,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":34360967925,"f":50331649},"n":"Item","o":"@$2","d":1229557,"h":30066000629,"f":2097153},{"p":1164021,"i":[{"n":"name","p":1310721}],"g":{"r":0,"d":0,"h":42950902517,"f":50331649},"n":"Item","o":"@$3","d":1229557,"h":38655935221,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":77310640885,"f":50331649},"n":"IsReadOnly","d":1229557,"h":73015673589,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":85900575477,"f":50331649},"n":"Count","d":1229557,"h":81605608181,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":94490510069,"f":50331649},"n":"IsSynchronized","d":1229557,"h":90195542773,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":103080444661,"f":50331649},"n":"SyncRoot","d":1229557,"h":98785477365,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":124555281141,"f":50331656},"n":"IsOtherVersionSeen","d":1229557,"h":120260313845,"f":2097160}],"m":[{"r":65537,"p":[{"n":"context","p":113967105}],"n":"OnSerializing","d":1229557,"h":47245869813,"f":16777218,"a":[{"t":113508353,"c":4408475649}]},{"r":65537,"p":[{"n":"cookie","p":1164021}],"n":"Add","d":1229557,"h":51540837109,"f":16777217},{"r":65537,"p":[{"n":"cookies","p":1229557}],"n":"Add","o":"@$1","d":1229557,"h":55835804405,"f":16777217},{"r":65537,"n":"Clear","d":1229557,"h":60130771701,"f":16777217},{"r":262145,"p":[{"n":"cookie","p":1164021}],"n":"Contains","d":1229557,"h":64425738997,"f":16777217},{"r":262145,"p":[{"n":"cookie","p":1164021}],"n":"Remove","d":1229557,"h":68720706293,"f":16777217},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":1229557,"h":107375411957,"f":16777217},{"r":65537,"p":[{"n":"array","p":$.$typeArray($.$snp.System.Net.Cookie).$h},{"n":"index","p":655361}],"n":"CopyTo","o":"@$1","d":1229557,"h":111670379253,"f":16777217},{"r":34275329,"p":[{"n":"how","p":1295093}],"n":"TimeStamp","d":1229557,"h":115965346549,"f":16777224},{"r":655361,"p":[{"n":"cookie","p":1164021},{"n":"isStrict","p":262145}],"n":"InternalAdd","d":1229557,"h":128850248437,"f":16777224},{"r":655361,"p":[{"n":"cookie","p":1164021}],"n":"IndexOf","d":1229557,"h":133145215733,"f":16777224},{"r":65537,"p":[{"n":"idx","p":655361}],"n":"RemoveAt","d":1229557,"h":137440183029,"f":16777224},{"r":31850497,"n":"GetEnumerator","d":1229557,"h":146030117621,"f":16777217}],"l":[{"t":23724033,"n":"m_list","d":1229557,"h":8591164149,"f":4194306},{"t":655361,"n":"m_version","d":1229557,"h":12886131445,"f":4194306},{"t":34275329,"n":"m_TimeStamp","d":1229557,"h":17181098741,"f":4194306},{"t":262145,"n":"m_has_other_versions","d":1229557,"h":21476066037,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$1","d":1229557,"h":25771033333,"f":16777217}],"i":[$.$$.System.Collections.Generic.ICollection$$($.$snp.System.Net.Cookie).$h,$.$$.System.Collections.Generic.IReadOnlyCollection$$($.$snp.System.Net.Cookie).$h,$.$$.System.Collections.Generic.IEnumerable$$($.$snp.System.Net.Cookie).$h,31457281,31719425],"j":[1295093],"h":1229557,"a":[{"t":118095873,"c":4413063169},{"t":96141313,"c":4391108609,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.Generic.ICollection$$($.$snp.System.Net.Cookie), $.$$.System.Collections.Generic.IReadOnlyCollection$$($.$snp.System.Net.Cookie), $.$$.System.Collections.Generic.IEnumerable$$($.$snp.System.Net.Cookie), $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.CookieCollection`; }
        });
        
        $asm.$cls("$snp.System.Net.NetEventSource", ($self) => class NetEventSource extends $.$$.System.Diagnostics.Tracing.EventSource
        {
            /*string*/ static EventSourceSuppressMessage$1 = null;
            /*NetEventSource*/ static Log = null;
            static $_Keywords;
            static get Keywords()
            {
                let $cls = $.$snp.System.Net.NetEventSource;
                return $cls.$_Keywords ??= $asm.$ncls("$snp.System.Net.NetEventSource.Keywords", ($self) => class Keywords
                {
                    /*EventKeywords*/ static Default = 1n;
                    /*EventKeywords*/ static Debug = 2n;
                    static $h = 3785461;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":40894465,"n":"Default","d":3785461,"h":4298752757,"f":4194337},{"t":40894465,"n":"Debug","d":3785461,"h":8593720053,"f":4194337}],"d":3719925,"h":3785461}; }
                    static get $b() { return $.$$.System.Object; }
                    static get $fullName() { return `System.Net.NetEventSource.Keywords`; }
                }, $cls, ($v) => $cls.$_Keywords = $v);
            }
            /*string*/ static MissingMember = null;
            /*string*/ static NullInstance = null;
            /*string*/ static StaticMethodObject = null;
            /*string*/ static NoParameters = null;
            /*int*/ static InfoEventId = 1;
            /*int*/ static ErrorEventId = 2;
            /*int*/ static NextAvailableEventId = 5;
            static /*void */ Info(/*object?*/ thisOrContextObject, /*FormattableString?*/ formattableString, /*string?*/ memberName)
            {
                return $.$snp.System.Net.NetEventSource.Log.Info$2($.$snp.System.Net.NetEventSource.IdOf(thisOrContextObject), memberName, formattableString !== null ? $.$snp.System.Net.NetEventSource.Format(formattableString) : ""/*NoParameters*/);
            }
            static /*void */ Info$1(/*object?*/ thisOrContextObject, /*object?*/ message, /*string?*/ memberName)
            {
                return $.$snp.System.Net.NetEventSource.Log.Info$2($.$snp.System.Net.NetEventSource.IdOf(thisOrContextObject), memberName, $.$snp.System.Net.NetEventSource.Format$1(message));
            }
            /*void */ Info$2(/*string*/ thisOrContextObject, /*string?*/ memberName, /*string?*/ message)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this.IsEnabled(), "IsEnabled()");
                this.WriteEvent$15(1/*InfoEventId*/, thisOrContextObject, memberName ?? "(?)"/*MissingMember*/, message);
            }
            static /*void */ Error(/*object?*/ thisOrContextObject, /*FormattableString*/ formattableString, /*string?*/ memberName)
            {
                return $.$snp.System.Net.NetEventSource.Log.ErrorMessage($.$snp.System.Net.NetEventSource.IdOf(thisOrContextObject), memberName, $.$snp.System.Net.NetEventSource.Format(formattableString));
            }
            static /*void */ Error$1(/*object?*/ thisOrContextObject, /*object*/ message, /*string?*/ memberName)
            {
                return $.$snp.System.Net.NetEventSource.Log.ErrorMessage($.$snp.System.Net.NetEventSource.IdOf(thisOrContextObject), memberName, $.$snp.System.Net.NetEventSource.Format$1(message));
            }
            /*void */ ErrorMessage(/*string*/ thisOrContextObject, /*string?*/ memberName, /*string?*/ message)
            {
                $.$$.System.Diagnostics.Debug.Assert$2(this.IsEnabled(), "IsEnabled()");
                this.WriteEvent$15(2/*ErrorEventId*/, thisOrContextObject, memberName ?? "(?)"/*MissingMember*/, message);
            }
            static /*string */ IdOf(/*object?*/ value)
            {
                return value !== null ? $.$$.System.Object.GetType.call(value).Name + "#" + $.$snp.System.Net.NetEventSource.GetHashCode$1(value) : "(null)"/*NullInstance*/;
            }
            static /*int */ GetHashCode$1(/*object?*/ value)
            {
                const $t1 = value;
                return $.$ifnn($t1, ($t) => $.$$.System.Object.GetHashCode.call($t)) ?? 0;
            }
            static /*string? */ Format$1(/*object?*/ value)
            {
                if (value === null)
                {
                    return "(null)"/*NullInstance*/;
                }
                /*string?*/ let result = null;
                //$.$snp.System.Net.NetEventSource.AdditionalCustomizedToString(value, $.$ref(() => result, ($v) => result = $v, $.$$.System.String));
                if (!(result === null))
                {
                    return result;
                }
                let arr;
                if ($.$is(value, $.$$.System.Array, { set $v(v){ arr = v; } }))
                {
                    return `${$.$$.System.Type.ToString.call($.$$.System.Object.GetType.call(arr).GetElementType())}[${($.$cast(value, $.$$.System.Array)).length}]`;
                }
                let c;
                if ($.$is(value, $.$$.System.Collections.ICollection, { set $v(v){ c = v; } }))
                {
                    return `${$.$$.System.Object.GetType.call(c).Name}(${c.System$Collections$ICollection$Count})`;
                }
                let handle;
                if ($.$is(value, $.$$.System.Runtime.InteropServices.SafeHandle, { set $v(v){ handle = v; } }))
                {
                    return (() =>
                    {
                        var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(3, 3);
                        $handler.AppendFormatted($.$box($.$$.System.Object.GetType.call(handle).Name, $.$$.System.String), null, null);
                        $handler.AppendLiteral(":");
                        $handler.AppendFormatted($.$box($.$$.System.Object.GetHashCode.call(handle), $.$$.System.Int32), null, null);
                        $handler.AppendLiteral("(0x");
                        $handler.AppendFormatted($.$box(handle.DangerousGetHandle(), $.$$.System.IntPtr), null, "X");
                        $handler.AppendLiteral(")");
                        return $handler.ToStringAndClear                ();
                    })();
                }
                if ($.$is(value, $.$$.System.IntPtr))
                {
                    return (() =>
                    {
                        var $handler = new $.$$.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$5(1, 1);
                        $handler.AppendLiteral("0x");
                        $handler.AppendFormatted(value, null, "X");
                        return $handler.ToStringAndClear                ();
                    })();
                }
                /*string?*/ let toString = $.$$.System.Object.ToString.call(value);
                if ($.$$.System.String.op_Equality(toString, null) || $.$$.System.String.op_Equality(toString, $.$$.System.Object.GetType.call(value).FullName))
                {
                    return $.$snp.System.Net.NetEventSource.IdOf(value);
                }
                return $.$$.System.Object.ToString.call(value);
            }
            static /*string */ Format(/*FormattableString*/ s)
            {
                let $switch1 = s.ArgumentCount;
                switch($switch1)
                {
                    case 0:
                    return s.Format;
                    case 1:
                    return $.$$.System.String.Format$9(s.Format, $.$snp.System.Net.NetEventSource.Format$1(s.GetArgument(0)));
                    case 2:
                    return $.$$.System.String.Format$8(s.Format, $.$snp.System.Net.NetEventSource.Format$1(s.GetArgument(0)), $.$snp.System.Net.NetEventSource.Format$1(s.GetArgument(1)));
                    case 3:
                    return $.$$.System.String.Format$7(s.Format, $.$snp.System.Net.NetEventSource.Format$1(s.GetArgument(0)), $.$snp.System.Net.NetEventSource.Format$1(s.GetArgument(1)), $.$snp.System.Net.NetEventSource.Format$1(s.GetArgument(2)));
                    default:
                    /*string?[]*/ let formattedArgs = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$$.System.String), null, [s.ArgumentCount], null);
                    for(/*int*/ let i = 0; i < formattedArgs.length; i++)
                    {
                        $.$$.System.Array.$WriteT1.call(formattedArgs, $.$snp.System.Net.NetEventSource.Format$1(s.GetArgument(i)), i);
                    }
                    return $.$$.System.String.Format$11(s.Format, $.$$.System.ReadOnlySpan$$($.$$.System.Object).op_Implicit$1(formattedArgs));
                }
            }
            /*void */ WriteEvent$19(/*int*/ eventId, /*string?*/ arg1, /*string?*/ arg2, /*int*/ arg3)
            {
                arg1 ??= "";
                arg2 ??= "";
                /*fixed*/ 
                {
                    /*char**/ let arg1Ptr = $.$$.System.String.GetPinnableReference.call(arg1);
                    /*fixed*/ 
                    {
                        /*char**/ let arg2Ptr = $.$$.System.String.GetPinnableReference.call(arg2);
                        /*int*/ let NumEventDatas = 3;
                        /*EventData**/ let descrs = $.$$.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$$.System.Diagnostics.Tracing.EventSource.EventData, NumEventDatas, null);
                        descrs.SetAt((() =>
                        {
                            //new $.$$.System.Diagnostics.Tracing.EventSource.EventData()
                            const $t1 = $.$$.System.Diagnostics.Tracing.EventSource.EventData;
                            const $i1 = new $t1();
                            $i1.DataPointer = $.$cast((arg1Ptr), $.$$.System.IntPtr);
                            $i1.Size = (((((arg1.length + 1) | 0)) * $.$$.System.Char.$z) | 0);
                            return $i1;
                        })(), 0);
                        descrs.SetAt((() =>
                        {
                            //new $.$$.System.Diagnostics.Tracing.EventSource.EventData()
                            const $t2 = $.$$.System.Diagnostics.Tracing.EventSource.EventData;
                            const $i2 = new $t2();
                            $i2.DataPointer = $.$cast((arg2Ptr), $.$$.System.IntPtr);
                            $i2.Size = (((((arg2.length + 1) | 0)) * $.$$.System.Char.$z) | 0);
                            return $i2;
                        })(), 1);
                        descrs.SetAt((() =>
                        {
                            //new $.$$.System.Diagnostics.Tracing.EventSource.EventData()
                            const $t3 = $.$$.System.Diagnostics.Tracing.EventSource.EventData;
                            const $i3 = new $t3();
                            $i3.DataPointer = $.$cast(($.$$.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$$.System.Int32, () => arg3, ($v) => arg3 = $v, null)), $.$$.System.IntPtr);
                            $i3.Size = $.$$.System.Int32.$z;
                            return $i3;
                        })(), 2);
                        this.WriteEventCore(eventId, NumEventDatas, descrs);
                    }
                }
            }
            //default reference type constructor overload
            $ctor$10()
            {
                super.$ctor$1();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.EventSourceSuppressMessage$1 = "Parameters to this method are primitive and are trimmer safe";
                }
                {
                    this.Log = new $.$snp.System.Net.NetEventSource().$ctor$10();
                }
                {
                    this.MissingMember = "(?)";
                }
                {
                    this.NullInstance = "(null)";
                }
                {
                    this.StaticMethodObject = "(static)";
                }
                {
                    this.NoParameters = "";
                }
            }
            static $h = 3719925;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":41746433,"m":[{"r":65537,"p":[{"n":"thisOrContextObject","p":131073},{"n":"formattableString","p":47841281,"f":65},{"n":"memberName","p":1310721,"f":65,"a":[{"t":88014849,"c":4382982145}]}],"n":"Info","d":3719925,"h":47248360181,"f":16777249,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":131073},{"n":"message","p":131073},{"n":"memberName","p":1310721,"f":65,"a":[{"t":88014849,"c":4382982145}]}],"n":"Info","o":"@$1","d":3719925,"h":51543327477,"f":16777249,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"memberName","p":1310721},{"n":"message","p":1310721}],"n":"Info","o":"@$2","d":3719925,"h":55838294773,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":1,"t":655361}],"n":[{"n":"Level","v":4,"t":40960001},{"n":"Keywords","v":1,"t":40894465}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":131073},{"n":"formattableString","p":47841281},{"n":"memberName","p":1310721,"f":65,"a":[{"t":88014849,"c":4382982145}]}],"n":"Error","d":3719925,"h":60133262069,"f":16777249,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":131073},{"n":"message","p":131073},{"n":"memberName","p":1310721,"f":65,"a":[{"t":88014849,"c":4382982145}]}],"n":"Error","o":"@$1","d":3719925,"h":64428229365,"f":16777249,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"memberName","p":1310721},{"n":"message","p":1310721}],"n":"ErrorMessage","d":3719925,"h":68723196661,"f":16777218,"a":[{"t":39976961,"c":4334944257,"a":[{"v":2,"t":655361}],"n":[{"n":"Level","v":2,"t":40960001},{"n":"Keywords","v":1,"t":40894465}]}]},{"r":1310721,"p":[{"n":"value","p":131073}],"n":"IdOf","d":3719925,"h":73018163957,"f":16777249,"a":[{"t":44302337,"c":4339269633}]},{"r":655361,"p":[{"n":"value","p":131073}],"n":"GetHashCode","o":"@$1","d":3719925,"h":77313131253,"f":16777249,"a":[{"t":44302337,"c":4339269633}]},{"r":1310721,"p":[{"n":"value","p":131073}],"n":"Format","o":"@$1","d":3719925,"h":81608098549,"f":16777249,"a":[{"t":44302337,"c":4339269633}]},{"r":1310721,"p":[{"n":"s","p":47841281}],"n":"Format","d":3719925,"h":85903065845,"f":16777250,"a":[{"t":44302337,"c":4339269633}]},{"r":65537,"p":[{"n":"value","p":131073},{"n":"result","p":1310721,"f":4}],"n":"AdditionalCustomizedToString","d":3719925,"h":90198033141,"f":16777250},{"r":65537,"p":[{"n":"eventId","p":655361},{"n":"arg1","p":1310721},{"n":"arg2","p":1310721},{"n":"arg3","p":655361}],"n":"WriteEvent","o":"@$19","d":3719925,"h":94493000437,"f":16777218,"a":[{"t":44302337,"c":4339269633}]}],"l":[{"t":1310721,"n":"EventSourceSuppressMessage","o":"@$1","d":3719925,"h":4298687221,"f":4194338},{"t":3719925,"n":"Log","d":3719925,"h":8593654517,"f":4194337},{"t":1310721,"n":"MissingMember","d":3719925,"h":17183589109,"f":4194338},{"t":1310721,"n":"NullInstance","d":3719925,"h":21478556405,"f":4194338},{"t":1310721,"n":"StaticMethodObject","d":3719925,"h":25773523701,"f":4194338},{"t":1310721,"n":"NoParameters","d":3719925,"h":30068490997,"f":4194338},{"t":655361,"n":"InfoEventId","d":3719925,"h":34363458293,"f":4194338},{"t":655361,"n":"ErrorEventId","d":3719925,"h":38658425589,"f":4194338},{"t":655361,"n":"NextAvailableEventId","d":3719925,"h":42953392885,"f":4194338}],"c":[{"n":".ctor","o":"$ctor$10","d":3719925,"h":98787967733,"f":16777217}],"i":[57540609],"j":[3785461],"h":3719925,"a":[{"t":42074113,"c":55876648961,"n":[{"n":"Name","v":"Private.InternalDiagnostics.System.Net.Primitives","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Net.NetEventSource`; }
        });
        
        $asm.$cls("$snp.System.Net.SystemNetworkCredential", ($self) => class SystemNetworkCredential extends $.$snp.System.Net.NetworkCredential
        {
            /*SystemNetworkCredential*/ static s_defaultCredential = null;
            $ctor$6()
            {
                super.$ctor$4($.$$.System.String.Empty, $.$$.System.String.Empty, $.$$.System.String.Empty);
                {
                }
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_defaultCredential = new $.$snp.System.Net.SystemNetworkCredential().$ctor$6();
                }
            }
            static $h = 4899573;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3850997,"l":[{"t":4899573,"n":"s_defaultCredential","d":4899573,"h":4299866869,"f":4194344}],"c":[{"n":".ctor","o":"$ctor$6","d":4899573,"h":8594834165,"f":16777218}],"i":[2933493,2999029],"h":4899573}; }
            static get $b() { return $.$snp.System.Net.NetworkCredential; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$snp.System.Net.ICredentials, $.$snp.System.Net.ICredentialsByHost ]; }
            static get $fullName() { return `System.Net.SystemNetworkCredential`; }
        });
        
        $asm.$cls("$snp.System.Net.CookieException", ($self) => class CookieException extends $.$$.System.FormatException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$16(/*string?*/ message)
            {
                super.$ctor$12(message);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message, innerException);
                {
                }
                return this;
            }
            $ctor$14(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.$ctor$10(serializationInfo, streamingContext);
                {
                }
                return this;
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.GetObjectData(serializationInfo, streamingContext);
            }
            /*void */ GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.GetObjectData(serializationInfo, streamingContext);
            }
            static $h = 1491701;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47775745,"h":1491701}; }
            static get $b() { return $.$$.System.FormatException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.CookieException`; }
        });
        
        $asm.$cls("$snp.System.Net.Sockets.SocketException", ($self) => class SocketException extends $.$$.System.ComponentModel.Win32Exception
        {
            $ctor$20()
            {
                this.$ctor$24($.$snp.Interop.Sys.GetLastErrorInfo());
                {
                }
                return this;
            }
            $ctor$26(/*SocketError*/ errorCode, /*uint*/ platformError)
            {
                super.$ctor$16((platformError | 0));
                {
                    this._errorCode = errorCode;
                }
                return this;
            }
            $ctor$24(/*Interop.ErrorInfo*/ error)
            {
                this.$ctor$26($.$snp.System.Net.Sockets.SocketErrorPal.GetSocketErrorForNativeError(error.Error), (error.RawErrno >>> 0));
                {
                }
                return this;
            }
            static /*int */ GetNativeErrorForSocketError(/*SocketError*/ error)
            {
                /*int*/ let nativeErr = error;
                /*Interop.Error*/ let interopErr;
                if ($.$snp.System.Net.Sockets.SocketErrorPal.TryGetNativeErrorForSocketError(error, $.$ref(() => interopErr, ($v) => interopErr = $v, $.$snp.Interop.Error)))
                {
                    nativeErr = $.$snp.InteropErrorExtensions.Info(interopErr).RawErrno;
                }
                return nativeErr;
            }
            /*SocketError*/ _errorCode = 0;
            $ctor$22(/*int*/ errorCode)
            {
                this.$ctor$27($.$cast(errorCode, $.$snp.System.Net.Sockets.SocketError));
                {
                }
                return this;
            }
            $ctor$21(/*int*/ errorCode, /*string?*/ message)
            {
                this.$ctor$25($.$cast(errorCode, $.$snp.System.Net.Sockets.SocketError), message);
                {
                }
                return this;
            }
            $ctor$27(/*SocketError*/ socketError)
            {
                super.$ctor$16($.$snp.System.Net.Sockets.SocketException.GetNativeErrorForSocketError(socketError));
                {
                    this._errorCode = socketError;
                }
                return this;
            }
            $ctor$25(/*SocketError*/ socketError, /*string?*/ message)
            {
                super.$ctor$15($.$snp.System.Net.Sockets.SocketException.GetNativeErrorForSocketError(socketError), message);
                {
                    this._errorCode = socketError;
                }
                return this;
            }
            /*string */ get Message()
            {
                return super.Message;
            }
            /*SocketError */ get SocketErrorCode()
            {
                return this._errorCode;
            }
            $ctor$23(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.$ctor$17(serializationInfo, streamingContext);
                {
                    if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                    {
                        $.$snp.System.Net.NetEventSource.Info(this, `${this.NativeErrorCode}:${this.Message}`, "SocketException");
                    }
                }
                return this;
            }
            /*int */ get ErrorCode()
            {
                return super.NativeErrorCode;
            }
            static $h = 4834037;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":33423361,"h":4834037}; }
            static get $b() { return $.$$.System.ComponentModel.Win32Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Sockets.SocketException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics"))