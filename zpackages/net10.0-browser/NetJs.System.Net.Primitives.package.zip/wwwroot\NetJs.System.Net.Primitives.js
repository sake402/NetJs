
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $spu, $sri, $st, $sr, $scc, $scn, $sris) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Primitives", 
    {"h":57100,"f":"System.Net.Primitives","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Primitives","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Primitives","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snp.System.Net.ICredentials", ($self) => class ICredentials
        {
            static $h = 2940684;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3858188,"p":[{"n":"uri","p":1744130},{"n":"authType","p":1310721}],"n":"GetCredential","o":"System$Net$ICredentials$GetCredential","d":2940684,"h":4297907980,"f":257}],"h":2940684}; }
            static get $fullName() { return `System.Net.ICredentials`; }
        });
        
        $asm.$cls("$snp.System.Net.ICredentialsByHost", ($self) => class ICredentialsByHost
        {
            static $h = 3006220;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"m":[{"r":3858188,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"authenticationType","p":1310721}],"n":"GetCredential","o":"System$Net$ICredentialsByHost$GetCredential","d":3006220,"h":4297973516,"f":257}],"h":3006220}; }
            static get $fullName() { return `System.Net.ICredentialsByHost`; }
        });
        
        $asm.$cls("$snp.System.Net.IWebProxy", ($self) => class IWebProxy
        {
            static $h = 3596044;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {"p":[{"p":2940684,"g":{"r":0,"d":0,"h":17183465228,"f":257},"s":{"r":0,"d":0,"h":21478432524,"f":257},"n":"Credentials","o":"System$Net$IWebProxy$Credentials","d":3596044,"h":12888497932,"f":257}],"m":[{"r":1744130,"p":[{"n":"destination","p":1744130}],"n":"GetProxy","o":"System$Net$IWebProxy$GetProxy","d":3596044,"h":4298563340,"f":257},{"r":262145,"p":[{"n":"host","p":1744130}],"n":"IsBypassed","o":"System$Net$IWebProxy$IsBypassed","d":3596044,"h":8593530636,"f":257}],"h":3596044}; }
            static get $fullName() { return `System.Net.IWebProxy`; }
        });
        
        $asm.$cls("$snp.System.Net.EndPoint", ($self) => class EndPoint extends $.$spc.System.Object
        {
            /*AddressFamily */ get AddressFamily()
            {
                throw $.$snp.System.NotImplemented.ByDesignWithMessage($.$snp.System.SR.net_PropertyNotImplementedException);
            }
            /*SocketAddress */ Serialize()
            {
                throw $.$snp.System.NotImplemented.ByDesignWithMessage($.$snp.System.SR.net_MethodNotImplementedException);
            }
            /*EndPoint */ Create(/*SocketAddress*/ socketAddress)
            {
                throw $.$snp.System.NotImplemented.ByDesignWithMessage($.$snp.System.SR.net_MethodNotImplementedException);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 2613004;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":4513548,"g":{"r":0,"d":0,"h":8592547596,"f":129},"n":"AddressFamily","d":2613004,"h":4297580300,"f":129}],"m":[{"r":4382476,"n":"Serialize","d":2613004,"h":12887514892,"f":129},{"r":2613004,"p":[{"n":"socketAddress","p":4382476}],"n":"Create","d":2613004,"h":17182482188,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":2613004,"h":21477449484,"f":4}],"h":2613004}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.EndPoint`; }
        });
        
        $asm.$cls("$snp.System.Net.TransportContext", ($self) => class TransportContext extends $.$spc.System.Object
        {
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            static $h = 5037836;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":5431052,"p":[{"n":"kind","p":5496588}],"n":"GetChannelBinding","d":5037836,"h":4300005132,"f":257}],"c":[{"n":".ctor","o":"$ctor$1","d":5037836,"h":8594972428,"f":4}],"h":5037836}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.TransportContext`; }
        });
        
        $asm.$cls("$snp.System.Security.Authentication.ExtendedProtection.ChannelBinding", ($self) => class ChannelBinding extends $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(true);
                {
                }
                return this;
            }
            $ctor$5(/*bool*/ ownsHandle)
            {
                super.$ctor$3(ownsHandle);
                {
                }
                return this;
            }
            static $h = 5431052;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7471105,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17185300236,"f":257},"n":"Size","d":5431052,"h":12890332940,"f":257}],"c":[{"n":".ctor","o":"$ctor$4","d":5431052,"h":4300398348,"f":4},{"p":[{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":5431052,"h":8595365644,"f":4}],"i":[57475073],"h":5431052}; }
            static get $b() { return $.$spc.Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ChannelBinding`; }
        });
        
        $asm.$cls("$snp.Interop", ($self) => class Interop
        {
            static $_Sys;
            static get Sys()
            {
                let $cls = $.$snp.Interop;
                return $cls.$_Sys ??= $asm.$ncls("$snp.Interop.Sys", ($self) => class Sys
                {
                    static /*Error */ ConvertErrorPlatformToPal(/*int*/ platformErrno)
                    {
                        return $.$cast(platformErrno, $.$snp.Interop.Error);
                    }
                    static /*int */ ConvertErrorPalToPlatform(/*Error*/ error)
                    {
                        return error;
                    }
                    static /*byte* */ StrErrorR(/*int*/ platformErrno, /*byte**/ buffer, /*int*/ bufferSize)
                    {
                        return null;
                    }
                    static /*Error */ GetSocketAddressSizes(/*int**/ ipv4SocketAddressSize, /*int**/ ipv6SocketAddressSize, /*int**/ udsSocketAddressSize, /*int**/ maxSocketAddressSize)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ GetAddressFamily(/*byte**/ socketAddress, /*int*/ socketAddressLen, /*int**/ addressFamily)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ SetAddressFamily(/*byte**/ socketAddress, /*int*/ socketAddressLen, /*int*/ addressFamily)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ GetPort(/*byte**/ socketAddress, /*int*/ socketAddressLen, /*ushort**/ port)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ SetPort(/*byte**/ socketAddress, /*int*/ socketAddressLen, /*ushort*/ port)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ GetIPv4Address(/*byte**/ socketAddress, /*int*/ socketAddressLen, /*uint**/ address)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ SetIPv4Address(/*byte**/ socketAddress, /*int*/ socketAddressLen, /*uint*/ address)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ GetIPv6Address(/*byte**/ socketAddress, /*int*/ socketAddressLen, /*byte**/ address, /*int*/ addressLen, /*uint**/ scopeId)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ SetIPv6Address(/*byte**/ socketAddress, /*int*/ socketAddressLen, /*byte**/ address, /*int*/ addressLen, /*uint*/ scopeId)
                    {
                        return 65597/*Error.ENOTSUP*/;
                    }
                    static /*Error */ GetLastError()
                    {
                        return $.$snp.Interop.Sys.ConvertErrorPlatformToPal($.$spc.System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
                    }
                    static /*ErrorInfo */ GetLastErrorInfo()
                    {
                        return new $.$snp.Interop.ErrorInfo().$ctor$2($.$spc.System.Runtime.InteropServices.Marshal.GetLastPInvokeError());
                    }
                    static /*string */ StrError(/*int*/ platformErrno)
                    {
                        /*int*/ let MaxBufferLength = 1024;
                        /*byte**/ let buffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.Byte, MaxBufferLength, null);
                        /*byte**/ let message = $.$snp.Interop.Sys.StrErrorR(platformErrno, buffer, MaxBufferLength);
                        if (message === null)
                        {
                            message = buffer;
                        }
                        return $.$spc.System.Runtime.InteropServices.Marshal.PtrToStringUTF8($.$cast(message, $.$spc.System.IntPtr));
                    }
                    /*int*/ static IPv4AddressBytes = 4;
                    /*int*/ static IPv6AddressBytes = 16;
                    /*int*/ static MAX_IP_ADDRESS_BYTES = 16;
                    /*int*/ static INET_ADDRSTRLEN = 22;
                    /*int*/ static INET6_ADDRSTRLEN = 65;
                    static $_IPAddress;
                    static get IPAddress()
                    {
                        let $cls = $.$snp.Interop.Sys;
                        return $cls.$_IPAddress ??= $asm.$nstr("$snp.Interop.Sys.IPAddress", ($self) => class IPAddress extends $.$spc.System.ValueType
                        {
                            /*bool */ get IsIPv6()
                            {
                                return this._isIPv6 !== 0;
                            }
                            /*bool */ set IsIPv6(value)
                            {
                                this._isIPv6 = value ? 1 : 0;
                            }
                            /*byte[16]*/  get Address() { return this.$getField(0, 0x80000000|16); }
                            /*byte[16]*/  set Address(value) { this.$setField(0, 0x80000000|16, value); }
                            /*uint*/  get _isIPv6() { return this.$getField(16, 4); }
                            /*uint*/  set _isIPv6(value) { this.$setField(16, 4, value); }
                            /*uint*/  get ScopeId() { return this.$getField(20, 4); }
                            /*uint*/  set ScopeId(value) { this.$setField(20, 4, value); }
                            static/*conventional*/ /*int */ GetHashCode()
                            {
                                /*HashCode*/ let h = new $.$spc.System.HashCode();
                                h.AddBytes($.$spc.System.Runtime.InteropServices.MemoryMarshal.CreateReadOnlySpan($.$spc.System.Byte, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$spc.System.Byte, this.Address, 0, false, true), this.IsIPv6 ? 16/*IPv6AddressBytes*/ : 4/*IPv4AddressBytes*/));
                                return h.ToHashCode();
                            }
                            //Static convention instance redirect
                            /*int */ GetHashCode() { return $.$snp.Interop.Sys.IPAddress.GetHashCode.apply(this, arguments); }
                            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
                            {
                                let other;
                                return $.$is(obj, $.$snp.Interop.Sys.IPAddress, { set $v(v){ other = v; } }) && this.Equals$2(other.Clone());
                            }
                            //Static convention instance redirect
                            /*bool */ Equals() { return $.$snp.Interop.Sys.IPAddress.Equals.apply(this, arguments); }
                            /*bool */ Equals$2(/*IPAddress*/ other)
                            {
                                /*int*/ let addressByteCount;
                                if (this.IsIPv6)
                                {
                                    if (!other.IsIPv6)
                                    {
                                        return false;
                                    }
                                    if (this.ScopeId !== other.ScopeId)
                                    {
                                        return false;
                                    }
                                    addressByteCount = 16/*IPv6AddressBytes*/;
                                }
                                else 
                                {
                                    if (other.IsIPv6)
                                    {
                                        return false;
                                    }
                                    addressByteCount = 4/*IPv4AddressBytes*/;
                                }
                                return $.$spc.System.MemoryExtensions.SequenceEqual$1($.$spc.System.Byte, $.$spc.System.Runtime.InteropServices.MemoryMarshal.CreateReadOnlySpan($.$spc.System.Byte, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArrayReferenceT($.$spc.System.Byte, this.Address, 0, false, true), addressByteCount), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$4(other.Address, addressByteCount));
                            }
                            //Generated interface implemetation for System.IEquatable<Interop.Sys.IPAddress>.Equals(Interop.Sys.IPAddress)
                            System$IEquatable$$$Equals()
                            {
                                return this.Equals$2(...arguments);
                            }
                            //default value type constructor
                            $ctor$2()
                            {
                                return this;
                            }
                            Clone($copy)
                            {
                                let copy = $copy ?? new this.constructor();
                                //InlineArray(16)
                                copy.Address = [...this.Address];
                                $.$spc.System.Array.CopyMetadata(copy.Address, this.Address)
                                copy._isIPv6 = this._isIPv6;
                                copy.ScopeId = this.ScopeId;
                                return copy;
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                //FixedSizeArray(byte*, 16)
                                let $t1 = this.Address;
                                $.$spc.System.Array.AddMetadata($t1, $.$spc.System.Byte.$type, null, null);
                                for (let $i = 0; $i < 16; $i++)
                                {
                                    $t1[$i] = 0;
                                }
                                this._isIPv6 = 0;
                                this.ScopeId = 0;
                            }
                            static $h = 581388;
                            static $z = 24;
                            static $f = 0b100010000001010000000;
                            static $k = 2;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":8590515980,"f":1},"s":{"r":0,"d":0,"h":12885483276,"f":1},"n":"IsIPv6","d":581388,"h":4295548684,"f":1}],"m":[{"r":655361,"n":"GetHashCode","d":581388,"h":30065352460,"f":32769},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":581388,"h":34360319756,"f":32769},{"r":262145,"p":[{"n":"other","p":581388}],"n":"Equals","o":"@$2","d":581388,"h":38655287052,"f":1}],"l":[{"t":0,"n":"Address","d":581388,"h":17180450572,"f":8},{"t":720897,"n":"_isIPv6","d":581388,"h":21475417868,"f":2},{"t":720897,"n":"ScopeId","d":581388,"h":25770385164,"f":8}],"c":[{"n":".ctor","o":"$ctor$2","d":581388,"h":42950254348,"f":1}],"i":[$.$spc.System.IEquatable$$($.$snp.Interop.Sys.IPAddress).$h],"d":515852,"h":581388,"a":[{"t":109903873,"c":4404871169,"a":[{"v":0,"t":105381889}]}]}; }
                            static get $b() { return $.$spc.System.ValueType; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$snp.Interop.Sys.IPAddress) ]; }
                            static get $fullName() { return `Interop.Sys.IPAddress`; }
                        }, $cls, ($v) => $cls.$_IPAddress = $v);
                    }
                    static $h = 515852;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":253708,"n":"GetLastError","d":515852,"h":4295483148,"f":40},{"r":319244,"n":"GetLastErrorInfo","d":515852,"h":8590450444,"f":40},{"r":1310721,"p":[{"n":"platformErrno","p":655361}],"n":"StrError","d":515852,"h":12885417740,"f":40},{"r":253708,"p":[{"n":"platformErrno","p":655361}],"n":"ConvertErrorPlatformToPal","d":515852,"h":17180385036,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_ConvertErrorPlatformToPal","t":1310721}]},{"t":109969409,"c":4404936705}]},{"r":655361,"p":[{"n":"error","p":253708}],"n":"ConvertErrorPalToPlatform","d":515852,"h":21475352332,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_ConvertErrorPalToPlatform","t":1310721}]},{"t":109969409,"c":4404936705}]},{"r":0,"p":[{"n":"platformErrno","p":655361},{"n":"buffer","p":0},{"n":"bufferSize","p":655361}],"n":"StrErrorR","d":515852,"h":25770319628,"f":34,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_StrErrorR","t":1310721}]}]},{"r":253708,"p":[{"n":"ipv4SocketAddressSize","p":0},{"n":"ipv6SocketAddressSize","p":0},{"n":"udsSocketAddressSize","p":0},{"n":"maxSocketAddressSize","p":0}],"n":"GetSocketAddressSizes","d":515852,"h":55835090700,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_GetSocketAddressSizes","t":1310721}]},{"t":109969409,"c":4404936705}]},{"r":253708,"p":[{"n":"socketAddress","p":0},{"n":"socketAddressLen","p":655361},{"n":"addressFamily","p":0}],"n":"GetAddressFamily","d":515852,"h":60130057996,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_GetAddressFamily","t":1310721}]},{"t":109969409,"c":4404936705}]},{"r":253708,"p":[{"n":"socketAddress","p":0},{"n":"socketAddressLen","p":655361},{"n":"addressFamily","p":655361}],"n":"SetAddressFamily","d":515852,"h":64425025292,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_SetAddressFamily","t":1310721}]},{"t":109969409,"c":4404936705}]},{"r":253708,"p":[{"n":"socketAddress","p":0},{"n":"socketAddressLen","p":655361},{"n":"port","p":0}],"n":"GetPort","d":515852,"h":68719992588,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_GetPort","t":1310721}]},{"t":109969409,"c":4404936705}]},{"r":253708,"p":[{"n":"socketAddress","p":0},{"n":"socketAddressLen","p":655361},{"n":"port","p":589825}],"n":"SetPort","d":515852,"h":73014959884,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_SetPort","t":1310721}]},{"t":109969409,"c":4404936705}]},{"r":253708,"p":[{"n":"socketAddress","p":0},{"n":"socketAddressLen","p":655361},{"n":"address","p":0}],"n":"GetIPv4Address","d":515852,"h":77309927180,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_GetIPv4Address","t":1310721}]},{"t":109969409,"c":4404936705}]},{"r":253708,"p":[{"n":"socketAddress","p":0},{"n":"socketAddressLen","p":655361},{"n":"address","p":720897}],"n":"SetIPv4Address","d":515852,"h":81604894476,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_SetIPv4Address","t":1310721}]},{"t":109969409,"c":4404936705}]},{"r":253708,"p":[{"n":"socketAddress","p":0},{"n":"socketAddressLen","p":655361},{"n":"address","p":0},{"n":"addressLen","p":655361},{"n":"scopeId","p":0}],"n":"GetIPv6Address","d":515852,"h":85899861772,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_GetIPv6Address","t":1310721}]}]},{"r":253708,"p":[{"n":"socketAddress","p":0},{"n":"socketAddressLen","p":655361},{"n":"address","p":0},{"n":"addressLen","p":655361},{"n":"scopeId","p":720897}],"n":"SetIPv6Address","d":515852,"h":90194829068,"f":40,"a":[{"t":105512961,"c":4400480257,"a":[{"v":"libSystem.Native","t":1310721}],"n":[{"n":"EntryPoint","v":"SystemNative_SetIPv6Address","t":1310721}]}]}],"l":[{"t":655361,"n":"IPv4AddressBytes","d":515852,"h":30065286924,"f":40},{"t":655361,"n":"IPv6AddressBytes","d":515852,"h":34360254220,"f":40},{"t":655361,"n":"MAX_IP_ADDRESS_BYTES","d":515852,"h":38655221516,"f":40},{"t":655361,"n":"INET_ADDRSTRLEN","d":515852,"h":42950188812,"f":40},{"t":655361,"n":"INET6_ADDRSTRLEN","d":515852,"h":47245156108,"f":40}],"j":[581388],"d":122636,"h":515852}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Sys`; }
                }, $cls, ($v) => $cls.$_Sys = $v);
            }
            static $_Crypt32;
            static get Crypt32()
            {
                let $cls = $.$snp.Interop;
                return $cls.$_Crypt32 ??= $asm.$ncls("$snp.Interop.Crypt32", ($self) => class Crypt32
                {
                    /*int*/ static ALG_CLASS_ANY = 0;
                    /*int*/ static ALG_CLASS_SIGNATURE = 8192;
                    /*int*/ static ALG_CLASS_ENCRYPT = 24576;
                    /*int*/ static ALG_CLASS_HASH = 32768;
                    /*int*/ static ALG_CLASS_KEY_EXCHANGE = 40960;
                    /*int*/ static ALG_TYPE_RSA = 1024;
                    /*int*/ static ALG_TYPE_BLOCK = 1536;
                    /*int*/ static ALG_TYPE_STREAM = 2048;
                    /*int*/ static ALG_TYPE_DH = 2560;
                    /*int*/ static ALG_SID_DES = 1;
                    /*int*/ static ALG_SID_3DES = 3;
                    /*int*/ static ALG_SID_AES_128 = 14;
                    /*int*/ static ALG_SID_AES_192 = 15;
                    /*int*/ static ALG_SID_AES_256 = 16;
                    /*int*/ static ALG_SID_AES = 17;
                    /*int*/ static ALG_SID_RC2 = 2;
                    /*int*/ static ALG_SID_RC4 = 1;
                    /*int*/ static ALG_SID_DH_EPHEM = 2;
                    /*int*/ static ALG_SID_MD5 = 3;
                    /*int*/ static ALG_SID_SHA = 4;
                    /*int*/ static ALG_SID_SHA_256 = 12;
                    /*int*/ static ALG_SID_SHA_384 = 13;
                    /*int*/ static ALG_SID_SHA_512 = 14;
                    static $h = 188172;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"ALG_CLASS_ANY","d":188172,"h":4295155468,"f":33},{"t":655361,"n":"ALG_CLASS_SIGNATURE","d":188172,"h":8590122764,"f":33},{"t":655361,"n":"ALG_CLASS_ENCRYPT","d":188172,"h":12885090060,"f":33},{"t":655361,"n":"ALG_CLASS_HASH","d":188172,"h":17180057356,"f":33},{"t":655361,"n":"ALG_CLASS_KEY_EXCHANGE","d":188172,"h":21475024652,"f":33},{"t":655361,"n":"ALG_TYPE_RSA","d":188172,"h":25769991948,"f":33},{"t":655361,"n":"ALG_TYPE_BLOCK","d":188172,"h":30064959244,"f":33},{"t":655361,"n":"ALG_TYPE_STREAM","d":188172,"h":34359926540,"f":33},{"t":655361,"n":"ALG_TYPE_DH","d":188172,"h":38654893836,"f":33},{"t":655361,"n":"ALG_SID_DES","d":188172,"h":42949861132,"f":33},{"t":655361,"n":"ALG_SID_3DES","d":188172,"h":47244828428,"f":33},{"t":655361,"n":"ALG_SID_AES_128","d":188172,"h":51539795724,"f":33},{"t":655361,"n":"ALG_SID_AES_192","d":188172,"h":55834763020,"f":33},{"t":655361,"n":"ALG_SID_AES_256","d":188172,"h":60129730316,"f":33},{"t":655361,"n":"ALG_SID_AES","d":188172,"h":64424697612,"f":33},{"t":655361,"n":"ALG_SID_RC2","d":188172,"h":68719664908,"f":33},{"t":655361,"n":"ALG_SID_RC4","d":188172,"h":73014632204,"f":33},{"t":655361,"n":"ALG_SID_DH_EPHEM","d":188172,"h":77309599500,"f":33},{"t":655361,"n":"ALG_SID_MD5","d":188172,"h":81604566796,"f":33},{"t":655361,"n":"ALG_SID_SHA","d":188172,"h":85899534092,"f":33},{"t":655361,"n":"ALG_SID_SHA_256","d":188172,"h":90194501388,"f":33},{"t":655361,"n":"ALG_SID_SHA_384","d":188172,"h":94489468684,"f":33},{"t":655361,"n":"ALG_SID_SHA_512","d":188172,"h":98784435980,"f":33}],"d":122636,"h":188172}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Crypt32`; }
                }, $cls, ($v) => $cls.$_Crypt32 = $v);
            }
            static $_SChannel;
            static get SChannel()
            {
                let $cls = $.$snp.Interop;
                return $cls.$_SChannel ??= $asm.$ncls("$snp.Interop.SChannel", ($self) => class SChannel
                {
                    /*int*/ static SP_PROT_SSL2_SERVER = 4;
                    /*int*/ static SP_PROT_SSL2_CLIENT = 8;
                    /*int*/ static SP_PROT_SSL2 = 12;
                    /*int*/ static SP_PROT_SSL3_SERVER = 16;
                    /*int*/ static SP_PROT_SSL3_CLIENT = 32;
                    /*int*/ static SP_PROT_SSL3 = 48;
                    /*int*/ static SP_PROT_TLS1_0_SERVER = 64;
                    /*int*/ static SP_PROT_TLS1_0_CLIENT = 128;
                    /*int*/ static SP_PROT_TLS1_0 = 192;
                    /*int*/ static SP_PROT_TLS1_1_SERVER = 256;
                    /*int*/ static SP_PROT_TLS1_1_CLIENT = 512;
                    /*int*/ static SP_PROT_TLS1_1 = 768;
                    /*int*/ static SP_PROT_TLS1_2_SERVER = 1024;
                    /*int*/ static SP_PROT_TLS1_2_CLIENT = 2048;
                    /*int*/ static SP_PROT_TLS1_2 = 3072;
                    /*int*/ static SP_PROT_TLS1_3_SERVER = 4096;
                    /*int*/ static SP_PROT_TLS1_3_CLIENT = 8192;
                    /*int*/ static SP_PROT_TLS1_3 = 12288;
                    /*int*/ static SP_PROT_NONE = 0;
                    /*int*/ static ClientProtocolMask = 10920;
                    /*int*/ static ServerProtocolMask = 5460;
                    static $h = 450316;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"SP_PROT_SSL2_SERVER","d":450316,"h":4295417612,"f":33},{"t":655361,"n":"SP_PROT_SSL2_CLIENT","d":450316,"h":8590384908,"f":33},{"t":655361,"n":"SP_PROT_SSL2","d":450316,"h":12885352204,"f":33},{"t":655361,"n":"SP_PROT_SSL3_SERVER","d":450316,"h":17180319500,"f":33},{"t":655361,"n":"SP_PROT_SSL3_CLIENT","d":450316,"h":21475286796,"f":33},{"t":655361,"n":"SP_PROT_SSL3","d":450316,"h":25770254092,"f":33},{"t":655361,"n":"SP_PROT_TLS1_0_SERVER","d":450316,"h":30065221388,"f":33},{"t":655361,"n":"SP_PROT_TLS1_0_CLIENT","d":450316,"h":34360188684,"f":33},{"t":655361,"n":"SP_PROT_TLS1_0","d":450316,"h":38655155980,"f":33},{"t":655361,"n":"SP_PROT_TLS1_1_SERVER","d":450316,"h":42950123276,"f":33},{"t":655361,"n":"SP_PROT_TLS1_1_CLIENT","d":450316,"h":47245090572,"f":33},{"t":655361,"n":"SP_PROT_TLS1_1","d":450316,"h":51540057868,"f":33},{"t":655361,"n":"SP_PROT_TLS1_2_SERVER","d":450316,"h":55835025164,"f":33},{"t":655361,"n":"SP_PROT_TLS1_2_CLIENT","d":450316,"h":60129992460,"f":33},{"t":655361,"n":"SP_PROT_TLS1_2","d":450316,"h":64424959756,"f":33},{"t":655361,"n":"SP_PROT_TLS1_3_SERVER","d":450316,"h":68719927052,"f":33},{"t":655361,"n":"SP_PROT_TLS1_3_CLIENT","d":450316,"h":73014894348,"f":33},{"t":655361,"n":"SP_PROT_TLS1_3","d":450316,"h":77309861644,"f":33},{"t":655361,"n":"SP_PROT_NONE","d":450316,"h":81604828940,"f":33},{"t":655361,"n":"ClientProtocolMask","d":450316,"h":85899796236,"f":33},{"t":655361,"n":"ServerProtocolMask","d":450316,"h":90194763532,"f":33}],"d":122636,"h":450316}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.SChannel`; }
                }, $cls, ($v) => $cls.$_SChannel = $v);
            }
            static $_Winsock;
            static get Winsock()
            {
                let $cls = $.$snp.Interop;
                return $cls.$_Winsock ??= $asm.$ncls("$snp.Interop.Winsock", ($self) => class Winsock
                {
                    /*uint*/ static ERROR_SUCCESS = 0;
                    /*uint*/ static ERROR_HANDLE_EOF = 38;
                    /*uint*/ static ERROR_NOT_SUPPORTED = 50;
                    /*uint*/ static ERROR_INVALID_PARAMETER = 87;
                    /*uint*/ static ERROR_ALREADY_EXISTS = 183;
                    /*uint*/ static ERROR_MORE_DATA = 234;
                    /*uint*/ static ERROR_OPERATION_ABORTED = 995;
                    /*uint*/ static ERROR_IO_PENDING = 997;
                    /*uint*/ static ERROR_NOT_FOUND = 1168;
                    /*uint*/ static ERROR_CONNECTION_INVALID = 1229;
                    static $h = 646924;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":720897,"n":"ERROR_SUCCESS","d":646924,"h":4295614220,"f":33},{"t":720897,"n":"ERROR_HANDLE_EOF","d":646924,"h":8590581516,"f":33},{"t":720897,"n":"ERROR_NOT_SUPPORTED","d":646924,"h":12885548812,"f":33},{"t":720897,"n":"ERROR_INVALID_PARAMETER","d":646924,"h":17180516108,"f":33},{"t":720897,"n":"ERROR_ALREADY_EXISTS","d":646924,"h":21475483404,"f":33},{"t":720897,"n":"ERROR_MORE_DATA","d":646924,"h":25770450700,"f":33},{"t":720897,"n":"ERROR_OPERATION_ABORTED","d":646924,"h":30065417996,"f":33},{"t":720897,"n":"ERROR_IO_PENDING","d":646924,"h":34360385292,"f":33},{"t":720897,"n":"ERROR_NOT_FOUND","d":646924,"h":38655352588,"f":33},{"t":720897,"n":"ERROR_CONNECTION_INVALID","d":646924,"h":42950319884,"f":33}],"d":122636,"h":646924}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Winsock`; }
                }, $cls, ($v) => $cls.$_Winsock = $v);
            }
            static $_Error;
            static get Error()
            {
                let $cls = $.$snp.Interop;
                return $cls.$_Error ??= $asm.$nstr("$snp.Interop.Error", ($self) => class Error extends $.$spc.System.Enum
                {
                    static SUCCESS = 0;
                    static E2BIG = 65537;
                    static EACCES = 65538;
                    static EADDRINUSE = 65539;
                    static EADDRNOTAVAIL = 65540;
                    static EAFNOSUPPORT = 65541;
                    static EAGAIN = 65542;
                    static EALREADY = 65543;
                    static EBADF = 65544;
                    static EBADMSG = 65545;
                    static EBUSY = 65546;
                    static ECANCELED = 65547;
                    static ECHILD = 65548;
                    static ECONNABORTED = 65549;
                    static ECONNREFUSED = 65550;
                    static ECONNRESET = 65551;
                    static EDEADLK = 65552;
                    static EDESTADDRREQ = 65553;
                    static EDOM = 65554;
                    static EDQUOT = 65555;
                    static EEXIST = 65556;
                    static EFAULT = 65557;
                    static EFBIG = 65558;
                    static EHOSTUNREACH = 65559;
                    static EIDRM = 65560;
                    static EILSEQ = 65561;
                    static EINPROGRESS = 65562;
                    static EINTR = 65563;
                    static EINVAL = 65564;
                    static EIO = 65565;
                    static EISCONN = 65566;
                    static EISDIR = 65567;
                    static ELOOP = 65568;
                    static EMFILE = 65569;
                    static EMLINK = 65570;
                    static EMSGSIZE = 65571;
                    static EMULTIHOP = 65572;
                    static ENAMETOOLONG = 65573;
                    static ENETDOWN = 65574;
                    static ENETRESET = 65575;
                    static ENETUNREACH = 65576;
                    static ENFILE = 65577;
                    static ENOBUFS = 65578;
                    static ENODEV = 65580;
                    static ENOENT = 65581;
                    static ENOEXEC = 65582;
                    static ENOLCK = 65583;
                    static ENOLINK = 65584;
                    static ENOMEM = 65585;
                    static ENOMSG = 65586;
                    static ENOPROTOOPT = 65587;
                    static ENOSPC = 65588;
                    static ENOSYS = 65591;
                    static ENOTCONN = 65592;
                    static ENOTDIR = 65593;
                    static ENOTEMPTY = 65594;
                    static ENOTRECOVERABLE = 65595;
                    static ENOTSOCK = 65596;
                    static ENOTSUP = 65597;
                    static ENOTTY = 65598;
                    static ENXIO = 65599;
                    static EOVERFLOW = 65600;
                    static EOWNERDEAD = 65601;
                    static EPERM = 65602;
                    static EPIPE = 65603;
                    static EPROTO = 65604;
                    static EPROTONOSUPPORT = 65605;
                    static EPROTOTYPE = 65606;
                    static ERANGE = 65607;
                    static EROFS = 65608;
                    static ESPIPE = 65609;
                    static ESRCH = 65610;
                    static ESTALE = 65611;
                    static ETIMEDOUT = 65613;
                    static ETXTBSY = 65614;
                    static EXDEV = 65615;
                    static ESOCKTNOSUPPORT = 65630;
                    static EPFNOSUPPORT = 65632;
                    static ESHUTDOWN = 65644;
                    static EHOSTDOWN = 65648;
                    static ENODATA = 65649;
                    static EHOSTNOTFOUND = 131073;
                    static ESOCKETERROR = 131074;
                    static EOPNOTSUPP = 65597;
                    static EWOULDBLOCK = 65542;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "SUCCESS": 0n,
                            "E2BIG": 65537n,
                            "EACCES": 65538n,
                            "EADDRINUSE": 65539n,
                            "EADDRNOTAVAIL": 65540n,
                            "EAFNOSUPPORT": 65541n,
                            "EAGAIN": 65542n,
                            "EALREADY": 65543n,
                            "EBADF": 65544n,
                            "EBADMSG": 65545n,
                            "EBUSY": 65546n,
                            "ECANCELED": 65547n,
                            "ECHILD": 65548n,
                            "ECONNABORTED": 65549n,
                            "ECONNREFUSED": 65550n,
                            "ECONNRESET": 65551n,
                            "EDEADLK": 65552n,
                            "EDESTADDRREQ": 65553n,
                            "EDOM": 65554n,
                            "EDQUOT": 65555n,
                            "EEXIST": 65556n,
                            "EFAULT": 65557n,
                            "EFBIG": 65558n,
                            "EHOSTUNREACH": 65559n,
                            "EIDRM": 65560n,
                            "EILSEQ": 65561n,
                            "EINPROGRESS": 65562n,
                            "EINTR": 65563n,
                            "EINVAL": 65564n,
                            "EIO": 65565n,
                            "EISCONN": 65566n,
                            "EISDIR": 65567n,
                            "ELOOP": 65568n,
                            "EMFILE": 65569n,
                            "EMLINK": 65570n,
                            "EMSGSIZE": 65571n,
                            "EMULTIHOP": 65572n,
                            "ENAMETOOLONG": 65573n,
                            "ENETDOWN": 65574n,
                            "ENETRESET": 65575n,
                            "ENETUNREACH": 65576n,
                            "ENFILE": 65577n,
                            "ENOBUFS": 65578n,
                            "ENODEV": 65580n,
                            "ENOENT": 65581n,
                            "ENOEXEC": 65582n,
                            "ENOLCK": 65583n,
                            "ENOLINK": 65584n,
                            "ENOMEM": 65585n,
                            "ENOMSG": 65586n,
                            "ENOPROTOOPT": 65587n,
                            "ENOSPC": 65588n,
                            "ENOSYS": 65591n,
                            "ENOTCONN": 65592n,
                            "ENOTDIR": 65593n,
                            "ENOTEMPTY": 65594n,
                            "ENOTRECOVERABLE": 65595n,
                            "ENOTSOCK": 65596n,
                            "ENOTSUP": 65597n,
                            "ENOTTY": 65598n,
                            "ENXIO": 65599n,
                            "EOVERFLOW": 65600n,
                            "EOWNERDEAD": 65601n,
                            "EPERM": 65602n,
                            "EPIPE": 65603n,
                            "EPROTO": 65604n,
                            "EPROTONOSUPPORT": 65605n,
                            "EPROTOTYPE": 65606n,
                            "ERANGE": 65607n,
                            "EROFS": 65608n,
                            "ESPIPE": 65609n,
                            "ESRCH": 65610n,
                            "ESTALE": 65611n,
                            "ETIMEDOUT": 65613n,
                            "ETXTBSY": 65614n,
                            "EXDEV": 65615n,
                            "ESOCKTNOSUPPORT": 65630n,
                            "EPFNOSUPPORT": 65632n,
                            "ESHUTDOWN": 65644n,
                            "EHOSTDOWN": 65648n,
                            "ENODATA": 65649n,
                            "EHOSTNOTFOUND": 131073n,
                            "ESOCKETERROR": 131074n,
                            "EOPNOTSUPP": 65597n,
                            "EWOULDBLOCK": 65542n
                        };
                    }
                    static $h = 253708;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":253708,"n":"SUCCESS","d":253708,"h":4295221004,"f":33},{"t":253708,"n":"E2BIG","d":253708,"h":8590188300,"f":33},{"t":253708,"n":"EACCES","d":253708,"h":12885155596,"f":33},{"t":253708,"n":"EADDRINUSE","d":253708,"h":17180122892,"f":33},{"t":253708,"n":"EADDRNOTAVAIL","d":253708,"h":21475090188,"f":33},{"t":253708,"n":"EAFNOSUPPORT","d":253708,"h":25770057484,"f":33},{"t":253708,"n":"EAGAIN","d":253708,"h":30065024780,"f":33},{"t":253708,"n":"EALREADY","d":253708,"h":34359992076,"f":33},{"t":253708,"n":"EBADF","d":253708,"h":38654959372,"f":33},{"t":253708,"n":"EBADMSG","d":253708,"h":42949926668,"f":33},{"t":253708,"n":"EBUSY","d":253708,"h":47244893964,"f":33},{"t":253708,"n":"ECANCELED","d":253708,"h":51539861260,"f":33},{"t":253708,"n":"ECHILD","d":253708,"h":55834828556,"f":33},{"t":253708,"n":"ECONNABORTED","d":253708,"h":60129795852,"f":33},{"t":253708,"n":"ECONNREFUSED","d":253708,"h":64424763148,"f":33},{"t":253708,"n":"ECONNRESET","d":253708,"h":68719730444,"f":33},{"t":253708,"n":"EDEADLK","d":253708,"h":73014697740,"f":33},{"t":253708,"n":"EDESTADDRREQ","d":253708,"h":77309665036,"f":33},{"t":253708,"n":"EDOM","d":253708,"h":81604632332,"f":33},{"t":253708,"n":"EDQUOT","d":253708,"h":85899599628,"f":33},{"t":253708,"n":"EEXIST","d":253708,"h":90194566924,"f":33},{"t":253708,"n":"EFAULT","d":253708,"h":94489534220,"f":33},{"t":253708,"n":"EFBIG","d":253708,"h":98784501516,"f":33},{"t":253708,"n":"EHOSTUNREACH","d":253708,"h":103079468812,"f":33},{"t":253708,"n":"EIDRM","d":253708,"h":107374436108,"f":33},{"t":253708,"n":"EILSEQ","d":253708,"h":111669403404,"f":33},{"t":253708,"n":"EINPROGRESS","d":253708,"h":115964370700,"f":33},{"t":253708,"n":"EINTR","d":253708,"h":120259337996,"f":33},{"t":253708,"n":"EINVAL","d":253708,"h":124554305292,"f":33},{"t":253708,"n":"EIO","d":253708,"h":128849272588,"f":33},{"t":253708,"n":"EISCONN","d":253708,"h":133144239884,"f":33},{"t":253708,"n":"EISDIR","d":253708,"h":137439207180,"f":33},{"t":253708,"n":"ELOOP","d":253708,"h":141734174476,"f":33},{"t":253708,"n":"EMFILE","d":253708,"h":146029141772,"f":33},{"t":253708,"n":"EMLINK","d":253708,"h":150324109068,"f":33},{"t":253708,"n":"EMSGSIZE","d":253708,"h":154619076364,"f":33},{"t":253708,"n":"EMULTIHOP","d":253708,"h":158914043660,"f":33},{"t":253708,"n":"ENAMETOOLONG","d":253708,"h":163209010956,"f":33},{"t":253708,"n":"ENETDOWN","d":253708,"h":167503978252,"f":33},{"t":253708,"n":"ENETRESET","d":253708,"h":171798945548,"f":33},{"t":253708,"n":"ENETUNREACH","d":253708,"h":176093912844,"f":33},{"t":253708,"n":"ENFILE","d":253708,"h":180388880140,"f":33},{"t":253708,"n":"ENOBUFS","d":253708,"h":184683847436,"f":33},{"t":253708,"n":"ENODEV","d":253708,"h":188978814732,"f":33},{"t":253708,"n":"ENOENT","d":253708,"h":193273782028,"f":33},{"t":253708,"n":"ENOEXEC","d":253708,"h":197568749324,"f":33},{"t":253708,"n":"ENOLCK","d":253708,"h":201863716620,"f":33},{"t":253708,"n":"ENOLINK","d":253708,"h":206158683916,"f":33},{"t":253708,"n":"ENOMEM","d":253708,"h":210453651212,"f":33},{"t":253708,"n":"ENOMSG","d":253708,"h":214748618508,"f":33},{"t":253708,"n":"ENOPROTOOPT","d":253708,"h":219043585804,"f":33},{"t":253708,"n":"ENOSPC","d":253708,"h":223338553100,"f":33},{"t":253708,"n":"ENOSYS","d":253708,"h":227633520396,"f":33},{"t":253708,"n":"ENOTCONN","d":253708,"h":231928487692,"f":33},{"t":253708,"n":"ENOTDIR","d":253708,"h":236223454988,"f":33},{"t":253708,"n":"ENOTEMPTY","d":253708,"h":240518422284,"f":33},{"t":253708,"n":"ENOTRECOVERABLE","d":253708,"h":244813389580,"f":33},{"t":253708,"n":"ENOTSOCK","d":253708,"h":249108356876,"f":33},{"t":253708,"n":"ENOTSUP","d":253708,"h":253403324172,"f":33},{"t":253708,"n":"ENOTTY","d":253708,"h":257698291468,"f":33},{"t":253708,"n":"ENXIO","d":253708,"h":261993258764,"f":33},{"t":253708,"n":"EOVERFLOW","d":253708,"h":266288226060,"f":33},{"t":253708,"n":"EOWNERDEAD","d":253708,"h":270583193356,"f":33},{"t":253708,"n":"EPERM","d":253708,"h":274878160652,"f":33},{"t":253708,"n":"EPIPE","d":253708,"h":279173127948,"f":33},{"t":253708,"n":"EPROTO","d":253708,"h":283468095244,"f":33},{"t":253708,"n":"EPROTONOSUPPORT","d":253708,"h":287763062540,"f":33},{"t":253708,"n":"EPROTOTYPE","d":253708,"h":292058029836,"f":33},{"t":253708,"n":"ERANGE","d":253708,"h":296352997132,"f":33},{"t":253708,"n":"EROFS","d":253708,"h":300647964428,"f":33},{"t":253708,"n":"ESPIPE","d":253708,"h":304942931724,"f":33},{"t":253708,"n":"ESRCH","d":253708,"h":309237899020,"f":33},{"t":253708,"n":"ESTALE","d":253708,"h":313532866316,"f":33},{"t":253708,"n":"ETIMEDOUT","d":253708,"h":317827833612,"f":33},{"t":253708,"n":"ETXTBSY","d":253708,"h":322122800908,"f":33},{"t":253708,"n":"EXDEV","d":253708,"h":326417768204,"f":33},{"t":253708,"n":"ESOCKTNOSUPPORT","d":253708,"h":330712735500,"f":33},{"t":253708,"n":"EPFNOSUPPORT","d":253708,"h":335007702796,"f":33},{"t":253708,"n":"ESHUTDOWN","d":253708,"h":339302670092,"f":33},{"t":253708,"n":"EHOSTDOWN","d":253708,"h":343597637388,"f":33},{"t":253708,"n":"ENODATA","d":253708,"h":347892604684,"f":33},{"t":253708,"n":"EHOSTNOTFOUND","d":253708,"h":352187571980,"f":33},{"t":253708,"n":"ESOCKETERROR","d":253708,"h":356482539276,"f":33},{"t":253708,"n":"EOPNOTSUPP","d":253708,"h":360777506572,"f":33},{"t":253708,"n":"EWOULDBLOCK","d":253708,"h":365072473868,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":253708,"h":369367441164,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":122636,"h":253708}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `Interop.Error`; }
                }, $cls, ($v) => $cls.$_Error = $v);
            }
            static $_ErrorInfo;
            static get ErrorInfo()
            {
                let $cls = $.$snp.Interop;
                return $cls.$_ErrorInfo ??= $asm.$nstr("$snp.Interop.ErrorInfo", ($self) => class ErrorInfo extends $.$spc.System.ValueType
                {
                    /*Error*/  get _error() { return this.$getField(0, $.$snp.Interop.Error); }
                    /*Error*/  set _error(value) { this.$setField(0, $.$snp.Interop.Error, value); }
                    /*int*/  get _rawErrno() { return this.$getField(4, $.$spc.System.Int32); }
                    /*int*/  set _rawErrno(value) { this.$setField(4, $.$spc.System.Int32, value); }
                    $ctor$2(/*int*/ errno)
                    {
                        super.$ctor$1();
                        {
                            this._error = $.$snp.Interop.Sys.ConvertErrorPlatformToPal(errno);
                            this._rawErrno = errno;
                        }
                        return this;
                    }
                    $ctor$3(/*Error*/ error)
                    {
                        super.$ctor$1();
                        {
                            this._error = error;
                            this._rawErrno = -1;
                        }
                        return this;
                    }
                    /*Error */ get Error()
                    {
                        return this._error;
                    }
                    /*int */ get RawErrno()
                    {
                        return this._rawErrno === -1 ? (this._rawErrno = $.$snp.Interop.Sys.ConvertErrorPalToPlatform(this._error)) : this._rawErrno;
                    }
                    /*string */ GetErrorMessage()
                    {
                        return $.$snp.Interop.Sys.StrError(this.RawErrno);
                    }
                    static/*conventional*/ /*string */ ToString()
                    {
                        return `RawErrno: ${this.RawErrno} Error: ${this.Error} GetErrorMessage: ${this.GetErrorMessage()}`;
                    }
                    //Static convention instance redirect
                    /*string */ ToString() { return $.$snp.Interop.ErrorInfo.ToString.apply(this, arguments); }
                    //default value type constructor
                    $ctor$4()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._error = this._error;
                        copy._rawErrno = this._rawErrno;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._error = 0;
                        this._rawErrno = 0;
                    }
                    static $h = 319244;
                    static $z = 8;
                    static $f = 0b10000010000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":253708,"g":{"r":0,"d":0,"h":25770123020,"f":8},"n":"Error","d":319244,"h":21475155724,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":34360057612,"f":8},"n":"RawErrno","d":319244,"h":30065090316,"f":8}],"m":[{"r":1310721,"n":"GetErrorMessage","d":319244,"h":38655024908,"f":8},{"r":1310721,"n":"ToString","d":319244,"h":42949992204,"f":32769}],"l":[{"t":253708,"n":"_error","d":319244,"h":4295286540,"f":2},{"t":655361,"n":"_rawErrno","d":319244,"h":8590253836,"f":2}],"c":[{"p":[{"n":"errno","p":655361}],"n":".ctor","o":"$ctor$2","d":319244,"h":12885221132,"f":8},{"p":[{"n":"error","p":253708}],"n":".ctor","o":"$ctor$3","d":319244,"h":17180188428,"f":8},{"n":".ctor","o":"$ctor$4","d":319244,"h":47244959500,"f":1}],"d":122636,"h":319244}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `Interop.ErrorInfo`; }
                }, $cls, ($v) => $cls.$_ErrorInfo = $v);
            }
            static $_Libraries;
            static get Libraries()
            {
                let $cls = $.$snp.Interop;
                return $cls.$_Libraries ??= $asm.$ncls("$snp.Interop.Libraries", ($self) => class Libraries
                {
                    /*string*/ static libc = null;
                    /*string*/ static SystemNative = null;
                    /*string*/ static NetSecurityNative = null;
                    /*string*/ static CryptoNative = null;
                    /*string*/ static CompressionNative = null;
                    /*string*/ static GlobalizationNative = null;
                    /*string*/ static IOPortsNative = null;
                    /*string*/ static HostPolicy = null;
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.libc = "libc";
                        }
                        {
                            this.SystemNative = "libSystem.Native";
                        }
                        {
                            this.NetSecurityNative = "libSystem.Net.Security.Native";
                        }
                        {
                            this.CryptoNative = "libSystem.Security.Cryptography.Native.OpenSsl";
                        }
                        {
                            this.CompressionNative = "libSystem.IO.Compression.Native";
                        }
                        {
                            this.GlobalizationNative = "libSystem.Globalization.Native";
                        }
                        {
                            this.IOPortsNative = "libSystem.IO.Ports.Native";
                        }
                        {
                            this.HostPolicy = "libhostpolicy";
                        }
                    }
                    static $h = 384780;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"libc","d":384780,"h":4295352076,"f":40},{"t":1310721,"n":"SystemNative","d":384780,"h":8590319372,"f":40},{"t":1310721,"n":"NetSecurityNative","d":384780,"h":12885286668,"f":40},{"t":1310721,"n":"CryptoNative","d":384780,"h":17180253964,"f":40},{"t":1310721,"n":"CompressionNative","d":384780,"h":21475221260,"f":40},{"t":1310721,"n":"GlobalizationNative","d":384780,"h":25770188556,"f":40},{"t":1310721,"n":"IOPortsNative","d":384780,"h":30065155852,"f":40},{"t":1310721,"n":"HostPolicy","d":384780,"h":34360123148,"f":40}],"d":122636,"h":384780}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `Interop.Libraries`; }
                }, $cls, ($v) => $cls.$_Libraries = $v);
            }
            static $h = 122636;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"j":[515852,188172,450316,646924,253708,319244,384780],"h":122636}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `Interop`; }
        });
        
        $asm.$cls("$snp.System.SR", ($self) => class SR
        {
            /*global::System.Resources.ResourceManager*/ static s_resourceManager = null;
            /*global::System.Globalization.CultureInfo*/ static resourceCulture = null;
            static /*global::System.Resources.ResourceManager */ get ResourceManager()
            {
                if ($.$spc.System.Object.ReferenceEquals($.$snp.System.SR.s_resourceManager, null))
                {
                    /*global::System.Resources.ResourceManager*/ let temp = new $.$spc.System.Resources.ResourceManager().$ctor$3("System.Net.Primitives", $.$snp.System.SR.$type.Assembly);
                    $.$snp.System.SR.s_resourceManager = temp;
                }
                return $.$snp.System.SR.s_resourceManager;
            }
            static /*global::System.Globalization.CultureInfo */ get Culture()
            {
                return $.$snp.System.SR.resourceCulture;
            }
            static /*global::System.Globalization.CultureInfo */ set Culture(value)
            {
                $.$snp.System.SR.resourceCulture = value;
            }
            static /*string */ get net_MethodNotImplementedException()
            {
                return "This method is not implemented by this class.";
            }
            static /*string */ get net_PropertyNotImplementedException()
            {
                return "This property is not implemented by this class.";
            }
            static /*string */ get net_InvalidAddressFamily()
            {
                return "The AddressFamily {0} is not valid for the {1} end point.";
            }
            static /*string */ Formatnet_InvalidAddressFamily(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The AddressFamily {0} is not valid for the {1} end point.", arg1, arg2);
            }
            static /*string */ get net_InvalidSocketAddressSize()
            {
                return "The supplied {0} is an invalid size for the {1} end point.";
            }
            static /*string */ Formatnet_InvalidSocketAddressSize(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The supplied {0} is an invalid size for the {1} end point.", arg1, arg2);
            }
            static /*string */ get net_sockets_invalid_optionValue_all()
            {
                return "The specified value is not valid.";
            }
            static /*string */ get net_emptystringcall()
            {
                return "The parameter '{0}' cannot be an empty string.";
            }
            static /*string */ Formatnet_emptystringcall(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("The parameter '{0}' cannot be an empty string.", arg1);
            }
            static /*string */ get dns_bad_ip_address()
            {
                return "An invalid IP address was specified.";
            }
            static /*string */ get net_bad_ip_network()
            {
                return "An invalid IP network was specified.";
            }
            static /*string */ get net_container_add_cookie()
            {
                return "An error occurred when adding a cookie to the container.";
            }
            static /*string */ get net_cookie_size()
            {
                return "The value size of the cookie is '{0}'. This exceeds the configured maximum size, which is '{1}'.";
            }
            static /*string */ Formatnet_cookie_size(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The value size of the cookie is '{0}'. This exceeds the configured maximum size, which is '{1}'.", arg1, arg2);
            }
            static /*string */ get net_cookie_parse_header()
            {
                return "An error occurred when parsing the Cookie header for Uri '{0}'.";
            }
            static /*string */ Formatnet_cookie_parse_header(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("An error occurred when parsing the Cookie header for Uri '{0}'.", arg1);
            }
            static /*string */ get net_cookie_attribute()
            {
                return "The '{0}'='{1}' part of the cookie is invalid.";
            }
            static /*string */ Formatnet_cookie_attribute(/*object*/ arg1, /*object*/ arg2)
            {
                return $.$spc.System.String.Format$1("The '{0}'='{1}' part of the cookie is invalid.", arg1, arg2);
            }
            static /*string */ get net_cookie_format()
            {
                return "Cookie format error.";
            }
            static /*string */ get net_cookie_capacity_range()
            {
                return "'{0}' has to be greater than '{1}' and less than '{2}'.";
            }
            static /*string */ Formatnet_cookie_capacity_range(/*object*/ arg1, /*object*/ arg2, /*object*/ arg3)
            {
                return $.$spc.System.String.Format$2("'{0}' has to be greater than '{1}' and less than '{2}'.", arg1, arg2, arg3);
            }
            static /*string */ get net_collection_readonly()
            {
                return "The collection is read-only.";
            }
            static /*string */ get net_nodefaultcreds()
            {
                return "Default credentials cannot be supplied for the {0} authentication scheme.";
            }
            static /*string */ Formatnet_nodefaultcreds(/*object*/ arg1)
            {
                return $.$spc.System.String.Format("Default credentials cannot be supplied for the {0} authentication scheme.", arg1);
            }
            static /*string */ get InvalidOperation_EnumFailedVersion()
            {
                return "Collection was modified after the enumerator was instantiated.";
            }
            static /*string */ get InvalidOperation_EnumOpCantHappen()
            {
                return "Enumeration has either not started or has already finished.";
            }
            static /*string */ get bad_endpoint_string()
            {
                return "An invalid IPEndPoint was specified.";
            }
            static /*string */ get PlatformNotSupported_NetPrimitives()
            {
                return "System.Net.Primitives is not supported on this platform.";
            }
            /*bool*/ static s_usingResourceKeys = false;
            static /*bool */ GetUsingResourceKeysSwitchValue()
            {
                /*bool*/ let usingResourceKeys;
                return $.$spc.System.AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", $.$ref(() => usingResourceKeys, ($v) => usingResourceKeys = $v, $.$spc.System.Boolean)) ? usingResourceKeys : false;
            }
            static /*bool */ UsingResourceKeys()
            {
                return $.$snp.System.SR.s_usingResourceKeys;
            }
            static /*string */ GetResourceString(/*string*/ resourceKey)
            {
                if ($.$snp.System.SR.UsingResourceKeys())
                {
                    return resourceKey;
                }
                /*string?*/ let resourceString = null;
                try
                {
                    resourceString = $.$snp.System.SR.ResourceManager.GetString(resourceKey);
                }
                catch($e)
                {
                }
                return resourceString;
            }
            static /*string */ GetResourceString$1(/*string*/ resourceKey, /*string*/ defaultString)
            {
                /*string*/ let resourceString = $.$snp.System.SR.GetResourceString(resourceKey);
                return $.$spc.System.String.op_Equality(resourceKey, resourceString) || $.$spc.System.String.op_Equality(resourceString, null) ? defaultString : resourceString;
            }
            static /*string */ Format(/*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$snp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format(resourceFormat, p1);
            }
            static /*string */ Format$1(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$snp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$1(resourceFormat, p1, p2);
            }
            static /*string */ Format$2(/*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$snp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$2(resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$3(/*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$snp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$3(resourceFormat, args);
                }
                return resourceFormat;
            }
            static /*string */ Format$4(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1)
            {
                if ($.$snp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1 ]));
                }
                return $.$spc.System.String.Format$5(provider, resourceFormat, p1);
            }
            static /*string */ Format$5(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2)
            {
                if ($.$snp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2 ]));
                }
                return $.$spc.System.String.Format$6(provider, resourceFormat, p1, p2);
            }
            static /*string */ Format$6(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*object?*/ p1, /*object?*/ p2, /*object?*/ p3)
            {
                if ($.$snp.System.SR.UsingResourceKeys())
                {
                    return $.$spc.System.String.Join$10(", ", $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit([ resourceFormat, p1, p2, p3 ]));
                }
                return $.$spc.System.String.Format$7(provider, resourceFormat, p1, p2, p3);
            }
            static /*string */ Format$7(/*IFormatProvider?*/ provider, /*string*/ resourceFormat, /*params object?[]?*/ args)
            {
                if (args !== null)
                {
                    if ($.$snp.System.SR.UsingResourceKeys())
                    {
                        return resourceFormat + ", " + $.$spc.System.String.Join$9(", ", args);
                    }
                    return $.$spc.System.String.Format$8(provider, resourceFormat, args);
                }
                return resourceFormat;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_usingResourceKeys = $.$snp.System.SR.GetUsingResourceKeysSwitchValue();
                }
            }
            static $h = 5693196;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"h":5693196}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.SR`; }
        });
        
        $asm.$cls("$snp.System.Net.Cookie", ($self) => class Cookie extends $.$spc.System.Object
        {
            /*int*/ static MaxSupportedVersion = 1;
            /*string*/ static MaxSupportedVersionString = null;
            /*string*/ static SeparatorLiteral = null;
            /*char*/ static EqualsLiteral = /*=*/ 61;
            /*string*/ static QuotesLiteral = null;
            /*string*/ static SpecialAttributeLiteral = null;
            /*char[]*/ static PortSplitDelimiters = null;
            /*SearchValues<char>*/ static s_reservedToNameChars = null;
            /*SearchValues<char>*/ static s_domainChars = null;
            /*string*/ m_comment = null;
            /*Uri?*/ m_commentUri = null;
            /*CookieVariant*/ m_cookieVariant = 1;
            /*bool*/ m_discard = false;
            /*string*/ m_domain = null;
            /*bool*/ m_domain_implicit = true;
            /*DateTime*/ m_expires;
            /*string*/ m_name = null;
            /*string*/ m_path = null;
            /*bool*/ m_path_implicit = true;
            /*string*/ m_port = null;
            /*bool*/ m_port_implicit = true;
            /*int[]?*/ m_port_list = null;
            /*bool*/ m_secure = false;
            /*bool*/ m_httpOnly = false;
            /*DateTime*/ m_timeStamp;
            /*string*/ m_value = null;
            /*int*/ m_version = 0;
            /*string?*/ m_domainKey = null;
            /*bool*/ IsQuotedVersion = false;
            /*bool*/ IsQuotedDomain = false;
            /*Static constructor*/ static $cctor()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.Equals$3.call($.$spc.System.Int32.ToString$2.call(1/*MaxSupportedVersion*/, $.$spc.System.Globalization.NumberFormatInfo.InvariantInfo), "1"/*MaxSupportedVersionString*/, 4/*StringComparison.Ordinal*/), "MaxSupportedVersion.ToString(NumberFormatInfo.InvariantInfo).Equals(MaxSupportedVersionString, StringComparison.Ordinal)");
            }
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*string*/ name, /*string?*/ value)
            {
                super.$ctor();
                {
                    this.Name = name;
                    this.Value = value;
                }
                return this;
            }
            $ctor$3(/*string*/ name, /*string?*/ value, /*string?*/ path)
            {
                this.$ctor$2(name, value);
                {
                    this.Path = path;
                }
                return this;
            }
            $ctor$4(/*string*/ name, /*string?*/ value, /*string?*/ path, /*string?*/ domain)
            {
                this.$ctor$3(name, value, path);
                {
                    this.Domain = domain;
                }
                return this;
            }
            /*string */ get Comment()
            {
                return this.m_comment;
            }
            /*string */ set Comment(value)
            {
                this.m_comment = value ?? $.$spc.System.String.Empty;
            }
            /*Uri? */ get CommentUri()
            {
                return this.m_commentUri;
            }
            /*Uri? */ set CommentUri(value)
            {
                this.m_commentUri = value;
            }
            /*bool */ get HttpOnly()
            {
                return this.m_httpOnly;
            }
            /*bool */ set HttpOnly(value)
            {
                this.m_httpOnly = value;
            }
            /*bool */ get Discard()
            {
                return this.m_discard;
            }
            /*bool */ set Discard(value)
            {
                this.m_discard = value;
            }
            /*string */ get Domain()
            {
                return this.m_domain;
            }
            /*string */ set Domain(value)
            {
                this.SetDomainAndKey(value ?? $.$spc.System.String.Empty);
                this.m_domain_implicit = false;
            }
            /*bool */ get DomainImplicit()
            {
                return this.m_domain_implicit;
            }
            /*bool */ set DomainImplicit(value)
            {
                this.m_domain_implicit = value;
            }
            /*bool */ get Expired()
            {
                return ($.$spc.System.DateTime.op_Inequality(this.m_expires, $.$spc.System.DateTime.MinValue)) && ($.$spc.System.DateTime.op_LessThanOrEqual(this.m_expires.ToUniversalTime(), $.$spc.System.DateTime.UtcNow));
            }
            /*bool */ set Expired(value)
            {
                if (value)
                {
                    this.m_expires = $.$spc.System.DateTime.UtcNow;
                }
            }
            /*DateTime */ get Expires()
            {
                return this.m_expires;
            }
            /*DateTime */ set Expires(value)
            {
                this.m_expires = value;
            }
            /*string */ get Name()
            {
                return this.m_name;
            }
            /*string */ set Name(value)
            {
                if ($.$spc.System.String.IsNullOrEmpty(value) || !this.InternalSetName(value))
                {
                    throw new $.$snp.System.Net.CookieException().$ctor$14($.$snp.System.SR.Format$1($.$snp.System.SR.net_cookie_attribute, "Name", value ?? "<null>"));
                }
            }
            /*bool */ InternalSetName(/*string?*/ value)
            {
                if ($.$spc.System.String.IsNullOrEmpty(value) || $.$spc.System.String.StartsWith$3.call(value, /*$*/ 36) || $.$spc.System.String.StartsWith$3.call(value, /* */ 32) || $.$spc.System.String.EndsWith$3.call(value, /* */ 32) || $.$spc.System.MemoryExtensions.ContainsAny$11($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(value), $.$snp.System.Net.Cookie.s_reservedToNameChars))
                {
                    this.m_name = $.$spc.System.String.Empty;
                    return false;
                }
                this.m_name = value;
                return true;
            }
            /*string */ get Path()
            {
                return this.m_path;
            }
            /*string */ set Path(value)
            {
                this.m_path = value ?? $.$spc.System.String.Empty;
                this.m_path_implicit = false;
            }
            /*bool */ get Plain()
            {
                return this.Variant === 1/*CookieVariant.Plain*/;
            }
            /*Cookie */ Clone()
            {
                /*Cookie*/ let clonedCookie = new $.$snp.System.Net.Cookie().$ctor$2(this.m_name, this.m_value);
                if (!this.m_port_implicit)
                {
                    clonedCookie.Port = this.m_port;
                }
                if (!this.m_path_implicit)
                {
                    clonedCookie.Path = this.m_path;
                }
                clonedCookie.m_domain = this.m_domain;
                clonedCookie.DomainImplicit = this.m_domain_implicit;
                clonedCookie.m_domainKey = this.m_domainKey;
                clonedCookie.m_timeStamp = this.m_timeStamp;
                clonedCookie.Comment = this.m_comment;
                clonedCookie.CommentUri = this.m_commentUri;
                clonedCookie.HttpOnly = this.m_httpOnly;
                clonedCookie.Discard = this.m_discard;
                clonedCookie.Expires = this.m_expires;
                clonedCookie.Version = this.m_version;
                clonedCookie.Secure = this.m_secure;
                clonedCookie.m_cookieVariant = this.m_cookieVariant;
                return clonedCookie;
            }
            /*void */ SetDomainAndKey(/*string*/ domain)
            {
                this.m_domain = domain;
                this.m_domainKey = $.$spc.System.String.ToLowerInvariant.call($.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call($.$snp.System.Net.CookieComparer.StripLeadingDot($.$spc.System.String.op_Implicit(this.m_domain))));
            }
            static /*bool */ HostMatchesDomain(/*ReadOnlySpan<char>*/ host, /*ReadOnlySpan<char>*/ domain)
            {
                if (!$.$spc.System.MemoryExtensions.EndsWith$5(host, domain, 4/*StringComparison.Ordinal*/))
                {
                    return false;
                }
                /*int*/ let idxOfSeparator = ((((host.Length - domain.Length) | 0) - 1) | 0);
                if (idxOfSeparator < 0)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(idxOfSeparator === -1, "idxOfSeparator == -1");
                    return true;
                }
                return host.get_Item(idxOfSeparator).$v === /*.*/ 46 && $.$spc.System.MemoryExtensions.Contains$1($.$spc.System.Char, domain, /*.*/ 46) && !$.$snp.System.Net.IPAddress.IsValid(host);
            }
            /*void */ VerifyAndSetDefaults(/*CookieVariant*/ variant, /*Uri*/ uri)
            {
                /*string*/ let host = uri.Host;
                /*int*/ let port = uri.Port;
                /*string*/ let path = uri.AbsolutePath;
                if (this.Version === 0)
                {
                    variant = 1/*CookieVariant.Plain*/;
                }
                else if (this.Version === 1 && variant === 0/*CookieVariant.Unknown*/)
                {
                    variant = 2/*CookieVariant.Default*/;
                }
                this.m_cookieVariant = variant;
                if ($.$spc.System.String.IsNullOrEmpty(this.m_name) || $.$spc.System.String.StartsWith$3.call(this.m_name, /*$*/ 36) || $.$spc.System.String.StartsWith$3.call(this.m_name, /* */ 32) || $.$spc.System.String.EndsWith$3.call(this.m_name, /* */ 32) || $.$spc.System.MemoryExtensions.ContainsAny$11($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(this.m_name), $.$snp.System.Net.Cookie.s_reservedToNameChars))
                {
                    throw new $.$snp.System.Net.CookieException().$ctor$14($.$snp.System.SR.Format$1($.$snp.System.SR.net_cookie_attribute, "Name", this.m_name ?? "<null>"));
                }
                if ($.$spc.System.String.op_Equality(this.m_value, null) || $.$spc.System.MemoryExtensions.ContainsAny$7($.$spc.System.Char, $.$spc.System.String.op_Implicit(this.m_value), /*\r*/ 13, /*\n*/ 10, /*\u0000*/ 0) || (!(this.m_value.length > 2 && $.$spc.System.String.StartsWith$3.call(this.m_value, /*\"*/ 34) && $.$spc.System.String.EndsWith$3.call(this.m_value, /*\"*/ 34)) && $.$spc.System.MemoryExtensions.ContainsAny$5($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(this.m_value), /*;*/ 59, /*,*/ 44)))
                {
                    throw new $.$snp.System.Net.CookieException().$ctor$14($.$snp.System.SR.Format$1($.$snp.System.SR.net_cookie_attribute, "Value", this.m_value ?? "<null>"));
                }
                if ($.$spc.System.String.op_Inequality(this.Comment, null) && !(this.Comment.length > 2 && $.$spc.System.String.StartsWith$3.call(this.Comment, /*\"*/ 34) && $.$spc.System.String.EndsWith$3.call(this.Comment, /*\"*/ 34)) && ($.$spc.System.MemoryExtensions.ContainsAny$5($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(this.Comment), /*;*/ 59, /*,*/ 44)))
                {
                    throw new $.$snp.System.Net.CookieException().$ctor$14($.$snp.System.SR.Format$1($.$snp.System.SR.net_cookie_attribute, "Comment"/*CookieFields.CommentAttributeName*/, this.Comment));
                }
                if ($.$spc.System.String.op_Inequality(this.Path, null) && !(this.Path.length > 2 && $.$spc.System.String.StartsWith$3.call(this.Path, /*\"*/ 34) && $.$spc.System.String.EndsWith$3.call(this.Path, /*\"*/ 34)) && ($.$spc.System.MemoryExtensions.ContainsAny$5($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(this.Path), /*;*/ 59, /*,*/ 44)))
                {
                    throw new $.$snp.System.Net.CookieException().$ctor$14($.$snp.System.SR.Format$1($.$snp.System.SR.net_cookie_attribute, "Path"/*CookieFields.PathAttributeName*/, this.Path));
                }
                if (this.m_domain_implicit)
                {
                    this.SetDomainAndKey(host);
                }
                else 
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!(this.m_domainKey === null), "m_domainKey is not null");
                    if (!$.$snp.System.Net.Cookie.IsValidDomainName($.$spc.System.String.op_Implicit(this.m_domainKey)) || !$.$snp.System.Net.Cookie.HostMatchesDomain($.$spc.System.String.op_Implicit(host), $.$spc.System.String.op_Implicit(this.m_domainKey)))
                    {
                        throw new $.$snp.System.Net.CookieException().$ctor$14($.$snp.System.SR.Format$1($.$snp.System.SR.net_cookie_attribute, "Domain"/*CookieFields.DomainAttributeName*/, this.m_domain));
                    }
                }
                if (this.m_path_implicit)
                {
                    switch(this.m_cookieVariant)
                    {
                        case 1/*CookieVariant.Plain*/:
                        /*int*/ let lastSlash;
                        if (!$.$spc.System.String.StartsWith$3.call(path, /*/*/ 47) || (lastSlash = $.$spc.System.String.LastIndexOf.call(path, /*/*/ 47)) === 0)
                        {
                            this.m_path = "/";
                            break;
                        }
                        this.m_path = $.$spc.System.String.Substring$1.call(path, 0, lastSlash);
                        break;
                        case 2/*CookieVariant.Rfc2109*/:
                        this.m_path = $.$spc.System.String.Substring$1.call(path, 0, $.$spc.System.String.LastIndexOf.call(path, /*/*/ 47));
                        break;
                        case 3/*CookieVariant.Rfc2965*/:
                        default:
                        this.m_path = $.$spc.System.String.Substring$1.call(path, 0, (($.$spc.System.String.LastIndexOf.call(path, /*/*/ 47) + 1) | 0));
                        break;
                    }
                }
                if (this.m_port_implicit === false && this.m_port.length === 0)
                {
                    this.m_port_list = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), [port], [1], null);
                }
                if (this.m_port_implicit === false)
                {
                    /*bool*/ let valid = false;
                    let $i1 = 0;
                    let $arr1 = this.m_port_list;
                    while ($i1 < $arr1.length)
                    {
                        let p = $arr1[$i1++];
                        if (p === port)
                        {
                            valid = true;
                            break;
                        }
                    }
                    if (!valid)
                    {
                        throw new $.$snp.System.Net.CookieException().$ctor$14($.$snp.System.SR.Format$1($.$snp.System.SR.net_cookie_attribute, "Port"/*CookieFields.PortAttributeName*/, this.m_port));
                    }
                }
            }
            static /*bool */ IsValidDomainName(/*ReadOnlySpan<char>*/ name)
            {
                return !name.IsEmpty && !$.$spc.System.MemoryExtensions.ContainsAnyExcept$13($.$spc.System.Char, name, $.$snp.System.Net.Cookie.s_domainChars);
            }
            /*string */ get Port()
            {
                return this.m_port;
            }
            /*string */ set Port(value)
            {
                if ($.$spc.System.String.IsNullOrEmpty(value))
                {
                    this.m_port_implicit = true;
                    this.m_port = $.$spc.System.String.Empty;
                }
                else 
                {
                    this.m_port_implicit = false;
                    if (!$.$spc.System.String.StartsWith$3.call(value, /*\"*/ 34) || !$.$spc.System.String.EndsWith$3.call(value, /*\"*/ 34))
                    {
                        throw new $.$snp.System.Net.CookieException().$ctor$14($.$snp.System.SR.Format$1($.$snp.System.SR.net_cookie_attribute, "Port"/*CookieFields.PortAttributeName*/, value));
                    }
                    /*string[]*/ let ports = $.$spc.System.String.Split$5.call(value, $.$snp.System.Net.Cookie.PortSplitDelimiters, 1/*StringSplitOptions.RemoveEmptyEntries*/);
                    /*int[]*/ let parsedPorts = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Int32), null, [ports.length], null);
                    for(/*int*/ let i = 0; i < ports.length; ++i)
                    {
                        /*int*/ let port;
                        if (!$.$spc.System.Int32.TryParse($.$spc.System.Array.$ReadT1.call(ports, i), $.$ref(() => port, ($v) => port = $v, $.$spc.System.Int32)))
                        {
                            throw new $.$snp.System.Net.CookieException().$ctor$14($.$snp.System.SR.Format$1($.$snp.System.SR.net_cookie_attribute, "Port"/*CookieFields.PortAttributeName*/, value));
                        }
                        if ((port < 0) || (port > 65535))
                        {
                            throw new $.$snp.System.Net.CookieException().$ctor$14($.$snp.System.SR.Format$1($.$snp.System.SR.net_cookie_attribute, "Port"/*CookieFields.PortAttributeName*/, value));
                        }
                        $.$spc.System.Array.$WriteT1.call(parsedPorts, port, i);
                    }
                    this.m_port_list = parsedPorts;
                    this.m_port = value;
                    this.m_version = 1/*MaxSupportedVersion*/;
                    this.m_cookieVariant = 3/*CookieVariant.Rfc2965*/;
                }
            }
            /*int[]? */ get PortList()
            {
                return this.m_port_list;
            }
            /*bool */ get Secure()
            {
                return this.m_secure;
            }
            /*bool */ set Secure(value)
            {
                this.m_secure = value;
            }
            /*DateTime */ get TimeStamp()
            {
                return this.m_timeStamp;
            }
            /*string */ get Value()
            {
                return this.m_value;
            }
            /*string */ set Value(value)
            {
                this.m_value = value ?? $.$spc.System.String.Empty;
            }
            /*CookieVariant */ get Variant()
            {
                return this.m_cookieVariant;
            }
            /*string */ get DomainKey()
            {
                return this.m_domain_implicit ? this.Domain : this.m_domainKey;
            }
            /*int */ get Version()
            {
                return this.m_version;
            }
            /*int */ set Version(value)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, value, "value");
                this.m_version = value;
                if (value > 0 && this.m_cookieVariant < 2/*CookieVariant.Rfc2109*/)
                {
                    this.m_cookieVariant = 2/*CookieVariant.Rfc2109*/;
                }
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                let other;
                return $.$is(comparand, $.$snp.System.Net.Cookie, { set $v(v){ other = v; } }) && $.$spc.System.String.Equals$5(this.Name, other.Name, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$spc.System.String.Equals$5(this.Value, other.Value, 4/*StringComparison.Ordinal*/) && $.$spc.System.String.Equals$5(this.Path, other.Path, 4/*StringComparison.Ordinal*/) && $.$snp.System.Net.CookieComparer.EqualDomains($.$spc.System.String.op_Implicit(this.Domain), $.$spc.System.String.op_Implicit(other.Domain)) && (this.Version === other.Version);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snp.System.Net.Cookie.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$4($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(this.Name), $.$spc.System.StringComparer.Ordinal.GetHashCode$2(this.Value), $.$spc.System.StringComparer.Ordinal.GetHashCode$2(this.Path), $.$spc.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(this.DomainKey), this.Version);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snp.System.Net.Cookie.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                /*StringBuilder*/ let sb = $.$snp.System.Text.StringBuilderCache.Acquire(16);
                this.ToString$1(sb);
                return $.$snp.System.Text.StringBuilderCache.GetStringAndRelease(sb);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.Cookie.ToString.apply(this, arguments); }
            /*void */ ToString$1(/*StringBuilder*/ sb)
            {
                /*int*/ let beforeLength = sb.Length;
                if (this.Version !== 0)
                {
                    sb.Append$2("$"/*SpecialAttributeLiteral*/ + "Version"/*CookieFields.VersionAttributeName*/ + /*=*/ 61);
                    if (this.IsQuotedVersion)
                    {
                        sb.Append$7(/*\"*/ 34);
                    }
                    sb.Append$24($.$spc.System.Globalization.NumberFormatInfo.InvariantInfo, `${this.m_version}`);
                    if (this.IsQuotedVersion)
                    {
                        sb.Append$7(/*\"*/ 34);
                    }
                    sb.Append$2("; "/*SeparatorLiteral*/);
                }
                sb.Append$2(this.Name).Append$7(/*=*/ 61).Append$2(this.Value);
                if (!this.Plain)
                {
                    if (!this.m_path_implicit && this.m_path.length > 0)
                    {
                        sb.Append$2("; "/*SeparatorLiteral*/ + "$"/*SpecialAttributeLiteral*/ + "Path"/*CookieFields.PathAttributeName*/ + /*=*/ 61);
                        sb.Append$2(this.m_path);
                    }
                    if (!this.m_domain_implicit && this.m_domain.length > 0)
                    {
                        sb.Append$2("; "/*SeparatorLiteral*/ + "$"/*SpecialAttributeLiteral*/ + "Domain"/*CookieFields.DomainAttributeName*/ + /*=*/ 61);
                        if (this.IsQuotedDomain)
                        {
                            sb.Append$7(/*\"*/ 34);
                        }
                        sb.Append$2(this.m_domain);
                        if (this.IsQuotedDomain)
                        {
                            sb.Append$7(/*\"*/ 34);
                        }
                    }
                }
                if (!this.m_port_implicit)
                {
                    sb.Append$2("; "/*SeparatorLiteral*/ + "$"/*SpecialAttributeLiteral*/ + "Port"/*CookieFields.PortAttributeName*/);
                    if (this.m_port.length > 0)
                    {
                        sb.Append$7(/*=*/ 61);
                        sb.Append$2(this.m_port);
                    }
                }
                /*int*/ let afterLength = sb.Length;
                if (afterLength === (((1 + beforeLength) | 0)) && sb.get_Chars(beforeLength) === /*=*/ 61)
                {
                    sb.Length = beforeLength;
                }
            }
            /*string? */ ToServerString()
            {
                /*string*/ let result = this.Name + /*=*/ 61 + this.Value;
                if ($.$spc.System.String.op_Inequality(this.m_comment, null) && this.m_comment.length > 0)
                {
                    result += "; "/*SeparatorLiteral*/ + "Comment"/*CookieFields.CommentAttributeName*/ + /*=*/ 61 + this.m_comment;
                }
                if ($.$spu.System.Uri.op_Inequality(this.m_commentUri, null))
                {
                    result += "; "/*SeparatorLiteral*/ + "CommentURL"/*CookieFields.CommentUrlAttributeName*/ + /*=*/ 61 + "\""/*QuotesLiteral*/ + $.$spu.System.Uri.ToString.call(this.m_commentUri) + "\""/*QuotesLiteral*/;
                }
                if (this.m_discard)
                {
                    result += "; "/*SeparatorLiteral*/ + "Discard"/*CookieFields.DiscardAttributeName*/;
                }
                if (!this.m_domain_implicit && $.$spc.System.String.op_Inequality(this.m_domain, null) && this.m_domain.length > 0)
                {
                    result += "; "/*SeparatorLiteral*/ + "Domain"/*CookieFields.DomainAttributeName*/ + /*=*/ 61 + this.m_domain;
                }
                if ($.$spc.System.DateTime.op_Inequality(this.Expires, $.$spc.System.DateTime.MinValue))
                {
                    /*int*/ let seconds = $.$cast(($.$spc.System.DateTime.op_Subtraction$1(this.Expires.ToUniversalTime(), $.$spc.System.DateTime.UtcNow)).TotalSeconds, $.$spc.System.Int32);
                    if (seconds < 0)
                    {
                        seconds = 0;
                    }
                    result += "; "/*SeparatorLiteral*/ + "Max-Age"/*CookieFields.MaxAgeAttributeName*/ + /*=*/ 61 + $.$spc.System.Int32.ToString$2.call(seconds, $.$spc.System.Globalization.NumberFormatInfo.InvariantInfo);
                }
                if (!this.m_path_implicit && $.$spc.System.String.op_Inequality(this.m_path, null) && this.m_path.length > 0)
                {
                    result += "; "/*SeparatorLiteral*/ + "Path"/*CookieFields.PathAttributeName*/ + /*=*/ 61 + this.m_path;
                }
                if (!this.Plain && !this.m_port_implicit && $.$spc.System.String.op_Inequality(this.m_port, null) && this.m_port.length > 0)
                {
                    result += "; "/*SeparatorLiteral*/ + "Port"/*CookieFields.PortAttributeName*/ + /*=*/ 61 + this.m_port;
                }
                if (this.m_version > 0)
                {
                    result += "; "/*SeparatorLiteral*/ + "Version"/*CookieFields.VersionAttributeName*/ + /*=*/ 61 + $.$spc.System.Int32.ToString$2.call(this.m_version, $.$spc.System.Globalization.NumberFormatInfo.InvariantInfo);
                }
                return $.$spc.System.String.op_Equality(result, "=") ? null : result;
            }
            //default member initializer
            constructor()
            {
                super();
                this.m_comment = $.$spc.System.String.Empty;
                this.m_domain = $.$spc.System.String.Empty;
                this.m_expires = $.$spc.System.DateTime.MinValue;
                this.m_name = $.$spc.System.String.Empty;
                this.m_path = $.$spc.System.String.Empty;
                this.m_port = $.$spc.System.String.Empty;
                this.m_timeStamp = $.$spc.System.DateTime.UtcNow;
                this.m_value = $.$spc.System.String.Empty;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.MaxSupportedVersionString = "1";
                }
                {
                    this.SeparatorLiteral = "; ";
                }
                {
                    this.QuotesLiteral = "\"";
                }
                {
                    this.SpecialAttributeLiteral = "$";
                }
                {
                    this.PortSplitDelimiters = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), [/* */ 32, /*,*/ 44, /*\"*/ 34], [-1], null);
                }
                {
                    this.s_reservedToNameChars = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("\t\u0000\r\n=;,"));
                }
                {
                    this.s_domainChars = $.$spc.System.Buffers.SearchValues.Create$1($.$spc.System.String.op_Implicit("-.0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz"));
                }
            }
            static $h = 1171212;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":158914961164,"f":1},"s":{"r":0,"d":0,"h":163209928460,"f":1},"n":"Comment","d":1171212,"h":154619993868,"f":1},{"p":1744130,"g":{"r":0,"d":0,"h":171799863052,"f":1},"s":{"r":0,"d":0,"h":176094830348,"f":1},"n":"CommentUri","d":1171212,"h":167504895756,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":184684764940,"f":1},"s":{"r":0,"d":0,"h":188979732236,"f":1},"n":"HttpOnly","d":1171212,"h":180389797644,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":197569666828,"f":1},"s":{"r":0,"d":0,"h":201864634124,"f":1},"n":"Discard","d":1171212,"h":193274699532,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":210454568716,"f":1},"s":{"r":0,"d":0,"h":214749536012,"f":1},"n":"Domain","d":1171212,"h":206159601420,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":223339470604,"f":8},"s":{"r":0,"d":0,"h":227634437900,"f":8},"n":"DomainImplicit","d":1171212,"h":219044503308,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":236224372492,"f":1},"s":{"r":0,"d":0,"h":240519339788,"f":1},"n":"Expired","d":1171212,"h":231929405196,"f":1},{"p":34144257,"g":{"r":0,"d":0,"h":249109274380,"f":1},"s":{"r":0,"d":0,"h":253404241676,"f":1},"n":"Expires","d":1171212,"h":244814307084,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":261994176268,"f":1},"s":{"r":0,"d":0,"h":266289143564,"f":1},"n":"Name","d":1171212,"h":257699208972,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":279174045452,"f":1},"s":{"r":0,"d":0,"h":283469012748,"f":1},"n":"Path","d":1171212,"h":274879078156,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":292058947340,"f":8},"n":"Plain","d":1171212,"h":287763980044,"f":8},{"p":1310721,"g":{"r":0,"d":0,"h":322123718412,"f":1},"s":{"r":0,"d":0,"h":326418685708,"f":1},"n":"Port","d":1171212,"h":317828751116,"f":1},{"p":0,"g":{"r":0,"d":0,"h":335008620300,"f":8},"n":"PortList","d":1171212,"h":330713653004,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":343598554892,"f":1},"s":{"r":0,"d":0,"h":347893522188,"f":1},"n":"Secure","d":1171212,"h":339303587596,"f":1},{"p":34144257,"g":{"r":0,"d":0,"h":356483456780,"f":1},"n":"TimeStamp","d":1171212,"h":352188489484,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":365073391372,"f":1},"s":{"r":0,"d":0,"h":369368358668,"f":1},"n":"Value","d":1171212,"h":360778424076,"f":1},{"p":1892108,"g":{"r":0,"d":0,"h":377958293260,"f":8},"n":"Variant","d":1171212,"h":373663325964,"f":8},{"p":1310721,"g":{"r":0,"d":0,"h":386548227852,"f":8},"n":"DomainKey","d":1171212,"h":382253260556,"f":8},{"p":655361,"g":{"r":0,"d":0,"h":395138162444,"f":1},"s":{"r":0,"d":0,"h":399433129740,"f":1},"n":"Version","d":1171212,"h":390843195148,"f":1}],"m":[{"r":262145,"p":[{"n":"value","p":1310721}],"n":"InternalSetName","d":1171212,"h":270584110860,"f":8},{"r":1171212,"n":"Clone","d":1171212,"h":296353914636,"f":8},{"r":65537,"p":[{"n":"domain","p":1310721}],"n":"SetDomainAndKey","d":1171212,"h":300648881932,"f":2},{"r":262145,"p":[{"n":"host","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"domain","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"HostMatchesDomain","d":1171212,"h":304943849228,"f":34},{"r":65537,"p":[{"n":"variant","p":1892108},{"n":"uri","p":1744130}],"n":"VerifyAndSetDefaults","d":1171212,"h":309238816524,"f":8},{"r":262145,"p":[{"n":"name","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"IsValidDomainName","d":1171212,"h":313533783820,"f":34},{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":1171212,"h":403728097036,"f":32769},{"r":655361,"n":"GetHashCode","d":1171212,"h":408023064332,"f":32769},{"r":1310721,"n":"ToString","d":1171212,"h":412318031628,"f":32769},{"r":65537,"p":[{"n":"sb","p":122945537}],"n":"ToString","o":"@$1","d":1171212,"h":416612998924,"f":8},{"r":1310721,"n":"ToServerString","d":1171212,"h":420907966220,"f":8}],"l":[{"t":655361,"n":"MaxSupportedVersion","d":1171212,"h":4296138508,"f":40},{"t":1310721,"n":"MaxSupportedVersionString","d":1171212,"h":8591105804,"f":40},{"t":1310721,"n":"SeparatorLiteral","d":1171212,"h":12886073100,"f":40},{"t":458753,"n":"EqualsLiteral","d":1171212,"h":17181040396,"f":40},{"t":1310721,"n":"QuotesLiteral","d":1171212,"h":21476007692,"f":40},{"t":1310721,"n":"SpecialAttributeLiteral","d":1171212,"h":25770974988,"f":40},{"t":0,"n":"PortSplitDelimiters","d":1171212,"h":30065942284,"f":40},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"s_reservedToNameChars","d":1171212,"h":34360909580,"f":34},{"t":$.$spc.System.Buffers.SearchValues$$($.$spc.System.Char).$h,"n":"s_domainChars","d":1171212,"h":38655876876,"f":34},{"t":1310721,"n":"m_comment","d":1171212,"h":42950844172,"f":2},{"t":1744130,"n":"m_commentUri","d":1171212,"h":47245811468,"f":2},{"t":1892108,"n":"m_cookieVariant","d":1171212,"h":51540778764,"f":2},{"t":262145,"n":"m_discard","d":1171212,"h":55835746060,"f":2},{"t":1310721,"n":"m_domain","d":1171212,"h":60130713356,"f":2},{"t":262145,"n":"m_domain_implicit","d":1171212,"h":64425680652,"f":2},{"t":34144257,"n":"m_expires","d":1171212,"h":68720647948,"f":2},{"t":1310721,"n":"m_name","d":1171212,"h":73015615244,"f":2},{"t":1310721,"n":"m_path","d":1171212,"h":77310582540,"f":2},{"t":262145,"n":"m_path_implicit","d":1171212,"h":81605549836,"f":2},{"t":1310721,"n":"m_port","d":1171212,"h":85900517132,"f":2},{"t":262145,"n":"m_port_implicit","d":1171212,"h":90195484428,"f":2},{"t":0,"n":"m_port_list","d":1171212,"h":94490451724,"f":2},{"t":262145,"n":"m_secure","d":1171212,"h":98785419020,"f":2},{"t":262145,"n":"m_httpOnly","d":1171212,"h":103080386316,"f":2,"a":[{"t":113704961,"c":21588541441}]},{"t":34144257,"n":"m_timeStamp","d":1171212,"h":107375353612,"f":2},{"t":1310721,"n":"m_value","d":1171212,"h":111670320908,"f":2},{"t":655361,"n":"m_version","d":1171212,"h":115965288204,"f":2},{"t":1310721,"n":"m_domainKey","d":1171212,"h":120260255500,"f":2},{"t":262145,"n":"IsQuotedVersion","d":1171212,"h":124555222796,"f":8},{"t":262145,"n":"IsQuotedDomain","d":1171212,"h":128850190092,"f":8}],"c":[{"n":".ctor","o":"$ctor$1","d":1171212,"h":137440124684,"f":1},{"p":[{"n":"name","p":1310721},{"n":"value","p":1310721}],"n":".ctor","o":"$ctor$2","d":1171212,"h":141735091980,"f":1},{"p":[{"n":"name","p":1310721},{"n":"value","p":1310721},{"n":"path","p":1310721}],"n":".ctor","o":"$ctor$3","d":1171212,"h":146030059276,"f":1},{"p":[{"n":"name","p":1310721},{"n":"value","p":1310721},{"n":"path","p":1310721},{"n":"domain","p":1310721}],"n":".ctor","o":"$ctor$4","d":1171212,"h":150325026572,"f":1}],"h":1171212,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Cookie`; }
        });
        
        $asm.$cls("$snp.System.Net.CookieContainer", ($self) => class CookieContainer extends $.$spc.System.Object
        {
            /*int*/ static DefaultCookieLimit = 300;
            /*int*/ static DefaultPerDomainCookieLimit = 20;
            /*int*/ static DefaultCookieLengthLimit = 4096;
            /*HeaderVariantInfo[]*/ static s_headerInfo = null;
            /*Hashtable*/ m_domainTable = null;
            /*int*/ m_maxCookieSize = 4096;
            /*int*/ m_maxCookies = 300;
            /*int*/ m_maxCookiesPerDomain = 20;
            /*int*/ m_count = 0;
            /*string*/ m_fqdnMyDomain = null;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*int*/ capacity)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$spc.System.Int32, capacity, "capacity");
                    this.m_maxCookies = capacity;
                }
                return this;
            }
            $ctor$3(/*int*/ capacity, /*int*/ perDomainCapacity, /*int*/ maxCookieSize)
            {
                this.$ctor$2(capacity);
                {
                    if (perDomainCapacity !== 2147483647/*int.MaxValue*/ && (perDomainCapacity <= 0 || perDomainCapacity > capacity))
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("perDomainCapacity", $.$snp.System.SR.Format$2($.$snp.System.SR.net_cookie_capacity_range, "PerDomainCapacity", $.$box(0, $.$spc.System.Int32), $.$box(capacity, $.$spc.System.Int32)));
                    }
                    this.m_maxCookiesPerDomain = perDomainCapacity;
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$spc.System.Int32, maxCookieSize, "maxCookieSize");
                    this.m_maxCookieSize = maxCookieSize;
                }
                return this;
            }
            /*int */ get Capacity()
            {
                return this.m_maxCookies;
            }
            /*int */ set Capacity(value)
            {
                if (value <= 0 || (value < this.m_maxCookiesPerDomain && this.m_maxCookiesPerDomain !== 2147483647/*int.MaxValue*/))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$17("value", $.$snp.System.SR.Format$2($.$snp.System.SR.net_cookie_capacity_range, "Capacity", $.$box(0, $.$spc.System.Int32), $.$box(this.m_maxCookiesPerDomain, $.$spc.System.Int32)));
                }
                if (value < this.m_maxCookies)
                {
                    this.m_maxCookies = value;
                    this.AgeCookies(null);
                }
                this.m_maxCookies = value;
            }
            /*int */ get Count()
            {
                return this.m_count;
            }
            /*int */ get MaxCookieSize()
            {
                return this.m_maxCookieSize;
            }
            /*int */ set MaxCookieSize(value)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$spc.System.Int32, value, "value");
                this.m_maxCookieSize = value;
            }
            /*int */ get PerDomainCapacity()
            {
                return this.m_maxCookiesPerDomain;
            }
            /*int */ set PerDomainCapacity(value)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegativeOrZero($.$spc.System.Int32, value, "value");
                if (value !== 2147483647/*int.MaxValue*/)
                {
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, value, this.m_maxCookies, "value");
                }
                if (value < this.m_maxCookiesPerDomain)
                {
                    this.m_maxCookiesPerDomain = value;
                    this.AgeCookies(null);
                }
                this.m_maxCookiesPerDomain = value;
            }
            /*void */ Add(/*Cookie*/ cookie)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(cookie, "cookie");
                if (cookie.Domain.length === 0)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$snp.System.SR.Format($.$snp.System.SR.net_emptystringcall, "cookie" + "." + "Domain"), "cookie");
                }
                /*Uri?*/ let uri;
                /*var*/ let uriSb = new $.$spc.System.Text.StringBuilder().$ctor$1();
                uriSb.Append$2(cookie.Secure ? "https"/*UriScheme.Https*/ : "http"/*UriScheme.Http*/).Append$2("://"/*UriScheme.SchemeDelimiter*/);
                if (!cookie.DomainImplicit)
                {
                    if ($.$spc.System.String.get_Chars.call(cookie.Domain, 0) === /*.*/ 46)
                    {
                        uriSb.Append$7(/*0*/ 48);
                    }
                }
                uriSb.Append$2(cookie.Domain);
                if (cookie.PortList !== null)
                {
                    uriSb.Append$7(/*:*/ 58).Append$11($.$spc.System.Array.$ReadT1.call(cookie.PortList, 0));
                }
                uriSb.Append$2(cookie.Path);
                if (!$.$spu.System.Uri.TryCreate($.$spc.System.Text.StringBuilder.ToString.call(uriSb), 1/*UriKind.Absolute*/, $.$ref(() => uri, ($v) => uri = $v, $.$spu.System.Uri)))
                {
                    throw new $.$snp.System.Net.CookieException().$ctor$14($.$snp.System.SR.Format$1($.$snp.System.SR.net_cookie_attribute, "Domain", cookie.Domain));
                }
                /*Cookie*/ let new_cookie = cookie.Clone();
                new_cookie.VerifyAndSetDefaults(new_cookie.Variant, uri);
                this.InternalAdd(new_cookie);
            }
            /*void */ InternalAdd(/*Cookie*/ cookie)
            {
                /*PathList?*/ let pathList;
                if (cookie.Value.length > this.m_maxCookieSize)
                {
                    throw new $.$snp.System.Net.CookieException().$ctor$14($.$snp.System.SR.Format$1($.$snp.System.SR.net_cookie_size, cookie, $.$box(this.m_maxCookieSize, $.$spc.System.Int32)));
                }
                try
                {
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this.m_domainTable.SyncRoot)
                        {
                            pathList = $.$cast(this.m_domainTable.get_Item(cookie.DomainKey), $.$snp.System.Net.PathList);
                            if (pathList === null)
                            {
                                this.m_domainTable.set_Item(cookie.DomainKey, (pathList = new $.$snp.System.Net.PathList().$ctor$1()));
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.m_domainTable.SyncRoot)
                    }
                    /*int*/ let domain_count = pathList.GetCookiesCount();
                    /*CookieCollection?*/ let cookies;
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(pathList.SyncRoot)
                        {
                            cookies = $.$cast(pathList.get_Item(cookie.Path), $.$snp.System.Net.CookieCollection);
                            if (cookies === null)
                            {
                                cookies = new $.$snp.System.Net.CookieCollection().$ctor$1();
                                pathList.set_Item(cookie.Path, cookies);
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(pathList.SyncRoot)
                    }
                    if (cookie.Expired)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(cookies)
                            {
                                /*int*/ let idx = cookies.IndexOf(cookie);
                                if (idx !== -1)
                                {
                                    cookies.RemoveAt(idx);
                                    --this.m_count;
                                }
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(cookies)
                        }
                    }
                    else 
                    {
                        if (domain_count >= this.m_maxCookiesPerDomain && !this.AgeCookies(cookie.DomainKey))
                        {
                            return;
                        }
                        else if (this.m_count >= this.m_maxCookies && !this.AgeCookies(null))
                        {
                            return;
                        }
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(cookies)
                            {
                                this.m_count += cookies.InternalAdd(cookie, true);
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(cookies)
                        }
                    }
                    if (this.m_domainTable.Count > this.m_count || pathList.Count > this.m_maxCookiesPerDomain)
                    {
                        this.DomainTableCleanup();
                    }
                }
                catch($e)
                {
                    if ($e instanceof $.$spc.System.OutOfMemoryException)
                    {
                        throw $e;
                    }
                    else if ($e instanceof $.$spc.System.Exception)
                    {
                        let e = $e;
                        throw new $.$snp.System.Net.CookieException().$ctor$15($.$snp.System.SR.net_container_add_cookie, e);
                    }
                    else
                    {
                        throw $e;
                    }
                }
            }
            /*bool */ AgeCookies(/*string?*/ domain)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.m_maxCookies !== 0, "m_maxCookies != 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(this.m_maxCookiesPerDomain !== 0, "m_maxCookiesPerDomain != 0");
                /*int*/ let removed = 0;
                /*DateTime*/ let oldUsed = $.$spc.System.DateTime.MaxValue;
                /*DateTime*/ let tempUsed;
                /*CookieCollection?*/ let lruCc = null;
                /*string?*/ let lruDomain;
                /*string*/ let tempDomain;
                /*PathList*/ let pathList;
                /*int*/ let domain_count;
                /*int*/ let itemp = 0;
                /*float*/ let remainingFraction = 1;
                if (this.m_count > this.m_maxCookies)
                {
                    remainingFraction = $.$cast(this.m_maxCookies, $.$spc.System.Single) / $.$cast(this.m_count, $.$spc.System.Single);
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.m_domainTable.SyncRoot)
                    {
                        var $en4 = this.m_domainTable.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var item = $en4.Current;
                            {
                                /*DictionaryEntry*/ let entry = $.$cast(item, $.$spc.System.Collections.DictionaryEntry);
                                if ($.$spc.System.String.op_Equality(domain, null))
                                {
                                    tempDomain = $.$cast(entry.Key, $.$spc.System.String);
                                    pathList = $.$cast(entry.Value, $.$snp.System.Net.PathList);
                                }
                                else 
                                {
                                    tempDomain = domain;
                                    pathList = $.$cast(this.m_domainTable.get_Item(domain), $.$snp.System.Net.PathList);
                                }
                                domain_count = 0;
                                //lock
                                try
                                {
                                    $.$spc.System.Threading.Monitor.Enter(pathList.SyncRoot)
                                    {
                                        var $en8 = pathList.Values.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                        while ($en8.System$Collections$IEnumerator$MoveNext())
                                        {
                                            var cc = $en8.System$Collections$Generic$IEnumerator$$$Current;
                                            {
                                                $.$spc.System.Diagnostics.Debug.Assert$1(cc !== null, "cc != null");
                                                itemp = $.$snp.System.Net.CookieContainer.ExpireCollection(cc);
                                                removed += itemp;
                                                this.m_count -= itemp;
                                                domain_count += cc.Count;
                                                if (cc.Count > 0 && $.$spc.System.DateTime.op_LessThan((tempUsed = cc.TimeStamp(0/*CookieCollection.Stamp.Check*/)), oldUsed))
                                                {
                                                    lruDomain = tempDomain;
                                                    lruCc = cc;
                                                    oldUsed = tempUsed;
                                                }
                                            }
                                        }
                                    }
                                }
                                finally
                                {
                                    $.$spc.System.Threading.Monitor.Exit(pathList.SyncRoot)
                                }
                                /*int*/ let min_count = $.$spc.System.Math.Min$4($.$cast((domain_count * remainingFraction), $.$spc.System.Int32), (($.$spc.System.Math.Min$4(this.m_maxCookiesPerDomain, this.m_maxCookies) - 1) | 0));
                                if (domain_count > min_count)
                                {
                                    /*CookieCollection[]*/ let cookies;
                                    /*DateTime[]*/ let stamps;
                                    //lock
                                    try
                                    {
                                        $.$spc.System.Threading.Monitor.Enter(pathList.SyncRoot)
                                        {
                                            cookies = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$snp.System.Net.CookieCollection), null, [pathList.Count], null);
                                            stamps = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.DateTime), null, [pathList.Count], null);
                                            var $en9 = pathList.Values.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                                            while ($en9.System$Collections$IEnumerator$MoveNext())
                                            {
                                                var cc = $en9.System$Collections$Generic$IEnumerator$$$Current;
                                                {
                                                    $.$spc.System.Array.$WriteT1.call(stamps, cc.TimeStamp(0/*CookieCollection.Stamp.Check*/), itemp);
                                                    $.$spc.System.Array.$WriteT1.call(cookies, cc, itemp);
                                                    ++itemp;
                                                }
                                            }
                                        }
                                    }
                                    finally
                                    {
                                        $.$spc.System.Threading.Monitor.Exit(pathList.SyncRoot)
                                    }
                                    $.$spc.System.Array.Sort$9($.$spc.System.DateTime, $.$snp.System.Net.CookieCollection, stamps, cookies);
                                    itemp = 0;
                                    for(/*int*/ let i = 0; i < cookies.length; ++i)
                                    {
                                        /*CookieCollection*/ let cc = $.$spc.System.Array.$ReadT1.call(cookies, i);
                                        //lock
                                        try
                                        {
                                            $.$spc.System.Threading.Monitor.Enter(cc)
                                            {
                                                while(domain_count > min_count && cc.Count > 0)
                                                {
                                                    cc.RemoveAt(0);
                                                    --domain_count;
                                                    --this.m_count;
                                                    ++removed;
                                                }
                                            }
                                        }
                                        finally
                                        {
                                            $.$spc.System.Threading.Monitor.Exit(cc)
                                        }
                                        if (domain_count <= min_count)
                                        {
                                            break;
                                        }
                                    }
                                    if (domain_count > min_count && $.$spc.System.String.op_Inequality(domain, null))
                                    {
                                        return false;
                                    }
                                }
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.m_domainTable.SyncRoot)
                }
                if ($.$spc.System.String.op_Inequality(domain, null))
                {
                    return true;
                }
                if (removed !== 0)
                {
                    return true;
                }
                if ($.$spc.System.DateTime.op_Equality(oldUsed, $.$spc.System.DateTime.MaxValue))
                {
                    return false;
                }
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(lruCc)
                    {
                        while(this.m_count >= this.m_maxCookies && lruCc.Count > 0)
                        {
                            lruCc.RemoveAt(0);
                            --this.m_count;
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(lruCc)
                }
                return true;
            }
            /*void */ DomainTableCleanup()
            {
                /*var*/ let removePathList = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.Object))().$ctor$1();
                /*var*/ let removeDomainList = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$1();
                /*string*/ let currentDomain;
                /*PathList*/ let pathList;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.m_domainTable.SyncRoot)
                    {
                        /*IDictionaryEnumerator*/ let enumerator = this.m_domainTable.GetEnumerator();
                        while(enumerator.System$Collections$IEnumerator$MoveNext())
                        {
                            currentDomain = $.$cast(enumerator.System$Collections$IDictionaryEnumerator$Key, $.$spc.System.String);
                            pathList = $.$cast(enumerator.System$Collections$IDictionaryEnumerator$Value, $.$snp.System.Net.PathList);
                            //lock
                            try
                            {
                                $.$spc.System.Threading.Monitor.Enter(pathList.SyncRoot)
                                {
                                    /*IDictionaryEnumerator*/ let e = pathList.GetEnumerator();
                                    while(e.System$Collections$IEnumerator$MoveNext())
                                    {
                                        /*CookieCollection*/ let cc = $.$cast(e.System$Collections$IDictionaryEnumerator$Value, $.$snp.System.Net.CookieCollection);
                                        if (cc.Count === 0)
                                        {
                                            removePathList.Add(e.System$Collections$IDictionaryEnumerator$Key);
                                        }
                                    }
                                    var $en7 = removePathList.GetEnumerator();
                                    while ($en7.MoveNext())
                                    {
                                        var key = $en7.Current;
                                        {
                                            pathList.Remove(key);
                                        }
                                    }
                                    removePathList.Clear();
                                    if (pathList.Count === 0)
                                    {
                                        removeDomainList.Add(currentDomain);
                                    }
                                }
                            }
                            finally
                            {
                                $.$spc.System.Threading.Monitor.Exit(pathList.SyncRoot)
                            }
                        }
                        var $en4 = removeDomainList.GetEnumerator();
                        while ($en4.MoveNext())
                        {
                            var key = $en4.Current;
                            {
                                this.m_domainTable.Remove(key);
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.m_domainTable.SyncRoot)
                }
            }
            static /*int */ ExpireCollection(/*CookieCollection*/ cc)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(cc)
                    {
                        /*int*/ let oldCount = cc.Count;
                        /*int*/ let idx = ((oldCount - 1) | 0);
                        while(idx >= 0)
                        {
                            /*Cookie*/ let cookie = cc.get_Item(idx);
                            if (cookie.Expired)
                            {
                                cc.RemoveAt(idx);
                            }
                            --idx;
                        }
                        return ((oldCount - cc.Count) | 0);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(cc)
                }
            }
            /*void */ Add$1(/*CookieCollection*/ cookies)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(cookies, "cookies");
                var $en2 = cookies.System$Collections$Generic$IEnumerable$$$GetEnumerator();
                while ($en2.System$Collections$IEnumerator$MoveNext())
                {
                    var c = $en2.System$Collections$Generic$IEnumerator$$$Current;
                    {
                        this.Add(c);
                    }
                }
            }
            /*void */ Add$2(/*Uri*/ uri, /*Cookie*/ cookie)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(uri, "uri");
                $.$spc.System.ArgumentNullException.ThrowIfNull(cookie, "cookie");
                /*Cookie*/ let new_cookie = cookie.Clone();
                new_cookie.VerifyAndSetDefaults(new_cookie.Variant, uri);
                this.InternalAdd(new_cookie);
            }
            /*void */ Add$3(/*Uri*/ uri, /*CookieCollection*/ cookies)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(uri, "uri");
                $.$spc.System.ArgumentNullException.ThrowIfNull(cookies, "cookies");
                var $en2 = cookies.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current;
                    {
                        /*Cookie*/ let new_cookie = c.Clone();
                        new_cookie.VerifyAndSetDefaults(new_cookie.Variant, uri);
                        this.InternalAdd(new_cookie);
                    }
                }
            }
            /*CookieCollection */ CookieCutter(/*Uri*/ uri, /*string?*/ headerName, /*string*/ setCookieHeader)
            {
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `uri:${$.$spu.System.Uri.ToString.call(uri)} headerName:${headerName} setCookieHeader:${setCookieHeader}`, "CookieCutter");
                }
                /*CookieCollection*/ let cookies = new $.$snp.System.Net.CookieCollection().$ctor$1();
                /*CookieVariant*/ let variant = 0/*CookieVariant.Unknown*/;
                if ($.$spc.System.String.op_Equality(headerName, null))
                {
                    variant = 2/*CookieVariant.Default*/;
                }
                else 
                {
                    for(/*int*/ let i = 0; i < $.$snp.System.Net.CookieContainer.s_headerInfo.length; ++i)
                    {
                        if ($.$spc.System.String.Equals$5(headerName, $.$spc.System.Array.$ReadT1.call($.$snp.System.Net.CookieContainer.s_headerInfo, i).Name, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            variant = $.$spc.System.Array.$ReadT1.call($.$snp.System.Net.CookieContainer.s_headerInfo, i).Variant;
                        }
                    }
                }
                try
                {
                    /*CookieParser*/ let parser = new $.$snp.System.Net.CookieParser().$ctor$2(setCookieHeader);
                    do
                    {
                        /*Cookie?*/ let cookie = parser.Get();
                        if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                        {
                            $.$snp.System.Net.NetEventSource.Info(this, `CookieParser returned cookie:${$.$snp.System.Net.Cookie.ToString.call(cookie)}`, "CookieCutter");
                        }
                        if (cookie === null)
                        {
                            if (parser.EndofHeader())
                            {
                                break;
                            }
                            continue;
                        }
                        if ($.$spc.System.String.IsNullOrEmpty(cookie.Name))
                        {
                            throw new $.$snp.System.Net.CookieException().$ctor$14($.$snp.System.SR.net_cookie_format);
                        }
                        cookie.VerifyAndSetDefaults(variant, uri);
                        cookies.InternalAdd(cookie, true);
                    }
                    while(true);
                }
                catch($e)
                {
                    if ($e instanceof $.$spc.System.OutOfMemoryException)
                    {
                        throw $e;
                    }
                    else if ($e instanceof $.$spc.System.Exception)
                    {
                        let e = $e;
                        throw new $.$snp.System.Net.CookieException().$ctor$15($.$snp.System.SR.Format($.$snp.System.SR.net_cookie_parse_header, uri.AbsoluteUri), e);
                    }
                    else
                    {
                        throw $e;
                    }
                }
                /*int*/ let cookiesCount = cookies.Count;
                for(/*int*/ let i = 0; i < cookiesCount; i++)
                {
                    this.InternalAdd(cookies.get_Item(i));
                }
                return cookies;
            }
            /*CookieCollection */ GetCookies(/*Uri*/ uri)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(uri, "uri");
                return this.InternalGetCookies(uri) ?? new $.$snp.System.Net.CookieCollection().$ctor$1();
            }
            /*CookieCollection */ GetAllCookies()
            {
                /*var*/ let result = new $.$snp.System.Net.CookieCollection().$ctor$1();
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.m_domainTable.SyncRoot)
                    {
                        /*IDictionaryEnumerator*/ let lists = this.m_domainTable.GetEnumerator();
                        while(lists.System$Collections$IEnumerator$MoveNext())
                        {
                            /*PathList*/ let list = $.$cast(lists.System$Collections$IDictionaryEnumerator$Value, $.$snp.System.Net.PathList);
                            //lock
                            try
                            {
                                $.$spc.System.Threading.Monitor.Enter(list.SyncRoot)
                                {
                                    /*IDictionaryEnumerator*/ let collections = list.List.GetEnumerator();
                                    while(collections.System$Collections$IEnumerator$MoveNext())
                                    {
                                        result.Add$1($.$cast(collections.System$Collections$IDictionaryEnumerator$Value, $.$snp.System.Net.CookieCollection));
                                    }
                                }
                            }
                            finally
                            {
                                $.$spc.System.Threading.Monitor.Exit(list.SyncRoot)
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.m_domainTable.SyncRoot)
                }
                return result;
            }
            /*CookieCollection? */ InternalGetCookies(/*Uri*/ uri)
            {
                if (this.m_count === 0)
                {
                    return null;
                }
                /*bool*/ let isSecure = ($.$spc.System.String.op_Equality(uri.Scheme, "https"/*UriScheme.Https*/) || $.$spc.System.String.op_Equality(uri.Scheme, "wss"/*UriScheme.Wss*/));
                /*int*/ let port = uri.Port;
                /*CookieCollection?*/ let cookies = null;
                /*List<string>*/ let matchingDomainKeys = (() =>
                {
                    let $t1 = new ($.$spc.System.Collections.Generic.List$$($.$spc.System.String))().$ctor$1();
                    $t1.Add(uri.Host);
                    return $t1;
                })();
                /*ReadOnlySpan<char>*/ let host = $.$spc.System.String.op_Implicit(uri.Host);
                /*int*/ let lastDot = $.$spc.System.MemoryExtensions.LastIndexOf$2($.$spc.System.Char, host, /*.*/ 46);
                while(lastDot > 0)
                {
                    let $t1 = host;
                    /*int*/ let dot = $.$spc.System.MemoryExtensions.LastIndexOf$2($.$spc.System.Char, $t1.Slice$1(0, lastDot), /*.*/ 46);
                    if (dot > 0)
                    {
                        let $t2 = host;
                        /*string*/ let match = $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call($t2.Slice$1((((dot + 1) | 0)), $t2.Length - (((dot + 1) | 0))));
                        matchingDomainKeys.Add(match);
                    }
                    lastDot = dot;
                }
                this.BuildCookieCollectionFromDomainMatches(uri, isSecure, port, $.$ref(() => cookies, ($v) => cookies = $v, $.$snp.System.Net.CookieCollection), matchingDomainKeys);
                return cookies;
            }
            /*void */ BuildCookieCollectionFromDomainMatches(/*Uri*/ uri, /*bool*/ isSecure, /*int*/ port, /*ref CookieCollection?*/ cookies, /*List<string>*/ matchingDomainKeys)
            {
                for(/*int*/ let i = 0; i < matchingDomainKeys.Count; i++)
                {
                    /*PathList*/ let pathList;
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(this.m_domainTable.SyncRoot)
                        {
                            pathList = $.$cast(this.m_domainTable.get_Item(matchingDomainKeys.get_Item(i)), $.$snp.System.Net.PathList);
                            if (pathList === null)
                            {
                                continue;
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(this.m_domainTable.SyncRoot)
                    }
                    //lock
                    try
                    {
                        $.$spc.System.Threading.Monitor.Enter(pathList.SyncRoot)
                        {
                            /*SortedList*/ let list = pathList.List;
                            /*int*/ let listCount = list.Count;
                            for(/*int*/ let e = 0; e < listCount; e++)
                            {
                                /*string*/ let path = $.$cast(list.GetKey(e), $.$spc.System.String);
                                if ($.$snp.System.Net.CookieContainer.PathMatch(uri.AbsolutePath, path))
                                {
                                    /*CookieCollection*/ let cc = $.$cast(list.GetByIndex(e), $.$snp.System.Net.CookieCollection);
                                    cc.TimeStamp(1/*CookieCollection.Stamp.Set*/);
                                    this.MergeUpdateCollections(cookies, uri.Host, cc, port, isSecure);
                                }
                            }
                        }
                    }
                    finally
                    {
                        $.$spc.System.Threading.Monitor.Exit(pathList.SyncRoot)
                    }
                    if (pathList.Count === 0)
                    {
                        //lock
                        try
                        {
                            $.$spc.System.Threading.Monitor.Enter(this.m_domainTable.SyncRoot)
                            {
                                this.m_domainTable.Remove(matchingDomainKeys.get_Item(i));
                            }
                        }
                        finally
                        {
                            $.$spc.System.Threading.Monitor.Exit(this.m_domainTable.SyncRoot)
                        }
                    }
                }
            }
            static /*bool */ PathMatch(/*string*/ requestPath, /*string*/ cookiePath)
            {
                cookiePath = $.$snp.System.Net.CookieParser.CheckQuoted(cookiePath);
                if (!$.$spc.System.String.StartsWith$1.call(requestPath, cookiePath, 4/*StringComparison.Ordinal*/))
                {
                    return false;
                }
                return requestPath.length === cookiePath.length || $.$spc.System.String.EndsWith$3.call(cookiePath, /*/*/ 47) || $.$spc.System.String.get_Chars.call(requestPath, cookiePath.length) === /*/*/ 47;
            }
            /*void */ MergeUpdateCollections(/*ref CookieCollection?*/ destination, /*string*/ host, /*CookieCollection*/ source, /*int*/ port, /*bool*/ isSecure)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(source)
                    {
                        for(/*int*/ let idx = 0; idx < source.Count; ++idx)
                        {
                            /*bool*/ let to_add = false;
                            /*Cookie*/ let cookie = source.get_Item(idx);
                            if (cookie.Expired)
                            {
                                source.RemoveAt(idx);
                                --this.m_count;
                                --idx;
                            }
                            else 
                            {
                                if (cookie.PortList !== null)
                                {
                                    let $i1 = 0;
                                    let $arr1 = cookie.PortList;
                                    while ($i1 < $arr1.length)
                                    {
                                        let p = $arr1[$i1++];
                                        if (p === port)
                                        {
                                            to_add = true;
                                            break;
                                        }
                                    }
                                }
                                else 
                                {
                                    to_add = true;
                                }
                                if (cookie.Secure && !isSecure)
                                {
                                    to_add = false;
                                }
                                if (cookie.DomainImplicit && !$.$spc.System.String.Equals$5(host, cookie.Domain, 5/*StringComparison.OrdinalIgnoreCase*/))
                                {
                                    to_add = false;
                                }
                                if (to_add)
                                {
                                    destination.$v ??= new $.$snp.System.Net.CookieCollection().$ctor$1();
                                    destination.$v.InternalAdd(cookie, false);
                                }
                            }
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(source)
                }
            }
            /*string */ GetCookieHeader(/*Uri*/ uri)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(uri, "uri");
                return this.GetCookieHeader$1(uri, $.$discardRef());
            }
            /*string */ GetCookieHeader$1(/*Uri*/ uri, /*out string*/ optCookie2)
            {
                /*CookieCollection?*/ let cookies = this.InternalGetCookies(uri);
                if (cookies === null)
                {
                    optCookie2.$v = $.$spc.System.String.Empty;
                    return $.$spc.System.String.Empty;
                }
                /*string*/ let delimiter = $.$spc.System.String.Empty;
                /*StringBuilder*/ let builder = $.$snp.System.Text.StringBuilderCache.Acquire(16);
                for(/*int*/ let i = 0; i < cookies.Count; i++)
                {
                    builder.Append$2(delimiter);
                    cookies.get_Item(i).ToString$1(builder);
                    delimiter = "; ";
                }
                optCookie2.$v = cookies.IsOtherVersionSeen ? ("$"/*Cookie.SpecialAttributeLiteral*/ + "Version"/*CookieFields.VersionAttributeName*/ + /*=*/ 61 + "1"/*Cookie.MaxSupportedVersionString*/) : $.$spc.System.String.Empty;
                return $.$snp.System.Text.StringBuilderCache.GetStringAndRelease(builder);
            }
            /*void */ SetCookies(/*Uri*/ uri, /*string*/ cookieHeader)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(uri, "uri");
                $.$spc.System.ArgumentNullException.ThrowIfNull(cookieHeader, "cookieHeader");
                this.CookieCutter(uri, null, cookieHeader);
            }
            //default member initializer
            constructor()
            {
                super();
                this.m_domainTable = new $.$spc.System.Collections.Hashtable().$ctor$2();
                this.m_fqdnMyDomain = $.$spc.System.String.Empty;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_headerInfo = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$snp.System.Net.HeaderVariantInfo), [new $.$snp.System.Net.HeaderVariantInfo().$ctor$2("Set-Cookie"/*HttpKnownHeaderNames.SetCookie*/, 2/*CookieVariant.Rfc2109*/), new $.$snp.System.Net.HeaderVariantInfo().$ctor$2("Set-Cookie2"/*HttpKnownHeaderNames.SetCookie2*/, 3/*CookieVariant.Rfc2965*/)], null, null);
                }
            }
            static $h = 1433356;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":64425942796,"f":1},"s":{"r":0,"d":0,"h":68720910092,"f":1},"n":"Capacity","d":1433356,"h":60130975500,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":77310844684,"f":1},"n":"Count","d":1433356,"h":73015877388,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":85900779276,"f":1},"s":{"r":0,"d":0,"h":90195746572,"f":1},"n":"MaxCookieSize","d":1433356,"h":81605811980,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":98785681164,"f":1},"s":{"r":0,"d":0,"h":103080648460,"f":1},"n":"PerDomainCapacity","d":1433356,"h":94490713868,"f":1}],"m":[{"r":65537,"p":[{"n":"cookie","p":1171212}],"n":"Add","d":1433356,"h":107375615756,"f":1},{"r":65537,"p":[{"n":"cookie","p":1171212}],"n":"InternalAdd","d":1433356,"h":111670583052,"f":8},{"r":262145,"p":[{"n":"domain","p":1310721}],"n":"AgeCookies","d":1433356,"h":115965550348,"f":2},{"r":65537,"n":"DomainTableCleanup","d":1433356,"h":120260517644,"f":2},{"r":655361,"p":[{"n":"cc","p":1236748}],"n":"ExpireCollection","d":1433356,"h":124555484940,"f":34},{"r":65537,"p":[{"n":"cookies","p":1236748}],"n":"Add","o":"@$1","d":1433356,"h":128850452236,"f":1},{"r":65537,"p":[{"n":"uri","p":1744130},{"n":"cookie","p":1171212}],"n":"Add","o":"@$2","d":1433356,"h":133145419532,"f":1},{"r":65537,"p":[{"n":"uri","p":1744130},{"n":"cookies","p":1236748}],"n":"Add","o":"@$3","d":1433356,"h":137440386828,"f":1},{"r":1236748,"p":[{"n":"uri","p":1744130},{"n":"headerName","p":1310721},{"n":"setCookieHeader","p":1310721}],"n":"CookieCutter","d":1433356,"h":141735354124,"f":8},{"r":1236748,"p":[{"n":"uri","p":1744130}],"n":"GetCookies","d":1433356,"h":146030321420,"f":1},{"r":1236748,"n":"GetAllCookies","d":1433356,"h":150325288716,"f":1},{"r":1236748,"p":[{"n":"uri","p":1744130}],"n":"InternalGetCookies","d":1433356,"h":154620256012,"f":8},{"r":65537,"p":[{"n":"uri","p":1744130},{"n":"isSecure","p":262145},{"n":"port","p":655361},{"n":"cookies","p":1236748,"f":4},{"n":"matchingDomainKeys","p":$.$spc.System.Collections.Generic.List$$($.$spc.System.String).$h}],"n":"BuildCookieCollectionFromDomainMatches","d":1433356,"h":158915223308,"f":2},{"r":262145,"p":[{"n":"requestPath","p":1310721},{"n":"cookiePath","p":1310721}],"n":"PathMatch","d":1433356,"h":163210190604,"f":34},{"r":65537,"p":[{"n":"destination","p":1236748,"f":4},{"n":"host","p":1310721},{"n":"source","p":1236748},{"n":"port","p":655361},{"n":"isSecure","p":262145}],"n":"MergeUpdateCollections","d":1433356,"h":167505157900,"f":2},{"r":1310721,"p":[{"n":"uri","p":1744130}],"n":"GetCookieHeader","d":1433356,"h":171800125196,"f":1},{"r":1310721,"p":[{"n":"uri","p":1744130},{"n":"optCookie2","p":1310721,"f":2}],"n":"GetCookieHeader","o":"@$1","d":1433356,"h":176095092492,"f":8},{"r":65537,"p":[{"n":"uri","p":1744130},{"n":"cookieHeader","p":1310721}],"n":"SetCookies","d":1433356,"h":180390059788,"f":1}],"l":[{"t":655361,"n":"DefaultCookieLimit","d":1433356,"h":4296400652,"f":33},{"t":655361,"n":"DefaultPerDomainCookieLimit","d":1433356,"h":8591367948,"f":33},{"t":655361,"n":"DefaultCookieLengthLimit","d":1433356,"h":12886335244,"f":33},{"t":0,"n":"s_headerInfo","d":1433356,"h":17181302540,"f":34},{"t":30932993,"n":"m_domainTable","d":1433356,"h":21476269836,"f":2},{"t":655361,"n":"m_maxCookieSize","d":1433356,"h":25771237132,"f":2},{"t":655361,"n":"m_maxCookies","d":1433356,"h":30066204428,"f":2},{"t":655361,"n":"m_maxCookiesPerDomain","d":1433356,"h":34361171724,"f":2},{"t":655361,"n":"m_count","d":1433356,"h":38656139020,"f":2},{"t":1310721,"n":"m_fqdnMyDomain","d":1433356,"h":42951106316,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1433356,"h":47246073612,"f":1},{"p":[{"n":"capacity","p":655361}],"n":".ctor","o":"$ctor$2","d":1433356,"h":51541040908,"f":1},{"p":[{"n":"capacity","p":655361},{"n":"perDomainCapacity","p":655361},{"n":"maxCookieSize","p":655361}],"n":".ctor","o":"$ctor$3","d":1433356,"h":55836008204,"f":1}],"h":1433356,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.CookieContainer`; }
        });
        
        $asm.$cls("$snp.System.Net.HttpVersion", ($self) => class HttpVersion
        {
            /*Version*/ static Unknown = null;
            /*Version*/ static Version10 = null;
            /*Version*/ static Version11 = null;
            /*Version*/ static Version20 = null;
            /*Version*/ static Version30 = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.Unknown = new $.$spc.System.Version().$ctor$3(0, 0);
                }
                {
                    this.Version10 = new $.$spc.System.Version().$ctor$3(1, 0);
                }
                {
                    this.Version11 = new $.$spc.System.Version().$ctor$3(1, 1);
                }
                {
                    this.Version20 = new $.$spc.System.Version().$ctor$3(2, 0);
                }
                {
                    this.Version30 = new $.$spc.System.Version().$ctor$3(3, 0);
                }
            }
            static $h = 2875148;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":144703489,"n":"Unknown","d":2875148,"h":4297842444,"f":33},{"t":144703489,"n":"Version10","d":2875148,"h":8592809740,"f":33},{"t":144703489,"n":"Version11","d":2875148,"h":12887777036,"f":33},{"t":144703489,"n":"Version20","d":2875148,"h":17182744332,"f":33},{"t":144703489,"n":"Version30","d":2875148,"h":21477711628,"f":33}],"h":2875148}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.HttpVersion`; }
        });
        
        $asm.$cls("$snp.System.Net.IPAddressParser", ($self) => class IPAddressParser
        {
            /*int*/ static MaxIPv4StringLength = 15;
            /*int*/ static MaxIPv6StringLength = 65;
            static /*bool */ IsValid(TChar, /*ReadOnlySpan<TChar>*/ ipSpan)
            {
                /*fixed*/ 
                {
                    /*TChar**/ let ipStringPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1(TChar, ipSpan);
                    if ($.$spc.System.MemoryExtensions.Contains$1(TChar, ipSpan, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58)))
                    {
                        return $.$snp.System.Net.IPv6AddressHelper.IsValidStrict(TChar, ipStringPtr, 0, ipSpan.Length);
                    }
                    else 
                    {
                        /*int*/ let end = ipSpan.Length;
                        /*long*/ let address = $.$snp.System.Net.IPv4AddressHelper.ParseNonCanonical(TChar, ipStringPtr, 0, $.$ref(() => end, ($v) => end = $v, $.$spc.System.Int32), true);
                        return address !== -1n && end === ipSpan.Length;
                    }
                }
            }
            static /*IPAddress? */ Parse(TChar, /*ReadOnlySpan<TChar>*/ ipSpan, /*bool*/ tryParse)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type) || $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type), "typeof(TChar) == typeof(byte) || typeof(TChar) == typeof(char)");
                /*long*/ let address;
                if ($.$spc.System.MemoryExtensions.Contains$1(TChar, ipSpan, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58)))
                {
                    /*Span<ushort>*/ let numbers = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.UInt16, 8/*IPAddressParserStatics.IPv6AddressShorts*/, null);
                    numbers.Clear();
                    /*uint*/ let scope;
                    if ($.$snp.System.Net.IPAddressParser.TryParseIPv6(TChar, ipSpan, numbers, 8/*IPAddressParserStatics.IPv6AddressShorts*/, $.$ref(() => scope, ($v) => scope = $v, $.$spc.System.UInt32)))
                    {
                        return new $.$snp.System.Net.IPAddress().$ctor$4($.$spc.System.Span$$($.$spc.System.UInt16).op_Implicit$2(numbers), scope);
                    }
                }
                else if ($.$snp.System.Net.IPAddressParser.TryParseIpv4(TChar, ipSpan, $.$ref(() => address, ($v) => address = $v, $.$spc.System.Int64)))
                {
                    return new $.$snp.System.Net.IPAddress().$ctor$1(address);
                }
                if (tryParse)
                {
                    return null;
                }
                throw new $.$spc.System.FormatException().$ctor$11($.$snp.System.SR.dns_bad_ip_address, new $.$snp.System.Net.Sockets.SocketException().$ctor$22(10022/*SocketError.InvalidArgument*/));
            }
            static /*bool */ TryParseIpv4(TChar, /*ReadOnlySpan<TChar>*/ ipSpan, /*out long*/ address)
            {
                /*int*/ let end = ipSpan.Length;
                /*long*/ let tmpAddr;
                /*fixed*/ 
                {
                    /*TChar**/ let ipStringPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1(TChar, ipSpan);
                    tmpAddr = $.$snp.System.Net.IPv4AddressHelper.ParseNonCanonical(TChar, ipStringPtr, 0, $.$ref(() => end, ($v) => end = $v, $.$spc.System.Int32), true);
                }
                if (tmpAddr !== -1n && end === ipSpan.Length)
                {
                    address.$v = BigInt(($.$snp.System.Net.IPAddress.HostToNetworkOrder$1($.$cast(tmpAddr, $.$spc.System.Int32)) >>> 0));
                    return true;
                }
                address.$v = 0n;
                return false;
            }
            static /*bool */ TryParseIPv6(TChar, /*ReadOnlySpan<TChar>*/ ipSpan, /*Span<ushort>*/ numbers, /*int*/ numbersLength, /*out uint*/ scope)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) || $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                $.$spc.System.Diagnostics.Debug.Assert$1(numbersLength >= 8/*IPAddressParserStatics.IPv6AddressShorts*/, "numbersLength >= IPAddressParserStatics.IPv6AddressShorts");
                /*fixed*/ 
                {
                    /*TChar**/ let ipStringPtr = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1(TChar, ipSpan);
                    if (!$.$snp.System.Net.IPv6AddressHelper.IsValidStrict(TChar, ipStringPtr, 0, ipSpan.Length))
                    {
                        scope.$v = 0;
                        return false;
                    }
                }
                /*ReadOnlySpan<TChar>*/ let scopeIdSpan;
                $.$snp.System.Net.IPv6AddressHelper.Parse(TChar, ipSpan, numbers, $.$ref(() => scopeIdSpan, ($v) => scopeIdSpan = $v, $.$spc.System.ReadOnlySpan$$(TChar)));
                if (scopeIdSpan.Length > 1)
                {
                    /*bool*/ let parsedNumericScope;
                    scopeIdSpan = scopeIdSpan.Slice(1);
                    if ($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type))
                    {
                        /*ReadOnlySpan<byte>*/ let castScopeIdSpan = $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1(TChar, $.$spc.System.Byte, scopeIdSpan);
                        parsedNumericScope = $.$spc.System.UInt32.TryParse$7(castScopeIdSpan, 0/*NumberStyles.None*/, $.$spc.System.Globalization.CultureInfo.InvariantCulture, scope);
                    }
                    else 
                    {
                        /*ReadOnlySpan<char>*/ let castScopeIdSpan = $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast$1(TChar, $.$spc.System.Char, scopeIdSpan);
                        parsedNumericScope = $.$spc.System.UInt32.TryParse$4(castScopeIdSpan, 0/*NumberStyles.None*/, $.$spc.System.Globalization.CultureInfo.InvariantCulture, scope);
                    }
                    if (parsedNumericScope)
                    {
                        return true;
                    }
                    else 
                    {
                        /*uint*/ let interfaceIndex = $.$snp.System.Net.NetworkInformation.InterfaceInfoPal.InterfaceNameToIndex(TChar, scopeIdSpan);
                        if (interfaceIndex > 0)
                        {
                            scope.$v = interfaceIndex;
                            return true;
                        }
                    }
                }
                scope.$v = 0;
                return true;
            }
            static /*int */ FormatIPv4Address(TChar, /*uint*/ address, /*Span<TChar>*/ addressString)
            {
                address = ($.$snp.System.Net.IPAddress.NetworkToHostOrder$1((address | 0)) >>> 0);
                /*int*/ let pos = FormatByte(address >>> 24, addressString);
                addressString.get_Item(pos++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*.*/ 46);
                pos += FormatByte(address >>> 16, addressString.Slice(pos));
                addressString.get_Item(pos++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*.*/ 46);
                pos += FormatByte(address >>> 8, addressString.Slice(pos));
                addressString.get_Item(pos++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*.*/ 46);
                pos += FormatByte(address, addressString.Slice(pos));
                return pos;
                /*static int*/  function FormatByte(/*uint*/ number, /*Span<TChar>*/ addressString)
                {
                    number &= 255;
                    if (number >= 10)
                    {
                        /*uint*/ let hundreds, tens;
                        if (number >= 100)
                        {
                            /*uint*/ let hundredsAndTens;
        $.$tupleUnpack(($tp) =>
                            {
                                hundredsAndTens = $tp.Item1;
                                number = $tp.Item2;
                            }).$v = $.$spc.System.Math.DivRem$7(number, 10);
                            $.$tupleUnpack(($tp) =>
                            {
                                hundreds = $tp.Item1;
                                tens = $tp.Item2;
                            }).$v = $.$spc.System.Math.DivRem$7(hundredsAndTens, 10);
                            addressString.get_Item(2).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.UInt32, ((/*0*/ 48 + number) >>> 0));
                            addressString.get_Item(1).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.UInt32, ((/*0*/ 48 + tens) >>> 0));
                            addressString.get_Item(0).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.UInt32, ((/*0*/ 48 + hundreds) >>> 0));
                            return 3;
                        }
                        $.$tupleUnpack(($tp) =>
                        {
                            tens = $tp.Item1;
                            number = $tp.Item2;
                        }).$v = $.$spc.System.Math.DivRem$7(number, 10);
                        addressString.get_Item(1).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.UInt32, ((/*0*/ 48 + number) >>> 0));
                        addressString.get_Item(0).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.UInt32, ((/*0*/ 48 + tens) >>> 0));
                        return 2;
                    }
                    addressString.get_Item(0).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.UInt32, ((/*0*/ 48 + number) >>> 0));
                    return 1;
                }
            }
            static /*int */ FormatIPv6Address(TChar, /*ushort[]*/ address, /*uint*/ scopeId, /*Span<TChar>*/ destination)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type) || $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type), "typeof(TChar) == typeof(byte) || typeof(TChar) == typeof(char)");
                /*int*/ let pos = 0;
                if ($.$snp.System.Net.IPv6AddressHelper.ShouldHaveIpv4Embedded($.$spc.System.ReadOnlySpan$$($.$spc.System.UInt16).op_Implicit(address)))
                {
                    AppendSections($.$spc.System.Span$$($.$spc.System.UInt16).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.UInt16, address, 0, 6)), destination, $.$ref(() => pos, ($v) => pos = $v, $.$spc.System.Int32));
                    if (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(destination.get_Item(((pos - 1) | 0)).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58)))
                    {
                        destination.get_Item(pos++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58);
                    }
                    pos += $.$snp.System.Net.IPAddressParser.FormatIPv4Address(TChar, $.$snp.System.Net.IPAddressParser.ExtractIPv4Address(address), destination.Slice(pos));
                }
                else 
                {
                    AppendSections($.$spc.System.Span$$($.$spc.System.UInt16).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.UInt16, address, 0, 8)), destination, $.$ref(() => pos, ($v) => pos = $v, $.$spc.System.Int32));
                }
                if (scopeId !== 0)
                {
                    destination.get_Item(pos++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*%*/ 37);
                    /*int*/ let bytesWritten;
                    /*bool*/ let formatted = $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type) ? $.$spc.System.UInt32.TryFormat$1.call(scopeId, $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast(TChar, $.$spc.System.Byte, destination).Slice(pos), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$spc.System.Int32), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))(), null) : $.$spc.System.UInt32.TryFormat.call(scopeId, $.$spc.System.Runtime.InteropServices.MemoryMarshal.Cast(TChar, $.$spc.System.Char, destination).Slice(pos), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$spc.System.Int32), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))(), null);
                    $.$spc.System.Diagnostics.Debug.Assert$1(formatted, "formatted");
                    pos += bytesWritten;
                }
                return pos;
                /*static void*/  function AppendSections(/*ReadOnlySpan<ushort>*/ address, /*Span<TChar>*/ destination, /*ref int*/ offset)
                {
                    const { Item1: zeroStart, Item2: zeroEnd } = $.$snp.System.Net.IPv6AddressHelper.FindCompressionRange(address);
                    /*bool*/ let needsColon = false;
                    if (zeroStart >= 0)
                    {
                        for(/*int*/ let i = 0; i < zeroStart; i++)
                        {
                            if (needsColon)
                            {
                                destination.get_Item(offset.$v++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58);
                            }
                            needsColon = true;
                            AppendHex(address.get_Item(i).$v, destination, offset);
                        }
                        destination.get_Item(offset.$v++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58);
                        destination.get_Item(offset.$v++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58);
                        needsColon = false;
                    }
                    for(/*int*/ let i = zeroEnd; i < address.Length; i++)
                    {
                        if (needsColon)
                        {
                            destination.get_Item(offset.$v++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58);
                        }
                        needsColon = true;
                        AppendHex(address.get_Item(i).$v, destination, offset);
                    }
                }
                /*static void*/  function AppendHex(/*ushort*/ value, /*Span<TChar>*/ destination, /*ref int*/ offset)
                {
                    if ((value & 65520) !== 0)
                    {
                        if ((value & 65280) !== 0)
                        {
                            if ((value & 61440) !== 0)
                            {
                                destination.get_Item(offset.$v++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, $.$snp.System.HexConverter.ToCharLower(value >>> 12));
                            }
                            destination.get_Item(offset.$v++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, $.$snp.System.HexConverter.ToCharLower(value >>> 8));
                        }
                        destination.get_Item(offset.$v++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, $.$snp.System.HexConverter.ToCharLower(value >>> 4));
                    }
                    destination.get_Item(offset.$v++).$v = TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, $.$snp.System.HexConverter.ToCharLower(value));
                }
            }
            static /*uint */ ExtractIPv4Address(/*ushort[]*/ address)
            {
                /*uint*/ let ipv4address = ($.$spc.System.Array.$ReadT1.call(address, 6) << 16) >>> 0 | $.$spc.System.Array.$ReadT1.call(address, 7);
                return ($.$snp.System.Net.IPAddress.HostToNetworkOrder$1((ipv4address | 0)) >>> 0);
            }
            static $h = 3202828;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"ipSpan","p":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h}],"g":["TChar"],"n":"IsValid","d":3202828,"h":12888104716,"f":131105},{"r":3071756,"p":[{"n":"ipSpan","p":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h},{"n":"tryParse","p":262145}],"g":["TChar"],"n":"Parse","d":3202828,"h":17183072012,"f":131112},{"r":262145,"p":[{"n":"ipSpan","p":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h},{"n":"address","p":917505,"f":2}],"g":["TChar"],"n":"TryParseIpv4","d":3202828,"h":21478039308,"f":131106},{"r":262145,"p":[{"n":"ipSpan","p":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h},{"n":"numbers","p":$.$spc.System.Span$$($.$spc.System.UInt16).$h},{"n":"numbersLength","p":655361},{"n":"scope","p":720897,"f":2}],"g":["TChar"],"n":"TryParseIPv6","d":3202828,"h":25773006604,"f":131106},{"r":655361,"p":[{"n":"address","p":720897},{"n":"addressString","p":(TChar) => $.$spc.System.Span$$(TChar).$h}],"g":["TChar"],"n":"FormatIPv4Address","d":3202828,"h":30067973900,"f":131112},{"r":655361,"p":[{"n":"address","p":0},{"n":"scopeId","p":720897},{"n":"destination","p":(TChar) => $.$spc.System.Span$$(TChar).$h}],"g":["TChar"],"n":"FormatIPv6Address","d":3202828,"h":34362941196,"f":131112},{"r":720897,"p":[{"n":"address","p":0}],"n":"ExtractIPv4Address","d":3202828,"h":38657908492,"f":34}],"l":[{"t":655361,"n":"MaxIPv4StringLength","d":3202828,"h":4298170124,"f":40},{"t":655361,"n":"MaxIPv6StringLength","d":3202828,"h":8593137420,"f":40}],"h":3202828}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.IPAddressParser`; }
        });
        
        $asm.$cls("$snp.System.Net.IPv4AddressHelper", ($self) => class IPv4AddressHelper
        {
            /*long*/ static Invalid = -1n;
            /*long*/ static MaxIPv4Value = 4294967295n;
            /*int*/ static Octal = 8;
            /*int*/ static Decimal = 10;
            /*int*/ static Hex = 16;
            /*int*/ static NumberOfLabels = 4;
            static /*ushort */ ToUShort(TChar, /*TChar*/ value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) || $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                return $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) ? $.$cast($.$box(value, TChar), $.$spc.System.Char) : $.$cast($.$box(value, TChar), $.$spc.System.Byte);
            }
            static /*int */ ParseHostNumber(TChar, /*ReadOnlySpan<TChar>*/ str, /*int*/ start, /*int*/ end)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) || $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*Span<byte>*/ let numbers = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 4/*NumberOfLabels*/, null);
                for(/*int*/ let i = 0; i < numbers.Length; ++i)
                {
                    /*int*/ let b = 0;
                    /*int*/ let ch;
                    for(; (start < end) && (ch = $.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, str.get_Item(start).$v)) !== /*.*/ 46 && ch !== /*:*/ 58; ++start)
                    {
                        b = (((((((b * 10) | 0)) + ch) | 0) - /*0*/ 48) | 0);
                    }
                    numbers.get_Item(i).$v = $.$cast(b, $.$spc.System.Byte);
                    ++start;
                }
                return $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadInt32BigEndian($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(numbers));
            }
            static /*bool */ IsValid(TChar, /*TChar**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ allowIPv6, /*bool*/ notImplicitFile, /*bool*/ unknownScheme)
            {
                if (allowIPv6 || unknownScheme)
                {
                    return $.$snp.System.Net.IPv4AddressHelper.IsValidCanonical(TChar, name, start, end, allowIPv6, notImplicitFile);
                }
                else 
                {
                    return $.$snp.System.Net.IPv4AddressHelper.ParseNonCanonical(TChar, name, start, end, notImplicitFile) !== -1n;
                }
            }
            static /*bool */ IsValidCanonical(TChar, /*TChar**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ allowIPv6, /*bool*/ notImplicitFile)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) || $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let dots = 0;
                /*long*/ let number = 0n;
                /*bool*/ let haveNumber = false;
                /*bool*/ let firstCharIsZero = false;
                while(start < end.$v)
                {
                    /*int*/ let ch = $.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(start));
                    if (allowIPv6)
                    {
                        if (ch === /*]*/ 93 || ch === /*/*/ 47 || ch === /*%*/ 37)
                        {
                            break;
                        }
                    }
                    else if (ch === /*/*/ 47 || ch === /*\\*/ 92 || (notImplicitFile && (ch === /*:*/ 58 || ch === /*?*/ 63 || ch === /*#*/ 35)))
                    {
                        break;
                    }
                    /*uint*/ let parsedCharacter = ((((ch - /*0*/ 48) | 0)) >>> 0);
                    if (parsedCharacter < 10/*IPv4AddressHelper.Decimal*/)
                    {
                        if (!haveNumber && parsedCharacter === 0)
                        {
                            if ((((start + 1) | 0) < end.$v) && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((start + 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*0*/ 48)))
                            {
                                return false;
                            }
                            firstCharIsZero = true;
                        }
                        haveNumber = true;
                        number = number * BigInt(10/*IPv4AddressHelper.Decimal*/) + BigInt(parsedCharacter);
                        if (number > BigInt(255/*byte.MaxValue*/))
                        {
                            return false;
                        }
                    }
                    else if (ch === /*.*/ 46)
                    {
                        if (!haveNumber || (number > 0n && firstCharIsZero))
                        {
                            return false;
                        }
                        ++dots;
                        haveNumber = false;
                        number = 0n;
                        firstCharIsZero = false;
                    }
                    else 
                    {
                        return false;
                    }
                    ++start;
                }
                /*bool*/ let res = (dots === 3) && haveNumber;
                if (res)
                {
                    end.$v = start;
                }
                return res;
            }
            static /*long */ ParseNonCanonical(TChar, /*TChar**/ name, /*int*/ start, /*ref int*/ end, /*bool*/ notImplicitFile)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) || $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let numberBase = 10/*IPv4AddressHelper.Decimal*/;
                /*int*/ let ch = 0;
                /*Span<long>*/ let parts = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Int64, 3, null);
                /*long*/ let currentValue = 0n;
                /*bool*/ let atLeastOneChar = false;
                /*int*/ let dotCount = 0;
                /*int*/ let current = start;
                for(; current < end.$v; current++)
                {
                    ch = $.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(current));
                    currentValue = 0n;
                    numberBase = 10/*IPv4AddressHelper.Decimal*/;
                    if (ch === /*0*/ 48)
                    {
                        current++;
                        atLeastOneChar = true;
                        if (current < end.$v)
                        {
                            ch = $.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(current));
                            if (ch === /*x*/ 120 || ch === /*X*/ 88)
                            {
                                numberBase = 16/*IPv4AddressHelper.Hex*/;
                                current++;
                                atLeastOneChar = false;
                            }
                            else 
                            {
                                numberBase = 8/*IPv4AddressHelper.Octal*/;
                            }
                        }
                    }
                    for(; current < end.$v; current++)
                    {
                        ch = $.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(current));
                        /*int*/ let digitValue = $.$snp.System.HexConverter.FromChar(ch);
                        if (digitValue >= numberBase)
                        {
                            break;
                        }
                        currentValue = (currentValue * BigInt(numberBase)) + BigInt(digitValue);
                        if (currentValue > 4294967295n)
                        {
                            return -1n;
                        }
                        atLeastOneChar = true;
                    }
                    if (current < end.$v && ch === /*.*/ 46)
                    {
                        if (dotCount >= 3 || !atLeastOneChar || currentValue > 255n)
                        {
                            return -1n;
                        }
                        parts.get_Item(dotCount).$v = currentValue;
                        dotCount++;
                        atLeastOneChar = false;
                        continue;
                    }
                    break;
                }
                if (!atLeastOneChar)
                {
                    return -1n;
                }
                else if (current >= end.$v)
                {
                }
                else if (ch === /*/*/ 47 || ch === /*\\*/ 92 || (notImplicitFile && (ch === /*:*/ 58 || ch === /*?*/ 63 || ch === /*#*/ 35)))
                {
                    end.$v = current;
                }
                else 
                {
                    return -1n;
                }
                switch(dotCount)
                {
                    case 0:
                    return currentValue;
                    case 1:
                    $.$spc.System.Diagnostics.Debug.Assert$1(parts.get_Item(0).$v <= 255n, "parts[0] <= 0xFF");
                    if (currentValue > 16777215n)
                    {
                        return -1n;
                    }
                    return (BigInt.asIntN(64, parts.get_Item(0).$v << 24n)) | currentValue;
                    case 2:
                    $.$spc.System.Diagnostics.Debug.Assert$1(parts.get_Item(0).$v <= 255n, "parts[0] <= 0xFF");
                    $.$spc.System.Diagnostics.Debug.Assert$1(parts.get_Item(1).$v <= 255n, "parts[1] <= 0xFF");
                    if (currentValue > 65535n)
                    {
                        return -1n;
                    }
                    return (BigInt.asIntN(64, parts.get_Item(0).$v << 24n)) | (BigInt.asIntN(64, parts.get_Item(1).$v << 16n)) | currentValue;
                    case 3:
                    $.$spc.System.Diagnostics.Debug.Assert$1(parts.get_Item(0).$v <= 255n, "parts[0] <= 0xFF");
                    $.$spc.System.Diagnostics.Debug.Assert$1(parts.get_Item(1).$v <= 255n, "parts[1] <= 0xFF");
                    $.$spc.System.Diagnostics.Debug.Assert$1(parts.get_Item(2).$v <= 255n, "parts[2] <= 0xFF");
                    if (currentValue > 255n)
                    {
                        return -1n;
                    }
                    return (BigInt.asIntN(64, parts.get_Item(0).$v << 24n)) | (BigInt.asIntN(64, parts.get_Item(1).$v << 16n)) | (BigInt.asIntN(64, parts.get_Item(2).$v << 8n)) | currentValue;
                    default:
                    return -1n;
                }
            }
            static $h = 3464972;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":589825,"p":[{"n":"value","p":25773408256}],"g":["TChar"],"n":"ToUShort","d":3464972,"h":30068236044,"f":131112},{"r":655361,"p":[{"n":"str","p":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h},{"n":"start","p":655361},{"n":"end","p":655361}],"g":["TChar"],"n":"ParseHostNumber","d":3464972,"h":34363203340,"f":131112},{"r":262145,"p":[{"n":"name","p":0},{"n":"start","p":655361},{"n":"end","p":655361,"f":4},{"n":"allowIPv6","p":262145},{"n":"notImplicitFile","p":262145},{"n":"unknownScheme","p":262145}],"g":["TChar"],"n":"IsValid","d":3464972,"h":38658170636,"f":131112},{"r":262145,"p":[{"n":"name","p":0},{"n":"start","p":655361},{"n":"end","p":655361,"f":4},{"n":"allowIPv6","p":262145},{"n":"notImplicitFile","p":262145}],"g":["TChar"],"n":"IsValidCanonical","d":3464972,"h":42953137932,"f":131112},{"r":917505,"p":[{"n":"name","p":0},{"n":"start","p":655361},{"n":"end","p":655361,"f":4},{"n":"notImplicitFile","p":262145}],"g":["TChar"],"n":"ParseNonCanonical","d":3464972,"h":47248105228,"f":131112}],"l":[{"t":917505,"n":"Invalid","d":3464972,"h":4298432268,"f":40},{"t":917505,"n":"MaxIPv4Value","d":3464972,"h":8593399564,"f":34},{"t":655361,"n":"Octal","d":3464972,"h":12888366860,"f":34},{"t":655361,"n":"Decimal","d":3464972,"h":17183334156,"f":34},{"t":655361,"n":"Hex","d":3464972,"h":21478301452,"f":34},{"t":655361,"n":"NumberOfLabels","d":3464972,"h":25773268748,"f":34}],"h":3464972}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.IPv4AddressHelper`; }
        });
        
        $asm.$cls("$snp.System.Net.IPv6AddressHelper", ($self) => class IPv6AddressHelper
        {
            /*int*/ static Hex = 16;
            /*int*/ static NumberOfLabels = 8;
            static /*(int longestSequenceStart, int longestSequenceLength) */ FindCompressionRange(/*ReadOnlySpan<ushort>*/ numbers)
            {
                /*int*/ let longestSequenceLength = 0, longestSequenceStart = -1, currentSequenceLength = 0;
                for(/*int*/ let i = 0; i < numbers.Length; i++)
                {
                    if (numbers.get_Item(i).$v === 0)
                    {
                        currentSequenceLength++;
                        if (currentSequenceLength > longestSequenceLength)
                        {
                            longestSequenceLength = currentSequenceLength;
                            longestSequenceStart = ((((i - currentSequenceLength) | 0) + 1) | 0);
                        }
                    }
                    else 
                    {
                        currentSequenceLength = 0;
                    }
                }
                return longestSequenceLength > 1 ? new ($.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32))().$ctor$2(longestSequenceStart, ((longestSequenceStart + longestSequenceLength) | 0)) : new ($.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32))().$ctor$2(-1, 0);
            }
            static /*bool */ ShouldHaveIpv4Embedded(/*ReadOnlySpan<ushort>*/ numbers)
            {
                if (numbers.get_Item(0).$v === 0 && numbers.get_Item(1).$v === 0 && numbers.get_Item(2).$v === 0 && numbers.get_Item(3).$v === 0 && numbers.get_Item(6).$v !== 0)
                {
                    if (numbers.get_Item(4).$v === 0 && (numbers.get_Item(5).$v === 0 || numbers.get_Item(5).$v === 65535))
                    {
                        return true;
                    }
                    else if (numbers.get_Item(4).$v === 65535 && numbers.get_Item(5).$v === 0)
                    {
                        return true;
                    }
                }
                return numbers.get_Item(4).$v === 0 && numbers.get_Item(5).$v === 24318;
            }
            static /*bool */ IsValidStrict(TChar, /*TChar**/ name, /*int*/ start, /*int*/ end)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) || $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let sequenceCount = 0;
                /*int*/ let sequenceLength = 0;
                /*bool*/ let haveCompressor = false;
                /*bool*/ let haveIPv4Address = false;
                /*bool*/ let expectingNumber = true;
                /*int*/ let lastSequence = 1;
                /*bool*/ let needsClosingBracket = false;
                if (start < end && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(start), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*[*/ 91)))
                {
                    start++;
                    needsClosingBracket = true;
                    $.$spc.System.Diagnostics.Debug.Assert$1(start < end, "start < end");
                }
                if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(start), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58)) && (((start + 1) | 0) >= end || TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(name.GetAt(((start + 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58))))
                {
                    return false;
                }
                /*int*/ let i;
                for(i = start; i < end; ++i)
                {
                    /*int*/ let currentCh = $.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(i));
                    if ($.$snp.System.HexConverter.IsHexChar(currentCh))
                    {
                        ++sequenceLength;
                        expectingNumber = false;
                    }
                    else 
                    {
                        if (sequenceLength > 4)
                        {
                            return false;
                        }
                        if (sequenceLength !== 0)
                        {
                            ++sequenceCount;
                            lastSequence = ((i - sequenceLength) | 0);
                            sequenceLength = 0;
                        }
                        let $switchJumpState1;
                        $switchJumpStart1: while(true)
                        {
                            switch($switchJumpState1 ?? currentCh)
                            {
                                case /*%*/ 37:
                                while(((i + 1) | 0) < end)
                                {
                                    i++;
                                    if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(i), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*]*/ 93)))
                                    {
                                        $switchJumpState1 = /*]*/ 93; /*goto case ']'*/
                                        continue $switchJumpStart1;
                                    }
                                    else if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(i), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*/*/ 47)))
                                    {
                                        $switchJumpState1 = /*/*/ 47; /*goto case '/'*/
                                        continue $switchJumpStart1;
                                    }
                                }
                                break;
                                case /*]*/ 93:
                                if (!needsClosingBracket)
                                {
                                    return false;
                                }
                                needsClosingBracket = false;
                                if (((i + 1) | 0) < end && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(name.GetAt(((i + 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58)))
                                {
                                    return false;
                                }
                                if (((i + 3) | 0) < end && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((i + 2) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*0*/ 48)) && TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((i + 3) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*x*/ 120)))
                                {
                                    i += 4;
                                    for(; i < end; i++)
                                    {
                                        /*int*/ let ch = $.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(i));
                                        if (!$.$snp.System.HexConverter.IsHexChar(ch))
                                        {
                                            return false;
                                        }
                                    }
                                }
                                else 
                                {
                                    i += 2;
                                    for(; i < end; i++)
                                    {
                                        if (!$.$spc.System.Char.IsAsciiDigit($.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, name.GetAt(i))))
                                        {
                                            return false;
                                        }
                                    }
                                }
                                continue;
                                case /*:*/ 58:
                                if ((i > 0) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(name.GetAt(((i - 1) | 0)), TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58))))
                                {
                                    if (haveCompressor)
                                    {
                                        return false;
                                    }
                                    haveCompressor = true;
                                    expectingNumber = false;
                                }
                                else 
                                {
                                    expectingNumber = true;
                                }
                                break;
                                case /*/*/ 47:
                                return false;
                                case /*.*/ 46:
                                if (haveIPv4Address)
                                {
                                    return false;
                                }
                                i = end;
                                if (!$.$snp.System.Net.IPv4AddressHelper.IsValid(TChar, name, lastSequence, $.$ref(() => i, ($v) => i = $v, $.$spc.System.Int32), true, false, false))
                                {
                                    return false;
                                }
                                ++sequenceCount;
                                lastSequence = ((i - sequenceLength) | 0);
                                sequenceLength = 0;
                                haveIPv4Address = true;
                                --i;
                                break;
                                default:
                                return false;
                            }
                            break;
                        }
                        sequenceLength = 0;
                    }
                }
                if (sequenceLength !== 0)
                {
                    if (sequenceLength > 4)
                    {
                        return false;
                    }
                    ++sequenceCount;
                }
                /*int*/ let ExpectedSequenceCount = 8;
                return !expectingNumber && (haveCompressor ? (sequenceCount < ExpectedSequenceCount) : (sequenceCount === ExpectedSequenceCount)) && !needsClosingBracket;
            }
            static /*void */ Parse(TChar, /*ReadOnlySpan<TChar>*/ address, /*scoped Span<ushort>*/ numbers, /*out ReadOnlySpan<TChar>*/ scopeId)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Char.$type) || $.$spc.System.Type.op_Equality$1(TChar.$type, $.$spc.System.Byte.$type), "typeof(TChar) == typeof(char) || typeof(TChar) == typeof(byte)");
                /*int*/ let number = 0;
                /*int*/ let currentCh;
                /*int*/ let index = 0;
                /*int*/ let compressorIndex = -1;
                /*bool*/ let numberIsValid = true;
                scopeId.$v = $.$spc.System.ReadOnlySpan$$(TChar).Empty;
                for(/*int*/ let i = (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(address.get_Item(0).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*[*/ 91)) ? 1 : 0); i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*]*/ 93)); )
                {
                    currentCh = $.$snp.System.Net.IPv4AddressHelper.ToUShort(TChar, address.get_Item(i).$v);
                    switch(currentCh)
                    {
                        case /*%*/ 37:
                        if (numberIsValid)
                        {
                            numbers.get_Item(index++).$v = $.$cast(number, $.$spc.System.UInt16);
                            numberIsValid = false;
                        }
                        /*int*/ let scopeStart = i;
                        for(++i; i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*]*/ 93)) && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*/*/ 47)); ++i)
                        {
                        }
                        scopeId.$v = address.Slice$1(scopeStart, ((i - scopeStart) | 0));
                        for(; i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*]*/ 93)); ++i)
                        {
                        }
                        break;
                        case /*:*/ 58:
                        numbers.get_Item(index++).$v = $.$cast(number, $.$spc.System.UInt16);
                        number = 0;
                        ++i;
                        if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58)))
                        {
                            compressorIndex = index;
                            ++i;
                        }
                        else if ((compressorIndex < 0) && (index < 6))
                        {
                            break;
                        }
                        for(/*int*/ let j = i; j < address.Length && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*]*/ 93))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*:*/ 58))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*%*/ 37))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*/*/ 47))) && (j < ((i + 4) | 0)); ++j)
                        {
                            if (TChar.System$Numerics$IEqualityOperators$$$$$op_Equality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*.*/ 46)))
                            {
                                while(j < address.Length && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*]*/ 93))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*/*/ 47))) && (TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(j).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*%*/ 37))))
                                {
                                    ++j;
                                }
                                /*int*/ let ipv4Address = $.$snp.System.Net.IPv4AddressHelper.ParseHostNumber(TChar, address, i, j);
                                numbers.get_Item(index++).$v = $.$cast((ipv4Address >> 16), $.$spc.System.UInt16);
                                numbers.get_Item(index++).$v = $.$cast((ipv4Address & 65535), $.$spc.System.UInt16);
                                i = j;
                                number = 0;
                                numberIsValid = false;
                                break;
                            }
                        }
                        break;
                        case /*/*/ 47:
                        if (numberIsValid)
                        {
                            numbers.get_Item(index++).$v = $.$cast(number, $.$spc.System.UInt16);
                            numberIsValid = false;
                        }
                        for(++i; i < address.Length && TChar.System$Numerics$IEqualityOperators$$$$$op_Inequality(address.get_Item(i).$v, TChar.System$Numerics$INumberBase$$$CreateTruncating($.$spc.System.Char, /*]*/ 93)); i++)
                        {
                        }
                        break;
                        default:
                        /*int*/ let characterValue = $.$snp.System.HexConverter.FromChar(currentCh);
                        number = ((((number * 16/*IPv6AddressHelper.Hex*/) | 0) + characterValue) | 0);
                        i++;
                        break;
                    }
                }
                if (numberIsValid)
                {
                    numbers.get_Item(index++).$v = $.$cast(number, $.$spc.System.UInt16);
                }
                if (compressorIndex > 0)
                {
                    /*int*/ let toIndex = ((8/*NumberOfLabels*/ - 1) | 0);
                    /*int*/ let fromIndex = ((index - 1) | 0);
                    if (fromIndex !== toIndex)
                    {
                        for(/*int*/ let i = ((index - compressorIndex) | 0); i > 0; --i)
                        {
                            numbers.get_Item(toIndex--).$v = numbers.get_Item(fromIndex).$v;
                            numbers.get_Item(fromIndex--).$v = 0;
                        }
                    }
                }
            }
            static $h = 3530508;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$spc.System.ValueTuple$$$($.$spc.System.Int32, $.$spc.System.Int32).$h,"p":[{"n":"numbers","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt16).$h}],"n":"FindCompressionRange","d":3530508,"h":12888432396,"f":40},{"r":262145,"p":[{"n":"numbers","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt16).$h}],"n":"ShouldHaveIpv4Embedded","d":3530508,"h":17183399692,"f":40},{"r":262145,"p":[{"n":"name","p":0},{"n":"start","p":655361},{"n":"end","p":655361}],"g":["TChar"],"n":"IsValidStrict","d":3530508,"h":21478366988,"f":131112},{"r":65537,"p":[{"n":"address","p":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h},{"n":"numbers","p":$.$spc.System.Span$$($.$spc.System.UInt16).$h},{"n":"scopeId","p":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h,"f":2}],"g":["TChar"],"n":"Parse","d":3530508,"h":25773334284,"f":131112}],"l":[{"t":655361,"n":"Hex","d":3530508,"h":4298497804,"f":34},{"t":655361,"n":"NumberOfLabels","d":3530508,"h":8593465100,"f":34}],"h":3530508}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.IPv6AddressHelper`; }
        });
        
        $asm.$cls("$snp.System.Net.Cache.RequestCachePolicy", ($self) => class RequestCachePolicy extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                    this.Level = 0/*RequestCacheLevel.Default*/;
                }
                return this;
            }
            $ctor$2(/*RequestCacheLevel*/ level)
            {
                super.$ctor();
                {
                    if (level < 0/*RequestCacheLevel.Default*/ || level > 6/*RequestCacheLevel.NoCacheNoStore*/)
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("level");
                    }
                    this.Level = level;
                }
                return this;
            }
            /*RequestCacheLevel*/ Level = 0;
            static/*conventional*/ /*string */ ToString()
            {
                return "Level:" + $.$spc.System.Enum.ToStringT($.$snp.System.Net.Cache.RequestCacheLevel, $.$spc.System.UInt32, this.Level);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.Cache.RequestCachePolicy.ToString.apply(this, arguments); }
            //default member initializer
            constructor()
            {
                super();
                this.Level = 0;
            }
            static $h = 1105676;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1040140,"g":{"r":0,"d":0,"h":21475942156,"f":1},"n":"Level","d":1105676,"h":17180974860,"f":1}],"m":[{"r":1310721,"n":"ToString","d":1105676,"h":25770909452,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":1105676,"h":4296072972,"f":1},{"p":[{"n":"level","p":1040140}],"n":".ctor","o":"$ctor$2","d":1105676,"h":8591040268,"f":1}],"h":1105676}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Cache.RequestCachePolicy`; }
        });
        
        $asm.$cls("$snp.System.Net.CookieComparer", ($self) => class CookieComparer
        {
            static /*bool */ Equals$2(/*Cookie*/ left, /*Cookie*/ right)
            {
                if (!$.$spc.System.String.Equals$5(left.Name, right.Name, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                if (!$.$snp.System.Net.CookieComparer.EqualDomains($.$spc.System.String.op_Implicit(left.Domain), $.$spc.System.String.op_Implicit(right.Domain)))
                {
                    return false;
                }
                return $.$spc.System.String.Equals$5(left.Path, right.Path, 4/*StringComparison.Ordinal*/);
            }
            static /*bool */ EqualDomains(/*ReadOnlySpan<char>*/ left, /*ReadOnlySpan<char>*/ right)
            {
                return $.$spc.System.MemoryExtensions.Equals$2($.$snp.System.Net.CookieComparer.StripLeadingDot(left), $.$snp.System.Net.CookieComparer.StripLeadingDot(right), 5/*StringComparison.OrdinalIgnoreCase*/);
            }
            static /*ReadOnlySpan<char> */ StripLeadingDot(/*ReadOnlySpan<char>*/ s)
            {
                let $t1 = s;
                return $.$spc.System.MemoryExtensions.StartsWith$3($.$spc.System.Char, s, /*.*/ 46) ? $t1.Slice$1(1, $t1.Length - 1) : s;
            }
            static $h = 1367820;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"left","p":1171212},{"n":"right","p":1171212}],"n":"Equals","o":"@$2","d":1367820,"h":4296335116,"f":40},{"r":262145,"p":[{"n":"left","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"right","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"EqualDomains","d":1367820,"h":8591302412,"f":40},{"r":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h,"p":[{"n":"s","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"StripLeadingDot","d":1367820,"h":12886269708,"f":40}],"h":1367820}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.CookieComparer`; }
        });
        
        $asm.$cls("$snp.System.Net.Sockets.IPEndPointExtensions", ($self) => class IPEndPointExtensions
        {
            static /*IPAddress */ GetIPAddress(/*ReadOnlySpan<byte>*/ socketAddressBuffer)
            {
                /*AddressFamily*/ let family = $.$snp.System.Net.SocketAddressPal.GetAddressFamily(socketAddressBuffer);
                if (family === 23/*AddressFamily.InterNetworkV6*/)
                {
                    /*Span<byte>*/ let address = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 16/*IPAddressParserStatics.IPv6AddressBytes*/, null);
                    /*uint*/ let scope;
                    $.$snp.System.Net.SocketAddressPal.GetIPv6Address(socketAddressBuffer, address, $.$ref(() => scope, ($v) => scope = $v, $.$spc.System.UInt32));
                    return new $.$snp.System.Net.IPAddress().$ctor$3($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(address), (address.get_Item(0).$v === 254 && (address.get_Item(1).$v & 192) === 128) ? $.$cast(scope, $.$spc.System.Int64) : 0n);
                }
                else if (family === 2/*AddressFamily.InterNetwork*/)
                {
                    return new $.$snp.System.Net.IPAddress().$ctor$1($.$cast($.$snp.System.Net.SocketAddressPal.GetIPv4Address(socketAddressBuffer), $.$spc.System.Int64) & 4294967295n);
                }
                throw new $.$snp.System.Net.Sockets.SocketException().$ctor$20(10047/*SocketError.AddressFamilyNotSupported*/);
            }
            static /*void */ SetIPAddress(/*Span<byte>*/ socketAddressBuffer, /*IPAddress*/ address)
            {
                $.$snp.System.Net.SocketAddressPal.SetAddressFamily(socketAddressBuffer, address.AddressFamily);
                $.$snp.System.Net.SocketAddressPal.SetPort(socketAddressBuffer, 0);
                if (address.AddressFamily === 2/*AddressFamily.InterNetwork*/)
                {
                    $.$snp.System.Net.SocketAddressPal.SetIPv4Address(socketAddressBuffer, $.$cast(address.Address, $.$spc.System.UInt32));
                }
                else 
                {
                    /*Span<byte>*/ let addressBuffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 16/*IPAddressParserStatics.IPv6AddressBytes*/, null);
                    /*int*/ let written;
                    address.TryWriteBytes(addressBuffer, $.$ref(() => written, ($v) => written = $v, $.$spc.System.Int32));
                    $.$spc.System.Diagnostics.Debug.Assert$1(written === 16/*IPAddressParserStatics.IPv6AddressBytes*/, "written == IPAddressParserStatics.IPv6AddressBytes");
                    $.$snp.System.Net.SocketAddressPal.SetIPv6Address(socketAddressBuffer, addressBuffer, $.$cast(address.ScopeId, $.$spc.System.UInt32));
                }
            }
            static /*IPEndPoint */ CreateIPEndPoint(/*ReadOnlySpan<byte>*/ socketAddressBuffer)
            {
                return new $.$snp.System.Net.IPEndPoint().$ctor$3($.$snp.System.Net.Sockets.IPEndPointExtensions.GetIPAddress(socketAddressBuffer), $.$snp.System.Net.SocketAddressPal.GetPort(socketAddressBuffer));
            }
            static /*void */ Serialize(/*this IPEndPoint*/ endPoint, /*Span<byte>*/ destination)
            {
                $.$snp.System.Net.SocketAddressPal.SetAddressFamily(destination, endPoint.AddressFamily);
                $.$snp.System.Net.Sockets.IPEndPointExtensions.SetIPAddress(destination, endPoint.Address);
                $.$snp.System.Net.SocketAddressPal.SetPort(destination, $.$cast(endPoint.Port, $.$spc.System.UInt16));
            }
            static /*bool */ Equals$2(/*this IPEndPoint*/ endPoint, /*ReadOnlySpan<byte>*/ socketAddressBuffer)
            {
                if (socketAddressBuffer.Length >= $.$snp.System.Net.SocketAddress.GetMaximumAddressSize(endPoint.AddressFamily) && endPoint.AddressFamily === $.$snp.System.Net.SocketAddressPal.GetAddressFamily(socketAddressBuffer) && endPoint.Port === $.$cast($.$snp.System.Net.SocketAddressPal.GetPort(socketAddressBuffer), $.$spc.System.Int32))
                {
                    if (endPoint.AddressFamily === 2/*AddressFamily.InterNetwork*/)
                    {
                        return endPoint.Address.Address === $.$cast($.$snp.System.Net.SocketAddressPal.GetIPv4Address(socketAddressBuffer), $.$spc.System.Int64);
                    }
                    else 
                    {
                        /*Span<byte>*/ let addressBuffer1 = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 16/*IPAddressParserStatics.IPv6AddressBytes*/, null);
                        /*Span<byte>*/ let addressBuffer2 = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 16/*IPAddressParserStatics.IPv6AddressBytes*/, null);
                        /*uint*/ let scopeid;
                        $.$snp.System.Net.SocketAddressPal.GetIPv6Address(socketAddressBuffer, addressBuffer1, $.$ref(() => scopeid, ($v) => scopeid = $v, $.$spc.System.UInt32));
                        if (endPoint.Address.ScopeId !== $.$cast(scopeid, $.$spc.System.Int64))
                        {
                            return false;
                        }
                        endPoint.Address.TryWriteBytes(addressBuffer2, $.$discardRef());
                        return $.$spc.System.MemoryExtensions.SequenceEqual$1($.$spc.System.Byte, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(addressBuffer1), $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(addressBuffer2));
                    }
                }
                return false;
            }
            static $h = 4579084;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3071756,"p":[{"n":"socketAddressBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"GetIPAddress","d":4579084,"h":4299546380,"f":33},{"r":65537,"p":[{"n":"socketAddressBuffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"address","p":3071756}],"n":"SetIPAddress","d":4579084,"h":8594513676,"f":33},{"r":3333900,"p":[{"n":"socketAddressBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"CreateIPEndPoint","d":4579084,"h":12889480972,"f":33},{"r":65537,"p":[{"n":"endPoint","p":3333900},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Serialize","d":4579084,"h":17184448268,"f":33},{"r":262145,"p":[{"n":"endPoint","p":3333900},{"n":"socketAddressBuffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Equals","o":"@$2","d":4579084,"h":21479415564,"f":33}],"h":4579084}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.IPEndPointExtensions`; }
        });
        
        $asm.$cls("$snp.System.Net.TcpValidationHelpers", ($self) => class TcpValidationHelpers
        {
            static /*bool */ ValidatePortNumber(/*int*/ port)
            {
                return port >= 0/*IPEndPoint.MinPort*/ && port <= 65535/*IPEndPoint.MaxPort*/;
            }
            static $h = 4972300;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"port","p":655361}],"n":"ValidatePortNumber","d":4972300,"h":4299939596,"f":33}],"h":4972300}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.TcpValidationHelpers`; }
        });
        
        $asm.$cls("$snp.System.Net.UriScheme", ($self) => class UriScheme
        {
            /*string*/ static File = null;
            /*string*/ static Ftp = null;
            /*string*/ static Gopher = null;
            /*string*/ static Http = null;
            /*string*/ static Https = null;
            /*string*/ static News = null;
            /*string*/ static NetPipe = null;
            /*string*/ static NetTcp = null;
            /*string*/ static Nntp = null;
            /*string*/ static Mailto = null;
            /*string*/ static Ws = null;
            /*string*/ static Wss = null;
            /*string*/ static SchemeDelimiter = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.File = "file";
                }
                {
                    this.Ftp = "ftp";
                }
                {
                    this.Gopher = "gopher";
                }
                {
                    this.Http = "http";
                }
                {
                    this.Https = "https";
                }
                {
                    this.News = "news";
                }
                {
                    this.NetPipe = "net.pipe";
                }
                {
                    this.NetTcp = "net.tcp";
                }
                {
                    this.Nntp = "nntp";
                }
                {
                    this.Mailto = "mailto";
                }
                {
                    this.Ws = "ws";
                }
                {
                    this.Wss = "wss";
                }
                {
                    this.SchemeDelimiter = "://";
                }
            }
            static $h = 5103372;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"File","d":5103372,"h":4300070668,"f":33},{"t":1310721,"n":"Ftp","d":5103372,"h":8595037964,"f":33},{"t":1310721,"n":"Gopher","d":5103372,"h":12890005260,"f":33},{"t":1310721,"n":"Http","d":5103372,"h":17184972556,"f":33},{"t":1310721,"n":"Https","d":5103372,"h":21479939852,"f":33},{"t":1310721,"n":"News","d":5103372,"h":25774907148,"f":33},{"t":1310721,"n":"NetPipe","d":5103372,"h":30069874444,"f":33},{"t":1310721,"n":"NetTcp","d":5103372,"h":34364841740,"f":33},{"t":1310721,"n":"Nntp","d":5103372,"h":38659809036,"f":33},{"t":1310721,"n":"Mailto","d":5103372,"h":42954776332,"f":33},{"t":1310721,"n":"Ws","d":5103372,"h":47249743628,"f":33},{"t":1310721,"n":"Wss","d":5103372,"h":51544710924,"f":33},{"t":1310721,"n":"SchemeDelimiter","d":5103372,"h":55839678220,"f":33}],"h":5103372}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.UriScheme`; }
        });
        
        $asm.$cls("$snp.System.Net.CookieFields", ($self) => class CookieFields
        {
            /*string*/ static CommentAttributeName = null;
            /*string*/ static CommentUrlAttributeName = null;
            /*string*/ static DiscardAttributeName = null;
            /*string*/ static DomainAttributeName = null;
            /*string*/ static ExpiresAttributeName = null;
            /*string*/ static MaxAgeAttributeName = null;
            /*string*/ static PathAttributeName = null;
            /*string*/ static PortAttributeName = null;
            /*string*/ static SecureAttributeName = null;
            /*string*/ static VersionAttributeName = null;
            /*string*/ static HttpOnlyAttributeName = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.CommentAttributeName = "Comment";
                }
                {
                    this.CommentUrlAttributeName = "CommentURL";
                }
                {
                    this.DiscardAttributeName = "Discard";
                }
                {
                    this.DomainAttributeName = "Domain";
                }
                {
                    this.ExpiresAttributeName = "Expires";
                }
                {
                    this.MaxAgeAttributeName = "Max-Age";
                }
                {
                    this.PathAttributeName = "Path";
                }
                {
                    this.PortAttributeName = "Port";
                }
                {
                    this.SecureAttributeName = "Secure";
                }
                {
                    this.VersionAttributeName = "Version";
                }
                {
                    this.HttpOnlyAttributeName = "HttpOnly";
                }
            }
            static $h = 1564428;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"CommentAttributeName","d":1564428,"h":4296531724,"f":40},{"t":1310721,"n":"CommentUrlAttributeName","d":1564428,"h":8591499020,"f":40},{"t":1310721,"n":"DiscardAttributeName","d":1564428,"h":12886466316,"f":40},{"t":1310721,"n":"DomainAttributeName","d":1564428,"h":17181433612,"f":40},{"t":1310721,"n":"ExpiresAttributeName","d":1564428,"h":21476400908,"f":40},{"t":1310721,"n":"MaxAgeAttributeName","d":1564428,"h":25771368204,"f":40},{"t":1310721,"n":"PathAttributeName","d":1564428,"h":30066335500,"f":40},{"t":1310721,"n":"PortAttributeName","d":1564428,"h":34361302796,"f":40},{"t":1310721,"n":"SecureAttributeName","d":1564428,"h":38656270092,"f":40},{"t":1310721,"n":"VersionAttributeName","d":1564428,"h":42951237388,"f":40},{"t":1310721,"n":"HttpOnlyAttributeName","d":1564428,"h":47246204684,"f":40}],"h":1564428}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.CookieFields`; }
        });
        
        $asm.$cls("$snp.System.Net.NegotiationInfoClass", ($self) => class NegotiationInfoClass
        {
            /*string*/ static NTLM = null;
            /*string*/ static Kerberos = null;
            /*string*/ static Negotiate = null;
            /*string*/ static Basic = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.NTLM = "NTLM";
                }
                {
                    this.Kerberos = "Kerberos";
                }
                {
                    this.Negotiate = "Negotiate";
                }
                {
                    this.Basic = "Basic";
                }
            }
            static $h = 3661580;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"NTLM","d":3661580,"h":4298628876,"f":40},{"t":1310721,"n":"Kerberos","d":3661580,"h":8593596172,"f":40},{"t":1310721,"n":"Negotiate","d":3661580,"h":12888563468,"f":40},{"t":1310721,"n":"Basic","d":3661580,"h":17183530764,"f":40}],"h":3661580}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NegotiationInfoClass`; }
        });
        
        $asm.$cls("$snp.System.Text.StringBuilderCache", ($self) => class StringBuilderCache
        {
            /*int*/ static MaxBuilderSize = 360;
            /*int*/ static DefaultCapacity = 16;
            /*StringBuilder?*/ static t_cachedInstance = null;
            static /*StringBuilder */ Acquire(/*int*/ capacity)
            {
                if (capacity <= 360/*MaxBuilderSize*/)
                {
                    /*StringBuilder?*/ let sb = $.$snp.System.Text.StringBuilderCache.t_cachedInstance;
                    if (sb !== null)
                    {
                        if (capacity <= sb.Capacity)
                        {
                            $.$snp.System.Text.StringBuilderCache.t_cachedInstance = null;
                            sb.Clear();
                            return sb;
                        }
                    }
                }
                return new $.$spc.System.Text.StringBuilder().$ctor$2(capacity);
            }
            static /*void */ Release(/*StringBuilder*/ sb)
            {
                if (sb.Capacity <= 360/*MaxBuilderSize*/)
                {
                    $.$snp.System.Text.StringBuilderCache.t_cachedInstance = sb;
                }
            }
            static /*string */ GetStringAndRelease(/*StringBuilder*/ sb)
            {
                /*string*/ let result = $.$spc.System.Text.StringBuilder.ToString.call(sb);
                $.$snp.System.Text.StringBuilderCache.Release(sb);
                return result;
            }
            static $h = 5758732;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":122945537,"p":[{"n":"capacity","p":655361,"f":65,"v":16}],"n":"Acquire","d":5758732,"h":17185627916,"f":33},{"r":65537,"p":[{"n":"sb","p":122945537}],"n":"Release","d":5758732,"h":21480595212,"f":33},{"r":1310721,"p":[{"n":"sb","p":122945537}],"n":"GetStringAndRelease","d":5758732,"h":25775562508,"f":33}],"l":[{"t":655361,"n":"MaxBuilderSize","d":5758732,"h":4300726028,"f":40},{"t":655361,"n":"DefaultCapacity","d":5758732,"h":8595693324,"f":34},{"t":122945537,"n":"t_cachedInstance","d":5758732,"h":12890660620,"f":34,"a":[{"t":140181505,"c":4435148801}]}],"h":5758732}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Text.StringBuilderCache`; }
        });
        
        $asm.$cls("$snp.System.HexConverter", ($self) => class HexConverter
        {
            static $_Casing;
            static get Casing()
            {
                let $cls = $.$snp.System.HexConverter;
                return $cls.$_Casing ??= $asm.$nstr("$snp.System.HexConverter.Casing", ($self) => class Casing extends $.$spc.System.Enum
                {
                    static Upper = 0;
                    static Lower = 8224;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Upper": 0n,
                            "Lower": 8224n
                        };
                    }
                    static $h = 843532;
                    static $z = 4;
                    static $f = 0b110000011010001001;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.UInt32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":720897,"l":[{"t":843532,"n":"Upper","d":843532,"h":4295810828,"f":33},{"t":843532,"n":"Lower","d":843532,"h":8590778124,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":843532,"h":12885745420,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":777996,"h":843532}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.HexConverter.Casing`; }
                }, $cls, ($v) => $cls.$_Casing = $v);
            }
            static /*void */ ToBytesBuffer(/*byte*/ value, /*Span<byte>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast(packedResult, $.$spc.System.Byte);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$spc.System.Byte);
            }
            static /*void */ ToCharsBuffer(/*byte*/ value, /*Span<char>*/ buffer, /*int*/ startingIndex, /*Casing*/ casing)
            {
                /*uint*/ let difference = (((((((value & 240) << 4) >>> 0) + (value & 15)) >>> 0) - 35209) >>> 0);
                /*uint*/ let packedResult = (((((((((-(difference | 0)) >>> 0) & 28784) >>> 4) + difference) >>> 0) + 47545) >>> 0)) | casing;
                buffer.get_Item(((startingIndex + 1) | 0)).$v = $.$cast((packedResult & 255), $.$spc.System.Char);
                buffer.get_Item(startingIndex).$v = $.$cast((packedResult >>> 8), $.$spc.System.Char);
            }
            static /*void */ EncodeToUtf8(/*ReadOnlySpan<byte>*/ source, /*Span<byte>*/ utf8Destination, /*Casing*/ casing)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(utf8Destination.Length >= (((source.Length * 2) | 0)), "utf8Destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$snp.System.HexConverter.ToBytesBuffer(source.get_Item(pos).$v, utf8Destination, ((pos * 2) | 0), casing);
                }
            }
            static /*void */ EncodeToUtf16(/*ReadOnlySpan<byte>*/ source, /*Span<char>*/ destination, /*Casing*/ casing)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(destination.Length >= (((source.Length * 2) | 0)), "destination.Length >= (source.Length * 2)");
                for(/*int*/ let pos = 0; pos < source.Length; pos++)
                {
                    $.$snp.System.HexConverter.ToCharsBuffer(source.get_Item(pos).$v, destination, ((pos * 2) | 0), casing);
                }
            }
            static /*string */ ToString$1(/*ReadOnlySpan<byte>*/ bytes, /*Casing*/ casing)
            {
                /*SpanCasingPair*/ let args = (() =>
                {
                    //new $.$snp.System.HexConverter.SpanCasingPair()
                    const $t1 = $.$snp.System.HexConverter.SpanCasingPair;
                    const $i1 = new $t1();
                    $i1.Bytes = bytes;
                    $i1.Casing = casing;
                    return $i1;
                })();
                return $.$spc.System.String.Create$8($.$snp.System.HexConverter.SpanCasingPair, ((bytes.Length * 2) | 0), args.Clone(), new ($.$spc.System.Buffers.SpanAction$$$($.$spc.System.Char, $.$snp.System.HexConverter.SpanCasingPair))().$ctor(null, /*static*/ (/**/ chars, /*args*/ args) =>
                {
                    return $.$snp.System.HexConverter.EncodeToUtf16(args.Bytes, chars, args.Casing);
                }));
            }
            static $_SpanCasingPair;
            static get SpanCasingPair()
            {
                let $cls = $.$snp.System.HexConverter;
                return $cls.$_SpanCasingPair ??= $asm.$nstr("$snp.System.HexConverter.SpanCasingPair", ($self) => class SpanCasingPair extends $.$spc.System.ValueType
                {
                    /*ReadOnlySpan<byte>*/ Bytes;
                    /*Casing*/ Casing = 0;
                    //default value type constructor
                    $ctor$2()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy.Bytes = this.Bytes.Clone();
                        copy.Casing = this.Casing;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this.Bytes = $.$default($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte));
                        this.Casing = 0;
                    }
                    static $h = 909068;
                    static $z = 9;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":12885810956,"f":1},"s":{"r":0,"d":0,"h":17180778252,"f":1},"n":"Bytes","d":909068,"h":8590843660,"f":1},{"p":843532,"g":{"r":0,"d":0,"h":30065680140,"f":1},"s":{"r":0,"d":0,"h":34360647436,"f":1},"n":"Casing","d":909068,"h":25770712844,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":909068,"h":38655614732,"f":1}],"d":777996,"h":909068}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.HexConverter.SpanCasingPair`; }
                }, $cls, ($v) => $cls.$_SpanCasingPair = $v);
            }
            static /*char */ ToCharUpper(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*A*/ 65 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$spc.System.Char);
            }
            static /*char */ ToCharLower(/*int*/ value)
            {
                value &= 15;
                value += /*0*/ 48;
                if (value > /*9*/ 57)
                {
                    value += (((/*a*/ 97 - (((/*9*/ 57 + 1) | 0))) | 0));
                }
                return $.$cast(value, $.$spc.System.Char);
            }
            static /*bool */ TryDecodeFromUtf8(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                return $.$snp.System.HexConverter.TryDecodeFromUtf8_Scalar(utf8Source, destination, bytesProcessed);
            }
            static /*bool */ TryDecodeFromUtf16(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                return $.$snp.System.HexConverter.TryDecodeFromUtf16_Scalar(source, destination, charsProcessed);
            }
            static /*bool */ TryDecodeFromUtf8_Scalar(/*ReadOnlySpan<byte>*/ utf8Source, /*Span<byte>*/ destination, /*out int*/ bytesProcessed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((utf8Source.Length % 2) === 0, "Un-even number of characters provided");
                $.$spc.System.Diagnostics.Debug.Assert$1(($.trunc(utf8Source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$snp.System.HexConverter.FromChar(utf8Source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$snp.System.HexConverter.FromChar(utf8Source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$spc.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                bytesProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*bool */ TryDecodeFromUtf16_Scalar(/*ReadOnlySpan<char>*/ source, /*Span<byte>*/ destination, /*out int*/ charsProcessed)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1((source.Length % 2) === 0, "Un-even number of characters provided");
                $.$spc.System.Diagnostics.Debug.Assert$1(($.trunc(source.Length / 2)) === destination.Length, "Target buffer not right-sized for provided characters");
                /*int*/ let i = 0;
                /*int*/ let j = 0;
                /*int*/ let byteLo = 0;
                /*int*/ let byteHi = 0;
                while(j < destination.Length)
                {
                    byteLo = $.$snp.System.HexConverter.FromChar(source.get_Item(((i + 1) | 0)).$v);
                    byteHi = $.$snp.System.HexConverter.FromChar(source.get_Item(i).$v);
                    if ((byteLo | byteHi) === 255)
                    {
                        break;
                    }
                    destination.get_Item(j++).$v = $.$cast(((byteHi << 4) | byteLo), $.$spc.System.Byte);
                    i += 2;
                }
                if (byteLo === 255)
                {
                    i++;
                }
                charsProcessed.$v = i;
                return (byteLo | byteHi) !== 255;
            }
            static /*int */ FromChar(/*int*/ c)
            {
                return (c >= $.$snp.System.HexConverter.CharToHexLookup.Length) ? 255 : $.$snp.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromUpperChar(/*int*/ c)
            {
                return (c > 71) ? 255 : $.$snp.System.HexConverter.CharToHexLookup.get_Item(c).$v;
            }
            static /*int */ FromLowerChar(/*int*/ c)
            {
                if (((((c - /*0*/ 48) | 0)) >>> 0) <= (/*9*/ 57 - /*0*/ 48))
                {
                    return ((c - /*0*/ 48) | 0);
                }
                if (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97))
                {
                    return ((((c - /*a*/ 97) | 0) + 10) | 0);
                }
                return 255;
            }
            static /*bool */ IsHexChar(/*int*/ c)
            {
                //if (IntPtr.Size == 8) { ... }
                return $.$snp.System.HexConverter.FromChar(c) !== 255;
            }
            static /*bool */ IsHexUpperChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*A*/ 65) | 0)) >>> 0) <= (/*F*/ 70 - /*A*/ 65));
            }
            static /*bool */ IsHexLowerChar(/*int*/ c)
            {
                return (((((c - /*0*/ 48) | 0)) >>> 0) <= 9) || (((((c - /*a*/ 97) | 0)) >>> 0) <= (/*f*/ 102 - /*a*/ 97));
            }
            static /*ReadOnlySpan<byte> */ get CharToHexLookup()
            {
                return this.$cacheCharToHexLookup ??= new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2([ 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10, 11, 12, 13, 14, 15, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255 ]);
            }
            static $h = 777996;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":90195091212,"f":33},"n":"CharToHexLookup","d":777996,"h":85900123916,"f":33}],"m":[{"r":65537,"p":[{"n":"value","p":393217},{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"startingIndex","p":655361,"f":65,"v":0},{"n":"casing","p":843532,"f":65,"v":0}],"n":"ToBytesBuffer","d":777996,"h":8590712588,"f":33},{"r":65537,"p":[{"n":"value","p":393217},{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"startingIndex","p":655361,"f":65,"v":0},{"n":"casing","p":843532,"f":65,"v":0}],"n":"ToCharsBuffer","d":777996,"h":12885679884,"f":33},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"utf8Destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"casing","p":843532,"f":65,"v":0}],"n":"EncodeToUtf8","d":777996,"h":17180647180,"f":33},{"r":65537,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"casing","p":843532,"f":65,"v":0}],"n":"EncodeToUtf16","d":777996,"h":21475614476,"f":33},{"r":1310721,"p":[{"n":"bytes","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"casing","p":843532,"f":65,"v":0}],"n":"ToString","o":"@$1","d":777996,"h":25770581772,"f":33},{"r":458753,"p":[{"n":"value","p":655361}],"n":"ToCharUpper","d":777996,"h":34360516364,"f":33},{"r":458753,"p":[{"n":"value","p":655361}],"n":"ToCharLower","d":777996,"h":38655483660,"f":33},{"r":262145,"p":[{"n":"utf8Source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf8","d":777996,"h":42950450956,"f":33},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"charsProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf16","d":777996,"h":47245418252,"f":33},{"r":262145,"p":[{"n":"utf8Source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf8_Scalar","d":777996,"h":51540385548,"f":34},{"r":262145,"p":[{"n":"source","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"charsProcessed","p":655361,"f":2}],"n":"TryDecodeFromUtf16_Scalar","d":777996,"h":55835352844,"f":34},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromChar","d":777996,"h":60130320140,"f":33},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromUpperChar","d":777996,"h":64425287436,"f":33},{"r":655361,"p":[{"n":"c","p":655361}],"n":"FromLowerChar","d":777996,"h":68720254732,"f":33},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexChar","d":777996,"h":73015222028,"f":33},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexUpperChar","d":777996,"h":77310189324,"f":33},{"r":262145,"p":[{"n":"c","p":655361}],"n":"IsHexLowerChar","d":777996,"h":81605156620,"f":33}],"j":[843532,909068],"h":777996}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.HexConverter`; }
        });
        
        $asm.$cls("$snp.System.NotImplemented", ($self) => class NotImplemented
        {
            static /*Exception */ get ByDesign()
            {
                return new $.$spc.System.NotImplementedException().$ctor$9();
            }
            static /*Exception */ ByDesignWithMessage(/*string*/ message)
            {
                return new $.$spc.System.NotImplementedException().$ctor$10(message);
            }
            static $h = 5168908;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":47185921,"g":{"r":0,"d":0,"h":8595103500,"f":40},"n":"ByDesign","d":5168908,"h":4300136204,"f":40}],"m":[{"r":47185921,"p":[{"n":"message","p":1310721}],"n":"ByDesignWithMessage","d":5168908,"h":12890070796,"f":40}],"h":5168908}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.NotImplemented`; }
        });
        
        $asm.$cls("$snp.System.Obsoletions", ($self) => class Obsoletions
        {
            /*string*/ static SharedUrlFormat = null;
            /*string*/ static SystemTextEncodingUTF7Message = null;
            /*string*/ static SystemTextEncodingUTF7DiagId = null;
            /*string*/ static PrincipalPermissionAttributeMessage = null;
            /*string*/ static PrincipalPermissionAttributeDiagId = null;
            /*string*/ static CodeAccessSecurityMessage = null;
            /*string*/ static CodeAccessSecurityDiagId = null;
            /*string*/ static ConstrainedExecutionRegionMessage = null;
            /*string*/ static ConstrainedExecutionRegionDiagId = null;
            /*string*/ static GlobalAssemblyCacheMessage = null;
            /*string*/ static GlobalAssemblyCacheDiagId = null;
            /*string*/ static ThreadAbortMessage = null;
            /*string*/ static ThreadResetAbortMessage = null;
            /*string*/ static ThreadAbortDiagId = null;
            /*string*/ static DefaultCryptoAlgorithmsMessage = null;
            /*string*/ static DefaultCryptoAlgorithmsDiagId = null;
            /*string*/ static CreatePdbGeneratorMessage = null;
            /*string*/ static CreatePdbGeneratorDiagId = null;
            /*string*/ static AuthenticationManagerMessage = null;
            /*string*/ static AuthenticationManagerDiagId = null;
            /*string*/ static RemotingApisMessage = null;
            /*string*/ static RemotingApisDiagId = null;
            /*string*/ static BinaryFormatterMessage = null;
            /*string*/ static BinaryFormatterDiagId = null;
            /*string*/ static CodeBaseMessage = null;
            /*string*/ static CodeBaseDiagId = null;
            /*string*/ static EscapeUriStringMessage = null;
            /*string*/ static EscapeUriStringDiagId = null;
            /*string*/ static WebRequestMessage = null;
            /*string*/ static WebRequestDiagId = null;
            /*string*/ static DisablePrivateReflectionAttributeMessage = null;
            /*string*/ static DisablePrivateReflectionAttributeDiagId = null;
            /*string*/ static GetContextInfoMessage = null;
            /*string*/ static GetContextInfoDiagId = null;
            /*string*/ static StrongNameKeyPairMessage = null;
            /*string*/ static StrongNameKeyPairDiagId = null;
            /*string*/ static ReflectionOnlyLoadingMessage = null;
            /*string*/ static ReflectionOnlyLoadingDiagId = null;
            /*string*/ static RuntimeEnvironmentMessage = null;
            /*string*/ static RuntimeEnvironmentDiagId = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesMessage = null;
            /*string*/ static JsonSerializerOptionsIgnoreNullValuesDiagId = null;
            /*string*/ static DerivedCryptographicTypesMessage = null;
            /*string*/ static DerivedCryptographicTypesDiagId = null;
            /*string*/ static RijndaelMessage = null;
            /*string*/ static RijndaelDiagId = null;
            /*string*/ static RNGCryptoServiceProviderMessage = null;
            /*string*/ static RNGCryptoServiceProviderDiagId = null;
            /*string*/ static AppDomainCreateUnloadMessage = null;
            /*string*/ static AppDomainCreateUnloadDiagId = null;
            /*string*/ static SuppressIldasmAttributeMessage = null;
            /*string*/ static SuppressIldasmAttributeDiagId = null;
            /*string*/ static X509CertificateImmutableMessage = null;
            /*string*/ static X509CertificateImmutableDiagId = null;
            /*string*/ static PublicKeyPropertyMessage = null;
            /*string*/ static PublicKeyPropertyDiagId = null;
            /*string*/ static X509CertificatePrivateKeyMessage = null;
            /*string*/ static X509CertificatePrivateKeyDiagId = null;
            /*string*/ static ProduceLegacyHmacValuesMessage = null;
            /*string*/ static ProduceLegacyHmacValuesDiagId = null;
            /*string*/ static UseManagedSha1Message = null;
            /*string*/ static UseManagedSha1DiagId = null;
            /*string*/ static CryptoConfigEncodeOIDMessage = null;
            /*string*/ static CryptoConfigEncodeOIDDiagId = null;
            /*string*/ static CorruptedStateRecoveryMessage = null;
            /*string*/ static CorruptedStateRecoveryDiagId = null;
            /*string*/ static Rfc2898CryptDeriveKeyMessage = null;
            /*string*/ static Rfc2898CryptDeriveKeyDiagId = null;
            /*string*/ static CmsSignerCspParamsCtorMessage = null;
            /*string*/ static CmsSignerCspParamsCtorDiagId = null;
            /*string*/ static SignerInfoCounterSigMessage = null;
            /*string*/ static SignerInfoCounterSigDiagId = null;
            /*string*/ static RegexCompileToAssemblyMessage = null;
            /*string*/ static RegexCompileToAssemblyDiagId = null;
            /*string*/ static AssemblyNameMembersMessage = null;
            /*string*/ static AssemblyNameMembersDiagId = null;
            /*string*/ static SystemDataSerializationFormatBinaryMessage = null;
            /*string*/ static SystemDataSerializationFormatBinaryDiagId = null;
            /*string*/ static TlsVersion10and11Message = null;
            /*string*/ static TlsVersion10and11DiagId = null;
            /*string*/ static EncryptionPolicyMessage = null;
            /*string*/ static EncryptionPolicyDiagId = null;
            /*string*/ static EccXmlExportImportMessage = null;
            /*string*/ static EccXmlExportImportDiagId = null;
            /*string*/ static EcDhPublicKeyBlobMessage = null;
            /*string*/ static EcDhPublicKeyBlobDiagId = null;
            /*string*/ static AssemblyNameCodeBaseMessage = null;
            /*string*/ static AssemblyNameCodeBaseDiagId = null;
            /*string*/ static CryptoStringFactoryMessage = null;
            /*string*/ static CryptoStringFactoryDiagId = null;
            /*string*/ static ControlledExecutionRunMessage = null;
            /*string*/ static ControlledExecutionRunDiagId = null;
            /*string*/ static XmlSecureResolverMessage = null;
            /*string*/ static XmlSecureResolverDiagId = null;
            /*string*/ static RsaEncryptDecryptValueMessage = null;
            /*string*/ static RsaEncryptDecryptDiagId = null;
            /*string*/ static JsonSerializerOptionsAddContextMessage = null;
            /*string*/ static JsonSerializerOptionsAddContextDiagId = null;
            /*string*/ static LegacyFormatterMessage = null;
            /*string*/ static LegacyFormatterDiagId = null;
            /*string*/ static LegacyFormatterImplMessage = null;
            /*string*/ static LegacyFormatterImplDiagId = null;
            /*string*/ static RegexExtensibilityImplMessage = null;
            /*string*/ static RegexExtensibilityDiagId = null;
            /*string*/ static AesGcmTagConstructorMessage = null;
            /*string*/ static AesGcmTagConstructorDiagId = null;
            /*string*/ static ThreadVolatileReadWriteMessage = null;
            /*string*/ static ThreadVolatileReadWriteDiagId = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationMessage = null;
            /*string*/ static ArmIntrinsicPerformsUnsignedOperationDiagId = null;
            /*string*/ static LoadFromHashAlgorithmMessage = null;
            /*string*/ static LoadFromHashAlgorithmDiagId = null;
            /*string*/ static X509CtorCertDataObsoleteMessage = null;
            /*string*/ static X509CtorCertDataObsoleteDiagId = null;
            /*string*/ static TlsCipherAlgorithmEnumsMessage = null;
            /*string*/ static TlsCipherAlgorithmEnumsDiagId = null;
            /*string*/ static SystemEventsEventsThreadShutdownMessage = null;
            /*string*/ static SystemEventsEventsThreadShutdownDiagId = null;
            /*string*/ static Rfc2898DeriveBytesCtorMessage = null;
            /*string*/ static Rfc2898DeriveBytesCtorDiagId = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteMessage = null;
            /*string*/ static QueryableMinByMaxByTSourceObsoleteDiagId = null;
            /*string*/ static XsltSettingsEnableScriptMessage = null;
            /*string*/ static XsltSettingsEnableScriptDiagId = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.SharedUrlFormat = "https://aka.ms/dotnet-warnings/{0}";
                }
                {
                    this.SystemTextEncodingUTF7Message = "The UTF-7 encoding is insecure and should not be used. Consider using UTF-8 instead.";
                }
                {
                    this.SystemTextEncodingUTF7DiagId = "SYSLIB0001";
                }
                {
                    this.PrincipalPermissionAttributeMessage = "PrincipalPermissionAttribute is not honored by the runtime and must not be used.";
                }
                {
                    this.PrincipalPermissionAttributeDiagId = "SYSLIB0002";
                }
                {
                    this.CodeAccessSecurityMessage = "Code Access Security is not supported or honored by the runtime.";
                }
                {
                    this.CodeAccessSecurityDiagId = "SYSLIB0003";
                }
                {
                    this.ConstrainedExecutionRegionMessage = "The Constrained Execution Region (CER) feature is not supported.";
                }
                {
                    this.ConstrainedExecutionRegionDiagId = "SYSLIB0004";
                }
                {
                    this.GlobalAssemblyCacheMessage = "The Global Assembly Cache is not supported.";
                }
                {
                    this.GlobalAssemblyCacheDiagId = "SYSLIB0005";
                }
                {
                    this.ThreadAbortMessage = "Thread.Abort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadResetAbortMessage = "Thread.ResetAbort is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ThreadAbortDiagId = "SYSLIB0006";
                }
                {
                    this.DefaultCryptoAlgorithmsMessage = "The default implementation of this cryptography algorithm is not supported.";
                }
                {
                    this.DefaultCryptoAlgorithmsDiagId = "SYSLIB0007";
                }
                {
                    this.CreatePdbGeneratorMessage = "The CreatePdbGenerator API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.CreatePdbGeneratorDiagId = "SYSLIB0008";
                }
                {
                    this.AuthenticationManagerMessage = "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.";
                }
                {
                    this.AuthenticationManagerDiagId = "SYSLIB0009";
                }
                {
                    this.RemotingApisMessage = "This Remoting API is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.RemotingApisDiagId = "SYSLIB0010";
                }
                {
                    this.BinaryFormatterMessage = "BinaryFormatter serialization is obsolete and should not be used. See https://aka.ms/binaryformatter for more information.";
                }
                {
                    this.BinaryFormatterDiagId = "SYSLIB0011";
                }
                {
                    this.CodeBaseMessage = "Assembly.CodeBase and Assembly.EscapedCodeBase are only included for .NET Framework compatibility. Use Assembly.Location instead.";
                }
                {
                    this.CodeBaseDiagId = "SYSLIB0012";
                }
                {
                    this.EscapeUriStringMessage = "Uri.EscapeUriString can corrupt the Uri string in some cases. Consider using Uri.EscapeDataString for query string components instead.";
                }
                {
                    this.EscapeUriStringDiagId = "SYSLIB0013";
                }
                {
                    this.WebRequestMessage = "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.";
                }
                {
                    this.WebRequestDiagId = "SYSLIB0014";
                }
                {
                    this.DisablePrivateReflectionAttributeMessage = "DisablePrivateReflectionAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.DisablePrivateReflectionAttributeDiagId = "SYSLIB0015";
                }
                {
                    this.GetContextInfoMessage = "Use the Graphics.GetContextInfo overloads that accept arguments for better performance and fewer allocations.";
                }
                {
                    this.GetContextInfoDiagId = "SYSLIB0016";
                }
                {
                    this.StrongNameKeyPairMessage = "Strong name signing is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.StrongNameKeyPairDiagId = "SYSLIB0017";
                }
                {
                    this.ReflectionOnlyLoadingMessage = "ReflectionOnly loading is not supported and throws PlatformNotSupportedException.";
                }
                {
                    this.ReflectionOnlyLoadingDiagId = "SYSLIB0018";
                }
                {
                    this.RuntimeEnvironmentMessage = "RuntimeEnvironment members SystemConfigurationFile, GetRuntimeInterfaceAsIntPtr, and GetRuntimeInterfaceAsObject are not supported and throw PlatformNotSupportedException.";
                }
                {
                    this.RuntimeEnvironmentDiagId = "SYSLIB0019";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesMessage = "JsonSerializerOptions.IgnoreNullValues is obsolete. To ignore null values when serializing, set DefaultIgnoreCondition to JsonIgnoreCondition.WhenWritingNull.";
                }
                {
                    this.JsonSerializerOptionsIgnoreNullValuesDiagId = "SYSLIB0020";
                }
                {
                    this.DerivedCryptographicTypesMessage = "Derived cryptographic types are obsolete. Use the Create method on the base type instead.";
                }
                {
                    this.DerivedCryptographicTypesDiagId = "SYSLIB0021";
                }
                {
                    this.RijndaelMessage = "The Rijndael and RijndaelManaged types are obsolete. Use Aes instead.";
                }
                {
                    this.RijndaelDiagId = "SYSLIB0022";
                }
                {
                    this.RNGCryptoServiceProviderMessage = "RNGCryptoServiceProvider is obsolete. To generate a random number, use one of the RandomNumberGenerator static methods instead.";
                }
                {
                    this.RNGCryptoServiceProviderDiagId = "SYSLIB0023";
                }
                {
                    this.AppDomainCreateUnloadMessage = "Creating and unloading AppDomains is not supported and throws an exception.";
                }
                {
                    this.AppDomainCreateUnloadDiagId = "SYSLIB0024";
                }
                {
                    this.SuppressIldasmAttributeMessage = "SuppressIldasmAttribute has no effect in .NET 6.0+.";
                }
                {
                    this.SuppressIldasmAttributeDiagId = "SYSLIB0025";
                }
                {
                    this.X509CertificateImmutableMessage = "X509Certificate and X509Certificate2 are immutable. Use X509CertificateLoader to create a new certificate.";
                }
                {
                    this.X509CertificateImmutableDiagId = "SYSLIB0026";
                }
                {
                    this.PublicKeyPropertyMessage = "PublicKey.Key is obsolete. Use the appropriate method to get the public key, such as GetRSAPublicKey.";
                }
                {
                    this.PublicKeyPropertyDiagId = "SYSLIB0027";
                }
                {
                    this.X509CertificatePrivateKeyMessage = "X509Certificate2.PrivateKey is obsolete. Use the appropriate method to get the private key, such as GetRSAPrivateKey, or use the CopyWithPrivateKey method to create a new instance with a private key.";
                }
                {
                    this.X509CertificatePrivateKeyDiagId = "SYSLIB0028";
                }
                {
                    this.ProduceLegacyHmacValuesMessage = "ProduceLegacyHmacValues is obsolete. Producing legacy HMAC values is not supported.";
                }
                {
                    this.ProduceLegacyHmacValuesDiagId = "SYSLIB0029";
                }
                {
                    this.UseManagedSha1Message = "HMACSHA1 always uses the algorithm implementation provided by the platform. Use a constructor without the useManagedSha1 parameter.";
                }
                {
                    this.UseManagedSha1DiagId = "SYSLIB0030";
                }
                {
                    this.CryptoConfigEncodeOIDMessage = "EncodeOID is obsolete. Use the ASN.1 functionality provided in System.Formats.Asn1.";
                }
                {
                    this.CryptoConfigEncodeOIDDiagId = "SYSLIB0031";
                }
                {
                    this.CorruptedStateRecoveryMessage = "Recovery from corrupted process state exceptions is not supported; HandleProcessCorruptedStateExceptionsAttribute is ignored.";
                }
                {
                    this.CorruptedStateRecoveryDiagId = "SYSLIB0032";
                }
                {
                    this.Rfc2898CryptDeriveKeyMessage = "Rfc2898DeriveBytes.CryptDeriveKey is obsolete and is not supported. Use PasswordDeriveBytes.CryptDeriveKey instead.";
                }
                {
                    this.Rfc2898CryptDeriveKeyDiagId = "SYSLIB0033";
                }
                {
                    this.CmsSignerCspParamsCtorMessage = "CmsSigner(CspParameters) is obsolete and is not supported. Use an alternative constructor instead.";
                }
                {
                    this.CmsSignerCspParamsCtorDiagId = "SYSLIB0034";
                }
                {
                    this.SignerInfoCounterSigMessage = "ComputeCounterSignature without specifying a CmsSigner is obsolete and is not supported. Use the overload that accepts a CmsSigner.";
                }
                {
                    this.SignerInfoCounterSigDiagId = "SYSLIB0035";
                }
                {
                    this.RegexCompileToAssemblyMessage = "Regex.CompileToAssembly is obsolete and not supported. Use the GeneratedRegexAttribute with the regular expression source generator instead.";
                }
                {
                    this.RegexCompileToAssemblyDiagId = "SYSLIB0036";
                }
                {
                    this.AssemblyNameMembersMessage = "AssemblyName members HashAlgorithm, ProcessorArchitecture, and VersionCompatibility are obsolete and not supported.";
                }
                {
                    this.AssemblyNameMembersDiagId = "SYSLIB0037";
                }
                {
                    this.SystemDataSerializationFormatBinaryMessage = "SerializationFormat.Binary is obsolete and should not be used. See https://aka.ms/serializationformat-binary-obsolete for more information.";
                }
                {
                    this.SystemDataSerializationFormatBinaryDiagId = "SYSLIB0038";
                }
                {
                    this.TlsVersion10and11Message = "TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.";
                }
                {
                    this.TlsVersion10and11DiagId = "SYSLIB0039";
                }
                {
                    this.EncryptionPolicyMessage = "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.";
                }
                {
                    this.EncryptionPolicyDiagId = "SYSLIB0040";
                }
                {
                    this.EccXmlExportImportMessage = "ToXmlString and FromXmlString have no implementation for ECC types, and are obsolete. Use a standard import and export format such as ExportSubjectPublicKeyInfo or ImportSubjectPublicKeyInfo for public keys and ExportPkcs8PrivateKey or ImportPkcs8PrivateKey for private keys.";
                }
                {
                    this.EccXmlExportImportDiagId = "SYSLIB0042";
                }
                {
                    this.EcDhPublicKeyBlobMessage = "ECDiffieHellmanPublicKey.ToByteArray() and the associated constructor do not have a consistent and interoperable implementation on all platforms. Use ECDiffieHellmanPublicKey.ExportSubjectPublicKeyInfo() instead.";
                }
                {
                    this.EcDhPublicKeyBlobDiagId = "SYSLIB0043";
                }
                {
                    this.AssemblyNameCodeBaseMessage = "AssemblyName.CodeBase and AssemblyName.EscapedCodeBase are obsolete. Using them for loading an assembly is not supported.";
                }
                {
                    this.AssemblyNameCodeBaseDiagId = "SYSLIB0044";
                }
                {
                    this.CryptoStringFactoryMessage = "Cryptographic factory methods accepting an algorithm name are obsolete. Use the parameterless Create factory method on the algorithm type instead.";
                }
                {
                    this.CryptoStringFactoryDiagId = "SYSLIB0045";
                }
                {
                    this.ControlledExecutionRunMessage = "ControlledExecution.Run method may corrupt the process and should not be used in production code.";
                }
                {
                    this.ControlledExecutionRunDiagId = "SYSLIB0046";
                }
                {
                    this.XmlSecureResolverMessage = "XmlSecureResolver is obsolete. Use XmlResolver.ThrowingResolver instead when attempting to forbid XML external entity resolution.";
                }
                {
                    this.XmlSecureResolverDiagId = "SYSLIB0047";
                }
                {
                    this.RsaEncryptDecryptValueMessage = "RSA.EncryptValue and DecryptValue are not supported and throw NotSupportedException. Use RSA.Encrypt and RSA.Decrypt instead.";
                }
                {
                    this.RsaEncryptDecryptDiagId = "SYSLIB0048";
                }
                {
                    this.JsonSerializerOptionsAddContextMessage = "JsonSerializerOptions.AddContext is obsolete. To register a JsonSerializerContext, use either the TypeInfoResolver or TypeInfoResolverChain properties.";
                }
                {
                    this.JsonSerializerOptionsAddContextDiagId = "SYSLIB0049";
                }
                {
                    this.LegacyFormatterMessage = "Formatter-based serialization is obsolete and should not be used.";
                }
                {
                    this.LegacyFormatterDiagId = "SYSLIB0050";
                }
                {
                    this.LegacyFormatterImplMessage = "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.";
                }
                {
                    this.LegacyFormatterImplDiagId = "SYSLIB0051";
                }
                {
                    this.RegexExtensibilityImplMessage = "This API supports obsolete mechanisms for Regex extensibility. It is not supported.";
                }
                {
                    this.RegexExtensibilityDiagId = "SYSLIB0052";
                }
                {
                    this.AesGcmTagConstructorMessage = "AesGcm should indicate the required tag size for encryption and decryption. Use a constructor that accepts the tag size.";
                }
                {
                    this.AesGcmTagConstructorDiagId = "SYSLIB0053";
                }
                {
                    this.ThreadVolatileReadWriteMessage = "Thread.VolatileRead and Thread.VolatileWrite are obsolete. Use Volatile.Read or Volatile.Write respectively instead.";
                }
                {
                    this.ThreadVolatileReadWriteDiagId = "SYSLIB0054";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationMessage = "The underlying hardware instruction does not perform a signed saturate narrowing operation, and it always returns an unsigned result. Use the unsigned overload instead.";
                }
                {
                    this.ArmIntrinsicPerformsUnsignedOperationDiagId = "SYSLIB0055";
                }
                {
                    this.LoadFromHashAlgorithmMessage = "LoadFrom with a custom AssemblyHashAlgorithm is obsolete. Use overloads without an AssemblyHashAlgorithm.";
                }
                {
                    this.LoadFromHashAlgorithmDiagId = "SYSLIB0056";
                }
                {
                    this.X509CtorCertDataObsoleteMessage = "Loading certificate data through the constructor or Import is obsolete. Use X509CertificateLoader instead to load certificates.";
                }
                {
                    this.X509CtorCertDataObsoleteDiagId = "SYSLIB0057";
                }
                {
                    this.TlsCipherAlgorithmEnumsMessage = "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.";
                }
                {
                    this.TlsCipherAlgorithmEnumsDiagId = "SYSLIB0058";
                }
                {
                    this.SystemEventsEventsThreadShutdownMessage = "SystemEvents.EventsThreadShutdown callbacks are not run before the process exits. Use AppDomain.ProcessExit instead.";
                }
                {
                    this.SystemEventsEventsThreadShutdownDiagId = "SYSLIB0059";
                }
                {
                    this.Rfc2898DeriveBytesCtorMessage = "The constructors on Rfc2898DeriveBytes are obsolete. Use the static Pbkdf2 method instead.";
                }
                {
                    this.Rfc2898DeriveBytesCtorDiagId = "SYSLIB0060";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteMessage = "The Queryable MinBy and MaxBy taking an IComparer<TSource> are obsolete. Use the new ones that take an IComparer<TKey>.";
                }
                {
                    this.QueryableMinByMaxByTSourceObsoleteDiagId = "SYSLIB0061";
                }
                {
                    this.XsltSettingsEnableScriptMessage = "XSLT Script blocks are not supported.";
                }
                {
                    this.XsltSettingsEnableScriptDiagId = "SYSLIB0062";
                }
            }
            static $h = 5234444;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"SharedUrlFormat","d":5234444,"h":4300201740,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7Message","d":5234444,"h":8595169036,"f":40},{"t":1310721,"n":"SystemTextEncodingUTF7DiagId","d":5234444,"h":12890136332,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeMessage","d":5234444,"h":17185103628,"f":40},{"t":1310721,"n":"PrincipalPermissionAttributeDiagId","d":5234444,"h":21480070924,"f":40},{"t":1310721,"n":"CodeAccessSecurityMessage","d":5234444,"h":25775038220,"f":40},{"t":1310721,"n":"CodeAccessSecurityDiagId","d":5234444,"h":30070005516,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionMessage","d":5234444,"h":34364972812,"f":40},{"t":1310721,"n":"ConstrainedExecutionRegionDiagId","d":5234444,"h":38659940108,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheMessage","d":5234444,"h":42954907404,"f":40},{"t":1310721,"n":"GlobalAssemblyCacheDiagId","d":5234444,"h":47249874700,"f":40},{"t":1310721,"n":"ThreadAbortMessage","d":5234444,"h":51544841996,"f":40},{"t":1310721,"n":"ThreadResetAbortMessage","d":5234444,"h":55839809292,"f":40},{"t":1310721,"n":"ThreadAbortDiagId","d":5234444,"h":60134776588,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsMessage","d":5234444,"h":64429743884,"f":40},{"t":1310721,"n":"DefaultCryptoAlgorithmsDiagId","d":5234444,"h":68724711180,"f":40},{"t":1310721,"n":"CreatePdbGeneratorMessage","d":5234444,"h":73019678476,"f":40},{"t":1310721,"n":"CreatePdbGeneratorDiagId","d":5234444,"h":77314645772,"f":40},{"t":1310721,"n":"AuthenticationManagerMessage","d":5234444,"h":81609613068,"f":40},{"t":1310721,"n":"AuthenticationManagerDiagId","d":5234444,"h":85904580364,"f":40},{"t":1310721,"n":"RemotingApisMessage","d":5234444,"h":90199547660,"f":40},{"t":1310721,"n":"RemotingApisDiagId","d":5234444,"h":94494514956,"f":40},{"t":1310721,"n":"BinaryFormatterMessage","d":5234444,"h":98789482252,"f":40},{"t":1310721,"n":"BinaryFormatterDiagId","d":5234444,"h":103084449548,"f":40},{"t":1310721,"n":"CodeBaseMessage","d":5234444,"h":107379416844,"f":40},{"t":1310721,"n":"CodeBaseDiagId","d":5234444,"h":111674384140,"f":40},{"t":1310721,"n":"EscapeUriStringMessage","d":5234444,"h":115969351436,"f":40},{"t":1310721,"n":"EscapeUriStringDiagId","d":5234444,"h":120264318732,"f":40},{"t":1310721,"n":"WebRequestMessage","d":5234444,"h":124559286028,"f":40},{"t":1310721,"n":"WebRequestDiagId","d":5234444,"h":128854253324,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeMessage","d":5234444,"h":133149220620,"f":40},{"t":1310721,"n":"DisablePrivateReflectionAttributeDiagId","d":5234444,"h":137444187916,"f":40},{"t":1310721,"n":"GetContextInfoMessage","d":5234444,"h":141739155212,"f":40},{"t":1310721,"n":"GetContextInfoDiagId","d":5234444,"h":146034122508,"f":40},{"t":1310721,"n":"StrongNameKeyPairMessage","d":5234444,"h":150329089804,"f":40},{"t":1310721,"n":"StrongNameKeyPairDiagId","d":5234444,"h":154624057100,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingMessage","d":5234444,"h":158919024396,"f":40},{"t":1310721,"n":"ReflectionOnlyLoadingDiagId","d":5234444,"h":163213991692,"f":40},{"t":1310721,"n":"RuntimeEnvironmentMessage","d":5234444,"h":167508958988,"f":40},{"t":1310721,"n":"RuntimeEnvironmentDiagId","d":5234444,"h":171803926284,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesMessage","d":5234444,"h":176098893580,"f":40},{"t":1310721,"n":"JsonSerializerOptionsIgnoreNullValuesDiagId","d":5234444,"h":180393860876,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesMessage","d":5234444,"h":184688828172,"f":40},{"t":1310721,"n":"DerivedCryptographicTypesDiagId","d":5234444,"h":188983795468,"f":40},{"t":1310721,"n":"RijndaelMessage","d":5234444,"h":193278762764,"f":40},{"t":1310721,"n":"RijndaelDiagId","d":5234444,"h":197573730060,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderMessage","d":5234444,"h":201868697356,"f":40},{"t":1310721,"n":"RNGCryptoServiceProviderDiagId","d":5234444,"h":206163664652,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadMessage","d":5234444,"h":210458631948,"f":40},{"t":1310721,"n":"AppDomainCreateUnloadDiagId","d":5234444,"h":214753599244,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeMessage","d":5234444,"h":219048566540,"f":40},{"t":1310721,"n":"SuppressIldasmAttributeDiagId","d":5234444,"h":223343533836,"f":40},{"t":1310721,"n":"X509CertificateImmutableMessage","d":5234444,"h":227638501132,"f":40},{"t":1310721,"n":"X509CertificateImmutableDiagId","d":5234444,"h":231933468428,"f":40},{"t":1310721,"n":"PublicKeyPropertyMessage","d":5234444,"h":236228435724,"f":40},{"t":1310721,"n":"PublicKeyPropertyDiagId","d":5234444,"h":240523403020,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyMessage","d":5234444,"h":244818370316,"f":40},{"t":1310721,"n":"X509CertificatePrivateKeyDiagId","d":5234444,"h":249113337612,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesMessage","d":5234444,"h":253408304908,"f":40},{"t":1310721,"n":"ProduceLegacyHmacValuesDiagId","d":5234444,"h":257703272204,"f":40},{"t":1310721,"n":"UseManagedSha1Message","d":5234444,"h":261998239500,"f":40},{"t":1310721,"n":"UseManagedSha1DiagId","d":5234444,"h":266293206796,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDMessage","d":5234444,"h":270588174092,"f":40},{"t":1310721,"n":"CryptoConfigEncodeOIDDiagId","d":5234444,"h":274883141388,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryMessage","d":5234444,"h":279178108684,"f":40},{"t":1310721,"n":"CorruptedStateRecoveryDiagId","d":5234444,"h":283473075980,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyMessage","d":5234444,"h":287768043276,"f":40},{"t":1310721,"n":"Rfc2898CryptDeriveKeyDiagId","d":5234444,"h":292063010572,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorMessage","d":5234444,"h":296357977868,"f":40},{"t":1310721,"n":"CmsSignerCspParamsCtorDiagId","d":5234444,"h":300652945164,"f":40},{"t":1310721,"n":"SignerInfoCounterSigMessage","d":5234444,"h":304947912460,"f":40},{"t":1310721,"n":"SignerInfoCounterSigDiagId","d":5234444,"h":309242879756,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyMessage","d":5234444,"h":313537847052,"f":40},{"t":1310721,"n":"RegexCompileToAssemblyDiagId","d":5234444,"h":317832814348,"f":40},{"t":1310721,"n":"AssemblyNameMembersMessage","d":5234444,"h":322127781644,"f":40},{"t":1310721,"n":"AssemblyNameMembersDiagId","d":5234444,"h":326422748940,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryMessage","d":5234444,"h":330717716236,"f":40},{"t":1310721,"n":"SystemDataSerializationFormatBinaryDiagId","d":5234444,"h":335012683532,"f":40},{"t":1310721,"n":"TlsVersion10and11Message","d":5234444,"h":339307650828,"f":40},{"t":1310721,"n":"TlsVersion10and11DiagId","d":5234444,"h":343602618124,"f":40},{"t":1310721,"n":"EncryptionPolicyMessage","d":5234444,"h":347897585420,"f":40},{"t":1310721,"n":"EncryptionPolicyDiagId","d":5234444,"h":352192552716,"f":40},{"t":1310721,"n":"EccXmlExportImportMessage","d":5234444,"h":356487520012,"f":40},{"t":1310721,"n":"EccXmlExportImportDiagId","d":5234444,"h":360782487308,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobMessage","d":5234444,"h":365077454604,"f":40},{"t":1310721,"n":"EcDhPublicKeyBlobDiagId","d":5234444,"h":369372421900,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseMessage","d":5234444,"h":373667389196,"f":40},{"t":1310721,"n":"AssemblyNameCodeBaseDiagId","d":5234444,"h":377962356492,"f":40},{"t":1310721,"n":"CryptoStringFactoryMessage","d":5234444,"h":382257323788,"f":40},{"t":1310721,"n":"CryptoStringFactoryDiagId","d":5234444,"h":386552291084,"f":40},{"t":1310721,"n":"ControlledExecutionRunMessage","d":5234444,"h":390847258380,"f":40},{"t":1310721,"n":"ControlledExecutionRunDiagId","d":5234444,"h":395142225676,"f":40},{"t":1310721,"n":"XmlSecureResolverMessage","d":5234444,"h":399437192972,"f":40},{"t":1310721,"n":"XmlSecureResolverDiagId","d":5234444,"h":403732160268,"f":40},{"t":1310721,"n":"RsaEncryptDecryptValueMessage","d":5234444,"h":408027127564,"f":40},{"t":1310721,"n":"RsaEncryptDecryptDiagId","d":5234444,"h":412322094860,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextMessage","d":5234444,"h":416617062156,"f":40},{"t":1310721,"n":"JsonSerializerOptionsAddContextDiagId","d":5234444,"h":420912029452,"f":40},{"t":1310721,"n":"LegacyFormatterMessage","d":5234444,"h":425206996748,"f":40},{"t":1310721,"n":"LegacyFormatterDiagId","d":5234444,"h":429501964044,"f":40},{"t":1310721,"n":"LegacyFormatterImplMessage","d":5234444,"h":433796931340,"f":40},{"t":1310721,"n":"LegacyFormatterImplDiagId","d":5234444,"h":438091898636,"f":40},{"t":1310721,"n":"RegexExtensibilityImplMessage","d":5234444,"h":442386865932,"f":40},{"t":1310721,"n":"RegexExtensibilityDiagId","d":5234444,"h":446681833228,"f":40},{"t":1310721,"n":"AesGcmTagConstructorMessage","d":5234444,"h":450976800524,"f":40},{"t":1310721,"n":"AesGcmTagConstructorDiagId","d":5234444,"h":455271767820,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteMessage","d":5234444,"h":459566735116,"f":40},{"t":1310721,"n":"ThreadVolatileReadWriteDiagId","d":5234444,"h":463861702412,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationMessage","d":5234444,"h":468156669708,"f":40},{"t":1310721,"n":"ArmIntrinsicPerformsUnsignedOperationDiagId","d":5234444,"h":472451637004,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmMessage","d":5234444,"h":476746604300,"f":40},{"t":1310721,"n":"LoadFromHashAlgorithmDiagId","d":5234444,"h":481041571596,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteMessage","d":5234444,"h":485336538892,"f":40},{"t":1310721,"n":"X509CtorCertDataObsoleteDiagId","d":5234444,"h":489631506188,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsMessage","d":5234444,"h":493926473484,"f":40},{"t":1310721,"n":"TlsCipherAlgorithmEnumsDiagId","d":5234444,"h":498221440780,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownMessage","d":5234444,"h":502516408076,"f":40},{"t":1310721,"n":"SystemEventsEventsThreadShutdownDiagId","d":5234444,"h":506811375372,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorMessage","d":5234444,"h":511106342668,"f":40},{"t":1310721,"n":"Rfc2898DeriveBytesCtorDiagId","d":5234444,"h":515401309964,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteMessage","d":5234444,"h":519696277260,"f":40},{"t":1310721,"n":"QueryableMinByMaxByTSourceObsoleteDiagId","d":5234444,"h":523991244556,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptMessage","d":5234444,"h":528286211852,"f":40},{"t":1310721,"n":"XsltSettingsEnableScriptDiagId","d":5234444,"h":532581179148,"f":40}],"h":5234444}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Obsoletions`; }
        });
        
        $asm.$cls("$snp.System.Net.SocketAddressPal", ($self) => class SocketAddressPal
        {
            /*int*/ static IPv4AddressSize = 0;
            /*int*/ static IPv6AddressSize = 0;
            /*int*/ static UdsAddressSize = 0;
            /*int*/ static MaxAddressSize = 0;
            /*Static constructor*/ static $cctor()
            {
                /*int*/ let ipv4 = 0;
                /*int*/ let ipv6 = 0;
                /*int*/ let uds = 0;
                /*int*/ let max = 0;
                /*Interop.Error*/ let err = $.$snp.Interop.Sys.GetSocketAddressSizes($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Int32, () => ipv4, ($v) => ipv4 = $v, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Int32, () => ipv6, ($v) => ipv6 = $v, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Int32, () => uds, ($v) => uds = $v, null), $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Int32, () => max, ($v) => max = $v, null));
                $.$spc.System.Diagnostics.Debug.Assert$2(err === 0/*Interop.Error.SUCCESS*/, `Unexpected err: ${err}`);
                $.$spc.System.Diagnostics.Debug.Assert$1(ipv4 > 0, "ipv4 > 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(ipv6 > 0, "ipv6 > 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(uds > 0, "uds > 0");
                $.$spc.System.Diagnostics.Debug.Assert$1(max >= ipv4 && max >= ipv6 && max >= uds, "max >= ipv4 && max >= ipv6 && max >= uds");
                $.$snp.System.Net.SocketAddressPal.IPv4AddressSize = ipv4;
                $.$snp.System.Net.SocketAddressPal.IPv6AddressSize = ipv6;
                $.$snp.System.Net.SocketAddressPal.UdsAddressSize = uds;
                $.$snp.System.Net.SocketAddressPal.MaxAddressSize = max;
            }
            static /*void */ ThrowOnFailure(/*Interop.Error*/ err)
            {
                switch(err)
                {
                    case 0/*Interop.Error.SUCCESS*/:
                    return;
                    case 65557/*Interop.Error.EFAULT*/:
                    throw new $.$spc.System.IndexOutOfRangeException().$ctor$9();
                    case 65541/*Interop.Error.EAFNOSUPPORT*/:
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                    default:
                    $.$spc.System.Diagnostics.Debug.Fail("Unexpected failure in GetAddressFamily");
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
            }
            static /*AddressFamily */ GetAddressFamily(/*ReadOnlySpan<byte>*/ buffer)
            {
                /*AddressFamily*/ let family;
                /*Interop.Error*/ let err;
                /*fixed*/ 
                {
                    /*byte**/ let rawAddress = buffer.GetPinnableReference();
                    err = $.$snp.Interop.Sys.GetAddressFamily(rawAddress, buffer.Length, $.$cast($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$snp.System.Net.Sockets.AddressFamily, () => family, ($v) => family = $v, null), $.$typePointer($.$spc.System.Int32)));
                }
                $.$snp.System.Net.SocketAddressPal.ThrowOnFailure(err);
                return family;
            }
            static /*void */ SetAddressFamily(/*Span<byte>*/ buffer, /*AddressFamily*/ family)
            {
                /*Interop.Error*/ let err;
                if (family !== -1/*AddressFamily.Unknown*/)
                {
                    /*fixed*/ 
                    {
                        /*byte**/ let rawAddress = buffer.GetPinnableReference();
                        err = $.$snp.Interop.Sys.SetAddressFamily(rawAddress, buffer.Length, family);
                    }
                    $.$snp.System.Net.SocketAddressPal.ThrowOnFailure(err);
                }
            }
            static /*ushort */ GetPort(/*ReadOnlySpan<byte>*/ buffer)
            {
                /*ushort*/ let port;
                /*Interop.Error*/ let err;
                /*fixed*/ 
                {
                    /*byte**/ let rawAddress = buffer.GetPinnableReference();
                    err = $.$snp.Interop.Sys.GetPort(rawAddress, buffer.Length, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.UInt16, () => port, ($v) => port = $v, null));
                }
                $.$snp.System.Net.SocketAddressPal.ThrowOnFailure(err);
                return port;
            }
            static /*void */ SetPort(/*Span<byte>*/ buffer, /*ushort*/ port)
            {
                /*Interop.Error*/ let err;
                /*fixed*/ 
                {
                    /*byte**/ let rawAddress = buffer.GetPinnableReference();
                    err = $.$snp.Interop.Sys.SetPort(rawAddress, buffer.Length, port);
                }
                $.$snp.System.Net.SocketAddressPal.ThrowOnFailure(err);
            }
            static /*uint */ GetIPv4Address(/*ReadOnlySpan<byte>*/ buffer)
            {
                /*uint*/ let ipAddress;
                /*Interop.Error*/ let err;
                /*fixed*/ 
                {
                    /*byte**/ let rawAddress = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, buffer);
                    err = $.$snp.Interop.Sys.GetIPv4Address(rawAddress, buffer.Length, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.UInt32, () => ipAddress, ($v) => ipAddress = $v, null));
                }
                $.$snp.System.Net.SocketAddressPal.ThrowOnFailure(err);
                return ipAddress;
            }
            static /*void */ GetIPv6Address(/*ReadOnlySpan<byte>*/ buffer, /*Span<byte>*/ address, /*out uint*/ scope)
            {
                /*uint*/ let localScope;
                /*Interop.Error*/ let err;
                /*fixed*/ 
                {
                    /*byte**/ let rawAddress = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference$1($.$spc.System.Byte, buffer);
                    /*fixed*/ 
                    {
                        /*byte**/ let ipAddress = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Byte, address);
                        err = $.$snp.Interop.Sys.GetIPv6Address(rawAddress, buffer.Length, ipAddress, address.Length, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.UInt32, () => localScope, ($v) => localScope = $v, null));
                    }
                }
                $.$snp.System.Net.SocketAddressPal.ThrowOnFailure(err);
                scope.$v = localScope;
            }
            static /*void */ SetIPv4Address(/*Span<byte>*/ buffer, /*uint*/ address)
            {
                /*Interop.Error*/ let err;
                /*fixed*/ 
                {
                    /*byte**/ let rawAddress = buffer.GetPinnableReference();
                    err = $.$snp.Interop.Sys.SetIPv4Address(rawAddress, buffer.Length, address);
                }
                $.$snp.System.Net.SocketAddressPal.ThrowOnFailure(err);
            }
            static /*void */ SetIPv4Address$1(/*Span<byte>*/ buffer, /*byte**/ address)
            {
                /*uint*/ let addr = ($.$spc.System.Runtime.InteropServices.Marshal.ReadInt32$2($.$cast(address, $.$spc.System.IntPtr)) >>> 0);
                $.$snp.System.Net.SocketAddressPal.SetIPv4Address(buffer, addr);
            }
            static /*void */ SetIPv6Address(/*Span<byte>*/ buffer, /*Span<byte>*/ address, /*uint*/ scope)
            {
                /*fixed*/ 
                {
                    /*byte**/ let rawInput = $.$spc.System.Runtime.InteropServices.MemoryMarshal.GetReference($.$spc.System.Byte, address);
                    $.$snp.System.Net.SocketAddressPal.SetIPv6Address$1(buffer, rawInput, address.Length, scope);
                }
            }
            static /*void */ SetIPv6Address$1(/*Span<byte>*/ buffer, /*byte**/ address, /*int*/ addressLength, /*uint*/ scope)
            {
                /*Interop.Error*/ let err;
                /*fixed*/ 
                {
                    /*byte**/ let rawAddress = buffer.GetPinnableReference();
                    err = $.$snp.Interop.Sys.SetIPv6Address(rawAddress, buffer.Length, address, addressLength, scope);
                }
                $.$snp.System.Net.SocketAddressPal.ThrowOnFailure(err);
            }
            static /*void */ Clear(/*Span<byte>*/ buffer)
            {
                /*AddressFamily*/ let family = $.$snp.System.Net.SocketAddressPal.GetAddressFamily($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(buffer));
                buffer.Clear();
                buffer.get_Item(0).$v = $.$cast($.$spc.System.Math.Min$4(buffer.Length, 255), $.$spc.System.Byte);
                $.$snp.System.Net.SocketAddressPal.SetAddressFamily(buffer, family);
            }
            static $h = 4448012;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":65537,"p":[{"n":"err","p":253708}],"n":"ThrowOnFailure","d":4448012,"h":25774251788,"f":34},{"r":4513548,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"GetAddressFamily","d":4448012,"h":30069219084,"f":33},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"family","p":4513548}],"n":"SetAddressFamily","d":4448012,"h":34364186380,"f":33},{"r":589825,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"GetPort","d":4448012,"h":38659153676,"f":33},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"port","p":589825}],"n":"SetPort","d":4448012,"h":42954120972,"f":33},{"r":720897,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"GetIPv4Address","d":4448012,"h":47249088268,"f":33},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"address","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"scope","p":720897,"f":2}],"n":"GetIPv6Address","d":4448012,"h":51544055564,"f":33},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"address","p":720897}],"n":"SetIPv4Address","d":4448012,"h":55839022860,"f":33},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"address","p":0}],"n":"SetIPv4Address","o":"@$1","d":4448012,"h":60133990156,"f":33},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"address","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"scope","p":720897}],"n":"SetIPv6Address","d":4448012,"h":64428957452,"f":33},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"address","p":0},{"n":"addressLength","p":655361},{"n":"scope","p":720897}],"n":"SetIPv6Address","o":"@$1","d":4448012,"h":68723924748,"f":33},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Clear","d":4448012,"h":73018892044,"f":33}],"l":[{"t":655361,"n":"IPv4AddressSize","d":4448012,"h":4299415308,"f":33},{"t":655361,"n":"IPv6AddressSize","d":4448012,"h":8594382604,"f":33},{"t":655361,"n":"UdsAddressSize","d":4448012,"h":12889349900,"f":33},{"t":655361,"n":"MaxAddressSize","d":4448012,"h":17184317196,"f":33}],"h":4448012}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.SocketAddressPal`; }
        });
        
        $asm.$cls("$snp.System.Net.HttpKnownHeaderNames", ($self) => class HttpKnownHeaderNames
        {
            /*string*/ static Accept = null;
            /*string*/ static AcceptCharset = null;
            /*string*/ static AcceptEncoding = null;
            /*string*/ static AcceptLanguage = null;
            /*string*/ static AcceptPatch = null;
            /*string*/ static AcceptRanges = null;
            /*string*/ static AccessControlAllowCredentials = null;
            /*string*/ static AccessControlAllowHeaders = null;
            /*string*/ static AccessControlAllowMethods = null;
            /*string*/ static AccessControlAllowOrigin = null;
            /*string*/ static AccessControlExposeHeaders = null;
            /*string*/ static AccessControlMaxAge = null;
            /*string*/ static Age = null;
            /*string*/ static Allow = null;
            /*string*/ static AltSvc = null;
            /*string*/ static Authorization = null;
            /*string*/ static CacheControl = null;
            /*string*/ static Connection = null;
            /*string*/ static ContentDisposition = null;
            /*string*/ static ContentEncoding = null;
            /*string*/ static ContentLanguage = null;
            /*string*/ static ContentLength = null;
            /*string*/ static ContentLocation = null;
            /*string*/ static ContentMD5 = null;
            /*string*/ static ContentRange = null;
            /*string*/ static ContentSecurityPolicy = null;
            /*string*/ static ContentType = null;
            /*string*/ static Cookie = null;
            /*string*/ static Cookie2 = null;
            /*string*/ static Date = null;
            /*string*/ static ETag = null;
            /*string*/ static Expect = null;
            /*string*/ static Expires = null;
            /*string*/ static From = null;
            /*string*/ static Host = null;
            /*string*/ static IfMatch = null;
            /*string*/ static IfModifiedSince = null;
            /*string*/ static IfNoneMatch = null;
            /*string*/ static IfRange = null;
            /*string*/ static IfUnmodifiedSince = null;
            /*string*/ static KeepAlive = null;
            /*string*/ static LastModified = null;
            /*string*/ static Link = null;
            /*string*/ static Location = null;
            /*string*/ static MaxForwards = null;
            /*string*/ static Origin = null;
            /*string*/ static P3P = null;
            /*string*/ static Pragma = null;
            /*string*/ static ProxyAuthenticate = null;
            /*string*/ static ProxyAuthorization = null;
            /*string*/ static ProxyConnection = null;
            /*string*/ static PublicKeyPins = null;
            /*string*/ static Range = null;
            /*string*/ static Referer = null;
            /*string*/ static RetryAfter = null;
            /*string*/ static SecWebSocketAccept = null;
            /*string*/ static SecWebSocketExtensions = null;
            /*string*/ static SecWebSocketKey = null;
            /*string*/ static SecWebSocketProtocol = null;
            /*string*/ static SecWebSocketVersion = null;
            /*string*/ static Server = null;
            /*string*/ static SetCookie = null;
            /*string*/ static SetCookie2 = null;
            /*string*/ static StrictTransportSecurity = null;
            /*string*/ static TE = null;
            /*string*/ static TSV = null;
            /*string*/ static Trailer = null;
            /*string*/ static TransferEncoding = null;
            /*string*/ static Upgrade = null;
            /*string*/ static UpgradeInsecureRequests = null;
            /*string*/ static UserAgent = null;
            /*string*/ static Vary = null;
            /*string*/ static Via = null;
            /*string*/ static WWWAuthenticate = null;
            /*string*/ static Warning = null;
            /*string*/ static XAspNetVersion = null;
            /*string*/ static XContentDuration = null;
            /*string*/ static XContentTypeOptions = null;
            /*string*/ static XFrameOptions = null;
            /*string*/ static XMSEdgeRef = null;
            /*string*/ static XPoweredBy = null;
            /*string*/ static XRequestID = null;
            /*string*/ static XUACompatible = null;
            //Static Initializer
            static $sinit()
            {
                {
                    this.Accept = "Accept";
                }
                {
                    this.AcceptCharset = "Accept-Charset";
                }
                {
                    this.AcceptEncoding = "Accept-Encoding";
                }
                {
                    this.AcceptLanguage = "Accept-Language";
                }
                {
                    this.AcceptPatch = "Accept-Patch";
                }
                {
                    this.AcceptRanges = "Accept-Ranges";
                }
                {
                    this.AccessControlAllowCredentials = "Access-Control-Allow-Credentials";
                }
                {
                    this.AccessControlAllowHeaders = "Access-Control-Allow-Headers";
                }
                {
                    this.AccessControlAllowMethods = "Access-Control-Allow-Methods";
                }
                {
                    this.AccessControlAllowOrigin = "Access-Control-Allow-Origin";
                }
                {
                    this.AccessControlExposeHeaders = "Access-Control-Expose-Headers";
                }
                {
                    this.AccessControlMaxAge = "Access-Control-Max-Age";
                }
                {
                    this.Age = "Age";
                }
                {
                    this.Allow = "Allow";
                }
                {
                    this.AltSvc = "Alt-Svc";
                }
                {
                    this.Authorization = "Authorization";
                }
                {
                    this.CacheControl = "Cache-Control";
                }
                {
                    this.Connection = "Connection";
                }
                {
                    this.ContentDisposition = "Content-Disposition";
                }
                {
                    this.ContentEncoding = "Content-Encoding";
                }
                {
                    this.ContentLanguage = "Content-Language";
                }
                {
                    this.ContentLength = "Content-Length";
                }
                {
                    this.ContentLocation = "Content-Location";
                }
                {
                    this.ContentMD5 = "Content-MD5";
                }
                {
                    this.ContentRange = "Content-Range";
                }
                {
                    this.ContentSecurityPolicy = "Content-Security-Policy";
                }
                {
                    this.ContentType = "Content-Type";
                }
                {
                    this.Cookie = "Cookie";
                }
                {
                    this.Cookie2 = "Cookie2";
                }
                {
                    this.Date = "Date";
                }
                {
                    this.ETag = "ETag";
                }
                {
                    this.Expect = "Expect";
                }
                {
                    this.Expires = "Expires";
                }
                {
                    this.From = "From";
                }
                {
                    this.Host = "Host";
                }
                {
                    this.IfMatch = "If-Match";
                }
                {
                    this.IfModifiedSince = "If-Modified-Since";
                }
                {
                    this.IfNoneMatch = "If-None-Match";
                }
                {
                    this.IfRange = "If-Range";
                }
                {
                    this.IfUnmodifiedSince = "If-Unmodified-Since";
                }
                {
                    this.KeepAlive = "Keep-Alive";
                }
                {
                    this.LastModified = "Last-Modified";
                }
                {
                    this.Link = "Link";
                }
                {
                    this.Location = "Location";
                }
                {
                    this.MaxForwards = "Max-Forwards";
                }
                {
                    this.Origin = "Origin";
                }
                {
                    this.P3P = "P3P";
                }
                {
                    this.Pragma = "Pragma";
                }
                {
                    this.ProxyAuthenticate = "Proxy-Authenticate";
                }
                {
                    this.ProxyAuthorization = "Proxy-Authorization";
                }
                {
                    this.ProxyConnection = "Proxy-Connection";
                }
                {
                    this.PublicKeyPins = "Public-Key-Pins";
                }
                {
                    this.Range = "Range";
                }
                {
                    this.Referer = "Referer";
                }
                {
                    this.RetryAfter = "Retry-After";
                }
                {
                    this.SecWebSocketAccept = "Sec-WebSocket-Accept";
                }
                {
                    this.SecWebSocketExtensions = "Sec-WebSocket-Extensions";
                }
                {
                    this.SecWebSocketKey = "Sec-WebSocket-Key";
                }
                {
                    this.SecWebSocketProtocol = "Sec-WebSocket-Protocol";
                }
                {
                    this.SecWebSocketVersion = "Sec-WebSocket-Version";
                }
                {
                    this.Server = "Server";
                }
                {
                    this.SetCookie = "Set-Cookie";
                }
                {
                    this.SetCookie2 = "Set-Cookie2";
                }
                {
                    this.StrictTransportSecurity = "Strict-Transport-Security";
                }
                {
                    this.TE = "TE";
                }
                {
                    this.TSV = "TSV";
                }
                {
                    this.Trailer = "Trailer";
                }
                {
                    this.TransferEncoding = "Transfer-Encoding";
                }
                {
                    this.Upgrade = "Upgrade";
                }
                {
                    this.UpgradeInsecureRequests = "Upgrade-Insecure-Requests";
                }
                {
                    this.UserAgent = "User-Agent";
                }
                {
                    this.Vary = "Vary";
                }
                {
                    this.Via = "Via";
                }
                {
                    this.WWWAuthenticate = "WWW-Authenticate";
                }
                {
                    this.Warning = "Warning";
                }
                {
                    this.XAspNetVersion = "X-AspNet-Version";
                }
                {
                    this.XContentDuration = "X-Content-Duration";
                }
                {
                    this.XContentTypeOptions = "X-Content-Type-Options";
                }
                {
                    this.XFrameOptions = "X-Frame-Options";
                }
                {
                    this.XMSEdgeRef = "X-MSEdge-Ref";
                }
                {
                    this.XPoweredBy = "X-Powered-By";
                }
                {
                    this.XRequestID = "X-Request-ID";
                }
                {
                    this.XUACompatible = "X-UA-Compatible";
                }
            }
            static $h = 2744076;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":1310721,"n":"Accept","d":2744076,"h":4297711372,"f":33},{"t":1310721,"n":"AcceptCharset","d":2744076,"h":8592678668,"f":33},{"t":1310721,"n":"AcceptEncoding","d":2744076,"h":12887645964,"f":33},{"t":1310721,"n":"AcceptLanguage","d":2744076,"h":17182613260,"f":33},{"t":1310721,"n":"AcceptPatch","d":2744076,"h":21477580556,"f":33},{"t":1310721,"n":"AcceptRanges","d":2744076,"h":25772547852,"f":33},{"t":1310721,"n":"AccessControlAllowCredentials","d":2744076,"h":30067515148,"f":33},{"t":1310721,"n":"AccessControlAllowHeaders","d":2744076,"h":34362482444,"f":33},{"t":1310721,"n":"AccessControlAllowMethods","d":2744076,"h":38657449740,"f":33},{"t":1310721,"n":"AccessControlAllowOrigin","d":2744076,"h":42952417036,"f":33},{"t":1310721,"n":"AccessControlExposeHeaders","d":2744076,"h":47247384332,"f":33},{"t":1310721,"n":"AccessControlMaxAge","d":2744076,"h":51542351628,"f":33},{"t":1310721,"n":"Age","d":2744076,"h":55837318924,"f":33},{"t":1310721,"n":"Allow","d":2744076,"h":60132286220,"f":33},{"t":1310721,"n":"AltSvc","d":2744076,"h":64427253516,"f":33},{"t":1310721,"n":"Authorization","d":2744076,"h":68722220812,"f":33},{"t":1310721,"n":"CacheControl","d":2744076,"h":73017188108,"f":33},{"t":1310721,"n":"Connection","d":2744076,"h":77312155404,"f":33},{"t":1310721,"n":"ContentDisposition","d":2744076,"h":81607122700,"f":33},{"t":1310721,"n":"ContentEncoding","d":2744076,"h":85902089996,"f":33},{"t":1310721,"n":"ContentLanguage","d":2744076,"h":90197057292,"f":33},{"t":1310721,"n":"ContentLength","d":2744076,"h":94492024588,"f":33},{"t":1310721,"n":"ContentLocation","d":2744076,"h":98786991884,"f":33},{"t":1310721,"n":"ContentMD5","d":2744076,"h":103081959180,"f":33},{"t":1310721,"n":"ContentRange","d":2744076,"h":107376926476,"f":33},{"t":1310721,"n":"ContentSecurityPolicy","d":2744076,"h":111671893772,"f":33},{"t":1310721,"n":"ContentType","d":2744076,"h":115966861068,"f":33},{"t":1310721,"n":"Cookie","d":2744076,"h":120261828364,"f":33},{"t":1310721,"n":"Cookie2","d":2744076,"h":124556795660,"f":33},{"t":1310721,"n":"Date","d":2744076,"h":128851762956,"f":33},{"t":1310721,"n":"ETag","d":2744076,"h":133146730252,"f":33},{"t":1310721,"n":"Expect","d":2744076,"h":137441697548,"f":33},{"t":1310721,"n":"Expires","d":2744076,"h":141736664844,"f":33},{"t":1310721,"n":"From","d":2744076,"h":146031632140,"f":33},{"t":1310721,"n":"Host","d":2744076,"h":150326599436,"f":33},{"t":1310721,"n":"IfMatch","d":2744076,"h":154621566732,"f":33},{"t":1310721,"n":"IfModifiedSince","d":2744076,"h":158916534028,"f":33},{"t":1310721,"n":"IfNoneMatch","d":2744076,"h":163211501324,"f":33},{"t":1310721,"n":"IfRange","d":2744076,"h":167506468620,"f":33},{"t":1310721,"n":"IfUnmodifiedSince","d":2744076,"h":171801435916,"f":33},{"t":1310721,"n":"KeepAlive","d":2744076,"h":176096403212,"f":33},{"t":1310721,"n":"LastModified","d":2744076,"h":180391370508,"f":33},{"t":1310721,"n":"Link","d":2744076,"h":184686337804,"f":33},{"t":1310721,"n":"Location","d":2744076,"h":188981305100,"f":33},{"t":1310721,"n":"MaxForwards","d":2744076,"h":193276272396,"f":33},{"t":1310721,"n":"Origin","d":2744076,"h":197571239692,"f":33},{"t":1310721,"n":"P3P","d":2744076,"h":201866206988,"f":33},{"t":1310721,"n":"Pragma","d":2744076,"h":206161174284,"f":33},{"t":1310721,"n":"ProxyAuthenticate","d":2744076,"h":210456141580,"f":33},{"t":1310721,"n":"ProxyAuthorization","d":2744076,"h":214751108876,"f":33},{"t":1310721,"n":"ProxyConnection","d":2744076,"h":219046076172,"f":33},{"t":1310721,"n":"PublicKeyPins","d":2744076,"h":223341043468,"f":33},{"t":1310721,"n":"Range","d":2744076,"h":227636010764,"f":33},{"t":1310721,"n":"Referer","d":2744076,"h":231930978060,"f":33},{"t":1310721,"n":"RetryAfter","d":2744076,"h":236225945356,"f":33},{"t":1310721,"n":"SecWebSocketAccept","d":2744076,"h":240520912652,"f":33},{"t":1310721,"n":"SecWebSocketExtensions","d":2744076,"h":244815879948,"f":33},{"t":1310721,"n":"SecWebSocketKey","d":2744076,"h":249110847244,"f":33},{"t":1310721,"n":"SecWebSocketProtocol","d":2744076,"h":253405814540,"f":33},{"t":1310721,"n":"SecWebSocketVersion","d":2744076,"h":257700781836,"f":33},{"t":1310721,"n":"Server","d":2744076,"h":261995749132,"f":33},{"t":1310721,"n":"SetCookie","d":2744076,"h":266290716428,"f":33},{"t":1310721,"n":"SetCookie2","d":2744076,"h":270585683724,"f":33},{"t":1310721,"n":"StrictTransportSecurity","d":2744076,"h":274880651020,"f":33},{"t":1310721,"n":"TE","d":2744076,"h":279175618316,"f":33},{"t":1310721,"n":"TSV","d":2744076,"h":283470585612,"f":33},{"t":1310721,"n":"Trailer","d":2744076,"h":287765552908,"f":33},{"t":1310721,"n":"TransferEncoding","d":2744076,"h":292060520204,"f":33},{"t":1310721,"n":"Upgrade","d":2744076,"h":296355487500,"f":33},{"t":1310721,"n":"UpgradeInsecureRequests","d":2744076,"h":300650454796,"f":33},{"t":1310721,"n":"UserAgent","d":2744076,"h":304945422092,"f":33},{"t":1310721,"n":"Vary","d":2744076,"h":309240389388,"f":33},{"t":1310721,"n":"Via","d":2744076,"h":313535356684,"f":33},{"t":1310721,"n":"WWWAuthenticate","d":2744076,"h":317830323980,"f":33},{"t":1310721,"n":"Warning","d":2744076,"h":322125291276,"f":33},{"t":1310721,"n":"XAspNetVersion","d":2744076,"h":326420258572,"f":33},{"t":1310721,"n":"XContentDuration","d":2744076,"h":330715225868,"f":33},{"t":1310721,"n":"XContentTypeOptions","d":2744076,"h":335010193164,"f":33},{"t":1310721,"n":"XFrameOptions","d":2744076,"h":339305160460,"f":33},{"t":1310721,"n":"XMSEdgeRef","d":2744076,"h":343600127756,"f":33},{"t":1310721,"n":"XPoweredBy","d":2744076,"h":347895095052,"f":33},{"t":1310721,"n":"XRequestID","d":2744076,"h":352190062348,"f":33},{"t":1310721,"n":"XUACompatible","d":2744076,"h":356485029644,"f":33}],"h":2744076}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.HttpKnownHeaderNames`; }
        });
        
        $asm.$cls("$snp.InteropErrorExtensions", ($self) => class InteropErrorExtensions
        {
            static /*Interop.ErrorInfo */ Info(/*this Interop.Error*/ error)
            {
                return new $.$snp.Interop.ErrorInfo().$ctor$3(error);
            }
            static $h = 712460;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":319244,"p":[{"n":"error","p":253708}],"n":"Info","d":712460,"h":4295679756,"f":33}],"h":712460}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `InteropErrorExtensions`; }
        });
        
        $asm.$cls("$snp.System.Net.NetworkInformation.HostInformationPal", ($self) => class HostInformationPal
        {
            static /*string */ GetHostName()
            {
                return $.$spc.System.Environment.MachineName;
            }
            static /*string */ GetDomainName()
            {
                return $.$spc.System.Environment.UserDomainName;
            }
            static $h = 3923724;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1310721,"n":"GetHostName","d":3923724,"h":4298891020,"f":33},{"r":1310721,"n":"GetDomainName","d":3923724,"h":8593858316,"f":33}],"h":3923724}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.HostInformationPal`; }
        });
        
        $asm.$cls("$snp.System.Net.NetworkInformation.InterfaceInfoPal", ($self) => class InterfaceInfoPal
        {
            static /*uint */ InterfaceNameToIndex(TChar, /*ReadOnlySpan<TChar>*/ _)
            {
                return 0;
            }
            static $h = 3989260;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":720897,"p":[{"n":"_","p":(TChar) => $.$spc.System.ReadOnlySpan$$(TChar).$h}],"g":["TChar"],"n":"InterfaceNameToIndex","d":3989260,"h":4298956556,"f":131105}],"h":3989260}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.NetworkInformation.InterfaceInfoPal`; }
        });
        
        $asm.$cls("$snp.System.Net.PathList", ($self) => class PathList extends $.$spc.System.Object
        {
            /*SortedList*/ m_list = null;
            /*int */ get Count()
            {
                return this.m_list.Count;
            }
            /*int */ GetCookiesCount()
            {
                /*int*/ let count = 0;
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncRoot)
                    {
                        /*IList*/ let list = this.m_list.GetValueList();
                        /*int*/ let listCount = list.System$Collections$ICollection$Count;
                        for(/*int*/ let i = 0; i < listCount; i++)
                        {
                            count += ($.$cast(list.System$Collections$IList$get_Item(i), $.$snp.System.Net.CookieCollection)).Count;
                        }
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncRoot)
                }
                return count;
            }
            /*ICollection */ get Values()
            {
                return this.m_list.Values;
            }
            /*object?*/ get_Item(/*string*/ s)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncRoot)
                    {
                        return this.m_list.get_Item(s);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncRoot)
                }
            }
            /*void*/ set_Item(/*string*/ s, /*object?*/ value)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncRoot)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(value !== null, "value != null");
                        this.m_list.set_Item(s, value);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncRoot)
                }
            }
            /*IDictionaryEnumerator */ GetEnumerator()
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncRoot)
                    {
                        return this.m_list.GetEnumerator();
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncRoot)
                }
            }
            /*void */ Remove(/*object*/ key)
            {
                //lock
                try
                {
                    $.$spc.System.Threading.Monitor.Enter(this.SyncRoot)
                    {
                        this.m_list.Remove(key);
                    }
                }
                finally
                {
                    $.$spc.System.Threading.Monitor.Exit(this.SyncRoot)
                }
            }
            /*SortedList */ get List()
            {
                return this.m_list;
            }
            /*object */ get SyncRoot()
            {
                return this.m_list.SyncRoot;
            }
            static $_PathListComparer;
            static get PathListComparer()
            {
                let $cls = $.$snp.System.Net.PathList;
                return $cls.$_PathListComparer ??= $asm.$ncls("$snp.System.Net.PathList.PathListComparer", ($self) => class PathListComparer extends $.$spc.System.Object
                {
                    /*PathListComparer*/ static StaticInstance = null;
                    /*int */ System$Collections$IComparer$Compare(/*object?*/ ol, /*object?*/ or)
                    {
                        /*string*/ let pathLeft = $.$snp.System.Net.CookieParser.CheckQuoted($.$cast(ol, $.$spc.System.String));
                        /*string*/ let pathRight = $.$snp.System.Net.CookieParser.CheckQuoted($.$cast(or, $.$spc.System.String));
                        /*int*/ let ll = pathLeft.length;
                        /*int*/ let lr = pathRight.length;
                        /*int*/ let length = $.$spc.System.Math.Min$4(ll, lr);
                        for(/*int*/ let i = 0; i < length; ++i)
                        {
                            if ($.$spc.System.String.get_Chars.call(pathLeft, i) !== $.$spc.System.String.get_Chars.call(pathRight, i))
                            {
                                return $.$spc.System.String.get_Chars.call(pathLeft, i) - $.$spc.System.String.get_Chars.call(pathRight, i);
                            }
                        }
                        return ((lr - ll) | 0);
                    }
                    //default reference type constructor overload
                    $ctor$1()
                    {
                        super.$ctor();
                        return this;
                    }
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            this.StaticInstance = new $.$snp.System.Net.PathList.PathListComparer().$ctor$1();
                        }
                    }
                    static $h = 4185868;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":4185868,"n":"StaticInstance","d":4185868,"h":4299153164,"f":40}],"c":[{"n":".ctor","o":"$ctor$1","d":4185868,"h":12889087756,"f":1}],"i":[31391745],"d":4120332,"h":4185868,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IComparer ]; }
                    static get $fullName() { return `System.Net.PathList.PathListComparer`; }
                }, $cls, ($v) => $cls.$_PathListComparer = $v);
            }
            //default reference type constructor overload
            $ctor$1()
            {
                super.$ctor();
                return this;
            }
            //default member initializer
            constructor()
            {
                super();
                this.m_list = $.$scn.System.Collections.SortedList.Synchronized(new $.$scn.System.Collections.SortedList().$ctor$3($.$snp.System.Net.PathList.PathListComparer.StaticInstance));
            }
            static $h = 4120332;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12889022220,"f":8},"n":"Count","d":4120332,"h":8594054924,"f":8},{"p":31326209,"g":{"r":0,"d":0,"h":25773924108,"f":8},"n":"Values","d":4120332,"h":21478956812,"f":8},{"p":131073,"i":[{"n":"s","p":1310721}],"g":{"r":0,"d":0,"h":34363858700,"f":8},"s":{"r":0,"d":0,"h":38658825996,"f":8},"n":"Item","o":"@$2","d":4120332,"h":30068891404,"f":8},{"p":655395,"g":{"r":0,"d":0,"h":55838695180,"f":8},"n":"List","d":4120332,"h":51543727884,"f":8},{"p":131073,"g":{"r":0,"d":0,"h":64428629772,"f":8},"n":"SyncRoot","d":4120332,"h":60133662476,"f":8}],"m":[{"r":655361,"n":"GetCookiesCount","d":4120332,"h":17183989516,"f":8},{"r":31522817,"n":"GetEnumerator","d":4120332,"h":42953793292,"f":8},{"r":65537,"p":[{"n":"key","p":131073}],"n":"Remove","d":4120332,"h":47248760588,"f":8}],"l":[{"t":655395,"n":"m_list","d":4120332,"h":4299087628,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":4120332,"h":73018564364,"f":1}],"j":[4185868],"h":4120332,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.PathList`; }
        });
        
        $asm.$cls("$snp.System.Net.Sockets.SocketErrorPal", ($self) => class SocketErrorPal
        {
            /*Static constructor*/ static $cctor()
            {
                $.$spc.System.Diagnostics.Debug.Assert$2($.$snp.System.Net.Sockets.SocketErrorPal.s_nativeErrorToSocketError.Count === 42/*NativeErrorToSocketErrorCount*/, `Expected s_nativeErrorToSocketError to have ${42/*NativeErrorToSocketErrorCount*/} count instead of ${$.$snp.System.Net.Sockets.SocketErrorPal.s_nativeErrorToSocketError.Count}.`);
                $.$spc.System.Diagnostics.Debug.Assert$2($.$snp.System.Net.Sockets.SocketErrorPal.s_socketErrorToNativeError.Count === 41/*SocketErrorToNativeErrorCount*/, `Expected s_socketErrorToNativeError to have ${41/*SocketErrorToNativeErrorCount*/} count instead of ${$.$snp.System.Net.Sockets.SocketErrorPal.s_socketErrorToNativeError.Count}.`);
            }
            /*int*/ static NativeErrorToSocketErrorCount = 42;
            /*int*/ static SocketErrorToNativeErrorCount = 41;
            /*Dictionary<Interop.Error, SocketError>*/ static s_nativeErrorToSocketError = null;
            /*Dictionary<SocketError, Interop.Error>*/ static s_socketErrorToNativeError = null;
            static /*SocketError */ GetSocketErrorForNativeError(/*Interop.Error*/ errno)
            {
                /*SocketError*/ let result;
                return $.$snp.System.Net.Sockets.SocketErrorPal.s_nativeErrorToSocketError.TryGetValue(errno, $.$ref(() => result, ($v) => result = $v, $.$snp.System.Net.Sockets.SocketError)) ? result : -1/*SocketError.SocketError*/;
            }
            static /*Interop.Error */ GetNativeErrorForSocketError(/*SocketError*/ error)
            {
                /*Interop.Error*/ let errno;
                if (!$.$snp.System.Net.Sockets.SocketErrorPal.TryGetNativeErrorForSocketError(error, $.$ref(() => errno, ($v) => errno = $v, $.$snp.Interop.Error)))
                {
                    errno = $.$cast(error, $.$snp.Interop.Error);
                }
                return errno;
            }
            static /*bool */ TryGetNativeErrorForSocketError(/*SocketError*/ error, /*out Interop.Error*/ errno)
            {
                return $.$snp.System.Net.Sockets.SocketErrorPal.s_socketErrorToNativeError.TryGetValue(error, errno);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_nativeErrorToSocketError = (() =>
                    {
                        //new $.$spc.System.Collections.Generic.Dictionary$$$($.$snp.Interop.Error, $.$snp.System.Net.Sockets.SocketError)()
                        const $t1 = $.$spc.System.Collections.Generic.Dictionary$$$($.$snp.Interop.Error, $.$snp.System.Net.Sockets.SocketError);
                        const $i1 = new $t1();
                        $i1.$ctor$2(42/*NativeErrorToSocketErrorCount*/);
                        $i1.Add(65538/*Interop.Error.EACCES*/, 10013/*SocketError.AccessDenied*/);
                        $i1.Add(65539/*Interop.Error.EADDRINUSE*/, 10048/*SocketError.AddressAlreadyInUse*/);
                        $i1.Add(65540/*Interop.Error.EADDRNOTAVAIL*/, 10049/*SocketError.AddressNotAvailable*/);
                        $i1.Add(65541/*Interop.Error.EAFNOSUPPORT*/, 10047/*SocketError.AddressFamilyNotSupported*/);
                        $i1.Add(65542/*Interop.Error.EAGAIN*/, 10035/*SocketError.WouldBlock*/);
                        $i1.Add(65543/*Interop.Error.EALREADY*/, 10037/*SocketError.AlreadyInProgress*/);
                        $i1.Add(65544/*Interop.Error.EBADF*/, 995/*SocketError.OperationAborted*/);
                        $i1.Add(65547/*Interop.Error.ECANCELED*/, 995/*SocketError.OperationAborted*/);
                        $i1.Add(65549/*Interop.Error.ECONNABORTED*/, 10053/*SocketError.ConnectionAborted*/);
                        $i1.Add(65550/*Interop.Error.ECONNREFUSED*/, 10061/*SocketError.ConnectionRefused*/);
                        $i1.Add(65551/*Interop.Error.ECONNRESET*/, 10054/*SocketError.ConnectionReset*/);
                        $i1.Add(65553/*Interop.Error.EDESTADDRREQ*/, 10039/*SocketError.DestinationAddressRequired*/);
                        $i1.Add(65557/*Interop.Error.EFAULT*/, 10014/*SocketError.Fault*/);
                        $i1.Add(65648/*Interop.Error.EHOSTDOWN*/, 10064/*SocketError.HostDown*/);
                        $i1.Add(65599/*Interop.Error.ENXIO*/, 11001/*SocketError.HostNotFound*/);
                        $i1.Add(65559/*Interop.Error.EHOSTUNREACH*/, 10065/*SocketError.HostUnreachable*/);
                        $i1.Add(65562/*Interop.Error.EINPROGRESS*/, 10036/*SocketError.InProgress*/);
                        $i1.Add(65563/*Interop.Error.EINTR*/, 10004/*SocketError.Interrupted*/);
                        $i1.Add(65564/*Interop.Error.EINVAL*/, 10022/*SocketError.InvalidArgument*/);
                        $i1.Add(65566/*Interop.Error.EISCONN*/, 10056/*SocketError.IsConnected*/);
                        $i1.Add(65569/*Interop.Error.EMFILE*/, 10024/*SocketError.TooManyOpenSockets*/);
                        $i1.Add(65571/*Interop.Error.EMSGSIZE*/, 10040/*SocketError.MessageSize*/);
                        $i1.Add(65574/*Interop.Error.ENETDOWN*/, 10050/*SocketError.NetworkDown*/);
                        $i1.Add(65575/*Interop.Error.ENETRESET*/, 10052/*SocketError.NetworkReset*/);
                        $i1.Add(65576/*Interop.Error.ENETUNREACH*/, 10051/*SocketError.NetworkUnreachable*/);
                        $i1.Add(65577/*Interop.Error.ENFILE*/, 10024/*SocketError.TooManyOpenSockets*/);
                        $i1.Add(65578/*Interop.Error.ENOBUFS*/, 10055/*SocketError.NoBufferSpaceAvailable*/);
                        $i1.Add(65649/*Interop.Error.ENODATA*/, 11004/*SocketError.NoData*/);
                        $i1.Add(65581/*Interop.Error.ENOENT*/, 10049/*SocketError.AddressNotAvailable*/);
                        $i1.Add(65587/*Interop.Error.ENOPROTOOPT*/, 10042/*SocketError.ProtocolOption*/);
                        $i1.Add(65592/*Interop.Error.ENOTCONN*/, 10057/*SocketError.NotConnected*/);
                        $i1.Add(65596/*Interop.Error.ENOTSOCK*/, 10038/*SocketError.NotSocket*/);
                        $i1.Add(65597/*Interop.Error.ENOTSUP*/, 10045/*SocketError.OperationNotSupported*/);
                        $i1.Add(65602/*Interop.Error.EPERM*/, 10013/*SocketError.AccessDenied*/);
                        $i1.Add(65603/*Interop.Error.EPIPE*/, 10058/*SocketError.Shutdown*/);
                        $i1.Add(65632/*Interop.Error.EPFNOSUPPORT*/, 10046/*SocketError.ProtocolFamilyNotSupported*/);
                        $i1.Add(65605/*Interop.Error.EPROTONOSUPPORT*/, 10043/*SocketError.ProtocolNotSupported*/);
                        $i1.Add(65606/*Interop.Error.EPROTOTYPE*/, 10041/*SocketError.ProtocolType*/);
                        $i1.Add(65630/*Interop.Error.ESOCKTNOSUPPORT*/, 10044/*SocketError.SocketNotSupported*/);
                        $i1.Add(65644/*Interop.Error.ESHUTDOWN*/, 10101/*SocketError.Disconnecting*/);
                        $i1.Add(0/*Interop.Error.SUCCESS*/, 0/*SocketError.Success*/);
                        $i1.Add(65613/*Interop.Error.ETIMEDOUT*/, 10060/*SocketError.TimedOut*/);
                        return $i1;
                    })();
                }
                {
                    this.s_socketErrorToNativeError = (() =>
                    {
                        //new $.$spc.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.Sockets.SocketError, $.$snp.Interop.Error)()
                        const $t1 = $.$spc.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.Sockets.SocketError, $.$snp.Interop.Error);
                        const $i1 = new $t1();
                        $i1.$ctor$2(41/*SocketErrorToNativeErrorCount*/);
                        $i1.Add(10013/*SocketError.AccessDenied*/, 65538/*Interop.Error.EACCES*/);
                        $i1.Add(10048/*SocketError.AddressAlreadyInUse*/, 65539/*Interop.Error.EADDRINUSE*/);
                        $i1.Add(10049/*SocketError.AddressNotAvailable*/, 65540/*Interop.Error.EADDRNOTAVAIL*/);
                        $i1.Add(10047/*SocketError.AddressFamilyNotSupported*/, 65541/*Interop.Error.EAFNOSUPPORT*/);
                        $i1.Add(10037/*SocketError.AlreadyInProgress*/, 65543/*Interop.Error.EALREADY*/);
                        $i1.Add(10053/*SocketError.ConnectionAborted*/, 65549/*Interop.Error.ECONNABORTED*/);
                        $i1.Add(10061/*SocketError.ConnectionRefused*/, 65550/*Interop.Error.ECONNREFUSED*/);
                        $i1.Add(10054/*SocketError.ConnectionReset*/, 65551/*Interop.Error.ECONNRESET*/);
                        $i1.Add(10039/*SocketError.DestinationAddressRequired*/, 65553/*Interop.Error.EDESTADDRREQ*/);
                        $i1.Add(10101/*SocketError.Disconnecting*/, 65644/*Interop.Error.ESHUTDOWN*/);
                        $i1.Add(10014/*SocketError.Fault*/, 65557/*Interop.Error.EFAULT*/);
                        $i1.Add(10064/*SocketError.HostDown*/, 65648/*Interop.Error.EHOSTDOWN*/);
                        $i1.Add(11001/*SocketError.HostNotFound*/, 131073/*Interop.Error.EHOSTNOTFOUND*/);
                        $i1.Add(10065/*SocketError.HostUnreachable*/, 65559/*Interop.Error.EHOSTUNREACH*/);
                        $i1.Add(10036/*SocketError.InProgress*/, 65562/*Interop.Error.EINPROGRESS*/);
                        $i1.Add(10004/*SocketError.Interrupted*/, 65563/*Interop.Error.EINTR*/);
                        $i1.Add(10022/*SocketError.InvalidArgument*/, 65564/*Interop.Error.EINVAL*/);
                        $i1.Add(997/*SocketError.IOPending*/, 65562/*Interop.Error.EINPROGRESS*/);
                        $i1.Add(10056/*SocketError.IsConnected*/, 65566/*Interop.Error.EISCONN*/);
                        $i1.Add(10040/*SocketError.MessageSize*/, 65571/*Interop.Error.EMSGSIZE*/);
                        $i1.Add(10050/*SocketError.NetworkDown*/, 65574/*Interop.Error.ENETDOWN*/);
                        $i1.Add(10052/*SocketError.NetworkReset*/, 65575/*Interop.Error.ENETRESET*/);
                        $i1.Add(10051/*SocketError.NetworkUnreachable*/, 65576/*Interop.Error.ENETUNREACH*/);
                        $i1.Add(10055/*SocketError.NoBufferSpaceAvailable*/, 65578/*Interop.Error.ENOBUFS*/);
                        $i1.Add(11004/*SocketError.NoData*/, 65649/*Interop.Error.ENODATA*/);
                        $i1.Add(10057/*SocketError.NotConnected*/, 65592/*Interop.Error.ENOTCONN*/);
                        $i1.Add(10038/*SocketError.NotSocket*/, 65596/*Interop.Error.ENOTSOCK*/);
                        $i1.Add(995/*SocketError.OperationAborted*/, 65547/*Interop.Error.ECANCELED*/);
                        $i1.Add(10045/*SocketError.OperationNotSupported*/, 65597/*Interop.Error.ENOTSUP*/);
                        $i1.Add(10046/*SocketError.ProtocolFamilyNotSupported*/, 65632/*Interop.Error.EPFNOSUPPORT*/);
                        $i1.Add(10043/*SocketError.ProtocolNotSupported*/, 65605/*Interop.Error.EPROTONOSUPPORT*/);
                        $i1.Add(10042/*SocketError.ProtocolOption*/, 65587/*Interop.Error.ENOPROTOOPT*/);
                        $i1.Add(10041/*SocketError.ProtocolType*/, 65606/*Interop.Error.EPROTOTYPE*/);
                        $i1.Add(10058/*SocketError.Shutdown*/, 65603/*Interop.Error.EPIPE*/);
                        $i1.Add(10044/*SocketError.SocketNotSupported*/, 65630/*Interop.Error.ESOCKTNOSUPPORT*/);
                        $i1.Add(0/*SocketError.Success*/, 0/*Interop.Error.SUCCESS*/);
                        $i1.Add(10060/*SocketError.TimedOut*/, 65613/*Interop.Error.ETIMEDOUT*/);
                        $i1.Add(10024/*SocketError.TooManyOpenSockets*/, 65577/*Interop.Error.ENFILE*/);
                        $i1.Add(11002/*SocketError.TryAgain*/, 65542/*Interop.Error.EAGAIN*/);
                        $i1.Add(10035/*SocketError.WouldBlock*/, 65542/*Interop.Error.EAGAIN*/);
                        $i1.Add(-1/*SocketError.SocketError*/, 131074/*Interop.Error.ESOCKETERROR*/);
                        return $i1;
                    })();
                }
            }
            static $h = 4775692;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":4710156,"p":[{"n":"errno","p":253708}],"n":"GetSocketErrorForNativeError","d":4775692,"h":25774579468,"f":40},{"r":253708,"p":[{"n":"error","p":4710156}],"n":"GetNativeErrorForSocketError","d":4775692,"h":30069546764,"f":40},{"r":262145,"p":[{"n":"error","p":4710156},{"n":"errno","p":253708,"f":2}],"n":"TryGetNativeErrorForSocketError","d":4775692,"h":34364514060,"f":40}],"l":[{"t":655361,"n":"NativeErrorToSocketErrorCount","d":4775692,"h":8594710284,"f":34},{"t":655361,"n":"SocketErrorToNativeErrorCount","d":4775692,"h":12889677580,"f":34},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$snp.Interop.Error, $.$snp.System.Net.Sockets.SocketError).$h,"n":"s_nativeErrorToSocketError","d":4775692,"h":17184644876,"f":34},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.Sockets.SocketError, $.$snp.Interop.Error).$h,"n":"s_socketErrorToNativeError","d":4775692,"h":21479612172,"f":34}],"h":4775692}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SocketErrorPal`; }
        });
        
        $asm.$cls("$snp.System.Net.CredentialCacheHelper", ($self) => class CredentialCacheHelper
        {
            static /*bool */ TryGetCredential(/*Dictionary<CredentialCacheKey, NetworkCredential>*/ cache, /*Uri*/ uriPrefix, /*string*/ authType, /*out Uri?*/ mostSpecificMatchUri, /*out NetworkCredential?*/ mostSpecificMatch)
            {
                /*int*/ let longestMatchPrefix = -1;
                mostSpecificMatch.$v = null;
                mostSpecificMatchUri.$v = null;
                if (cache.Count === 0)
                {
                    return false;
                }
                /*int*/ let uriPrefixLength = $.$spc.System.String.LastIndexOf.call(uriPrefix.AbsolutePath, /*/*/ 47);
                var $en2 = cache.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var $t1 = $en2.Current;
                    /*CredentialCacheKey*/ let key = $t1.Item1;
                    /*NetworkCredential*/ let value = $t1.Item2;
                    {
                        /*int*/ let prefixLen = key.UriPrefixLength;
                        if (prefixLen <= longestMatchPrefix)
                        {
                            continue;
                        }
                        if (key.Match(uriPrefix, uriPrefixLength, authType))
                        {
                            longestMatchPrefix = prefixLen;
                            mostSpecificMatch.$v = value;
                            mostSpecificMatchUri.$v = key.UriPrefix;
                            if (uriPrefixLength === prefixLen)
                            {
                                break;
                            }
                        }
                    }
                }
                return mostSpecificMatch.$v !== null;
            }
            static $h = 2285324;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"cache","p":$.$spc.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialCacheKey, $.$snp.System.Net.NetworkCredential).$h},{"n":"uriPrefix","p":1744130},{"n":"authType","p":1310721},{"n":"mostSpecificMatchUri","p":1744130,"f":2},{"n":"mostSpecificMatch","p":3858188,"f":2}],"n":"TryGetCredential","d":2285324,"h":4297252620,"f":33}],"h":2285324}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.CredentialCacheHelper`; }
        });
        
        $asm.$cls("$snp.System.Net.Sockets.SocketAddressExtensions", ($self) => class SocketAddressExtensions
        {
            static /*IPAddress */ GetIPAddress(/*this SocketAddress*/ socketAddress)
            {
                return $.$snp.System.Net.Sockets.IPEndPointExtensions.GetIPAddress($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(socketAddress.Buffer.Span));
            }
            static /*int */ GetPort(/*this SocketAddress*/ socketAddress)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(socketAddress.Family === 2/*AddressFamily.InterNetwork*/ || socketAddress.Family === 23/*AddressFamily.InterNetworkV6*/, "socketAddress.Family == AddressFamily.InterNetwork || socketAddress.Family == AddressFamily.InterNetworkV6");
                return $.$cast($.$snp.System.Net.SocketAddressPal.GetPort($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(socketAddress.Buffer.Span)), $.$spc.System.Int32);
            }
            static /*IPEndPoint */ GetIPEndPoint(/*this SocketAddress*/ socketAddress)
            {
                return new $.$snp.System.Net.IPEndPoint().$ctor$3($.$snp.System.Net.Sockets.SocketAddressExtensions.GetIPAddress(socketAddress), $.$snp.System.Net.Sockets.SocketAddressExtensions.GetPort(socketAddress));
            }
            static /*bool */ Equals$2(/*this SocketAddress*/ socketAddress, /*EndPoint?*/ endPoint)
            {
                let ipe;
                if (socketAddress.Family === (endPoint?.AddressFamily ?? null) && $.$is(endPoint, $.$snp.System.Net.IPEndPoint, { set $v(v){ ipe = v; } }))
                {
                    return $.$snp.System.Net.Sockets.IPEndPointExtensions.Equals$2(ipe, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(socketAddress.Buffer.Span));
                }
                return false;
            }
            static $h = 4644620;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":3071756,"p":[{"n":"socketAddress","p":4382476}],"n":"GetIPAddress","d":4644620,"h":4299611916,"f":33},{"r":655361,"p":[{"n":"socketAddress","p":4382476}],"n":"GetPort","d":4644620,"h":8594579212,"f":33},{"r":3333900,"p":[{"n":"socketAddress","p":4382476}],"n":"GetIPEndPoint","d":4644620,"h":12889546508,"f":33},{"r":262145,"p":[{"n":"socketAddress","p":4382476},{"n":"endPoint","p":2613004}],"n":"Equals","o":"@$2","d":4644620,"h":17184513804,"f":33}],"h":4644620}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SocketAddressExtensions`; }
        });
        
        $asm.$cls("$snp.System.Net.IPAddressParserStatics", ($self) => class IPAddressParserStatics
        {
            /*int*/ static IPv4AddressBytes = 4;
            /*int*/ static IPv6AddressBytes = 16;
            /*int*/ static IPv6AddressShorts = 8;
            static $h = 3268364;
            static $f = 0b10000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":655361,"n":"IPv4AddressBytes","d":3268364,"h":4298235660,"f":33},{"t":655361,"n":"IPv6AddressBytes","d":3268364,"h":8593202956,"f":33},{"t":655361,"n":"IPv6AddressShorts","d":3268364,"h":12888170252,"f":33}],"h":3268364}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.IPAddressParserStatics`; }
        });
        
        $asm.$cls("$snp.System.Net.SocketAddress", ($self) => class SocketAddress extends $.$spc.System.Object
        {
            /*int*/ static IPv6AddressSize = 0;
            /*int*/ static IPv4AddressSize = 0;
            /*int*/ static UdsAddressSize = 0;
            /*int*/ static MaxAddressSize = 0;
            /*int*/ _size = 0;
            /*byte[]*/ _buffer = null;
            /*int*/ static MinSize = 2;
            /*int*/ static DataOffset = 2;
            /*AddressFamily */ get Family()
            {
                return $.$snp.System.Net.SocketAddressPal.GetAddressFamily($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit(this._buffer));
            }
            /*int */ get Size()
            {
                return this._size;
            }
            /*int */ set Size(value)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, value, this._buffer.length, "value");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, value, 0, "value");
                this._size = value;
            }
            /*byte*/ get_Item(/*int*/ offset)
            {
                if ((offset >>> 0) >= (this.Size >>> 0))
                {
                    throw new $.$spc.System.IndexOutOfRangeException().$ctor$9();
                }
                return $.$spc.System.Array.$ReadT1.call(this._buffer, offset);
            }
            /*void*/ set_Item(/*int*/ offset, /*byte*/ value)
            {
                if ((offset >>> 0) >= (this.Size >>> 0))
                {
                    throw new $.$spc.System.IndexOutOfRangeException().$ctor$9();
                }
                $.$spc.System.Array.$WriteT1.call(this._buffer, value, offset);
            }
            static /*int */ GetMaximumAddressSize(/*AddressFamily*/ addressFamily)
            {
                return (() =>
                {
                    if (addressFamily === 2/*AddressFamily.InterNetwork*/)
                    {
                        return $.$snp.System.Net.SocketAddress.IPv4AddressSize;
                    }
                    if (addressFamily === 23/*AddressFamily.InterNetworkV6*/)
                    {
                        return $.$snp.System.Net.SocketAddress.IPv6AddressSize;
                    }
                    if (addressFamily === 1/*AddressFamily.Unix*/)
                    {
                        return $.$snp.System.Net.SocketAddress.UdsAddressSize;
                    }
                    return $.$snp.System.Net.SocketAddress.MaxAddressSize;
                })();
            }
            $ctor$1(/*AddressFamily*/ family)
            {
                this.$ctor$2(family, $.$snp.System.Net.SocketAddress.GetMaximumAddressSize(family));
                {
                }
                return this;
            }
            $ctor$2(/*AddressFamily*/ family, /*int*/ size)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, size, 2/*MinSize*/, "size");
                    this._size = size;
                    this._buffer = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [size], null);
                    $.$spc.System.Array.$WriteT1.call(this._buffer, $.$cast(this._size, $.$spc.System.Byte), 0);
                    $.$snp.System.Net.SocketAddressPal.SetAddressFamily($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(this._buffer), family);
                }
                return this;
            }
            $ctor$3(/*IPAddress*/ ipAddress)
            {
                this.$ctor$2(ipAddress.AddressFamily, ((ipAddress.AddressFamily === 2/*AddressFamily.InterNetwork*/) ? $.$snp.System.Net.SocketAddress.IPv4AddressSize : $.$snp.System.Net.SocketAddress.IPv6AddressSize));
                {
                    $.$snp.System.Net.SocketAddressPal.SetPort($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(this._buffer), 0);
                    if (ipAddress.AddressFamily === 23/*AddressFamily.InterNetworkV6*/)
                    {
                        /*Span<byte>*/ let addressBytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Byte, 16/*IPAddressParserStatics.IPv6AddressBytes*/, null);
                        /*int*/ let bytesWritten;
                        ipAddress.TryWriteBytes(addressBytes, $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$spc.System.Int32));
                        $.$spc.System.Diagnostics.Debug.Assert$1(bytesWritten === 16/*IPAddressParserStatics.IPv6AddressBytes*/, "bytesWritten == IPAddressParserStatics.IPv6AddressBytes");
                        $.$snp.System.Net.SocketAddressPal.SetIPv6Address($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(this._buffer), addressBytes, $.$cast(ipAddress.ScopeId, $.$spc.System.UInt32));
                    }
                    else 
                    {
                        /*uint*/ let address = $.$cast(ipAddress.Address, $.$spc.System.UInt32);
                        $.$spc.System.Diagnostics.Debug.Assert$1(ipAddress.AddressFamily === 2/*AddressFamily.InterNetwork*/, "ipAddress.AddressFamily == AddressFamily.InterNetwork");
                        $.$snp.System.Net.SocketAddressPal.SetIPv4Address($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(this._buffer), address);
                    }
                }
                return this;
            }
            $ctor$4(/*IPAddress*/ ipaddress, /*int*/ port)
            {
                this.$ctor$3(ipaddress);
                {
                    $.$snp.System.Net.SocketAddressPal.SetPort($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(this._buffer), $.$cast(port, $.$spc.System.UInt16));
                }
                return this;
            }
            /*Memory<byte> */ get Buffer()
            {
                return new ($.$spc.System.Memory$$($.$spc.System.Byte))().$ctor$2(this._buffer);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                let other;
                return $.$is(comparand, $.$snp.System.Net.SocketAddress, { set $v(v){ other = v; } }) && this.Equals$2(other);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snp.System.Net.SocketAddress.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*SocketAddress?*/ comparand)
            {
                return comparand !== null && $.$spc.System.MemoryExtensions.SequenceEqual$1($.$spc.System.Byte, $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(this.Buffer.Span), $.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2(comparand.Buffer.Span));
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                /*HashCode*/ let hash = new $.$spc.System.HashCode();
                hash.AddBytes(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$3(this._buffer, 0, this._size));
                return hash.ToHashCode();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snp.System.Net.SocketAddress.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                /*string*/ let familyString = $.$spc.System.Enum.ToStringT($.$snp.System.Net.Sockets.AddressFamily, $.$spc.System.UInt32, this.Family);
                /*int*/ let maxLength = $.$checked($.$checked($.$checked($.$checked($.$checked(familyString.length + 1, 1) + 10, 1) + 2, 1) + $.$checked(($.$checked(this.Size - 2/*DataOffset*/, 1)) * 4, 1), 1) + 1, 1);
                /*Span<char>*/ let result = (maxLength >>> 0) <= 256 ? $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 256, null) : $.$spc.System.Span$$($.$spc.System.Char).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Char), null, [maxLength], null));
                $.$spc.System.String.CopyTo$1.call(familyString, result);
                /*int*/ let length = familyString.length;
                result.get_Item(length++).$v = /*:*/ 58;
                /*int*/ let charsWritten;
                /*bool*/ let formatted = $.$spc.System.Int32.TryFormat.call(this.Size, result.Slice(length), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))(), null);
                $.$spc.System.Diagnostics.Debug.Assert$1(formatted, "formatted");
                length += charsWritten;
                result.get_Item(length++).$v = /*:*/ 58;
                result.get_Item(length++).$v = /*{*/ 123;
                /*byte[]*/ let buffer = this._buffer;
                for(/*int*/ let i = 2/*DataOffset*/; i < this.Size; i++)
                {
                    if (i > 2/*DataOffset*/)
                    {
                        result.get_Item(length++).$v = /*,*/ 44;
                    }
                    formatted = $.$spc.System.Byte.TryFormat.call($.$spc.System.Array.$ReadT1.call(buffer, i), result.Slice(length), $.$ref(() => charsWritten, ($v) => charsWritten = $v, $.$spc.System.Int32), new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Char))(), null);
                    $.$spc.System.Diagnostics.Debug.Assert$1(formatted, "formatted");
                    length += charsWritten;
                }
                result.get_Item(length++).$v = /*}*/ 125;
                return $.$spc.System.Span$$($.$spc.System.Char).ToString.call(result.Slice$1(0, length));
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.SocketAddress.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Net.SocketAddress>.Equals(System.Net.SocketAddress?)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.IPv6AddressSize = $.$snp.System.Net.SocketAddressPal.IPv6AddressSize;
                }
                {
                    this.IPv4AddressSize = $.$snp.System.Net.SocketAddressPal.IPv4AddressSize;
                }
                {
                    this.UdsAddressSize = $.$snp.System.Net.SocketAddressPal.UdsAddressSize;
                }
                {
                    this.MaxAddressSize = $.$snp.System.Net.SocketAddressPal.MaxAddressSize;
                }
            }
            static $h = 4382476;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":4513548,"g":{"r":0,"d":0,"h":42954055436,"f":1},"n":"Family","d":4382476,"h":38659088140,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51543990028,"f":1},"s":{"r":0,"d":0,"h":55838957324,"f":1},"n":"Size","d":4382476,"h":47249022732,"f":1},{"p":393217,"i":[{"n":"offset","p":655361}],"g":{"r":0,"d":0,"h":64428891916,"f":1},"s":{"r":0,"d":0,"h":68723859212,"f":1},"n":"Item","o":"@$2","d":4382476,"h":60133924620,"f":1},{"p":$.$spc.System.Memory$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":98788630284,"f":1},"n":"Buffer","d":4382476,"h":94493662988,"f":1}],"m":[{"r":655361,"p":[{"n":"addressFamily","p":4513548}],"n":"GetMaximumAddressSize","d":4382476,"h":73018826508,"f":33},{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":4382476,"h":103083597580,"f":32769},{"r":262145,"p":[{"n":"comparand","p":4382476}],"n":"Equals","o":"@$2","d":4382476,"h":107378564876,"f":1},{"r":655361,"n":"GetHashCode","d":4382476,"h":111673532172,"f":32769},{"r":1310721,"n":"ToString","d":4382476,"h":115968499468,"f":32769}],"l":[{"t":655361,"n":"IPv6AddressSize","d":4382476,"h":4299349772,"f":40},{"t":655361,"n":"IPv4AddressSize","d":4382476,"h":8594317068,"f":40},{"t":655361,"n":"UdsAddressSize","d":4382476,"h":12889284364,"f":40},{"t":655361,"n":"MaxAddressSize","d":4382476,"h":17184251660,"f":40},{"t":655361,"n":"_size","d":4382476,"h":21479218956,"f":2},{"t":0,"n":"_buffer","d":4382476,"h":25774186252,"f":2},{"t":655361,"n":"MinSize","d":4382476,"h":30069153548,"f":34},{"t":655361,"n":"DataOffset","d":4382476,"h":34364120844,"f":34}],"c":[{"p":[{"n":"family","p":4513548}],"n":".ctor","o":"$ctor$1","d":4382476,"h":77313793804,"f":1},{"p":[{"n":"family","p":4513548},{"n":"size","p":655361}],"n":".ctor","o":"$ctor$2","d":4382476,"h":81608761100,"f":1},{"p":[{"n":"ipAddress","p":3071756}],"n":".ctor","o":"$ctor$3","d":4382476,"h":85903728396,"f":8},{"p":[{"n":"ipaddress","p":3071756},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$4","d":4382476,"h":90198695692,"f":8}],"i":[$.$spc.System.IEquatable$$($.$snp.System.Net.SocketAddress).$h],"h":4382476}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$snp.System.Net.SocketAddress) ]; }
            static get $fullName() { return `System.Net.SocketAddress`; }
        });
        
        $asm.$cls("$snp.System.Net.CredentialCacheKey", ($self) => class CredentialCacheKey extends $.$spc.System.Object
        {
            /*Uri*/ UriPrefix = null;
            /*int*/ UriPrefixLength = -1;
            /*string*/ AuthenticationType = null;
            $ctor$1(/*Uri*/ uriPrefix, /*string*/ authenticationType)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spu.System.Uri.op_Inequality(uriPrefix, null), "uriPrefix != null");
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(authenticationType, null), "authenticationType != null");
                    this.UriPrefix = uriPrefix;
                    this.UriPrefixLength = $.$spc.System.String.LastIndexOf.call(this.UriPrefix.AbsolutePath, /*/*/ 47);
                    this.AuthenticationType = authenticationType;
                }
                return this;
            }
            /*bool */ Match(/*Uri*/ uri, /*int*/ prefixLen, /*string*/ authenticationType)
            {
                if ($.$spu.System.Uri.op_Equality(uri, null) || $.$spc.System.String.op_Equality(authenticationType, null))
                {
                    return false;
                }
                if (!$.$spc.System.String.Equals$5(authenticationType, this.AuthenticationType, 5/*StringComparison.OrdinalIgnoreCase*/))
                {
                    return false;
                }
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Match(${$.$spu.System.Uri.ToString.call(this.UriPrefix)} & ${$.$spu.System.Uri.ToString.call(uri)})`, "Match");
                }
                return this.IsPrefix(uri, prefixLen);
            }
            /*bool */ IsPrefix(/*Uri*/ uri, /*int*/ prefixLen)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1($.$spu.System.Uri.op_Inequality(uri, null), "uri != null");
                /*Uri*/ let uriPrefix = this.UriPrefix;
                if ($.$spc.System.String.op_Inequality(uriPrefix.Scheme, uri.Scheme) || $.$spc.System.String.op_Inequality(uriPrefix.Host, uri.Host) || uriPrefix.Port !== uri.Port)
                {
                    return false;
                }
                if (this.UriPrefixLength > prefixLen)
                {
                    return false;
                }
                return $.$spc.System.String.Compare$9(uri.AbsolutePath, 0, uriPrefix.AbsolutePath, 0, this.UriPrefixLength, 5/*StringComparison.OrdinalIgnoreCase*/) === 0;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(this.AuthenticationType) ^ $.$spu.System.Uri.GetHashCode.call(this.UriPrefix);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snp.System.Net.CredentialCacheKey.GetHashCode.apply(this, arguments); }
            /*bool */ Equals$2(/*CredentialCacheKey?*/ other)
            {
                if (other === null)
                {
                    return false;
                }
                /*bool*/ let equals = $.$spc.System.String.Equals$5(this.AuthenticationType, other.AuthenticationType, 5/*StringComparison.OrdinalIgnoreCase*/) && this.UriPrefix.Equals$2(other.UriPrefix);
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Equals(${$.$snp.System.Net.CredentialCacheKey.ToString.call(this)},${$.$snp.System.Net.CredentialCacheKey.ToString.call(other)}) returns ${equals}`, "Equals");
                }
                return equals;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return this.Equals$2($.$as(obj, $.$snp.System.Net.CredentialCacheKey));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snp.System.Net.CredentialCacheKey.Equals.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return $.$spc.System.String.Create$9($.$spc.System.Globalization.CultureInfo.InvariantCulture, `[${this.UriPrefixLength}]:${$.$spu.System.Uri.ToString.call(this.UriPrefix)}:${this.AuthenticationType}`);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.CredentialCacheKey.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Net.CredentialCacheKey?>.Equals(System.Net.CredentialCacheKey?)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            static $h = 2350860;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"uri","p":1744130},{"n":"prefixLen","p":655361},{"n":"authenticationType","p":1310721}],"n":"Match","d":2350860,"h":21477187340,"f":8},{"r":262145,"p":[{"n":"uri","p":1744130},{"n":"prefixLen","p":655361}],"n":"IsPrefix","d":2350860,"h":25772154636,"f":2},{"r":655361,"n":"GetHashCode","d":2350860,"h":30067121932,"f":32769},{"r":262145,"p":[{"n":"other","p":2350860}],"n":"Equals","o":"@$2","d":2350860,"h":34362089228,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2350860,"h":38657056524,"f":32769},{"r":1310721,"n":"ToString","d":2350860,"h":42952023820,"f":32769}],"l":[{"t":1744130,"n":"UriPrefix","d":2350860,"h":4297318156,"f":1},{"t":655361,"n":"UriPrefixLength","d":2350860,"h":8592285452,"f":1},{"t":1310721,"n":"AuthenticationType","d":2350860,"h":12887252748,"f":1}],"c":[{"p":[{"n":"uriPrefix","p":1744130},{"n":"authenticationType","p":1310721}],"n":".ctor","o":"$ctor$1","d":2350860,"h":17182220044,"f":8}],"i":[$.$spc.System.IEquatable$$($.$snp.System.Net.CredentialCacheKey).$h],"h":2350860}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$snp.System.Net.CredentialCacheKey) ]; }
            static get $fullName() { return `System.Net.CredentialCacheKey`; }
        });
        
        $asm.$cls("$snp.System.Net.NetworkCredential", ($self) => class NetworkCredential extends $.$spc.System.Object
        {
            /*string*/ _domain = null;
            /*string*/ _userName = null;
            /*object?*/ _password = null;
            $ctor$1()
            {
                this.$ctor$3($.$spc.System.String.Empty, $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                {
                }
                return this;
            }
            $ctor$2(/*string?*/ userName, /*string?*/ password)
            {
                this.$ctor$3(userName, password, $.$spc.System.String.Empty);
                {
                }
                return this;
            }
            $ctor$3(/*string?*/ userName, /*string?*/ password, /*string?*/ domain)
            {
                super.$ctor();
                {
                    this.UserName = userName;
                    this.Password = password;
                    this.Domain = domain;
                }
                return this;
            }
            $ctor$4(/*string?*/ userName, /*SecureString?*/ password)
            {
                this.$ctor$5(userName, password, $.$spc.System.String.Empty);
                {
                }
                return this;
            }
            $ctor$5(/*string?*/ userName, /*SecureString?*/ password, /*string?*/ domain)
            {
                super.$ctor();
                {
                    this.UserName = userName;
                    this.SecurePassword = password;
                    this.Domain = domain;
                }
                return this;
            }
            /*string */ get UserName()
            {
                return this._userName;
            }
            /*string */ set UserName(value)
            {
                this._userName = value ?? $.$spc.System.String.Empty;
            }
            /*string */ get Password()
            {
                /*SecureString?*/ let sstr = $.$as(this._password, $.$spc.System.Security.SecureString);
                if (sstr !== null)
                {
                    return $.$snp.System.Net.NetworkCredential.MarshalToString(sstr);
                }
                return $.$cast(this._password, $.$spc.System.String) ?? $.$spc.System.String.Empty;
            }
            /*string */ set Password(value)
            {
                /*SecureString?*/ let old = $.$as(this._password, $.$spc.System.Security.SecureString);
                this._password = value;
                old?.Dispose();
            }
            /*SecureString */ get SecurePassword()
            {
                /*string?*/ let str = $.$as(this._password, $.$spc.System.String);
                if ($.$spc.System.String.op_Inequality(str, null))
                {
                    return this.MarshalToSecureString(str);
                }
                /*SecureString?*/ let sstr = $.$as(this._password, $.$spc.System.Security.SecureString);
                return sstr !== null ? sstr.Copy() : new $.$spc.System.Security.SecureString().$ctor$1();
            }
            /*SecureString */ set SecurePassword(value)
            {
                /*SecureString?*/ let old = $.$as(this._password, $.$spc.System.Security.SecureString);
                this._password = (value?.Copy() ?? null);
                old?.Dispose();
            }
            /*string */ get Domain()
            {
                return this._domain;
            }
            /*string */ set Domain(value)
            {
                this._domain = value ?? $.$spc.System.String.Empty;
            }
            /*NetworkCredential */ GetCredential(/*Uri?*/ uri, /*string?*/ authenticationType)
            {
                return this;
            }
            /*NetworkCredential */ GetCredential$1(/*string?*/ host, /*int*/ port, /*string?*/ authenticationType)
            {
                return this;
            }
            static /*string */ MarshalToString(/*SecureString*/ sstr)
            {
                if (sstr === null || sstr.Length === 0)
                {
                    return $.$spc.System.String.Empty;
                }
                /*IntPtr*/ let ptr = $.$spc.System.IntPtr.Zero;
                /*string*/ let result = $.$spc.System.String.Empty;
                try
                {
                    ptr = $.$spc.System.Runtime.InteropServices.Marshal.SecureStringToGlobalAllocUnicode(sstr);
                    result = $.$spc.System.Runtime.InteropServices.Marshal.PtrToStringUni(ptr);
                }
                finally
                {
                    {
                        if (ptr !== $.$spc.System.IntPtr.Zero)
                        {
                            $.$spc.System.Runtime.InteropServices.Marshal.ZeroFreeGlobalAllocUnicode(ptr);
                        }
                    }
                }
                return result;
            }
            /*SecureString */ MarshalToSecureString(/*string*/ str)
            {
                if ($.$spc.System.String.IsNullOrEmpty(str))
                {
                    return new $.$spc.System.Security.SecureString().$ctor$1();
                }
                /*fixed*/ 
                {
                    /*char**/ let ptr = $.$spc.System.String.GetPinnableReference.call(str);
                    return new $.$spc.System.Security.SecureString().$ctor$2(ptr, str.length);
                }
            }
            //Generated interface implemetation for System.Net.ICredentials.GetCredential(System.Uri, string)
            System$Net$ICredentials$GetCredential()
            {
                return this.GetCredential(...arguments);
            }
            //Generated interface implemetation for System.Net.ICredentialsByHost.GetCredential(string, int, string)
            System$Net$ICredentialsByHost$GetCredential()
            {
                return this.GetCredential$1(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this._userName = $.$spc.System.String.Empty;
            }
            static $h = 3858188;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":42953531148,"f":1},"s":{"r":0,"d":0,"h":47248498444,"f":1},"n":"UserName","d":3858188,"h":38658563852,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":55838433036,"f":1},"s":{"r":0,"d":0,"h":60133400332,"f":1},"n":"Password","d":3858188,"h":51543465740,"f":1},{"p":117309441,"g":{"r":0,"d":0,"h":68723334924,"f":1},"s":{"r":0,"d":0,"h":73018302220,"f":1},"n":"SecurePassword","d":3858188,"h":64428367628,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"p":1310721,"g":{"r":0,"d":0,"h":81608236812,"f":1},"s":{"r":0,"d":0,"h":85903204108,"f":1},"n":"Domain","d":3858188,"h":77313269516,"f":1}],"m":[{"r":3858188,"p":[{"n":"uri","p":1744130},{"n":"authenticationType","p":1310721}],"n":"GetCredential","d":3858188,"h":90198171404,"f":1},{"r":3858188,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"authenticationType","p":1310721}],"n":"GetCredential","o":"@$1","d":3858188,"h":94493138700,"f":1},{"r":1310721,"p":[{"n":"sstr","p":117309441}],"n":"MarshalToString","d":3858188,"h":98788105996,"f":34},{"r":117309441,"p":[{"n":"str","p":1310721}],"n":"MarshalToSecureString","d":3858188,"h":103083073292,"f":2}],"l":[{"t":1310721,"n":"_domain","d":3858188,"h":4298825484,"f":2},{"t":1310721,"n":"_userName","d":3858188,"h":8593792780,"f":2},{"t":131073,"n":"_password","d":3858188,"h":12888760076,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":3858188,"h":17183727372,"f":1},{"p":[{"n":"userName","p":1310721},{"n":"password","p":1310721}],"n":".ctor","o":"$ctor$2","d":3858188,"h":21478694668,"f":1},{"p":[{"n":"userName","p":1310721},{"n":"password","p":1310721},{"n":"domain","p":1310721}],"n":".ctor","o":"$ctor$3","d":3858188,"h":25773661964,"f":1},{"p":[{"n":"userName","p":1310721},{"n":"password","p":117309441}],"n":".ctor","o":"$ctor$4","d":3858188,"h":30068629260,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"p":[{"n":"userName","p":1310721},{"n":"password","p":117309441},{"n":"domain","p":1310721}],"n":".ctor","o":"$ctor$5","d":3858188,"h":34363596556,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}],"i":[2940684,3006220],"h":3858188}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$snp.System.Net.ICredentials, $.$snp.System.Net.ICredentialsByHost ]; }
            static get $fullName() { return `System.Net.NetworkCredential`; }
        });
        
        $asm.$cls("$snp.System.Net.CredentialCache", ($self) => class CredentialCache extends $.$spc.System.Object
        {
            /*Dictionary<CredentialCacheKey, NetworkCredential>?*/ _cache = null;
            /*Dictionary<CredentialHostKey, NetworkCredential>?*/ _cacheForHosts = null;
            /*int*/ _version = 0;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*void */ Add(/*Uri*/ uriPrefix, /*string*/ authType, /*NetworkCredential*/ cred)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(uriPrefix, "uriPrefix");
                $.$spc.System.ArgumentNullException.ThrowIfNull(authType, "authType");
                if (($.$is(cred, $.$snp.System.Net.SystemNetworkCredential)) && !(($.$spc.System.String.Equals$5(authType, "NTLM"/*NegotiationInfoClass.NTLM*/, 5/*StringComparison.OrdinalIgnoreCase*/)) || ($.$spc.System.String.Equals$5(authType, "Kerberos"/*NegotiationInfoClass.Kerberos*/, 5/*StringComparison.OrdinalIgnoreCase*/)) || ($.$spc.System.String.Equals$5(authType, "Negotiate"/*NegotiationInfoClass.Negotiate*/, 5/*StringComparison.OrdinalIgnoreCase*/))))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$snp.System.SR.Format($.$snp.System.SR.net_nodefaultcreds, authType), "authType");
                }
                ++this._version;
                /*var*/ let key = new $.$snp.System.Net.CredentialCacheKey().$ctor$1(uriPrefix, authType);
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Adding key:[${$.$snp.System.Net.CredentialCacheKey.ToString.call(key)}], cred:[${cred.Domain}],[${cred.UserName}]`, "Add");
                }
                this._cache ??= new ($.$spc.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialCacheKey, $.$snp.System.Net.NetworkCredential))().$ctor$1();
                this._cache.Add(key, cred);
            }
            /*void */ Add$1(/*string*/ host, /*int*/ port, /*string*/ authenticationType, /*NetworkCredential*/ credential)
            {
                $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(host, "host");
                $.$spc.System.ArgumentNullException.ThrowIfNull(authenticationType, "authenticationType");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, port, "port");
                if (($.$is(credential, $.$snp.System.Net.SystemNetworkCredential)) && !(($.$spc.System.String.Equals$5(authenticationType, "NTLM"/*NegotiationInfoClass.NTLM*/, 5/*StringComparison.OrdinalIgnoreCase*/)) || ($.$spc.System.String.Equals$5(authenticationType, "Kerberos"/*NegotiationInfoClass.Kerberos*/, 5/*StringComparison.OrdinalIgnoreCase*/)) || ($.$spc.System.String.Equals$5(authenticationType, "Negotiate"/*NegotiationInfoClass.Negotiate*/, 5/*StringComparison.OrdinalIgnoreCase*/))))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$snp.System.SR.Format($.$snp.System.SR.net_nodefaultcreds, authenticationType), "authenticationType");
                }
                ++this._version;
                /*var*/ let key = new $.$snp.System.Net.CredentialHostKey().$ctor$2(host, port, authenticationType);
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Adding key:[${$.$snp.System.Net.CredentialHostKey.ToString.call(key)}], cred:[${credential.Domain}],[${credential.UserName}]`, "Add");
                }
                this._cacheForHosts ??= new ($.$spc.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialHostKey, $.$snp.System.Net.NetworkCredential))().$ctor$1();
                this._cacheForHosts.Add(key, credential);
            }
            /*void */ Remove(/*Uri?*/ uriPrefix, /*string?*/ authType)
            {
                if ($.$spu.System.Uri.op_Equality(uriPrefix, null) || $.$spc.System.String.op_Equality(authType, null))
                {
                    return;
                }
                if (this._cache === null)
                {
                    if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                    {
                        $.$snp.System.Net.NetEventSource.Info$1(this, "Short-circuiting because the dictionary is null.", "Remove");
                    }
                    return;
                }
                ++this._version;
                /*var*/ let key = new $.$snp.System.Net.CredentialCacheKey().$ctor$1(uriPrefix, authType);
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Removing key:[${$.$snp.System.Net.CredentialCacheKey.ToString.call(key)}]`, "Remove");
                }
                this._cache.Remove(key);
            }
            /*void */ Remove$1(/*string?*/ host, /*int*/ port, /*string?*/ authenticationType)
            {
                if ($.$spc.System.String.op_Equality(host, null) || $.$spc.System.String.op_Equality(authenticationType, null))
                {
                    return;
                }
                if (port < 0)
                {
                    return;
                }
                if (this._cacheForHosts === null)
                {
                    if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                    {
                        $.$snp.System.Net.NetEventSource.Info$1(this, "Short-circuiting because the dictionary is null.", "Remove");
                    }
                    return;
                }
                ++this._version;
                /*var*/ let key = new $.$snp.System.Net.CredentialHostKey().$ctor$2(host, port, authenticationType);
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Removing key:[${$.$snp.System.Net.CredentialHostKey.ToString.call(key)}]`, "Remove");
                }
                this._cacheForHosts.Remove(key);
            }
            /*NetworkCredential? */ GetCredential(/*Uri*/ uriPrefix, /*string*/ authType)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(uriPrefix, "uriPrefix");
                $.$spc.System.ArgumentNullException.ThrowIfNull(authType, "authType");
                if (this._cache === null)
                {
                    if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                    {
                        $.$snp.System.Net.NetEventSource.Info$1(this, "CredentialCache::GetCredential short-circuiting because the dictionary is null.", "GetCredential");
                    }
                    return null;
                }
                /*NetworkCredential?*/ let mostSpecificMatch;
                $.$snp.System.Net.CredentialCacheHelper.TryGetCredential(this._cache, uriPrefix, authType, $.$discardRef(), $.$ref(() => mostSpecificMatch, ($v) => mostSpecificMatch = $v, $.$snp.System.Net.NetworkCredential));
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Returning ${(mostSpecificMatch === null ? "null" : "(" + mostSpecificMatch.UserName + ":" + mostSpecificMatch.Domain + ")")}`, "GetCredential");
                }
                return mostSpecificMatch;
            }
            /*NetworkCredential? */ GetCredential$1(/*string*/ host, /*int*/ port, /*string*/ authenticationType)
            {
                $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(host, "host");
                $.$spc.System.ArgumentNullException.ThrowIfNull(authenticationType, "authenticationType");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, port, "port");
                if (this._cacheForHosts === null)
                {
                    if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                    {
                        $.$snp.System.Net.NetEventSource.Info$1(this, "CredentialCache::GetCredential short-circuiting because the dictionary is null.", "GetCredential");
                    }
                    return null;
                }
                /*var*/ let key = new $.$snp.System.Net.CredentialHostKey().$ctor$2(host, port, authenticationType);
                /*NetworkCredential?*/ let match;
                this._cacheForHosts.TryGetValue(key, $.$ref(() => match, ($v) => match = $v, $.$snp.System.Net.NetworkCredential));
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Returning ${((match === null) ? "null" : "(" + match.UserName + ":" + match.Domain + ")")}`, "GetCredential");
                }
                return match;
            }
            /*IEnumerator */ GetEnumerator()
            {
                return $.$snp.System.Net.CredentialCache.CredentialEnumerator.Create(this);
            }
            static /*ICredentials */ get DefaultCredentials()
            {
                return $.$snp.System.Net.SystemNetworkCredential.s_defaultCredential;
            }
            static /*NetworkCredential */ get DefaultNetworkCredentials()
            {
                return $.$snp.System.Net.SystemNetworkCredential.s_defaultCredential;
            }
            static $_CredentialEnumerator;
            static get CredentialEnumerator()
            {
                let $cls = $.$snp.System.Net.CredentialCache;
                return $cls.$_CredentialEnumerator ??= $asm.$ncls("$snp.System.Net.CredentialCache.CredentialEnumerator", ($self) => class CredentialEnumerator extends $.$spc.System.Object
                {
                    static /*CredentialEnumerator */ Create(/*CredentialCache*/ cache)
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(cache !== null, "cache != null");
                        if (cache._cache !== null)
                        {
                            return cache._cacheForHosts !== null ? new $.$snp.System.Net.CredentialCache.CredentialEnumerator.DoubleTableCredentialEnumerator().$ctor$3(cache) : new ($.$snp.System.Net.CredentialCache.CredentialEnumerator.SingleTableCredentialEnumerator$$($.$snp.System.Net.CredentialCacheKey))().$ctor$2(cache, cache._cache);
                        }
                        else 
                        {
                            return cache._cacheForHosts !== null ? new ($.$snp.System.Net.CredentialCache.CredentialEnumerator.SingleTableCredentialEnumerator$$($.$snp.System.Net.CredentialHostKey))().$ctor$2(cache, cache._cacheForHosts) : new $.$snp.System.Net.CredentialCache.CredentialEnumerator().$ctor$1(cache);
                        }
                    }
                    /*CredentialCache*/ _cache = null;
                    /*int*/ _version = 0;
                    /*bool*/ _enumerating = false;
                    /*NetworkCredential?*/ _current = null;
                    $ctor$1(/*CredentialCache*/ cache)
                    {
                        super.$ctor();
                        {
                            $.$spc.System.Diagnostics.Debug.Assert$1(cache !== null, "cache != null");
                            this._cache = cache;
                            this._version = cache._version;
                        }
                        return this;
                    }
                    /*object */ get Current()
                    {
                        if (!this._enumerating)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$snp.System.SR.InvalidOperation_EnumOpCantHappen);
                        }
                        if (this._version !== this._cache._version)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$snp.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        return this._current;
                    }
                    /*bool */ MoveNext()
                    {
                        if (this._version !== this._cache._version)
                        {
                            throw new $.$spc.System.InvalidOperationException().$ctor$10($.$snp.System.SR.InvalidOperation_EnumFailedVersion);
                        }
                        return this._enumerating = this.MoveNext$1($.$ref(() => this._current, ($v) => this._current = $v, $.$snp.System.Net.NetworkCredential));
                    }
                    /*bool */ MoveNext$1(/*out NetworkCredential?*/ current)
                    {
                        current.$v = null;
                        return false;
                    }
                    /*void */ Reset()
                    {
                        this._enumerating = false;
                    }
                    static $_SingleTableCredentialEnumerator$$;
                    static SingleTableCredentialEnumerator$$(TKey)
                    {
                        let $cls = $.$snp.System.Net.CredentialCache.CredentialEnumerator;
                        return ($cls.$_SingleTableCredentialEnumerator$$ ??= $asm.$ncls("$snp.System.Net.CredentialCache.CredentialEnumerator.SingleTableCredentialEnumerator<>", (TKey) => $asm.$gt("$snp.System.Net.CredentialCache.CredentialEnumerator.SingleTableCredentialEnumerator<>", [TKey], ($self) => class SingleTableCredentialEnumerator$$ extends $.$snp.System.Net.CredentialCache.CredentialEnumerator
                        {
                            /*Dictionary<TKey, NetworkCredential>.ValueCollection.Enumerator*/ _enumerator;
                            $ctor$2(/*CredentialCache*/ cache, /*Dictionary<TKey, NetworkCredential>*/ table)
                            {
                                super.$ctor$1(cache);
                                {
                                    $.$spc.System.Diagnostics.Debug.Assert$1(table !== null, "table != null");
                                    this._enumerator = table.Values.GetEnumerator();
                                }
                                return this;
                            }
                            /*bool */ MoveNext$1(/*out NetworkCredential*/ current)
                            {
                                return $.$snp.System.Net.CredentialCache.CredentialEnumerator.DictionaryEnumeratorHelper.MoveNext(TKey, $.$snp.System.Net.NetworkCredential, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Collections.Generic.Dictionary$$$(TKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator, () => this._enumerator, ($v) => this._enumerator = $v, null), current);
                            }
                            /*void */ Reset()
                            {
                                $.$snp.System.Net.CredentialCache.CredentialEnumerator.DictionaryEnumeratorHelper.Reset($.$spc.System.Collections.Generic.Dictionary$$$(TKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Collections.Generic.Dictionary$$$(TKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator, () => this._enumerator, ($v) => this._enumerator = $v, null));
                                super.Reset();
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this._enumerator = $.$default($.$spc.System.Collections.Generic.Dictionary$$$(TKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator);
                            }
                            static $h = 2219788;
                            static $g = 1;
                            static $f = 0b10000000001010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":2023180,"m":[{"r":262145,"p":[{"n":"current","p":3858188,"f":2}],"n":"MoveNext","o":"@$1","d":this.$h,"h":Number(BigInt(this.$h)|0x300000000n),"f":32772},{"r":65537,"n":"Reset","d":this.$h,"h":Number(BigInt(this.$h)|0x400000000n),"f":32769}],"l":[{"t":$.$spc.System.Collections.Generic.Dictionary$$$(TKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator.$h,"n":"_enumerator","d":this.$h,"h":Number(BigInt(this.$h)|0x100000000n),"f":2}],"c":[{"p":[{"n":"cache","p":1957644},{"n":"table","p":$.$spc.System.Collections.Generic.Dictionary$$$(TKey, $.$snp.System.Net.NetworkCredential).$h}],"n":".ctor","o":"$ctor$2","d":this.$h,"h":Number(BigInt(this.$h)|0x200000000n),"f":1}],"i":[31719425],"g":[TKey?.$h??1507328],"s":[{"n":"TKey","f":64}],"r":1,"d":2023180,"h":this.$h}; }
                            static get $b() { return $.$snp.System.Net.CredentialCache.CredentialEnumerator; }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Net.CredentialCache.CredentialEnumerator.SingleTableCredentialEnumerator<${TKey?.$fullName}>`; }
                        }), $cls, ($v) => $cls.$_SingleTableCredentialEnumerator$$ = $v))(TKey);
                    }
                    static $_DoubleTableCredentialEnumerator;
                    static get DoubleTableCredentialEnumerator()
                    {
                        let $cls = $.$snp.System.Net.CredentialCache.CredentialEnumerator;
                        return $cls.$_DoubleTableCredentialEnumerator ??= $asm.$ncls("$snp.System.Net.CredentialCache.CredentialEnumerator.DoubleTableCredentialEnumerator", ($self) => class DoubleTableCredentialEnumerator extends $.$snp.System.Net.CredentialCache.CredentialEnumerator.SingleTableCredentialEnumerator$$($.$snp.System.Net.CredentialCacheKey)
                        {
                            /*Dictionary<CredentialHostKey, NetworkCredential>.ValueCollection.Enumerator*/ _enumerator;
                            /*bool*/ _onThisEnumerator = false;
                            $ctor$3(/*CredentialCache*/ cache)
                            {
                                super.$ctor$2(cache, cache._cache);
                                {
                                    $.$spc.System.Diagnostics.Debug.Assert$1(cache._cacheForHosts !== null, "cache._cacheForHosts != null");
                                    this._enumerator = cache._cacheForHosts.Values.GetEnumerator();
                                }
                                return this;
                            }
                            /*bool */ MoveNext$1(/*out NetworkCredential*/ current)
                            {
                                if (!this._onThisEnumerator)
                                {
                                    if (super.MoveNext$1(current))
                                    {
                                        return true;
                                    }
                                    else 
                                    {
                                        this._onThisEnumerator = true;
                                    }
                                }
                                return $.$snp.System.Net.CredentialCache.CredentialEnumerator.DictionaryEnumeratorHelper.MoveNext($.$snp.System.Net.CredentialHostKey, $.$snp.System.Net.NetworkCredential, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialHostKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator, () => this._enumerator, ($v) => this._enumerator = $v, null), current);
                            }
                            /*void */ Reset()
                            {
                                this._onThisEnumerator = false;
                                $.$snp.System.Net.CredentialCache.CredentialEnumerator.DictionaryEnumeratorHelper.Reset($.$spc.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialHostKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialHostKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator, () => this._enumerator, ($v) => this._enumerator = $v, null));
                                super.Reset();
                            }
                            //default member initializer
                            constructor()
                            {
                                super();
                                this._enumerator = $.$default($.$spc.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialHostKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator);
                            }
                            static $h = 2154252;
                            static $f = 0b10000000010010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":2219788,"m":[{"r":262145,"p":[{"n":"current","p":3858188,"f":2}],"n":"MoveNext","o":"@$1","d":2154252,"h":17182023436,"f":32772},{"r":65537,"n":"Reset","d":2154252,"h":21476990732,"f":32769}],"l":[{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialHostKey, $.$snp.System.Net.NetworkCredential).ValueCollection.Enumerator.$h,"n":"_enumerator","d":2154252,"h":4297121548,"f":2},{"t":262145,"n":"_onThisEnumerator","d":2154252,"h":8592088844,"f":2}],"c":[{"p":[{"n":"cache","p":1957644}],"n":".ctor","o":"$ctor$3","d":2154252,"h":12887056140,"f":1}],"i":[31719425],"d":2023180,"h":2154252}; }
                            static get $b() { return $.$snp.System.Net.CredentialCache.CredentialEnumerator.SingleTableCredentialEnumerator$$($.$snp.System.Net.CredentialCacheKey); }
                            static $$i;
                            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IEnumerator ]; }
                            static get $fullName() { return `System.Net.CredentialCache.CredentialEnumerator.DoubleTableCredentialEnumerator`; }
                        }, $cls, ($v) => $cls.$_DoubleTableCredentialEnumerator = $v);
                    }
                    static $_DictionaryEnumeratorHelper;
                    static get DictionaryEnumeratorHelper()
                    {
                        let $cls = $.$snp.System.Net.CredentialCache.CredentialEnumerator;
                        return $cls.$_DictionaryEnumeratorHelper ??= $asm.$ncls("$snp.System.Net.CredentialCache.CredentialEnumerator.DictionaryEnumeratorHelper", ($self) => class DictionaryEnumeratorHelper
                        {
                            static /*bool */ MoveNext(TKey, TValue, /*ref Dictionary<TKey, TValue>.ValueCollection.Enumerator*/ enumerator, /*out TValue*/ current)
                            {
                                /*bool*/ let result = enumerator.$v.MoveNext();
                                current.$v = enumerator.$v.Current;
                                return result;
                            }
                            static /*void */ Reset(TEnumerator, /*ref TEnumerator*/ enumerator)
                            {
                                try
                                {
                                    $.$dsp(enumerator.$v, TEnumerator, ($t) => $t.System$Collections$IEnumerator$Reset,);
                                }
                                catch($e)
                                {
                                }
                            }
                            static $h = 2088716;
                            static $f = 0b10000000000010000;
                            static $k = 1;
                            static $$md;
                            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":262145,"p":[{"n":"enumerator","p":(TKey, TValue) => $.$spc.System.Collections.Generic.Dictionary$$$(TKey, TValue).ValueCollection.Enumerator.$h,"f":4},{"n":"current","p":0,"f":2}],"g":["TKey","TValue"],"n":"MoveNext","d":2088716,"h":4297056012,"f":131112},{"r":65537,"p":[{"n":"enumerator","p":4298571776,"f":4}],"g":["TEnumerator"],"n":"Reset","d":2088716,"h":8592023308,"f":131112}],"d":2023180,"h":2088716}; }
                            static get $b() { return $.$spc.System.Object; }
                            static get $fullName() { return `System.Net.CredentialCache.CredentialEnumerator.DictionaryEnumeratorHelper`; }
                        }, $cls, ($v) => $cls.$_DictionaryEnumeratorHelper = $v);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.MoveNext()
                    System$Collections$IEnumerator$MoveNext()
                    {
                        return this.MoveNext(...arguments);
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Current.get
                    get System$Collections$IEnumerator$Current()
                    {
                        return this.Current;
                    }
                    //Generated interface implemetation for System.Collections.IEnumerator.Reset()
                    System$Collections$IEnumerator$Reset()
                    {
                        return this.Reset(...arguments);
                    }
                    static $h = 2023180;
                    static $f = 0b10000000000010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":131073,"g":{"r":0,"d":0,"h":34361761548,"f":1},"n":"Current","d":2023180,"h":30066794252,"f":1}],"m":[{"r":2023180,"p":[{"n":"cache","p":1957644}],"n":"Create","d":2023180,"h":4296990476,"f":40},{"r":262145,"n":"MoveNext","d":2023180,"h":38656728844,"f":1},{"r":262145,"p":[{"n":"current","p":3858188,"f":2}],"n":"MoveNext","o":"@$1","d":2023180,"h":42951696140,"f":132},{"r":65537,"n":"Reset","d":2023180,"h":47246663436,"f":129}],"l":[{"t":1957644,"n":"_cache","d":2023180,"h":8591957772,"f":2},{"t":655361,"n":"_version","d":2023180,"h":12886925068,"f":2},{"t":262145,"n":"_enumerating","d":2023180,"h":17181892364,"f":2},{"t":3858188,"n":"_current","d":2023180,"h":21476859660,"f":2}],"c":[{"p":[{"n":"cache","p":1957644}],"n":".ctor","o":"$ctor$1","d":2023180,"h":25771826956,"f":2}],"i":[31719425],"j":[2219788,2154252,2088716],"d":1957644,"h":2023180}; }
                    static get $b() { return $.$spc.System.Object; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.Collections.IEnumerator ]; }
                    static get $fullName() { return `System.Net.CredentialCache.CredentialEnumerator`; }
                }, $cls, ($v) => $cls.$_CredentialEnumerator = $v);
            }
            //Generated interface implemetation for System.Net.ICredentials.GetCredential(System.Uri, string)
            System$Net$ICredentials$GetCredential()
            {
                return this.GetCredential(...arguments);
            }
            //Generated interface implemetation for System.Net.ICredentialsByHost.GetCredential(string, int, string)
            System$Net$ICredentialsByHost$GetCredential()
            {
                return this.GetCredential$1(...arguments);
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 1957644;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":2940684,"g":{"r":0,"d":0,"h":55836532492,"f":33},"n":"DefaultCredentials","d":1957644,"h":51541565196,"f":33},{"p":3858188,"g":{"r":0,"d":0,"h":64426467084,"f":33},"n":"DefaultNetworkCredentials","d":1957644,"h":60131499788,"f":33}],"m":[{"r":65537,"p":[{"n":"uriPrefix","p":1744130},{"n":"authType","p":1310721},{"n":"cred","p":3858188}],"n":"Add","d":1957644,"h":21476794124,"f":1},{"r":65537,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"authenticationType","p":1310721},{"n":"credential","p":3858188}],"n":"Add","o":"@$1","d":1957644,"h":25771761420,"f":1},{"r":65537,"p":[{"n":"uriPrefix","p":1744130},{"n":"authType","p":1310721}],"n":"Remove","d":1957644,"h":30066728716,"f":1},{"r":65537,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"authenticationType","p":1310721}],"n":"Remove","o":"@$1","d":1957644,"h":34361696012,"f":1},{"r":3858188,"p":[{"n":"uriPrefix","p":1744130},{"n":"authType","p":1310721}],"n":"GetCredential","d":1957644,"h":38656663308,"f":1},{"r":3858188,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"authenticationType","p":1310721}],"n":"GetCredential","o":"@$1","d":1957644,"h":42951630604,"f":1},{"r":31719425,"n":"GetEnumerator","d":1957644,"h":47246597900,"f":1}],"l":[{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialCacheKey, $.$snp.System.Net.NetworkCredential).$h,"n":"_cache","d":1957644,"h":4296924940,"f":2},{"t":$.$spc.System.Collections.Generic.Dictionary$$$($.$snp.System.Net.CredentialHostKey, $.$snp.System.Net.NetworkCredential).$h,"n":"_cacheForHosts","d":1957644,"h":8591892236,"f":2},{"t":655361,"n":"_version","d":1957644,"h":12886859532,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1957644,"h":17181826828,"f":1}],"i":[2940684,3006220,31588353],"j":[2023180],"h":1957644}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$snp.System.Net.ICredentials, $.$snp.System.Net.ICredentialsByHost, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.CredentialCache`; }
        });
        
        $asm.$cls("$snp.System.Net.IPAddress", ($self) => class IPAddress extends $.$spc.System.Object
        {
            /*IPAddress*/ static Any = null;
            /*IPAddress*/ static Loopback = null;
            /*IPAddress*/ static Broadcast = null;
            /*IPAddress*/ static None = null;
            /*uint*/ static LoopbackMaskHostOrder = 4278190080;
            /*IPAddress*/ static IPv6Any = null;
            /*IPAddress*/ static IPv6Loopback = null;
            /*IPAddress*/ static IPv6None = null;
            /*IPAddress*/ static s_loopbackMappedToIPv6 = null;
            /*uint*/ _addressOrScopeId = 0;
            /*ushort[]?*/ _numbers = null;
            /*string?*/ _toString = null;
            /*int*/ _hashCode = 0;
            /*int*/ static NumberOfLabels = 8;
            /*bool */ get IsIPv4()
            {
                return this._numbers === null;
            }
            /*bool */ get IsIPv6()
            {
                return this._numbers !== null;
            }
            /*uint */ get PrivateAddress()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsIPv4, "IsIPv4");
                return this._addressOrScopeId;
            }
            /*uint */ set PrivateAddress(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsIPv4, "IsIPv4");
                this._toString = null;
                this._hashCode = 0;
                this._addressOrScopeId = value;
            }
            /*uint */ get PrivateIPv4Address()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsIPv4 || this.IsIPv4MappedToIPv6, "IsIPv4 || IsIPv4MappedToIPv6");
                if (this.IsIPv4)
                {
                    return this._addressOrScopeId;
                }
                /*uint*/ let address = ($.$spc.System.Array.$ReadT1.call(this._numbers, 6) << 16) >>> 0 | $.$spc.System.Array.$ReadT1.call(this._numbers, 7);
                return ($.$snp.System.Net.IPAddress.HostToNetworkOrder$1((address | 0)) >>> 0);
            }
            /*uint */ get PrivateScopeId()
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsIPv6, "IsIPv6");
                return this._addressOrScopeId;
            }
            /*uint */ set PrivateScopeId(value)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsIPv6, "IsIPv6");
                this._toString = null;
                this._hashCode = 0;
                this._addressOrScopeId = value;
            }
            $ctor$1(/*long*/ newAddress)
            {
                super.$ctor();
                {
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.UInt64, $.$cast(newAddress, $.$spc.System.UInt64), 4294967295n, "newAddress");
                    this.PrivateAddress = $.$cast(newAddress, $.$spc.System.UInt32);
                }
                return this;
            }
            $ctor$2(/*byte[]*/ address, /*long*/ scopeid)
            {
                this.$ctor$3(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2(address ?? $.$snp.System.Net.IPAddress.ThrowAddressNullException()), scopeid);
                {
                }
                return this;
            }
            $ctor$3(/*ReadOnlySpan<byte>*/ address, /*long*/ scopeid)
            {
                super.$ctor();
                {
                    if (address.Length !== 16/*IPAddressParserStatics.IPv6AddressBytes*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$snp.System.SR.dns_bad_ip_address, "address");
                    }
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.UInt64, $.$cast(scopeid, $.$spc.System.UInt64), 4294967295n, "scopeid");
                    this._numbers = $.$snp.System.Net.IPAddress.ReadUInt16NumbersFromBytes(address);
                    this.PrivateScopeId = $.$cast(scopeid, $.$spc.System.UInt32);
                }
                return this;
            }
            $ctor$4(/*ReadOnlySpan<ushort>*/ numbers, /*uint*/ scopeid)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(numbers.Length === 8/*NumberOfLabels*/, "numbers.Length == NumberOfLabels");
                    this._numbers = numbers.ToArray();
                    this.PrivateScopeId = scopeid;
                }
                return this;
            }
            $ctor$5(/*ushort[]*/ numbers, /*uint*/ scopeid)
            {
                super.$ctor();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(numbers !== null, "numbers != null");
                    $.$spc.System.Diagnostics.Debug.Assert$1(numbers.length === 8/*NumberOfLabels*/, "numbers.Length == NumberOfLabels");
                    this._numbers = numbers;
                    this.PrivateScopeId = scopeid;
                }
                return this;
            }
            $ctor$6(/*byte[]*/ address)
            {
                this.$ctor$7(new ($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte))().$ctor$2(address ?? $.$snp.System.Net.IPAddress.ThrowAddressNullException()));
                {
                }
                return this;
            }
            $ctor$7(/*ReadOnlySpan<byte>*/ address)
            {
                super.$ctor();
                {
                    if (address.Length === 4/*IPAddressParserStatics.IPv4AddressBytes*/)
                    {
                        this.PrivateAddress = $.$spc.System.Runtime.InteropServices.MemoryMarshal.Read($.$spc.System.UInt32, address);
                    }
                    else if (address.Length === 16/*IPAddressParserStatics.IPv6AddressBytes*/)
                    {
                        this._numbers = $.$snp.System.Net.IPAddress.ReadUInt16NumbersFromBytes(address);
                    }
                    else 
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$snp.System.SR.dns_bad_ip_address, "address");
                    }
                }
                return this;
            }
            static /*ushort[] */ ReadUInt16NumbersFromBytes(/*ReadOnlySpan<byte>*/ address)
            {
                /*ushort[]*/ let numbers = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt16), null, [8/*NumberOfLabels*/], null);
                //if (Vector128.IsHardwareAccelerated && BitConverter.IsLittleEndian) { ... }
                //else 
                {
                    for(/*int*/ let i = 0; i < numbers.length; i++)
                    {
                        $.$spc.System.Array.$WriteT1.call(numbers, $.$spc.System.Buffers.Binary.BinaryPrimitives.ReadUInt16BigEndian(address.Slice(((i * 2) | 0))), i);
                    }
                }
                return numbers;
            }
            $ctor$8(/*int*/ newAddress)
            {
                super.$ctor();
                {
                    this.PrivateAddress = (newAddress >>> 0);
                }
                return this;
            }
            static /*bool */ IsValid(/*ReadOnlySpan<char>*/ ipSpan)
            {
                return $.$snp.System.Net.IPAddressParser.IsValid($.$spc.System.Char, ipSpan);
            }
            static /*bool */ IsValidUtf8(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                return $.$snp.System.Net.IPAddressParser.IsValid($.$spc.System.Byte, utf8Text);
            }
            static /*bool */ TryParse(/*string?*/ ipString, /*out IPAddress?*/ address)
            {
                if ($.$spc.System.String.op_Equality(ipString, null))
                {
                    address.$v = null;
                    return false;
                }
                address.$v = $.$snp.System.Net.IPAddressParser.Parse($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(ipString), true);
                return (address.$v !== null);
            }
            static /*bool */ TryParse$1(/*ReadOnlySpan<byte>*/ utf8Text, /*out IPAddress?*/ result)
            {
                result.$v = $.$snp.System.Net.IPAddressParser.Parse($.$spc.System.Byte, utf8Text, true);
                return (result.$v !== null);
            }
            static /*bool */ TryParse$2(/*ReadOnlySpan<char>*/ ipSpan, /*out IPAddress?*/ address)
            {
                address.$v = $.$snp.System.Net.IPAddressParser.Parse($.$spc.System.Char, ipSpan, true);
                return (address.$v !== null);
            }
            static /*bool */ System$IUtf8SpanParsable$$$TryParse(/*ReadOnlySpan<byte>*/ utf8Text, /*IFormatProvider?*/ provider, /*out IPAddress?*/ result)
            {
                return $.$snp.System.Net.IPAddress.TryParse$1(utf8Text, result);
            }
            static /*bool */ System$IParsable$$$TryParse(/*string?*/ s, /*IFormatProvider?*/ provider, /*out IPAddress?*/ result)
            {
                return $.$snp.System.Net.IPAddress.TryParse(s, result);
            }
            static /*bool */ System$ISpanParsable$$$TryParse(/*ReadOnlySpan<char>*/ s, /*IFormatProvider?*/ provider, /*out IPAddress?*/ result)
            {
                return $.$snp.System.Net.IPAddress.TryParse$2(s, result);
            }
            static /*IPAddress */ Parse(/*string*/ ipString)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(ipString, "ipString");
                return $.$snp.System.Net.IPAddressParser.Parse($.$spc.System.Char, $.$spc.System.MemoryExtensions.AsSpan$3(ipString), false);
            }
            static /*IPAddress */ Parse$1(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                return $.$snp.System.Net.IPAddressParser.Parse($.$spc.System.Byte, utf8Text, false);
            }
            static /*IPAddress */ Parse$2(/*ReadOnlySpan<char>*/ ipSpan)
            {
                return $.$snp.System.Net.IPAddressParser.Parse($.$spc.System.Char, ipSpan, false);
            }
            static /*IPAddress */ System$IUtf8SpanParsable$$$Parse(/*ReadOnlySpan<byte>*/ utf8Text, /*IFormatProvider?*/ provider)
            {
                return $.$snp.System.Net.IPAddress.Parse$1(utf8Text);
            }
            static /*IPAddress */ System$ISpanParsable$$$Parse(/*ReadOnlySpan<char>*/ s, /*IFormatProvider?*/ provider)
            {
                return $.$snp.System.Net.IPAddress.Parse$2(s);
            }
            static /*IPAddress */ System$IParsable$$$Parse(/*string*/ s, /*IFormatProvider?*/ provider)
            {
                return $.$snp.System.Net.IPAddress.Parse(s);
            }
            /*bool */ TryWriteBytes(/*Span<byte>*/ destination, /*out int*/ bytesWritten)
            {
                if (this.IsIPv6)
                {
                    if (destination.Length < 16/*IPAddressParserStatics.IPv6AddressBytes*/)
                    {
                        bytesWritten.$v = 0;
                        return false;
                    }
                    this.WriteIPv6Bytes(destination);
                    bytesWritten.$v = 16/*IPAddressParserStatics.IPv6AddressBytes*/;
                }
                else 
                {
                    if (destination.Length < 4/*IPAddressParserStatics.IPv4AddressBytes*/)
                    {
                        bytesWritten.$v = 0;
                        return false;
                    }
                    this.WriteIPv4Bytes(destination);
                    bytesWritten.$v = 4/*IPAddressParserStatics.IPv4AddressBytes*/;
                }
                return true;
            }
            /*void */ WriteIPv6Bytes(/*Span<byte>*/ destination)
            {
                /*ushort[]?*/ let numbers = this._numbers;
                $.$spc.System.Diagnostics.Debug.Assert$1(numbers !== null && (numbers.length === 8/*NumberOfLabels*/), "numbers is { Length: NumberOfLabels }");
                if ($.$spc.System.BitConverter.IsLittleEndian)
                {
                    //if (Vector128.IsHardwareAccelerated) { ... }
                    //else 
                    {
                        for(/*int*/ let i = 0; i < numbers.length; i++)
                        {
                            $.$spc.System.Buffers.Binary.BinaryPrimitives.WriteUInt16BigEndian(destination.Slice(((i * 2) | 0)), $.$spc.System.Array.$ReadT1.call(numbers, i));
                        }
                    }
                }
                else 
                {
                    $.$spc.System.Runtime.InteropServices.MemoryMarshal.AsBytes$1($.$spc.System.UInt16, $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt16).op_Implicit(numbers)).CopyTo(destination);
                }
            }
            /*void */ WriteIPv4Bytes(/*Span<byte>*/ destination)
            {
                /*uint*/ let address = this.PrivateAddress;
                $.$spc.System.Runtime.InteropServices.MemoryMarshal.Write($.$spc.System.UInt32, destination, $.$ref(() => address, undefined, $.$spc.System.UInt32));
            }
            /*byte[] */ GetAddressBytes()
            {
                if (this.IsIPv6)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._numbers !== null && (this._numbers.length === 8/*NumberOfLabels*/), "_numbers is { Length: NumberOfLabels }");
                    /*byte[]*/ let bytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [16/*IPAddressParserStatics.IPv6AddressBytes*/], null);
                    this.WriteIPv6Bytes($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(bytes));
                    return bytes;
                }
                else 
                {
                    /*byte[]*/ let bytes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), null, [4/*IPAddressParserStatics.IPv4AddressBytes*/], null);
                    this.WriteIPv4Bytes($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit(bytes));
                    return bytes;
                }
            }
            /*AddressFamily */ get AddressFamily()
            {
                return this.IsIPv4 ? 2/*AddressFamily.InterNetwork*/ : 23/*AddressFamily.InterNetworkV6*/;
            }
            /*long */ get ScopeId()
            {
                if (this.IsIPv4)
                {
                    $.$snp.System.Net.IPAddress.ThrowSocketOperationNotSupported();
                }
                return BigInt(this.PrivateScopeId);
            }
            /*long */ set ScopeId(value)
            {
                if (this.IsIPv4)
                {
                    $.$snp.System.Net.IPAddress.ThrowSocketOperationNotSupported();
                }
                if ($.$is(this, $.$snp.System.Net.IPAddress.ReadOnlyIPAddress))
                {
                    $.$snp.System.Net.IPAddress.ThrowSocketOperationNotSupported();
                }
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int64, value, "value");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int64, value, 4294967295n, "value");
                this.PrivateScopeId = $.$cast(value, $.$spc.System.UInt32);
            }
            static/*conventional*/ /*string */ ToString()
            {
                /*string?*/ let toString = this._toString;
                if (toString === null)
                {
                    /*Span<char>*/ let span = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 65/*IPAddressParser.MaxIPv6StringLength*/, null);
                    /*int*/ let length = this.IsIPv4 ? $.$snp.System.Net.IPAddressParser.FormatIPv4Address($.$spc.System.Char, this._addressOrScopeId, span) : $.$snp.System.Net.IPAddressParser.FormatIPv6Address($.$spc.System.Char, this._numbers, this._addressOrScopeId, span);
                    this._toString = toString = $.$spc.System.String.Create($.$spc.System.Span$$($.$spc.System.Char).op_Implicit$2(span.Slice$1(0, length)));
                }
                return toString;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.IPAddress.ToString.apply(this, arguments); }
            /*string */ System$IFormattable$ToString(/*string?*/ format, /*IFormatProvider?*/ formatProvider)
            {
                return $.$snp.System.Net.IPAddress.ToString.call(this);
            }
            /*bool */ TryFormat(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                return this.TryFormatCore($.$spc.System.Char, destination, charsWritten);
            }
            /*bool */ TryFormat$1(/*Span<byte>*/ utf8Destination, /*out int*/ bytesWritten)
            {
                return this.TryFormatCore($.$spc.System.Byte, utf8Destination, bytesWritten);
            }
            /*bool */ System$ISpanFormattable$TryFormat(/*Span<char>*/ destination, /*out int*/ charsWritten, /*ReadOnlySpan<char>*/ format, /*IFormatProvider?*/ provider)
            {
                return this.TryFormatCore($.$spc.System.Char, destination, charsWritten);
            }
            /*bool */ System$IUtf8SpanFormattable$TryFormat(/*Span<byte>*/ utf8Destination, /*out int*/ bytesWritten, /*ReadOnlySpan<char>*/ format, /*IFormatProvider?*/ provider)
            {
                return this.TryFormatCore($.$spc.System.Byte, utf8Destination, bytesWritten);
            }
            /*bool */ TryFormatCore(TChar, /*Span<TChar>*/ destination, /*out int*/ charsWritten)
            {
                if (this.IsIPv4)
                {
                    if (destination.Length >= 15/*IPAddressParser.MaxIPv4StringLength*/)
                    {
                        charsWritten.$v = $.$snp.System.Net.IPAddressParser.FormatIPv4Address(TChar, this._addressOrScopeId, destination);
                        return true;
                    }
                }
                else 
                {
                    if (destination.Length >= 65/*IPAddressParser.MaxIPv6StringLength*/)
                    {
                        charsWritten.$v = $.$snp.System.Net.IPAddressParser.FormatIPv6Address(TChar, this._numbers, this._addressOrScopeId, destination);
                        return true;
                    }
                }
                /*Span<TChar>*/ let tmpDestination = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan(TChar, 65/*IPAddressParser.MaxIPv6StringLength*/, null);
                $.$spc.System.Diagnostics.Debug.Assert$1(tmpDestination.Length >= 15/*IPAddressParser.MaxIPv4StringLength*/, "tmpDestination.Length >= IPAddressParser.MaxIPv4StringLength");
                /*int*/ let written = this.IsIPv4 ? $.$snp.System.Net.IPAddressParser.FormatIPv4Address(TChar, this.PrivateAddress, tmpDestination) : $.$snp.System.Net.IPAddressParser.FormatIPv6Address(TChar, this._numbers, this.PrivateScopeId, tmpDestination);
                if (tmpDestination.Slice$1(0, written).TryCopyTo(destination))
                {
                    charsWritten.$v = written;
                    return true;
                }
                charsWritten.$v = 0;
                return false;
            }
            static /*long */ HostToNetworkOrder(/*long*/ host)
            {
                return $.$spc.System.BitConverter.IsLittleEndian ? $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$3(host) : host;
            }
            static /*int */ HostToNetworkOrder$1(/*int*/ host)
            {
                return $.$spc.System.BitConverter.IsLittleEndian ? $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$2(host) : host;
            }
            static /*short */ HostToNetworkOrder$2(/*short*/ host)
            {
                return $.$spc.System.BitConverter.IsLittleEndian ? $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$1(host) : host;
            }
            static /*long */ NetworkToHostOrder(/*long*/ network)
            {
                return $.$snp.System.Net.IPAddress.HostToNetworkOrder(network);
            }
            static /*int */ NetworkToHostOrder$1(/*int*/ network)
            {
                return $.$snp.System.Net.IPAddress.HostToNetworkOrder$1(network);
            }
            static /*short */ NetworkToHostOrder$2(/*short*/ network)
            {
                return $.$snp.System.Net.IPAddress.HostToNetworkOrder$2(network);
            }
            static /*bool */ IsLoopback(/*IPAddress*/ address)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(address, "address");
                if (address.IsIPv6)
                {
                    return address.Equals$2($.$snp.System.Net.IPAddress.IPv6Loopback) || address.Equals$2($.$snp.System.Net.IPAddress.s_loopbackMappedToIPv6);
                }
                else 
                {
                    /*long*/ let LoopbackMask = BigInt(($.$snp.System.Net.IPAddress.HostToNetworkOrder$1((4278190080/*LoopbackMaskHostOrder*/ | 0)) >>> 0));
                    return ((BigInt(address.PrivateAddress) & LoopbackMask) === (BigInt($.$snp.System.Net.IPAddress.Loopback.PrivateAddress) & LoopbackMask));
                }
            }
            /*bool */ get IsIPv6Multicast()
            {
                return this.IsIPv6 && (($.$spc.System.Array.$ReadT1.call(this._numbers, 0) & 65280) === 65280);
            }
            /*bool */ get IsIPv6LinkLocal()
            {
                return this.IsIPv6 && (($.$spc.System.Array.$ReadT1.call(this._numbers, 0) & 65472) === 65152);
            }
            /*bool */ get IsIPv6SiteLocal()
            {
                return this.IsIPv6 && (($.$spc.System.Array.$ReadT1.call(this._numbers, 0) & 65472) === 65216);
            }
            /*bool */ get IsIPv6Teredo()
            {
                return this.IsIPv6 && ($.$spc.System.Array.$ReadT1.call(this._numbers, 0) === 8193) && ($.$spc.System.Array.$ReadT1.call(this._numbers, 1) === 0);
            }
            /*bool */ get IsIPv6UniqueLocal()
            {
                return this.IsIPv6 && (($.$spc.System.Array.$ReadT1.call(this._numbers, 0) & 65024) === 64512);
            }
            /*bool */ get IsIPv4MappedToIPv6()
            {
                return !this.IsIPv4 && $.$spc.System.MemoryExtensions.SequenceEqual$1($.$spc.System.UInt16, $.$spc.System.Span$$($.$spc.System.UInt16).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.UInt16, this._numbers, 0, 6)), $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt16).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$spc.System.UInt16.$type, [ 0, 0, 0, 0, 0, 65535 ], null, null)));
            }
            /*long */ get Address()
            {
                if (this.AddressFamily === 23/*AddressFamily.InterNetworkV6*/)
                {
                    $.$snp.System.Net.IPAddress.ThrowSocketOperationNotSupported();
                }
                return BigInt(this.PrivateAddress);
            }
            /*long */ set Address(value)
            {
                if (this.AddressFamily === 23/*AddressFamily.InterNetworkV6*/)
                {
                    $.$snp.System.Net.IPAddress.ThrowSocketOperationNotSupported();
                }
                if (BigInt(this.PrivateAddress) !== value)
                {
                    if ($.$is(this, $.$snp.System.Net.IPAddress.ReadOnlyIPAddress))
                    {
                        $.$snp.System.Net.IPAddress.ThrowSocketOperationNotSupported();
                    }
                    this.PrivateAddress = $.$cast(value, $.$spc.System.UInt32);
                }
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                let address;
                return $.$is(comparand, $.$snp.System.Net.IPAddress, { set $v(v){ address = v; } }) && this.Equals$2(address);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snp.System.Net.IPAddress.Equals.apply(this, arguments); }
            /*bool */ Equals$2(/*IPAddress*/ comparand)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(comparand !== null, "comparand != null");
                if (this.AddressFamily !== comparand.AddressFamily)
                {
                    return false;
                }
                if (this.IsIPv6)
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(this._numbers.length === 8/*IPAddressParserStatics.IPv6AddressShorts*/, "_numbers.Length == IPAddressParserStatics.IPv6AddressShorts");
                    $.$spc.System.Diagnostics.Debug.Assert$1(comparand._numbers.length === 8/*IPAddressParserStatics.IPv6AddressShorts*/, "comparand._numbers.Length == IPAddressParserStatics.IPv6AddressShorts");
                    /*ReadOnlySpan<ushort>*/ let left = $.$spc.System.Span$$($.$spc.System.UInt16).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.UInt16, this._numbers, 0, 8/*IPAddressParserStatics.IPv6AddressShorts*/));
                    /*ReadOnlySpan<ushort>*/ let right = $.$spc.System.Span$$($.$spc.System.UInt16).op_Implicit$2($.$spc.System.MemoryExtensions.AsSpan$9($.$spc.System.UInt16, comparand._numbers, 0, 8/*IPAddressParserStatics.IPv6AddressShorts*/));
                    return $.$spc.System.MemoryExtensions.SequenceEqual$1($.$spc.System.UInt16, left, right) && this.PrivateScopeId === comparand.PrivateScopeId;
                }
                return comparand.PrivateAddress === this.PrivateAddress;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                if (this._hashCode === 0)
                {
                    if (this.IsIPv6)
                    {
                        /*ReadOnlySpan<byte>*/ let numbers = $.$spc.System.Runtime.InteropServices.MemoryMarshal.AsBytes$1($.$spc.System.UInt16, $.$spc.System.ReadOnlySpan$$($.$spc.System.UInt16).op_Implicit(this._numbers));
                        this._hashCode = $.$spc.System.HashCode.Combine$4($.$spc.System.UInt32, $.$spc.System.UInt32, $.$spc.System.UInt32, $.$spc.System.UInt32, $.$spc.System.UInt32, $.$spc.System.Runtime.InteropServices.MemoryMarshal.Read($.$spc.System.UInt32, numbers), $.$spc.System.Runtime.InteropServices.MemoryMarshal.Read($.$spc.System.UInt32, numbers.Slice(4)), $.$spc.System.Runtime.InteropServices.MemoryMarshal.Read($.$spc.System.UInt32, numbers.Slice(8)), $.$spc.System.Runtime.InteropServices.MemoryMarshal.Read($.$spc.System.UInt32, numbers.Slice(12)), this._addressOrScopeId);
                    }
                    else 
                    {
                        this._hashCode = $.$spc.System.HashCode.Combine($.$spc.System.UInt32, this._addressOrScopeId);
                    }
                }
                return this._hashCode;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snp.System.Net.IPAddress.GetHashCode.apply(this, arguments); }
            /*IPAddress */ MapToIPv6()
            {
                if (this.IsIPv6)
                {
                    return this;
                }
                /*uint*/ let address = ($.$snp.System.Net.IPAddress.NetworkToHostOrder$1((this.PrivateAddress | 0)) >>> 0);
                /*ushort[]*/ let labels = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.UInt16), null, [8/*NumberOfLabels*/], null);
                $.$spc.System.Array.$WriteT1.call(labels, 65535, 5);
                $.$spc.System.Array.$WriteT1.call(labels, $.$cast((address >>> 16), $.$spc.System.UInt16), 6);
                $.$spc.System.Array.$WriteT1.call(labels, $.$cast(address, $.$spc.System.UInt16), 7);
                return new $.$snp.System.Net.IPAddress().$ctor$5(labels, 0);
            }
            /*IPAddress */ MapToIPv4()
            {
                if (this.IsIPv4)
                {
                    return this;
                }
                /*uint*/ let address = ($.$spc.System.Array.$ReadT1.call(this._numbers, 6) << 16) >>> 0 | $.$spc.System.Array.$ReadT1.call(this._numbers, 7);
                return new $.$snp.System.Net.IPAddress().$ctor$1(BigInt(($.$snp.System.Net.IPAddress.HostToNetworkOrder$1((address | 0)) >>> 0)));
            }
            static /*byte[] */ ThrowAddressNullException()
            {
                throw new $.$spc.System.ArgumentNullException().$ctor$16("address");
            }
            static /*void */ ThrowSocketOperationNotSupported()
            {
                throw new $.$snp.System.Net.Sockets.SocketException().$ctor$22(10045/*SocketError.OperationNotSupported*/);
            }
            static $_ReadOnlyIPAddress;
            static get ReadOnlyIPAddress()
            {
                let $cls = $.$snp.System.Net.IPAddress;
                return $cls.$_ReadOnlyIPAddress ??= $asm.$ncls("$snp.System.Net.IPAddress.ReadOnlyIPAddress", ($self) => class ReadOnlyIPAddress extends $.$snp.System.Net.IPAddress
                {
                    $ctor$9(/*ReadOnlySpan<byte>*/ newAddress)
                    {
                        super.$ctor$7(newAddress);
                        {
                        }
                        return this;
                    }
                    $ctor$10(/*ReadOnlySpan<byte>*/ address, /*long*/ scopeid)
                    {
                        super.$ctor$3(address, scopeid);
                        {
                        }
                        return this;
                    }
                    static $h = 3137292;
                    static $f = 0b10000000010010000;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":3071756,"c":[{"p":[{"n":"newAddress","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":".ctor","o":"$ctor$9","d":3137292,"h":4298104588,"f":1},{"p":[{"n":"address","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"scopeid","p":917505}],"n":".ctor","o":"$ctor$10","d":3137292,"h":8593071884,"f":1}],"i":[63766529,57671681,$.$spc.System.ISpanParsable$$($.$snp.System.Net.IPAddress).$h,$.$spc.System.IParsable$$($.$snp.System.Net.IPAddress).$h,64094209,$.$spc.System.IUtf8SpanParsable$$($.$snp.System.Net.IPAddress).$h],"d":3071756,"h":3137292}; }
                    static get $b() { return $.$snp.System.Net.IPAddress; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.ISpanParsable$$($.$snp.System.Net.IPAddress), $.$spc.System.IParsable$$($.$snp.System.Net.IPAddress), $.$spc.System.IUtf8SpanFormattable, $.$spc.System.IUtf8SpanParsable$$($.$snp.System.Net.IPAddress) ]; }
                    static get $fullName() { return `System.Net.IPAddress.ReadOnlyIPAddress`; }
                }, $cls, ($v) => $cls.$_ReadOnlyIPAddress = $v);
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Any = new $.$snp.System.Net.IPAddress.ReadOnlyIPAddress().$ctor$9($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), [0, 0, 0, 0], null, null)));
                }
                {
                    this.Loopback = new $.$snp.System.Net.IPAddress.ReadOnlyIPAddress().$ctor$9($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), [127, 0, 0, 1], null, null)));
                }
                {
                    this.Broadcast = new $.$snp.System.Net.IPAddress.ReadOnlyIPAddress().$ctor$9($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), [255, 255, 255, 255], null, null)));
                }
                {
                    this.None = $.$snp.System.Net.IPAddress.Broadcast;
                }
                {
                    this.IPv6Any = new $.$snp.System.Net.IPAddress.ReadOnlyIPAddress().$ctor$10($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], null, null)), 0n);
                }
                {
                    this.IPv6Loopback = new $.$snp.System.Net.IPAddress.ReadOnlyIPAddress().$ctor$10($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1], null, null)), 0n);
                }
                {
                    this.IPv6None = $.$snp.System.Net.IPAddress.IPv6Any;
                }
                {
                    this.s_loopbackMappedToIPv6 = new $.$snp.System.Net.IPAddress.ReadOnlyIPAddress().$ctor$10($.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).op_Implicit($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.Byte), [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 255, 255, 127, 0, 0, 1], null, null)), 0n);
                }
            }
            static $h = 3071756;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":68722548492,"f":2},"n":"IsIPv4","d":3071756,"h":64427581196,"f":2},{"p":262145,"g":{"r":0,"d":0,"h":77312483084,"f":2},"n":"IsIPv6","d":3071756,"h":73017515788,"f":2},{"p":720897,"g":{"r":0,"d":0,"h":85902417676,"f":8},"s":{"r":0,"d":0,"h":90197384972,"f":2},"n":"PrivateAddress","d":3071756,"h":81607450380,"f":8},{"p":720897,"g":{"r":0,"d":0,"h":98787319564,"f":8},"n":"PrivateIPv4Address","d":3071756,"h":94492352268,"f":8},{"p":720897,"g":{"r":0,"d":0,"h":107377254156,"f":2},"s":{"r":0,"d":0,"h":111672221452,"f":2},"n":"PrivateScopeId","d":3071756,"h":103082286860,"f":2},{"p":4513548,"g":{"r":0,"d":0,"h":236226273036,"f":1},"n":"AddressFamily","d":3071756,"h":231931305740,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":244816207628,"f":1},"s":{"r":0,"d":0,"h":249111174924,"f":1},"n":"ScopeId","d":3071756,"h":240521240332,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":317830651660,"f":1},"n":"IsIPv6Multicast","d":3071756,"h":313535684364,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":326420586252,"f":1},"n":"IsIPv6LinkLocal","d":3071756,"h":322125618956,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":335010520844,"f":1},"n":"IsIPv6SiteLocal","d":3071756,"h":330715553548,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":343600455436,"f":1},"n":"IsIPv6Teredo","d":3071756,"h":339305488140,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":352190390028,"f":1},"n":"IsIPv6UniqueLocal","d":3071756,"h":347895422732,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":360780324620,"f":1},"n":"IsIPv4MappedToIPv6","d":3071756,"h":356485357324,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":369370259212,"f":1},"s":{"r":0,"d":0,"h":373665226508,"f":1},"n":"Address","d":3071756,"h":365075291916,"f":1,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"IPAddress.Address is address family dependent and has been deprecated. Use IPAddress.Equals to perform comparisons instead.","t":1310721}]}]}],"m":[{"r":0,"p":[{"n":"address","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"ReadUInt16NumbersFromBytes","d":3071756,"h":146031959820,"f":34},{"r":262145,"p":[{"n":"ipSpan","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"IsValid","d":3071756,"h":154621894412,"f":33},{"r":262145,"p":[{"n":"utf8Text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"IsValidUtf8","d":3071756,"h":158916861708,"f":33},{"r":262145,"p":[{"n":"ipString","p":1310721},{"n":"address","p":3071756,"f":2}],"n":"TryParse","d":3071756,"h":163211829004,"f":33},{"r":262145,"p":[{"n":"utf8Text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"result","p":3071756,"f":2}],"n":"TryParse","o":"@$1","d":3071756,"h":167506796300,"f":33},{"r":262145,"p":[{"n":"ipSpan","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"address","p":3071756,"f":2}],"n":"TryParse","o":"@$2","d":3071756,"h":171801763596,"f":33},{"r":3071756,"p":[{"n":"ipString","p":1310721}],"n":"Parse","d":3071756,"h":188981632780,"f":33},{"r":3071756,"p":[{"n":"utf8Text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Parse","o":"@$1","d":3071756,"h":193276600076,"f":33},{"r":3071756,"p":[{"n":"ipSpan","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Parse","o":"@$2","d":3071756,"h":197571567372,"f":33},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryWriteBytes","d":3071756,"h":214751436556,"f":1},{"r":65537,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"WriteIPv6Bytes","d":3071756,"h":219046403852,"f":2},{"r":65537,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"WriteIPv4Bytes","d":3071756,"h":223341371148,"f":2},{"r":0,"n":"GetAddressBytes","d":3071756,"h":227636338444,"f":1},{"r":1310721,"n":"ToString","d":3071756,"h":253406142220,"f":32769},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryFormat","d":3071756,"h":261996076812,"f":1},{"r":262145,"p":[{"n":"utf8Destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryFormat","o":"@$1","d":3071756,"h":266291044108,"f":1},{"r":262145,"p":[{"n":"destination","p":(TChar) => $.$spc.System.Span$$(TChar).$h},{"n":"charsWritten","p":655361,"f":2}],"g":["TChar"],"n":"TryFormatCore","d":3071756,"h":279175945996,"f":131074},{"r":917505,"p":[{"n":"host","p":917505}],"n":"HostToNetworkOrder","d":3071756,"h":283470913292,"f":33},{"r":655361,"p":[{"n":"host","p":655361}],"n":"HostToNetworkOrder","o":"@$1","d":3071756,"h":287765880588,"f":33},{"r":524289,"p":[{"n":"host","p":524289}],"n":"HostToNetworkOrder","o":"@$2","d":3071756,"h":292060847884,"f":33},{"r":917505,"p":[{"n":"network","p":917505}],"n":"NetworkToHostOrder","d":3071756,"h":296355815180,"f":33},{"r":655361,"p":[{"n":"network","p":655361}],"n":"NetworkToHostOrder","o":"@$1","d":3071756,"h":300650782476,"f":33},{"r":524289,"p":[{"n":"network","p":524289}],"n":"NetworkToHostOrder","o":"@$2","d":3071756,"h":304945749772,"f":33},{"r":262145,"p":[{"n":"address","p":3071756}],"n":"IsLoopback","d":3071756,"h":309240717068,"f":33},{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":3071756,"h":377960193804,"f":32769},{"r":262145,"p":[{"n":"comparand","p":3071756}],"n":"Equals","o":"@$2","d":3071756,"h":382255161100,"f":8},{"r":655361,"n":"GetHashCode","d":3071756,"h":386550128396,"f":32769},{"r":3071756,"n":"MapToIPv6","d":3071756,"h":390845095692,"f":1},{"r":3071756,"n":"MapToIPv4","d":3071756,"h":395140062988,"f":1},{"r":0,"n":"ThrowAddressNullException","d":3071756,"h":399435030284,"f":34},{"r":65537,"n":"ThrowSocketOperationNotSupported","d":3071756,"h":403729997580,"f":34}],"l":[{"t":3071756,"n":"Any","d":3071756,"h":4298039052,"f":33},{"t":3071756,"n":"Loopback","d":3071756,"h":8593006348,"f":33},{"t":3071756,"n":"Broadcast","d":3071756,"h":12887973644,"f":33},{"t":3071756,"n":"None","d":3071756,"h":17182940940,"f":33},{"t":720897,"n":"LoopbackMaskHostOrder","d":3071756,"h":21477908236,"f":40},{"t":3071756,"n":"IPv6Any","d":3071756,"h":25772875532,"f":33},{"t":3071756,"n":"IPv6Loopback","d":3071756,"h":30067842828,"f":33},{"t":3071756,"n":"IPv6None","d":3071756,"h":34362810124,"f":33},{"t":3071756,"n":"s_loopbackMappedToIPv6","d":3071756,"h":38657777420,"f":34},{"t":720897,"n":"_addressOrScopeId","d":3071756,"h":42952744716,"f":2},{"t":0,"n":"_numbers","d":3071756,"h":47247712012,"f":2},{"t":1310721,"n":"_toString","d":3071756,"h":51542679308,"f":2},{"t":655361,"n":"_hashCode","d":3071756,"h":55837646604,"f":2},{"t":655361,"n":"NumberOfLabels","d":3071756,"h":60132613900,"f":40}],"c":[{"p":[{"n":"newAddress","p":917505}],"n":".ctor","o":"$ctor$1","d":3071756,"h":115967188748,"f":1},{"p":[{"n":"address","p":0},{"n":"scopeid","p":917505}],"n":".ctor","o":"$ctor$2","d":3071756,"h":120262156044,"f":1},{"p":[{"n":"address","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"scopeid","p":917505}],"n":".ctor","o":"$ctor$3","d":3071756,"h":124557123340,"f":1},{"p":[{"n":"numbers","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.UInt16).$h},{"n":"scopeid","p":720897}],"n":".ctor","o":"$ctor$4","d":3071756,"h":128852090636,"f":8},{"p":[{"n":"numbers","p":0},{"n":"scopeid","p":720897}],"n":".ctor","o":"$ctor$5","d":3071756,"h":133147057932,"f":2},{"p":[{"n":"address","p":0}],"n":".ctor","o":"$ctor$6","d":3071756,"h":137442025228,"f":1},{"p":[{"n":"address","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":".ctor","o":"$ctor$7","d":3071756,"h":141736992524,"f":1},{"p":[{"n":"newAddress","p":655361}],"n":".ctor","o":"$ctor$8","d":3071756,"h":150326927116,"f":8}],"i":[63766529,57671681,$.$spc.System.ISpanParsable$$($.$snp.System.Net.IPAddress).$h,$.$spc.System.IParsable$$($.$snp.System.Net.IPAddress).$h,64094209,$.$spc.System.IUtf8SpanParsable$$($.$snp.System.Net.IPAddress).$h],"j":[3137292],"h":3071756}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.ISpanParsable$$($.$snp.System.Net.IPAddress), $.$spc.System.IParsable$$($.$snp.System.Net.IPAddress), $.$spc.System.IUtf8SpanFormattable, $.$spc.System.IUtf8SpanParsable$$($.$snp.System.Net.IPAddress) ]; }
            static get $fullName() { return `System.Net.IPAddress`; }
        });
        
        $asm.$str("$snp.System.Net.HeaderVariantInfo", ($self) => class HeaderVariantInfo extends $.$spc.System.ValueType
        {
            /*string*/  get _name() { return this.$getField(0, 4); }
            /*string*/  set _name(value) { this.$setField(0, 4, value); }
            /*CookieVariant*/  get _variant() { return this.$getField(4, 4); }
            /*CookieVariant*/  set _variant(value) { this.$setField(4, 4, value); }
            $ctor$2(/*string*/ name, /*CookieVariant*/ variant)
            {
                super.$ctor$1();
                {
                    this._name = name;
                    this._variant = variant;
                }
                return this;
            }
            /*string */ get Name()
            {
                return this._name;
            }
            /*CookieVariant */ get Variant()
            {
                return this._variant;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._name = this._name;
                copy._variant = this._variant;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._name = null;
                this._variant = 0;
            }
            static $h = 2678540;
            static $z = 8;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21477515020,"f":8},"n":"Name","d":2678540,"h":17182547724,"f":8},{"p":1892108,"g":{"r":0,"d":0,"h":30067449612,"f":8},"n":"Variant","d":2678540,"h":25772482316,"f":8}],"l":[{"t":1310721,"n":"_name","d":2678540,"h":4297645836,"f":2},{"t":1892108,"n":"_variant","d":2678540,"h":8592613132,"f":2}],"c":[{"p":[{"n":"name","p":1310721},{"n":"variant","p":1892108}],"n":".ctor","o":"$ctor$2","d":2678540,"h":12887580428,"f":8},{"n":".ctor","o":"$ctor$3","d":2678540,"h":34362416908,"f":1}],"h":2678540}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.HeaderVariantInfo`; }
        });
        
        $asm.$cls("$snp.System.Net.DnsEndPoint", ($self) => class DnsEndPoint extends $.$snp.System.Net.EndPoint
        {
            /*string*/ _host = null;
            /*int*/ _port = 0;
            /*AddressFamily*/ _family = 0;
            $ctor$2(/*string*/ host, /*int*/ port)
            {
                this.$ctor$3(host, port, 0/*AddressFamily.Unspecified*/);
                {
                }
                return this;
            }
            $ctor$3(/*string*/ host, /*int*/ port, /*AddressFamily*/ addressFamily)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentException.ThrowIfNullOrEmpty(host, "host");
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfLessThan($.$spc.System.Int32, port, 0/*IPEndPoint.MinPort*/, "port");
                    $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThan($.$spc.System.Int32, port, 65535/*IPEndPoint.MaxPort*/, "port");
                    if (addressFamily !== 2/*AddressFamily.InterNetwork*/ && addressFamily !== 23/*AddressFamily.InterNetworkV6*/ && addressFamily !== 0/*AddressFamily.Unspecified*/)
                    {
                        throw new $.$spc.System.ArgumentException().$ctor$13($.$snp.System.SR.net_sockets_invalid_optionValue_all, "addressFamily");
                    }
                    this._host = host;
                    this._port = port;
                    this._family = addressFamily;
                }
                return this;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                let dnsComparand;
                return $.$is(comparand, $.$snp.System.Net.DnsEndPoint, { set $v(v){ dnsComparand = v; } }) && this._family === dnsComparand._family && this._port === dnsComparand._port && $.$spc.System.StringComparer.OrdinalIgnoreCase.Equals$3(this._host, dnsComparand._host);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snp.System.Net.DnsEndPoint.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$2($.$spc.System.Int32, $.$spc.System.Int32, $.$spc.System.Int32, this._family, this._port, $.$spc.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(this._host));
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snp.System.Net.DnsEndPoint.GetHashCode.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return `${this._family}/${this._host}:${this._port}`;
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.DnsEndPoint.ToString.apply(this, arguments); }
            /*string */ get Host()
            {
                return this._host;
            }
            /*AddressFamily */ get AddressFamily()
            {
                return this._family;
            }
            /*int */ get Port()
            {
                return this._port;
            }
            static $h = 2547468;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2613004,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":42952220428,"f":1},"n":"Host","d":2547468,"h":38657253132,"f":1},{"p":4513548,"g":{"r":0,"d":0,"h":51542155020,"f":32769},"n":"AddressFamily","d":2547468,"h":47247187724,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":60132089612,"f":1},"n":"Port","d":2547468,"h":55837122316,"f":1}],"m":[{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":2547468,"h":25772351244,"f":32769},{"r":655361,"n":"GetHashCode","d":2547468,"h":30067318540,"f":32769},{"r":1310721,"n":"ToString","d":2547468,"h":34362285836,"f":32769}],"l":[{"t":1310721,"n":"_host","d":2547468,"h":4297514764,"f":2},{"t":655361,"n":"_port","d":2547468,"h":8592482060,"f":2},{"t":4513548,"n":"_family","d":2547468,"h":12887449356,"f":2}],"c":[{"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$2","d":2547468,"h":17182416652,"f":1},{"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"addressFamily","p":4513548}],"n":".ctor","o":"$ctor$3","d":2547468,"h":21477383948,"f":1}],"h":2547468}; }
            static get $b() { return $.$snp.System.Net.EndPoint; }
            static get $fullName() { return `System.Net.DnsEndPoint`; }
        });
        
        $asm.$str("$snp.System.Net.CookieTokenizer", ($self) => class CookieTokenizer extends $.$spc.System.ValueType
        {
            /*bool*/  get _eofCookie() { return this.$getField(0, 1); }
            /*bool*/  set _eofCookie(value) { this.$setField(0, 1, value); }
            /*int*/  get _index() { return this.$getField(1, 4); }
            /*int*/  set _index(value) { this.$setField(1, 4, value); }
            /*int*/  get _length() { return this.$getField(5, 4); }
            /*int*/  set _length(value) { this.$setField(5, 4, value); }
            /*string?*/  get _name() { return this.$getField(9, 4); }
            /*string?*/  set _name(value) { this.$setField(9, 4, value); }
            /*bool*/  get _quoted() { return this.$getField(13, 1); }
            /*bool*/  set _quoted(value) { this.$setField(13, 1, value); }
            /*int*/  get _start() { return this.$getField(14, 4); }
            /*int*/  set _start(value) { this.$setField(14, 4, value); }
            /*CookieToken*/  get _token() { return this.$getField(18, 4); }
            /*CookieToken*/  set _token(value) { this.$setField(18, 4, value); }
            /*int*/  get _tokenLength() { return this.$getField(22, 4); }
            /*int*/  set _tokenLength(value) { this.$setField(22, 4, value); }
            /*string*/  get _tokenStream() { return this.$getField(26, 4); }
            /*string*/  set _tokenStream(value) { this.$setField(26, 4, value); }
            /*string*/  get _value() { return this.$getField(30, 4); }
            /*string*/  set _value(value) { this.$setField(30, 4, value); }
            /*int*/  get _cookieStartIndex() { return this.$getField(34, 4); }
            /*int*/  set _cookieStartIndex(value) { this.$setField(34, 4, value); }
            /*int*/  get _cookieLength() { return this.$getField(38, 4); }
            /*int*/  set _cookieLength(value) { this.$setField(38, 4, value); }
            $ctor$2(/*string*/ tokenStream)
            {
                this.$ctor$3();
                {
                    this._length = tokenStream.length;
                    this._tokenStream = tokenStream;
                    this._value = $.$spc.System.String.Empty;
                }
                return this;
            }
            /*bool */ get EndOfCookie()
            {
                return this._eofCookie;
            }
            /*bool */ set EndOfCookie(value)
            {
                this._eofCookie = value;
            }
            /*bool */ get Eof()
            {
                return this._index >= this._length;
            }
            /*string? */ get Name()
            {
                return this._name;
            }
            /*string? */ set Name(value)
            {
                this._name = value;
            }
            /*bool */ get Quoted()
            {
                return this._quoted;
            }
            /*bool */ set Quoted(value)
            {
                this._quoted = value;
            }
            /*CookieToken */ get Token()
            {
                return this._token;
            }
            /*CookieToken */ set Token(value)
            {
                this._token = value;
            }
            /*string */ get Value()
            {
                return this._value;
            }
            /*string */ set Value(value)
            {
                this._value = value;
            }
            /*string */ Extract()
            {
                /*string*/ let tokenString = $.$spc.System.String.Empty;
                if (this._tokenLength !== 0)
                {
                    tokenString = this.Quoted ? $.$spc.System.String.Substring$1.call(this._tokenStream, this._start, this._tokenLength) : $.$spc.System.ReadOnlySpan$$($.$spc.System.Char).ToString.call($.$spc.System.MemoryExtensions.Trim$10($.$spc.System.MemoryExtensions.AsSpan$7(this._tokenStream, this._start, this._tokenLength)));
                }
                return tokenString;
            }
            /*CookieToken */ FindNext(/*bool*/ ignoreComma, /*bool*/ ignoreEquals)
            {
                this._tokenLength = 0;
                this._start = this._index;
                while((this._index < this._length) && $.$spc.System.Char.IsWhiteSpace($.$spc.System.String.get_Chars.call(this._tokenStream, this._index)))
                {
                    ++this._index;
                    ++this._start;
                }
                /*CookieToken*/ let token = 5/*CookieToken.End*/;
                /*int*/ let increment = 1;
                if (!this.Eof)
                {
                    if ($.$spc.System.String.get_Chars.call(this._tokenStream, this._index) === /*\"*/ 34)
                    {
                        this.Quoted = true;
                        ++this._index;
                        /*bool*/ let quoteOn = false;
                        while(this._index < this._length)
                        {
                            /*char*/ let currChar = $.$spc.System.String.get_Chars.call(this._tokenStream, this._index);
                            if (!quoteOn && currChar === /*\"*/ 34)
                            {
                                break;
                            }
                            if (quoteOn)
                            {
                                quoteOn = false;
                            }
                            else if (currChar === /*\\*/ 92)
                            {
                                quoteOn = true;
                            }
                            ++this._index;
                        }
                        if (this._index < this._length)
                        {
                            ++this._index;
                        }
                        this._tokenLength = ((this._index - this._start) | 0);
                        increment = 0;
                        ignoreComma = false;
                    }
                    while((this._index < this._length) && ($.$spc.System.String.get_Chars.call(this._tokenStream, this._index) !== /*;*/ 59) && (ignoreEquals || ($.$spc.System.String.get_Chars.call(this._tokenStream, this._index) !== /*=*/ 61)) && (ignoreComma || ($.$spc.System.String.get_Chars.call(this._tokenStream, this._index) !== /*,*/ 44)))
                    {
                        if ($.$spc.System.String.get_Chars.call(this._tokenStream, this._index) === /*,*/ 44)
                        {
                            this._start = ((this._index + 1) | 0);
                            this._tokenLength = -1;
                            ignoreComma = false;
                        }
                        ++this._index;
                        this._tokenLength += increment;
                    }
                    if (!this.Eof)
                    {
                        let $switch1 = $.$spc.System.String.get_Chars.call(this._tokenStream, this._index);
                        switch($switch1)
                        {
                            case /*;*/ 59:
                            token = 3/*CookieToken.EndToken*/;
                            break;
                            case /*=*/ 61:
                            token = 6/*CookieToken.Equals*/;
                            break;
                            default:
                            this._cookieLength = ((this._index - this._cookieStartIndex) | 0);
                            token = 4/*CookieToken.EndCookie*/;
                            break;
                        }
                        ++this._index;
                    }
                    if (this.Eof)
                    {
                        this._cookieLength = ((this._index - this._cookieStartIndex) | 0);
                    }
                }
                return token;
            }
            /*CookieToken */ Next(/*bool*/ first, /*bool*/ parseResponseCookies)
            {
                this.Reset();
                if (first)
                {
                    this._cookieStartIndex = this._index;
                    this._cookieLength = 0;
                }
                /*CookieToken*/ let terminator = this.FindNext(false, false);
                if (terminator === 4/*CookieToken.EndCookie*/)
                {
                    this.EndOfCookie = true;
                }
                if ((terminator === 5/*CookieToken.End*/) || (terminator === 4/*CookieToken.EndCookie*/))
                {
                    if ((this.Name = this.Extract()).length !== 0)
                    {
                        this.Token = this.TokenFromName(parseResponseCookies);
                        return 2/*CookieToken.Attribute*/;
                    }
                    return terminator;
                }
                this.Name = this.Extract();
                if (first)
                {
                    this.Token = 9/*CookieToken.CookieName*/;
                }
                else 
                {
                    this.Token = this.TokenFromName(parseResponseCookies);
                }
                if (terminator === 6/*CookieToken.Equals*/)
                {
                    terminator = this.FindNext(!first && (this.Token === 12/*CookieToken.Expires*/), true);
                    if (terminator === 4/*CookieToken.EndCookie*/)
                    {
                        this.EndOfCookie = true;
                    }
                    this.Value = this.Extract();
                    return 1/*CookieToken.NameValuePair*/;
                }
                else 
                {
                    return 2/*CookieToken.Attribute*/;
                }
            }
            /*void */ Reset()
            {
                this._eofCookie = false;
                this._name = $.$spc.System.String.Empty;
                this._quoted = false;
                this._start = this._index;
                this._token = 0/*CookieToken.Nothing*/;
                this._tokenLength = 0;
                this._value = $.$spc.System.String.Empty;
            }
            static $_RecognizedAttribute;
            static get RecognizedAttribute()
            {
                let $cls = $.$snp.System.Net.CookieTokenizer;
                return $cls.$_RecognizedAttribute ??= $asm.$nstr("$snp.System.Net.CookieTokenizer.RecognizedAttribute", ($self) => class RecognizedAttribute extends $.$spc.System.ValueType
                {
                    /*string*/  get _name() { return this.$getField(0, 4); }
                    /*string*/  set _name(value) { this.$setField(0, 4, value); }
                    /*CookieToken*/  get _token() { return this.$getField(4, 4); }
                    /*CookieToken*/  set _token(value) { this.$setField(4, 4, value); }
                    $ctor$2(/*string*/ name, /*CookieToken*/ token)
                    {
                        super.$ctor$1();
                        {
                            this._name = name;
                            this._token = token;
                        }
                        return this;
                    }
                    /*CookieToken */ get Token()
                    {
                        return this._token;
                    }
                    /*bool */ IsEqualTo(/*string?*/ value)
                    {
                        return $.$spc.System.String.Equals$5(this._name, value, 5/*StringComparison.OrdinalIgnoreCase*/);
                    }
                    //default value type constructor
                    $ctor$3()
                    {
                        return this;
                    }
                    Clone($copy)
                    {
                        let copy = $copy ?? new this.constructor();
                        copy._name = this._name;
                        copy._token = this._token;
                        return copy;
                    }
                    //default member initializer
                    constructor()
                    {
                        super();
                        this._name = null;
                        this._token = 0;
                    }
                    static $h = 1826572;
                    static $z = 8;
                    static $f = 0b10000001010000000;
                    static $k = 2;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1695500,"g":{"r":0,"d":0,"h":21476663052,"f":8},"n":"Token","d":1826572,"h":17181695756,"f":8}],"m":[{"r":262145,"p":[{"n":"value","p":1310721}],"n":"IsEqualTo","d":1826572,"h":25771630348,"f":8}],"l":[{"t":1310721,"n":"_name","d":1826572,"h":4296793868,"f":2},{"t":1695500,"n":"_token","d":1826572,"h":8591761164,"f":2}],"c":[{"p":[{"n":"name","p":1310721},{"n":"token","p":1695500}],"n":".ctor","o":"$ctor$2","d":1826572,"h":12886728460,"f":8},{"n":".ctor","o":"$ctor$3","d":1826572,"h":30066597644,"f":1}],"d":1761036,"h":1826572}; }
                    static get $b() { return $.$spc.System.ValueType; }
                    static get $fullName() { return `System.Net.CookieTokenizer.RecognizedAttribute`; }
                }, $cls, ($v) => $cls.$_RecognizedAttribute = $v);
            }
            /*RecognizedAttribute[]*/ static s_recognizedAttributes = null;
            /*RecognizedAttribute[]*/ static s_recognizedServerAttributes = null;
            /*CookieToken */ TokenFromName(/*bool*/ parseResponseCookies)
            {
                if (!parseResponseCookies)
                {
                    for(/*int*/ let i = 0; i < $.$snp.System.Net.CookieTokenizer.s_recognizedServerAttributes.length; ++i)
                    {
                        if ($.$spc.System.Array.$ReadT1.call($.$snp.System.Net.CookieTokenizer.s_recognizedServerAttributes, i).IsEqualTo(this.Name))
                        {
                            return $.$spc.System.Array.$ReadT1.call($.$snp.System.Net.CookieTokenizer.s_recognizedServerAttributes, i).Token;
                        }
                    }
                }
                else 
                {
                    for(/*int*/ let i = 0; i < $.$snp.System.Net.CookieTokenizer.s_recognizedAttributes.length; ++i)
                    {
                        if ($.$spc.System.Array.$ReadT1.call($.$snp.System.Net.CookieTokenizer.s_recognizedAttributes, i).IsEqualTo(this.Name))
                        {
                            return $.$spc.System.Array.$ReadT1.call($.$snp.System.Net.CookieTokenizer.s_recognizedAttributes, i).Token;
                        }
                    }
                }
                return 18/*CookieToken.Unknown*/;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._eofCookie = this._eofCookie;
                copy._index = this._index;
                copy._length = this._length;
                copy._name = this._name;
                copy._quoted = this._quoted;
                copy._start = this._start;
                copy._token = this._token;
                copy._tokenLength = this._tokenLength;
                copy._tokenStream = this._tokenStream;
                copy._value = this._value;
                copy._cookieStartIndex = this._cookieStartIndex;
                copy._cookieLength = this._cookieLength;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._eofCookie = false;
                this._index = 0;
                this._length = 0;
                this._name = null;
                this._quoted = false;
                this._start = 0;
                this._token = 0;
                this._tokenLength = 0;
                this._tokenStream = null;
                this._value = null;
                this._cookieStartIndex = 0;
                this._cookieLength = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_recognizedAttributes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$snp.System.Net.CookieTokenizer.RecognizedAttribute), [new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$2("Path"/*CookieFields.PathAttributeName*/, 14/*CookieToken.Path*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$2("Max-Age"/*CookieFields.MaxAgeAttributeName*/, 13/*CookieToken.MaxAge*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$2("Expires"/*CookieFields.ExpiresAttributeName*/, 12/*CookieToken.Expires*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$2("Version"/*CookieFields.VersionAttributeName*/, 19/*CookieToken.Version*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$2("Domain"/*CookieFields.DomainAttributeName*/, 11/*CookieToken.Domain*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$2("Secure"/*CookieFields.SecureAttributeName*/, 16/*CookieToken.Secure*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$2("Discard"/*CookieFields.DiscardAttributeName*/, 10/*CookieToken.Discard*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$2("Port"/*CookieFields.PortAttributeName*/, 15/*CookieToken.Port*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$2("Comment"/*CookieFields.CommentAttributeName*/, 7/*CookieToken.Comment*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$2("CommentURL"/*CookieFields.CommentUrlAttributeName*/, 8/*CookieToken.CommentUrl*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$2("HttpOnly"/*CookieFields.HttpOnlyAttributeName*/, 17/*CookieToken.HttpOnly*/)], null, null);
                }
                {
                    this.s_recognizedServerAttributes = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$snp.System.Net.CookieTokenizer.RecognizedAttribute), [new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$2(/*$*/ 36 + "Path"/*CookieFields.PathAttributeName*/, 14/*CookieToken.Path*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$2(/*$*/ 36 + "Version"/*CookieFields.VersionAttributeName*/, 19/*CookieToken.Version*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$2(/*$*/ 36 + "Domain"/*CookieFields.DomainAttributeName*/, 11/*CookieToken.Domain*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$2(/*$*/ 36 + "Port"/*CookieFields.PortAttributeName*/, 15/*CookieToken.Port*/), new $.$snp.System.Net.CookieTokenizer.RecognizedAttribute().$ctor$2(/*$*/ 36 + "HttpOnly"/*CookieFields.HttpOnlyAttributeName*/, 17/*CookieToken.HttpOnly*/)], null, null);
                }
            }
            static $h = 1761036;
            static $z = 42;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":262145,"g":{"r":0,"d":0,"h":64426270476,"f":8},"s":{"r":0,"d":0,"h":68721237772,"f":8},"n":"EndOfCookie","d":1761036,"h":60131303180,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":77311172364,"f":8},"n":"Eof","d":1761036,"h":73016205068,"f":8},{"p":1310721,"g":{"r":0,"d":0,"h":85901106956,"f":8},"s":{"r":0,"d":0,"h":90196074252,"f":8},"n":"Name","d":1761036,"h":81606139660,"f":8},{"p":262145,"g":{"r":0,"d":0,"h":98786008844,"f":8},"s":{"r":0,"d":0,"h":103080976140,"f":8},"n":"Quoted","d":1761036,"h":94491041548,"f":8},{"p":1695500,"g":{"r":0,"d":0,"h":111670910732,"f":8},"s":{"r":0,"d":0,"h":115965878028,"f":8},"n":"Token","d":1761036,"h":107375943436,"f":8},{"p":1310721,"g":{"r":0,"d":0,"h":124555812620,"f":8},"s":{"r":0,"d":0,"h":128850779916,"f":8},"n":"Value","d":1761036,"h":120260845324,"f":8}],"m":[{"r":1310721,"n":"Extract","d":1761036,"h":133145747212,"f":8},{"r":1695500,"p":[{"n":"ignoreComma","p":262145},{"n":"ignoreEquals","p":262145}],"n":"FindNext","d":1761036,"h":137440714508,"f":8},{"r":1695500,"p":[{"n":"first","p":262145},{"n":"parseResponseCookies","p":262145}],"n":"Next","d":1761036,"h":141735681804,"f":8},{"r":65537,"n":"Reset","d":1761036,"h":146030649100,"f":8},{"r":1695500,"p":[{"n":"parseResponseCookies","p":262145}],"n":"TokenFromName","d":1761036,"h":163210518284,"f":8}],"l":[{"t":262145,"n":"_eofCookie","d":1761036,"h":4296728332,"f":2},{"t":655361,"n":"_index","d":1761036,"h":8591695628,"f":2},{"t":655361,"n":"_length","d":1761036,"h":12886662924,"f":2},{"t":1310721,"n":"_name","d":1761036,"h":17181630220,"f":2},{"t":262145,"n":"_quoted","d":1761036,"h":21476597516,"f":2},{"t":655361,"n":"_start","d":1761036,"h":25771564812,"f":2},{"t":1695500,"n":"_token","d":1761036,"h":30066532108,"f":2},{"t":655361,"n":"_tokenLength","d":1761036,"h":34361499404,"f":2},{"t":1310721,"n":"_tokenStream","d":1761036,"h":38656466700,"f":2},{"t":1310721,"n":"_value","d":1761036,"h":42951433996,"f":2},{"t":655361,"n":"_cookieStartIndex","d":1761036,"h":47246401292,"f":2},{"t":655361,"n":"_cookieLength","d":1761036,"h":51541368588,"f":2},{"t":0,"n":"s_recognizedAttributes","d":1761036,"h":154620583692,"f":34},{"t":0,"n":"s_recognizedServerAttributes","d":1761036,"h":158915550988,"f":34}],"c":[{"p":[{"n":"tokenStream","p":1310721}],"n":".ctor","o":"$ctor$2","d":1761036,"h":55836335884,"f":8},{"n":".ctor","o":"$ctor$3","d":1761036,"h":167505485580,"f":1}],"j":[1826572],"h":1761036}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.CookieTokenizer`; }
        });
        
        $asm.$cls("$snp.System.Net.IPEndPoint", ($self) => class IPEndPoint extends $.$snp.System.Net.EndPoint
        {
            /*int*/ static MinPort = 0;
            /*int*/ static MaxPort = 65535;
            /*IPAddress*/ _address = null;
            /*int*/ _port = 0;
            /*AddressFamily */ get AddressFamily()
            {
                return this._address.AddressFamily;
            }
            $ctor$2(/*long*/ address, /*int*/ port)
            {
                super.$ctor$1();
                {
                    if (!$.$snp.System.Net.TcpValidationHelpers.ValidatePortNumber(port))
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("port");
                    }
                    this._port = port;
                    this._address = new $.$snp.System.Net.IPAddress().$ctor$1(address);
                }
                return this;
            }
            $ctor$3(/*IPAddress*/ address, /*int*/ port)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(address, "address");
                    if (!$.$snp.System.Net.TcpValidationHelpers.ValidatePortNumber(port))
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("port");
                    }
                    this._port = port;
                    this._address = address;
                }
                return this;
            }
            /*IPAddress */ get Address()
            {
                return this._address;
            }
            /*IPAddress */ set Address(value)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(value, "value");
                this._address = value;
            }
            /*int */ get Port()
            {
                return this._port;
            }
            /*int */ set Port(value)
            {
                if (!$.$snp.System.Net.TcpValidationHelpers.ValidatePortNumber(value))
                {
                    throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("value");
                }
                this._port = value;
            }
            static /*bool */ TryParse(/*string*/ s, /*out IPEndPoint?*/ result)
            {
                return $.$snp.System.Net.IPEndPoint.TryParse$1($.$spc.System.MemoryExtensions.AsSpan$3(s), result);
            }
            static /*bool */ TryParse$1(/*ReadOnlySpan<char>*/ s, /*out IPEndPoint?*/ result)
            {
                /*int*/ let addressLength = s.Length;
                /*int*/ let lastColonPos = $.$spc.System.MemoryExtensions.LastIndexOf$2($.$spc.System.Char, s, /*:*/ 58);
                if (lastColonPos > 0)
                {
                    if (s.get_Item(((lastColonPos - 1) | 0)).$v === /*]*/ 93)
                    {
                        addressLength = lastColonPos;
                    }
                    else if ($.$spc.System.MemoryExtensions.LastIndexOf$2($.$spc.System.Char, s.Slice$1(0, lastColonPos), /*:*/ 58) === -1)
                    {
                        addressLength = lastColonPos;
                    }
                }
                /*IPAddress?*/ let address;
                if ($.$snp.System.Net.IPAddress.TryParse$2(s.Slice$1(0, addressLength), $.$ref(() => address, ($v) => address = $v, $.$snp.System.Net.IPAddress)))
                {
                    /*uint*/ let port = 0;
                    if (addressLength === s.Length || ($.$spc.System.UInt32.TryParse$4(s.Slice(((addressLength + 1) | 0)), 0/*NumberStyles.None*/, $.$spc.System.Globalization.CultureInfo.InvariantCulture, $.$ref(() => port, ($v) => port = $v, $.$spc.System.UInt32)) && port <= 65535/*MaxPort*/))
                    {
                        result.$v = new $.$snp.System.Net.IPEndPoint().$ctor$3(address, (port | 0));
                        return true;
                    }
                }
                result.$v = null;
                return false;
            }
            static /*IPEndPoint */ Parse(/*string*/ s)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(s, "s");
                return $.$snp.System.Net.IPEndPoint.Parse$1($.$spc.System.MemoryExtensions.AsSpan$3(s));
            }
            static /*IPEndPoint */ Parse$1(/*ReadOnlySpan<char>*/ s)
            {
                /*IPEndPoint?*/ let result;
                if ($.$snp.System.Net.IPEndPoint.TryParse$1(s, $.$ref(() => result, ($v) => result = $v, $.$snp.System.Net.IPEndPoint)))
                {
                    return result;
                }
                throw new $.$spc.System.FormatException().$ctor$10($.$snp.System.SR.bad_endpoint_string);
            }
            static/*conventional*/ /*string */ ToString()
            {
                return this._address.AddressFamily === 23/*AddressFamily.InterNetworkV6*/ ? $.$spc.System.String.Create$9($.$spc.System.Globalization.NumberFormatInfo.InvariantInfo, `[${$.$snp.System.Net.IPAddress.ToString.call(this._address)}]:${this._port}`) : $.$spc.System.String.Create$9($.$spc.System.Globalization.NumberFormatInfo.InvariantInfo, `${$.$snp.System.Net.IPAddress.ToString.call(this._address)}:${this._port}`);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.IPEndPoint.ToString.apply(this, arguments); }
            /*SocketAddress */ Serialize()
            {
                return new $.$snp.System.Net.SocketAddress().$ctor$4(this.Address, this.Port);
            }
            /*EndPoint */ Create(/*SocketAddress*/ socketAddress)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(socketAddress, "socketAddress");
                if (!((socketAddress.Family === 2/*AddressFamily.InterNetwork*/) || (socketAddress.Family === 23/*AddressFamily.InterNetworkV6*/)))
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$snp.System.SR.Format$1($.$snp.System.SR.net_InvalidAddressFamily, $.$spc.System.Enum.ToStringT($.$snp.System.Net.Sockets.AddressFamily, $.$spc.System.UInt32, socketAddress.Family), $.$spc.System.Object.GetType.call(this).FullName), "socketAddress");
                }
                /*int*/ let minSize = this.AddressFamily === 23/*AddressFamily.InterNetworkV6*/ ? $.$snp.System.Net.SocketAddress.IPv6AddressSize : $.$snp.System.Net.SocketAddress.IPv4AddressSize;
                if (socketAddress.Size < minSize)
                {
                    throw new $.$spc.System.ArgumentException().$ctor$13($.$snp.System.SR.Format$1($.$snp.System.SR.net_InvalidSocketAddressSize, $.$spc.System.Object.GetType.call(socketAddress).FullName, $.$spc.System.Object.GetType.call(this).FullName), "socketAddress");
                }
                return $.$snp.System.Net.Sockets.SocketAddressExtensions.GetIPEndPoint(socketAddress);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ comparand)
            {
                let other;
                return $.$is(comparand, $.$snp.System.Net.IPEndPoint, { set $v(v){ other = v; } }) && other._address.Equals$2(this._address) && other._port === this._port;
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snp.System.Net.IPEndPoint.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$snp.System.Net.IPAddress.GetHashCode.call(this._address) ^ this._port;
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snp.System.Net.IPEndPoint.GetHashCode.apply(this, arguments); }
            static $h = 3333900;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2613004,"p":[{"p":4513548,"g":{"r":0,"d":0,"h":25773137676,"f":32769},"n":"AddressFamily","d":3333900,"h":21478170380,"f":32769},{"p":3071756,"g":{"r":0,"d":0,"h":42953006860,"f":1},"s":{"r":0,"d":0,"h":47247974156,"f":1},"n":"Address","d":3333900,"h":38658039564,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":55837908748,"f":1},"s":{"r":0,"d":0,"h":60132876044,"f":1},"n":"Port","d":3333900,"h":51542941452,"f":1}],"m":[{"r":262145,"p":[{"n":"s","p":1310721},{"n":"result","p":3333900,"f":2}],"n":"TryParse","d":3333900,"h":64427843340,"f":33},{"r":262145,"p":[{"n":"s","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"result","p":3333900,"f":2}],"n":"TryParse","o":"@$1","d":3333900,"h":68722810636,"f":33},{"r":3333900,"p":[{"n":"s","p":1310721}],"n":"Parse","d":3333900,"h":73017777932,"f":33},{"r":3333900,"p":[{"n":"s","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Parse","o":"@$1","d":3333900,"h":77312745228,"f":33},{"r":1310721,"n":"ToString","d":3333900,"h":81607712524,"f":32769},{"r":4382476,"n":"Serialize","d":3333900,"h":85902679820,"f":32769},{"r":2613004,"p":[{"n":"socketAddress","p":4382476}],"n":"Create","d":3333900,"h":90197647116,"f":32769},{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","d":3333900,"h":94492614412,"f":32769},{"r":655361,"n":"GetHashCode","d":3333900,"h":98787581708,"f":32769}],"l":[{"t":655361,"n":"MinPort","d":3333900,"h":4298301196,"f":33},{"t":655361,"n":"MaxPort","d":3333900,"h":8593268492,"f":33},{"t":3071756,"n":"_address","d":3333900,"h":12888235788,"f":2},{"t":655361,"n":"_port","d":3333900,"h":17183203084,"f":2}],"c":[{"p":[{"n":"address","p":917505},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$2","d":3333900,"h":30068104972,"f":1},{"p":[{"n":"address","p":3071756},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$3","d":3333900,"h":34363072268,"f":1}],"h":3333900}; }
            static get $b() { return $.$snp.System.Net.EndPoint; }
            static get $fullName() { return `System.Net.IPEndPoint`; }
        });
        
        $asm.$str("$snp.System.Net.CookieParser", ($self) => class CookieParser extends $.$spc.System.ValueType
        {
            /*CookieTokenizer*/  get _tokenizer() { return this.$getField(0, 42); }
            /*CookieTokenizer*/  set _tokenizer(value) { this.$setField(0, 42, value); }
            /*Cookie?*/  get _savedCookie() { return this.$getField(42, 4); }
            /*Cookie?*/  set _savedCookie(value) { this.$setField(42, 4, value); }
            $ctor$2(/*string*/ cookieString)
            {
                super.$ctor$1();
                {
                    this._tokenizer = new $.$snp.System.Net.CookieTokenizer().$ctor$2(cookieString);
                    this._savedCookie = null;
                }
                return this;
            }
            static /*bool */ InternalSetNameMethod(/*Cookie*/ cookie, /*string?*/ value)
            {
                return cookie.InternalSetName(value);
            }
            /*FieldInfo?*/ static s_isQuotedDomainField = null;
            static /*FieldInfo */ get IsQuotedDomainField()
            {
                if ($.$spc.System.Reflection.FieldInfo.op_Equality$1($.$snp.System.Net.CookieParser.s_isQuotedDomainField, null))
                {
                    /*FieldInfo?*/ let fieldInfo = $.$snp.System.Net.Cookie.$type.GetField$2("IsQuotedDomain", 4/*BindingFlags.Instance*/ | 32/*BindingFlags.NonPublic*/);
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Reflection.FieldInfo.op_Inequality$1(fieldInfo, null), "We need to use an internal field named IsQuotedDomain that is declared on Cookie.");
                    $.$snp.System.Net.CookieParser.s_isQuotedDomainField = fieldInfo;
                }
                return $.$snp.System.Net.CookieParser.s_isQuotedDomainField;
            }
            /*FieldInfo?*/ static s_isQuotedVersionField = null;
            static /*FieldInfo */ get IsQuotedVersionField()
            {
                if ($.$spc.System.Reflection.FieldInfo.op_Equality$1($.$snp.System.Net.CookieParser.s_isQuotedVersionField, null))
                {
                    /*FieldInfo?*/ let fieldInfo = $.$snp.System.Net.Cookie.$type.GetField$2("IsQuotedVersion", 4/*BindingFlags.Instance*/ | 32/*BindingFlags.NonPublic*/);
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.Reflection.FieldInfo.op_Inequality$1(fieldInfo, null), "We need to use an internal field named IsQuotedVersion that is declared on Cookie.");
                    $.$snp.System.Net.CookieParser.s_isQuotedVersionField = fieldInfo;
                }
                return $.$snp.System.Net.CookieParser.s_isQuotedVersionField;
            }
            /*Cookie? */ Get()
            {
                /*Cookie?*/ let cookie = null;
                /*bool*/ let commentSet = false;
                /*bool*/ let commentUriSet = false;
                /*bool*/ let domainSet = false;
                /*bool*/ let expiresSet = false;
                /*bool*/ let pathSet = false;
                /*bool*/ let portSet = false;
                /*bool*/ let versionSet = false;
                /*bool*/ let secureSet = false;
                /*bool*/ let discardSet = false;
                do
                {
                    /*CookieToken*/ let token = this._tokenizer.Next(cookie === null, true);
                    if (cookie === null && (token === 1/*CookieToken.NameValuePair*/ || token === 2/*CookieToken.Attribute*/))
                    {
                        cookie = new $.$snp.System.Net.Cookie().$ctor$1();
                        $.$snp.System.Net.CookieParser.InternalSetNameMethod(cookie, this._tokenizer.Name);
                        cookie.Value = this._tokenizer.Value;
                    }
                    else 
                    {
                        switch(token)
                        {
                            case 1/*CookieToken.NameValuePair*/:
                            let $switch2 = this._tokenizer.Token;
                            switch($switch2)
                            {
                                case 7/*CookieToken.Comment*/:
                                if (!commentSet)
                                {
                                    commentSet = true;
                                    cookie.Comment = this._tokenizer.Value;
                                }
                                break;
                                case 8/*CookieToken.CommentUrl*/:
                                if (!commentUriSet)
                                {
                                    commentUriSet = true;
                                    /*Uri?*/ let parsed;
                                    if ($.$spu.System.Uri.TryCreate($.$snp.System.Net.CookieParser.CheckQuoted(this._tokenizer.Value), 1/*UriKind.Absolute*/, $.$ref(() => parsed, ($v) => parsed = $v, $.$spu.System.Uri)))
                                    {
                                        cookie.CommentUri = parsed;
                                    }
                                }
                                break;
                                case 11/*CookieToken.Domain*/:
                                if (!domainSet)
                                {
                                    domainSet = true;
                                    cookie.Domain = $.$snp.System.Net.CookieParser.CheckQuoted(this._tokenizer.Value);
                                    $.$snp.System.Net.CookieParser.IsQuotedDomainField.SetValue(cookie, $.$box(this._tokenizer.Quoted, $.$spc.System.Boolean));
                                }
                                break;
                                case 12/*CookieToken.Expires*/:
                                if (!expiresSet)
                                {
                                    expiresSet = true;
                                    /*DateTime*/ let expires;
                                    if ($.$spc.System.DateTime.TryParse$2($.$snp.System.Net.CookieParser.CheckQuoted(this._tokenizer.Value), $.$spc.System.Globalization.CultureInfo.InvariantCulture, 7/*DateTimeStyles.AllowWhiteSpaces*/ | 16/*DateTimeStyles.AdjustToUniversal*/, $.$ref(() => expires, ($v) => expires = $v, $.$spc.System.DateTime)))
                                    {
                                        cookie.Expires = expires;
                                    }
                                    else 
                                    {
                                        $.$snp.System.Net.CookieParser.InternalSetNameMethod(cookie, $.$spc.System.String.Empty);
                                    }
                                }
                                break;
                                case 13/*CookieToken.MaxAge*/:
                                if (!expiresSet)
                                {
                                    expiresSet = true;
                                    /*int*/ let parsed;
                                    if ($.$spc.System.Int32.TryParse($.$snp.System.Net.CookieParser.CheckQuoted(this._tokenizer.Value), $.$ref(() => parsed, ($v) => parsed = $v, $.$spc.System.Int32)))
                                    {
                                        cookie.Expires = $.$spc.System.DateTime.UtcNow.AddSeconds(parsed);
                                    }
                                    else 
                                    {
                                        $.$snp.System.Net.CookieParser.InternalSetNameMethod(cookie, $.$spc.System.String.Empty);
                                    }
                                }
                                break;
                                case 14/*CookieToken.Path*/:
                                if (!pathSet)
                                {
                                    pathSet = true;
                                    cookie.Path = this._tokenizer.Value;
                                }
                                break;
                                case 15/*CookieToken.Port*/:
                                if (!portSet)
                                {
                                    portSet = true;
                                    try
                                    {
                                        cookie.Port = this._tokenizer.Value;
                                    }
                                    catch($e)
                                    {
                                        $.$snp.System.Net.CookieParser.InternalSetNameMethod(cookie, $.$spc.System.String.Empty);
                                    }
                                }
                                break;
                                case 19/*CookieToken.Version*/:
                                if (!versionSet)
                                {
                                    versionSet = true;
                                    /*int*/ let parsed;
                                    if ($.$spc.System.Int32.TryParse($.$snp.System.Net.CookieParser.CheckQuoted(this._tokenizer.Value), $.$ref(() => parsed, ($v) => parsed = $v, $.$spc.System.Int32)))
                                    {
                                        cookie.Version = parsed;
                                        $.$snp.System.Net.CookieParser.IsQuotedVersionField.SetValue(cookie, $.$box(this._tokenizer.Quoted, $.$spc.System.Boolean));
                                    }
                                    else 
                                    {
                                        $.$snp.System.Net.CookieParser.InternalSetNameMethod(cookie, $.$spc.System.String.Empty);
                                    }
                                }
                                break;
                            }
                            break;
                            case 2/*CookieToken.Attribute*/:
                            let $switch3 = this._tokenizer.Token;
                            switch($switch3)
                            {
                                case 10/*CookieToken.Discard*/:
                                if (!discardSet)
                                {
                                    discardSet = true;
                                    cookie.Discard = true;
                                }
                                break;
                                case 16/*CookieToken.Secure*/:
                                if (!secureSet)
                                {
                                    secureSet = true;
                                    cookie.Secure = true;
                                }
                                break;
                                case 17/*CookieToken.HttpOnly*/:
                                cookie.HttpOnly = true;
                                break;
                                case 15/*CookieToken.Port*/:
                                if (!portSet)
                                {
                                    portSet = true;
                                    cookie.Port = $.$spc.System.String.Empty;
                                }
                                break;
                            }
                            break;
                        }
                    }
                }
                while(!this._tokenizer.Eof && !this._tokenizer.EndOfCookie);
                return cookie;
            }
            /*Cookie? */ GetServer()
            {
                /*Cookie?*/ let cookie = this._savedCookie;
                this._savedCookie = null;
                /*bool*/ let domainSet = false;
                /*bool*/ let pathSet = false;
                /*bool*/ let portSet = false;
                do
                {
                    /*bool*/ let first = cookie === null || $.$spc.System.String.IsNullOrEmpty(cookie.Name);
                    /*CookieToken*/ let token = this._tokenizer.Next(first, false);
                    if (first && (token === 1/*CookieToken.NameValuePair*/ || token === 2/*CookieToken.Attribute*/))
                    {
                        cookie ??= new $.$snp.System.Net.Cookie().$ctor$1();
                        $.$snp.System.Net.CookieParser.InternalSetNameMethod(cookie, this._tokenizer.Name);
                        cookie.Value = this._tokenizer.Value;
                    }
                    else 
                    {
                        switch(token)
                        {
                            case 1/*CookieToken.NameValuePair*/:
                            let $switch2 = this._tokenizer.Token;
                            switch($switch2)
                            {
                                case 11/*CookieToken.Domain*/:
                                if (!domainSet)
                                {
                                    domainSet = true;
                                    cookie.Domain = $.$snp.System.Net.CookieParser.CheckQuoted(this._tokenizer.Value);
                                    $.$snp.System.Net.CookieParser.IsQuotedDomainField.SetValue(cookie, $.$box(this._tokenizer.Quoted, $.$spc.System.Boolean));
                                }
                                break;
                                case 14/*CookieToken.Path*/:
                                if (!pathSet)
                                {
                                    pathSet = true;
                                    cookie.Path = this._tokenizer.Value;
                                }
                                break;
                                case 15/*CookieToken.Port*/:
                                if (!portSet)
                                {
                                    portSet = true;
                                    try
                                    {
                                        cookie.Port = this._tokenizer.Value;
                                    }
                                    catch($e)
                                    {
                                        $.$snp.System.Net.CookieParser.InternalSetNameMethod(cookie, $.$spc.System.String.Empty);
                                    }
                                }
                                break;
                                case 19/*CookieToken.Version*/:
                                this._savedCookie = new $.$snp.System.Net.Cookie().$ctor$1();
                                /*int*/ let parsed;
                                if ($.$spc.System.Int32.TryParse(this._tokenizer.Value, $.$ref(() => parsed, ($v) => parsed = $v, $.$spc.System.Int32)))
                                {
                                    this._savedCookie.Version = parsed;
                                }
                                return cookie;
                                case 18/*CookieToken.Unknown*/:
                                this._savedCookie = new $.$snp.System.Net.Cookie().$ctor$1();
                                $.$snp.System.Net.CookieParser.InternalSetNameMethod(this._savedCookie, this._tokenizer.Name);
                                this._savedCookie.Value = this._tokenizer.Value;
                                return cookie;
                            }
                            break;
                            case 2/*CookieToken.Attribute*/:
                            if (this._tokenizer.Token === 15/*CookieToken.Port*/ && !portSet)
                            {
                                portSet = true;
                                cookie.Port = $.$spc.System.String.Empty;
                            }
                            break;
                        }
                    }
                }
                while(!this._tokenizer.Eof && !this._tokenizer.EndOfCookie);
                return cookie;
            }
            static /*string */ CheckQuoted(/*string*/ value)
            {
                return (value.length >= 2 && $.$spc.System.String.StartsWith$3.call(value, /*\"*/ 34) && $.$spc.System.String.EndsWith$3.call(value, /*\"*/ 34)) ? $.$spc.System.String.Substring$1.call(value, 1, ((value.length - 2) | 0)) : value;
            }
            /*bool */ EndofHeader()
            {
                return this._tokenizer.Eof;
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._tokenizer = this._tokenizer.Clone();
                copy._savedCookie = this._savedCookie;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._tokenizer = $.$default($.$snp.System.Net.CookieTokenizer);
                this._savedCookie = null;
            }
            static $h = 1629964;
            static $z = 46;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":76677121,"g":{"r":0,"d":0,"h":30066401036,"f":34},"n":"IsQuotedDomainField","d":1629964,"h":25771433740,"f":34},{"p":76677121,"g":{"r":0,"d":0,"h":42951302924,"f":34},"n":"IsQuotedVersionField","d":1629964,"h":38656335628,"f":34}],"m":[{"r":262145,"p":[{"n":"cookie","p":1171212},{"n":"value","p":1310721}],"n":"InternalSetNameMethod","d":1629964,"h":17181499148,"f":34},{"r":1171212,"n":"Get","d":1629964,"h":47246270220,"f":8},{"r":1171212,"n":"GetServer","d":1629964,"h":51541237516,"f":8},{"r":1310721,"p":[{"n":"value","p":1310721}],"n":"CheckQuoted","d":1629964,"h":55836204812,"f":40},{"r":262145,"n":"EndofHeader","d":1629964,"h":60131172108,"f":8}],"l":[{"t":1761036,"n":"_tokenizer","d":1629964,"h":4296597260,"f":2},{"t":1171212,"n":"_savedCookie","d":1629964,"h":8591564556,"f":2},{"t":76677121,"n":"s_isQuotedDomainField","d":1629964,"h":21476466444,"f":34},{"t":76677121,"n":"s_isQuotedVersionField","d":1629964,"h":34361368332,"f":34}],"c":[{"p":[{"n":"cookieString","p":1310721}],"n":".ctor","o":"$ctor$2","d":1629964,"h":12886531852,"f":8},{"n":".ctor","o":"$ctor$3","d":1629964,"h":64426139404,"f":1}],"h":1629964}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.CookieParser`; }
        });
        
        $asm.$str("$snp.System.Net.CredentialHostKey", ($self) => class CredentialHostKey extends $.$spc.System.ValueType
        {
            /*string*/  get Host() { return this.$getField(0, 4); }
            /*string*/  set Host(value) { this.$setField(0, 4, value); }
            /*string*/  get AuthenticationType() { return this.$getField(4, 4); }
            /*string*/  set AuthenticationType(value) { this.$setField(4, 4, value); }
            /*int*/  get Port() { return this.$getField(8, 4); }
            /*int*/  set Port(value) { this.$setField(8, 4, value); }
            $ctor$2(/*string*/ host, /*int*/ port, /*string*/ authenticationType)
            {
                super.$ctor$1();
                {
                    $.$spc.System.Diagnostics.Debug.Assert$1(!$.$spc.System.String.IsNullOrEmpty(host), "!string.IsNullOrEmpty(host)");
                    $.$spc.System.Diagnostics.Debug.Assert$1(port >= 0, "port >= 0");
                    $.$spc.System.Diagnostics.Debug.Assert$1($.$spc.System.String.op_Inequality(authenticationType, null), "authenticationType != null");
                    this.Host = host;
                    this.Port = port;
                    this.AuthenticationType = authenticationType;
                }
                return this;
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(this.AuthenticationType) ^ $.$spc.System.StringComparer.OrdinalIgnoreCase.GetHashCode$2(this.Host) ^ $.$spc.System.Int32.GetHashCode.call(this.Port);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snp.System.Net.CredentialHostKey.GetHashCode.apply(this, arguments); }
            /*bool */ Equals$2(/*CredentialHostKey*/ other)
            {
                /*bool*/ let equals = $.$spc.System.String.Equals$5(this.AuthenticationType, other.AuthenticationType, 5/*StringComparison.OrdinalIgnoreCase*/) && $.$spc.System.String.Equals$5(this.Host, other.Host, 5/*StringComparison.OrdinalIgnoreCase*/) && this.Port === other.Port;
                if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                {
                    $.$snp.System.Net.NetEventSource.Info(this, `Equals(${$.$snp.System.Net.CredentialHostKey.ToString.call(this)},${$.$snp.System.Net.CredentialHostKey.ToString.call(other)}) returns ${equals}`, "Equals");
                }
                return equals;
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                return $.$is(obj, $.$snp.System.Net.CredentialHostKey) && this.Equals$2($.$cast(obj, $.$snp.System.Net.CredentialHostKey));
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snp.System.Net.CredentialHostKey.Equals.apply(this, arguments); }
            static/*conventional*/ /*string */ ToString()
            {
                return $.$spc.System.String.Create$9($.$spc.System.Globalization.CultureInfo.InvariantCulture, `${this.Host}:${this.Port}:${this.AuthenticationType}`);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.CredentialHostKey.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Net.CredentialHostKey>.Equals(System.Net.CredentialHostKey)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.Host = this.Host;
                copy.AuthenticationType = this.AuthenticationType;
                copy.Port = this.Port;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.Host = null;
                this.AuthenticationType = null;
                this.Port = 0;
            }
            static $h = 2416396;
            static $z = 12;
            static $f = 0b1010000000;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"m":[{"r":655361,"n":"GetHashCode","d":2416396,"h":21477252876,"f":32769},{"r":262145,"p":[{"n":"other","p":2416396}],"n":"Equals","o":"@$2","d":2416396,"h":25772220172,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":2416396,"h":30067187468,"f":32769},{"r":1310721,"n":"ToString","d":2416396,"h":34362154764,"f":32769}],"l":[{"t":1310721,"n":"Host","d":2416396,"h":4297383692,"f":1},{"t":1310721,"n":"AuthenticationType","d":2416396,"h":8592350988,"f":1},{"t":655361,"n":"Port","d":2416396,"h":12887318284,"f":1}],"c":[{"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"authenticationType","p":1310721}],"n":".ctor","o":"$ctor$2","d":2416396,"h":17182285580,"f":8},{"n":".ctor","o":"$ctor$3","d":2416396,"h":38657122060,"f":1}],"i":[$.$spc.System.IEquatable$$($.$snp.System.Net.CredentialHostKey).$h],"h":2416396}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$snp.System.Net.CredentialHostKey) ]; }
            static get $fullName() { return `System.Net.CredentialHostKey`; }
        });
        
        $asm.$str("$snp.System.Net.IPNetwork", ($self) => class IPNetwork extends $.$spc.System.ValueType
        {
            /*IPAddress?*/  get _baseAddress() { return this.$getField(0, 4); }
            /*IPAddress?*/  set _baseAddress(value) { this.$setField(0, 4, value); }
            /*IPAddress */ get BaseAddress()
            {
                return this._baseAddress ?? $.$snp.System.Net.IPAddress.Any;
            }
            /*int*/ PrefixLength = 0;
            $ctor$2(/*IPAddress*/ baseAddress, /*int*/ prefixLength)
            {
                super.$ctor$1();
                {
                    $.$spc.System.ArgumentNullException.ThrowIfNull(baseAddress, "baseAddress");
                    if (prefixLength < 0 || prefixLength > $.$snp.System.Net.IPNetwork.GetMaxPrefixLength(baseAddress))
                    {
                        ThrowArgumentOutOfRangeException();
                    }
                    this._baseAddress = $.$snp.System.Net.IPNetwork.ClearNonZeroBitsAfterNetworkPrefix(baseAddress, prefixLength);
                    this.PrefixLength = prefixLength;
                    /*static void*/  function ThrowArgumentOutOfRangeException()
                    {
                        throw new $.$spc.System.ArgumentOutOfRangeException().$ctor$16("prefixLength");
                    }
                }
                return this;
            }
            /*bool */ Contains(/*IPAddress*/ address)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(address, "address");
                if (address.AddressFamily !== this.BaseAddress.AddressFamily && (this.BaseAddress.AddressFamily !== 2/*AddressFamily.InterNetwork*/ || !address.IsIPv4MappedToIPv6))
                {
                    return false;
                }
                if (this.PrefixLength === 0)
                {
                    return true;
                }
                if (address.AddressFamily === 2/*AddressFamily.InterNetwork*/ || address.IsIPv4MappedToIPv6)
                {
                    /*uint*/ let mask = (4294967295/*uint.MaxValue*/ << (((32 - this.PrefixLength) | 0))) >>> 0;
                    if ($.$spc.System.BitConverter.IsLittleEndian)
                    {
                        mask = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$9(mask);
                    }
                    return this.BaseAddress.PrivateIPv4Address === (address.PrivateIPv4Address & mask);
                }
                else 
                {
                    /*UInt128*/ let baseAddressValue = new $.$spc.System.UInt128();
                    /*UInt128*/ let otherAddressValue = new $.$spc.System.UInt128();
                    /*int*/ let bytesWritten;
                    this.BaseAddress.TryWriteBytes($.$spc.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$spc.System.UInt128, new ($.$spc.System.Span$$($.$spc.System.UInt128))().$ctor$5($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.UInt128, () => baseAddressValue, ($v) => baseAddressValue = $v, null))), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$spc.System.Int32));
                    $.$spc.System.Diagnostics.Debug.Assert$1(bytesWritten === 16/*IPAddressParserStatics.IPv6AddressBytes*/, "bytesWritten == IPAddressParserStatics.IPv6AddressBytes");
                    address.TryWriteBytes($.$spc.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$spc.System.UInt128, new ($.$spc.System.Span$$($.$spc.System.UInt128))().$ctor$5($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.UInt128, () => otherAddressValue, ($v) => otherAddressValue = $v, null))), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$spc.System.Int32));
                    $.$spc.System.Diagnostics.Debug.Assert$1(bytesWritten === 16/*IPAddressParserStatics.IPv6AddressBytes*/, "bytesWritten == IPAddressParserStatics.IPv6AddressBytes");
                    /*UInt128*/ let mask = $.$spc.System.UInt128.op_LeftShift($.$spc.System.UInt128.MaxValue, (((128 - this.PrefixLength) | 0)));
                    if ($.$spc.System.BitConverter.IsLittleEndian)
                    {
                        mask = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$12(mask);
                    }
                    return $.$spc.System.UInt128.op_Equality(baseAddressValue, ($.$spc.System.UInt128.op_BitwiseAnd(otherAddressValue, mask)));
                }
            }
            static /*IPNetwork */ Parse(/*string*/ s)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(s, "s");
                return $.$snp.System.Net.IPNetwork.Parse$1($.$spc.System.MemoryExtensions.AsSpan$3(s));
            }
            static /*IPNetwork */ Parse$1(/*ReadOnlySpan<char>*/ s)
            {
                /*IPNetwork*/ let result;
                if (!$.$snp.System.Net.IPNetwork.TryParse$1(s, $.$ref(() => result, ($v) => result = $v, $.$snp.System.Net.IPNetwork)))
                {
                    throw new $.$spc.System.FormatException().$ctor$10($.$snp.System.SR.net_bad_ip_network);
                }
                return result;
            }
            static /*IPNetwork */ Parse$2(/*ReadOnlySpan<byte>*/ utf8Text)
            {
                /*IPNetwork*/ let result;
                if (!$.$snp.System.Net.IPNetwork.TryParse$2(utf8Text, $.$ref(() => result, ($v) => result = $v, $.$snp.System.Net.IPNetwork)))
                {
                    throw new $.$spc.System.FormatException().$ctor$10($.$snp.System.SR.net_bad_ip_network);
                }
                return result;
            }
            static /*bool */ TryParse(/*string?*/ s, /*out IPNetwork*/ result)
            {
                if ($.$spc.System.String.op_Equality(s, null))
                {
                    result.$v = new $.$snp.System.Net.IPNetwork();
                    return false;
                }
                return $.$snp.System.Net.IPNetwork.TryParse$1($.$spc.System.MemoryExtensions.AsSpan$3(s), result);
            }
            static /*bool */ TryParse$1(/*ReadOnlySpan<char>*/ s, /*out IPNetwork*/ result)
            {
                /*int*/ let separatorIndex = $.$spc.System.MemoryExtensions.LastIndexOf$2($.$spc.System.Char, s, /*/*/ 47);
                if (separatorIndex >= 0)
                {
                    /*ReadOnlySpan<char>*/ let ipAddressSpan = s.Slice$1(0, separatorIndex);
                    /*ReadOnlySpan<char>*/ let prefixLengthSpan = s.Slice(((separatorIndex + 1) | 0));
                    /*IPAddress?*/ let address;
                    /*int*/ let prefixLength;
                    if ($.$snp.System.Net.IPAddress.TryParse$2(ipAddressSpan, $.$ref(() => address, ($v) => address = $v, $.$snp.System.Net.IPAddress)) && $.$spc.System.Int32.TryParse$4(prefixLengthSpan, 0/*NumberStyles.None*/, $.$spc.System.Globalization.CultureInfo.InvariantCulture, $.$ref(() => prefixLength, ($v) => prefixLength = $v, $.$spc.System.Int32)) && prefixLength <= $.$snp.System.Net.IPNetwork.GetMaxPrefixLength(address))
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(prefixLength >= 0, "prefixLength >= 0");
                        result.$v = new $.$snp.System.Net.IPNetwork().$ctor$2(address, prefixLength);
                        return true;
                    }
                }
                result.$v = new $.$snp.System.Net.IPNetwork();
                return false;
            }
            static /*bool */ TryParse$2(/*ReadOnlySpan<byte>*/ utf8Text, /*out IPNetwork*/ result)
            {
                /*int*/ let separatorIndex = $.$spc.System.MemoryExtensions.LastIndexOf$2($.$spc.System.Byte, utf8Text, /*/*/ 47);
                if (separatorIndex >= 0)
                {
                    /*ReadOnlySpan<byte>*/ let ipAddressSpan = utf8Text.Slice$1(0, separatorIndex);
                    /*ReadOnlySpan<byte>*/ let prefixLengthSpan = utf8Text.Slice(((separatorIndex + 1) | 0));
                    /*IPAddress?*/ let address;
                    /*int*/ let prefixLength;
                    if ($.$snp.System.Net.IPAddress.TryParse$1(ipAddressSpan, $.$ref(() => address, ($v) => address = $v, $.$snp.System.Net.IPAddress)) && $.$spc.System.Int32.TryParse$7(prefixLengthSpan, 0/*NumberStyles.None*/, $.$spc.System.Globalization.CultureInfo.InvariantCulture, $.$ref(() => prefixLength, ($v) => prefixLength = $v, $.$spc.System.Int32)) && prefixLength <= $.$snp.System.Net.IPNetwork.GetMaxPrefixLength(address))
                    {
                        $.$spc.System.Diagnostics.Debug.Assert$1(prefixLength >= 0, "prefixLength >= 0");
                        result.$v = new $.$snp.System.Net.IPNetwork().$ctor$2(address, prefixLength);
                        return true;
                    }
                }
                result.$v = new $.$snp.System.Net.IPNetwork();
                return false;
            }
            static /*int */ GetMaxPrefixLength(/*IPAddress*/ baseAddress)
            {
                return baseAddress.AddressFamily === 2/*AddressFamily.InterNetwork*/ ? 32 : 128;
            }
            static /*IPAddress */ ClearNonZeroBitsAfterNetworkPrefix(/*IPAddress*/ baseAddress, /*int*/ prefixLength)
            {
                if (baseAddress.AddressFamily === 2/*AddressFamily.InterNetwork*/)
                {
                    if (prefixLength === 0)
                    {
                        return $.$snp.System.Net.IPAddress.Any;
                    }
                    /*uint*/ let mask = (4294967295/*uint.MaxValue*/ << (((32 - prefixLength) | 0))) >>> 0;
                    if ($.$spc.System.BitConverter.IsLittleEndian)
                    {
                        mask = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$9(mask);
                    }
                    /*uint*/ let newAddress = baseAddress.PrivateAddress & mask;
                    return newAddress === baseAddress.PrivateAddress ? baseAddress : new $.$snp.System.Net.IPAddress().$ctor$1(BigInt(newAddress));
                }
                else 
                {
                    if (prefixLength === 0)
                    {
                        return $.$snp.System.Net.IPAddress.IPv6Any;
                    }
                    /*UInt128*/ let value = new $.$spc.System.UInt128();
                    /*int*/ let bytesWritten;
                    baseAddress.TryWriteBytes($.$spc.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$spc.System.UInt128, new ($.$spc.System.Span$$($.$spc.System.UInt128))().$ctor$5($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.UInt128, () => value, ($v) => value = $v, null))), $.$ref(() => bytesWritten, ($v) => bytesWritten = $v, $.$spc.System.Int32));
                    $.$spc.System.Diagnostics.Debug.Assert$1(bytesWritten === 16/*IPAddressParserStatics.IPv6AddressBytes*/, "bytesWritten == IPAddressParserStatics.IPv6AddressBytes");
                    /*UInt128*/ let mask = $.$spc.System.UInt128.op_LeftShift($.$spc.System.UInt128.MaxValue, (((128 - prefixLength) | 0)));
                    if ($.$spc.System.BitConverter.IsLittleEndian)
                    {
                        mask = $.$spc.System.Buffers.Binary.BinaryPrimitives.ReverseEndianness$12(mask);
                    }
                    /*UInt128*/ let newAddress = $.$spc.System.UInt128.op_BitwiseAnd(value, mask);
                    return $.$spc.System.UInt128.op_Equality(newAddress, value) ? baseAddress : new $.$snp.System.Net.IPAddress().$ctor$7($.$spc.System.Span$$($.$spc.System.Byte).op_Implicit$2($.$spc.System.Runtime.InteropServices.MemoryMarshal.AsBytes($.$spc.System.UInt128, new ($.$spc.System.Span$$($.$spc.System.UInt128))().$ctor$5($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.UInt128, () => newAddress, ($v) => newAddress = $v, null)))));
                }
            }
            static/*conventional*/ /*string */ ToString()
            {
                return $.$spc.System.String.Create$10($.$spc.System.Globalization.CultureInfo.InvariantCulture, $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocSpan($.$spc.System.Char, 128, null), `${$.$snp.System.Net.IPAddress.ToString.call(this.BaseAddress)}/${(this.PrefixLength >>> 0)}`);
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snp.System.Net.IPNetwork.ToString.apply(this, arguments); }
            /*bool */ TryFormat(/*Span<char>*/ destination, /*out int*/ charsWritten)
            {
                return $.$spc.System.MemoryExtensions.TryWrite$1(destination, $.$spc.System.Globalization.CultureInfo.InvariantCulture, `${$.$snp.System.Net.IPAddress.ToString.call(this.BaseAddress)}/${(this.PrefixLength >>> 0)}`, charsWritten);
            }
            /*bool */ TryFormat$1(/*Span<byte>*/ utf8Destination, /*out int*/ bytesWritten)
            {
                return $.$spc.System.Text.Unicode.Utf8.TryWrite$1(utf8Destination, $.$spc.System.Globalization.CultureInfo.InvariantCulture, `${$.$snp.System.Net.IPAddress.ToString.call(this.BaseAddress)}/${(this.PrefixLength >>> 0)}`, bytesWritten);
            }
            /*bool */ Equals$2(/*IPNetwork*/ other)
            {
                return this.PrefixLength === other.PrefixLength && this.BaseAddress.Equals$2(other.BaseAddress);
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                let other;
                return $.$is(obj, $.$snp.System.Net.IPNetwork, { set $v(v){ other = v; } }) && this.Equals$2(other);
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snp.System.Net.IPNetwork.Equals.apply(this, arguments); }
            static /*bool */ op_Equality(/*IPNetwork*/ left, /*IPNetwork*/ right)
            {
                return left.Equals$2(right);
            }
            static /*bool */ op_Inequality(/*IPNetwork*/ left, /*IPNetwork*/ right)
            {
                return !($.$snp.System.Net.IPNetwork.op_Equality(left, right));
            }
            static/*conventional*/ /*int */ GetHashCode()
            {
                return $.$spc.System.HashCode.Combine$1($.$snp.System.Net.IPAddress, $.$spc.System.Int32, this.BaseAddress, this.PrefixLength);
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snp.System.Net.IPNetwork.GetHashCode.apply(this, arguments); }
            /*string */ System$IFormattable$ToString(/*string?*/ format, /*IFormatProvider?*/ provider)
            {
                return $.$snp.System.Net.IPNetwork.ToString.call(this);
            }
            /*bool */ System$ISpanFormattable$TryFormat(/*Span<char>*/ destination, /*out int*/ charsWritten, /*ReadOnlySpan<char>*/ format, /*IFormatProvider?*/ provider)
            {
                return this.TryFormat(destination, charsWritten);
            }
            /*bool */ System$IUtf8SpanFormattable$TryFormat(/*Span<byte>*/ utf8Destination, /*out int*/ bytesWritten, /*ReadOnlySpan<char>*/ format, /*IFormatProvider?*/ provider)
            {
                return this.TryFormat$1(utf8Destination, bytesWritten);
            }
            static /*IPNetwork */ System$IParsable$$$Parse(/*string*/ s, /*IFormatProvider?*/ provider)
            {
                return $.$snp.System.Net.IPNetwork.Parse(s);
            }
            static /*bool */ System$IParsable$$$TryParse(/*string?*/ s, /*IFormatProvider?*/ provider, /*out IPNetwork*/ result)
            {
                return $.$snp.System.Net.IPNetwork.TryParse(s, result);
            }
            static /*IPNetwork */ System$ISpanParsable$$$Parse(/*ReadOnlySpan<char>*/ s, /*IFormatProvider?*/ provider)
            {
                return $.$snp.System.Net.IPNetwork.Parse$1(s);
            }
            static /*IPNetwork */ System$IUtf8SpanParsable$$$Parse(/*ReadOnlySpan<byte>*/ utf8Text, /*IFormatProvider?*/ provider)
            {
                return $.$snp.System.Net.IPNetwork.Parse$2(utf8Text);
            }
            static /*bool */ System$ISpanParsable$$$TryParse(/*ReadOnlySpan<char>*/ s, /*IFormatProvider?*/ provider, /*out IPNetwork*/ result)
            {
                return $.$snp.System.Net.IPNetwork.TryParse$1(s, result);
            }
            static /*bool */ System$IUtf8SpanParsable$$$TryParse(/*ReadOnlySpan<byte>*/ utf8Text, /*IFormatProvider?*/ provider, /*out IPNetwork*/ result)
            {
                return $.$snp.System.Net.IPNetwork.TryParse$2(utf8Text, result);
            }
            //Generated interface implemetation for System.IEquatable<System.Net.IPNetwork>.Equals(System.Net.IPNetwork)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._baseAddress = this._baseAddress;
                copy.PrefixLength = this.PrefixLength;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._baseAddress = null;
            }
            static $h = 3399436;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":3071756,"g":{"r":0,"d":0,"h":12888301324,"f":1},"n":"BaseAddress","d":3399436,"h":8593334028,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25773203212,"f":1},"n":"PrefixLength","d":3399436,"h":21478235916,"f":1}],"m":[{"r":262145,"p":[{"n":"address","p":3071756}],"n":"Contains","d":3399436,"h":34363137804,"f":1},{"r":3399436,"p":[{"n":"s","p":1310721}],"n":"Parse","d":3399436,"h":38658105100,"f":33},{"r":3399436,"p":[{"n":"s","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h}],"n":"Parse","o":"@$1","d":3399436,"h":42953072396,"f":33},{"r":3399436,"p":[{"n":"utf8Text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Parse","o":"@$2","d":3399436,"h":47248039692,"f":33},{"r":262145,"p":[{"n":"s","p":1310721},{"n":"result","p":3399436,"f":2}],"n":"TryParse","d":3399436,"h":51543006988,"f":33},{"r":262145,"p":[{"n":"s","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Char).$h},{"n":"result","p":3399436,"f":2}],"n":"TryParse","o":"@$1","d":3399436,"h":55837974284,"f":33},{"r":262145,"p":[{"n":"utf8Text","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"result","p":3399436,"f":2}],"n":"TryParse","o":"@$2","d":3399436,"h":60132941580,"f":33},{"r":655361,"p":[{"n":"baseAddress","p":3071756}],"n":"GetMaxPrefixLength","d":3399436,"h":64427908876,"f":34},{"r":3071756,"p":[{"n":"baseAddress","p":3071756},{"n":"prefixLength","p":655361}],"n":"ClearNonZeroBitsAfterNetworkPrefix","d":3399436,"h":68722876172,"f":34},{"r":1310721,"n":"ToString","d":3399436,"h":73017843468,"f":32769},{"r":262145,"p":[{"n":"destination","p":$.$spc.System.Span$$($.$spc.System.Char).$h},{"n":"charsWritten","p":655361,"f":2}],"n":"TryFormat","d":3399436,"h":77312810764,"f":1},{"r":262145,"p":[{"n":"utf8Destination","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"bytesWritten","p":655361,"f":2}],"n":"TryFormat","o":"@$1","d":3399436,"h":81607778060,"f":1},{"r":262145,"p":[{"n":"other","p":3399436}],"n":"Equals","o":"@$2","d":3399436,"h":85902745356,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":3399436,"h":90197712652,"f":32769},{"r":655361,"n":"GetHashCode","d":3399436,"h":103082614540,"f":32769}],"l":[{"t":3071756,"n":"_baseAddress","d":3399436,"h":4298366732,"f":2}],"c":[{"p":[{"n":"baseAddress","p":3071756},{"n":"prefixLength","p":655361}],"n":".ctor","o":"$ctor$2","d":3399436,"h":30068170508,"f":1},{"n":".ctor","o":"$ctor$3","d":3399436,"h":146032287500,"f":1}],"i":[$.$spc.System.IEquatable$$($.$snp.System.Net.IPNetwork).$h,63766529,57671681,$.$spc.System.ISpanParsable$$($.$snp.System.Net.IPNetwork).$h,$.$spc.System.IParsable$$($.$snp.System.Net.IPNetwork).$h,64094209,$.$spc.System.IUtf8SpanParsable$$($.$snp.System.Net.IPNetwork).$h],"h":3399436}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$snp.System.Net.IPNetwork), $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.ISpanParsable$$($.$snp.System.Net.IPNetwork), $.$spc.System.IParsable$$($.$snp.System.Net.IPNetwork), $.$spc.System.IUtf8SpanFormattable, $.$spc.System.IUtf8SpanParsable$$($.$snp.System.Net.IPNetwork) ]; }
            static get $fullName() { return `System.Net.IPNetwork`; }
        });
        
        $asm.$str("$snp.System.Net.AuthenticationSchemes", ($self) => class AuthenticationSchemes extends $.$spc.System.Enum
        {
            static None = 0;
            static Digest = 1;
            static Negotiate = 2;
            static Ntlm = 4;
            static Basic = 8;
            static Anonymous = 32768;
            static IntegratedWindowsAuthentication = 6;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Digest": 1n,
                    "Negotiate": 2n,
                    "Ntlm": 4n,
                    "Basic": 8n,
                    "Anonymous": 32768n,
                    "IntegratedWindowsAuthentication": 6n
                };
            }
            static $h = 974604;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":974604,"n":"None","d":974604,"h":4295941900,"f":33},{"t":974604,"n":"Digest","d":974604,"h":8590909196,"f":33},{"t":974604,"n":"Negotiate","d":974604,"h":12885876492,"f":33},{"t":974604,"n":"Ntlm","d":974604,"h":17180843788,"f":33},{"t":974604,"n":"Basic","d":974604,"h":21475811084,"f":33},{"t":974604,"n":"Anonymous","d":974604,"h":25770778380,"f":33},{"t":974604,"n":"IntegratedWindowsAuthentication","d":974604,"h":30065745676,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":974604,"h":34360712972,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":974604,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.AuthenticationSchemes`; }
        });
        
        $asm.$str("$snp.System.Net.CookieVariant", ($self) => class CookieVariant extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Plain = 1;
            static Rfc2109 = 2;
            static Rfc2965 = 3;
            static Default = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Plain": 1n,
                    "Rfc2109": 2n,
                    "Rfc2965": 3n,
                    "Default": 2n
                };
            }
            static $h = 1892108;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1892108,"n":"Unknown","d":1892108,"h":4296859404,"f":33},{"t":1892108,"n":"Plain","d":1892108,"h":8591826700,"f":33},{"t":1892108,"n":"Rfc2109","d":1892108,"h":12886793996,"f":33},{"t":1892108,"n":"Rfc2965","d":1892108,"h":17181761292,"f":33},{"t":1892108,"n":"Default","d":1892108,"h":21476728588,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1892108,"h":25771695884,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1892108,"a":[{"t":96272385,"c":4391239681,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.CookieVariant`; }
        });
        
        $asm.$str("$snp.System.Net.DecompressionMethods", ($self) => class DecompressionMethods extends $.$spc.System.Enum
        {
            static None = 0;
            static GZip = 1;
            static Deflate = 2;
            static Brotli = 4;
            static All = -1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "GZip": 1n,
                    "Deflate": 2n,
                    "Brotli": 4n,
                    "All": -1n
                };
            }
            static $h = 2481932;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2481932,"n":"None","d":2481932,"h":4297449228,"f":33},{"t":2481932,"n":"GZip","d":2481932,"h":8592416524,"f":33},{"t":2481932,"n":"Deflate","d":2481932,"h":12887383820,"f":33},{"t":2481932,"n":"Brotli","d":2481932,"h":17182351116,"f":33},{"t":2481932,"n":"All","d":2481932,"h":21477318412,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2481932,"h":25772285708,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2481932,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.DecompressionMethods`; }
        });
        
        $asm.$str("$snp.System.Net.HttpStatusCode", ($self) => class HttpStatusCode extends $.$spc.System.Enum
        {
            static Continue = 100;
            static SwitchingProtocols = 101;
            static Processing = 102;
            static EarlyHints = 103;
            static OK = 200;
            static Created = 201;
            static Accepted = 202;
            static NonAuthoritativeInformation = 203;
            static NoContent = 204;
            static ResetContent = 205;
            static PartialContent = 206;
            static MultiStatus = 207;
            static AlreadyReported = 208;
            static IMUsed = 226;
            static MultipleChoices = 300;
            static Ambiguous = 300;
            static MovedPermanently = 301;
            static Moved = 301;
            static Found = 302;
            static Redirect = 302;
            static SeeOther = 303;
            static RedirectMethod = 303;
            static NotModified = 304;
            static UseProxy = 305;
            static Unused = 306;
            static TemporaryRedirect = 307;
            static RedirectKeepVerb = 307;
            static PermanentRedirect = 308;
            static BadRequest = 400;
            static Unauthorized = 401;
            static PaymentRequired = 402;
            static Forbidden = 403;
            static NotFound = 404;
            static MethodNotAllowed = 405;
            static NotAcceptable = 406;
            static ProxyAuthenticationRequired = 407;
            static RequestTimeout = 408;
            static Conflict = 409;
            static Gone = 410;
            static LengthRequired = 411;
            static PreconditionFailed = 412;
            static RequestEntityTooLarge = 413;
            static RequestUriTooLong = 414;
            static UnsupportedMediaType = 415;
            static RequestedRangeNotSatisfiable = 416;
            static ExpectationFailed = 417;
            static MisdirectedRequest = 421;
            static UnprocessableEntity = 422;
            static UnprocessableContent = 422;
            static Locked = 423;
            static FailedDependency = 424;
            static UpgradeRequired = 426;
            static PreconditionRequired = 428;
            static TooManyRequests = 429;
            static RequestHeaderFieldsTooLarge = 431;
            static UnavailableForLegalReasons = 451;
            static InternalServerError = 500;
            static NotImplemented = 501;
            static BadGateway = 502;
            static ServiceUnavailable = 503;
            static GatewayTimeout = 504;
            static HttpVersionNotSupported = 505;
            static VariantAlsoNegotiates = 506;
            static InsufficientStorage = 507;
            static LoopDetected = 508;
            static NotExtended = 510;
            static NetworkAuthenticationRequired = 511;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Continue": 100n,
                    "SwitchingProtocols": 101n,
                    "Processing": 102n,
                    "EarlyHints": 103n,
                    "OK": 200n,
                    "Created": 201n,
                    "Accepted": 202n,
                    "NonAuthoritativeInformation": 203n,
                    "NoContent": 204n,
                    "ResetContent": 205n,
                    "PartialContent": 206n,
                    "MultiStatus": 207n,
                    "AlreadyReported": 208n,
                    "IMUsed": 226n,
                    "MultipleChoices": 300n,
                    "Ambiguous": 300n,
                    "MovedPermanently": 301n,
                    "Moved": 301n,
                    "Found": 302n,
                    "Redirect": 302n,
                    "SeeOther": 303n,
                    "RedirectMethod": 303n,
                    "NotModified": 304n,
                    "UseProxy": 305n,
                    "Unused": 306n,
                    "TemporaryRedirect": 307n,
                    "RedirectKeepVerb": 307n,
                    "PermanentRedirect": 308n,
                    "BadRequest": 400n,
                    "Unauthorized": 401n,
                    "PaymentRequired": 402n,
                    "Forbidden": 403n,
                    "NotFound": 404n,
                    "MethodNotAllowed": 405n,
                    "NotAcceptable": 406n,
                    "ProxyAuthenticationRequired": 407n,
                    "RequestTimeout": 408n,
                    "Conflict": 409n,
                    "Gone": 410n,
                    "LengthRequired": 411n,
                    "PreconditionFailed": 412n,
                    "RequestEntityTooLarge": 413n,
                    "RequestUriTooLong": 414n,
                    "UnsupportedMediaType": 415n,
                    "RequestedRangeNotSatisfiable": 416n,
                    "ExpectationFailed": 417n,
                    "MisdirectedRequest": 421n,
                    "UnprocessableEntity": 422n,
                    "UnprocessableContent": 422n,
                    "Locked": 423n,
                    "FailedDependency": 424n,
                    "UpgradeRequired": 426n,
                    "PreconditionRequired": 428n,
                    "TooManyRequests": 429n,
                    "RequestHeaderFieldsTooLarge": 431n,
                    "UnavailableForLegalReasons": 451n,
                    "InternalServerError": 500n,
                    "NotImplemented": 501n,
                    "BadGateway": 502n,
                    "ServiceUnavailable": 503n,
                    "GatewayTimeout": 504n,
                    "HttpVersionNotSupported": 505n,
                    "VariantAlsoNegotiates": 506n,
                    "InsufficientStorage": 507n,
                    "LoopDetected": 508n,
                    "NotExtended": 510n,
                    "NetworkAuthenticationRequired": 511n
                };
            }
            static $h = 2809612;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":2809612,"n":"Continue","d":2809612,"h":4297776908,"f":33},{"t":2809612,"n":"SwitchingProtocols","d":2809612,"h":8592744204,"f":33},{"t":2809612,"n":"Processing","d":2809612,"h":12887711500,"f":33},{"t":2809612,"n":"EarlyHints","d":2809612,"h":17182678796,"f":33},{"t":2809612,"n":"OK","d":2809612,"h":21477646092,"f":33},{"t":2809612,"n":"Created","d":2809612,"h":25772613388,"f":33},{"t":2809612,"n":"Accepted","d":2809612,"h":30067580684,"f":33},{"t":2809612,"n":"NonAuthoritativeInformation","d":2809612,"h":34362547980,"f":33},{"t":2809612,"n":"NoContent","d":2809612,"h":38657515276,"f":33},{"t":2809612,"n":"ResetContent","d":2809612,"h":42952482572,"f":33},{"t":2809612,"n":"PartialContent","d":2809612,"h":47247449868,"f":33},{"t":2809612,"n":"MultiStatus","d":2809612,"h":51542417164,"f":33},{"t":2809612,"n":"AlreadyReported","d":2809612,"h":55837384460,"f":33},{"t":2809612,"n":"IMUsed","d":2809612,"h":60132351756,"f":33},{"t":2809612,"n":"MultipleChoices","d":2809612,"h":64427319052,"f":33},{"t":2809612,"n":"Ambiguous","d":2809612,"h":68722286348,"f":33},{"t":2809612,"n":"MovedPermanently","d":2809612,"h":73017253644,"f":33},{"t":2809612,"n":"Moved","d":2809612,"h":77312220940,"f":33},{"t":2809612,"n":"Found","d":2809612,"h":81607188236,"f":33},{"t":2809612,"n":"Redirect","d":2809612,"h":85902155532,"f":33},{"t":2809612,"n":"SeeOther","d":2809612,"h":90197122828,"f":33},{"t":2809612,"n":"RedirectMethod","d":2809612,"h":94492090124,"f":33},{"t":2809612,"n":"NotModified","d":2809612,"h":98787057420,"f":33},{"t":2809612,"n":"UseProxy","d":2809612,"h":103082024716,"f":33},{"t":2809612,"n":"Unused","d":2809612,"h":107376992012,"f":33},{"t":2809612,"n":"TemporaryRedirect","d":2809612,"h":111671959308,"f":33},{"t":2809612,"n":"RedirectKeepVerb","d":2809612,"h":115966926604,"f":33},{"t":2809612,"n":"PermanentRedirect","d":2809612,"h":120261893900,"f":33},{"t":2809612,"n":"BadRequest","d":2809612,"h":124556861196,"f":33},{"t":2809612,"n":"Unauthorized","d":2809612,"h":128851828492,"f":33},{"t":2809612,"n":"PaymentRequired","d":2809612,"h":133146795788,"f":33},{"t":2809612,"n":"Forbidden","d":2809612,"h":137441763084,"f":33},{"t":2809612,"n":"NotFound","d":2809612,"h":141736730380,"f":33},{"t":2809612,"n":"MethodNotAllowed","d":2809612,"h":146031697676,"f":33},{"t":2809612,"n":"NotAcceptable","d":2809612,"h":150326664972,"f":33},{"t":2809612,"n":"ProxyAuthenticationRequired","d":2809612,"h":154621632268,"f":33},{"t":2809612,"n":"RequestTimeout","d":2809612,"h":158916599564,"f":33},{"t":2809612,"n":"Conflict","d":2809612,"h":163211566860,"f":33},{"t":2809612,"n":"Gone","d":2809612,"h":167506534156,"f":33},{"t":2809612,"n":"LengthRequired","d":2809612,"h":171801501452,"f":33},{"t":2809612,"n":"PreconditionFailed","d":2809612,"h":176096468748,"f":33},{"t":2809612,"n":"RequestEntityTooLarge","d":2809612,"h":180391436044,"f":33},{"t":2809612,"n":"RequestUriTooLong","d":2809612,"h":184686403340,"f":33},{"t":2809612,"n":"UnsupportedMediaType","d":2809612,"h":188981370636,"f":33},{"t":2809612,"n":"RequestedRangeNotSatisfiable","d":2809612,"h":193276337932,"f":33},{"t":2809612,"n":"ExpectationFailed","d":2809612,"h":197571305228,"f":33},{"t":2809612,"n":"MisdirectedRequest","d":2809612,"h":201866272524,"f":33},{"t":2809612,"n":"UnprocessableEntity","d":2809612,"h":206161239820,"f":33},{"t":2809612,"n":"UnprocessableContent","d":2809612,"h":210456207116,"f":33},{"t":2809612,"n":"Locked","d":2809612,"h":214751174412,"f":33},{"t":2809612,"n":"FailedDependency","d":2809612,"h":219046141708,"f":33},{"t":2809612,"n":"UpgradeRequired","d":2809612,"h":223341109004,"f":33},{"t":2809612,"n":"PreconditionRequired","d":2809612,"h":227636076300,"f":33},{"t":2809612,"n":"TooManyRequests","d":2809612,"h":231931043596,"f":33},{"t":2809612,"n":"RequestHeaderFieldsTooLarge","d":2809612,"h":236226010892,"f":33},{"t":2809612,"n":"UnavailableForLegalReasons","d":2809612,"h":240520978188,"f":33},{"t":2809612,"n":"InternalServerError","d":2809612,"h":244815945484,"f":33},{"t":2809612,"n":"NotImplemented","d":2809612,"h":249110912780,"f":33},{"t":2809612,"n":"BadGateway","d":2809612,"h":253405880076,"f":33},{"t":2809612,"n":"ServiceUnavailable","d":2809612,"h":257700847372,"f":33},{"t":2809612,"n":"GatewayTimeout","d":2809612,"h":261995814668,"f":33},{"t":2809612,"n":"HttpVersionNotSupported","d":2809612,"h":266290781964,"f":33},{"t":2809612,"n":"VariantAlsoNegotiates","d":2809612,"h":270585749260,"f":33},{"t":2809612,"n":"InsufficientStorage","d":2809612,"h":274880716556,"f":33},{"t":2809612,"n":"LoopDetected","d":2809612,"h":279175683852,"f":33},{"t":2809612,"n":"NotExtended","d":2809612,"h":283470651148,"f":33},{"t":2809612,"n":"NetworkAuthenticationRequired","d":2809612,"h":287765618444,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":2809612,"h":292060585740,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":2809612}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.HttpStatusCode`; }
        });
        
        $asm.$str("$snp.System.Net.Security.AuthenticationLevel", ($self) => class AuthenticationLevel extends $.$spc.System.Enum
        {
            static None = 0;
            static MutualAuthRequested = 1;
            static MutualAuthRequired = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "MutualAuthRequested": 1n,
                    "MutualAuthRequired": 2n
                };
            }
            static $h = 4251404;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4251404,"n":"None","d":4251404,"h":4299218700,"f":33},{"t":4251404,"n":"MutualAuthRequested","d":4251404,"h":8594185996,"f":33},{"t":4251404,"n":"MutualAuthRequired","d":4251404,"h":12889153292,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4251404,"h":17184120588,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4251404}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.AuthenticationLevel`; }
        });
        
        $asm.$str("$snp.System.Security.Authentication.SslProtocols", ($self) => class SslProtocols extends $.$spc.System.Enum
        {
            static None = 0;
            static Ssl2 = 12;
            static Ssl3 = 48;
            static Tls = 192;
            static Tls11 = 768;
            static Tls12 = 3072;
            static Tls13 = 12288;
            static Default = 240;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Ssl2": 12n,
                    "Ssl3": 48n,
                    "Tls": 192n,
                    "Tls11": 768n,
                    "Tls12": 3072n,
                    "Tls13": 12288n,
                    "Default": 240n
                };
            }
            static $h = 5627660;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5627660,"n":"None","d":5627660,"h":4300594956,"f":33},{"t":5627660,"n":"Ssl2","d":5627660,"h":8595562252,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SslProtocols.Ssl2 has been deprecated and is not supported.","t":1310721}]}]},{"t":5627660,"n":"Ssl3","d":5627660,"h":12890529548,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SslProtocols.Ssl3 has been deprecated and is not supported.","t":1310721}]}]},{"t":5627660,"n":"Tls","d":5627660,"h":17185496844,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0039","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"t":5627660,"n":"Tls11","d":5627660,"h":21480464140,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"TLS versions 1.0 and 1.1 have known vulnerabilities and are not recommended. Use a newer TLS version instead, or use SslProtocols.None to defer to OS defaults.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0039","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"t":5627660,"n":"Tls12","d":5627660,"h":25775431436,"f":33},{"t":5627660,"n":"Tls13","d":5627660,"h":30070398732,"f":33},{"t":5627660,"n":"Default","d":5627660,"h":34365366028,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SslProtocols.Default has been deprecated and is not supported.","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":5627660,"h":38660333324,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":5627660,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.SslProtocols`; }
        });
        
        $asm.$str("$snp.System.Security.Authentication.ExchangeAlgorithmType", ($self) => class ExchangeAlgorithmType extends $.$spc.System.Enum
        {
            static None = 0;
            static RsaSign = 9216;
            static RsaKeyX = 41984;
            static DiffieHellman = 43522;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "RsaSign": 9216n,
                    "RsaKeyX": 41984n,
                    "DiffieHellman": 43522n
                };
            }
            static $h = 5365516;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5365516,"n":"None","d":5365516,"h":4300332812,"f":33},{"t":5365516,"n":"RsaSign","d":5365516,"h":8595300108,"f":33},{"t":5365516,"n":"RsaKeyX","d":5365516,"h":12890267404,"f":33},{"t":5365516,"n":"DiffieHellman","d":5365516,"h":17185234700,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5365516,"h":21480201996,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":5365516,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExchangeAlgorithmType`; }
        });
        
        $asm.$str("$snp.System.Security.Authentication.CipherAlgorithmType", ($self) => class CipherAlgorithmType extends $.$spc.System.Enum
        {
            static None = 0;
            static Rc2 = 26114;
            static Rc4 = 26625;
            static Des = 26113;
            static TripleDes = 26115;
            static Aes = 26129;
            static Aes128 = 26126;
            static Aes192 = 26127;
            static Aes256 = 26128;
            static Null = 24576;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Rc2": 26114n,
                    "Rc4": 26625n,
                    "Des": 26113n,
                    "TripleDes": 26115n,
                    "Aes": 26129n,
                    "Aes128": 26126n,
                    "Aes192": 26127n,
                    "Aes256": 26128n,
                    "Null": 24576n
                };
            }
            static $h = 5299980;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5299980,"n":"None","d":5299980,"h":4300267276,"f":33},{"t":5299980,"n":"Rc2","d":5299980,"h":8595234572,"f":33},{"t":5299980,"n":"Rc4","d":5299980,"h":12890201868,"f":33},{"t":5299980,"n":"Des","d":5299980,"h":17185169164,"f":33},{"t":5299980,"n":"TripleDes","d":5299980,"h":21480136460,"f":33},{"t":5299980,"n":"Aes","d":5299980,"h":25775103756,"f":33},{"t":5299980,"n":"Aes128","d":5299980,"h":30070071052,"f":33},{"t":5299980,"n":"Aes192","d":5299980,"h":34365038348,"f":33},{"t":5299980,"n":"Aes256","d":5299980,"h":38660005644,"f":33},{"t":5299980,"n":"Null","d":5299980,"h":42954972940,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5299980,"h":47249940236,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":5299980,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.CipherAlgorithmType`; }
        });
        
        $asm.$str("$snp.System.Security.Authentication.HashAlgorithmType", ($self) => class HashAlgorithmType extends $.$spc.System.Enum
        {
            static None = 0;
            static Md5 = 32771;
            static Sha1 = 32772;
            static Sha256 = 32780;
            static Sha384 = 32781;
            static Sha512 = 32782;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Md5": 32771n,
                    "Sha1": 32772n,
                    "Sha256": 32780n,
                    "Sha384": 32781n,
                    "Sha512": 32782n
                };
            }
            static $h = 5562124;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5562124,"n":"None","d":5562124,"h":4300529420,"f":33},{"t":5562124,"n":"Md5","d":5562124,"h":8595496716,"f":33},{"t":5562124,"n":"Sha1","d":5562124,"h":12890464012,"f":33},{"t":5562124,"n":"Sha256","d":5562124,"h":17185431308,"f":33},{"t":5562124,"n":"Sha384","d":5562124,"h":21480398604,"f":33},{"t":5562124,"n":"Sha512","d":5562124,"h":25775365900,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5562124,"h":30070333196,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":5562124,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.HashAlgorithmType`; }
        });
        
        $asm.$str("$snp.System.Net.Cache.RequestCacheLevel", ($self) => class RequestCacheLevel extends $.$spc.System.Enum
        {
            static Default = 0;
            static BypassCache = 1;
            static CacheOnly = 2;
            static CacheIfAvailable = 3;
            static Revalidate = 4;
            static Reload = 5;
            static NoCacheNoStore = 6;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Default": 0n,
                    "BypassCache": 1n,
                    "CacheOnly": 2n,
                    "CacheIfAvailable": 3n,
                    "Revalidate": 4n,
                    "Reload": 5n,
                    "NoCacheNoStore": 6n
                };
            }
            static $h = 1040140;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1040140,"n":"Default","d":1040140,"h":4296007436,"f":33},{"t":1040140,"n":"BypassCache","d":1040140,"h":8590974732,"f":33},{"t":1040140,"n":"CacheOnly","d":1040140,"h":12885942028,"f":33},{"t":1040140,"n":"CacheIfAvailable","d":1040140,"h":17180909324,"f":33},{"t":1040140,"n":"Revalidate","d":1040140,"h":21475876620,"f":33},{"t":1040140,"n":"Reload","d":1040140,"h":25770843916,"f":33},{"t":1040140,"n":"NoCacheNoStore","d":1040140,"h":30065811212,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1040140,"h":34360778508,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1040140}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Cache.RequestCacheLevel`; }
        });
        
        $asm.$str("$snp.System.Net.Sockets.SocketError", ($self) => class SocketError extends $.$spc.System.Enum
        {
            static Success = 0;
            static SocketError = -1;
            static Interrupted = 10004;
            static AccessDenied = 10013;
            static Fault = 10014;
            static InvalidArgument = 10022;
            static TooManyOpenSockets = 10024;
            static WouldBlock = 10035;
            static InProgress = 10036;
            static AlreadyInProgress = 10037;
            static NotSocket = 10038;
            static DestinationAddressRequired = 10039;
            static MessageSize = 10040;
            static ProtocolType = 10041;
            static ProtocolOption = 10042;
            static ProtocolNotSupported = 10043;
            static SocketNotSupported = 10044;
            static OperationNotSupported = 10045;
            static ProtocolFamilyNotSupported = 10046;
            static AddressFamilyNotSupported = 10047;
            static AddressAlreadyInUse = 10048;
            static AddressNotAvailable = 10049;
            static NetworkDown = 10050;
            static NetworkUnreachable = 10051;
            static NetworkReset = 10052;
            static ConnectionAborted = 10053;
            static ConnectionReset = 10054;
            static NoBufferSpaceAvailable = 10055;
            static IsConnected = 10056;
            static NotConnected = 10057;
            static Shutdown = 10058;
            static TimedOut = 10060;
            static ConnectionRefused = 10061;
            static HostDown = 10064;
            static HostUnreachable = 10065;
            static ProcessLimit = 10067;
            static SystemNotReady = 10091;
            static VersionNotSupported = 10092;
            static NotInitialized = 10093;
            static Disconnecting = 10101;
            static TypeNotFound = 10109;
            static HostNotFound = 11001;
            static TryAgain = 11002;
            static NoRecovery = 11003;
            static NoData = 11004;
            static IOPending = 997;
            static OperationAborted = 995;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Success": 0n,
                    "SocketError": -1n,
                    "Interrupted": 10004n,
                    "AccessDenied": 10013n,
                    "Fault": 10014n,
                    "InvalidArgument": 10022n,
                    "TooManyOpenSockets": 10024n,
                    "WouldBlock": 10035n,
                    "InProgress": 10036n,
                    "AlreadyInProgress": 10037n,
                    "NotSocket": 10038n,
                    "DestinationAddressRequired": 10039n,
                    "MessageSize": 10040n,
                    "ProtocolType": 10041n,
                    "ProtocolOption": 10042n,
                    "ProtocolNotSupported": 10043n,
                    "SocketNotSupported": 10044n,
                    "OperationNotSupported": 10045n,
                    "ProtocolFamilyNotSupported": 10046n,
                    "AddressFamilyNotSupported": 10047n,
                    "AddressAlreadyInUse": 10048n,
                    "AddressNotAvailable": 10049n,
                    "NetworkDown": 10050n,
                    "NetworkUnreachable": 10051n,
                    "NetworkReset": 10052n,
                    "ConnectionAborted": 10053n,
                    "ConnectionReset": 10054n,
                    "NoBufferSpaceAvailable": 10055n,
                    "IsConnected": 10056n,
                    "NotConnected": 10057n,
                    "Shutdown": 10058n,
                    "TimedOut": 10060n,
                    "ConnectionRefused": 10061n,
                    "HostDown": 10064n,
                    "HostUnreachable": 10065n,
                    "ProcessLimit": 10067n,
                    "SystemNotReady": 10091n,
                    "VersionNotSupported": 10092n,
                    "NotInitialized": 10093n,
                    "Disconnecting": 10101n,
                    "TypeNotFound": 10109n,
                    "HostNotFound": 11001n,
                    "TryAgain": 11002n,
                    "NoRecovery": 11003n,
                    "NoData": 11004n,
                    "IOPending": 997n,
                    "OperationAborted": 995n
                };
            }
            static $h = 4710156;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4710156,"n":"Success","d":4710156,"h":4299677452,"f":33},{"t":4710156,"n":"SocketError","d":4710156,"h":8594644748,"f":33},{"t":4710156,"n":"Interrupted","d":4710156,"h":12889612044,"f":33},{"t":4710156,"n":"AccessDenied","d":4710156,"h":17184579340,"f":33},{"t":4710156,"n":"Fault","d":4710156,"h":21479546636,"f":33},{"t":4710156,"n":"InvalidArgument","d":4710156,"h":25774513932,"f":33},{"t":4710156,"n":"TooManyOpenSockets","d":4710156,"h":30069481228,"f":33},{"t":4710156,"n":"WouldBlock","d":4710156,"h":34364448524,"f":33},{"t":4710156,"n":"InProgress","d":4710156,"h":38659415820,"f":33},{"t":4710156,"n":"AlreadyInProgress","d":4710156,"h":42954383116,"f":33},{"t":4710156,"n":"NotSocket","d":4710156,"h":47249350412,"f":33},{"t":4710156,"n":"DestinationAddressRequired","d":4710156,"h":51544317708,"f":33},{"t":4710156,"n":"MessageSize","d":4710156,"h":55839285004,"f":33},{"t":4710156,"n":"ProtocolType","d":4710156,"h":60134252300,"f":33},{"t":4710156,"n":"ProtocolOption","d":4710156,"h":64429219596,"f":33},{"t":4710156,"n":"ProtocolNotSupported","d":4710156,"h":68724186892,"f":33},{"t":4710156,"n":"SocketNotSupported","d":4710156,"h":73019154188,"f":33},{"t":4710156,"n":"OperationNotSupported","d":4710156,"h":77314121484,"f":33},{"t":4710156,"n":"ProtocolFamilyNotSupported","d":4710156,"h":81609088780,"f":33},{"t":4710156,"n":"AddressFamilyNotSupported","d":4710156,"h":85904056076,"f":33},{"t":4710156,"n":"AddressAlreadyInUse","d":4710156,"h":90199023372,"f":33},{"t":4710156,"n":"AddressNotAvailable","d":4710156,"h":94493990668,"f":33},{"t":4710156,"n":"NetworkDown","d":4710156,"h":98788957964,"f":33},{"t":4710156,"n":"NetworkUnreachable","d":4710156,"h":103083925260,"f":33},{"t":4710156,"n":"NetworkReset","d":4710156,"h":107378892556,"f":33},{"t":4710156,"n":"ConnectionAborted","d":4710156,"h":111673859852,"f":33},{"t":4710156,"n":"ConnectionReset","d":4710156,"h":115968827148,"f":33},{"t":4710156,"n":"NoBufferSpaceAvailable","d":4710156,"h":120263794444,"f":33},{"t":4710156,"n":"IsConnected","d":4710156,"h":124558761740,"f":33},{"t":4710156,"n":"NotConnected","d":4710156,"h":128853729036,"f":33},{"t":4710156,"n":"Shutdown","d":4710156,"h":133148696332,"f":33},{"t":4710156,"n":"TimedOut","d":4710156,"h":137443663628,"f":33},{"t":4710156,"n":"ConnectionRefused","d":4710156,"h":141738630924,"f":33},{"t":4710156,"n":"HostDown","d":4710156,"h":146033598220,"f":33},{"t":4710156,"n":"HostUnreachable","d":4710156,"h":150328565516,"f":33},{"t":4710156,"n":"ProcessLimit","d":4710156,"h":154623532812,"f":33},{"t":4710156,"n":"SystemNotReady","d":4710156,"h":158918500108,"f":33},{"t":4710156,"n":"VersionNotSupported","d":4710156,"h":163213467404,"f":33},{"t":4710156,"n":"NotInitialized","d":4710156,"h":167508434700,"f":33},{"t":4710156,"n":"Disconnecting","d":4710156,"h":171803401996,"f":33},{"t":4710156,"n":"TypeNotFound","d":4710156,"h":176098369292,"f":33},{"t":4710156,"n":"HostNotFound","d":4710156,"h":180393336588,"f":33},{"t":4710156,"n":"TryAgain","d":4710156,"h":184688303884,"f":33},{"t":4710156,"n":"NoRecovery","d":4710156,"h":188983271180,"f":33},{"t":4710156,"n":"NoData","d":4710156,"h":193278238476,"f":33},{"t":4710156,"n":"IOPending","d":4710156,"h":197573205772,"f":33},{"t":4710156,"n":"OperationAborted","d":4710156,"h":201868173068,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4710156,"h":206163140364,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4710156}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketError`; }
        });
        
        $asm.$str("$snp.System.Security.Authentication.ExtendedProtection.ChannelBindingKind", ($self) => class ChannelBindingKind extends $.$spc.System.Enum
        {
            static Unknown = 0;
            static Unique = 25;
            static Endpoint = 26;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": 0n,
                    "Unique": 25n,
                    "Endpoint": 26n
                };
            }
            static $h = 5496588;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":5496588,"n":"Unknown","d":5496588,"h":4300463884,"f":33},{"t":5496588,"n":"Unique","d":5496588,"h":8595431180,"f":33},{"t":5496588,"n":"Endpoint","d":5496588,"h":12890398476,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":5496588,"h":17185365772,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":5496588}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ChannelBindingKind`; }
        });
        
        $asm.$str("$snp.System.Net.CookieToken", ($self) => class CookieToken extends $.$spc.System.Enum
        {
            static Nothing = 0;
            static NameValuePair = 1;
            static Attribute = 2;
            static EndToken = 3;
            static EndCookie = 4;
            static End = 5;
            static Equals = 6;
            static Comment = 7;
            static CommentUrl = 8;
            static CookieName = 9;
            static Discard = 10;
            static Domain = 11;
            static Expires = 12;
            static MaxAge = 13;
            static Path = 14;
            static Port = 15;
            static Secure = 16;
            static HttpOnly = 17;
            static Unknown = 18;
            static Version = 19;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Nothing": 0n,
                    "NameValuePair": 1n,
                    "Attribute": 2n,
                    "EndToken": 3n,
                    "EndCookie": 4n,
                    "End": 5n,
                    "Equals": 6n,
                    "Comment": 7n,
                    "CommentUrl": 8n,
                    "CookieName": 9n,
                    "Discard": 10n,
                    "Domain": 11n,
                    "Expires": 12n,
                    "MaxAge": 13n,
                    "Path": 14n,
                    "Port": 15n,
                    "Secure": 16n,
                    "HttpOnly": 17n,
                    "Unknown": 18n,
                    "Version": 19n
                };
            }
            static $h = 1695500;
            static $z = 4;
            static $f = 0b100000011010001000;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1695500,"n":"Nothing","d":1695500,"h":4296662796,"f":33},{"t":1695500,"n":"NameValuePair","d":1695500,"h":8591630092,"f":33},{"t":1695500,"n":"Attribute","d":1695500,"h":12886597388,"f":33},{"t":1695500,"n":"EndToken","d":1695500,"h":17181564684,"f":33},{"t":1695500,"n":"EndCookie","d":1695500,"h":21476531980,"f":33},{"t":1695500,"n":"End","d":1695500,"h":25771499276,"f":33},{"t":1695500,"n":"Equals","d":1695500,"h":30066466572,"f":33},{"t":1695500,"n":"Comment","d":1695500,"h":34361433868,"f":33},{"t":1695500,"n":"CommentUrl","d":1695500,"h":38656401164,"f":33},{"t":1695500,"n":"CookieName","d":1695500,"h":42951368460,"f":33},{"t":1695500,"n":"Discard","d":1695500,"h":47246335756,"f":33},{"t":1695500,"n":"Domain","d":1695500,"h":51541303052,"f":33},{"t":1695500,"n":"Expires","d":1695500,"h":55836270348,"f":33},{"t":1695500,"n":"MaxAge","d":1695500,"h":60131237644,"f":33},{"t":1695500,"n":"Path","d":1695500,"h":64426204940,"f":33},{"t":1695500,"n":"Port","d":1695500,"h":68721172236,"f":33},{"t":1695500,"n":"Secure","d":1695500,"h":73016139532,"f":33},{"t":1695500,"n":"HttpOnly","d":1695500,"h":77311106828,"f":33},{"t":1695500,"n":"Unknown","d":1695500,"h":81606074124,"f":33},{"t":1695500,"n":"Version","d":1695500,"h":85901041420,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1695500,"h":90196008716,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1695500}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.CookieToken`; }
        });
        
        $asm.$str("$snp.System.Net.Security.SslPolicyErrors", ($self) => class SslPolicyErrors extends $.$spc.System.Enum
        {
            static None = 0;
            static RemoteCertificateNotAvailable = 1;
            static RemoteCertificateNameMismatch = 2;
            static RemoteCertificateChainErrors = 4;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "RemoteCertificateNotAvailable": 1n,
                    "RemoteCertificateNameMismatch": 2n,
                    "RemoteCertificateChainErrors": 4n
                };
            }
            static $h = 4316940;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4316940,"n":"None","d":4316940,"h":4299284236,"f":33},{"t":4316940,"n":"RemoteCertificateNotAvailable","d":4316940,"h":8594251532,"f":33},{"t":4316940,"n":"RemoteCertificateNameMismatch","d":4316940,"h":12889218828,"f":33},{"t":4316940,"n":"RemoteCertificateChainErrors","d":4316940,"h":17184186124,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4316940,"h":21479153420,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4316940,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.SslPolicyErrors`; }
        });
        
        $asm.$str("$snp.System.Net.Sockets.AddressFamily", ($self) => class AddressFamily extends $.$spc.System.Enum
        {
            static Unknown = -1;
            static Unspecified = 0;
            static Unix = 1;
            static InterNetwork = 2;
            static ImpLink = 3;
            static Pup = 4;
            static Chaos = 5;
            static NS = 6;
            static Ipx = 6;
            static Iso = 7;
            static Osi = 7;
            static Ecma = 8;
            static DataKit = 9;
            static Ccitt = 10;
            static Sna = 11;
            static DecNet = 12;
            static DataLink = 13;
            static Lat = 14;
            static HyperChannel = 15;
            static AppleTalk = 16;
            static NetBios = 17;
            static VoiceView = 18;
            static FireFox = 19;
            static Banyan = 21;
            static Atm = 22;
            static InterNetworkV6 = 23;
            static Cluster = 24;
            static Ieee12844 = 25;
            static Irda = 26;
            static NetworkDesigners = 28;
            static Max = 29;
            static Packet = 65536;
            static ControllerAreaNetwork = 65537;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "Unspecified": 0n,
                    "Unix": 1n,
                    "InterNetwork": 2n,
                    "ImpLink": 3n,
                    "Pup": 4n,
                    "Chaos": 5n,
                    "NS": 6n,
                    "Ipx": 6n,
                    "Iso": 7n,
                    "Osi": 7n,
                    "Ecma": 8n,
                    "DataKit": 9n,
                    "Ccitt": 10n,
                    "Sna": 11n,
                    "DecNet": 12n,
                    "DataLink": 13n,
                    "Lat": 14n,
                    "HyperChannel": 15n,
                    "AppleTalk": 16n,
                    "NetBios": 17n,
                    "VoiceView": 18n,
                    "FireFox": 19n,
                    "Banyan": 21n,
                    "Atm": 22n,
                    "InterNetworkV6": 23n,
                    "Cluster": 24n,
                    "Ieee12844": 25n,
                    "Irda": 26n,
                    "NetworkDesigners": 28n,
                    "Max": 29n,
                    "Packet": 65536n,
                    "ControllerAreaNetwork": 65537n
                };
            }
            static $h = 4513548;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":4513548,"n":"Unknown","d":4513548,"h":4299480844,"f":33},{"t":4513548,"n":"Unspecified","d":4513548,"h":8594448140,"f":33},{"t":4513548,"n":"Unix","d":4513548,"h":12889415436,"f":33},{"t":4513548,"n":"InterNetwork","d":4513548,"h":17184382732,"f":33},{"t":4513548,"n":"ImpLink","d":4513548,"h":21479350028,"f":33},{"t":4513548,"n":"Pup","d":4513548,"h":25774317324,"f":33},{"t":4513548,"n":"Chaos","d":4513548,"h":30069284620,"f":33},{"t":4513548,"n":"NS","d":4513548,"h":34364251916,"f":33},{"t":4513548,"n":"Ipx","d":4513548,"h":38659219212,"f":33},{"t":4513548,"n":"Iso","d":4513548,"h":42954186508,"f":33},{"t":4513548,"n":"Osi","d":4513548,"h":47249153804,"f":33},{"t":4513548,"n":"Ecma","d":4513548,"h":51544121100,"f":33},{"t":4513548,"n":"DataKit","d":4513548,"h":55839088396,"f":33},{"t":4513548,"n":"Ccitt","d":4513548,"h":60134055692,"f":33},{"t":4513548,"n":"Sna","d":4513548,"h":64429022988,"f":33},{"t":4513548,"n":"DecNet","d":4513548,"h":68723990284,"f":33},{"t":4513548,"n":"DataLink","d":4513548,"h":73018957580,"f":33},{"t":4513548,"n":"Lat","d":4513548,"h":77313924876,"f":33},{"t":4513548,"n":"HyperChannel","d":4513548,"h":81608892172,"f":33},{"t":4513548,"n":"AppleTalk","d":4513548,"h":85903859468,"f":33},{"t":4513548,"n":"NetBios","d":4513548,"h":90198826764,"f":33},{"t":4513548,"n":"VoiceView","d":4513548,"h":94493794060,"f":33},{"t":4513548,"n":"FireFox","d":4513548,"h":98788761356,"f":33},{"t":4513548,"n":"Banyan","d":4513548,"h":103083728652,"f":33},{"t":4513548,"n":"Atm","d":4513548,"h":107378695948,"f":33},{"t":4513548,"n":"InterNetworkV6","d":4513548,"h":111673663244,"f":33},{"t":4513548,"n":"Cluster","d":4513548,"h":115968630540,"f":33},{"t":4513548,"n":"Ieee12844","d":4513548,"h":120263597836,"f":33},{"t":4513548,"n":"Irda","d":4513548,"h":124558565132,"f":33},{"t":4513548,"n":"NetworkDesigners","d":4513548,"h":128853532428,"f":33},{"t":4513548,"n":"Max","d":4513548,"h":133148499724,"f":33},{"t":4513548,"n":"Packet","d":4513548,"h":137443467020,"f":33},{"t":4513548,"n":"ControllerAreaNetwork","d":4513548,"h":141738434316,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":4513548,"h":146033401612,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":4513548}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.AddressFamily`; }
        });
        
        $asm.$cls("$snp.System.Net.NetworkInformation.IPAddressCollection", ($self) => class IPAddressCollection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*void */ CopyTo(/*IPAddress[]*/ array, /*int*/ offset)
            {
                throw $.$snp.System.NotImplemented.ByDesign;
            }
            /*int */ get Count()
            {
                throw $.$snp.System.NotImplemented.ByDesign;
            }
            /*bool */ get IsReadOnly()
            {
                return true;
            }
            /*void */ Add(/*IPAddress*/ address)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$snp.System.SR.net_collection_readonly);
            }
            /*bool */ Contains(/*IPAddress*/ address)
            {
                throw $.$snp.System.NotImplemented.ByDesign;
            }
            /*System.Collections.IEnumerator */ System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator();
            }
            /*IEnumerator<IPAddress> */ GetEnumerator()
            {
                throw $.$snp.System.NotImplemented.ByDesign;
            }
            /*IPAddress*/ get_Item(/*int*/ index)
            {
                throw $.$snp.System.NotImplemented.ByDesign;
            }
            /*bool */ Remove(/*IPAddress*/ address)
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$snp.System.SR.net_collection_readonly);
            }
            /*void */ Clear()
            {
                throw new $.$spc.System.NotSupportedException().$ctor$10($.$snp.System.SR.net_collection_readonly);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.IPAddress>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.IPAddress>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.IPAddress>.Add(System.Net.IPAddress)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.IPAddress>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.IPAddress>.Contains(System.Net.IPAddress)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.IPAddress>.CopyTo(System.Net.IPAddress[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.IPAddress>.Remove(System.Net.IPAddress)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IEnumerable<System.Net.IPAddress>.GetEnumerator()
            System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            static $h = 4054796;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17183923980,"f":129},"n":"Count","d":4054796,"h":12888956684,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":25773858572,"f":129},"n":"IsReadOnly","d":4054796,"h":21478891276,"f":129},{"p":3071756,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":51543662348,"f":129},"n":"Item","o":"@$2","d":4054796,"h":47248695052,"f":129}],"m":[{"r":65537,"p":[{"n":"array","p":0},{"n":"offset","p":655361}],"n":"CopyTo","d":4054796,"h":8593989388,"f":129},{"r":65537,"p":[{"n":"address","p":3071756}],"n":"Add","d":4054796,"h":30068825868,"f":129},{"r":262145,"p":[{"n":"address","p":3071756}],"n":"Contains","d":4054796,"h":34363793164,"f":129},{"r":$.$spc.System.Collections.Generic.IEnumerator$$($.$snp.System.Net.IPAddress).$h,"n":"GetEnumerator","d":4054796,"h":42953727756,"f":129},{"r":262145,"p":[{"n":"address","p":3071756}],"n":"Remove","d":4054796,"h":55838629644,"f":129},{"r":65537,"n":"Clear","d":4054796,"h":60133596940,"f":129}],"c":[{"n":".ctor","o":"$ctor$1","d":4054796,"h":4299022092,"f":16}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snp.System.Net.IPAddress).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snp.System.Net.IPAddress).$h,31588353],"h":4054796}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snp.System.Net.IPAddress), $.$spc.System.Collections.Generic.IEnumerable$$($.$snp.System.Net.IPAddress), $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.NetworkInformation.IPAddressCollection`; }
        });
        
        $asm.$cls("$snp.System.Net.CookieCollection", ($self) => class CookieCollection extends $.$spc.System.Object
        {
            static $_Stamp;
            static get Stamp()
            {
                let $cls = $.$snp.System.Net.CookieCollection;
                return $cls.$_Stamp ??= $asm.$nstr("$snp.System.Net.CookieCollection.Stamp", ($self) => class Stamp extends $.$spc.System.Enum
                {
                    static Check = 0;
                    static Set = 1;
                    static SetToUnused = 2;
                    static SetToMaxUsed = 3;
                    static $map;
                    static get Map()
                    {
                        return this.$map ??= 
                        {
                            "Check": 0n,
                            "Set": 1n,
                            "SetToUnused": 2n,
                            "SetToMaxUsed": 3n
                        };
                    }
                    static $h = 1302284;
                    static $z = 4;
                    static $f = 0b110000011010001000;
                    static $k = 4;
                    static get $eut() { return $.$spc.System.Int32; }
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1302284,"n":"Check","d":1302284,"h":4296269580,"f":33},{"t":1302284,"n":"Set","d":1302284,"h":8591236876,"f":33},{"t":1302284,"n":"SetToUnused","d":1302284,"h":12886204172,"f":33},{"t":1302284,"n":"SetToMaxUsed","d":1302284,"h":17181171468,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1302284,"h":21476138764,"f":1}],"i":[57212929,63766529,57671681,57344001],"d":1236748,"h":1302284}; }
                    static get $b() { return $.$spc.System.Enum; }
                    static $$i;
                    static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
                    static get $fullName() { return `System.Net.CookieCollection.Stamp`; }
                }, $cls, ($v) => $cls.$_Stamp = $v);
            }
            /*ArrayList*/ m_list = null;
            /*int*/ m_version = 0;
            /*DateTime*/ m_TimeStamp;
            /*bool*/ m_has_other_versions = false;
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*Cookie*/ get_Item(/*int*/ index)
            {
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfNegative($.$spc.System.Int32, index, "index");
                $.$spc.System.ArgumentOutOfRangeException.ThrowIfGreaterThanOrEqual($.$spc.System.Int32, index, this.m_list.Count, "index");
                return ($.$as(this.m_list.get_Item(index), $.$snp.System.Net.Cookie));
            }
            /*Cookie?*/ get_Item$1(/*string*/ name)
            {
                var $en2 = this.m_list.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current;
                    {
                        if ($.$spc.System.String.Equals$5(c.Name, name, 5/*StringComparison.OrdinalIgnoreCase*/))
                        {
                            return c;
                        }
                    }
                }
                return null;
            }
            /*void */ OnSerializing(/*StreamingContext*/ context)
            {
                this.m_version = this.m_list.Count;
            }
            /*void */ Add(/*Cookie*/ cookie)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(cookie, "cookie");
                /*int*/ let idx = this.IndexOf(cookie);
                if (idx === -1)
                {
                    this.m_list.Add(cookie);
                }
                else 
                {
                    this.m_list.set_Item(idx, cookie);
                }
            }
            /*void */ Add$1(/*CookieCollection*/ cookies)
            {
                $.$spc.System.ArgumentNullException.ThrowIfNull(cookies, "cookies");
                var $en2 = cookies.m_list.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var cookie = $en2.Current;
                    {
                        this.Add(cookie);
                    }
                }
            }
            /*void */ Clear()
            {
                this.m_list.Clear();
            }
            /*bool */ Contains(/*Cookie*/ cookie)
            {
                return this.IndexOf(cookie) >= 0;
            }
            /*bool */ Remove(/*Cookie*/ cookie)
            {
                /*int*/ let idx = this.IndexOf(cookie);
                if (idx === -1)
                {
                    return false;
                }
                this.m_list.RemoveAt(idx);
                return true;
            }
            /*bool */ get IsReadOnly()
            {
                return false;
            }
            /*int */ get Count()
            {
                return this.m_list.Count;
            }
            /*bool */ get IsSynchronized()
            {
                return false;
            }
            /*object */ get SyncRoot()
            {
                return this;
            }
            /*void */ CopyTo(/*Array*/ array, /*int*/ index)
            {
                (this.m_list).System$Collections$ICollection$CopyTo(array, index);
            }
            /*void */ CopyTo$1(/*Cookie[]*/ array, /*int*/ index)
            {
                this.m_list.CopyTo$1(array, index);
            }
            /*DateTime */ TimeStamp(/*Stamp*/ how)
            {
                switch(how)
                {
                    case 1/*Stamp.Set*/:
                    this.m_TimeStamp = $.$spc.System.DateTime.Now;
                    break;
                    case 3/*Stamp.SetToMaxUsed*/:
                    this.m_TimeStamp = $.$spc.System.DateTime.MaxValue;
                    break;
                    case 2/*Stamp.SetToUnused*/:
                    this.m_TimeStamp = $.$spc.System.DateTime.MinValue;
                    break;
                    case 0/*Stamp.Check*/:
                    default:
                    break;
                }
                return this.m_TimeStamp;
            }
            /*bool */ get IsOtherVersionSeen()
            {
                return this.m_has_other_versions;
            }
            /*int */ InternalAdd(/*Cookie*/ cookie, /*bool*/ isStrict)
            {
                /*int*/ let ret = 1;
                if (isStrict)
                {
                    /*int*/ let idx = 0;
                    /*int*/ let listCount = this.m_list.Count;
                    for(/*int*/ let i = 0; i < listCount; i++)
                    {
                        /*Cookie*/ let c = $.$cast(this.m_list.get_Item(i), $.$snp.System.Net.Cookie);
                        if ($.$snp.System.Net.CookieComparer.Equals$2(cookie, c))
                        {
                            ret = 0;
                            if (c.Variant <= cookie.Variant)
                            {
                                this.m_list.set_Item(idx, cookie);
                            }
                            break;
                        }
                        ++idx;
                    }
                    if (idx === this.m_list.Count)
                    {
                        this.m_list.Add(cookie);
                    }
                }
                else 
                {
                    this.m_list.Add(cookie);
                }
                if (cookie.Version !== 1/*Cookie.MaxSupportedVersion*/)
                {
                    this.m_has_other_versions = true;
                }
                return ret;
            }
            /*int */ IndexOf(/*Cookie*/ cookie)
            {
                /*int*/ let idx = 0;
                var $en2 = this.m_list.GetEnumerator();
                while ($en2.MoveNext())
                {
                    var c = $en2.Current;
                    {
                        if ($.$snp.System.Net.CookieComparer.Equals$2(cookie, c))
                        {
                            return idx;
                        }
                        ++idx;
                    }
                }
                return -1;
            }
            /*void */ RemoveAt(/*int*/ idx)
            {
                this.m_list.RemoveAt(idx);
            }
            /*IEnumerator<Cookie> */ System$Collections$Generic$IEnumerable$$$GetEnumerator()
            {
                return new ($.$spc.NetJs.YieldToIterator$$($.$snp.System.Net.Cookie))().$ctor$1(function*()
                {
                    var $en3 = this.m_list.GetEnumerator();
                    while ($en3.MoveNext())
                    {
                        var cookie = $en3.Current;
                        {
                            yield cookie;
                        }
                    }
                }.bind(this)).GetEnumerator();
            }
            /*IEnumerator */ GetEnumerator()
            {
                return this.m_list.GetEnumerator();
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.Cookie>.Count.get
            get System$Collections$Generic$ICollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.Cookie>.IsReadOnly.get
            get System$Collections$Generic$ICollection$$$IsReadOnly()
            {
                return this.IsReadOnly;
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.Cookie>.Add(System.Net.Cookie)
            System$Collections$Generic$ICollection$$$Add()
            {
                return this.Add(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.Cookie>.Clear()
            System$Collections$Generic$ICollection$$$Clear()
            {
                return this.Clear(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.Cookie>.Contains(System.Net.Cookie)
            System$Collections$Generic$ICollection$$$Contains()
            {
                return this.Contains(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.Cookie>.CopyTo(System.Net.Cookie[], int)
            System$Collections$Generic$ICollection$$$CopyTo()
            {
                return this.CopyTo$1(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.ICollection<System.Net.Cookie>.Remove(System.Net.Cookie)
            System$Collections$Generic$ICollection$$$Remove()
            {
                return this.Remove(...arguments);
            }
            //Generated interface implemetation for System.Collections.Generic.IReadOnlyCollection<System.Net.Cookie>.Count.get
            get System$Collections$Generic$IReadOnlyCollection$$$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.CopyTo(System.Array, int)
            System$Collections$ICollection$CopyTo()
            {
                return this.CopyTo(...arguments);
            }
            //Generated interface implemetation for System.Collections.ICollection.Count.get
            get System$Collections$ICollection$Count()
            {
                return this.Count;
            }
            //Generated interface implemetation for System.Collections.ICollection.SyncRoot.get
            get System$Collections$ICollection$SyncRoot()
            {
                return this.SyncRoot;
            }
            //Generated interface implemetation for System.Collections.ICollection.IsSynchronized.get
            get System$Collections$ICollection$IsSynchronized()
            {
                return this.IsSynchronized;
            }
            //Generated interface implemetation for System.Collections.IEnumerable.GetEnumerator()
            System$Collections$IEnumerable$GetEnumerator()
            {
                return this.GetEnumerator(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                this.m_list = new $.$spc.System.Collections.ArrayList().$ctor$1();
                this.m_TimeStamp = $.$spc.System.DateTime.MinValue;
            }
            static $h = 1236748;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":1171212,"i":[{"n":"index","p":655361}],"g":{"r":0,"d":0,"h":34360975116,"f":1},"n":"Item","o":"@$2","d":1236748,"h":30066007820,"f":1},{"p":1171212,"i":[{"n":"name","p":1310721}],"g":{"r":0,"d":0,"h":42950909708,"f":1},"n":"Item","o":"@$3","d":1236748,"h":38655942412,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77310648076,"f":1},"n":"IsReadOnly","d":1236748,"h":73015680780,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":85900582668,"f":1},"n":"Count","d":1236748,"h":81605615372,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":94490517260,"f":1},"n":"IsSynchronized","d":1236748,"h":90195549964,"f":1},{"p":131073,"g":{"r":0,"d":0,"h":103080451852,"f":1},"n":"SyncRoot","d":1236748,"h":98785484556,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":124555288332,"f":8},"n":"IsOtherVersionSeen","d":1236748,"h":120260321036,"f":8}],"m":[{"r":65537,"p":[{"n":"context","p":114098177}],"n":"OnSerializing","d":1236748,"h":47245877004,"f":2,"a":[{"t":113639425,"c":4408606721}]},{"r":65537,"p":[{"n":"cookie","p":1171212}],"n":"Add","d":1236748,"h":51540844300,"f":1},{"r":65537,"p":[{"n":"cookies","p":1236748}],"n":"Add","o":"@$1","d":1236748,"h":55835811596,"f":1},{"r":65537,"n":"Clear","d":1236748,"h":60130778892,"f":1},{"r":262145,"p":[{"n":"cookie","p":1171212}],"n":"Contains","d":1236748,"h":64425746188,"f":1},{"r":262145,"p":[{"n":"cookie","p":1171212}],"n":"Remove","d":1236748,"h":68720713484,"f":1},{"r":65537,"p":[{"n":"array","p":1245185},{"n":"index","p":655361}],"n":"CopyTo","d":1236748,"h":107375419148,"f":1},{"r":65537,"p":[{"n":"array","p":0},{"n":"index","p":655361}],"n":"CopyTo","o":"@$1","d":1236748,"h":111670386444,"f":1},{"r":34144257,"p":[{"n":"how","p":1302284}],"n":"TimeStamp","d":1236748,"h":115965353740,"f":8},{"r":655361,"p":[{"n":"cookie","p":1171212},{"n":"isStrict","p":262145}],"n":"InternalAdd","d":1236748,"h":128850255628,"f":8},{"r":655361,"p":[{"n":"cookie","p":1171212}],"n":"IndexOf","d":1236748,"h":133145222924,"f":8},{"r":65537,"p":[{"n":"idx","p":655361}],"n":"RemoveAt","d":1236748,"h":137440190220,"f":8},{"r":31719425,"n":"GetEnumerator","d":1236748,"h":146030124812,"f":1}],"l":[{"t":23592961,"n":"m_list","d":1236748,"h":8591171340,"f":2},{"t":655361,"n":"m_version","d":1236748,"h":12886138636,"f":2},{"t":34144257,"n":"m_TimeStamp","d":1236748,"h":17181105932,"f":2},{"t":262145,"n":"m_has_other_versions","d":1236748,"h":21476073228,"f":2}],"c":[{"n":".ctor","o":"$ctor$1","d":1236748,"h":25771040524,"f":1}],"i":[$.$spc.System.Collections.Generic.ICollection$$($.$snp.System.Net.Cookie).$h,$.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$snp.System.Net.Cookie).$h,$.$spc.System.Collections.Generic.IEnumerable$$($.$snp.System.Net.Cookie).$h,31326209,31588353],"j":[1302284],"h":1236748,"a":[{"t":118226945,"c":4413194241},{"t":96272385,"c":4391239681,"a":[{"v":"System, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.Generic.ICollection$$($.$snp.System.Net.Cookie), $.$spc.System.Collections.Generic.IReadOnlyCollection$$($.$snp.System.Net.Cookie), $.$spc.System.Collections.Generic.IEnumerable$$($.$snp.System.Net.Cookie), $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Net.CookieCollection`; }
        });
        
        $asm.$cls("$snp.System.Net.NetEventSource", ($self) => class NetEventSource extends $.$spc.System.Diagnostics.Tracing.EventSource
        {
            /*string*/ static EventSourceSuppressMessage = null;
            /*NetEventSource*/ static Log = null;
            static $_Keywords;
            static get Keywords()
            {
                let $cls = $.$snp.System.Net.NetEventSource;
                return $cls.$_Keywords ??= $asm.$ncls("$snp.System.Net.NetEventSource.Keywords", ($self) => class Keywords
                {
                    /*EventKeywords*/ static Default = 1n;
                    /*EventKeywords*/ static Debug = 2n;
                    static $h = 3792652;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$md;
                    static get $md() { return this.$$md ??= {"b":131073,"l":[{"t":40828929,"n":"Default","d":3792652,"h":4298759948,"f":33},{"t":40828929,"n":"Debug","d":3792652,"h":8593727244,"f":33}],"d":3727116,"h":3792652}; }
                    static get $b() { return $.$spc.System.Object; }
                    static get $fullName() { return `System.Net.NetEventSource.Keywords`; }
                }, $cls, ($v) => $cls.$_Keywords = $v);
            }
            /*string*/ static MissingMember = null;
            /*string*/ static NullInstance = null;
            /*string*/ static StaticMethodObject = null;
            /*string*/ static NoParameters = null;
            /*int*/ static InfoEventId = 1;
            /*int*/ static ErrorEventId = 2;
            /*int*/ static NextAvailableEventId = 5;
            static /*void */ Info(/*object?*/ thisOrContextObject, /*FormattableString?*/ formattableString, /*string?*/ memberName)
            {
                return $.$snp.System.Net.NetEventSource.Log.Info$2($.$snp.System.Net.NetEventSource.IdOf(thisOrContextObject), memberName, formattableString !== null ? $.$snp.System.Net.NetEventSource.Format$1(formattableString) : ""/*NoParameters*/);
            }
            static /*void */ Info$1(/*object?*/ thisOrContextObject, /*object?*/ message, /*string?*/ memberName)
            {
                return $.$snp.System.Net.NetEventSource.Log.Info$2($.$snp.System.Net.NetEventSource.IdOf(thisOrContextObject), memberName, $.$snp.System.Net.NetEventSource.Format(message));
            }
            /*void */ Info$2(/*string*/ thisOrContextObject, /*string?*/ memberName, /*string?*/ message)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsEnabled(), "IsEnabled()");
                this.WriteEvent$9(1/*InfoEventId*/, thisOrContextObject, memberName ?? "(?)"/*MissingMember*/, message);
            }
            static /*void */ Error(/*object?*/ thisOrContextObject, /*FormattableString*/ formattableString, /*string?*/ memberName)
            {
                return $.$snp.System.Net.NetEventSource.Log.ErrorMessage($.$snp.System.Net.NetEventSource.IdOf(thisOrContextObject), memberName, $.$snp.System.Net.NetEventSource.Format$1(formattableString));
            }
            static /*void */ Error$1(/*object?*/ thisOrContextObject, /*object*/ message, /*string?*/ memberName)
            {
                return $.$snp.System.Net.NetEventSource.Log.ErrorMessage($.$snp.System.Net.NetEventSource.IdOf(thisOrContextObject), memberName, $.$snp.System.Net.NetEventSource.Format(message));
            }
            /*void */ ErrorMessage(/*string*/ thisOrContextObject, /*string?*/ memberName, /*string?*/ message)
            {
                $.$spc.System.Diagnostics.Debug.Assert$1(this.IsEnabled(), "IsEnabled()");
                this.WriteEvent$9(2/*ErrorEventId*/, thisOrContextObject, memberName ?? "(?)"/*MissingMember*/, message);
            }
            static /*string */ IdOf(/*object?*/ value)
            {
                return value !== null ? $.$spc.System.Object.GetType.call(value).Name + "#" + $.$snp.System.Net.NetEventSource.GetHashCode$1(value) : "(null)"/*NullInstance*/;
            }
            static /*int */ GetHashCode$1(/*object?*/ value)
            {
                const $t1 = value;
                return $.$ifnn($t1, ($t) => $.$spc.System.Object.GetHashCode.call($t)) ?? 0;
            }
            static /*string? */ Format(/*object?*/ value)
            {
                if (value === null)
                {
                    return "(null)"/*NullInstance*/;
                }
                /*string?*/ let result = null;
                //$.$snp.System.Net.NetEventSource.AdditionalCustomizedToString(value, $.$ref(() => result, ($v) => result = $v, $.$spc.System.String));
                if (!(result === null))
                {
                    return result;
                }
                let arr;
                if ($.$is(value, $.$spc.System.Array, { set $v(v){ arr = v; } }))
                {
                    return `${$.$spc.System.Type.ToString.call($.$spc.System.Object.GetType.call(arr).GetElementType())}[${($.$cast(value, $.$spc.System.Array)).length}]`;
                }
                let c;
                if ($.$is(value, $.$spc.System.Collections.ICollection, { set $v(v){ c = v; } }))
                {
                    return `${$.$spc.System.Object.GetType.call(c).Name}(${c.System$Collections$ICollection$Count})`;
                }
                let handle;
                if ($.$is(value, $.$spc.System.Runtime.InteropServices.SafeHandle, { set $v(v){ handle = v; } }))
                {
                    return (() =>
                    {
                        var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(3, 3);
                        $handler.AppendFormatted$8($.$box($.$spc.System.Object.GetType.call(handle).Name, $.$spc.System.String), null, null);
                        $handler.AppendLiteral(":");
                        $handler.AppendFormatted$8($.$box($.$spc.System.Object.GetHashCode.call(handle), $.$spc.System.Int32), null, null);
                        $handler.AppendLiteral("(0x");
                        $handler.AppendFormatted$8($.$box(handle.DangerousGetHandle(), $.$spc.System.IntPtr), null, "X");
                        $handler.AppendLiteral(")");
                        return $handler.ToStringAndClear();
                    })();
                }
                if ($.$is(value, $.$spc.System.IntPtr))
                {
                    return (() =>
                    {
                        var $handler = new $.$spc.System.Runtime.CompilerServices.DefaultInterpolatedStringHandler().$ctor$2(1, 1);
                        $handler.AppendLiteral("0x");
                        $handler.AppendFormatted$8(value, null, "X");
                        return $handler.ToStringAndClear();
                    })();
                }
                /*string?*/ let toString = $.$spc.System.Object.ToString.call(value);
                if ($.$spc.System.String.op_Equality(toString, null) || $.$spc.System.String.op_Equality(toString, $.$spc.System.Object.GetType.call(value).FullName))
                {
                    return $.$snp.System.Net.NetEventSource.IdOf(value);
                }
                return $.$spc.System.Object.ToString.call(value);
            }
            static /*string */ Format$1(/*FormattableString*/ s)
            {
                let $switch1 = s.ArgumentCount;
                switch($switch1)
                {
                    case 0:
                    return s.Format;
                    case 1:
                    return $.$spc.System.String.Format(s.Format, $.$snp.System.Net.NetEventSource.Format(s.GetArgument(0)));
                    case 2:
                    return $.$spc.System.String.Format$1(s.Format, $.$snp.System.Net.NetEventSource.Format(s.GetArgument(0)), $.$snp.System.Net.NetEventSource.Format(s.GetArgument(1)));
                    case 3:
                    return $.$spc.System.String.Format$2(s.Format, $.$snp.System.Net.NetEventSource.Format(s.GetArgument(0)), $.$snp.System.Net.NetEventSource.Format(s.GetArgument(1)), $.$snp.System.Net.NetEventSource.Format(s.GetArgument(2)));
                    default:
                    /*string?[]*/ let formattedArgs = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateArray($.$typeOf($.$spc.System.String), null, [s.ArgumentCount], null);
                    for(/*int*/ let i = 0; i < formattedArgs.length; i++)
                    {
                        $.$spc.System.Array.$WriteT1.call(formattedArgs, $.$snp.System.Net.NetEventSource.Format(s.GetArgument(i)), i);
                    }
                    return $.$spc.System.String.Format$4(s.Format, $.$spc.System.ReadOnlySpan$$($.$spc.System.Object).op_Implicit(formattedArgs));
                }
            }
            /*void */ WriteEvent$19(/*int*/ eventId, /*string?*/ arg1, /*string?*/ arg2, /*int*/ arg3)
            {
                arg1 ??= "";
                arg2 ??= "";
                /*fixed*/ 
                {
                    /*char**/ let arg1Ptr = $.$spc.System.String.GetPinnableReference.call(arg1);
                    /*fixed*/ 
                    {
                        /*char**/ let arg2Ptr = $.$spc.System.String.GetPinnableReference.call(arg2);
                        /*int*/ let NumEventDatas = 3;
                        /*EventData**/ let descrs = $.$spc.System.Runtime.CompilerServices.RuntimeHelpers.StackAllocPointer($.$spc.System.Diagnostics.Tracing.EventSource.EventData, NumEventDatas, null);
                        descrs.SetAt((() =>
                        {
                            //new $.$spc.System.Diagnostics.Tracing.EventSource.EventData()
                            const $t1 = $.$spc.System.Diagnostics.Tracing.EventSource.EventData;
                            const $i1 = new $t1();
                            $i1.DataPointer = $.$cast((arg1Ptr), $.$spc.System.IntPtr);
                            $i1.Size = (((((arg1.length + 1) | 0)) * $.$spc.System.Char.$z) | 0);
                            return $i1;
                        })(), 0);
                        descrs.SetAt((() =>
                        {
                            //new $.$spc.System.Diagnostics.Tracing.EventSource.EventData()
                            const $t2 = $.$spc.System.Diagnostics.Tracing.EventSource.EventData;
                            const $i2 = new $t2();
                            $i2.DataPointer = $.$cast((arg2Ptr), $.$spc.System.IntPtr);
                            $i2.Size = (((((arg2.length + 1) | 0)) * $.$spc.System.Char.$z) | 0);
                            return $i2;
                        })(), 1);
                        descrs.SetAt((() =>
                        {
                            //new $.$spc.System.Diagnostics.Tracing.EventSource.EventData()
                            const $t3 = $.$spc.System.Diagnostics.Tracing.EventSource.EventData;
                            const $i3 = new $t3();
                            $i3.DataPointer = $.$cast(($.$spc.System.Runtime.CompilerServices.RuntimeHelpers.CreateObjectReferenceT($.$spc.System.Int32, () => arg3, ($v) => arg3 = $v, null)), $.$spc.System.IntPtr);
                            $i3.Size = $.$spc.System.Int32.$z;
                            return $i3;
                        })(), 2);
                        this.WriteEventCore(eventId, NumEventDatas, descrs);
                    }
                }
            }
            //default reference type constructor overload
            $ctor$5()
            {
                super.$ctor$1();
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.EventSourceSuppressMessage = "Parameters to this method are primitive and are trimmer safe";
                }
                {
                    this.Log = new $.$snp.System.Net.NetEventSource().$ctor$5();
                }
                {
                    this.MissingMember = "(?)";
                }
                {
                    this.NullInstance = "(null)";
                }
                {
                    this.StaticMethodObject = "(static)";
                }
                {
                    this.NoParameters = "";
                }
            }
            static $h = 3727116;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":41680897,"m":[{"r":65537,"p":[{"n":"thisOrContextObject","p":131073},{"n":"formattableString","p":47775745,"f":65},{"n":"memberName","p":1310721,"f":65,"a":[{"t":88145921,"c":4383113217}]}],"n":"Info","d":3727116,"h":47248367372,"f":33,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":131073},{"n":"message","p":131073},{"n":"memberName","p":1310721,"f":65,"a":[{"t":88145921,"c":4383113217}]}],"n":"Info","o":"@$1","d":3727116,"h":51543334668,"f":33,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"memberName","p":1310721},{"n":"message","p":1310721}],"n":"Info","o":"@$2","d":3727116,"h":55838301964,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":1,"t":655361}],"n":[{"n":"Level","v":4,"t":40894465},{"n":"Keywords","v":1,"t":40828929}]}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":131073},{"n":"formattableString","p":47775745},{"n":"memberName","p":1310721,"f":65,"a":[{"t":88145921,"c":4383113217}]}],"n":"Error","d":3727116,"h":60133269260,"f":33,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":131073},{"n":"message","p":131073},{"n":"memberName","p":1310721,"f":65,"a":[{"t":88145921,"c":4383113217}]}],"n":"Error","o":"@$1","d":3727116,"h":64428236556,"f":33,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"thisOrContextObject","p":1310721},{"n":"memberName","p":1310721},{"n":"message","p":1310721}],"n":"ErrorMessage","d":3727116,"h":68723203852,"f":2,"a":[{"t":39911425,"c":4334878721,"a":[{"v":2,"t":655361}],"n":[{"n":"Level","v":2,"t":40894465},{"n":"Keywords","v":1,"t":40828929}]}]},{"r":1310721,"p":[{"n":"value","p":131073}],"n":"IdOf","d":3727116,"h":73018171148,"f":33,"a":[{"t":44236801,"c":4339204097}]},{"r":655361,"p":[{"n":"value","p":131073}],"n":"GetHashCode","o":"@$1","d":3727116,"h":77313138444,"f":33,"a":[{"t":44236801,"c":4339204097}]},{"r":1310721,"p":[{"n":"value","p":131073}],"n":"Format","d":3727116,"h":81608105740,"f":33,"a":[{"t":44236801,"c":4339204097}]},{"r":1310721,"p":[{"n":"s","p":47775745}],"n":"Format","o":"@$1","d":3727116,"h":85903073036,"f":34,"a":[{"t":44236801,"c":4339204097}]},{"r":65537,"p":[{"n":"value","p":131073},{"n":"result","p":1310721,"f":4}],"n":"AdditionalCustomizedToString","d":3727116,"h":90198040332,"f":34},{"r":65537,"p":[{"n":"eventId","p":655361},{"n":"arg1","p":1310721},{"n":"arg2","p":1310721},{"n":"arg3","p":655361}],"n":"WriteEvent","o":"@$19","d":3727116,"h":94493007628,"f":2,"a":[{"t":44236801,"c":4339204097}]}],"l":[{"t":1310721,"n":"EventSourceSuppressMessage","d":3727116,"h":4298694412,"f":34},{"t":3727116,"n":"Log","d":3727116,"h":8593661708,"f":33},{"t":1310721,"n":"MissingMember","d":3727116,"h":17183596300,"f":34},{"t":1310721,"n":"NullInstance","d":3727116,"h":21478563596,"f":34},{"t":1310721,"n":"StaticMethodObject","d":3727116,"h":25773530892,"f":34},{"t":1310721,"n":"NoParameters","d":3727116,"h":30068498188,"f":34},{"t":655361,"n":"InfoEventId","d":3727116,"h":34363465484,"f":34},{"t":655361,"n":"ErrorEventId","d":3727116,"h":38658432780,"f":34},{"t":655361,"n":"NextAvailableEventId","d":3727116,"h":42953400076,"f":34}],"c":[{"n":".ctor","o":"$ctor$5","d":3727116,"h":98787974924,"f":1}],"i":[57475073],"j":[3792652],"h":3727116,"a":[{"t":42008577,"c":55876583425,"n":[{"n":"Name","v":"Private.InternalDiagnostics.System.Net.Primitives","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Diagnostics.Tracing.EventSource; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.NetEventSource`; }
        });
        
        $asm.$cls("$snp.System.Net.SystemNetworkCredential", ($self) => class SystemNetworkCredential extends $.$snp.System.Net.NetworkCredential
        {
            /*SystemNetworkCredential*/ static s_defaultCredential = null;
            $ctor$6()
            {
                super.$ctor$3($.$spc.System.String.Empty, $.$spc.System.String.Empty, $.$spc.System.String.Empty);
                {
                }
                return this;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.s_defaultCredential = new $.$snp.System.Net.SystemNetworkCredential().$ctor$6();
                }
            }
            static $h = 4906764;
            static $f = 0b10010000;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":3858188,"l":[{"t":4906764,"n":"s_defaultCredential","d":4906764,"h":4299874060,"f":40}],"c":[{"n":".ctor","o":"$ctor$6","d":4906764,"h":8594841356,"f":2}],"i":[2940684,3006220],"h":4906764}; }
            static get $b() { return $.$snp.System.Net.NetworkCredential; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$snp.System.Net.ICredentials, $.$snp.System.Net.ICredentialsByHost ]; }
            static get $fullName() { return `System.Net.SystemNetworkCredential`; }
        });
        
        $asm.$cls("$snp.System.Net.CookieException", ($self) => class CookieException extends $.$spc.System.FormatException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$14(/*string?*/ message)
            {
                super.$ctor$10(message);
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*Exception?*/ innerException)
            {
                super.$ctor$11(message, innerException);
                {
                }
                return this;
            }
            $ctor$16(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.$ctor$12(serializationInfo, streamingContext);
                {
                }
                return this;
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.GetObjectData(serializationInfo, streamingContext);
            }
            /*void */ GetObjectData(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.GetObjectData(serializationInfo, streamingContext);
            }
            static $h = 1498892;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":47710209,"h":1498892}; }
            static get $b() { return $.$spc.System.FormatException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.CookieException`; }
        });
        
        $asm.$cls("$snp.System.Net.Sockets.SocketException", ($self) => class SocketException extends $.$spc.System.ComponentModel.Win32Exception
        {
            /*SocketError*/ _errorCode = 0;
            $ctor$20(/*int*/ errorCode)
            {
                this.$ctor$22($.$cast(errorCode, $.$snp.System.Net.Sockets.SocketError));
                {
                }
                return this;
            }
            $ctor$21(/*int*/ errorCode, /*string?*/ message)
            {
                this.$ctor$23($.$cast(errorCode, $.$snp.System.Net.Sockets.SocketError), message);
                {
                }
                return this;
            }
            $ctor$22(/*SocketError*/ socketError)
            {
                super.$ctor$15($.$snp.System.Net.Sockets.SocketException.GetNativeErrorForSocketError(socketError));
                {
                    this._errorCode = socketError;
                }
                return this;
            }
            $ctor$23(/*SocketError*/ socketError, /*string?*/ message)
            {
                super.$ctor$16($.$snp.System.Net.Sockets.SocketException.GetNativeErrorForSocketError(socketError), message);
                {
                    this._errorCode = socketError;
                }
                return this;
            }
            /*string */ get Message()
            {
                return super.Message;
            }
            /*SocketError */ get SocketErrorCode()
            {
                return this._errorCode;
            }
            $ctor$24(/*SerializationInfo*/ serializationInfo, /*StreamingContext*/ streamingContext)
            {
                super.$ctor$19(serializationInfo, streamingContext);
                {
                    if ($.$snp.System.Net.NetEventSource.Log.IsEnabled())
                    {
                        $.$snp.System.Net.NetEventSource.Info(this, `${this.NativeErrorCode}:${this.Message}`, "SocketException");
                    }
                }
                return this;
            }
            /*int */ get ErrorCode()
            {
                return super.NativeErrorCode;
            }
            $ctor$25()
            {
                this.$ctor$27($.$snp.Interop.Sys.GetLastErrorInfo());
                {
                }
                return this;
            }
            $ctor$26(/*SocketError*/ errorCode, /*uint*/ platformError)
            {
                super.$ctor$15((platformError | 0));
                {
                    this._errorCode = errorCode;
                }
                return this;
            }
            $ctor$27(/*Interop.ErrorInfo*/ error)
            {
                this.$ctor$26($.$snp.System.Net.Sockets.SocketErrorPal.GetSocketErrorForNativeError(error.Error), (error.RawErrno >>> 0));
                {
                }
                return this;
            }
            static /*int */ GetNativeErrorForSocketError(/*SocketError*/ error)
            {
                /*int*/ let nativeErr = error;
                /*Interop.Error*/ let interopErr;
                if ($.$snp.System.Net.Sockets.SocketErrorPal.TryGetNativeErrorForSocketError(error, $.$ref(() => interopErr, ($v) => interopErr = $v, $.$snp.Interop.Error)))
                {
                    nativeErr = $.$snp.InteropErrorExtensions.Info(interopErr).RawErrno;
                }
                return nativeErr;
            }
            static $h = 4841228;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":33292289,"h":4841228}; }
            static get $b() { return $.$spc.System.ComponentModel.Win32Exception; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Sockets.SocketException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Threading", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices"))