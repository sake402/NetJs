
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $stc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Quic", 
    {"h":54226,"f":"System.Net.Quic","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Quic","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Quic","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snq.System.Net.Quic.QuicConnectionOptions", ($self) => class QuicConnectionOptions extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*long */ get DefaultCloseErrorCode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set DefaultCloseErrorCode(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get DefaultStreamErrorCode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set DefaultStreamErrorCode(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get HandshakeTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set HandshakeTimeout(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get IdleTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set IdleTimeout(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicReceiveWindowSizes */ get InitialReceiveWindowSizes()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicReceiveWindowSizes */ set InitialReceiveWindowSizes(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get KeepAliveInterval()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set KeepAliveInterval(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get MaxInboundBidirectionalStreams()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set MaxInboundBidirectionalStreams(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get MaxInboundUnidirectionalStreams()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set MaxInboundUnidirectionalStreams(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Action<System.Net.Quic.QuicConnection, System.Net.Quic.QuicStreamCapacityChangedArgs>? */ get StreamCapacityCallback()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Action<System.Net.Quic.QuicConnection, System.Net.Quic.QuicStreamCapacityChangedArgs>? */ set StreamCapacityCallback(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 316370;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885218258,"f":50331649},"s":{"r":0,"d":0,"h":17180185554,"f":83886081},"n":"DefaultCloseErrorCode","d":316370,"h":8590250962,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":25770120146,"f":50331649},"s":{"r":0,"d":0,"h":30065087442,"f":83886081},"n":"DefaultStreamErrorCode","d":316370,"h":21475152850,"f":2097153},{"p":140574721,"g":{"r":0,"d":0,"h":38655022034,"f":50331649},"s":{"r":0,"d":0,"h":42949989330,"f":83886081},"n":"HandshakeTimeout","d":316370,"h":34360054738,"f":2097153},{"p":140574721,"g":{"r":0,"d":0,"h":51539923922,"f":50331649},"s":{"r":0,"d":0,"h":55834891218,"f":83886081},"n":"IdleTimeout","d":316370,"h":47244956626,"f":2097153},{"p":644050,"g":{"r":0,"d":0,"h":64424825810,"f":50331649},"s":{"r":0,"d":0,"h":68719793106,"f":83886081},"n":"InitialReceiveWindowSizes","d":316370,"h":60129858514,"f":2097153},{"p":140574721,"g":{"r":0,"d":0,"h":77309727698,"f":50331649},"s":{"r":0,"d":0,"h":81604694994,"f":83886081},"n":"KeepAliveInterval","d":316370,"h":73014760402,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":90194629586,"f":50331649},"s":{"r":0,"d":0,"h":94489596882,"f":83886081},"n":"MaxInboundBidirectionalStreams","d":316370,"h":85899662290,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":103079531474,"f":50331649},"s":{"r":0,"d":0,"h":107374498770,"f":83886081},"n":"MaxInboundUnidirectionalStreams","d":316370,"h":98784564178,"f":2097153},{"p":$.$$.System.Action$$$($.$snq.System.Net.Quic.QuicConnection, $.$snq.System.Net.Quic.QuicStreamCapacityChangedArgs).$h,"g":{"r":0,"d":0,"h":115964433362,"f":50331649},"s":{"r":0,"d":0,"h":120259400658,"f":83886081},"n":"StreamCapacityCallback","d":316370,"h":111669466066,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":316370,"h":4295283666,"f":16777224}],"h":316370}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Quic.QuicConnectionOptions`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicListenerOptions", ($self) => class QuicListenerOptions extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol> */ get ApplicationProtocols()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol> */ set ApplicationProtocols(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Func<System.Net.Quic.QuicConnection, System.Net.Security.SslClientHelloInfo, System.Threading.CancellationToken, System.Threading.Tasks.ValueTask<System.Net.Quic.QuicServerConnectionOptions>> */ get ConnectionOptionsCallback()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Func<System.Net.Quic.QuicConnection, System.Net.Security.SslClientHelloInfo, System.Threading.CancellationToken, System.Threading.Tasks.ValueTask<System.Net.Quic.QuicServerConnectionOptions>> */ set ConnectionOptionsCallback(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ListenBacklog()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ListenBacklog(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get ListenEndPoint()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ set ListenEndPoint(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 578514;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":12885480402,"f":50331649},"s":{"r":0,"d":0,"h":17180447698,"f":83886081},"n":"ApplicationProtocols","d":578514,"h":8590513106,"f":2097153},{"p":$.$$.System.Func$$$$$($.$snq.System.Net.Quic.QuicConnection, $.$snsc.System.Net.Security.SslClientHelloInfo, $.$$.System.Threading.CancellationToken, $.$$.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicServerConnectionOptions)).$h,"g":{"r":0,"d":0,"h":25770382290,"f":50331649},"s":{"r":0,"d":0,"h":30065349586,"f":83886081},"n":"ConnectionOptionsCallback","d":578514,"h":21475414994,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":38655284178,"f":50331649},"s":{"r":0,"d":0,"h":42950251474,"f":83886081},"n":"ListenBacklog","d":578514,"h":34360316882,"f":2097153},{"p":3326709,"g":{"r":0,"d":0,"h":51540186066,"f":50331649},"s":{"r":0,"d":0,"h":55835153362,"f":83886081},"n":"ListenEndPoint","d":578514,"h":47245218770,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":578514,"h":4295545810,"f":16777217}],"h":578514}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Quic.QuicListenerOptions`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicReceiveWindowSizes", ($self) => class QuicReceiveWindowSizes extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Connection()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set Connection(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get LocallyInitiatedBidirectionalStream()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set LocallyInitiatedBidirectionalStream(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get RemotelyInitiatedBidirectionalStream()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set RemotelyInitiatedBidirectionalStream(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get UnidirectionalStream()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set UnidirectionalStream(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 644050;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885545938,"f":50331649},"s":{"r":0,"d":0,"h":17180513234,"f":83886081},"n":"Connection","d":644050,"h":8590578642,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":25770447826,"f":50331649},"s":{"r":0,"d":0,"h":30065415122,"f":83886081},"n":"LocallyInitiatedBidirectionalStream","d":644050,"h":21475480530,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":38655349714,"f":50331649},"s":{"r":0,"d":0,"h":42950317010,"f":83886081},"n":"RemotelyInitiatedBidirectionalStream","d":644050,"h":34360382418,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":51540251602,"f":50331649},"s":{"r":0,"d":0,"h":55835218898,"f":83886081},"n":"UnidirectionalStream","d":644050,"h":47245284306,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":644050,"h":4295611346,"f":16777217}],"h":644050}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Quic.QuicReceiveWindowSizes`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicConnection", ($self) => class QuicConnection extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ get IsSupported()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get LocalEndPoint()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslApplicationProtocol */ get NegotiatedApplicationProtocol()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.TlsCipherSuite */ get NegotiatedCipherSuite()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocol()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get RemoteCertificate()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get RemoteEndPoint()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get TargetHostName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicStream> */ AcceptInboundStreamAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ CloseAsync(/*long*/ errorCode, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicConnection> */ ConnectAsync(/*System.Net.Quic.QuicClientConnectionOptions*/ options, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicStream> */ OpenOutboundStreamAsync(/*System.Net.Quic.QuicStreamType*/ type, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snq.System.Net.Quic.QuicConnection.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            static $h = 250834;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885152722,"f":50331681},"n":"IsSupported","d":250834,"h":8590185426,"f":2097185,"a":[{"t":114884609,"c":4409851905,"a":[{"v":"windows","t":1310721}]},{"t":114884609,"c":4409851905,"a":[{"v":"linux","t":1310721}]},{"t":114884609,"c":4409851905,"a":[{"v":"osx","t":1310721}]}]},{"p":3326709,"g":{"r":0,"d":0,"h":21475087314,"f":50331649},"n":"LocalEndPoint","d":250834,"h":17180120018,"f":2097153},{"p":977516,"g":{"r":0,"d":0,"h":30065021906,"f":50331649},"n":"NegotiatedApplicationProtocol","d":250834,"h":25770054610,"f":2097153},{"p":1436268,"g":{"r":0,"d":0,"h":38654956498,"f":50331649},"n":"NegotiatedCipherSuite","d":250834,"h":34359989202,"f":2097153,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"p":5620469,"g":{"r":0,"d":0,"h":47244891090,"f":50331649},"n":"SslProtocol","d":250834,"h":42949923794,"f":2097153},{"p":28160783,"g":{"r":0,"d":0,"h":55834825682,"f":50331649},"n":"RemoteCertificate","d":250834,"h":51539858386,"f":2097153},{"p":3326709,"g":{"r":0,"d":0,"h":64424760274,"f":50331649},"n":"RemoteEndPoint","d":250834,"h":60129792978,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":73014694866,"f":50331649},"n":"TargetHostName","d":250834,"h":68719727570,"f":2097153}],"m":[{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicStream).$h,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"AcceptInboundStreamAsync","d":250834,"h":77309662162,"f":16777217},{"r":135987201,"p":[{"n":"errorCode","p":917505},{"n":"cancellationToken","p":125829121,"f":65}],"n":"CloseAsync","d":250834,"h":81604629458,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicConnection).$h,"p":[{"n":"options","p":185298},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ConnectAsync","d":250834,"h":85899596754,"f":16777249},{"r":135987201,"n":"DisposeAsync","d":250834,"h":90194564050,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicStream).$h,"p":[{"n":"type","p":906194},{"n":"cancellationToken","p":125829121,"f":65}],"n":"OpenOutboundStreamAsync","d":250834,"h":94489531346,"f":16777217},{"r":1310721,"n":"ToString","d":250834,"h":98784498642,"f":16809985}],"c":[{"n":".ctor","o":"$ctor$1","d":250834,"h":4295218130,"f":16777224}],"i":[56950785],"h":250834}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Quic.QuicConnection`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicListener", ($self) => class QuicListener extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ get IsSupported()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get LocalEndPoint()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicConnection> */ AcceptConnectionAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicListener> */ ListenAsync(/*System.Net.Quic.QuicListenerOptions*/ options, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snq.System.Net.Quic.QuicListener.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            static $h = 512978;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885414866,"f":50331681},"n":"IsSupported","d":512978,"h":8590447570,"f":2097185,"a":[{"t":114884609,"c":4409851905,"a":[{"v":"windows","t":1310721}]},{"t":114884609,"c":4409851905,"a":[{"v":"linux","t":1310721}]},{"t":114884609,"c":4409851905,"a":[{"v":"osx","t":1310721}]}]},{"p":3326709,"g":{"r":0,"d":0,"h":21475349458,"f":50331649},"n":"LocalEndPoint","d":512978,"h":17180382162,"f":2097153}],"m":[{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicConnection).$h,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"AcceptConnectionAsync","d":512978,"h":25770316754,"f":16777217},{"r":135987201,"n":"DisposeAsync","d":512978,"h":30065284050,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicListener).$h,"p":[{"n":"options","p":578514},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ListenAsync","d":512978,"h":34360251346,"f":16777249},{"r":1310721,"n":"ToString","d":512978,"h":38655218642,"f":16809985}],"c":[{"n":".ctor","o":"$ctor$1","d":512978,"h":4295480274,"f":16777224}],"i":[56950785],"h":512978}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Quic.QuicListener`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicClientConnectionOptions", ($self) => class QuicClientConnectionOptions extends $.$snq.System.Net.Quic.QuicConnectionOptions
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Security.SslClientAuthenticationOptions */ get ClientAuthenticationOptions()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslClientAuthenticationOptions */ set ClientAuthenticationOptions(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint? */ get LocalEndPoint()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint? */ set LocalEndPoint(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ get RemoteEndPoint()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ set RemoteEndPoint(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 185298;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":316370,"p":[{"p":1108588,"g":{"r":0,"d":0,"h":12885087186,"f":50331649},"s":{"r":0,"d":0,"h":17180054482,"f":83886081},"n":"ClientAuthenticationOptions","d":185298,"h":8590119890,"f":2097153},{"p":3326709,"g":{"r":0,"d":0,"h":25769989074,"f":50331649},"s":{"r":0,"d":0,"h":30064956370,"f":83886081},"n":"LocalEndPoint","d":185298,"h":21475021778,"f":2097153},{"p":2605813,"g":{"r":0,"d":0,"h":38654890962,"f":50331649},"s":{"r":0,"d":0,"h":42949858258,"f":83886081},"n":"RemoteEndPoint","d":185298,"h":34359923666,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":185298,"h":4295152594,"f":16777217}],"h":185298}; }
            static get $b() { return $.$snq.System.Net.Quic.QuicConnectionOptions; }
            static get $fullName() { return `System.Net.Quic.QuicClientConnectionOptions`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicServerConnectionOptions", ($self) => class QuicServerConnectionOptions extends $.$snq.System.Net.Quic.QuicConnectionOptions
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Security.SslServerAuthenticationOptions */ get ServerAuthenticationOptions()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslServerAuthenticationOptions */ set ServerAuthenticationOptions(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 709586;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":316370,"p":[{"p":1239660,"g":{"r":0,"d":0,"h":12885611474,"f":50331649},"s":{"r":0,"d":0,"h":17180578770,"f":83886081},"n":"ServerAuthenticationOptions","d":709586,"h":8590644178,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$2","d":709586,"h":4295676882,"f":16777217}],"h":709586}; }
            static get $b() { return $.$snq.System.Net.Quic.QuicConnectionOptions; }
            static get $fullName() { return `System.Net.Quic.QuicServerConnectionOptions`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicStreamCapacityChangedArgs", ($self) => class QuicStreamCapacityChangedArgs extends $.$$.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*int */ get BidirectionalIncrement()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set BidirectionalIncrement(value)
            {
            }
            /*int */ get UnidirectionalIncrement()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set UnidirectionalIncrement(value)
            {
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 840658;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180709842,"f":50331649},"s":{"r":0,"d":0,"h":21475677138,"f":83886081},"n":"BidirectionalIncrement","d":840658,"h":12885742546,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":30065611730,"f":50331649},"s":{"r":0,"d":0,"h":34360579026,"f":83886081},"n":"UnidirectionalIncrement","d":840658,"h":25770644434,"f":2097153}],"l":[{"t":131073,"n":"_dummy","d":840658,"h":4295807954,"f":4194306},{"t":655361,"n":"_dummyPrimitive","d":840658,"h":8590775250,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":840658,"h":38655546322,"f":16777217}],"h":840658}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Net.Quic.QuicStreamCapacityChangedArgs`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicStream", ($self) => class QuicStream extends $.$$.System.IO.Stream
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Id()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ get ReadsClosed()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicStreamType */ get Type()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ get WritesClosed()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Abort(/*System.Net.Quic.QuicAbortDirection*/ abortDirection, /*long*/ errorCode)
            {
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CompleteWrites()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snq.System.Net.Quic.QuicStream.ToString.apply(this, arguments); }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$3(/*System.ReadOnlyMemory<byte>*/ buffer, /*bool*/ completeWrites, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            static $h = 775122;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885677010,"f":50364417},"n":"CanRead","d":775122,"h":8590709714,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":21475611602,"f":50364417},"n":"CanSeek","d":775122,"h":17180644306,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":30065546194,"f":50364417},"n":"CanTimeout","d":775122,"h":25770578898,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":38655480786,"f":50364417},"n":"CanWrite","d":775122,"h":34360513490,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":47245415378,"f":50331649},"n":"Id","d":775122,"h":42950448082,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":55835349970,"f":50364417},"n":"Length","d":775122,"h":51540382674,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":64425284562,"f":50364417},"s":{"r":0,"d":0,"h":68720251858,"f":83918849},"n":"Position","d":775122,"h":60130317266,"f":2129921},{"p":133169153,"g":{"r":0,"d":0,"h":77310186450,"f":50331649},"n":"ReadsClosed","d":775122,"h":73015219154,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":85900121042,"f":50364417},"s":{"r":0,"d":0,"h":90195088338,"f":83918849},"n":"ReadTimeout","d":775122,"h":81605153746,"f":2129921},{"p":906194,"g":{"r":0,"d":0,"h":98785022930,"f":50331649},"n":"Type","d":775122,"h":94490055634,"f":2097153},{"p":133169153,"g":{"r":0,"d":0,"h":107374957522,"f":50331649},"n":"WritesClosed","d":775122,"h":103079990226,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":115964892114,"f":50364417},"s":{"r":0,"d":0,"h":120259859410,"f":83918849},"n":"WriteTimeout","d":775122,"h":111669924818,"f":2129921}],"m":[{"r":65537,"p":[{"n":"abortDirection","p":119762},{"n":"errorCode","p":917505}],"n":"Abort","d":775122,"h":124554826706,"f":16777217},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginRead","d":775122,"h":128849794002,"f":16809985},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginWrite","d":775122,"h":133144761298,"f":16809985},{"r":65537,"n":"CompleteWrites","d":775122,"h":137439728594,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":775122,"h":141734695890,"f":16809988},{"r":135987201,"n":"DisposeAsync","d":775122,"h":146029663186,"f":16809985},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":775122,"h":150324630482,"f":16809985},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":775122,"h":154619597778,"f":16809985},{"r":65537,"n":"Flush","d":775122,"h":158914565074,"f":16809985},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"FlushAsync","o":"@$1","d":775122,"h":163209532370,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":775122,"h":167504499666,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"Read","o":"@$1","d":775122,"h":171799466962,"f":16809985},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAsync","d":775122,"h":176094434258,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAsync","o":"@$2","d":775122,"h":180389401554,"f":16809985},{"r":655361,"n":"ReadByte","d":775122,"h":184684368850,"f":16809985},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":775122,"h":188979336146,"f":16809985},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":775122,"h":193274303442,"f":16809985},{"r":1310721,"n":"ToString","d":775122,"h":197569270738,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":775122,"h":201864238034,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"Write","o":"@$1","d":775122,"h":206159205330,"f":16809985},{"r":133169153,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121,"f":65}],"n":"WriteAsync","d":775122,"h":210454172626,"f":16809985},{"r":135987201,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"completeWrites","p":262145},{"n":"cancellationToken","p":125829121,"f":65}],"n":"WriteAsync","o":"@$3","d":775122,"h":214749139922,"f":16777217},{"r":135987201,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"WriteAsync","o":"@$2","d":775122,"h":219044107218,"f":16809985},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":775122,"h":223339074514,"f":16809985}],"c":[{"n":".ctor","o":"$ctor$3","d":775122,"h":4295742418,"f":16777224}],"i":[57540609,56950785],"h":775122}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Quic.QuicStream`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicAbortDirection", ($self) => class QuicAbortDirection extends $.$$.System.Enum
        {
            static Read = 1;
            static Write = 2;
            static Both = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Read": 1n,
                    "Write": 2n,
                    "Both": 3n
                };
            }
            static $h = 119762;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":119762,"n":"Read","d":119762,"h":4295087058,"f":4194337},{"t":119762,"n":"Write","d":119762,"h":8590054354,"f":4194337},{"t":119762,"n":"Both","d":119762,"h":12885021650,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":119762,"h":17179988946,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":119762,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Quic.QuicAbortDirection`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicError", ($self) => class QuicError extends $.$$.System.Enum
        {
            static Success = 0;
            static InternalError = 1;
            static ConnectionAborted = 2;
            static StreamAborted = 3;
            static ConnectionTimeout = 6;
            static ConnectionRefused = 8;
            static VersionNegotiationError = 9;
            static ConnectionIdle = 10;
            static OperationAborted = 12;
            static AlpnInUse = 13;
            static TransportError = 14;
            static CallbackError = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Success": 0n,
                    "InternalError": 1n,
                    "ConnectionAborted": 2n,
                    "StreamAborted": 3n,
                    "ConnectionTimeout": 6n,
                    "ConnectionRefused": 8n,
                    "VersionNegotiationError": 9n,
                    "ConnectionIdle": 10n,
                    "OperationAborted": 12n,
                    "AlpnInUse": 13n,
                    "TransportError": 14n,
                    "CallbackError": 15n
                };
            }
            static $h = 381906;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":381906,"n":"Success","d":381906,"h":4295349202,"f":4194337},{"t":381906,"n":"InternalError","d":381906,"h":8590316498,"f":4194337},{"t":381906,"n":"ConnectionAborted","d":381906,"h":12885283794,"f":4194337},{"t":381906,"n":"StreamAborted","d":381906,"h":17180251090,"f":4194337},{"t":381906,"n":"ConnectionTimeout","d":381906,"h":21475218386,"f":4194337},{"t":381906,"n":"ConnectionRefused","d":381906,"h":25770185682,"f":4194337},{"t":381906,"n":"VersionNegotiationError","d":381906,"h":30065152978,"f":4194337},{"t":381906,"n":"ConnectionIdle","d":381906,"h":34360120274,"f":4194337},{"t":381906,"n":"OperationAborted","d":381906,"h":38655087570,"f":4194337},{"t":381906,"n":"AlpnInUse","d":381906,"h":42950054866,"f":4194337},{"t":381906,"n":"TransportError","d":381906,"h":47245022162,"f":4194337},{"t":381906,"n":"CallbackError","d":381906,"h":51539989458,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":381906,"h":55834956754,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":381906}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Quic.QuicError`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicStreamType", ($self) => class QuicStreamType extends $.$$.System.Enum
        {
            static Unidirectional = 0;
            static Bidirectional = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unidirectional": 0n,
                    "Bidirectional": 1n
                };
            }
            static $h = 906194;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":906194,"n":"Unidirectional","d":906194,"h":4295873490,"f":4194337},{"t":906194,"n":"Bidirectional","d":906194,"h":8590840786,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":906194,"h":12885808082,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":906194}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Quic.QuicStreamType`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicException", ($self) => class QuicException extends $.$$.System.IO.IOException
        {
            $ctor$14(/*System.Net.Quic.QuicError*/ error, /*long?*/ applicationErrorCode, /*string*/ message)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            /*long? */ get ApplicationErrorCode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicError */ get QuicError()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long? */ get TransportErrorCode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 447442;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":60751873,"h":447442}; }
            static get $b() { return $.$$.System.IO.IOException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Quic.QuicException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels"))