
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $stc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Quic", 
    {"h":39693,"f":"System.Net.Quic","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Quic","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Quic","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snq.System.Net.Quic.QuicConnectionOptions", ($self) => class QuicConnectionOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*long */ get DefaultCloseErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set DefaultCloseErrorCode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get DefaultStreamErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set DefaultStreamErrorCode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get HandshakeTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set HandshakeTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get IdleTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set IdleTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicReceiveWindowSizes */ get InitialReceiveWindowSizes()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicReceiveWindowSizes */ set InitialReceiveWindowSizes(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get KeepAliveInterval()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set KeepAliveInterval(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get MaxInboundBidirectionalStreams()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set MaxInboundBidirectionalStreams(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get MaxInboundUnidirectionalStreams()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set MaxInboundUnidirectionalStreams(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Action<System.Net.Quic.QuicConnection, System.Net.Quic.QuicStreamCapacityChangedArgs>? */ get StreamCapacityCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Action<System.Net.Quic.QuicConnection, System.Net.Quic.QuicStreamCapacityChangedArgs>? */ set StreamCapacityCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 301837;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885203725,"f":1},"s":{"r":0,"d":0,"h":17180171021,"f":1},"n":"DefaultCloseErrorCode","d":301837,"h":8590236429,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":25770105613,"f":1},"s":{"r":0,"d":0,"h":30065072909,"f":1},"n":"DefaultStreamErrorCode","d":301837,"h":21475138317,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":38655007501,"f":1},"s":{"r":0,"d":0,"h":42949974797,"f":1},"n":"HandshakeTimeout","d":301837,"h":34360040205,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":51539909389,"f":1},"s":{"r":0,"d":0,"h":55834876685,"f":1},"n":"IdleTimeout","d":301837,"h":47244942093,"f":1},{"p":629517,"g":{"r":0,"d":0,"h":64424811277,"f":1},"s":{"r":0,"d":0,"h":68719778573,"f":1},"n":"InitialReceiveWindowSizes","d":301837,"h":60129843981,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":77309713165,"f":1},"s":{"r":0,"d":0,"h":81604680461,"f":1},"n":"KeepAliveInterval","d":301837,"h":73014745869,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":90194615053,"f":1},"s":{"r":0,"d":0,"h":94489582349,"f":1},"n":"MaxInboundBidirectionalStreams","d":301837,"h":85899647757,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":103079516941,"f":1},"s":{"r":0,"d":0,"h":107374484237,"f":1},"n":"MaxInboundUnidirectionalStreams","d":301837,"h":98784549645,"f":1},{"p":$.$spc.System.Action$$$($.$snq.System.Net.Quic.QuicConnection, $.$snq.System.Net.Quic.QuicStreamCapacityChangedArgs).$h,"g":{"r":0,"d":0,"h":115964418829,"f":1},"s":{"r":0,"d":0,"h":120259386125,"f":1},"n":"StreamCapacityCallback","d":301837,"h":111669451533,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":301837,"h":4295269133,"f":8}],"h":301837}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Quic.QuicConnectionOptions`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicListenerOptions", ($self) => class QuicListenerOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol> */ get ApplicationProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol> */ set ApplicationProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Func<System.Net.Quic.QuicConnection, System.Net.Security.SslClientHelloInfo, System.Threading.CancellationToken, System.Threading.Tasks.ValueTask<System.Net.Quic.QuicServerConnectionOptions>> */ get ConnectionOptionsCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Func<System.Net.Quic.QuicConnection, System.Net.Security.SslClientHelloInfo, System.Threading.CancellationToken, System.Threading.Tasks.ValueTask<System.Net.Quic.QuicServerConnectionOptions>> */ set ConnectionOptionsCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ListenBacklog()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ListenBacklog(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get ListenEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ set ListenEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 563981;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":12885465869,"f":1},"s":{"r":0,"d":0,"h":17180433165,"f":1},"n":"ApplicationProtocols","d":563981,"h":8590498573,"f":1},{"p":$.$spc.System.Func$$$$$($.$snq.System.Net.Quic.QuicConnection, $.$snsc.System.Net.Security.SslClientHelloInfo, $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicServerConnectionOptions)).$h,"g":{"r":0,"d":0,"h":25770367757,"f":1},"s":{"r":0,"d":0,"h":30065335053,"f":1},"n":"ConnectionOptionsCallback","d":563981,"h":21475400461,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38655269645,"f":1},"s":{"r":0,"d":0,"h":42950236941,"f":1},"n":"ListenBacklog","d":563981,"h":34360302349,"f":1},{"p":3332934,"g":{"r":0,"d":0,"h":51540171533,"f":1},"s":{"r":0,"d":0,"h":55835138829,"f":1},"n":"ListenEndPoint","d":563981,"h":47245204237,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":563981,"h":4295531277,"f":1}],"h":563981}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Quic.QuicListenerOptions`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicReceiveWindowSizes", ($self) => class QuicReceiveWindowSizes extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Connection()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set Connection(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get LocallyInitiatedBidirectionalStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set LocallyInitiatedBidirectionalStream(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get RemotelyInitiatedBidirectionalStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set RemotelyInitiatedBidirectionalStream(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get UnidirectionalStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set UnidirectionalStream(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 629517;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885531405,"f":1},"s":{"r":0,"d":0,"h":17180498701,"f":1},"n":"Connection","d":629517,"h":8590564109,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25770433293,"f":1},"s":{"r":0,"d":0,"h":30065400589,"f":1},"n":"LocallyInitiatedBidirectionalStream","d":629517,"h":21475465997,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38655335181,"f":1},"s":{"r":0,"d":0,"h":42950302477,"f":1},"n":"RemotelyInitiatedBidirectionalStream","d":629517,"h":34360367885,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51540237069,"f":1},"s":{"r":0,"d":0,"h":55835204365,"f":1},"n":"UnidirectionalStream","d":629517,"h":47245269773,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":629517,"h":4295596813,"f":1}],"h":629517}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Quic.QuicReceiveWindowSizes`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicConnection", ($self) => class QuicConnection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ get IsSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslApplicationProtocol */ get NegotiatedApplicationProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.TlsCipherSuite */ get NegotiatedCipherSuite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get RemoteCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get TargetHostName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicStream> */ AcceptInboundStreamAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ CloseAsync(/*long*/ errorCode, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicConnection> */ ConnectAsync(/*System.Net.Quic.QuicClientConnectionOptions*/ options, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicStream> */ OpenOutboundStreamAsync(/*System.Net.Quic.QuicStreamType*/ type, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snq.System.Net.Quic.QuicConnection.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            static $h = 236301;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885138189,"f":33},"n":"IsSupported","d":236301,"h":8590170893,"f":33,"a":[{"t":115015681,"c":4409982977,"a":[{"v":"windows","t":1310721}]},{"t":115015681,"c":4409982977,"a":[{"v":"linux","t":1310721}]},{"t":115015681,"c":4409982977,"a":[{"v":"osx","t":1310721}]}]},{"p":3332934,"g":{"r":0,"d":0,"h":21475072781,"f":1},"n":"LocalEndPoint","d":236301,"h":17180105485,"f":1},{"p":954174,"g":{"r":0,"d":0,"h":30065007373,"f":1},"n":"NegotiatedApplicationProtocol","d":236301,"h":25770040077,"f":1},{"p":1412926,"g":{"r":0,"d":0,"h":38654941965,"f":1},"n":"NegotiatedCipherSuite","d":236301,"h":34359974669,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"p":5626694,"g":{"r":0,"d":0,"h":47244876557,"f":1},"n":"SslProtocol","d":236301,"h":42949909261,"f":1},{"p":28163835,"g":{"r":0,"d":0,"h":55834811149,"f":1},"n":"RemoteCertificate","d":236301,"h":51539843853,"f":1},{"p":3332934,"g":{"r":0,"d":0,"h":64424745741,"f":1},"n":"RemoteEndPoint","d":236301,"h":60129778445,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":73014680333,"f":1},"n":"TargetHostName","d":236301,"h":68719713037,"f":1}],"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicStream).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"AcceptInboundStreamAsync","d":236301,"h":77309647629,"f":1},{"r":136118273,"p":[{"n":"errorCode","p":917505},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CloseAsync","d":236301,"h":81604614925,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicConnection).$h,"p":[{"n":"options","p":170765},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ConnectAsync","d":236301,"h":85899582221,"f":33},{"r":136118273,"n":"DisposeAsync","d":236301,"h":90194549517,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicStream).$h,"p":[{"n":"type","p":891661},{"n":"cancellationToken","p":125960193,"f":65}],"n":"OpenOutboundStreamAsync","d":236301,"h":94489516813,"f":1},{"r":1310721,"n":"ToString","d":236301,"h":98784484109,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":236301,"h":4295203597,"f":8}],"i":[56950785],"h":236301}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Quic.QuicConnection`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicListener", ($self) => class QuicListener extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ get IsSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicConnection> */ AcceptConnectionAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicListener> */ ListenAsync(/*System.Net.Quic.QuicListenerOptions*/ options, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snq.System.Net.Quic.QuicListener.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            static $h = 498445;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885400333,"f":33},"n":"IsSupported","d":498445,"h":8590433037,"f":33,"a":[{"t":115015681,"c":4409982977,"a":[{"v":"windows","t":1310721}]},{"t":115015681,"c":4409982977,"a":[{"v":"linux","t":1310721}]},{"t":115015681,"c":4409982977,"a":[{"v":"osx","t":1310721}]}]},{"p":3332934,"g":{"r":0,"d":0,"h":21475334925,"f":1},"n":"LocalEndPoint","d":498445,"h":17180367629,"f":1}],"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicConnection).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"AcceptConnectionAsync","d":498445,"h":25770302221,"f":1},{"r":136118273,"n":"DisposeAsync","d":498445,"h":30065269517,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicListener).$h,"p":[{"n":"options","p":563981},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ListenAsync","d":498445,"h":34360236813,"f":33},{"r":1310721,"n":"ToString","d":498445,"h":38655204109,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":498445,"h":4295465741,"f":8}],"i":[56950785],"h":498445}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Quic.QuicListener`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicClientConnectionOptions", ($self) => class QuicClientConnectionOptions extends $.$snq.System.Net.Quic.QuicConnectionOptions
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Security.SslClientAuthenticationOptions */ get ClientAuthenticationOptions()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslClientAuthenticationOptions */ set ClientAuthenticationOptions(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint? */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint? */ set LocalEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ set RemoteEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 170765;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":301837,"p":[{"p":1085246,"g":{"r":0,"d":0,"h":12885072653,"f":1},"s":{"r":0,"d":0,"h":17180039949,"f":1},"n":"ClientAuthenticationOptions","d":170765,"h":8590105357,"f":1},{"p":3332934,"g":{"r":0,"d":0,"h":25769974541,"f":1},"s":{"r":0,"d":0,"h":30064941837,"f":1},"n":"LocalEndPoint","d":170765,"h":21475007245,"f":1},{"p":2612038,"g":{"r":0,"d":0,"h":38654876429,"f":1},"s":{"r":0,"d":0,"h":42949843725,"f":1},"n":"RemoteEndPoint","d":170765,"h":34359909133,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":170765,"h":4295138061,"f":1}],"h":170765}; }
            static get $b() { return $.$snq.System.Net.Quic.QuicConnectionOptions; }
            static get $fullName() { return `System.Net.Quic.QuicClientConnectionOptions`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicServerConnectionOptions", ($self) => class QuicServerConnectionOptions extends $.$snq.System.Net.Quic.QuicConnectionOptions
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Security.SslServerAuthenticationOptions */ get ServerAuthenticationOptions()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslServerAuthenticationOptions */ set ServerAuthenticationOptions(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 695053;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":301837,"p":[{"p":1216318,"g":{"r":0,"d":0,"h":12885596941,"f":1},"s":{"r":0,"d":0,"h":17180564237,"f":1},"n":"ServerAuthenticationOptions","d":695053,"h":8590629645,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":695053,"h":4295662349,"f":1}],"h":695053}; }
            static get $b() { return $.$snq.System.Net.Quic.QuicConnectionOptions; }
            static get $fullName() { return `System.Net.Quic.QuicServerConnectionOptions`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicStreamCapacityChangedArgs", ($self) => class QuicStreamCapacityChangedArgs extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*int */ get BidirectionalIncrement()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set BidirectionalIncrement(value)
            {
            }
            /*int */ get UnidirectionalIncrement()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set UnidirectionalIncrement(value)
            {
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 826125;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180695309,"f":1},"s":{"r":0,"d":0,"h":21475662605,"f":1},"n":"BidirectionalIncrement","d":826125,"h":12885728013,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30065597197,"f":1},"s":{"r":0,"d":0,"h":34360564493,"f":1},"n":"UnidirectionalIncrement","d":826125,"h":25770629901,"f":1}],"l":[{"t":131073,"n":"_dummy","d":826125,"h":4295793421,"f":2},{"t":655361,"n":"_dummyPrimitive","d":826125,"h":8590760717,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":826125,"h":38655531789,"f":1}],"h":826125}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Quic.QuicStreamCapacityChangedArgs`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicStream", ($self) => class QuicStream extends $.$spc.System.IO.Stream
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ get ReadsClosed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicStreamType */ get Type()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ get WritesClosed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Abort(/*System.Net.Quic.QuicAbortDirection*/ abortDirection, /*long*/ errorCode)
            {
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CompleteWrites()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snq.System.Net.Quic.QuicStream.ToString.apply(this, arguments); }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$3(/*System.ReadOnlyMemory<byte>*/ buffer, /*bool*/ completeWrites, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            static $h = 760589;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885662477,"f":32769},"n":"CanRead","d":760589,"h":8590695181,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":21475597069,"f":32769},"n":"CanSeek","d":760589,"h":17180629773,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":30065531661,"f":32769},"n":"CanTimeout","d":760589,"h":25770564365,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38655466253,"f":32769},"n":"CanWrite","d":760589,"h":34360498957,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":47245400845,"f":1},"n":"Id","d":760589,"h":42950433549,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":55835335437,"f":32769},"n":"Length","d":760589,"h":51540368141,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":64425270029,"f":32769},"s":{"r":0,"d":0,"h":68720237325,"f":32769},"n":"Position","d":760589,"h":60130302733,"f":32769},{"p":133300225,"g":{"r":0,"d":0,"h":77310171917,"f":1},"n":"ReadsClosed","d":760589,"h":73015204621,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":85900106509,"f":32769},"s":{"r":0,"d":0,"h":90195073805,"f":32769},"n":"ReadTimeout","d":760589,"h":81605139213,"f":32769},{"p":891661,"g":{"r":0,"d":0,"h":98785008397,"f":1},"n":"Type","d":760589,"h":94490041101,"f":1},{"p":133300225,"g":{"r":0,"d":0,"h":107374942989,"f":1},"n":"WritesClosed","d":760589,"h":103079975693,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":115964877581,"f":32769},"s":{"r":0,"d":0,"h":120259844877,"f":32769},"n":"WriteTimeout","d":760589,"h":111669910285,"f":32769}],"m":[{"r":65537,"p":[{"n":"abortDirection","p":105229},{"n":"errorCode","p":917505}],"n":"Abort","d":760589,"h":124554812173,"f":1},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginRead","d":760589,"h":128849779469,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginWrite","d":760589,"h":133144746765,"f":32769},{"r":65537,"n":"CompleteWrites","d":760589,"h":137439714061,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":760589,"h":141734681357,"f":32772},{"r":136118273,"n":"DisposeAsync","d":760589,"h":146029648653,"f":32769},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":760589,"h":150324615949,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":760589,"h":154619583245,"f":32769},{"r":65537,"n":"Flush","d":760589,"h":158914550541,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsync","o":"@$1","d":760589,"h":163209517837,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":760589,"h":167504485133,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":760589,"h":171799452429,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$1","d":760589,"h":176094419725,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":760589,"h":180389387021,"f":32769},{"r":655361,"n":"ReadByte","d":760589,"h":184684354317,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":760589,"h":188979321613,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":760589,"h":193274288909,"f":32769},{"r":1310721,"n":"ToString","d":760589,"h":197569256205,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":760589,"h":201864223501,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":760589,"h":206159190797,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$1","d":760589,"h":210454158093,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"completeWrites","p":262145},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$3","d":760589,"h":214749125389,"f":1},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":760589,"h":219044092685,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":760589,"h":223339059981,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":760589,"h":4295727885,"f":8}],"i":[57540609,56950785],"h":760589}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Quic.QuicStream`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicAbortDirection", ($self) => class QuicAbortDirection extends $.$spc.System.Enum
        {
            static Read = 1;
            static Write = 2;
            static Both = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Read": 1n,
                    "Write": 2n,
                    "Both": 3n
                };
            }
            static $h = 105229;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":105229,"n":"Read","d":105229,"h":4295072525,"f":33},{"t":105229,"n":"Write","d":105229,"h":8590039821,"f":33},{"t":105229,"n":"Both","d":105229,"h":12885007117,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":105229,"h":17179974413,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":105229,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Quic.QuicAbortDirection`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicError", ($self) => class QuicError extends $.$spc.System.Enum
        {
            static Success = 0;
            static InternalError = 1;
            static ConnectionAborted = 2;
            static StreamAborted = 3;
            static ConnectionTimeout = 6;
            static ConnectionRefused = 8;
            static VersionNegotiationError = 9;
            static ConnectionIdle = 10;
            static OperationAborted = 12;
            static AlpnInUse = 13;
            static TransportError = 14;
            static CallbackError = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Success": 0n,
                    "InternalError": 1n,
                    "ConnectionAborted": 2n,
                    "StreamAborted": 3n,
                    "ConnectionTimeout": 6n,
                    "ConnectionRefused": 8n,
                    "VersionNegotiationError": 9n,
                    "ConnectionIdle": 10n,
                    "OperationAborted": 12n,
                    "AlpnInUse": 13n,
                    "TransportError": 14n,
                    "CallbackError": 15n
                };
            }
            static $h = 367373;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":367373,"n":"Success","d":367373,"h":4295334669,"f":33},{"t":367373,"n":"InternalError","d":367373,"h":8590301965,"f":33},{"t":367373,"n":"ConnectionAborted","d":367373,"h":12885269261,"f":33},{"t":367373,"n":"StreamAborted","d":367373,"h":17180236557,"f":33},{"t":367373,"n":"ConnectionTimeout","d":367373,"h":21475203853,"f":33},{"t":367373,"n":"ConnectionRefused","d":367373,"h":25770171149,"f":33},{"t":367373,"n":"VersionNegotiationError","d":367373,"h":30065138445,"f":33},{"t":367373,"n":"ConnectionIdle","d":367373,"h":34360105741,"f":33},{"t":367373,"n":"OperationAborted","d":367373,"h":38655073037,"f":33},{"t":367373,"n":"AlpnInUse","d":367373,"h":42950040333,"f":33},{"t":367373,"n":"TransportError","d":367373,"h":47245007629,"f":33},{"t":367373,"n":"CallbackError","d":367373,"h":51539974925,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":367373,"h":55834942221,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":367373}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Quic.QuicError`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicStreamType", ($self) => class QuicStreamType extends $.$spc.System.Enum
        {
            static Unidirectional = 0;
            static Bidirectional = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unidirectional": 0n,
                    "Bidirectional": 1n
                };
            }
            static $h = 891661;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":891661,"n":"Unidirectional","d":891661,"h":4295858957,"f":33},{"t":891661,"n":"Bidirectional","d":891661,"h":8590826253,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":891661,"h":12885793549,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":891661}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Quic.QuicStreamType`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicException", ($self) => class QuicException extends $.$spc.System.IO.IOException
        {
            $ctor$14(/*System.Net.Quic.QuicError*/ error, /*long?*/ applicationErrorCode, /*string*/ message)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            /*long? */ get ApplicationErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicError */ get QuicError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long? */ get TransportErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 432909;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":60751873,"h":432909}; }
            static get $b() { return $.$spc.System.IO.IOException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Quic.QuicException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels"))