
//--TRIMMABLE-BOUNDARY-START(49)
(async function () {
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $stc) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.Net.Quic", 
    {
  "h": 49,
  "f": "System.Net.Quic",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Net.Quic",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Net.Quic",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(262193)
        $asm.$cls(`$snq.SNQ.QuicConnectionOptions`, ($self) => class QuicConnectionOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295229489)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295229489);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229489)
            
            //--TRIMMABLE-BOUNDARY-START(8590196785)
            /*long */ get DefaultCloseErrorCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475098673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set DefaultCloseErrorCode(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554313777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590196785)
            
            //--TRIMMABLE-BOUNDARY-START(12885164081)
            /*long */ get DefaultStreamErrorCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065033265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set DefaultStreamErrorCode(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144248369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885164081)
            
            //--TRIMMABLE-BOUNDARY-START(94489542705)
            /*System.TimeSpan */ get HandshakeTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654967857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set HandshakeTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734182961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(94489542705)
            
            //--TRIMMABLE-BOUNDARY-START(98784510001)
            /*System.TimeSpan */ get IdleTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244902449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set IdleTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324117553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(98784510001)
            
            //--TRIMMABLE-BOUNDARY-START(103079477297)
            /*System.Net.Quic.QuicReceiveWindowSizes */ get InitialReceiveWindowSizes()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834837041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicReceiveWindowSizes */ set InitialReceiveWindowSizes(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914052145);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103079477297)
            
            //--TRIMMABLE-BOUNDARY-START(107374444593)
            /*System.TimeSpan */ get KeepAliveInterval()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424771633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set KeepAliveInterval(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167503986737);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(107374444593)
            
            //--TRIMMABLE-BOUNDARY-START(111669411889)
            /*int */ get MaxInboundBidirectionalStreams()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014706225);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set MaxInboundBidirectionalStreams(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176093921329);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(111669411889)
            
            //--TRIMMABLE-BOUNDARY-START(115964379185)
            /*int */ get MaxInboundUnidirectionalStreams()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604640817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set MaxInboundUnidirectionalStreams(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184683855921);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115964379185)
            
            //--TRIMMABLE-BOUNDARY-START(197568757809)
            /*System.Action<System.Net.Quic.QuicConnection, System.Net.Quic.QuicStreamCapacityChangedArgs>? */ get StreamCapacityCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194575409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Action<System.Net.Quic.QuicConnection, System.Net.Quic.QuicStreamCapacityChangedArgs>? */ set StreamCapacityCallback(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193273790513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(197568757809)
            
            //--TRIMMABLE-BOUNDARY-START(4295229489)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295229489)
            
            static $h = 262193;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590196785),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475098673,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554313777,
        "f": 83886081
      },
      "n": "DefaultCloseErrorCode",
      "d": 262193,
      "h": 8590196785,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590196785),
//--TRIMMABLE-BOUNDARY-START(12885164081),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065033265,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144248369,
        "f": 83886081
      },
      "n": "DefaultStreamErrorCode",
      "d": 262193,
      "h": 12885164081,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885164081),
//--TRIMMABLE-BOUNDARY-START(94489542705),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654967857,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734182961,
        "f": 83886081
      },
      "n": "HandshakeTimeout",
      "d": 262193,
      "h": 94489542705,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(94489542705),
//--TRIMMABLE-BOUNDARY-START(98784510001),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244902449,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324117553,
        "f": 83886081
      },
      "n": "IdleTimeout",
      "d": 262193,
      "h": 98784510001,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784510001),
//--TRIMMABLE-BOUNDARY-START(103079477297),
    {
      "p": 589873,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834837041,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 158914052145,
        "f": 83886081
      },
      "n": "InitialReceiveWindowSizes",
      "d": 262193,
      "h": 103079477297,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079477297),
//--TRIMMABLE-BOUNDARY-START(107374444593),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424771633,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 167503986737,
        "f": 83886081
      },
      "n": "KeepAliveInterval",
      "d": 262193,
      "h": 107374444593,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107374444593),
//--TRIMMABLE-BOUNDARY-START(111669411889),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014706225,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 176093921329,
        "f": 83886081
      },
      "n": "MaxInboundBidirectionalStreams",
      "d": 262193,
      "h": 111669411889,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(111669411889),
//--TRIMMABLE-BOUNDARY-START(115964379185),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604640817,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184683855921,
        "f": 83886081
      },
      "n": "MaxInboundUnidirectionalStreams",
      "d": 262193,
      "h": 115964379185,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964379185),
//--TRIMMABLE-BOUNDARY-START(197568757809),
    {
      "p": $.$$.S.Action$$$($.$snq.SNQ.QuicConnection, $.$snq.SNQ.QuicStreamCapacityChangedArgs).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194575409,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193273790513,
        "f": 83886081
      },
      "n": "StreamCapacityCallback",
      "d": 262193,
      "h": 197568757809,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197568757809)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229489),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 262193,
      "h": 4295229489,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295229489)
  ],
  "h": 262193
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Quic.QuicConnectionOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Quic${separator}QuicConnectionOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262193)
        
        

        //--TRIMMABLE-BOUNDARY-START(524337)
        $asm.$cls(`$snq.SNQ.QuicListenerOptions`, ($self) => class QuicListenerOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295491633)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295491633);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491633)
            
            //--TRIMMABLE-BOUNDARY-START(8590458929)
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol> */ get ApplicationProtocols()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475360817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol> */ set ApplicationProtocols(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425033777);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590458929)
            
            //--TRIMMABLE-BOUNDARY-START(12885426225)
            /*System.Func<System.Net.Quic.QuicConnection, System.Net.Security.SslClientHelloInfo, System.Threading.CancellationToken, System.Threading.Tasks.ValueTask<System.Net.Quic.QuicServerConnectionOptions>> */ get ConnectionOptionsCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065295409);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Func<System.Net.Quic.QuicConnection, System.Net.Security.SslClientHelloInfo, System.Threading.CancellationToken, System.Threading.Tasks.ValueTask<System.Net.Quic.QuicServerConnectionOptions>> */ set ConnectionOptionsCallback(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014968369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885426225)
            
            //--TRIMMABLE-BOUNDARY-START(51540131889)
            /*int */ get ListenBacklog()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655230001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ListenBacklog(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604902961);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51540131889)
            
            //--TRIMMABLE-BOUNDARY-START(55835099185)
            /*System.Net.IPEndPoint */ get ListenEndPoint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245164593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ set ListenEndPoint(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194837553);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55835099185)
            
            //--TRIMMABLE-BOUNDARY-START(4295491633)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295491633)
            
            static $h = 524337;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590458929),
    {
      "p": $.$$.SCG.List$$($.$snsc.SNS.SslApplicationProtocol).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475360817,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64425033777,
        "f": 83886081
      },
      "n": "ApplicationProtocols",
      "d": 524337,
      "h": 8590458929,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590458929),
//--TRIMMABLE-BOUNDARY-START(12885426225),
    {
      "p": $.$$.S.Func$$$$$($.$snq.SNQ.QuicConnection, $.$snsc.SNS.SslClientHelloInfo, $.$$.ST$1.CancellationToken, $.$$.STT.ValueTask$$($.$snq.SNQ.QuicServerConnectionOptions)).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065295409,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 73014968369,
        "f": 83886081
      },
      "n": "ConnectionOptionsCallback",
      "d": 524337,
      "h": 12885426225,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885426225),
//--TRIMMABLE-BOUNDARY-START(51540131889),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655230001,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 81604902961,
        "f": 83886081
      },
      "n": "ListenBacklog",
      "d": 524337,
      "h": 51540131889,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540131889),
//--TRIMMABLE-BOUNDARY-START(55835099185),
    {
      "p": 3276847,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245164593,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194837553,
        "f": 83886081
      },
      "n": "ListenEndPoint",
      "d": 524337,
      "h": 55835099185,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835099185)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491633),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 524337,
      "h": 4295491633,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491633)
  ],
  "h": 524337
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Quic.QuicListenerOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Quic${separator}QuicListenerOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524337)
        
        

        //--TRIMMABLE-BOUNDARY-START(589873)
        $asm.$cls(`$snq.SNQ.QuicReceiveWindowSizes`, ($self) => class QuicReceiveWindowSizes extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295557169)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295557169);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557169)
            
            //--TRIMMABLE-BOUNDARY-START(8590524465)
            /*int */ get Connection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set Connection(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130132017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590524465)
            
            //--TRIMMABLE-BOUNDARY-START(47245230129)
            /*int */ get LocallyInitiatedBidirectionalStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770393649);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set LocallyInitiatedBidirectionalStream(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720066609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245230129)
            
            //--TRIMMABLE-BOUNDARY-START(51540197425)
            /*int */ get RemotelyInitiatedBidirectionalStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328241);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set RemotelyInitiatedBidirectionalStream(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51540197425)
            
            //--TRIMMABLE-BOUNDARY-START(90194903089)
            /*int */ get UnidirectionalStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950262833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set UnidirectionalStream(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899935793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90194903089)
            
            //--TRIMMABLE-BOUNDARY-START(4295557169)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295557169)
            
            static $h = 589873;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590524465),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180459057,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60130132017,
        "f": 83886081
      },
      "n": "Connection",
      "d": 589873,
      "h": 8590524465,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590524465),
//--TRIMMABLE-BOUNDARY-START(47245230129),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770393649,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68720066609,
        "f": 83886081
      },
      "n": "LocallyInitiatedBidirectionalStream",
      "d": 589873,
      "h": 47245230129,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245230129),
//--TRIMMABLE-BOUNDARY-START(51540197425),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360328241,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 77310001201,
        "f": 83886081
      },
      "n": "RemotelyInitiatedBidirectionalStream",
      "d": 589873,
      "h": 51540197425,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540197425),
//--TRIMMABLE-BOUNDARY-START(90194903089),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950262833,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899935793,
        "f": 83886081
      },
      "n": "UnidirectionalStream",
      "d": 589873,
      "h": 90194903089,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194903089)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557169),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 589873,
      "h": 4295557169,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557169)
  ],
  "h": 589873
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Quic.QuicReceiveWindowSizes`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Quic${separator}QuicReceiveWindowSizes`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589873)
        
        

        //--TRIMMABLE-BOUNDARY-START(196657)
        $asm.$cls(`$snq.SNQ.QuicConnection`, ($self) => class QuicConnection extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295163953)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295163953);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163953)
            
            //--TRIMMABLE-BOUNDARY-START(94489477169)
            static /*bool */ get IsSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064967729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(94489477169)
            
            //--TRIMMABLE-BOUNDARY-START(98784444465)
            /*System.Net.IPEndPoint */ get LocalEndPoint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654902321);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(98784444465)
            
            //--TRIMMABLE-BOUNDARY-START(103079411761)
            /*System.Net.Security.SslApplicationProtocol */ get NegotiatedApplicationProtocol()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244836913);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103079411761)
            
            //--TRIMMABLE-BOUNDARY-START(107374379057)
            /*System.Net.Security.TlsCipherSuite */ get NegotiatedCipherSuite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834771505);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(107374379057)
            
            //--TRIMMABLE-BOUNDARY-START(124554248241)
            /*System.Security.Authentication.SslProtocols */ get SslProtocol()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604575281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(124554248241)
            
            //--TRIMMABLE-BOUNDARY-START(115964313649)
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get RemoteCertificate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424706097);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115964313649)
            
            //--TRIMMABLE-BOUNDARY-START(120259280945)
            /*System.Net.IPEndPoint */ get RemoteEndPoint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014640689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120259280945)
            
            //--TRIMMABLE-BOUNDARY-START(128849215537)
            /*string */ get TargetHostName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194509873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(128849215537)
            
            //--TRIMMABLE-BOUNDARY-START(8590131249)
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicStream> */ AcceptInboundStreamAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590131249);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590131249)
            
            //--TRIMMABLE-BOUNDARY-START(12885098545)
            /*System.Threading.Tasks.ValueTask */ CloseAsync(/*long*/ errorCode, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885098545);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885098545)
            
            //--TRIMMABLE-BOUNDARY-START(17180065841)
            static /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicConnection> */ ConnectAsync(/*System.Net.Quic.QuicClientConnectionOptions*/ options, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180065841);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180065841)
            
            //--TRIMMABLE-BOUNDARY-START(21475033137)
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475033137);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475033137)
            
            //--TRIMMABLE-BOUNDARY-START(111669346353)
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicStream> */ OpenOutboundStreamAsync(/*System.Net.Quic.QuicStreamType*/ type, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669346353);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(111669346353)
            
            //--TRIMMABLE-BOUNDARY-START(133144182833)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144182833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(133144182833)
            
            //--TRIMMABLE-BOUNDARY-START(4385472513)
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            S$IAsyncDisposable$DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385472513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DisposeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385472513)
            
            //--TRIMMABLE-BOUNDARY-START(4295163953)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295163953)
            
            static $h = 196657;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(94489477169),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064967729,
        "f": 50331681
      },
      "n": "IsSupported",
      "d": 196657,
      "h": 94489477169,
      "f": 2097185,
      "a": [
        {
          "t": 159907841,
          "c": 4454875137,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159907841,
          "c": 4454875137,
          "a": [
            {
              "v": "linux",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159907841,
          "c": 4454875137,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94489477169),
//--TRIMMABLE-BOUNDARY-START(98784444465),
    {
      "p": 3276847,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654902321,
        "f": 50331649
      },
      "n": "LocalEndPoint",
      "d": 196657,
      "h": 98784444465,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(98784444465),
//--TRIMMABLE-BOUNDARY-START(103079411761),
    {
      "p": 917554,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244836913,
        "f": 50331649
      },
      "n": "NegotiatedApplicationProtocol",
      "d": 196657,
      "h": 103079411761,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079411761),
//--TRIMMABLE-BOUNDARY-START(107374379057),
    {
      "p": 1376306,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834771505,
        "f": 50331649
      },
      "n": "NegotiatedCipherSuite",
      "d": 196657,
      "h": 107374379057,
      "f": 2097153,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(107374379057),
//--TRIMMABLE-BOUNDARY-START(124554248241),
    {
      "p": 5570607,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81604575281,
        "f": 50331649
      },
      "n": "SslProtocol",
      "d": 196657,
      "h": 124554248241,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124554248241),
//--TRIMMABLE-BOUNDARY-START(115964313649),
    {
      "p": 28114974,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424706097,
        "f": 50331649
      },
      "n": "RemoteCertificate",
      "d": 196657,
      "h": 115964313649,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964313649),
//--TRIMMABLE-BOUNDARY-START(120259280945),
    {
      "p": 3276847,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014640689,
        "f": 50331649
      },
      "n": "RemoteEndPoint",
      "d": 196657,
      "h": 120259280945,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259280945),
//--TRIMMABLE-BOUNDARY-START(128849215537),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90194509873,
        "f": 50331649
      },
      "n": "TargetHostName",
      "d": 196657,
      "h": 128849215537,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849215537)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590131249),
    {
      "r": $.$$.STT.ValueTask$$($.$snq.SNQ.QuicStream).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "AcceptInboundStreamAsync",
      "d": 196657,
      "h": 8590131249,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590131249),
//--TRIMMABLE-BOUNDARY-START(12885098545),
    {
      "r": 181338113,
      "p": [
        {
          "n": "errorCode",
          "p": 917505
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "CloseAsync",
      "d": 196657,
      "h": 12885098545,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885098545),
//--TRIMMABLE-BOUNDARY-START(17180065841),
    {
      "r": $.$$.STT.ValueTask$$($.$snq.SNQ.QuicConnection).$h,
      "p": [
        {
          "n": "options",
          "p": 131121
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ConnectAsync",
      "d": 196657,
      "h": 17180065841,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180065841),
//--TRIMMABLE-BOUNDARY-START(21475033137),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 196657,
      "h": 21475033137,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475033137),
//--TRIMMABLE-BOUNDARY-START(111669346353),
    {
      "r": $.$$.STT.ValueTask$$($.$snq.SNQ.QuicStream).$h,
      "p": [
        {
          "n": "type",
          "p": 852017
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "OpenOutboundStreamAsync",
      "d": 196657,
      "h": 111669346353,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669346353),
//--TRIMMABLE-BOUNDARY-START(133144182833),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 196657,
      "h": 133144182833,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(133144182833)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163953),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 196657,
      "h": 4295163953,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295163953)
  ],
  "h": 196657
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Quic.QuicConnection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Quic${separator}QuicConnection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196657)
        
        

        //--TRIMMABLE-BOUNDARY-START(458801)
        $asm.$cls(`$snq.SNQ.QuicListener`, ($self) => class QuicListener extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295426097)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295426097);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426097)
            
            //--TRIMMABLE-BOUNDARY-START(34360197169)
            static /*bool */ get IsSupported()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295281);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360197169)
            
            //--TRIMMABLE-BOUNDARY-START(42950131761)
            /*System.Net.IPEndPoint */ get LocalEndPoint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950131761)
            
            //--TRIMMABLE-BOUNDARY-START(8590393393)
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicConnection> */ AcceptConnectionAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393393);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590393393)
            
            //--TRIMMABLE-BOUNDARY-START(12885360689)
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360689);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885360689)
            
            //--TRIMMABLE-BOUNDARY-START(38655164465)
            static /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicListener> */ ListenAsync(/*System.Net.Quic.QuicListenerOptions*/ options, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164465);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655164465)
            
            //--TRIMMABLE-BOUNDARY-START(47245099057)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245099057);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245099057)
            
            //--TRIMMABLE-BOUNDARY-START(4385472513)
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            S$IAsyncDisposable$DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4385472513);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.DisposeAsync(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4385472513)
            
            //--TRIMMABLE-BOUNDARY-START(4295426097)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295426097)
            
            static $h = 458801;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34360197169),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475295281,
        "f": 50331681
      },
      "n": "IsSupported",
      "d": 458801,
      "h": 34360197169,
      "f": 2097185,
      "a": [
        {
          "t": 159907841,
          "c": 4454875137,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159907841,
          "c": 4454875137,
          "a": [
            {
              "v": "linux",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159907841,
          "c": 4454875137,
          "a": [
            {
              "v": "osx",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34360197169),
//--TRIMMABLE-BOUNDARY-START(42950131761),
    {
      "p": 3276847,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065229873,
        "f": 50331649
      },
      "n": "LocalEndPoint",
      "d": 458801,
      "h": 42950131761,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950131761)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590393393),
    {
      "r": $.$$.STT.ValueTask$$($.$snq.SNQ.QuicConnection).$h,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "AcceptConnectionAsync",
      "d": 458801,
      "h": 8590393393,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590393393),
//--TRIMMABLE-BOUNDARY-START(12885360689),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 458801,
      "h": 12885360689,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885360689),
//--TRIMMABLE-BOUNDARY-START(38655164465),
    {
      "r": $.$$.STT.ValueTask$$($.$snq.SNQ.QuicListener).$h,
      "p": [
        {
          "n": "options",
          "p": 524337
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ListenAsync",
      "d": 458801,
      "h": 38655164465,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(38655164465),
//--TRIMMABLE-BOUNDARY-START(47245099057),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 458801,
      "h": 47245099057,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245099057)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426097),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458801,
      "h": 4295426097,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295426097)
  ],
  "h": 458801
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Quic.QuicListener`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Quic${separator}QuicListener`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458801)
        
        

        //--TRIMMABLE-BOUNDARY-START(131121)
        $asm.$cls(`$snq.SNQ.QuicClientConnectionOptions`, ($self) => class QuicClientConnectionOptions extends $.$snq.SNQ.QuicConnectionOptions
        {
            //--TRIMMABLE-BOUNDARY-START(4295098417)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295098417);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098417)
            
            //--TRIMMABLE-BOUNDARY-START(8590065713)
            /*System.Net.Security.SslClientAuthenticationOptions */ get ClientAuthenticationOptions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslClientAuthenticationOptions */ set ClientAuthenticationOptions(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539738673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590065713)
            
            //--TRIMMABLE-BOUNDARY-START(38654836785)
            /*System.Net.IPEndPoint? */ get LocalEndPoint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769934897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint? */ set LocalEndPoint(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129673265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38654836785)
            
            //--TRIMMABLE-BOUNDARY-START(42949804081)
            /*System.Net.EndPoint */ get RemoteEndPoint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359869489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ set RemoteEndPoint(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719607857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42949804081)
            
            //--TRIMMABLE-BOUNDARY-START(4295098417)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295098417)
            
            static $h = 131121;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$snq.SNQ.QuicConnectionOptions; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590065713),
    {
      "p": 1048626,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180000305,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51539738673,
        "f": 83886081
      },
      "n": "ClientAuthenticationOptions",
      "d": 131121,
      "h": 8590065713,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590065713),
//--TRIMMABLE-BOUNDARY-START(38654836785),
    {
      "p": 3276847,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769934897,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 60129673265,
        "f": 83886081
      },
      "n": "LocalEndPoint",
      "d": 131121,
      "h": 38654836785,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38654836785),
//--TRIMMABLE-BOUNDARY-START(42949804081),
    {
      "p": 2555951,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359869489,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 68719607857,
        "f": 83886081
      },
      "n": "RemoteEndPoint",
      "d": 131121,
      "h": 42949804081,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42949804081)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098417),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131121,
      "h": 4295098417,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098417)
  ],
  "h": 131121
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Quic.QuicClientConnectionOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Quic${separator}QuicClientConnectionOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131121)
        
        

        //--TRIMMABLE-BOUNDARY-START(655409)
        $asm.$cls(`$snq.SNQ.QuicServerConnectionOptions`, ($self) => class QuicServerConnectionOptions extends $.$snq.SNQ.QuicConnectionOptions
        {
            //--TRIMMABLE-BOUNDARY-START(4295622705)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295622705);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622705)
            
            //--TRIMMABLE-BOUNDARY-START(17180524593)
            /*System.Net.Security.SslServerAuthenticationOptions */ get ServerAuthenticationOptions()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885557297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslServerAuthenticationOptions */ set ServerAuthenticationOptions(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770459185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180524593)
            
            //--TRIMMABLE-BOUNDARY-START(4295622705)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4295622705)
            
            static $h = 655409;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$snq.SNQ.QuicConnectionOptions; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180524593),
    {
      "p": 1179698,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885557297,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 25770459185,
        "f": 83886081
      },
      "n": "ServerAuthenticationOptions",
      "d": 655409,
      "h": 17180524593,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180524593)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622705),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 655409,
      "h": 4295622705,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622705)
  ],
  "h": 655409
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Quic.QuicServerConnectionOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Quic${separator}QuicServerConnectionOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655409)
        
        

        //--TRIMMABLE-BOUNDARY-START(786481)
        $asm.$str(`$snq.SNQ.QuicStreamCapacityChangedArgs`, ($self) => class QuicStreamCapacityChangedArgs extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295753777)
            /*object*/ _dummy = null;
            //--TRIMMABLE-BOUNDARY-END(4295753777)
            
            //--TRIMMABLE-BOUNDARY-START(8590721073)
            /*int*/ _dummyPrimitive = 0;
            //--TRIMMABLE-BOUNDARY-END(8590721073)
            
            //--TRIMMABLE-BOUNDARY-START(17180655665)
            /*int */ get BidirectionalIncrement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770590257);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set BidirectionalIncrement(value)
            {
            }
            //--TRIMMABLE-BOUNDARY-END(17180655665)
            
            //--TRIMMABLE-BOUNDARY-START(55835361329)
            /*int */ get UnidirectionalIncrement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360524849);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set UnidirectionalIncrement(value)
            {
            }
            //--TRIMMABLE-BOUNDARY-END(55835361329)
            
            //--TRIMMABLE-BOUNDARY-START(12885688369)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688369);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885688369)
            
            //--TRIMMABLE-BOUNDARY-START(12885688369)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885688369)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            static $h = 786481;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180655665),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770590257,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 42950459441,
        "f": 83886081
      },
      "n": "BidirectionalIncrement",
      "d": 786481,
      "h": 17180655665,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180655665),
//--TRIMMABLE-BOUNDARY-START(55835361329),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360524849,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 51540394033,
        "f": 83886081
      },
      "n": "UnidirectionalIncrement",
      "d": 786481,
      "h": 55835361329,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835361329)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295753777),
    {
      "t": 131073,
      "n": "_dummy",
      "d": 786481,
      "h": 4295753777,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295753777),
//--TRIMMABLE-BOUNDARY-START(8590721073),
    {
      "t": 655361,
      "n": "_dummyPrimitive",
      "d": 786481,
      "h": 8590721073,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590721073)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885688369),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 786481,
      "h": 12885688369,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885688369)
  ],
  "h": 786481
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Quic.QuicStreamCapacityChangedArgs`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Quic${separator}QuicStreamCapacityChangedArgs`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786481)
        
        

        //--TRIMMABLE-BOUNDARY-START(720945)
        $asm.$cls(`$snq.SNQ.QuicStream`, ($self) => class QuicStream extends $.$$.SI.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(4295688241)
            $ctor$3()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295688241);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688241)
            
            //--TRIMMABLE-BOUNDARY-START(21475557425)
            /*bool */ get CanRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015164977);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475557425)
            
            //--TRIMMABLE-BOUNDARY-START(25770524721)
            /*bool */ get CanSeek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605099569);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770524721)
            
            //--TRIMMABLE-BOUNDARY-START(30065492017)
            /*bool */ get CanTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195034161);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065492017)
            
            //--TRIMMABLE-BOUNDARY-START(34360459313)
            /*bool */ get CanWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968753);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360459313)
            
            //--TRIMMABLE-BOUNDARY-START(171799412785)
            /*long */ get Id()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374903345);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(171799412785)
            
            //--TRIMMABLE-BOUNDARY-START(176094380081)
            /*long */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964837937);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(176094380081)
            
            //--TRIMMABLE-BOUNDARY-START(180389347377)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554772529);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339020337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(180389347377)
            
            //--TRIMMABLE-BOUNDARY-START(206159151153)
            /*System.Threading.Tasks.Task */ get ReadsClosed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144707121);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(206159151153)
            
            //--TRIMMABLE-BOUNDARY-START(210454118449)
            /*int */ get ReadTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734641713);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928954929);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(210454118449)
            
            //--TRIMMABLE-BOUNDARY-START(253403791409)
            /*System.Net.Quic.QuicStreamType */ get Type()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324576305);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(253403791409)
            
            //--TRIMMABLE-BOUNDARY-START(283468562481)
            /*System.Threading.Tasks.Task */ get WritesClosed()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914510897);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(283468562481)
            
            //--TRIMMABLE-BOUNDARY-START(287763529777)
            /*int */ get WriteTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504445489);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518889521);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(287763529777)
            
            //--TRIMMABLE-BOUNDARY-START(8590655537)
            /*void */ Abort(/*System.Net.Quic.QuicAbortDirection*/ abortDirection, /*long*/ errorCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590655537);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590655537)
            
            //--TRIMMABLE-BOUNDARY-START(12885622833)
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885622833);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885622833)
            
            //--TRIMMABLE-BOUNDARY-START(17180590129)
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180590129);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180590129)
            
            //--TRIMMABLE-BOUNDARY-START(38655426609)
            /*void */ CompleteWrites()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655426609);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38655426609)
            
            //--TRIMMABLE-BOUNDARY-START(42950393905)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950393905);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42950393905)
            
            //--TRIMMABLE-BOUNDARY-START(47245361201)
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361201);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245361201)
            
            //--TRIMMABLE-BOUNDARY-START(51540328497)
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540328497);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51540328497)
            
            //--TRIMMABLE-BOUNDARY-START(55835295793)
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295793);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(55835295793)
            
            //--TRIMMABLE-BOUNDARY-START(60130263089)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130263089);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60130263089)
            
            //--TRIMMABLE-BOUNDARY-START(64425230385)
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230385);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64425230385)
            
            //--TRIMMABLE-BOUNDARY-START(184684314673)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684314673);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(184684314673)
            
            //--TRIMMABLE-BOUNDARY-START(188979281969)
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979281969);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(188979281969)
            
            //--TRIMMABLE-BOUNDARY-START(193274249265)
            /*System.Threading.Tasks.Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274249265);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(193274249265)
            
            //--TRIMMABLE-BOUNDARY-START(197569216561)
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569216561);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(197569216561)
            
            //--TRIMMABLE-BOUNDARY-START(201864183857)
            /*int */ ReadByte()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864183857);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(201864183857)
            
            //--TRIMMABLE-BOUNDARY-START(214749085745)
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749085745);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(214749085745)
            
            //--TRIMMABLE-BOUNDARY-START(244813856817)
            /*void */ SetLength(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813856817);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(244813856817)
            
            //--TRIMMABLE-BOUNDARY-START(249108824113)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108824113);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(249108824113)
            
            //--TRIMMABLE-BOUNDARY-START(257698758705)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698758705);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(257698758705)
            
            //--TRIMMABLE-BOUNDARY-START(261993726001)
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993726001);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(261993726001)
            
            //--TRIMMABLE-BOUNDARY-START(266288693297)
            /*System.Threading.Tasks.Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266288693297);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(266288693297)
            
            //--TRIMMABLE-BOUNDARY-START(270583660593)
            /*System.Threading.Tasks.ValueTask */ WriteAsync$3(/*System.ReadOnlyMemory<byte>*/ buffer, /*bool*/ completeWrites, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583660593);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(270583660593)
            
            //--TRIMMABLE-BOUNDARY-START(274878627889)
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274878627889);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(274878627889)
            
            //--TRIMMABLE-BOUNDARY-START(279173595185)
            /*void */ WriteByte(/*byte*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173595185);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(279173595185)
            
            //--TRIMMABLE-BOUNDARY-START(4295688241)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295688241)
            
            static $h = 720945;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SI.Stream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475557425),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015164977,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 720945,
      "h": 21475557425,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475557425),
//--TRIMMABLE-BOUNDARY-START(25770524721),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605099569,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 720945,
      "h": 25770524721,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770524721),
//--TRIMMABLE-BOUNDARY-START(30065492017),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195034161,
        "f": 50364417
      },
      "n": "CanTimeout",
      "d": 720945,
      "h": 30065492017,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065492017),
//--TRIMMABLE-BOUNDARY-START(34360459313),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784968753,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 720945,
      "h": 34360459313,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360459313),
//--TRIMMABLE-BOUNDARY-START(171799412785),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374903345,
        "f": 50331649
      },
      "n": "Id",
      "d": 720945,
      "h": 171799412785,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(171799412785),
//--TRIMMABLE-BOUNDARY-START(176094380081),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115964837937,
        "f": 50364417
      },
      "n": "Length",
      "d": 720945,
      "h": 176094380081,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(176094380081),
//--TRIMMABLE-BOUNDARY-START(180389347377),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124554772529,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223339020337,
        "f": 83918849
      },
      "n": "Position",
      "d": 720945,
      "h": 180389347377,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180389347377),
//--TRIMMABLE-BOUNDARY-START(206159151153),
    {
      "p": 178454529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144707121,
        "f": 50331649
      },
      "n": "ReadsClosed",
      "d": 720945,
      "h": 206159151153,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(206159151153),
//--TRIMMABLE-BOUNDARY-START(210454118449),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734641713,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928954929,
        "f": 83918849
      },
      "n": "ReadTimeout",
      "d": 720945,
      "h": 210454118449,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(210454118449),
//--TRIMMABLE-BOUNDARY-START(253403791409),
    {
      "p": 852017,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324576305,
        "f": 50331649
      },
      "n": "Type",
      "d": 720945,
      "h": 253403791409,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(253403791409),
//--TRIMMABLE-BOUNDARY-START(283468562481),
    {
      "p": 178454529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914510897,
        "f": 50331649
      },
      "n": "WritesClosed",
      "d": 720945,
      "h": 283468562481,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(283468562481),
//--TRIMMABLE-BOUNDARY-START(287763529777),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504445489,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518889521,
        "f": 83918849
      },
      "n": "WriteTimeout",
      "d": 720945,
      "h": 287763529777,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(287763529777)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590655537),
    {
      "r": 65537,
      "p": [
        {
          "n": "abortDirection",
          "p": 65585
        },
        {
          "n": "errorCode",
          "p": 917505
        }
      ],
      "n": "Abort",
      "d": 720945,
      "h": 8590655537,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590655537),
//--TRIMMABLE-BOUNDARY-START(12885622833),
    {
      "r": 90570753,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginRead",
      "d": 720945,
      "h": 12885622833,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885622833),
//--TRIMMABLE-BOUNDARY-START(17180590129),
    {
      "r": 90570753,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginWrite",
      "d": 720945,
      "h": 17180590129,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180590129),
//--TRIMMABLE-BOUNDARY-START(38655426609),
    {
      "r": 65537,
      "n": "CompleteWrites",
      "d": 720945,
      "h": 38655426609,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655426609),
//--TRIMMABLE-BOUNDARY-START(42950393905),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 720945,
      "h": 42950393905,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(42950393905),
//--TRIMMABLE-BOUNDARY-START(47245361201),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 720945,
      "h": 47245361201,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(47245361201),
//--TRIMMABLE-BOUNDARY-START(51540328497),
    {
      "r": 655361,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndRead",
      "d": 720945,
      "h": 51540328497,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(51540328497),
//--TRIMMABLE-BOUNDARY-START(55835295793),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndWrite",
      "d": 720945,
      "h": 55835295793,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835295793),
//--TRIMMABLE-BOUNDARY-START(60130263089),
    {
      "r": 65537,
      "n": "Flush",
      "d": 720945,
      "h": 60130263089,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130263089),
//--TRIMMABLE-BOUNDARY-START(64425230385),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "FlushAsync",
      "o": "@$1",
      "d": 720945,
      "h": 64425230385,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(64425230385),
//--TRIMMABLE-BOUNDARY-START(184684314673),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 720945,
      "h": 184684314673,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184684314673),
//--TRIMMABLE-BOUNDARY-START(188979281969),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "Read",
      "o": "@$1",
      "d": 720945,
      "h": 188979281969,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(188979281969),
//--TRIMMABLE-BOUNDARY-START(193274249265),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "d": 720945,
      "h": 193274249265,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193274249265),
//--TRIMMABLE-BOUNDARY-START(197569216561),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 720945,
      "h": 197569216561,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(197569216561),
//--TRIMMABLE-BOUNDARY-START(201864183857),
    {
      "r": 655361,
      "n": "ReadByte",
      "d": 720945,
      "h": 201864183857,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(201864183857),
//--TRIMMABLE-BOUNDARY-START(214749085745),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 95289345
        }
      ],
      "n": "Seek",
      "d": 720945,
      "h": 214749085745,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(214749085745),
//--TRIMMABLE-BOUNDARY-START(244813856817),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 720945,
      "h": 244813856817,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(244813856817),
//--TRIMMABLE-BOUNDARY-START(249108824113),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 720945,
      "h": 249108824113,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(249108824113),
//--TRIMMABLE-BOUNDARY-START(257698758705),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 720945,
      "h": 257698758705,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(257698758705),
//--TRIMMABLE-BOUNDARY-START(261993726001),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Write",
      "o": "@$1",
      "d": 720945,
      "h": 261993726001,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(261993726001),
//--TRIMMABLE-BOUNDARY-START(266288693297),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "d": 720945,
      "h": 266288693297,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(266288693297),
//--TRIMMABLE-BOUNDARY-START(270583660593),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "completeWrites",
          "p": 262145
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$3",
      "d": 720945,
      "h": 270583660593,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(270583660593),
//--TRIMMABLE-BOUNDARY-START(274878627889),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 720945,
      "h": 274878627889,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(274878627889),
//--TRIMMABLE-BOUNDARY-START(279173595185),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217
        }
      ],
      "n": "WriteByte",
      "d": 720945,
      "h": 279173595185,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(279173595185)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688241),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 720945,
      "h": 4295688241,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295688241)
  ],
  "h": 720945
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Quic.QuicStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Quic${separator}QuicStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720945)
        
        

        //--TRIMMABLE-BOUNDARY-START(65585)
        $asm.$str(`$snq.SNQ.QuicAbortDirection`, ($self) => class QuicAbortDirection extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Read = 1;
            static Write = 2;
            static Both = 3;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(65585);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Read": 1n,
                    "Write": 2n,
                    "Both": 3n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295032881)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295032881);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032881)
            
            //--TRIMMABLE-BOUNDARY-START(4295032881)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295032881)
            
            static $h = 65585;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12884967473),
    {
      "t": 65585,
      "n": "Read",
      "d": 65585,
      "h": 12884967473,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12884967473),
//--TRIMMABLE-BOUNDARY-START(17179934769),
    {
      "t": 65585,
      "n": "Write",
      "d": 65585,
      "h": 17179934769,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17179934769),
//--TRIMMABLE-BOUNDARY-START(8590000177),
    {
      "t": 65585,
      "n": "Both",
      "d": 65585,
      "h": 8590000177,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590000177)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032881),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65585,
      "h": 4295032881,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295032881)
  ],
  "h": 65585,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Quic.QuicAbortDirection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Quic${separator}QuicAbortDirection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65585)
        
        

        //--TRIMMABLE-BOUNDARY-START(327729)
        $asm.$str(`$snq.SNQ.QuicError`, ($self) => class QuicError extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Success = 0;
            static InternalError = 1;
            static ConnectionAborted = 2;
            static StreamAborted = 3;
            static ConnectionTimeout = 6;
            static ConnectionRefused = 8;
            static VersionNegotiationError = 9;
            static ConnectionIdle = 10;
            static OperationAborted = 12;
            static AlpnInUse = 13;
            static TransportError = 14;
            static CallbackError = 15;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(327729);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Success": 0n,
                    "InternalError": 1n,
                    "ConnectionAborted": 2n,
                    "StreamAborted": 3n,
                    "ConnectionTimeout": 6n,
                    "ConnectionRefused": 8n,
                    "VersionNegotiationError": 9n,
                    "ConnectionIdle": 10n,
                    "OperationAborted": 12n,
                    "AlpnInUse": 13n,
                    "TransportError": 14n,
                    "CallbackError": 15n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295295025)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295025);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295025)
            
            //--TRIMMABLE-BOUNDARY-START(4295295025)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295295025)
            
            static $h = 327729;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(47244967985),
    {
      "t": 327729,
      "n": "Success",
      "d": 327729,
      "h": 47244967985,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47244967985),
//--TRIMMABLE-BOUNDARY-START(34360066097),
    {
      "t": 327729,
      "n": "InternalError",
      "d": 327729,
      "h": 34360066097,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360066097),
//--TRIMMABLE-BOUNDARY-START(17180196913),
    {
      "t": 327729,
      "n": "ConnectionAborted",
      "d": 327729,
      "h": 17180196913,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180196913),
//--TRIMMABLE-BOUNDARY-START(42950000689),
    {
      "t": 327729,
      "n": "StreamAborted",
      "d": 327729,
      "h": 42950000689,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950000689),
//--TRIMMABLE-BOUNDARY-START(30065098801),
    {
      "t": 327729,
      "n": "ConnectionTimeout",
      "d": 327729,
      "h": 30065098801,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065098801),
//--TRIMMABLE-BOUNDARY-START(25770131505),
    {
      "t": 327729,
      "n": "ConnectionRefused",
      "d": 327729,
      "h": 25770131505,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770131505),
//--TRIMMABLE-BOUNDARY-START(55834902577),
    {
      "t": 327729,
      "n": "VersionNegotiationError",
      "d": 327729,
      "h": 55834902577,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55834902577),
//--TRIMMABLE-BOUNDARY-START(21475164209),
    {
      "t": 327729,
      "n": "ConnectionIdle",
      "d": 327729,
      "h": 21475164209,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475164209),
//--TRIMMABLE-BOUNDARY-START(38655033393),
    {
      "t": 327729,
      "n": "OperationAborted",
      "d": 327729,
      "h": 38655033393,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655033393),
//--TRIMMABLE-BOUNDARY-START(8590262321),
    {
      "t": 327729,
      "n": "AlpnInUse",
      "d": 327729,
      "h": 8590262321,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590262321),
//--TRIMMABLE-BOUNDARY-START(51539935281),
    {
      "t": 327729,
      "n": "TransportError",
      "d": 327729,
      "h": 51539935281,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51539935281),
//--TRIMMABLE-BOUNDARY-START(12885229617),
    {
      "t": 327729,
      "n": "CallbackError",
      "d": 327729,
      "h": 12885229617,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885229617)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295025),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327729,
      "h": 4295295025,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295025)
  ],
  "h": 327729
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Quic.QuicError`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Quic${separator}QuicError`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327729)
        
        

        //--TRIMMABLE-BOUNDARY-START(852017)
        $asm.$str(`$snq.SNQ.QuicStreamType`, ($self) => class QuicStreamType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Unidirectional = 0;
            static Bidirectional = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(852017);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Unidirectional": 0n,
                    "Bidirectional": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295819313)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295819313);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295819313)
            
            //--TRIMMABLE-BOUNDARY-START(4295819313)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295819313)
            
            static $h = 852017;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885753905),
    {
      "t": 852017,
      "n": "Unidirectional",
      "d": 852017,
      "h": 12885753905,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885753905),
//--TRIMMABLE-BOUNDARY-START(8590786609),
    {
      "t": 852017,
      "n": "Bidirectional",
      "d": 852017,
      "h": 8590786609,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590786609)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819313),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 852017,
      "h": 4295819313,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819313)
  ],
  "h": 852017
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Quic.QuicStreamType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Quic${separator}QuicStreamType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852017)
        
        

        //--TRIMMABLE-BOUNDARY-START(393265)
        $asm.$cls(`$snq.SNQ.QuicException`, ($self) => class QuicException extends $.$$.SI.IOException
        {
            //--TRIMMABLE-BOUNDARY-START(4295360561)
            $ctor$14(/*System.Net.Quic.QuicError*/ error, /*long?*/ applicationErrorCode, /*string*/ message)
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360561);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360561)
            
            //--TRIMMABLE-BOUNDARY-START(8590327857)
            /*long? */ get ApplicationErrorCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180262449);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590327857)
            
            //--TRIMMABLE-BOUNDARY-START(38655098929)
            /*System.Net.Quic.QuicError */ get QuicError()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770197041);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655098929)
            
            //--TRIMMABLE-BOUNDARY-START(42950066225)
            /*long? */ get TransportErrorCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360131633);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950066225)
            
            static $h = 393265;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SI.IOException; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 393265
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Quic.QuicException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Quic${separator}QuicException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393265)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels"));
})();
//--TRIMMABLE-BOUNDARY-END(49)
