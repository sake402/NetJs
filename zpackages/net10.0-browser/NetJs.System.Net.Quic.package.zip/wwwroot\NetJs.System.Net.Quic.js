
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr, $snsc, $stc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Quic", 
    {"h":34093,"f":"System.Net.Quic","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Quic","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Quic","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snq.System.Net.Quic.QuicConnectionOptions", ($self) => class QuicConnectionOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*long */ get DefaultCloseErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set DefaultCloseErrorCode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get DefaultStreamErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set DefaultStreamErrorCode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get HandshakeTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set HandshakeTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get IdleTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set IdleTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicReceiveWindowSizes */ get InitialReceiveWindowSizes()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicReceiveWindowSizes */ set InitialReceiveWindowSizes(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get KeepAliveInterval()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set KeepAliveInterval(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get MaxInboundBidirectionalStreams()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set MaxInboundBidirectionalStreams(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get MaxInboundUnidirectionalStreams()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set MaxInboundUnidirectionalStreams(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Action<System.Net.Quic.QuicConnection, System.Net.Quic.QuicStreamCapacityChangedArgs>? */ get StreamCapacityCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Action<System.Net.Quic.QuicConnection, System.Net.Quic.QuicStreamCapacityChangedArgs>? */ set StreamCapacityCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 296237;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885198125,"f":1},"s":{"r":0,"d":0,"h":17180165421,"f":1},"n":"DefaultCloseErrorCode","d":296237,"h":8590230829,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":25770100013,"f":1},"s":{"r":0,"d":0,"h":30065067309,"f":1},"n":"DefaultStreamErrorCode","d":296237,"h":21475132717,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":38655001901,"f":1},"s":{"r":0,"d":0,"h":42949969197,"f":1},"n":"HandshakeTimeout","d":296237,"h":34360034605,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":51539903789,"f":1},"s":{"r":0,"d":0,"h":55834871085,"f":1},"n":"IdleTimeout","d":296237,"h":47244936493,"f":1},{"p":623917,"g":{"r":0,"d":0,"h":64424805677,"f":1},"s":{"r":0,"d":0,"h":68719772973,"f":1},"n":"InitialReceiveWindowSizes","d":296237,"h":60129838381,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":77309707565,"f":1},"s":{"r":0,"d":0,"h":81604674861,"f":1},"n":"KeepAliveInterval","d":296237,"h":73014740269,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":90194609453,"f":1},"s":{"r":0,"d":0,"h":94489576749,"f":1},"n":"MaxInboundBidirectionalStreams","d":296237,"h":85899642157,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":103079511341,"f":1},"s":{"r":0,"d":0,"h":107374478637,"f":1},"n":"MaxInboundUnidirectionalStreams","d":296237,"h":98784544045,"f":1},{"p":$.$spc.System.Action$$$($.$snq.System.Net.Quic.QuicConnection, $.$snq.System.Net.Quic.QuicStreamCapacityChangedArgs).$h,"g":{"r":0,"d":0,"h":115964413229,"f":1},"s":{"r":0,"d":0,"h":120259380525,"f":1},"n":"StreamCapacityCallback","d":296237,"h":111669445933,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":296237,"h":4295263533,"f":8}],"h":296237}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Quic.QuicConnectionOptions`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicListenerOptions", ($self) => class QuicListenerOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol> */ get ApplicationProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol> */ set ApplicationProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Func<System.Net.Quic.QuicConnection, System.Net.Security.SslClientHelloInfo, System.Threading.CancellationToken, System.Threading.Tasks.ValueTask<System.Net.Quic.QuicServerConnectionOptions>> */ get ConnectionOptionsCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Func<System.Net.Quic.QuicConnection, System.Net.Security.SslClientHelloInfo, System.Threading.CancellationToken, System.Threading.Tasks.ValueTask<System.Net.Quic.QuicServerConnectionOptions>> */ set ConnectionOptionsCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ListenBacklog()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ListenBacklog(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get ListenEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ set ListenEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 558381;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":12885460269,"f":1},"s":{"r":0,"d":0,"h":17180427565,"f":1},"n":"ApplicationProtocols","d":558381,"h":8590492973,"f":1},{"p":$.$spc.System.Func$$$$$($.$snq.System.Net.Quic.QuicConnection, $.$snsc.System.Net.Security.SslClientHelloInfo, $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicServerConnectionOptions)).$h,"g":{"r":0,"d":0,"h":25770362157,"f":1},"s":{"r":0,"d":0,"h":30065329453,"f":1},"n":"ConnectionOptionsCallback","d":558381,"h":21475394861,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38655264045,"f":1},"s":{"r":0,"d":0,"h":42950231341,"f":1},"n":"ListenBacklog","d":558381,"h":34360296749,"f":1},{"p":3318258,"g":{"r":0,"d":0,"h":51540165933,"f":1},"s":{"r":0,"d":0,"h":55835133229,"f":1},"n":"ListenEndPoint","d":558381,"h":47245198637,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":558381,"h":4295525677,"f":1}],"h":558381}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Quic.QuicListenerOptions`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicReceiveWindowSizes", ($self) => class QuicReceiveWindowSizes extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Connection()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set Connection(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get LocallyInitiatedBidirectionalStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set LocallyInitiatedBidirectionalStream(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get RemotelyInitiatedBidirectionalStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set RemotelyInitiatedBidirectionalStream(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get UnidirectionalStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set UnidirectionalStream(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 623917;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885525805,"f":1},"s":{"r":0,"d":0,"h":17180493101,"f":1},"n":"Connection","d":623917,"h":8590558509,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25770427693,"f":1},"s":{"r":0,"d":0,"h":30065394989,"f":1},"n":"LocallyInitiatedBidirectionalStream","d":623917,"h":21475460397,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38655329581,"f":1},"s":{"r":0,"d":0,"h":42950296877,"f":1},"n":"RemotelyInitiatedBidirectionalStream","d":623917,"h":34360362285,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51540231469,"f":1},"s":{"r":0,"d":0,"h":55835198765,"f":1},"n":"UnidirectionalStream","d":623917,"h":47245264173,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":623917,"h":4295591213,"f":1}],"h":623917}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Quic.QuicReceiveWindowSizes`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicConnection", ($self) => class QuicConnection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ get IsSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslApplicationProtocol */ get NegotiatedApplicationProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.TlsCipherSuite */ get NegotiatedCipherSuite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get RemoteCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get TargetHostName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicStream> */ AcceptInboundStreamAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ CloseAsync(/*long*/ errorCode, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicConnection> */ ConnectAsync(/*System.Net.Quic.QuicClientConnectionOptions*/ options, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicStream> */ OpenOutboundStreamAsync(/*System.Net.Quic.QuicStreamType*/ type, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snq.System.Net.Quic.QuicConnection.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            static $h = 230701;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885132589,"f":33},"n":"IsSupported","d":230701,"h":8590165293,"f":33,"a":[{"t":115015681,"c":4409982977,"a":[{"v":"windows","t":1310721}]},{"t":115015681,"c":4409982977,"a":[{"v":"linux","t":1310721}]},{"t":115015681,"c":4409982977,"a":[{"v":"osx","t":1310721}]}]},{"p":3318258,"g":{"r":0,"d":0,"h":21475067181,"f":1},"n":"LocalEndPoint","d":230701,"h":17180099885,"f":1},{"p":970860,"g":{"r":0,"d":0,"h":30065001773,"f":1},"n":"NegotiatedApplicationProtocol","d":230701,"h":25770034477,"f":1},{"p":1429612,"g":{"r":0,"d":0,"h":38654936365,"f":1},"n":"NegotiatedCipherSuite","d":230701,"h":34359969069,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"p":5612018,"g":{"r":0,"d":0,"h":47244870957,"f":1},"n":"SslProtocol","d":230701,"h":42949903661,"f":1},{"p":28168653,"g":{"r":0,"d":0,"h":55834805549,"f":1},"n":"RemoteCertificate","d":230701,"h":51539838253,"f":1},{"p":3318258,"g":{"r":0,"d":0,"h":64424740141,"f":1},"n":"RemoteEndPoint","d":230701,"h":60129772845,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":73014674733,"f":1},"n":"TargetHostName","d":230701,"h":68719707437,"f":1}],"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicStream).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"AcceptInboundStreamAsync","d":230701,"h":77309642029,"f":1},{"r":136118273,"p":[{"n":"errorCode","p":917505},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CloseAsync","d":230701,"h":81604609325,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicConnection).$h,"p":[{"n":"options","p":165165},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ConnectAsync","d":230701,"h":85899576621,"f":33},{"r":136118273,"n":"DisposeAsync","d":230701,"h":90194543917,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicStream).$h,"p":[{"n":"type","p":886061},{"n":"cancellationToken","p":125960193,"f":65}],"n":"OpenOutboundStreamAsync","d":230701,"h":94489511213,"f":1},{"r":1310721,"n":"ToString","d":230701,"h":98784478509,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":230701,"h":4295197997,"f":8}],"i":[56950785],"h":230701}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Quic.QuicConnection`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicListener", ($self) => class QuicListener extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ get IsSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicConnection> */ AcceptConnectionAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicListener> */ ListenAsync(/*System.Net.Quic.QuicListenerOptions*/ options, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snq.System.Net.Quic.QuicListener.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            static $h = 492845;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885394733,"f":33},"n":"IsSupported","d":492845,"h":8590427437,"f":33,"a":[{"t":115015681,"c":4409982977,"a":[{"v":"windows","t":1310721}]},{"t":115015681,"c":4409982977,"a":[{"v":"linux","t":1310721}]},{"t":115015681,"c":4409982977,"a":[{"v":"osx","t":1310721}]}]},{"p":3318258,"g":{"r":0,"d":0,"h":21475329325,"f":1},"n":"LocalEndPoint","d":492845,"h":17180362029,"f":1}],"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicConnection).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"AcceptConnectionAsync","d":492845,"h":25770296621,"f":1},{"r":136118273,"n":"DisposeAsync","d":492845,"h":30065263917,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicListener).$h,"p":[{"n":"options","p":558381},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ListenAsync","d":492845,"h":34360231213,"f":33},{"r":1310721,"n":"ToString","d":492845,"h":38655198509,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":492845,"h":4295460141,"f":8}],"i":[56950785],"h":492845}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Quic.QuicListener`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicClientConnectionOptions", ($self) => class QuicClientConnectionOptions extends $.$snq.System.Net.Quic.QuicConnectionOptions
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Security.SslClientAuthenticationOptions */ get ClientAuthenticationOptions()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslClientAuthenticationOptions */ set ClientAuthenticationOptions(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint? */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint? */ set LocalEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ set RemoteEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 165165;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":296237,"p":[{"p":1101932,"g":{"r":0,"d":0,"h":12885067053,"f":1},"s":{"r":0,"d":0,"h":17180034349,"f":1},"n":"ClientAuthenticationOptions","d":165165,"h":8590099757,"f":1},{"p":3318258,"g":{"r":0,"d":0,"h":25769968941,"f":1},"s":{"r":0,"d":0,"h":30064936237,"f":1},"n":"LocalEndPoint","d":165165,"h":21475001645,"f":1},{"p":2597362,"g":{"r":0,"d":0,"h":38654870829,"f":1},"s":{"r":0,"d":0,"h":42949838125,"f":1},"n":"RemoteEndPoint","d":165165,"h":34359903533,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":165165,"h":4295132461,"f":1}],"h":165165}; }
            static get $b() { return $.$snq.System.Net.Quic.QuicConnectionOptions; }
            static get $fullName() { return `System.Net.Quic.QuicClientConnectionOptions`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicServerConnectionOptions", ($self) => class QuicServerConnectionOptions extends $.$snq.System.Net.Quic.QuicConnectionOptions
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Security.SslServerAuthenticationOptions */ get ServerAuthenticationOptions()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslServerAuthenticationOptions */ set ServerAuthenticationOptions(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 689453;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":296237,"p":[{"p":1233004,"g":{"r":0,"d":0,"h":12885591341,"f":1},"s":{"r":0,"d":0,"h":17180558637,"f":1},"n":"ServerAuthenticationOptions","d":689453,"h":8590624045,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":689453,"h":4295656749,"f":1}],"h":689453}; }
            static get $b() { return $.$snq.System.Net.Quic.QuicConnectionOptions; }
            static get $fullName() { return `System.Net.Quic.QuicServerConnectionOptions`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicStreamCapacityChangedArgs", ($self) => class QuicStreamCapacityChangedArgs extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*int */ get BidirectionalIncrement()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set BidirectionalIncrement(value)
            {
            }
            /*int */ get UnidirectionalIncrement()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set UnidirectionalIncrement(value)
            {
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 820525;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180689709,"f":1},"s":{"r":0,"d":0,"h":21475657005,"f":1},"n":"BidirectionalIncrement","d":820525,"h":12885722413,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30065591597,"f":1},"s":{"r":0,"d":0,"h":34360558893,"f":1},"n":"UnidirectionalIncrement","d":820525,"h":25770624301,"f":1}],"l":[{"t":131073,"n":"_dummy","d":820525,"h":4295787821,"f":2},{"t":655361,"n":"_dummyPrimitive","d":820525,"h":8590755117,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":820525,"h":38655526189,"f":1}],"h":820525}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Quic.QuicStreamCapacityChangedArgs`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicStream", ($self) => class QuicStream extends $.$spc.System.IO.Stream
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ get ReadsClosed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicStreamType */ get Type()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ get WritesClosed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Abort(/*System.Net.Quic.QuicAbortDirection*/ abortDirection, /*long*/ errorCode)
            {
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CompleteWrites()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snq.System.Net.Quic.QuicStream.ToString.apply(this, arguments); }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$3(/*System.ReadOnlyMemory<byte>*/ buffer, /*bool*/ completeWrites, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            static $h = 754989;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885656877,"f":32769},"n":"CanRead","d":754989,"h":8590689581,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":21475591469,"f":32769},"n":"CanSeek","d":754989,"h":17180624173,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":30065526061,"f":32769},"n":"CanTimeout","d":754989,"h":25770558765,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38655460653,"f":32769},"n":"CanWrite","d":754989,"h":34360493357,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":47245395245,"f":1},"n":"Id","d":754989,"h":42950427949,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":55835329837,"f":32769},"n":"Length","d":754989,"h":51540362541,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":64425264429,"f":32769},"s":{"r":0,"d":0,"h":68720231725,"f":32769},"n":"Position","d":754989,"h":60130297133,"f":32769},{"p":133300225,"g":{"r":0,"d":0,"h":77310166317,"f":1},"n":"ReadsClosed","d":754989,"h":73015199021,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":85900100909,"f":32769},"s":{"r":0,"d":0,"h":90195068205,"f":32769},"n":"ReadTimeout","d":754989,"h":81605133613,"f":32769},{"p":886061,"g":{"r":0,"d":0,"h":98785002797,"f":1},"n":"Type","d":754989,"h":94490035501,"f":1},{"p":133300225,"g":{"r":0,"d":0,"h":107374937389,"f":1},"n":"WritesClosed","d":754989,"h":103079970093,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":115964871981,"f":32769},"s":{"r":0,"d":0,"h":120259839277,"f":32769},"n":"WriteTimeout","d":754989,"h":111669904685,"f":32769}],"m":[{"r":65537,"p":[{"n":"abortDirection","p":99629},{"n":"errorCode","p":917505}],"n":"Abort","d":754989,"h":124554806573,"f":1},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginRead","d":754989,"h":128849773869,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14483457},{"n":"state","p":131073}],"n":"BeginWrite","d":754989,"h":133144741165,"f":32769},{"r":65537,"n":"CompleteWrites","d":754989,"h":137439708461,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":754989,"h":141734675757,"f":32772},{"r":136118273,"n":"DisposeAsync","d":754989,"h":146029643053,"f":32769},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":754989,"h":150324610349,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":754989,"h":154619577645,"f":32769},{"r":65537,"n":"Flush","d":754989,"h":158914544941,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsync","o":"@$1","d":754989,"h":163209512237,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":754989,"h":167504479533,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":754989,"h":171799446829,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$1","d":754989,"h":176094414125,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":754989,"h":180389381421,"f":32769},{"r":655361,"n":"ReadByte","d":754989,"h":184684348717,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":754989,"h":188979316013,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":754989,"h":193274283309,"f":32769},{"r":1310721,"n":"ToString","d":754989,"h":197569250605,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":754989,"h":201864217901,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":754989,"h":206159185197,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$1","d":754989,"h":210454152493,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"completeWrites","p":262145},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$3","d":754989,"h":214749119789,"f":1},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":754989,"h":219044087085,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":754989,"h":223339054381,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":754989,"h":4295722285,"f":8}],"i":[57540609,56950785],"h":754989}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Quic.QuicStream`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicAbortDirection", ($self) => class QuicAbortDirection extends $.$spc.System.Enum
        {
            static Read = 1;
            static Write = 2;
            static Both = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Read": 1n,
                    "Write": 2n,
                    "Both": 3n
                };
            }
            static $h = 99629;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":99629,"n":"Read","d":99629,"h":4295066925,"f":33},{"t":99629,"n":"Write","d":99629,"h":8590034221,"f":33},{"t":99629,"n":"Both","d":99629,"h":12885001517,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":99629,"h":17179968813,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":99629,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Quic.QuicAbortDirection`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicError", ($self) => class QuicError extends $.$spc.System.Enum
        {
            static Success = 0;
            static InternalError = 1;
            static ConnectionAborted = 2;
            static StreamAborted = 3;
            static ConnectionTimeout = 6;
            static ConnectionRefused = 8;
            static VersionNegotiationError = 9;
            static ConnectionIdle = 10;
            static OperationAborted = 12;
            static AlpnInUse = 13;
            static TransportError = 14;
            static CallbackError = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Success": 0n,
                    "InternalError": 1n,
                    "ConnectionAborted": 2n,
                    "StreamAborted": 3n,
                    "ConnectionTimeout": 6n,
                    "ConnectionRefused": 8n,
                    "VersionNegotiationError": 9n,
                    "ConnectionIdle": 10n,
                    "OperationAborted": 12n,
                    "AlpnInUse": 13n,
                    "TransportError": 14n,
                    "CallbackError": 15n
                };
            }
            static $h = 361773;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":361773,"n":"Success","d":361773,"h":4295329069,"f":33},{"t":361773,"n":"InternalError","d":361773,"h":8590296365,"f":33},{"t":361773,"n":"ConnectionAborted","d":361773,"h":12885263661,"f":33},{"t":361773,"n":"StreamAborted","d":361773,"h":17180230957,"f":33},{"t":361773,"n":"ConnectionTimeout","d":361773,"h":21475198253,"f":33},{"t":361773,"n":"ConnectionRefused","d":361773,"h":25770165549,"f":33},{"t":361773,"n":"VersionNegotiationError","d":361773,"h":30065132845,"f":33},{"t":361773,"n":"ConnectionIdle","d":361773,"h":34360100141,"f":33},{"t":361773,"n":"OperationAborted","d":361773,"h":38655067437,"f":33},{"t":361773,"n":"AlpnInUse","d":361773,"h":42950034733,"f":33},{"t":361773,"n":"TransportError","d":361773,"h":47245002029,"f":33},{"t":361773,"n":"CallbackError","d":361773,"h":51539969325,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":361773,"h":55834936621,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":361773}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Quic.QuicError`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicStreamType", ($self) => class QuicStreamType extends $.$spc.System.Enum
        {
            static Unidirectional = 0;
            static Bidirectional = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unidirectional": 0n,
                    "Bidirectional": 1n
                };
            }
            static $h = 886061;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":886061,"n":"Unidirectional","d":886061,"h":4295853357,"f":33},{"t":886061,"n":"Bidirectional","d":886061,"h":8590820653,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":886061,"h":12885787949,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":886061}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Quic.QuicStreamType`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicException", ($self) => class QuicException extends $.$spc.System.IO.IOException
        {
            $ctor$14(/*System.Net.Quic.QuicError*/ error, /*long?*/ applicationErrorCode, /*string*/ message)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            /*long? */ get ApplicationErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicError */ get QuicError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long? */ get TransportErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 427309;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":60751873,"h":427309}; }
            static get $b() { return $.$spc.System.IO.IOException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Quic.QuicException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels"))