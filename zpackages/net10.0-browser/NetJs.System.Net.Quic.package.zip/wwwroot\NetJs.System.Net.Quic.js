
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $srn, $ssc, $sris, $stc, $scsl, $sfa, $sic, $sim, $sl, $snp, $sspw, $sci, $sdd, $srm, $snnr, $sds, $sns, $sscr, $snsc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Quic", 
    {"h":35071,"f":"System.Net.Quic","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Quic","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Quic","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snq.System.Net.Quic.QuicConnectionOptions", ($self) => class QuicConnectionOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*long */ get DefaultCloseErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set DefaultCloseErrorCode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get DefaultStreamErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set DefaultStreamErrorCode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get HandshakeTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set HandshakeTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get IdleTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set IdleTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicReceiveWindowSizes */ get InitialReceiveWindowSizes()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicReceiveWindowSizes */ set InitialReceiveWindowSizes(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get KeepAliveInterval()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set KeepAliveInterval(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get MaxInboundBidirectionalStreams()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set MaxInboundBidirectionalStreams(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get MaxInboundUnidirectionalStreams()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set MaxInboundUnidirectionalStreams(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Action<System.Net.Quic.QuicConnection, System.Net.Quic.QuicStreamCapacityChangedArgs>? */ get StreamCapacityCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Action<System.Net.Quic.QuicConnection, System.Net.Quic.QuicStreamCapacityChangedArgs>? */ set StreamCapacityCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 297215;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885199103,"f":1},"s":{"r":0,"d":0,"h":17180166399,"f":1},"n":"DefaultCloseErrorCode","d":297215,"h":8590231807,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":25770100991,"f":1},"s":{"r":0,"d":0,"h":30065068287,"f":1},"n":"DefaultStreamErrorCode","d":297215,"h":21475133695,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":38655002879,"f":1},"s":{"r":0,"d":0,"h":42949970175,"f":1},"n":"HandshakeTimeout","d":297215,"h":34360035583,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":51539904767,"f":1},"s":{"r":0,"d":0,"h":55834872063,"f":1},"n":"IdleTimeout","d":297215,"h":47244937471,"f":1},{"p":624895,"g":{"r":0,"d":0,"h":64424806655,"f":1},"s":{"r":0,"d":0,"h":68719773951,"f":1},"n":"InitialReceiveWindowSizes","d":297215,"h":60129839359,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":77309708543,"f":1},"s":{"r":0,"d":0,"h":81604675839,"f":1},"n":"KeepAliveInterval","d":297215,"h":73014741247,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":90194610431,"f":1},"s":{"r":0,"d":0,"h":94489577727,"f":1},"n":"MaxInboundBidirectionalStreams","d":297215,"h":85899643135,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":103079512319,"f":1},"s":{"r":0,"d":0,"h":107374479615,"f":1},"n":"MaxInboundUnidirectionalStreams","d":297215,"h":98784545023,"f":1},{"p":$.$spc.System.Action$$$($.$snq.System.Net.Quic.QuicConnection, $.$snq.System.Net.Quic.QuicStreamCapacityChangedArgs).$h,"g":{"r":0,"d":0,"h":115964414207,"f":1},"s":{"r":0,"d":0,"h":120259381503,"f":1},"n":"StreamCapacityCallback","d":297215,"h":111669446911,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":297215,"h":4295264511,"f":8}],"h":297215}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Quic.QuicConnectionOptions`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicListenerOptions", ($self) => class QuicListenerOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol> */ get ApplicationProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol> */ set ApplicationProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Func<System.Net.Quic.QuicConnection, System.Net.Security.SslClientHelloInfo, System.Threading.CancellationToken, System.Threading.Tasks.ValueTask<System.Net.Quic.QuicServerConnectionOptions>> */ get ConnectionOptionsCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Func<System.Net.Quic.QuicConnection, System.Net.Security.SslClientHelloInfo, System.Threading.CancellationToken, System.Threading.Tasks.ValueTask<System.Net.Quic.QuicServerConnectionOptions>> */ set ConnectionOptionsCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ListenBacklog()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ListenBacklog(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get ListenEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ set ListenEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 559359;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":12885461247,"f":1},"s":{"r":0,"d":0,"h":17180428543,"f":1},"n":"ApplicationProtocols","d":559359,"h":8590493951,"f":1},{"p":$.$spc.System.Func$$$$$($.$snq.System.Net.Quic.QuicConnection, $.$snsc.System.Net.Security.SslClientHelloInfo, $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicServerConnectionOptions)).$h,"g":{"r":0,"d":0,"h":25770363135,"f":1},"s":{"r":0,"d":0,"h":30065330431,"f":1},"n":"ConnectionOptionsCallback","d":559359,"h":21475395839,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38655265023,"f":1},"s":{"r":0,"d":0,"h":42950232319,"f":1},"n":"ListenBacklog","d":559359,"h":34360297727,"f":1},{"p":3315146,"g":{"r":0,"d":0,"h":51540166911,"f":1},"s":{"r":0,"d":0,"h":55835134207,"f":1},"n":"ListenEndPoint","d":559359,"h":47245199615,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":559359,"h":4295526655,"f":1}],"h":559359}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Quic.QuicListenerOptions`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicReceiveWindowSizes", ($self) => class QuicReceiveWindowSizes extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Connection()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set Connection(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get LocallyInitiatedBidirectionalStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set LocallyInitiatedBidirectionalStream(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get RemotelyInitiatedBidirectionalStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set RemotelyInitiatedBidirectionalStream(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get UnidirectionalStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set UnidirectionalStream(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 624895;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885526783,"f":1},"s":{"r":0,"d":0,"h":17180494079,"f":1},"n":"Connection","d":624895,"h":8590559487,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25770428671,"f":1},"s":{"r":0,"d":0,"h":30065395967,"f":1},"n":"LocallyInitiatedBidirectionalStream","d":624895,"h":21475461375,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38655330559,"f":1},"s":{"r":0,"d":0,"h":42950297855,"f":1},"n":"RemotelyInitiatedBidirectionalStream","d":624895,"h":34360363263,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51540232447,"f":1},"s":{"r":0,"d":0,"h":55835199743,"f":1},"n":"UnidirectionalStream","d":624895,"h":47245265151,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":624895,"h":4295592191,"f":1}],"h":624895}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Quic.QuicReceiveWindowSizes`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicConnection", ($self) => class QuicConnection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ get IsSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslApplicationProtocol */ get NegotiatedApplicationProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.TlsCipherSuite */ get NegotiatedCipherSuite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get RemoteCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get TargetHostName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicStream> */ AcceptInboundStreamAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ CloseAsync(/*long*/ errorCode, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicConnection> */ ConnectAsync(/*System.Net.Quic.QuicClientConnectionOptions*/ options, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicStream> */ OpenOutboundStreamAsync(/*System.Net.Quic.QuicStreamType*/ type, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snq.System.Net.Quic.QuicConnection.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            static $h = 231679;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885133567,"f":33},"n":"IsSupported","d":231679,"h":8590166271,"f":33,"a":[{"t":115015681,"c":4409982977,"a":[{"v":"windows","t":1310721}]},{"t":115015681,"c":4409982977,"a":[{"v":"linux","t":1310721}]},{"t":115015681,"c":4409982977,"a":[{"v":"osx","t":1310721}]}]},{"p":3315146,"g":{"r":0,"d":0,"h":21475068159,"f":1},"n":"LocalEndPoint","d":231679,"h":17180100863,"f":1},{"p":974949,"g":{"r":0,"d":0,"h":30065002751,"f":1},"n":"NegotiatedApplicationProtocol","d":231679,"h":25770035455,"f":1},{"p":1433701,"g":{"r":0,"d":0,"h":38654937343,"f":1},"n":"NegotiatedCipherSuite","d":231679,"h":34359970047,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"p":5608906,"g":{"r":0,"d":0,"h":47244871935,"f":1},"n":"SslProtocol","d":231679,"h":42949904639,"f":1},{"p":28174526,"g":{"r":0,"d":0,"h":55834806527,"f":1},"n":"RemoteCertificate","d":231679,"h":51539839231,"f":1},{"p":3315146,"g":{"r":0,"d":0,"h":64424741119,"f":1},"n":"RemoteEndPoint","d":231679,"h":60129773823,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":73014675711,"f":1},"n":"TargetHostName","d":231679,"h":68719708415,"f":1}],"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicStream).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"AcceptInboundStreamAsync","d":231679,"h":77309643007,"f":1},{"r":136118273,"p":[{"n":"errorCode","p":917505},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CloseAsync","d":231679,"h":81604610303,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicConnection).$h,"p":[{"n":"options","p":166143},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ConnectAsync","d":231679,"h":85899577599,"f":33},{"r":136118273,"n":"DisposeAsync","d":231679,"h":90194544895,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicStream).$h,"p":[{"n":"type","p":887039},{"n":"cancellationToken","p":125960193,"f":65}],"n":"OpenOutboundStreamAsync","d":231679,"h":94489512191,"f":1},{"r":1310721,"n":"ToString","d":231679,"h":98784479487,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":231679,"h":4295198975,"f":8}],"i":[56885249],"h":231679}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Quic.QuicConnection`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicListener", ($self) => class QuicListener extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ get IsSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicConnection> */ AcceptConnectionAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicListener> */ ListenAsync(/*System.Net.Quic.QuicListenerOptions*/ options, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snq.System.Net.Quic.QuicListener.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            static $h = 493823;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885395711,"f":33},"n":"IsSupported","d":493823,"h":8590428415,"f":33,"a":[{"t":115015681,"c":4409982977,"a":[{"v":"windows","t":1310721}]},{"t":115015681,"c":4409982977,"a":[{"v":"linux","t":1310721}]},{"t":115015681,"c":4409982977,"a":[{"v":"osx","t":1310721}]}]},{"p":3315146,"g":{"r":0,"d":0,"h":21475330303,"f":1},"n":"LocalEndPoint","d":493823,"h":17180363007,"f":1}],"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicConnection).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"AcceptConnectionAsync","d":493823,"h":25770297599,"f":1},{"r":136118273,"n":"DisposeAsync","d":493823,"h":30065264895,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicListener).$h,"p":[{"n":"options","p":559359},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ListenAsync","d":493823,"h":34360232191,"f":33},{"r":1310721,"n":"ToString","d":493823,"h":38655199487,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":493823,"h":4295461119,"f":8}],"i":[56885249],"h":493823}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Quic.QuicListener`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicClientConnectionOptions", ($self) => class QuicClientConnectionOptions extends $.$snq.System.Net.Quic.QuicConnectionOptions
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Security.SslClientAuthenticationOptions */ get ClientAuthenticationOptions()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslClientAuthenticationOptions */ set ClientAuthenticationOptions(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint? */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint? */ set LocalEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ set RemoteEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 166143;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":297215,"p":[{"p":1106021,"g":{"r":0,"d":0,"h":12885068031,"f":1},"s":{"r":0,"d":0,"h":17180035327,"f":1},"n":"ClientAuthenticationOptions","d":166143,"h":8590100735,"f":1},{"p":3315146,"g":{"r":0,"d":0,"h":25769969919,"f":1},"s":{"r":0,"d":0,"h":30064937215,"f":1},"n":"LocalEndPoint","d":166143,"h":21475002623,"f":1},{"p":2594250,"g":{"r":0,"d":0,"h":38654871807,"f":1},"s":{"r":0,"d":0,"h":42949839103,"f":1},"n":"RemoteEndPoint","d":166143,"h":34359904511,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":166143,"h":4295133439,"f":1}],"h":166143}; }
            static get $b() { return $.$snq.System.Net.Quic.QuicConnectionOptions; }
            static get $fullName() { return `System.Net.Quic.QuicClientConnectionOptions`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicServerConnectionOptions", ($self) => class QuicServerConnectionOptions extends $.$snq.System.Net.Quic.QuicConnectionOptions
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Security.SslServerAuthenticationOptions */ get ServerAuthenticationOptions()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslServerAuthenticationOptions */ set ServerAuthenticationOptions(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 690431;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":297215,"p":[{"p":1237093,"g":{"r":0,"d":0,"h":12885592319,"f":1},"s":{"r":0,"d":0,"h":17180559615,"f":1},"n":"ServerAuthenticationOptions","d":690431,"h":8590625023,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":690431,"h":4295657727,"f":1}],"h":690431}; }
            static get $b() { return $.$snq.System.Net.Quic.QuicConnectionOptions; }
            static get $fullName() { return `System.Net.Quic.QuicServerConnectionOptions`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicStreamCapacityChangedArgs", ($self) => class QuicStreamCapacityChangedArgs extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*int */ get BidirectionalIncrement()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set BidirectionalIncrement(value)
            {
            }
            /*int */ get UnidirectionalIncrement()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set UnidirectionalIncrement(value)
            {
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 821503;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180690687,"f":1},"s":{"r":0,"d":0,"h":21475657983,"f":1},"n":"BidirectionalIncrement","d":821503,"h":12885723391,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30065592575,"f":1},"s":{"r":0,"d":0,"h":34360559871,"f":1},"n":"UnidirectionalIncrement","d":821503,"h":25770625279,"f":1}],"l":[{"t":131073,"n":"_dummy","d":821503,"h":4295788799,"f":2},{"t":655361,"n":"_dummyPrimitive","d":821503,"h":8590756095,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":821503,"h":38655527167,"f":1}],"h":821503}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Quic.QuicStreamCapacityChangedArgs`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicStream", ($self) => class QuicStream extends $.$spc.System.IO.Stream
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ get ReadsClosed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicStreamType */ get Type()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ get WritesClosed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Abort(/*System.Net.Quic.QuicAbortDirection*/ abortDirection, /*long*/ errorCode)
            {
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CompleteWrites()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snq.System.Net.Quic.QuicStream.ToString.apply(this, arguments); }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$3(/*System.ReadOnlyMemory<byte>*/ buffer, /*bool*/ completeWrites, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            static $h = 755967;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885657855,"f":32769},"n":"CanRead","d":755967,"h":8590690559,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":21475592447,"f":32769},"n":"CanSeek","d":755967,"h":17180625151,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":30065527039,"f":32769},"n":"CanTimeout","d":755967,"h":25770559743,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38655461631,"f":32769},"n":"CanWrite","d":755967,"h":34360494335,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":47245396223,"f":1},"n":"Id","d":755967,"h":42950428927,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":55835330815,"f":32769},"n":"Length","d":755967,"h":51540363519,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":64425265407,"f":32769},"s":{"r":0,"d":0,"h":68720232703,"f":32769},"n":"Position","d":755967,"h":60130298111,"f":32769},{"p":133300225,"g":{"r":0,"d":0,"h":77310167295,"f":1},"n":"ReadsClosed","d":755967,"h":73015199999,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":85900101887,"f":32769},"s":{"r":0,"d":0,"h":90195069183,"f":32769},"n":"ReadTimeout","d":755967,"h":81605134591,"f":32769},{"p":887039,"g":{"r":0,"d":0,"h":98785003775,"f":1},"n":"Type","d":755967,"h":94490036479,"f":1},{"p":133300225,"g":{"r":0,"d":0,"h":107374938367,"f":1},"n":"WritesClosed","d":755967,"h":103079971071,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":115964872959,"f":32769},"s":{"r":0,"d":0,"h":120259840255,"f":32769},"n":"WriteTimeout","d":755967,"h":111669905663,"f":32769}],"m":[{"r":65537,"p":[{"n":"abortDirection","p":100607},{"n":"errorCode","p":917505}],"n":"Abort","d":755967,"h":124554807551,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginRead","d":755967,"h":128849774847,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWrite","d":755967,"h":133144742143,"f":32769},{"r":65537,"n":"CompleteWrites","d":755967,"h":137439709439,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":755967,"h":141734676735,"f":32772},{"r":136118273,"n":"DisposeAsync","d":755967,"h":146029644031,"f":32769},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":755967,"h":150324611327,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":755967,"h":154619578623,"f":32769},{"r":65537,"n":"Flush","d":755967,"h":158914545919,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsync","o":"@$1","d":755967,"h":163209513215,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":755967,"h":167504480511,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":755967,"h":171799447807,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$1","d":755967,"h":176094415103,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":755967,"h":180389382399,"f":32769},{"r":655361,"n":"ReadByte","d":755967,"h":184684349695,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":755967,"h":188979316991,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":755967,"h":193274284287,"f":32769},{"r":1310721,"n":"ToString","d":755967,"h":197569251583,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":755967,"h":201864218879,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":755967,"h":206159186175,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$1","d":755967,"h":210454153471,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"completeWrites","p":262145},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$3","d":755967,"h":214749120767,"f":1},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":755967,"h":219044088063,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":755967,"h":223339055359,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":755967,"h":4295723263,"f":8}],"i":[57475073,56885249],"h":755967}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Quic.QuicStream`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicAbortDirection", ($self) => class QuicAbortDirection extends $.$spc.System.Enum
        {
            static Read = 1;
            static Write = 2;
            static Both = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Read": 1n,
                    "Write": 2n,
                    "Both": 3n
                };
            }
            static $h = 100607;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":100607,"n":"Read","d":100607,"h":4295067903,"f":33},{"t":100607,"n":"Write","d":100607,"h":8590035199,"f":33},{"t":100607,"n":"Both","d":100607,"h":12885002495,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":100607,"h":17179969791,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":100607,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Quic.QuicAbortDirection`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicError", ($self) => class QuicError extends $.$spc.System.Enum
        {
            static Success = 0;
            static InternalError = 1;
            static ConnectionAborted = 2;
            static StreamAborted = 3;
            static ConnectionTimeout = 6;
            static ConnectionRefused = 8;
            static VersionNegotiationError = 9;
            static ConnectionIdle = 10;
            static OperationAborted = 12;
            static AlpnInUse = 13;
            static TransportError = 14;
            static CallbackError = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Success": 0n,
                    "InternalError": 1n,
                    "ConnectionAborted": 2n,
                    "StreamAborted": 3n,
                    "ConnectionTimeout": 6n,
                    "ConnectionRefused": 8n,
                    "VersionNegotiationError": 9n,
                    "ConnectionIdle": 10n,
                    "OperationAborted": 12n,
                    "AlpnInUse": 13n,
                    "TransportError": 14n,
                    "CallbackError": 15n
                };
            }
            static $h = 362751;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":362751,"n":"Success","d":362751,"h":4295330047,"f":33},{"t":362751,"n":"InternalError","d":362751,"h":8590297343,"f":33},{"t":362751,"n":"ConnectionAborted","d":362751,"h":12885264639,"f":33},{"t":362751,"n":"StreamAborted","d":362751,"h":17180231935,"f":33},{"t":362751,"n":"ConnectionTimeout","d":362751,"h":21475199231,"f":33},{"t":362751,"n":"ConnectionRefused","d":362751,"h":25770166527,"f":33},{"t":362751,"n":"VersionNegotiationError","d":362751,"h":30065133823,"f":33},{"t":362751,"n":"ConnectionIdle","d":362751,"h":34360101119,"f":33},{"t":362751,"n":"OperationAborted","d":362751,"h":38655068415,"f":33},{"t":362751,"n":"AlpnInUse","d":362751,"h":42950035711,"f":33},{"t":362751,"n":"TransportError","d":362751,"h":47245003007,"f":33},{"t":362751,"n":"CallbackError","d":362751,"h":51539970303,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":362751,"h":55834937599,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":362751}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Quic.QuicError`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicStreamType", ($self) => class QuicStreamType extends $.$spc.System.Enum
        {
            static Unidirectional = 0;
            static Bidirectional = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unidirectional": 0n,
                    "Bidirectional": 1n
                };
            }
            static $h = 887039;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":887039,"n":"Unidirectional","d":887039,"h":4295854335,"f":33},{"t":887039,"n":"Bidirectional","d":887039,"h":8590821631,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":887039,"h":12885788927,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":887039}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Quic.QuicStreamType`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicException", ($self) => class QuicException extends $.$spc.System.IO.IOException
        {
            $ctor$14(/*System.Net.Quic.QuicError*/ error, /*long?*/ applicationErrorCode, /*string*/ message)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            /*long? */ get ApplicationErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicError */ get QuicError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long? */ get TransportErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 428287;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":60686337,"h":428287}; }
            static get $b() { return $.$spc.System.IO.IOException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Quic.QuicException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.Numerics", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Channels", "NetJs.System.Console", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Net.NameResolution", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security"))