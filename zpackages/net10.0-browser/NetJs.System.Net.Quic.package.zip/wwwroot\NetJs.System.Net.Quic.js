
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $srn, $ssc, $sris, $stc, $scsl, $sfa, $sic, $sim, $sl, $snp, $sspw, $sci, $sdd, $srm, $snnr, $sds, $sns, $sscr, $snsc) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Quic", 
    {"h":40463,"f":"System.Net.Quic","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Quic","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Quic","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snq.System.Net.Quic.QuicConnectionOptions", ($self) => class QuicConnectionOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*long */ get DefaultCloseErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set DefaultCloseErrorCode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get DefaultStreamErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set DefaultStreamErrorCode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get HandshakeTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set HandshakeTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get IdleTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set IdleTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicReceiveWindowSizes */ get InitialReceiveWindowSizes()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicReceiveWindowSizes */ set InitialReceiveWindowSizes(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ get KeepAliveInterval()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.TimeSpan */ set KeepAliveInterval(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get MaxInboundBidirectionalStreams()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set MaxInboundBidirectionalStreams(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get MaxInboundUnidirectionalStreams()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set MaxInboundUnidirectionalStreams(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Action<System.Net.Quic.QuicConnection, System.Net.Quic.QuicStreamCapacityChangedArgs>? */ get StreamCapacityCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Action<System.Net.Quic.QuicConnection, System.Net.Quic.QuicStreamCapacityChangedArgs>? */ set StreamCapacityCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 302607;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":917505,"g":{"r":0,"d":0,"h":12885204495,"f":1},"s":{"r":0,"d":0,"h":17180171791,"f":1},"n":"DefaultCloseErrorCode","d":302607,"h":8590237199,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":25770106383,"f":1},"s":{"r":0,"d":0,"h":30065073679,"f":1},"n":"DefaultStreamErrorCode","d":302607,"h":21475139087,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":38655008271,"f":1},"s":{"r":0,"d":0,"h":42949975567,"f":1},"n":"HandshakeTimeout","d":302607,"h":34360040975,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":51539910159,"f":1},"s":{"r":0,"d":0,"h":55834877455,"f":1},"n":"IdleTimeout","d":302607,"h":47244942863,"f":1},{"p":630287,"g":{"r":0,"d":0,"h":64424812047,"f":1},"s":{"r":0,"d":0,"h":68719779343,"f":1},"n":"InitialReceiveWindowSizes","d":302607,"h":60129844751,"f":1},{"p":140705793,"g":{"r":0,"d":0,"h":77309713935,"f":1},"s":{"r":0,"d":0,"h":81604681231,"f":1},"n":"KeepAliveInterval","d":302607,"h":73014746639,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":90194615823,"f":1},"s":{"r":0,"d":0,"h":94489583119,"f":1},"n":"MaxInboundBidirectionalStreams","d":302607,"h":85899648527,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":103079517711,"f":1},"s":{"r":0,"d":0,"h":107374485007,"f":1},"n":"MaxInboundUnidirectionalStreams","d":302607,"h":98784550415,"f":1},{"p":$.$spc.System.Action$$$($.$snq.System.Net.Quic.QuicConnection, $.$snq.System.Net.Quic.QuicStreamCapacityChangedArgs).$h,"g":{"r":0,"d":0,"h":115964419599,"f":1},"s":{"r":0,"d":0,"h":120259386895,"f":1},"n":"StreamCapacityCallback","d":302607,"h":111669452303,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":302607,"h":4295269903,"f":8}],"h":302607}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Quic.QuicConnectionOptions`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicListenerOptions", ($self) => class QuicListenerOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol> */ get ApplicationProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol> */ set ApplicationProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Func<System.Net.Quic.QuicConnection, System.Net.Security.SslClientHelloInfo, System.Threading.CancellationToken, System.Threading.Tasks.ValueTask<System.Net.Quic.QuicServerConnectionOptions>> */ get ConnectionOptionsCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Func<System.Net.Quic.QuicConnection, System.Net.Security.SslClientHelloInfo, System.Threading.CancellationToken, System.Threading.Tasks.ValueTask<System.Net.Quic.QuicServerConnectionOptions>> */ set ConnectionOptionsCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ListenBacklog()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ListenBacklog(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get ListenEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ set ListenEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 564751;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":12885466639,"f":1},"s":{"r":0,"d":0,"h":17180433935,"f":1},"n":"ApplicationProtocols","d":564751,"h":8590499343,"f":1},{"p":$.$spc.System.Func$$$$$($.$snq.System.Net.Quic.QuicConnection, $.$snsc.System.Net.Security.SslClientHelloInfo, $.$spc.System.Threading.CancellationToken, $.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicServerConnectionOptions)).$h,"g":{"r":0,"d":0,"h":25770368527,"f":1},"s":{"r":0,"d":0,"h":30065335823,"f":1},"n":"ConnectionOptionsCallback","d":564751,"h":21475401231,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38655270415,"f":1},"s":{"r":0,"d":0,"h":42950237711,"f":1},"n":"ListenBacklog","d":564751,"h":34360303119,"f":1},{"p":3317723,"g":{"r":0,"d":0,"h":51540172303,"f":1},"s":{"r":0,"d":0,"h":55835139599,"f":1},"n":"ListenEndPoint","d":564751,"h":47245205007,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":564751,"h":4295532047,"f":1}],"h":564751}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Quic.QuicListenerOptions`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicReceiveWindowSizes", ($self) => class QuicReceiveWindowSizes extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*int */ get Connection()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set Connection(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get LocallyInitiatedBidirectionalStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set LocallyInitiatedBidirectionalStream(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get RemotelyInitiatedBidirectionalStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set RemotelyInitiatedBidirectionalStream(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get UnidirectionalStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set UnidirectionalStream(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 630287;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":655361,"g":{"r":0,"d":0,"h":12885532175,"f":1},"s":{"r":0,"d":0,"h":17180499471,"f":1},"n":"Connection","d":630287,"h":8590564879,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":25770434063,"f":1},"s":{"r":0,"d":0,"h":30065401359,"f":1},"n":"LocallyInitiatedBidirectionalStream","d":630287,"h":21475466767,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":38655335951,"f":1},"s":{"r":0,"d":0,"h":42950303247,"f":1},"n":"RemotelyInitiatedBidirectionalStream","d":630287,"h":34360368655,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":51540237839,"f":1},"s":{"r":0,"d":0,"h":55835205135,"f":1},"n":"UnidirectionalStream","d":630287,"h":47245270543,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":630287,"h":4295597583,"f":1}],"h":630287}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Quic.QuicReceiveWindowSizes`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicConnection", ($self) => class QuicConnection extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ get IsSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslApplicationProtocol */ get NegotiatedApplicationProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.TlsCipherSuite */ get NegotiatedCipherSuite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get RemoteCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get TargetHostName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicStream> */ AcceptInboundStreamAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ CloseAsync(/*long*/ errorCode, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicConnection> */ ConnectAsync(/*System.Net.Quic.QuicClientConnectionOptions*/ options, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicStream> */ OpenOutboundStreamAsync(/*System.Net.Quic.QuicStreamType*/ type, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snq.System.Net.Quic.QuicConnection.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            static $h = 237071;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885138959,"f":33},"n":"IsSupported","d":237071,"h":8590171663,"f":33,"a":[{"t":115015681,"c":4409982977,"a":[{"v":"windows","t":1310721}]},{"t":115015681,"c":4409982977,"a":[{"v":"linux","t":1310721}]},{"t":115015681,"c":4409982977,"a":[{"v":"osx","t":1310721}]}]},{"p":3317723,"g":{"r":0,"d":0,"h":21475073551,"f":1},"n":"LocalEndPoint","d":237071,"h":17180106255,"f":1},{"p":978150,"g":{"r":0,"d":0,"h":30065008143,"f":1},"n":"NegotiatedApplicationProtocol","d":237071,"h":25770040847,"f":1},{"p":1436902,"g":{"r":0,"d":0,"h":38654942735,"f":1},"n":"NegotiatedCipherSuite","d":237071,"h":34359975439,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"p":5611483,"g":{"r":0,"d":0,"h":47244877327,"f":1},"n":"SslProtocol","d":237071,"h":42949910031,"f":1},{"p":28172903,"g":{"r":0,"d":0,"h":55834811919,"f":1},"n":"RemoteCertificate","d":237071,"h":51539844623,"f":1},{"p":3317723,"g":{"r":0,"d":0,"h":64424746511,"f":1},"n":"RemoteEndPoint","d":237071,"h":60129779215,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":73014681103,"f":1},"n":"TargetHostName","d":237071,"h":68719713807,"f":1}],"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicStream).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"AcceptInboundStreamAsync","d":237071,"h":77309648399,"f":1},{"r":136118273,"p":[{"n":"errorCode","p":917505},{"n":"cancellationToken","p":125960193,"f":65}],"n":"CloseAsync","d":237071,"h":81604615695,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicConnection).$h,"p":[{"n":"options","p":171535},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ConnectAsync","d":237071,"h":85899582991,"f":33},{"r":136118273,"n":"DisposeAsync","d":237071,"h":90194550287,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicStream).$h,"p":[{"n":"type","p":892431},{"n":"cancellationToken","p":125960193,"f":65}],"n":"OpenOutboundStreamAsync","d":237071,"h":94489517583,"f":1},{"r":1310721,"n":"ToString","d":237071,"h":98784484879,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":237071,"h":4295204367,"f":8}],"i":[56885249],"h":237071}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Quic.QuicConnection`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicListener", ($self) => class QuicListener extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*bool */ get IsSupported()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicConnection> */ AcceptConnectionAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<System.Net.Quic.QuicListener> */ ListenAsync(/*System.Net.Quic.QuicListenerOptions*/ options, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snq.System.Net.Quic.QuicListener.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IAsyncDisposable.DisposeAsync()
            System$IAsyncDisposable$DisposeAsync()
            {
                return this.DisposeAsync(...arguments);
            }
            static $h = 499215;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885401103,"f":33},"n":"IsSupported","d":499215,"h":8590433807,"f":33,"a":[{"t":115015681,"c":4409982977,"a":[{"v":"windows","t":1310721}]},{"t":115015681,"c":4409982977,"a":[{"v":"linux","t":1310721}]},{"t":115015681,"c":4409982977,"a":[{"v":"osx","t":1310721}]}]},{"p":3317723,"g":{"r":0,"d":0,"h":21475335695,"f":1},"n":"LocalEndPoint","d":499215,"h":17180368399,"f":1}],"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicConnection).$h,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"AcceptConnectionAsync","d":499215,"h":25770302991,"f":1},{"r":136118273,"n":"DisposeAsync","d":499215,"h":30065270287,"f":1},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snq.System.Net.Quic.QuicListener).$h,"p":[{"n":"options","p":564751},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ListenAsync","d":499215,"h":34360237583,"f":33},{"r":1310721,"n":"ToString","d":499215,"h":38655204879,"f":32769}],"c":[{"n":".ctor","o":"$ctor$1","d":499215,"h":4295466511,"f":8}],"i":[56885249],"h":499215}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Quic.QuicListener`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicClientConnectionOptions", ($self) => class QuicClientConnectionOptions extends $.$snq.System.Net.Quic.QuicConnectionOptions
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Security.SslClientAuthenticationOptions */ get ClientAuthenticationOptions()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslClientAuthenticationOptions */ set ClientAuthenticationOptions(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint? */ get LocalEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint? */ set LocalEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ get RemoteEndPoint()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ set RemoteEndPoint(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 171535;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":302607,"p":[{"p":1109222,"g":{"r":0,"d":0,"h":12885073423,"f":1},"s":{"r":0,"d":0,"h":17180040719,"f":1},"n":"ClientAuthenticationOptions","d":171535,"h":8590106127,"f":1},{"p":3317723,"g":{"r":0,"d":0,"h":25769975311,"f":1},"s":{"r":0,"d":0,"h":30064942607,"f":1},"n":"LocalEndPoint","d":171535,"h":21475008015,"f":1},{"p":2596827,"g":{"r":0,"d":0,"h":38654877199,"f":1},"s":{"r":0,"d":0,"h":42949844495,"f":1},"n":"RemoteEndPoint","d":171535,"h":34359909903,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":171535,"h":4295138831,"f":1}],"h":171535}; }
            static get $b() { return $.$snq.System.Net.Quic.QuicConnectionOptions; }
            static get $fullName() { return `System.Net.Quic.QuicClientConnectionOptions`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicServerConnectionOptions", ($self) => class QuicServerConnectionOptions extends $.$snq.System.Net.Quic.QuicConnectionOptions
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Security.SslServerAuthenticationOptions */ get ServerAuthenticationOptions()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslServerAuthenticationOptions */ set ServerAuthenticationOptions(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 695823;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":302607,"p":[{"p":1240294,"g":{"r":0,"d":0,"h":12885597711,"f":1},"s":{"r":0,"d":0,"h":17180565007,"f":1},"n":"ServerAuthenticationOptions","d":695823,"h":8590630415,"f":1}],"c":[{"n":".ctor","o":"$ctor$2","d":695823,"h":4295663119,"f":1}],"h":695823}; }
            static get $b() { return $.$snq.System.Net.Quic.QuicConnectionOptions; }
            static get $fullName() { return `System.Net.Quic.QuicServerConnectionOptions`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicStreamCapacityChangedArgs", ($self) => class QuicStreamCapacityChangedArgs extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*int */ get BidirectionalIncrement()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set BidirectionalIncrement(value)
            {
            }
            /*int */ get UnidirectionalIncrement()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set UnidirectionalIncrement(value)
            {
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 826895;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":655361,"g":{"r":0,"d":0,"h":17180696079,"f":1},"s":{"r":0,"d":0,"h":21475663375,"f":1},"n":"BidirectionalIncrement","d":826895,"h":12885728783,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":30065597967,"f":1},"s":{"r":0,"d":0,"h":34360565263,"f":1},"n":"UnidirectionalIncrement","d":826895,"h":25770630671,"f":1}],"l":[{"t":131073,"n":"_dummy","d":826895,"h":4295794191,"f":2},{"t":655361,"n":"_dummyPrimitive","d":826895,"h":8590761487,"f":2}],"c":[{"n":".ctor","o":"$ctor$2","d":826895,"h":38655532559,"f":1}],"h":826895}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Quic.QuicStreamCapacityChangedArgs`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicStream", ($self) => class QuicStream extends $.$spc.System.IO.Stream
        {
            $ctor$3()
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Id()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ get ReadsClosed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicStreamType */ get Type()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ get WritesClosed()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Abort(/*System.Net.Quic.QuicAbortDirection*/ abortDirection, /*long*/ errorCode)
            {
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ CompleteWrites()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snq.System.Net.Quic.QuicStream.ToString.apply(this, arguments); }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$3(/*System.ReadOnlyMemory<byte>*/ buffer, /*bool*/ completeWrites, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            static $h = 761359;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885663247,"f":32769},"n":"CanRead","d":761359,"h":8590695951,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":21475597839,"f":32769},"n":"CanSeek","d":761359,"h":17180630543,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":30065532431,"f":32769},"n":"CanTimeout","d":761359,"h":25770565135,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38655467023,"f":32769},"n":"CanWrite","d":761359,"h":34360499727,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":47245401615,"f":1},"n":"Id","d":761359,"h":42950434319,"f":1},{"p":917505,"g":{"r":0,"d":0,"h":55835336207,"f":32769},"n":"Length","d":761359,"h":51540368911,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":64425270799,"f":32769},"s":{"r":0,"d":0,"h":68720238095,"f":32769},"n":"Position","d":761359,"h":60130303503,"f":32769},{"p":133300225,"g":{"r":0,"d":0,"h":77310172687,"f":1},"n":"ReadsClosed","d":761359,"h":73015205391,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":85900107279,"f":32769},"s":{"r":0,"d":0,"h":90195074575,"f":32769},"n":"ReadTimeout","d":761359,"h":81605139983,"f":32769},{"p":892431,"g":{"r":0,"d":0,"h":98785009167,"f":1},"n":"Type","d":761359,"h":94490041871,"f":1},{"p":133300225,"g":{"r":0,"d":0,"h":107374943759,"f":1},"n":"WritesClosed","d":761359,"h":103079976463,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":115964878351,"f":32769},"s":{"r":0,"d":0,"h":120259845647,"f":32769},"n":"WriteTimeout","d":761359,"h":111669911055,"f":32769}],"m":[{"r":65537,"p":[{"n":"abortDirection","p":105999},{"n":"errorCode","p":917505}],"n":"Abort","d":761359,"h":124554812943,"f":1},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginRead","d":761359,"h":128849780239,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14417921},{"n":"state","p":131073}],"n":"BeginWrite","d":761359,"h":133144747535,"f":32769},{"r":65537,"n":"CompleteWrites","d":761359,"h":137439714831,"f":1},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":761359,"h":141734682127,"f":32772},{"r":136118273,"n":"DisposeAsync","d":761359,"h":146029649423,"f":32769},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":761359,"h":150324616719,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":761359,"h":154619584015,"f":32769},{"r":65537,"n":"Flush","d":761359,"h":158914551311,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"FlushAsync","o":"@$1","d":761359,"h":163209518607,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":761359,"h":167504485903,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":761359,"h":171799453199,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$1","d":761359,"h":176094420495,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":761359,"h":180389387791,"f":32769},{"r":655361,"n":"ReadByte","d":761359,"h":184684355087,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":761359,"h":188979322383,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":761359,"h":193274289679,"f":32769},{"r":1310721,"n":"ToString","d":761359,"h":197569256975,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":761359,"h":201864224271,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":761359,"h":206159191567,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$1","d":761359,"h":210454158863,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"completeWrites","p":262145},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$3","d":761359,"h":214749126159,"f":1},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":761359,"h":219044093455,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":761359,"h":223339060751,"f":32769}],"c":[{"n":".ctor","o":"$ctor$3","d":761359,"h":4295728655,"f":8}],"i":[57475073,56885249],"h":761359}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Quic.QuicStream`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicAbortDirection", ($self) => class QuicAbortDirection extends $.$spc.System.Enum
        {
            static Read = 1;
            static Write = 2;
            static Both = 3;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Read": 1n,
                    "Write": 2n,
                    "Both": 3n
                };
            }
            static $h = 105999;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":105999,"n":"Read","d":105999,"h":4295073295,"f":33},{"t":105999,"n":"Write","d":105999,"h":8590040591,"f":33},{"t":105999,"n":"Both","d":105999,"h":12885007887,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":105999,"h":17179975183,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":105999,"a":[{"t":47644673,"c":4342611969}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Quic.QuicAbortDirection`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicError", ($self) => class QuicError extends $.$spc.System.Enum
        {
            static Success = 0;
            static InternalError = 1;
            static ConnectionAborted = 2;
            static StreamAborted = 3;
            static ConnectionTimeout = 6;
            static ConnectionRefused = 8;
            static VersionNegotiationError = 9;
            static ConnectionIdle = 10;
            static OperationAborted = 12;
            static AlpnInUse = 13;
            static TransportError = 14;
            static CallbackError = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Success": 0n,
                    "InternalError": 1n,
                    "ConnectionAborted": 2n,
                    "StreamAborted": 3n,
                    "ConnectionTimeout": 6n,
                    "ConnectionRefused": 8n,
                    "VersionNegotiationError": 9n,
                    "ConnectionIdle": 10n,
                    "OperationAborted": 12n,
                    "AlpnInUse": 13n,
                    "TransportError": 14n,
                    "CallbackError": 15n
                };
            }
            static $h = 368143;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":368143,"n":"Success","d":368143,"h":4295335439,"f":33},{"t":368143,"n":"InternalError","d":368143,"h":8590302735,"f":33},{"t":368143,"n":"ConnectionAborted","d":368143,"h":12885270031,"f":33},{"t":368143,"n":"StreamAborted","d":368143,"h":17180237327,"f":33},{"t":368143,"n":"ConnectionTimeout","d":368143,"h":21475204623,"f":33},{"t":368143,"n":"ConnectionRefused","d":368143,"h":25770171919,"f":33},{"t":368143,"n":"VersionNegotiationError","d":368143,"h":30065139215,"f":33},{"t":368143,"n":"ConnectionIdle","d":368143,"h":34360106511,"f":33},{"t":368143,"n":"OperationAborted","d":368143,"h":38655073807,"f":33},{"t":368143,"n":"AlpnInUse","d":368143,"h":42950041103,"f":33},{"t":368143,"n":"TransportError","d":368143,"h":47245008399,"f":33},{"t":368143,"n":"CallbackError","d":368143,"h":51539975695,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":368143,"h":55834942991,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":368143}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Quic.QuicError`; }
        });
        
        $asm.$str("$snq.System.Net.Quic.QuicStreamType", ($self) => class QuicStreamType extends $.$spc.System.Enum
        {
            static Unidirectional = 0;
            static Bidirectional = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unidirectional": 0n,
                    "Bidirectional": 1n
                };
            }
            static $h = 892431;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":892431,"n":"Unidirectional","d":892431,"h":4295859727,"f":33},{"t":892431,"n":"Bidirectional","d":892431,"h":8590827023,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":892431,"h":12885794319,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":892431}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Quic.QuicStreamType`; }
        });
        
        $asm.$cls("$snq.System.Net.Quic.QuicException", ($self) => class QuicException extends $.$spc.System.IO.IOException
        {
            $ctor$14(/*System.Net.Quic.QuicError*/ error, /*long?*/ applicationErrorCode, /*string*/ message)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            /*long? */ get ApplicationErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Quic.QuicError */ get QuicError()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long? */ get TransportErrorCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 433679;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":60686337,"h":433679}; }
            static get $b() { return $.$spc.System.IO.IOException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Quic.QuicException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.Numerics", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Threading.Channels", "NetJs.System.Console", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Net.NameResolution", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security"))