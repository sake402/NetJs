
//--TRIMMABLE-BOUNDARY-START(107)
(async function () {
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sl, $sci, $scn, $scm, $so, $scp, $scs, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $sicb, $snp, $ssc, $sspw, $sto, $snnr, $sns, $snn, $sscr, $snsc, $stc, $snq, $srij, $snh, $snwh) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.Net.Requests", 
    {
  "h": 107,
  "f": "System.Net.Requests",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 134545409,
      "c": 8724480001,
      "a": [
        {
          "v": 589930,
          "t": 188547073
        }
      ]
    },
    {
      "t": 134545409,
      "c": 8724480001,
      "a": [
        {
          "v": 262250,
          "t": 188547073
        }
      ]
    },
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Net.Requests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Net.Requests",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(1048683)
        $asm.$cls(`$snr.SN.IAuthenticationModule`, ($self) => class IAuthenticationModule
        {
            static $h = 1048683;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590983275),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475885163,
        "f": 50331905
      },
      "n": "AuthenticationType",
      "o": "SN$IAuthenticationModule$AuthenticationType",
      "d": 1048683,
      "h": 8590983275,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(8590983275),
//--TRIMMABLE-BOUNDARY-START(12885950571),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065819755,
        "f": 50331905
      },
      "n": "CanPreAuthenticate",
      "o": "SN$IAuthenticationModule$CanPreAuthenticate",
      "d": 1048683,
      "h": 12885950571,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(12885950571)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296015979),
    {
      "r": 131179,
      "p": [
        {
          "n": "challenge",
          "p": 1310721
        },
        {
          "n": "request",
          "p": 1638507
        },
        {
          "n": "credentials",
          "p": 2883631
        }
      ],
      "n": "Authenticate",
      "o": "SN$IAuthenticationModule$Authenticate",
      "d": 1048683,
      "h": 4296015979,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296015979),
//--TRIMMABLE-BOUNDARY-START(34360787051),
    {
      "r": 131179,
      "p": [
        {
          "n": "request",
          "p": 1638507
        },
        {
          "n": "credentials",
          "p": 2883631
        }
      ],
      "n": "PreAuthenticate",
      "o": "SN$IAuthenticationModule$PreAuthenticate",
      "d": 1048683,
      "h": 34360787051,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(34360787051)
  ],
  "h": 1048683
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.IAuthenticationModule`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}IAuthenticationModule`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048683)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114219)
        $asm.$cls(`$snr.SN.ICredentialPolicy`, ($self) => class ICredentialPolicy
        {
            static $h = 1114219;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296081515),
    {
      "r": 262145,
      "p": [
        {
          "n": "challengeUri",
          "p": 1703938
        },
        {
          "n": "request",
          "p": 1638507
        },
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "authenticationModule",
          "p": 1048683
        }
      ],
      "n": "ShouldSendCredential",
      "o": "SN$ICredentialPolicy$ShouldSendCredential",
      "d": 1114219,
      "h": 4296081515,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296081515)
  ],
  "h": 1114219
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.ICredentialPolicy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}ICredentialPolicy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114219)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179755)
        $asm.$cls(`$snr.SN.IWebRequestCreate`, ($self) => class IWebRequestCreate
        {
            static $h = 1179755;
            static $f = 0b100101;
            static $k = 3;
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(4296147051),
    {
      "r": 1638507,
      "p": [
        {
          "n": "uri",
          "p": 1703938
        }
      ],
      "n": "Create",
      "o": "SN$IWebRequestCreate$Create",
      "d": 1179755,
      "h": 4296147051,
      "f": 16777473
    },
//--TRIMMABLE-BOUNDARY-END(4296147051)
  ],
  "h": 1179755
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.IWebRequestCreate`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}IWebRequestCreate`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179755)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638507)
        $asm.$cls(`$snr.SN.WebRequest`, ($self) => class WebRequest extends $.$$.S.MarshalByRefObject
        {
            //--TRIMMABLE-BOUNDARY-START(4296605803)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296605803);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605803)
            
            //--TRIMMABLE-BOUNDARY-START(8591573099)
            $ctor$3(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591573099);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591573099)
            
            //--TRIMMABLE-BOUNDARY-START(17181507691)
            /*System.Net.Security.AuthenticationLevel */ get AuthenticationLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490919019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.AuthenticationLevel */ set AuthenticationLevel(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287764447339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17181507691)
            
            //--TRIMMABLE-BOUNDARY-START(30066409579)
            /*System.Net.Cache.RequestCachePolicy? */ get CachePolicy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080853611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Cache.RequestCachePolicy? */ set CachePolicy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296354381931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30066409579)
            
            //--TRIMMABLE-BOUNDARY-START(34361376875)
            /*string? */ get ConnectionGroupName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670788203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set ConnectionGroupName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304944316523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34361376875)
            
            //--TRIMMABLE-BOUNDARY-START(38656344171)
            /*long */ get ContentLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260722795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set ContentLength(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313534251115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38656344171)
            
            //--TRIMMABLE-BOUNDARY-START(42951311467)
            /*string? */ get ContentType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850657387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set ContentType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322124185707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42951311467)
            
            //--TRIMMABLE-BOUNDARY-START(68721115243)
            /*System.Net.ICredentials? */ get Credentials()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440591979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.ICredentials? */ set Credentials(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330714120299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68721115243)
            
            //--TRIMMABLE-BOUNDARY-START(73016082539)
            static /*System.Net.Cache.RequestCachePolicy? */ get DefaultCachePolicy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030526571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Cache.RequestCachePolicy? */ set DefaultCachePolicy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339304054891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73016082539)
            
            //--TRIMMABLE-BOUNDARY-START(77311049835)
            static /*System.Net.IWebProxy? */ get DefaultWebProxy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620461163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IWebProxy? */ set DefaultWebProxy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347893989483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77311049835)
            
            //--TRIMMABLE-BOUNDARY-START(253404708971)
            /*System.Net.WebHeaderCollection */ get Headers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210395755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.WebHeaderCollection */ set Headers(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483924075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(253404708971)
            
            //--TRIMMABLE-BOUNDARY-START(257699676267)
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171800330347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set ImpersonationLevel(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365073858667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(257699676267)
            
            //--TRIMMABLE-BOUNDARY-START(261994643563)
            /*string */ get Method()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180390264939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Method(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373663793259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(261994643563)
            
            //--TRIMMABLE-BOUNDARY-START(266289610859)
            /*bool */ get PreAuthenticate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188980199531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PreAuthenticate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382253727851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(266289610859)
            
            //--TRIMMABLE-BOUNDARY-START(270584578155)
            /*System.Net.IWebProxy? */ get Proxy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197570134123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IWebProxy? */ set Proxy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390843662443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(270584578155)
            
            //--TRIMMABLE-BOUNDARY-START(279174512747)
            /*System.Uri */ get RequestUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206160068715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(279174512747)
            
            //--TRIMMABLE-BOUNDARY-START(416613466219)
            /*int */ get Timeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214750003307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set Timeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399433597035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(416613466219)
            
            //--TRIMMABLE-BOUNDARY-START(420908433515)
            /*bool */ get UseDefaultCredentials()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339937899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseDefaultCredentials(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408023531627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(420908433515)
            
            //--TRIMMABLE-BOUNDARY-START(12886540395)
            /*void */ Abort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886540395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12886540395)
            
            //--TRIMMABLE-BOUNDARY-START(21476474987)
            /*System.IAsyncResult */ BeginGetRequestStream(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476474987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21476474987)
            
            //--TRIMMABLE-BOUNDARY-START(25771442283)
            /*System.IAsyncResult */ BeginGetResponse(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771442283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25771442283)
            
            //--TRIMMABLE-BOUNDARY-START(47246278763)
            static /*System.Net.WebRequest */ Create(/*string*/ requestUriString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246278763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47246278763)
            
            //--TRIMMABLE-BOUNDARY-START(51541246059)
            static /*System.Net.WebRequest */ Create$1(/*System.Uri*/ requestUri)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541246059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51541246059)
            
            //--TRIMMABLE-BOUNDARY-START(55836213355)
            static /*System.Net.WebRequest */ CreateDefault(/*System.Uri*/ requestUri)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836213355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55836213355)
            
            //--TRIMMABLE-BOUNDARY-START(60131180651)
            static /*System.Net.HttpWebRequest */ CreateHttp(/*string*/ requestUriString)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131180651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60131180651)
            
            //--TRIMMABLE-BOUNDARY-START(64426147947)
            static /*System.Net.HttpWebRequest */ CreateHttp$1(/*System.Uri*/ requestUri)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426147947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64426147947)
            
            //--TRIMMABLE-BOUNDARY-START(81606017131)
            /*System.IO.Stream */ EndGetRequestStream(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606017131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81606017131)
            
            //--TRIMMABLE-BOUNDARY-START(85900984427)
            /*System.Net.WebResponse */ EndGetResponse(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900984427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(85900984427)
            
            //--TRIMMABLE-BOUNDARY-START(227634905195)
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634905195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(227634905195)
            
            //--TRIMMABLE-BOUNDARY-START(231929872491)
            /*System.IO.Stream */ GetRequestStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929872491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(231929872491)
            
            //--TRIMMABLE-BOUNDARY-START(236224839787)
            /*System.Threading.Tasks.Task<System.IO.Stream> */ GetRequestStreamAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224839787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(236224839787)
            
            //--TRIMMABLE-BOUNDARY-START(240519807083)
            /*System.Net.WebResponse */ GetResponse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519807083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(240519807083)
            
            //--TRIMMABLE-BOUNDARY-START(244814774379)
            /*System.Threading.Tasks.Task<System.Net.WebResponse> */ GetResponseAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814774379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(244814774379)
            
            //--TRIMMABLE-BOUNDARY-START(249109741675)
            static /*System.Net.IWebProxy */ GetSystemWebProxy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109741675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(249109741675)
            
            //--TRIMMABLE-BOUNDARY-START(274879545451)
            static /*bool */ RegisterPrefix(/*string*/ prefix, /*System.Net.IWebRequestCreate*/ creator)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879545451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(274879545451)
            
            //--TRIMMABLE-BOUNDARY-START(412318498923)
            /*void */ SRS$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412318498923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(412318498923)
            
            //--TRIMMABLE-BOUNDARY-START(4296605803)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296605803)
            
            static $h = 1638507;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MarshalByRefObject; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181507691),
    {
      "p": 4194351,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490919019,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287764447339,
        "f": 83886081
      },
      "n": "AuthenticationLevel",
      "d": 1638507,
      "h": 17181507691,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181507691),
//--TRIMMABLE-BOUNDARY-START(30066409579),
    {
      "p": 1048623,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080853611,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296354381931,
        "f": 83886209
      },
      "n": "CachePolicy",
      "d": 1638507,
      "h": 30066409579,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(30066409579),
//--TRIMMABLE-BOUNDARY-START(34361376875),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670788203,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304944316523,
        "f": 83886209
      },
      "n": "ConnectionGroupName",
      "d": 1638507,
      "h": 34361376875,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(34361376875),
//--TRIMMABLE-BOUNDARY-START(38656344171),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260722795,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313534251115,
        "f": 83886209
      },
      "n": "ContentLength",
      "d": 1638507,
      "h": 38656344171,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(38656344171),
//--TRIMMABLE-BOUNDARY-START(42951311467),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850657387,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322124185707,
        "f": 83886209
      },
      "n": "ContentType",
      "d": 1638507,
      "h": 42951311467,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(42951311467),
//--TRIMMABLE-BOUNDARY-START(68721115243),
    {
      "p": 2883631,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440591979,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330714120299,
        "f": 83886209
      },
      "n": "Credentials",
      "d": 1638507,
      "h": 68721115243,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(68721115243),
//--TRIMMABLE-BOUNDARY-START(73016082539),
    {
      "p": 1048623,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030526571,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339304054891,
        "f": 83886113
      },
      "n": "DefaultCachePolicy",
      "d": 1638507,
      "h": 73016082539,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(73016082539),
//--TRIMMABLE-BOUNDARY-START(77311049835),
    {
      "p": 3538991,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154620461163,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347893989483,
        "f": 83886113
      },
      "n": "DefaultWebProxy",
      "d": 1638507,
      "h": 77311049835,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(77311049835),
//--TRIMMABLE-BOUNDARY-START(253404708971),
    {
      "p": 589930,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163210395755,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 356483924075,
        "f": 83886209
      },
      "n": "Headers",
      "d": 1638507,
      "h": 253404708971,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(253404708971),
//--TRIMMABLE-BOUNDARY-START(257699676267),
    {
      "p": 162136065,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171800330347,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 365073858667,
        "f": 83886081
      },
      "n": "ImpersonationLevel",
      "d": 1638507,
      "h": 257699676267,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257699676267),
//--TRIMMABLE-BOUNDARY-START(261994643563),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180390264939,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 373663793259,
        "f": 83886209
      },
      "n": "Method",
      "d": 1638507,
      "h": 261994643563,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(261994643563),
//--TRIMMABLE-BOUNDARY-START(266289610859),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188980199531,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 382253727851,
        "f": 83886209
      },
      "n": "PreAuthenticate",
      "d": 1638507,
      "h": 266289610859,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(266289610859),
//--TRIMMABLE-BOUNDARY-START(270584578155),
    {
      "p": 3538991,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197570134123,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 390843662443,
        "f": 83886209
      },
      "n": "Proxy",
      "d": 1638507,
      "h": 270584578155,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(270584578155),
//--TRIMMABLE-BOUNDARY-START(279174512747),
    {
      "p": 1703938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206160068715,
        "f": 50331777
      },
      "n": "RequestUri",
      "d": 1638507,
      "h": 279174512747,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(279174512747),
//--TRIMMABLE-BOUNDARY-START(416613466219),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214750003307,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 399433597035,
        "f": 83886209
      },
      "n": "Timeout",
      "d": 1638507,
      "h": 416613466219,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(416613466219),
//--TRIMMABLE-BOUNDARY-START(420908433515),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223339937899,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 408023531627,
        "f": 83886209
      },
      "n": "UseDefaultCredentials",
      "d": 1638507,
      "h": 420908433515,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(420908433515)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886540395),
    {
      "r": 65537,
      "n": "Abort",
      "d": 1638507,
      "h": 12886540395,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886540395),
//--TRIMMABLE-BOUNDARY-START(21476474987),
    {
      "r": 90570753,
      "p": [
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginGetRequestStream",
      "d": 1638507,
      "h": 21476474987,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21476474987),
//--TRIMMABLE-BOUNDARY-START(25771442283),
    {
      "r": 90570753,
      "p": [
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginGetResponse",
      "d": 1638507,
      "h": 25771442283,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25771442283),
//--TRIMMABLE-BOUNDARY-START(47246278763),
    {
      "r": 1638507,
      "p": [
        {
          "n": "requestUriString",
          "p": 1310721
        }
      ],
      "n": "Create",
      "d": 1638507,
      "h": 47246278763,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0014",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(47246278763),
//--TRIMMABLE-BOUNDARY-START(51541246059),
    {
      "r": 1638507,
      "p": [
        {
          "n": "requestUri",
          "p": 1703938
        }
      ],
      "n": "Create",
      "o": "@$1",
      "d": 1638507,
      "h": 51541246059,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0014",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(51541246059),
//--TRIMMABLE-BOUNDARY-START(55836213355),
    {
      "r": 1638507,
      "p": [
        {
          "n": "requestUri",
          "p": 1703938
        }
      ],
      "n": "CreateDefault",
      "d": 1638507,
      "h": 55836213355,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0014",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(55836213355),
//--TRIMMABLE-BOUNDARY-START(60131180651),
    {
      "r": 917611,
      "p": [
        {
          "n": "requestUriString",
          "p": 1310721
        }
      ],
      "n": "CreateHttp",
      "d": 1638507,
      "h": 60131180651,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0014",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(60131180651),
//--TRIMMABLE-BOUNDARY-START(64426147947),
    {
      "r": 917611,
      "p": [
        {
          "n": "requestUri",
          "p": 1703938
        }
      ],
      "n": "CreateHttp",
      "o": "@$1",
      "d": 1638507,
      "h": 64426147947,
      "f": 16777249,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0014",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64426147947),
//--TRIMMABLE-BOUNDARY-START(81606017131),
    {
      "r": 95748097,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndGetRequestStream",
      "d": 1638507,
      "h": 81606017131,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(81606017131),
//--TRIMMABLE-BOUNDARY-START(85900984427),
    {
      "r": 1966187,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndGetResponse",
      "d": 1638507,
      "h": 85900984427,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(85900984427),
//--TRIMMABLE-BOUNDARY-START(227634905195),
    {
      "r": 65537,
      "p": [
        {
          "n": "serializationInfo",
          "p": 158859265
        },
        {
          "n": "streamingContext",
          "p": 158990337
        }
      ],
      "n": "GetObjectData",
      "d": 1638507,
      "h": 227634905195,
      "f": 16777348,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "Serialization has been deprecated for WebRequest.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(227634905195),
//--TRIMMABLE-BOUNDARY-START(231929872491),
    {
      "r": 95748097,
      "n": "GetRequestStream",
      "d": 1638507,
      "h": 231929872491,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(231929872491),
//--TRIMMABLE-BOUNDARY-START(236224839787),
    {
      "r": $.$$.STT.Task$$($.$$.SI.Stream).$h,
      "n": "GetRequestStreamAsync",
      "d": 1638507,
      "h": 236224839787,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(236224839787),
//--TRIMMABLE-BOUNDARY-START(240519807083),
    {
      "r": 1966187,
      "n": "GetResponse",
      "d": 1638507,
      "h": 240519807083,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(240519807083),
//--TRIMMABLE-BOUNDARY-START(244814774379),
    {
      "r": $.$$.STT.Task$$($.$snr.SN.WebResponse).$h,
      "n": "GetResponseAsync",
      "d": 1638507,
      "h": 244814774379,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(244814774379),
//--TRIMMABLE-BOUNDARY-START(249109741675),
    {
      "r": 3538991,
      "n": "GetSystemWebProxy",
      "d": 1638507,
      "h": 249109741675,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(249109741675),
//--TRIMMABLE-BOUNDARY-START(274879545451),
    {
      "r": 262145,
      "p": [
        {
          "n": "prefix",
          "p": 1310721
        },
        {
          "n": "creator",
          "p": 1179755
        }
      ],
      "n": "RegisterPrefix",
      "d": 1638507,
      "h": 274879545451,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(274879545451)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605803),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1638507,
      "h": 4296605803,
      "f": 16777220,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0014",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4296605803),
//--TRIMMABLE-BOUNDARY-START(8591573099),
    {
      "p": [
        {
          "n": "serializationInfo",
          "p": 158859265
        },
        {
          "n": "streamingContext",
          "p": 158990337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1638507,
      "h": 8591573099,
      "f": 16777220,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0014",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591573099)
  ],
  "h": 1638507
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebRequest`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebRequest`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638507)
        
        

        //--TRIMMABLE-BOUNDARY-START(1966187)
        $asm.$cls(`$snr.SN.WebResponse`, ($self) => class WebResponse extends $.$$.S.MarshalByRefObject
        {
            //--TRIMMABLE-BOUNDARY-START(4296933483)
            $ctor$2()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296933483);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296933483)
            
            //--TRIMMABLE-BOUNDARY-START(8591900779)
            $ctor$3(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591900779);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591900779)
            
            //--TRIMMABLE-BOUNDARY-START(17181835371)
            /*long */ get ContentLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656671851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set ContentLength(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124556017771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17181835371)
            
            //--TRIMMABLE-BOUNDARY-START(21476802667)
            /*string */ get ContentType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246606443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set ContentType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145952363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21476802667)
            
            //--TRIMMABLE-BOUNDARY-START(103081181291)
            /*System.Net.WebHeaderCollection */ get Headers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836541035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103081181291)
            
            //--TRIMMABLE-BOUNDARY-START(107376148587)
            /*bool */ get IsFromCache()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426475627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(107376148587)
            
            //--TRIMMABLE-BOUNDARY-START(111671115883)
            /*bool */ get IsMutuallyAuthenticated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73016410219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(111671115883)
            
            //--TRIMMABLE-BOUNDARY-START(115966083179)
            /*System.Uri */ get ResponseUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81606344811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115966083179)
            
            //--TRIMMABLE-BOUNDARY-START(137440919659)
            /*bool */ get SupportsHeaders()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90196279403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(137440919659)
            
            //--TRIMMABLE-BOUNDARY-START(12886868075)
            /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886868075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12886868075)
            
            //--TRIMMABLE-BOUNDARY-START(25771769963)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771769963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25771769963)
            
            //--TRIMMABLE-BOUNDARY-START(30066737259)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066737259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30066737259)
            
            //--TRIMMABLE-BOUNDARY-START(94491246699)
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94491246699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(94491246699)
            
            //--TRIMMABLE-BOUNDARY-START(98786213995)
            /*System.IO.Stream */ GetResponseStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98786213995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(98786213995)
            
            //--TRIMMABLE-BOUNDARY-START(141735886955)
            /*void */ SRS$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735886955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(141735886955)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            //--TRIMMABLE-BOUNDARY-START(4296933483)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(4296933483)
            
            static $h = 1966187;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MarshalByRefObject; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17181835371),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656671851,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124556017771,
        "f": 83886209
      },
      "n": "ContentLength",
      "d": 1966187,
      "h": 17181835371,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(17181835371),
//--TRIMMABLE-BOUNDARY-START(21476802667),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246606443,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133145952363,
        "f": 83886209
      },
      "n": "ContentType",
      "d": 1966187,
      "h": 21476802667,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(21476802667),
//--TRIMMABLE-BOUNDARY-START(103081181291),
    {
      "p": 589930,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836541035,
        "f": 50331777
      },
      "n": "Headers",
      "d": 1966187,
      "h": 103081181291,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(103081181291),
//--TRIMMABLE-BOUNDARY-START(107376148587),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426475627,
        "f": 50331777
      },
      "n": "IsFromCache",
      "d": 1966187,
      "h": 107376148587,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(107376148587),
//--TRIMMABLE-BOUNDARY-START(111671115883),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73016410219,
        "f": 50331777
      },
      "n": "IsMutuallyAuthenticated",
      "d": 1966187,
      "h": 111671115883,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(111671115883),
//--TRIMMABLE-BOUNDARY-START(115966083179),
    {
      "p": 1703938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81606344811,
        "f": 50331777
      },
      "n": "ResponseUri",
      "d": 1966187,
      "h": 115966083179,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(115966083179),
//--TRIMMABLE-BOUNDARY-START(137440919659),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90196279403,
        "f": 50331777
      },
      "n": "SupportsHeaders",
      "d": 1966187,
      "h": 137440919659,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(137440919659)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886868075),
    {
      "r": 65537,
      "n": "Close",
      "d": 1966187,
      "h": 12886868075,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12886868075),
//--TRIMMABLE-BOUNDARY-START(25771769963),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 1966187,
      "h": 25771769963,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771769963),
//--TRIMMABLE-BOUNDARY-START(30066737259),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 1966187,
      "h": 30066737259,
      "f": 16777348
    },
//--TRIMMABLE-BOUNDARY-END(30066737259),
//--TRIMMABLE-BOUNDARY-START(94491246699),
    {
      "r": 65537,
      "p": [
        {
          "n": "serializationInfo",
          "p": 158859265
        },
        {
          "n": "streamingContext",
          "p": 158990337
        }
      ],
      "n": "GetObjectData",
      "d": 1966187,
      "h": 94491246699,
      "f": 16777348,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "Serialization has been deprecated for WebResponse.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(94491246699),
//--TRIMMABLE-BOUNDARY-START(98786213995),
    {
      "r": 95748097,
      "n": "GetResponseStream",
      "d": 1966187,
      "h": 98786213995,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(98786213995)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296933483),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1966187,
      "h": 4296933483,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4296933483),
//--TRIMMABLE-BOUNDARY-START(8591900779),
    {
      "p": [
        {
          "n": "serializationInfo",
          "p": 158859265
        },
        {
          "n": "streamingContext",
          "p": 158990337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1966187,
      "h": 8591900779,
      "f": 16777220,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "Serialization has been deprecated for WebResponse.",
              "t": 1310721
            }
          ]
        },
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591900779)
  ],
  "h": 1966187
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebResponse`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebResponse`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1966187)
        
        

        //--TRIMMABLE-BOUNDARY-START(65643)
        $asm.$cls(`$snr.SN.AuthenticationManager`, ($self) => class AuthenticationManager extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295032939)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295032939);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032939)
            
            //--TRIMMABLE-BOUNDARY-START(12884967531)
            static /*System.Net.ICredentialPolicy? */ get CredentialPolicy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25769869419);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.ICredentialPolicy? */ set CredentialPolicy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424575083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12884967531)
            
            //--TRIMMABLE-BOUNDARY-START(17179934827)
            static /*System.Collections.Specialized.StringDictionary */ get CustomTargetNameDictionary()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34359804011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17179934827)
            
            //--TRIMMABLE-BOUNDARY-START(55834640491)
            static /*System.Collections.IEnumerator */ get RegisteredModules()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42949738603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55834640491)
            
            //--TRIMMABLE-BOUNDARY-START(8590000235)
            static /*System.Net.Authorization? */ Authenticate(/*string*/ challenge, /*System.Net.WebRequest*/ request, /*System.Net.ICredentials*/ credentials)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590000235)
            
            //--TRIMMABLE-BOUNDARY-START(47244705899)
            static /*System.Net.Authorization? */ PreAuthenticate(/*System.Net.WebRequest*/ request, /*System.Net.ICredentials*/ credentials)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244705899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47244705899)
            
            //--TRIMMABLE-BOUNDARY-START(51539673195)
            static /*void */ Register(/*System.Net.IAuthenticationModule*/ authenticationModule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539673195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(51539673195)
            
            //--TRIMMABLE-BOUNDARY-START(68719542379)
            static /*void */ Unregister(/*System.Net.IAuthenticationModule*/ authenticationModule)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719542379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(68719542379)
            
            //--TRIMMABLE-BOUNDARY-START(73014509675)
            static /*void */ Unregister$1(/*string*/ authenticationScheme)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014509675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(73014509675)
            
            //--TRIMMABLE-BOUNDARY-START(4295032939)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295032939)
            
            static $h = 65643;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12884967531),
    {
      "p": 1114219,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25769869419,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 64424575083,
        "f": 83886113
      },
      "n": "CredentialPolicy",
      "d": 65643,
      "h": 12884967531,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(12884967531),
//--TRIMMABLE-BOUNDARY-START(17179934827),
    {
      "p": 1310737,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34359804011,
        "f": 50331681
      },
      "n": "CustomTargetNameDictionary",
      "d": 65643,
      "h": 17179934827,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(17179934827),
//--TRIMMABLE-BOUNDARY-START(55834640491),
    {
      "p": 63504385,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42949738603,
        "f": 50331681
      },
      "n": "RegisteredModules",
      "d": 65643,
      "h": 55834640491,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(55834640491)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590000235),
    {
      "r": 131179,
      "p": [
        {
          "n": "challenge",
          "p": 1310721
        },
        {
          "n": "request",
          "p": 1638507
        },
        {
          "n": "credentials",
          "p": 2883631
        }
      ],
      "n": "Authenticate",
      "d": 65643,
      "h": 8590000235,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590000235),
//--TRIMMABLE-BOUNDARY-START(47244705899),
    {
      "r": 131179,
      "p": [
        {
          "n": "request",
          "p": 1638507
        },
        {
          "n": "credentials",
          "p": 2883631
        }
      ],
      "n": "PreAuthenticate",
      "d": 65643,
      "h": 47244705899,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47244705899),
//--TRIMMABLE-BOUNDARY-START(51539673195),
    {
      "r": 65537,
      "p": [
        {
          "n": "authenticationModule",
          "p": 1048683
        }
      ],
      "n": "Register",
      "d": 65643,
      "h": 51539673195,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51539673195),
//--TRIMMABLE-BOUNDARY-START(68719542379),
    {
      "r": 65537,
      "p": [
        {
          "n": "authenticationModule",
          "p": 1048683
        }
      ],
      "n": "Unregister",
      "d": 65643,
      "h": 68719542379,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(68719542379),
//--TRIMMABLE-BOUNDARY-START(73014509675),
    {
      "r": 65537,
      "p": [
        {
          "n": "authenticationScheme",
          "p": 1310721
        }
      ],
      "n": "Unregister",
      "o": "@$1",
      "d": 65643,
      "h": 73014509675,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(73014509675)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032939),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 65643,
      "h": 4295032939,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295032939)
  ],
  "h": 65643,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "AuthenticationManager is not supported. Methods will no-op or throw PlatformNotSupportedException.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0009",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.AuthenticationManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}AuthenticationManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65643)
        
        

        //--TRIMMABLE-BOUNDARY-START(131179)
        $asm.$cls(`$snr.SN.Authorization`, ($self) => class Authorization extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(12885033067)
            $ctor$3(/*string?*/ token)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885033067);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885033067)
            
            //--TRIMMABLE-BOUNDARY-START(8590065771)
            $ctor$2(/*string?*/ token, /*bool*/ finished)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590065771);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590065771)
            
            //--TRIMMABLE-BOUNDARY-START(4295098475)
            $ctor$1(/*string?*/ token, /*bool*/ finished, /*string?*/ connectionGroupId)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295098475);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098475)
            
            //--TRIMMABLE-BOUNDARY-START(17180000363)
            /*bool */ get Complete()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30064902251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180000363)
            
            //--TRIMMABLE-BOUNDARY-START(21474967659)
            /*string? */ get ConnectionGroupId()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38654836843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21474967659)
            
            //--TRIMMABLE-BOUNDARY-START(68719607915)
            /*string? */ get Message()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47244771435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68719607915)
            
            //--TRIMMABLE-BOUNDARY-START(73014575211)
            /*bool */ get MutuallyAuthenticated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834706027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set MutuallyAuthenticated(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899477099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73014575211)
            
            //--TRIMMABLE-BOUNDARY-START(77309542507)
            /*string[]? */ get ProtectionRealm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424640619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string[]? */ set ProtectionRealm(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489411691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77309542507)
            
            static $h = 131179;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(17180000363),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064902251,
        "f": 50331649
      },
      "n": "Complete",
      "d": 131179,
      "h": 17180000363,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180000363),
//--TRIMMABLE-BOUNDARY-START(21474967659),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654836843,
        "f": 50331649
      },
      "n": "ConnectionGroupId",
      "d": 131179,
      "h": 21474967659,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21474967659),
//--TRIMMABLE-BOUNDARY-START(68719607915),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244771435,
        "f": 50331649
      },
      "n": "Message",
      "d": 131179,
      "h": 68719607915,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719607915),
//--TRIMMABLE-BOUNDARY-START(73014575211),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834706027,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 85899477099,
        "f": 83886081
      },
      "n": "MutuallyAuthenticated",
      "d": 131179,
      "h": 73014575211,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014575211),
//--TRIMMABLE-BOUNDARY-START(77309542507),
    {
      "p": $.$typeArray($.$$.S.String).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424640619,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 94489411691,
        "f": 83886081
      },
      "n": "ProtectionRealm",
      "d": 131179,
      "h": 77309542507,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309542507)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(12885033067),
    {
      "p": [
        {
          "n": "token",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 131179,
      "h": 12885033067,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885033067),
//--TRIMMABLE-BOUNDARY-START(8590065771),
    {
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "finished",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 131179,
      "h": 8590065771,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590065771),
//--TRIMMABLE-BOUNDARY-START(4295098475),
    {
      "p": [
        {
          "n": "token",
          "p": 1310721
        },
        {
          "n": "finished",
          "p": 262145
        },
        {
          "n": "connectionGroupId",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131179,
      "h": 4295098475,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295098475)
  ],
  "h": 131179
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Authorization`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Authorization`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131179)
        
        

        //--TRIMMABLE-BOUNDARY-START(786539)
        $asm.$cls(`$snr.SN.GlobalProxySelection`, ($self) => class GlobalProxySelection extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295753835)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295753835);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295753835)
            
            //--TRIMMABLE-BOUNDARY-START(21475623019)
            static /*System.Net.IWebProxy */ get Select()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885688427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.IWebProxy */ set Select(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065557611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475623019)
            
            //--TRIMMABLE-BOUNDARY-START(17180655723)
            static /*System.Net.IWebProxy */ GetEmptyWebProxy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180655723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180655723)
            
            //--TRIMMABLE-BOUNDARY-START(4295753835)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295753835)
            
            static $h = 786539;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475623019),
    {
      "p": 3538991,
      "g": {
        "r": 0,
        "d": 0,
        "h": 12885688427,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 30065557611,
        "f": 83886113
      },
      "n": "Select",
      "d": 786539,
      "h": 21475623019,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(21475623019)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180655723),
    {
      "r": 3538991,
      "n": "GetEmptyWebProxy",
      "d": 786539,
      "h": 17180655723,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(17180655723)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753835),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 786539,
      "h": 4295753835,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753835)
  ],
  "h": 786539,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "GlobalProxySelection has been deprecated. Use WebRequest.DefaultWebProxy instead to access and set the global default proxy. Use \u0027null\u0027 instead of GetEmptyWebProxy.",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.GlobalProxySelection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}GlobalProxySelection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786539)
        
        

        //--TRIMMABLE-BOUNDARY-START(1704043)
        $asm.$cls(`$snr.SN.WebRequestMethods`, ($self) => class WebRequestMethods
        {
            //--TRIMMABLE-BOUNDARY-START(1769579)
            static $_File;
            static get File()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1769579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snr.SN.WebRequestMethods;
                return $cls.$_File ??= $asm.$ncls(`$snr.SN.WebRequestMethods.File`, ($self) => class File
                {
                    //--TRIMMABLE-BOUNDARY-START(4296736875)
                    /*string*/ static DownloadFile = null;
                    //--TRIMMABLE-BOUNDARY-END(4296736875)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591704171)
                    /*string*/ static UploadFile = null;
                    //--TRIMMABLE-BOUNDARY-END(8591704171)
                    
                    //--TRIMMABLE-BOUNDARY-START(SINIT)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(4296736875)
                            this.DownloadFile = "GET";
                            //--TRIMMABLE-BOUNDARY-END(4296736875)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(8591704171)
                            this.UploadFile = "PUT";
                            //--TRIMMABLE-BOUNDARY-END(8591704171)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(SINIT)
                    
                    static $h = 1769579;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296736875),
    {
      "t": 1310721,
      "n": "DownloadFile",
      "d": 1769579,
      "h": 4296736875,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4296736875),
//--TRIMMABLE-BOUNDARY-START(8591704171),
    {
      "t": 1310721,
      "n": "UploadFile",
      "d": 1769579,
      "h": 8591704171,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591704171)
  ],
  "d": 1704043,
  "h": 1769579
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Net.WebRequestMethods+File`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebRequestMethods${separator}File`; }
                }, $cls, ($v) => $cls.$_File = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1769579)
            
            //--TRIMMABLE-BOUNDARY-START(1835115)
            static $_Ftp;
            static get Ftp()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1835115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snr.SN.WebRequestMethods;
                return $cls.$_Ftp ??= $asm.$ncls(`$snr.SN.WebRequestMethods.Ftp`, ($self) => class Ftp
                {
                    //--TRIMMABLE-BOUNDARY-START(4296802411)
                    /*string*/ static AppendFile = null;
                    //--TRIMMABLE-BOUNDARY-END(4296802411)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591769707)
                    /*string*/ static DeleteFile = null;
                    //--TRIMMABLE-BOUNDARY-END(8591769707)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886737003)
                    /*string*/ static DownloadFile = null;
                    //--TRIMMABLE-BOUNDARY-END(12886737003)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181704299)
                    /*string*/ static GetDateTimestamp = null;
                    //--TRIMMABLE-BOUNDARY-END(17181704299)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476671595)
                    /*string*/ static GetFileSize = null;
                    //--TRIMMABLE-BOUNDARY-END(21476671595)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771638891)
                    /*string*/ static ListDirectory = null;
                    //--TRIMMABLE-BOUNDARY-END(25771638891)
                    
                    //--TRIMMABLE-BOUNDARY-START(30066606187)
                    /*string*/ static ListDirectoryDetails = null;
                    //--TRIMMABLE-BOUNDARY-END(30066606187)
                    
                    //--TRIMMABLE-BOUNDARY-START(34361573483)
                    /*string*/ static MakeDirectory = null;
                    //--TRIMMABLE-BOUNDARY-END(34361573483)
                    
                    //--TRIMMABLE-BOUNDARY-START(38656540779)
                    /*string*/ static PrintWorkingDirectory = null;
                    //--TRIMMABLE-BOUNDARY-END(38656540779)
                    
                    //--TRIMMABLE-BOUNDARY-START(42951508075)
                    /*string*/ static RemoveDirectory = null;
                    //--TRIMMABLE-BOUNDARY-END(42951508075)
                    
                    //--TRIMMABLE-BOUNDARY-START(47246475371)
                    /*string*/ static Rename = null;
                    //--TRIMMABLE-BOUNDARY-END(47246475371)
                    
                    //--TRIMMABLE-BOUNDARY-START(51541442667)
                    /*string*/ static UploadFile = null;
                    //--TRIMMABLE-BOUNDARY-END(51541442667)
                    
                    //--TRIMMABLE-BOUNDARY-START(55836409963)
                    /*string*/ static UploadFileWithUniqueName = null;
                    //--TRIMMABLE-BOUNDARY-END(55836409963)
                    
                    //--TRIMMABLE-BOUNDARY-START(SINIT)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(4296802411)
                            this.AppendFile = "APPE";
                            //--TRIMMABLE-BOUNDARY-END(4296802411)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(8591769707)
                            this.DeleteFile = "DELE";
                            //--TRIMMABLE-BOUNDARY-END(8591769707)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(12886737003)
                            this.DownloadFile = "RETR";
                            //--TRIMMABLE-BOUNDARY-END(12886737003)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(17181704299)
                            this.GetDateTimestamp = "MDTM";
                            //--TRIMMABLE-BOUNDARY-END(17181704299)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(21476671595)
                            this.GetFileSize = "SIZE";
                            //--TRIMMABLE-BOUNDARY-END(21476671595)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(25771638891)
                            this.ListDirectory = "NLST";
                            //--TRIMMABLE-BOUNDARY-END(25771638891)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(30066606187)
                            this.ListDirectoryDetails = "LIST";
                            //--TRIMMABLE-BOUNDARY-END(30066606187)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(34361573483)
                            this.MakeDirectory = "MKD";
                            //--TRIMMABLE-BOUNDARY-END(34361573483)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(38656540779)
                            this.PrintWorkingDirectory = "PWD";
                            //--TRIMMABLE-BOUNDARY-END(38656540779)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(42951508075)
                            this.RemoveDirectory = "RMD";
                            //--TRIMMABLE-BOUNDARY-END(42951508075)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(47246475371)
                            this.Rename = "RENAME";
                            //--TRIMMABLE-BOUNDARY-END(47246475371)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(51541442667)
                            this.UploadFile = "STOR";
                            //--TRIMMABLE-BOUNDARY-END(51541442667)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(55836409963)
                            this.UploadFileWithUniqueName = "STOU";
                            //--TRIMMABLE-BOUNDARY-END(55836409963)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(SINIT)
                    
                    static $h = 1835115;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296802411),
    {
      "t": 1310721,
      "n": "AppendFile",
      "d": 1835115,
      "h": 4296802411,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4296802411),
//--TRIMMABLE-BOUNDARY-START(8591769707),
    {
      "t": 1310721,
      "n": "DeleteFile",
      "d": 1835115,
      "h": 8591769707,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591769707),
//--TRIMMABLE-BOUNDARY-START(12886737003),
    {
      "t": 1310721,
      "n": "DownloadFile",
      "d": 1835115,
      "h": 12886737003,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886737003),
//--TRIMMABLE-BOUNDARY-START(17181704299),
    {
      "t": 1310721,
      "n": "GetDateTimestamp",
      "d": 1835115,
      "h": 17181704299,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181704299),
//--TRIMMABLE-BOUNDARY-START(21476671595),
    {
      "t": 1310721,
      "n": "GetFileSize",
      "d": 1835115,
      "h": 21476671595,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476671595),
//--TRIMMABLE-BOUNDARY-START(25771638891),
    {
      "t": 1310721,
      "n": "ListDirectory",
      "d": 1835115,
      "h": 25771638891,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771638891),
//--TRIMMABLE-BOUNDARY-START(30066606187),
    {
      "t": 1310721,
      "n": "ListDirectoryDetails",
      "d": 1835115,
      "h": 30066606187,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066606187),
//--TRIMMABLE-BOUNDARY-START(34361573483),
    {
      "t": 1310721,
      "n": "MakeDirectory",
      "d": 1835115,
      "h": 34361573483,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361573483),
//--TRIMMABLE-BOUNDARY-START(38656540779),
    {
      "t": 1310721,
      "n": "PrintWorkingDirectory",
      "d": 1835115,
      "h": 38656540779,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656540779),
//--TRIMMABLE-BOUNDARY-START(42951508075),
    {
      "t": 1310721,
      "n": "RemoveDirectory",
      "d": 1835115,
      "h": 42951508075,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951508075),
//--TRIMMABLE-BOUNDARY-START(47246475371),
    {
      "t": 1310721,
      "n": "Rename",
      "d": 1835115,
      "h": 47246475371,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246475371),
//--TRIMMABLE-BOUNDARY-START(51541442667),
    {
      "t": 1310721,
      "n": "UploadFile",
      "d": 1835115,
      "h": 51541442667,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541442667),
//--TRIMMABLE-BOUNDARY-START(55836409963),
    {
      "t": 1310721,
      "n": "UploadFileWithUniqueName",
      "d": 1835115,
      "h": 55836409963,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55836409963)
  ],
  "d": 1704043,
  "h": 1835115
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Net.WebRequestMethods+Ftp`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebRequestMethods${separator}Ftp`; }
                }, $cls, ($v) => $cls.$_Ftp = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1835115)
            
            //--TRIMMABLE-BOUNDARY-START(1900651)
            static $_Http;
            static get Http()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1900651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                let $cls = $.$snr.SN.WebRequestMethods;
                return $cls.$_Http ??= $asm.$ncls(`$snr.SN.WebRequestMethods.Http`, ($self) => class Http
                {
                    //--TRIMMABLE-BOUNDARY-START(4296867947)
                    /*string*/ static Connect = null;
                    //--TRIMMABLE-BOUNDARY-END(4296867947)
                    
                    //--TRIMMABLE-BOUNDARY-START(8591835243)
                    /*string*/ static Get = null;
                    //--TRIMMABLE-BOUNDARY-END(8591835243)
                    
                    //--TRIMMABLE-BOUNDARY-START(12886802539)
                    /*string*/ static Head = null;
                    //--TRIMMABLE-BOUNDARY-END(12886802539)
                    
                    //--TRIMMABLE-BOUNDARY-START(17181769835)
                    /*string*/ static MkCol = null;
                    //--TRIMMABLE-BOUNDARY-END(17181769835)
                    
                    //--TRIMMABLE-BOUNDARY-START(21476737131)
                    /*string*/ static Post = null;
                    //--TRIMMABLE-BOUNDARY-END(21476737131)
                    
                    //--TRIMMABLE-BOUNDARY-START(25771704427)
                    /*string*/ static Put = null;
                    //--TRIMMABLE-BOUNDARY-END(25771704427)
                    
                    //--TRIMMABLE-BOUNDARY-START(SINIT)
                    //Static Initializer
                    static $sinit()
                    {
                        {
                            //--TRIMMABLE-BOUNDARY-START(4296867947)
                            this.Connect = "CONNECT";
                            //--TRIMMABLE-BOUNDARY-END(4296867947)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(8591835243)
                            this.Get = "GET";
                            //--TRIMMABLE-BOUNDARY-END(8591835243)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(12886802539)
                            this.Head = "HEAD";
                            //--TRIMMABLE-BOUNDARY-END(12886802539)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(17181769835)
                            this.MkCol = "MKCOL";
                            //--TRIMMABLE-BOUNDARY-END(17181769835)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(21476737131)
                            this.Post = "POST";
                            //--TRIMMABLE-BOUNDARY-END(21476737131)
                            
                        }
                        {
                            //--TRIMMABLE-BOUNDARY-START(25771704427)
                            this.Put = "PUT";
                            //--TRIMMABLE-BOUNDARY-END(25771704427)
                            
                        }
                    }
                    //--TRIMMABLE-BOUNDARY-END(SINIT)
                    
                    static $h = 1900651;
                    static $f = 0b10000000000010001;
                    static $k = 1;
                    static $$b;
                    static get $b() { return this.$$b ??= $.$$.S.Object; }
                    static $$md;
                    static get $md() { return this.$$md ??= {
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296867947),
    {
      "t": 1310721,
      "n": "Connect",
      "d": 1900651,
      "h": 4296867947,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(4296867947),
//--TRIMMABLE-BOUNDARY-START(8591835243),
    {
      "t": 1310721,
      "n": "Get",
      "d": 1900651,
      "h": 8591835243,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591835243),
//--TRIMMABLE-BOUNDARY-START(12886802539),
    {
      "t": 1310721,
      "n": "Head",
      "d": 1900651,
      "h": 12886802539,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886802539),
//--TRIMMABLE-BOUNDARY-START(17181769835),
    {
      "t": 1310721,
      "n": "MkCol",
      "d": 1900651,
      "h": 17181769835,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181769835),
//--TRIMMABLE-BOUNDARY-START(21476737131),
    {
      "t": 1310721,
      "n": "Post",
      "d": 1900651,
      "h": 21476737131,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476737131),
//--TRIMMABLE-BOUNDARY-START(25771704427),
    {
      "t": 1310721,
      "n": "Put",
      "d": 1900651,
      "h": 25771704427,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771704427)
  ],
  "d": 1704043,
  "h": 1900651
}; }
                    static $$fullName;
                    static get $fullName() { return this.$$fullName ??= `System.Net.WebRequestMethods+Http`; }
                    static $$getFullName = {};
                    static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebRequestMethods${separator}Http`; }
                }, $cls, ($v) => $cls.$_Http = $v);
            }
            //--TRIMMABLE-BOUNDARY-END(1900651)
            
            static $h = 1704043;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1704043
}; }
            static $$n;
            static get $n() { return this.$$n ??= [ $.$snr.SN.WebRequestMethods.File, $.$snr.SN.WebRequestMethods.Ftp, $.$snr.SN.WebRequestMethods.Http ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebRequestMethods`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebRequestMethods`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1704043)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376363)
        $asm.$cls(`$snr.SN.ServicePoint`, ($self) => class ServicePoint extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296343659)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296343659);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296343659)
            
            //--TRIMMABLE-BOUNDARY-START(8591310955)
            /*System.Uri */ get Address()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835951211);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8591310955)
            
            //--TRIMMABLE-BOUNDARY-START(12886278251)
            /*System.Net.BindIPEndPoint? */ get BindIPEndPointDelegate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425885803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.BindIPEndPoint? */ set BindIPEndPointDelegate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864839275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12886278251)
            
            //--TRIMMABLE-BOUNDARY-START(17181245547)
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get Certificate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015820395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17181245547)
            
            //--TRIMMABLE-BOUNDARY-START(21476212843)
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get ClientCertificate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605754987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21476212843)
            
            //--TRIMMABLE-BOUNDARY-START(30066147435)
            /*int */ get ConnectionLeaseTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195689579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ConnectionLeaseTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454773867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30066147435)
            
            //--TRIMMABLE-BOUNDARY-START(34361114731)
            /*int */ get ConnectionLimit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785624171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ConnectionLimit(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044708459);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34361114731)
            
            //--TRIMMABLE-BOUNDARY-START(38656082027)
            /*string */ get ConnectionName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375558763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38656082027)
            
            //--TRIMMABLE-BOUNDARY-START(42951049323)
            /*int */ get CurrentConnections()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965493355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42951049323)
            
            //--TRIMMABLE-BOUNDARY-START(47246016619)
            /*bool */ get Expect100Continue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555427947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Expect100Continue(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634643051);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47246016619)
            
            //--TRIMMABLE-BOUNDARY-START(180390002795)
            /*System.DateTime */ get IdleSince()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145362539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(180390002795)
            
            //--TRIMMABLE-BOUNDARY-START(184684970091)
            /*int */ get MaxIdleTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141735297131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set MaxIdleTime(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224577643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(184684970091)
            
            //--TRIMMABLE-BOUNDARY-START(188979937387)
            /*System.Version */ get ProtocolVersion()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150325231723);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(188979937387)
            
            //--TRIMMABLE-BOUNDARY-START(193274904683)
            /*int */ get ReceiveBufferSize()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158915166315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveBufferSize(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814512235);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(193274904683)
            
            //--TRIMMABLE-BOUNDARY-START(261994381419)
            /*bool */ get SupportsPipelining()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167505100907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(261994381419)
            
            //--TRIMMABLE-BOUNDARY-START(266289348715)
            /*bool */ get UseNagleAlgorithm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176095035499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseNagleAlgorithm(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404446827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(266289348715)
            
            //--TRIMMABLE-BOUNDARY-START(25771180139)
            /*bool */ CloseConnectionGroup(/*string*/ connectionGroupName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771180139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25771180139)
            
            //--TRIMMABLE-BOUNDARY-START(257699414123)
            /*void */ SetTcpKeepAlive(/*bool*/ enabled, /*int*/ keepAliveTime, /*int*/ keepAliveInterval)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699414123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(257699414123)
            
            //--TRIMMABLE-BOUNDARY-START(4296343659)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296343659)
            
            static $h = 1376363;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591310955),
    {
      "p": 1703938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835951211,
        "f": 50331649
      },
      "n": "Address",
      "d": 1376363,
      "h": 8591310955,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8591310955),
//--TRIMMABLE-BOUNDARY-START(12886278251),
    {
      "p": 196715,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425885803,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201864839275,
        "f": 83886081
      },
      "n": "BindIPEndPointDelegate",
      "d": 1376363,
      "h": 12886278251,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886278251),
//--TRIMMABLE-BOUNDARY-START(17181245547),
    {
      "p": 28114974,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015820395,
        "f": 50331649
      },
      "n": "Certificate",
      "d": 1376363,
      "h": 17181245547,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181245547),
//--TRIMMABLE-BOUNDARY-START(21476212843),
    {
      "p": 28114974,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605754987,
        "f": 50331649
      },
      "n": "ClientCertificate",
      "d": 1376363,
      "h": 21476212843,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476212843),
//--TRIMMABLE-BOUNDARY-START(30066147435),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195689579,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454773867,
        "f": 83886081
      },
      "n": "ConnectionLeaseTimeout",
      "d": 1376363,
      "h": 30066147435,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066147435),
//--TRIMMABLE-BOUNDARY-START(34361114731),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785624171,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044708459,
        "f": 83886081
      },
      "n": "ConnectionLimit",
      "d": 1376363,
      "h": 34361114731,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361114731),
//--TRIMMABLE-BOUNDARY-START(38656082027),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375558763,
        "f": 50331649
      },
      "n": "ConnectionName",
      "d": 1376363,
      "h": 38656082027,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656082027),
//--TRIMMABLE-BOUNDARY-START(42951049323),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965493355,
        "f": 50331649
      },
      "n": "CurrentConnections",
      "d": 1376363,
      "h": 42951049323,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42951049323),
//--TRIMMABLE-BOUNDARY-START(47246016619),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555427947,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227634643051,
        "f": 83886081
      },
      "n": "Expect100Continue",
      "d": 1376363,
      "h": 47246016619,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47246016619),
//--TRIMMABLE-BOUNDARY-START(180390002795),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145362539,
        "f": 50331649
      },
      "n": "IdleSince",
      "d": 1376363,
      "h": 180390002795,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(180390002795),
//--TRIMMABLE-BOUNDARY-START(184684970091),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141735297131,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236224577643,
        "f": 83886081
      },
      "n": "MaxIdleTime",
      "d": 1376363,
      "h": 184684970091,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184684970091),
//--TRIMMABLE-BOUNDARY-START(188979937387),
    {
      "p": 190644225,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150325231723,
        "f": 50331777
      },
      "n": "ProtocolVersion",
      "d": 1376363,
      "h": 188979937387,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(188979937387),
//--TRIMMABLE-BOUNDARY-START(193274904683),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158915166315,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244814512235,
        "f": 83886081
      },
      "n": "ReceiveBufferSize",
      "d": 1376363,
      "h": 193274904683,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274904683),
//--TRIMMABLE-BOUNDARY-START(261994381419),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167505100907,
        "f": 50331649
      },
      "n": "SupportsPipelining",
      "d": 1376363,
      "h": 261994381419,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(261994381419),
//--TRIMMABLE-BOUNDARY-START(266289348715),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176095035499,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253404446827,
        "f": 83886081
      },
      "n": "UseNagleAlgorithm",
      "d": 1376363,
      "h": 266289348715,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(266289348715)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771180139),
    {
      "r": 262145,
      "p": [
        {
          "n": "connectionGroupName",
          "p": 1310721
        }
      ],
      "n": "CloseConnectionGroup",
      "d": 1376363,
      "h": 25771180139,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771180139),
//--TRIMMABLE-BOUNDARY-START(257699414123),
    {
      "r": 65537,
      "p": [
        {
          "n": "enabled",
          "p": 262145
        },
        {
          "n": "keepAliveTime",
          "p": 655361
        },
        {
          "n": "keepAliveInterval",
          "p": 655361
        }
      ],
      "n": "SetTcpKeepAlive",
      "d": 1376363,
      "h": 257699414123,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(257699414123)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343659),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1376363,
      "h": 4296343659,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296343659)
  ],
  "h": 1376363
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.ServicePoint`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}ServicePoint`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376363)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441899)
        $asm.$cls(`$snr.SN.ServicePointManager`, ($self) => class ServicePointManager extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296409195)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296409195);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296409195)
            
            //--TRIMMABLE-BOUNDARY-START(17181311083)
            /*int*/ static DefaultNonPersistentConnectionLimit = 4;
            //--TRIMMABLE-BOUNDARY-END(17181311083)
            
            //--TRIMMABLE-BOUNDARY-START(21476278379)
            /*int*/ static DefaultPersistentConnectionLimit = 2;
            //--TRIMMABLE-BOUNDARY-END(21476278379)
            
            //--TRIMMABLE-BOUNDARY-START(8591376491)
            static /*bool */ get CheckCertificateRevocationList()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130984043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ set CheckCertificateRevocationList(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184685035627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8591376491)
            
            //--TRIMMABLE-BOUNDARY-START(12886343787)
            static /*int */ get DefaultConnectionLimit()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720918635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ set DefaultConnectionLimit(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274970219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12886343787)
            
            //--TRIMMABLE-BOUNDARY-START(25771245675)
            static /*int */ get DnsRefreshTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310853227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ set DnsRefreshTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864904811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25771245675)
            
            //--TRIMMABLE-BOUNDARY-START(30066212971)
            static /*bool */ get EnableDnsRoundRobin()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900787819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ set EnableDnsRoundRobin(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454839403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30066212971)
            
            //--TRIMMABLE-BOUNDARY-START(34361180267)
            static /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490722411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34361180267)
            
            //--TRIMMABLE-BOUNDARY-START(38656147563)
            static /*bool */ get Expect100Continue()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080657003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ set Expect100Continue(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044773995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38656147563)
            
            //--TRIMMABLE-BOUNDARY-START(158915231851)
            static /*int */ get MaxServicePointIdleTime()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670591595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ set MaxServicePointIdleTime(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634708587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(158915231851)
            
            //--TRIMMABLE-BOUNDARY-START(163210199147)
            static /*int */ get MaxServicePoints()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260526187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ set MaxServicePoints(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224643179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(163210199147)
            
            //--TRIMMABLE-BOUNDARY-START(167505166443)
            static /*bool */ get ReusePort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850460779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ set ReusePort(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814577771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(167505166443)
            
            //--TRIMMABLE-BOUNDARY-START(171800133739)
            static /*System.Net.SecurityProtocolType */ get SecurityProtocol()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440395371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.SecurityProtocolType */ set SecurityProtocol(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404512363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(171800133739)
            
            //--TRIMMABLE-BOUNDARY-START(176095101035)
            static /*System.Net.Security.RemoteCertificateValidationCallback? */ get ServerCertificateValidationCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030329963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.RemoteCertificateValidationCallback? */ set ServerCertificateValidationCallback(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994446955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(176095101035)
            
            //--TRIMMABLE-BOUNDARY-START(279174316139)
            static /*bool */ get UseNagleAlgorithm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620264555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ set UseNagleAlgorithm(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270584381547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(279174316139)
            
            //--TRIMMABLE-BOUNDARY-START(42951114859)
            static /*System.Net.ServicePoint */ FindServicePoint(/*string*/ uriString, /*System.Net.IWebProxy?*/ proxy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951114859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42951114859)
            
            //--TRIMMABLE-BOUNDARY-START(51541049451)
            static /*System.Net.ServicePoint */ FindServicePoint$2(/*System.Uri*/ address)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51541049451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51541049451)
            
            //--TRIMMABLE-BOUNDARY-START(47246082155)
            static /*System.Net.ServicePoint */ FindServicePoint$1(/*System.Uri*/ address, /*System.Net.IWebProxy?*/ proxy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246082155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47246082155)
            
            //--TRIMMABLE-BOUNDARY-START(274879348843)
            static /*void */ SetTcpKeepAlive(/*bool*/ enabled, /*int*/ keepAliveTime, /*int*/ keepAliveInterval)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879348843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(274879348843)
            
            //--TRIMMABLE-BOUNDARY-START(4296409195)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296409195)
            
            static $h = 1441899;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591376491),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130984043,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 184685035627,
        "f": 83886113
      },
      "n": "CheckCertificateRevocationList",
      "d": 1441899,
      "h": 8591376491,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(8591376491),
//--TRIMMABLE-BOUNDARY-START(12886343787),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720918635,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 193274970219,
        "f": 83886113
      },
      "n": "DefaultConnectionLimit",
      "d": 1441899,
      "h": 12886343787,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(12886343787),
//--TRIMMABLE-BOUNDARY-START(25771245675),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310853227,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201864904811,
        "f": 83886113
      },
      "n": "DnsRefreshTimeout",
      "d": 1441899,
      "h": 25771245675,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(25771245675),
//--TRIMMABLE-BOUNDARY-START(30066212971),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900787819,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454839403,
        "f": 83886113
      },
      "n": "EnableDnsRoundRobin",
      "d": 1441899,
      "h": 30066212971,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(30066212971),
//--TRIMMABLE-BOUNDARY-START(34361180267),
    {
      "p": 196658,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490722411,
        "f": 50331681
      },
      "n": "EncryptionPolicy",
      "d": 1441899,
      "h": 34361180267,
      "f": 2097185,
      "a": [
        {
          "t": 160169985,
          "c": 13045071873,
          "a": [
            {
              "v": "browser",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(34361180267),
//--TRIMMABLE-BOUNDARY-START(38656147563),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080657003,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044773995,
        "f": 83886113
      },
      "n": "Expect100Continue",
      "d": 1441899,
      "h": 38656147563,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(38656147563),
//--TRIMMABLE-BOUNDARY-START(158915231851),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670591595,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227634708587,
        "f": 83886113
      },
      "n": "MaxServicePointIdleTime",
      "d": 1441899,
      "h": 158915231851,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(158915231851),
//--TRIMMABLE-BOUNDARY-START(163210199147),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260526187,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236224643179,
        "f": 83886113
      },
      "n": "MaxServicePoints",
      "d": 1441899,
      "h": 163210199147,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(163210199147),
//--TRIMMABLE-BOUNDARY-START(167505166443),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850460779,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244814577771,
        "f": 83886113
      },
      "n": "ReusePort",
      "d": 1441899,
      "h": 167505166443,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(167505166443),
//--TRIMMABLE-BOUNDARY-START(171800133739),
    {
      "p": 1310827,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440395371,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253404512363,
        "f": 83886113
      },
      "n": "SecurityProtocol",
      "d": 1441899,
      "h": 171800133739,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(171800133739),
//--TRIMMABLE-BOUNDARY-START(176095101035),
    {
      "p": 720946,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030329963,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261994446955,
        "f": 83886113
      },
      "n": "ServerCertificateValidationCallback",
      "d": 1441899,
      "h": 176095101035,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(176095101035),
//--TRIMMABLE-BOUNDARY-START(279174316139),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154620264555,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270584381547,
        "f": 83886113
      },
      "n": "UseNagleAlgorithm",
      "d": 1441899,
      "h": 279174316139,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(279174316139)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(42951114859),
    {
      "r": 1376363,
      "p": [
        {
          "n": "uriString",
          "p": 1310721
        },
        {
          "n": "proxy",
          "p": 3538991
        }
      ],
      "n": "FindServicePoint",
      "d": 1441899,
      "h": 42951114859,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(42951114859),
//--TRIMMABLE-BOUNDARY-START(51541049451),
    {
      "r": 1376363,
      "p": [
        {
          "n": "address",
          "p": 1703938
        }
      ],
      "n": "FindServicePoint",
      "o": "@$2",
      "d": 1441899,
      "h": 51541049451,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(51541049451),
//--TRIMMABLE-BOUNDARY-START(47246082155),
    {
      "r": 1376363,
      "p": [
        {
          "n": "address",
          "p": 1703938
        },
        {
          "n": "proxy",
          "p": 3538991
        }
      ],
      "n": "FindServicePoint",
      "o": "@$1",
      "d": 1441899,
      "h": 47246082155,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(47246082155),
//--TRIMMABLE-BOUNDARY-START(274879348843),
    {
      "r": 65537,
      "p": [
        {
          "n": "enabled",
          "p": 262145
        },
        {
          "n": "keepAliveTime",
          "p": 655361
        },
        {
          "n": "keepAliveInterval",
          "p": 655361
        }
      ],
      "n": "SetTcpKeepAlive",
      "d": 1441899,
      "h": 274879348843,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(274879348843)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(17181311083),
    {
      "t": 655361,
      "n": "DefaultNonPersistentConnectionLimit",
      "d": 1441899,
      "h": 17181311083,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181311083),
//--TRIMMABLE-BOUNDARY-START(21476278379),
    {
      "t": 655361,
      "n": "DefaultPersistentConnectionLimit",
      "d": 1441899,
      "h": 21476278379,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476278379)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296409195),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1441899,
      "h": 4296409195,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296409195)
  ],
  "h": 1441899,
  "a": [
    {
      "t": 104464385,
      "c": 30169235457,
      "a": [
        {
          "v": "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead. Settings on ServicePointManager no longer affect SslStream or HttpClient.",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "DiagnosticId",
          "v": "SYSLIB0014",
          "t": 1310721
        },
        {
          "n": "UrlFormat",
          "v": "https://aka.ms/dotnet-warnings/{0}",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.ServicePointManager`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}ServicePointManager`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441899)
        
        

        //--TRIMMABLE-BOUNDARY-START(458859)
        $asm.$cls(`$snr.SN.FileWebRequest`, ($self) => class FileWebRequest extends $.$snr.SN.WebRequest
        {
            //--TRIMMABLE-BOUNDARY-START(4295426155)
            $ctor$4(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295426155);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426155)
            
            //--TRIMMABLE-BOUNDARY-START(21475295339)
            /*string? */ get ConnectionGroupName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540066411);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set ConnectionGroupName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979019883);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475295339)
            
            //--TRIMMABLE-BOUNDARY-START(25770262635)
            /*long */ get ContentLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130001003);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set ContentLength(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197568954475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770262635)
            
            //--TRIMMABLE-BOUNDARY-START(30065229931)
            /*string? */ get ContentType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719935595);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set ContentType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206158889067);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065229931)
            
            //--TRIMMABLE-BOUNDARY-START(34360197227)
            /*System.Net.ICredentials? */ get Credentials()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309870187);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.ICredentials? */ set Credentials(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214748823659);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360197227)
            
            //--TRIMMABLE-BOUNDARY-START(163209216107)
            /*System.Net.WebHeaderCollection */ get Headers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899804779);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(163209216107)
            
            //--TRIMMABLE-BOUNDARY-START(167504183403)
            /*string */ get Method()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489739371);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Method(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338758251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(167504183403)
            
            //--TRIMMABLE-BOUNDARY-START(171799150699)
            /*bool */ get PreAuthenticate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079673963);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PreAuthenticate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928692843);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(171799150699)
            
            //--TRIMMABLE-BOUNDARY-START(176094117995)
            /*System.Net.IWebProxy? */ get Proxy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669608555);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IWebProxy? */ set Proxy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518627435);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(176094117995)
            
            //--TRIMMABLE-BOUNDARY-START(180389085291)
            /*System.Uri */ get RequestUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259543147);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(180389085291)
            
            //--TRIMMABLE-BOUNDARY-START(266288431211)
            /*int */ get Timeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849477739);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set Timeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108562027);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(266288431211)
            
            //--TRIMMABLE-BOUNDARY-START(270583398507)
            /*bool */ get UseDefaultCredentials()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439412331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseDefaultCredentials(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257698496619);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(270583398507)
            
            //--TRIMMABLE-BOUNDARY-START(8590393451)
            /*void */ Abort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590393451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590393451)
            
            //--TRIMMABLE-BOUNDARY-START(12885360747)
            /*System.IAsyncResult */ BeginGetRequestStream(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885360747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885360747)
            
            //--TRIMMABLE-BOUNDARY-START(17180328043)
            /*System.IAsyncResult */ BeginGetResponse(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180328043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180328043)
            
            //--TRIMMABLE-BOUNDARY-START(38655164523)
            /*System.IO.Stream */ EndGetRequestStream(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655164523)
            
            //--TRIMMABLE-BOUNDARY-START(42950131819)
            /*System.Net.WebResponse */ EndGetResponse(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950131819);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950131819)
            
            //--TRIMMABLE-BOUNDARY-START(141734379627)
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734379627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(141734379627)
            
            //--TRIMMABLE-BOUNDARY-START(146029346923)
            /*System.IO.Stream */ GetRequestStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029346923);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(146029346923)
            
            //--TRIMMABLE-BOUNDARY-START(150324314219)
            /*System.Threading.Tasks.Task<System.IO.Stream> */ GetRequestStreamAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324314219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(150324314219)
            
            //--TRIMMABLE-BOUNDARY-START(154619281515)
            /*System.Net.WebResponse */ GetResponse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619281515);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(154619281515)
            
            //--TRIMMABLE-BOUNDARY-START(158914248811)
            /*System.Threading.Tasks.Task<System.Net.WebResponse> */ GetResponseAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914248811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(158914248811)
            
            //--TRIMMABLE-BOUNDARY-START(261993463915)
            /*void */ SRS$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993463915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(261993463915)
            
            static $h = 458859;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$snr.SN.WebRequest; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475295339),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540066411,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 188979019883,
        "f": 83918849
      },
      "n": "ConnectionGroupName",
      "d": 458859,
      "h": 21475295339,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(21475295339),
//--TRIMMABLE-BOUNDARY-START(25770262635),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130001003,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 197568954475,
        "f": 83918849
      },
      "n": "ContentLength",
      "d": 458859,
      "h": 25770262635,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770262635),
//--TRIMMABLE-BOUNDARY-START(30065229931),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719935595,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206158889067,
        "f": 83918849
      },
      "n": "ContentType",
      "d": 458859,
      "h": 30065229931,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065229931),
//--TRIMMABLE-BOUNDARY-START(34360197227),
    {
      "p": 2883631,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309870187,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214748823659,
        "f": 83918849
      },
      "n": "Credentials",
      "d": 458859,
      "h": 34360197227,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(34360197227),
//--TRIMMABLE-BOUNDARY-START(163209216107),
    {
      "p": 589930,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899804779,
        "f": 50364417
      },
      "n": "Headers",
      "d": 458859,
      "h": 163209216107,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(163209216107),
//--TRIMMABLE-BOUNDARY-START(167504183403),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489739371,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223338758251,
        "f": 83918849
      },
      "n": "Method",
      "d": 458859,
      "h": 167504183403,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(167504183403),
//--TRIMMABLE-BOUNDARY-START(171799150699),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079673963,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231928692843,
        "f": 83918849
      },
      "n": "PreAuthenticate",
      "d": 458859,
      "h": 171799150699,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(171799150699),
//--TRIMMABLE-BOUNDARY-START(176094117995),
    {
      "p": 3538991,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669608555,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240518627435,
        "f": 83918849
      },
      "n": "Proxy",
      "d": 458859,
      "h": 176094117995,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(176094117995),
//--TRIMMABLE-BOUNDARY-START(180389085291),
    {
      "p": 1703938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259543147,
        "f": 50364417
      },
      "n": "RequestUri",
      "d": 458859,
      "h": 180389085291,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(180389085291),
//--TRIMMABLE-BOUNDARY-START(266288431211),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849477739,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249108562027,
        "f": 83918849
      },
      "n": "Timeout",
      "d": 458859,
      "h": 266288431211,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(266288431211),
//--TRIMMABLE-BOUNDARY-START(270583398507),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439412331,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257698496619,
        "f": 83918849
      },
      "n": "UseDefaultCredentials",
      "d": 458859,
      "h": 270583398507,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(270583398507)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590393451),
    {
      "r": 65537,
      "n": "Abort",
      "d": 458859,
      "h": 8590393451,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590393451),
//--TRIMMABLE-BOUNDARY-START(12885360747),
    {
      "r": 90570753,
      "p": [
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginGetRequestStream",
      "d": 458859,
      "h": 12885360747,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885360747),
//--TRIMMABLE-BOUNDARY-START(17180328043),
    {
      "r": 90570753,
      "p": [
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginGetResponse",
      "d": 458859,
      "h": 17180328043,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180328043),
//--TRIMMABLE-BOUNDARY-START(38655164523),
    {
      "r": 95748097,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndGetRequestStream",
      "d": 458859,
      "h": 38655164523,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(38655164523),
//--TRIMMABLE-BOUNDARY-START(42950131819),
    {
      "r": 1966187,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndGetResponse",
      "d": 458859,
      "h": 42950131819,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950131819),
//--TRIMMABLE-BOUNDARY-START(141734379627),
    {
      "r": 65537,
      "p": [
        {
          "n": "serializationInfo",
          "p": 158859265
        },
        {
          "n": "streamingContext",
          "p": 158990337
        }
      ],
      "n": "GetObjectData",
      "d": 458859,
      "h": 141734379627,
      "f": 16809988,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "Serialization has been deprecated for FileWebRequest.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(141734379627),
//--TRIMMABLE-BOUNDARY-START(146029346923),
    {
      "r": 95748097,
      "n": "GetRequestStream",
      "d": 458859,
      "h": 146029346923,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146029346923),
//--TRIMMABLE-BOUNDARY-START(150324314219),
    {
      "r": $.$$.STT.Task$$($.$$.SI.Stream).$h,
      "n": "GetRequestStreamAsync",
      "d": 458859,
      "h": 150324314219,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(150324314219),
//--TRIMMABLE-BOUNDARY-START(154619281515),
    {
      "r": 1966187,
      "n": "GetResponse",
      "d": 458859,
      "h": 154619281515,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(154619281515),
//--TRIMMABLE-BOUNDARY-START(158914248811),
    {
      "r": $.$$.STT.Task$$($.$snr.SN.WebResponse).$h,
      "n": "GetResponseAsync",
      "d": 458859,
      "h": 158914248811,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(158914248811)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426155),
    {
      "p": [
        {
          "n": "serializationInfo",
          "p": 158859265
        },
        {
          "n": "streamingContext",
          "p": 158990337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 458859,
      "h": 4295426155,
      "f": 16777220,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "Serialization has been deprecated for FileWebRequest.",
              "t": 1310721
            }
          ]
        },
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295426155)
  ],
  "h": 458859
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.FileWebRequest`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}FileWebRequest`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458859)
        
        

        //--TRIMMABLE-BOUNDARY-START(655467)
        $asm.$cls(`$snr.SN.FtpWebRequest`, ($self) => class FtpWebRequest extends $.$snr.SN.WebRequest
        {
            //--TRIMMABLE-BOUNDARY-START(4295622763)
            $ctor$4()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295622763);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622763)
            
            //--TRIMMABLE-BOUNDARY-START(21475491947)
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection */ get ClientCertificates()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720132203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection */ set ClientCertificates(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353398891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475491947)
            
            //--TRIMMABLE-BOUNDARY-START(25770459243)
            /*string? */ get ConnectionGroupName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310066795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set ConnectionGroupName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943333483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770459243)
            
            //--TRIMMABLE-BOUNDARY-START(30065426539)
            /*long */ get ContentLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900001387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set ContentLength(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533268075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065426539)
            
            //--TRIMMABLE-BOUNDARY-START(34360393835)
            /*long */ get ContentOffset()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489935979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set ContentOffset(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123202667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360393835)
            
            //--TRIMMABLE-BOUNDARY-START(38655361131)
            /*string? */ get ContentType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079870571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set ContentType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713137259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655361131)
            
            //--TRIMMABLE-BOUNDARY-START(42950328427)
            /*System.Net.ICredentials? */ get Credentials()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669805163);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.ICredentials? */ set Credentials(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303071851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950328427)
            
            //--TRIMMABLE-BOUNDARY-START(47245295723)
            static /*System.Net.Cache.RequestCachePolicy? */ get DefaultCachePolicy$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259739755);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Cache.RequestCachePolicy? */ set DefaultCachePolicy$1(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347893006443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245295723)
            
            //--TRIMMABLE-BOUNDARY-START(51540263019)
            /*bool */ get EnableSsl()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849674347);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableSsl(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356482941035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51540263019)
            
            //--TRIMMABLE-BOUNDARY-START(253403725931)
            /*System.Net.WebHeaderCollection */ get Headers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439608939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.WebHeaderCollection */ set Headers(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365072875627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(253403725931)
            
            //--TRIMMABLE-BOUNDARY-START(257698693227)
            /*bool */ get KeepAlive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029543531);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set KeepAlive(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662810219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(257698693227)
            
            //--TRIMMABLE-BOUNDARY-START(261993660523)
            /*string */ get Method()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619478123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Method(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382252744811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(261993660523)
            
            //--TRIMMABLE-BOUNDARY-START(266288627819)
            /*bool */ get PreAuthenticate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209412715);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PreAuthenticate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842679403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(266288627819)
            
            //--TRIMMABLE-BOUNDARY-START(270583595115)
            /*System.Net.IWebProxy? */ get Proxy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799347307);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IWebProxy? */ set Proxy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399432613995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(270583595115)
            
            //--TRIMMABLE-BOUNDARY-START(274878562411)
            /*int */ get ReadWriteTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389281899);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadWriteTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022548587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(274878562411)
            
            //--TRIMMABLE-BOUNDARY-START(279173529707)
            /*string? */ get RenameTo()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(188979216491);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set RenameTo(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612483179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(279173529707)
            
            //--TRIMMABLE-BOUNDARY-START(283468497003)
            /*System.Uri */ get RequestUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569151083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(283468497003)
            
            //--TRIMMABLE-BOUNDARY-START(287763464299)
            /*System.Net.ServicePoint */ get ServicePoint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159085675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(287763464299)
            
            //--TRIMMABLE-BOUNDARY-START(455267188843)
            /*int */ get Timeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749020267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set Timeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425202417771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(455267188843)
            
            //--TRIMMABLE-BOUNDARY-START(459562156139)
            /*bool */ get UseBinary()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223338954859);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseBinary(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433792352363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(459562156139)
            
            //--TRIMMABLE-BOUNDARY-START(463857123435)
            /*bool */ get UseDefaultCredentials()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231928889451);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseDefaultCredentials(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442382286955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(463857123435)
            
            //--TRIMMABLE-BOUNDARY-START(468152090731)
            /*bool */ get UsePassive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240518824043);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UsePassive(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450972221547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(468152090731)
            
            //--TRIMMABLE-BOUNDARY-START(8590590059)
            /*void */ Abort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590590059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590590059)
            
            //--TRIMMABLE-BOUNDARY-START(12885557355)
            /*System.IAsyncResult */ BeginGetRequestStream(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885557355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885557355)
            
            //--TRIMMABLE-BOUNDARY-START(17180524651)
            /*System.IAsyncResult */ BeginGetResponse(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180524651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180524651)
            
            //--TRIMMABLE-BOUNDARY-START(55835230315)
            /*System.IO.Stream */ EndGetRequestStream(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835230315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55835230315)
            
            //--TRIMMABLE-BOUNDARY-START(60130197611)
            /*System.Net.WebResponse */ EndGetResponse(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130197611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60130197611)
            
            //--TRIMMABLE-BOUNDARY-START(244813791339)
            /*System.IO.Stream */ GetRequestStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813791339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(244813791339)
            
            //--TRIMMABLE-BOUNDARY-START(249108758635)
            /*System.Net.WebResponse */ GetResponse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249108758635);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(249108758635)
            
            //--TRIMMABLE-BOUNDARY-START(4295622763)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295622763)
            
            static $h = 655467;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$snr.SN.WebRequest; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(21475491947),
    {
      "p": 28377118,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720132203,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296353398891,
        "f": 83886081
      },
      "n": "ClientCertificates",
      "d": 655467,
      "h": 21475491947,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475491947),
//--TRIMMABLE-BOUNDARY-START(25770459243),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310066795,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304943333483,
        "f": 83918849
      },
      "n": "ConnectionGroupName",
      "d": 655467,
      "h": 25770459243,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770459243),
//--TRIMMABLE-BOUNDARY-START(30065426539),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900001387,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313533268075,
        "f": 83918849
      },
      "n": "ContentLength",
      "d": 655467,
      "h": 30065426539,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065426539),
//--TRIMMABLE-BOUNDARY-START(34360393835),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489935979,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322123202667,
        "f": 83886081
      },
      "n": "ContentOffset",
      "d": 655467,
      "h": 34360393835,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360393835),
//--TRIMMABLE-BOUNDARY-START(38655361131),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079870571,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 330713137259,
        "f": 83918849
      },
      "n": "ContentType",
      "d": 655467,
      "h": 38655361131,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(38655361131),
//--TRIMMABLE-BOUNDARY-START(42950328427),
    {
      "p": 2883631,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111669805163,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 339303071851,
        "f": 83918849
      },
      "n": "Credentials",
      "d": 655467,
      "h": 42950328427,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(42950328427),
//--TRIMMABLE-BOUNDARY-START(47245295723),
    {
      "p": 1048623,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120259739755,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 347893006443,
        "f": 83886113
      },
      "n": "DefaultCachePolicy",
      "o": "@$1",
      "d": 655467,
      "h": 47245295723,
      "f": 538968097
    },
//--TRIMMABLE-BOUNDARY-END(47245295723),
//--TRIMMABLE-BOUNDARY-START(51540263019),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128849674347,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 356482941035,
        "f": 83886081
      },
      "n": "EnableSsl",
      "d": 655467,
      "h": 51540263019,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540263019),
//--TRIMMABLE-BOUNDARY-START(253403725931),
    {
      "p": 589930,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137439608939,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 365072875627,
        "f": 83918849
      },
      "n": "Headers",
      "d": 655467,
      "h": 253403725931,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(253403725931),
//--TRIMMABLE-BOUNDARY-START(257698693227),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146029543531,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 373662810219,
        "f": 83886081
      },
      "n": "KeepAlive",
      "d": 655467,
      "h": 257698693227,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(257698693227),
//--TRIMMABLE-BOUNDARY-START(261993660523),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154619478123,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 382252744811,
        "f": 83918849
      },
      "n": "Method",
      "d": 655467,
      "h": 261993660523,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(261993660523),
//--TRIMMABLE-BOUNDARY-START(266288627819),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209412715,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 390842679403,
        "f": 83918849
      },
      "n": "PreAuthenticate",
      "d": 655467,
      "h": 266288627819,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(266288627819),
//--TRIMMABLE-BOUNDARY-START(270583595115),
    {
      "p": 3538991,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799347307,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 399432613995,
        "f": 83918849
      },
      "n": "Proxy",
      "d": 655467,
      "h": 270583595115,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(270583595115),
//--TRIMMABLE-BOUNDARY-START(274878562411),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389281899,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 408022548587,
        "f": 83886081
      },
      "n": "ReadWriteTimeout",
      "d": 655467,
      "h": 274878562411,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(274878562411),
//--TRIMMABLE-BOUNDARY-START(279173529707),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 188979216491,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 416612483179,
        "f": 83886081
      },
      "n": "RenameTo",
      "d": 655467,
      "h": 279173529707,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(279173529707),
//--TRIMMABLE-BOUNDARY-START(283468497003),
    {
      "p": 1703938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 197569151083,
        "f": 50364417
      },
      "n": "RequestUri",
      "d": 655467,
      "h": 283468497003,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(283468497003),
//--TRIMMABLE-BOUNDARY-START(287763464299),
    {
      "p": 1376363,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206159085675,
        "f": 50331649
      },
      "n": "ServicePoint",
      "d": 655467,
      "h": 287763464299,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(287763464299),
//--TRIMMABLE-BOUNDARY-START(455267188843),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214749020267,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 425202417771,
        "f": 83918849
      },
      "n": "Timeout",
      "d": 655467,
      "h": 455267188843,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(455267188843),
//--TRIMMABLE-BOUNDARY-START(459562156139),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223338954859,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 433792352363,
        "f": 83886081
      },
      "n": "UseBinary",
      "d": 655467,
      "h": 459562156139,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(459562156139),
//--TRIMMABLE-BOUNDARY-START(463857123435),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231928889451,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 442382286955,
        "f": 83918849
      },
      "n": "UseDefaultCredentials",
      "d": 655467,
      "h": 463857123435,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(463857123435),
//--TRIMMABLE-BOUNDARY-START(468152090731),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240518824043,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 450972221547,
        "f": 83886081
      },
      "n": "UsePassive",
      "d": 655467,
      "h": 468152090731,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(468152090731)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590590059),
    {
      "r": 65537,
      "n": "Abort",
      "d": 655467,
      "h": 8590590059,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590590059),
//--TRIMMABLE-BOUNDARY-START(12885557355),
    {
      "r": 90570753,
      "p": [
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginGetRequestStream",
      "d": 655467,
      "h": 12885557355,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885557355),
//--TRIMMABLE-BOUNDARY-START(17180524651),
    {
      "r": 90570753,
      "p": [
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginGetResponse",
      "d": 655467,
      "h": 17180524651,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180524651),
//--TRIMMABLE-BOUNDARY-START(55835230315),
    {
      "r": 95748097,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndGetRequestStream",
      "d": 655467,
      "h": 55835230315,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(55835230315),
//--TRIMMABLE-BOUNDARY-START(60130197611),
    {
      "r": 1966187,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndGetResponse",
      "d": 655467,
      "h": 60130197611,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(60130197611),
//--TRIMMABLE-BOUNDARY-START(244813791339),
    {
      "r": 95748097,
      "n": "GetRequestStream",
      "d": 655467,
      "h": 244813791339,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(244813791339),
//--TRIMMABLE-BOUNDARY-START(249108758635),
    {
      "r": 1966187,
      "n": "GetResponse",
      "d": 655467,
      "h": 249108758635,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(249108758635)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622763),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 655467,
      "h": 4295622763,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295622763)
  ],
  "h": 655467
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.FtpWebRequest`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}FtpWebRequest`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655467)
        
        

        //--TRIMMABLE-BOUNDARY-START(917611)
        $asm.$cls(`$snr.SN.HttpWebRequest`, ($self) => class HttpWebRequest extends $.$snr.SN.WebRequest
        {
            //--TRIMMABLE-BOUNDARY-START(4295884907)
            $ctor$4(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295884907);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295884907)
            
            //--TRIMMABLE-BOUNDARY-START(12885819499)
            /*string? */ get Accept()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914707563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set Accept(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(644246012011);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885819499)
            
            //--TRIMMABLE-BOUNDARY-START(51540525163)
            /*System.Uri */ get Address()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504642155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51540525163)
            
            //--TRIMMABLE-BOUNDARY-START(55835492459)
            /*bool */ get AllowAutoRedirect()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094576747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowAutoRedirect(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(652835946603);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55835492459)
            
            //--TRIMMABLE-BOUNDARY-START(60130459755)
            /*bool */ get AllowReadStreamBuffering()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684511339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowReadStreamBuffering(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(661425881195);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60130459755)
            
            //--TRIMMABLE-BOUNDARY-START(64425427051)
            /*bool */ get AllowWriteStreamBuffering()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274445931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowWriteStreamBuffering(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(670015815787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64425427051)
            
            //--TRIMMABLE-BOUNDARY-START(68720394347)
            /*System.Net.DecompressionMethods */ get AutomaticDecompression()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864380523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.DecompressionMethods */ set AutomaticDecompression(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(678605750379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68720394347)
            
            //--TRIMMABLE-BOUNDARY-START(81605296235)
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection */ get ClientCertificates()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454315115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection */ set ClientCertificates(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(687195684971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81605296235)
            
            //--TRIMMABLE-BOUNDARY-START(85900263531)
            /*string? */ get Connection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044249707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set Connection(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(695785619563);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(85900263531)
            
            //--TRIMMABLE-BOUNDARY-START(90195230827)
            /*string? */ get ConnectionGroupName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634184299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set ConnectionGroupName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(704375554155);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90195230827)
            
            //--TRIMMABLE-BOUNDARY-START(94490198123)
            /*long */ get ContentLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224118891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set ContentLength(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(712965488747);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(94490198123)
            
            //--TRIMMABLE-BOUNDARY-START(98785165419)
            /*string? */ get ContentType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814053483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set ContentType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(721555423339);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(98785165419)
            
            //--TRIMMABLE-BOUNDARY-START(103080132715)
            /*System.Net.HttpContinueDelegate? */ get ContinueDelegate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403988075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.HttpContinueDelegate? */ set ContinueDelegate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(730145357931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103080132715)
            
            //--TRIMMABLE-BOUNDARY-START(107375100011)
            /*int */ get ContinueTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993922667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ContinueTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(738735292523);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(107375100011)
            
            //--TRIMMABLE-BOUNDARY-START(111670067307)
            /*System.Net.CookieContainer? */ get CookieContainer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583857259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.CookieContainer? */ set CookieContainer(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(747325227115);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(111670067307)
            
            //--TRIMMABLE-BOUNDARY-START(115965034603)
            /*System.Net.ICredentials? */ get Credentials()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173791851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.ICredentials? */ set Credentials(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(755915161707);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115965034603)
            
            //--TRIMMABLE-BOUNDARY-START(120260001899)
            /*System.DateTime */ get Date()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763726443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ set Date(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(764505096299);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120260001899)
            
            //--TRIMMABLE-BOUNDARY-START(124554969195)
            static /*System.Net.Cache.RequestCachePolicy? */ get DefaultCachePolicy$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353661035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Cache.RequestCachePolicy? */ set DefaultCachePolicy$1(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(773095030891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(124554969195)
            
            //--TRIMMABLE-BOUNDARY-START(128849936491)
            static /*int */ get DefaultMaximumErrorResponseLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943595627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ set DefaultMaximumErrorResponseLength(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(781684965483);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(128849936491)
            
            //--TRIMMABLE-BOUNDARY-START(133144903787)
            static /*int */ get DefaultMaximumResponseHeadersLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533530219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            static /*int */ set DefaultMaximumResponseHeadersLength(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(790274900075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(133144903787)
            
            //--TRIMMABLE-BOUNDARY-START(150324772971)
            /*string? */ get Expect()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123464811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set Expect(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(798864834667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(150324772971)
            
            //--TRIMMABLE-BOUNDARY-START(558346666091)
            /*bool */ get HaveResponse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(330713399403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(558346666091)
            
            //--TRIMMABLE-BOUNDARY-START(562641633387)
            /*System.Net.WebHeaderCollection */ get Headers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(339303333995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.WebHeaderCollection */ set Headers(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(807454769259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(562641633387)
            
            //--TRIMMABLE-BOUNDARY-START(566936600683)
            /*string */ get Host()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(347893268587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Host(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(816044703851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(566936600683)
            
            //--TRIMMABLE-BOUNDARY-START(571231567979)
            /*System.DateTime */ get IfModifiedSince()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356483203179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.DateTime */ set IfModifiedSince(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(824634638443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(571231567979)
            
            //--TRIMMABLE-BOUNDARY-START(575526535275)
            /*bool */ get KeepAlive()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(365073137771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set KeepAlive(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(833224573035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(575526535275)
            
            //--TRIMMABLE-BOUNDARY-START(579821502571)
            /*int */ get MaximumAutomaticRedirections()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373663072363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set MaximumAutomaticRedirections(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(841814507627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(579821502571)
            
            //--TRIMMABLE-BOUNDARY-START(584116469867)
            /*int */ get MaximumResponseHeadersLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382253006955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set MaximumResponseHeadersLength(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(850404442219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(584116469867)
            
            //--TRIMMABLE-BOUNDARY-START(588411437163)
            /*string? */ get MediaType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842941547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set MediaType(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(858994376811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(588411437163)
            
            //--TRIMMABLE-BOUNDARY-START(592706404459)
            /*string */ get Method()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399432876139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Method(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(867584311403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(592706404459)
            
            //--TRIMMABLE-BOUNDARY-START(597001371755)
            /*bool */ get Pipelined()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022810731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Pipelined(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(876174245995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(597001371755)
            
            //--TRIMMABLE-BOUNDARY-START(601296339051)
            /*bool */ get PreAuthenticate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612745323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set PreAuthenticate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(884764180587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(601296339051)
            
            //--TRIMMABLE-BOUNDARY-START(605591306347)
            /*System.Version */ get ProtocolVersion()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(425202679915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Version */ set ProtocolVersion(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(893354115179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(605591306347)
            
            //--TRIMMABLE-BOUNDARY-START(609886273643)
            /*System.Net.IWebProxy? */ get Proxy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(433792614507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IWebProxy? */ set Proxy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(901944049771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(609886273643)
            
            //--TRIMMABLE-BOUNDARY-START(614181240939)
            /*int */ get ReadWriteTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(442382549099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadWriteTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(910533984363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(614181240939)
            
            //--TRIMMABLE-BOUNDARY-START(618476208235)
            /*string? */ get Referer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(450972483691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set Referer(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(919123918955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(618476208235)
            
            //--TRIMMABLE-BOUNDARY-START(622771175531)
            /*System.Uri */ get RequestUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(459562418283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(622771175531)
            
            //--TRIMMABLE-BOUNDARY-START(627066142827)
            /*bool */ get SendChunked()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(468152352875);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set SendChunked(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(927713853547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(627066142827)
            
            //--TRIMMABLE-BOUNDARY-START(631361110123)
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get ServerCertificateValidationCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(476742287467);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set ServerCertificateValidationCallback(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(936303788139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(631361110123)
            
            //--TRIMMABLE-BOUNDARY-START(635656077419)
            /*System.Net.ServicePoint */ get ServicePoint()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(485332222059);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(635656077419)
            
            //--TRIMMABLE-BOUNDARY-START(983548428395)
            /*bool */ get SupportsCookieContainer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(493922156651);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(983548428395)
            
            //--TRIMMABLE-BOUNDARY-START(992138362987)
            /*int */ get Timeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502512091243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set Timeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(944893722731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(992138362987)
            
            //--TRIMMABLE-BOUNDARY-START(996433330283)
            /*string? */ get TransferEncoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511102025835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TransferEncoding(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(953483657323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(996433330283)
            
            //--TRIMMABLE-BOUNDARY-START(1000728297579)
            /*bool */ get UnsafeAuthenticatedConnectionSharing()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(519691960427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UnsafeAuthenticatedConnectionSharing(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(962073591915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(1000728297579)
            
            //--TRIMMABLE-BOUNDARY-START(1005023264875)
            /*bool */ get UseDefaultCredentials()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528281895019);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseDefaultCredentials(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(970663526507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(1005023264875)
            
            //--TRIMMABLE-BOUNDARY-START(1009318232171)
            /*string? */ get UserAgent()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536871829611);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set UserAgent(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(979253461099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(1009318232171)
            
            //--TRIMMABLE-BOUNDARY-START(8590852203)
            /*void */ Abort()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590852203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590852203)
            
            //--TRIMMABLE-BOUNDARY-START(21475754091)
            /*void */ AddRange$1(/*int*/ range)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475754091);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21475754091)
            
            //--TRIMMABLE-BOUNDARY-START(17180786795)
            /*void */ AddRange(/*int*/ $from, /*int*/ to)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180786795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17180786795)
            
            //--TRIMMABLE-BOUNDARY-START(30065688683)
            /*void */ AddRange$3(/*long*/ range)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065688683);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30065688683)
            
            //--TRIMMABLE-BOUNDARY-START(25770721387)
            /*void */ AddRange$2(/*long*/ $from, /*long*/ to)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770721387);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25770721387)
            
            //--TRIMMABLE-BOUNDARY-START(38655623275)
            /*void */ AddRange$5(/*string*/ rangeSpecifier, /*int*/ range)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655623275);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38655623275)
            
            //--TRIMMABLE-BOUNDARY-START(34360655979)
            /*void */ AddRange$4(/*string*/ rangeSpecifier, /*int*/ $from, /*int*/ to)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360655979);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(34360655979)
            
            //--TRIMMABLE-BOUNDARY-START(47245557867)
            /*void */ AddRange$7(/*string*/ rangeSpecifier, /*long*/ range)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245557867);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47245557867)
            
            //--TRIMMABLE-BOUNDARY-START(42950590571)
            /*void */ AddRange$6(/*string*/ rangeSpecifier, /*long*/ $from, /*long*/ to)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950590571);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(42950590571)
            
            //--TRIMMABLE-BOUNDARY-START(73015361643)
            /*System.IAsyncResult */ BeginGetRequestStream(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015361643);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73015361643)
            
            //--TRIMMABLE-BOUNDARY-START(77310328939)
            /*System.IAsyncResult */ BeginGetResponse(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310328939);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77310328939)
            
            //--TRIMMABLE-BOUNDARY-START(141734838379)
            /*System.IO.Stream */ EndGetRequestStream(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734838379);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(141734838379)
            
            //--TRIMMABLE-BOUNDARY-START(137439871083)
            /*System.IO.Stream */ EndGetRequestStream$1(/*System.IAsyncResult*/ asyncResult, /*out System.Net.TransportContext?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137439871083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(137439871083)
            
            //--TRIMMABLE-BOUNDARY-START(146029805675)
            /*System.Net.WebResponse */ EndGetResponse(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146029805675);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(146029805675)
            
            //--TRIMMABLE-BOUNDARY-START(541166796907)
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(541166796907);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(541166796907)
            
            //--TRIMMABLE-BOUNDARY-START(545461764203)
            /*System.IO.Stream */ GetRequestStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545461764203);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(545461764203)
            
            //--TRIMMABLE-BOUNDARY-START(549756731499)
            /*System.IO.Stream */ GetRequestStream$1(/*out System.Net.TransportContext?*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(549756731499);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(549756731499)
            
            //--TRIMMABLE-BOUNDARY-START(554051698795)
            /*System.Net.WebResponse */ GetResponse()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(554051698795);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(554051698795)
            
            //--TRIMMABLE-BOUNDARY-START(987843395691)
            /*void */ SRS$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(987843395691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(987843395691)
            
            static $h = 917611;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$snr.SN.WebRequest; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885819499),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914707563,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 644246012011,
        "f": 83886081
      },
      "n": "Accept",
      "d": 917611,
      "h": 12885819499,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885819499),
//--TRIMMABLE-BOUNDARY-START(51540525163),
    {
      "p": 1703938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504642155,
        "f": 50331649
      },
      "n": "Address",
      "d": 917611,
      "h": 51540525163,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540525163),
//--TRIMMABLE-BOUNDARY-START(55835492459),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094576747,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 652835946603,
        "f": 83886209
      },
      "n": "AllowAutoRedirect",
      "d": 917611,
      "h": 55835492459,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(55835492459),
//--TRIMMABLE-BOUNDARY-START(60130459755),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684511339,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 661425881195,
        "f": 83886209
      },
      "n": "AllowReadStreamBuffering",
      "d": 917611,
      "h": 60130459755,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(60130459755),
//--TRIMMABLE-BOUNDARY-START(64425427051),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193274445931,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 670015815787,
        "f": 83886209
      },
      "n": "AllowWriteStreamBuffering",
      "d": 917611,
      "h": 64425427051,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(64425427051),
//--TRIMMABLE-BOUNDARY-START(68720394347),
    {
      "p": 2424879,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201864380523,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 678605750379,
        "f": 83886081
      },
      "n": "AutomaticDecompression",
      "d": 917611,
      "h": 68720394347,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720394347),
//--TRIMMABLE-BOUNDARY-START(81605296235),
    {
      "p": 28377118,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210454315115,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 687195684971,
        "f": 83886081
      },
      "n": "ClientCertificates",
      "d": 917611,
      "h": 81605296235,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605296235),
//--TRIMMABLE-BOUNDARY-START(85900263531),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219044249707,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 695785619563,
        "f": 83886081
      },
      "n": "Connection",
      "d": 917611,
      "h": 85900263531,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900263531),
//--TRIMMABLE-BOUNDARY-START(90195230827),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227634184299,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 704375554155,
        "f": 83918849
      },
      "n": "ConnectionGroupName",
      "d": 917611,
      "h": 90195230827,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(90195230827),
//--TRIMMABLE-BOUNDARY-START(94490198123),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236224118891,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 712965488747,
        "f": 83918849
      },
      "n": "ContentLength",
      "d": 917611,
      "h": 94490198123,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(94490198123),
//--TRIMMABLE-BOUNDARY-START(98785165419),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244814053483,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 721555423339,
        "f": 83918849
      },
      "n": "ContentType",
      "d": 917611,
      "h": 98785165419,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(98785165419),
//--TRIMMABLE-BOUNDARY-START(103080132715),
    {
      "p": 852075,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253403988075,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 730145357931,
        "f": 83886081
      },
      "n": "ContinueDelegate",
      "d": 917611,
      "h": 103080132715,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103080132715),
//--TRIMMABLE-BOUNDARY-START(107375100011),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261993922667,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 738735292523,
        "f": 83886081
      },
      "n": "ContinueTimeout",
      "d": 917611,
      "h": 107375100011,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(107375100011),
//--TRIMMABLE-BOUNDARY-START(111670067307),
    {
      "p": 1376303,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270583857259,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 747325227115,
        "f": 83886209
      },
      "n": "CookieContainer",
      "d": 917611,
      "h": 111670067307,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(111670067307),
//--TRIMMABLE-BOUNDARY-START(115965034603),
    {
      "p": 2883631,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279173791851,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 755915161707,
        "f": 83918849
      },
      "n": "Credentials",
      "d": 917611,
      "h": 115965034603,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(115965034603),
//--TRIMMABLE-BOUNDARY-START(120260001899),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287763726443,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 764505096299,
        "f": 83886081
      },
      "n": "Date",
      "d": 917611,
      "h": 120260001899,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120260001899),
//--TRIMMABLE-BOUNDARY-START(124554969195),
    {
      "p": 1048623,
      "g": {
        "r": 0,
        "d": 0,
        "h": 296353661035,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 773095030891,
        "f": 83886113
      },
      "n": "DefaultCachePolicy",
      "o": "@$1",
      "d": 917611,
      "h": 124554969195,
      "f": 538968097
    },
//--TRIMMABLE-BOUNDARY-END(124554969195),
//--TRIMMABLE-BOUNDARY-START(128849936491),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304943595627,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 781684965483,
        "f": 83886113
      },
      "n": "DefaultMaximumErrorResponseLength",
      "d": 917611,
      "h": 128849936491,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(128849936491),
//--TRIMMABLE-BOUNDARY-START(133144903787),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 313533530219,
        "f": 50331681
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 790274900075,
        "f": 83886113
      },
      "n": "DefaultMaximumResponseHeadersLength",
      "d": 917611,
      "h": 133144903787,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(133144903787),
//--TRIMMABLE-BOUNDARY-START(150324772971),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 322123464811,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 798864834667,
        "f": 83886081
      },
      "n": "Expect",
      "d": 917611,
      "h": 150324772971,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150324772971),
//--TRIMMABLE-BOUNDARY-START(558346666091),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 330713399403,
        "f": 50331777
      },
      "n": "HaveResponse",
      "d": 917611,
      "h": 558346666091,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(558346666091),
//--TRIMMABLE-BOUNDARY-START(562641633387),
    {
      "p": 589930,
      "g": {
        "r": 0,
        "d": 0,
        "h": 339303333995,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 807454769259,
        "f": 83918849
      },
      "n": "Headers",
      "d": 917611,
      "h": 562641633387,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(562641633387),
//--TRIMMABLE-BOUNDARY-START(566936600683),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 347893268587,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 816044703851,
        "f": 83886081
      },
      "n": "Host",
      "d": 917611,
      "h": 566936600683,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(566936600683),
//--TRIMMABLE-BOUNDARY-START(571231567979),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 356483203179,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 824634638443,
        "f": 83886081
      },
      "n": "IfModifiedSince",
      "d": 917611,
      "h": 571231567979,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(571231567979),
//--TRIMMABLE-BOUNDARY-START(575526535275),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 365073137771,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 833224573035,
        "f": 83886081
      },
      "n": "KeepAlive",
      "d": 917611,
      "h": 575526535275,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(575526535275),
//--TRIMMABLE-BOUNDARY-START(579821502571),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 373663072363,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 841814507627,
        "f": 83886081
      },
      "n": "MaximumAutomaticRedirections",
      "d": 917611,
      "h": 579821502571,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(579821502571),
//--TRIMMABLE-BOUNDARY-START(584116469867),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 382253006955,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 850404442219,
        "f": 83886081
      },
      "n": "MaximumResponseHeadersLength",
      "d": 917611,
      "h": 584116469867,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(584116469867),
//--TRIMMABLE-BOUNDARY-START(588411437163),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 390842941547,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 858994376811,
        "f": 83886081
      },
      "n": "MediaType",
      "d": 917611,
      "h": 588411437163,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(588411437163),
//--TRIMMABLE-BOUNDARY-START(592706404459),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 399432876139,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 867584311403,
        "f": 83918849
      },
      "n": "Method",
      "d": 917611,
      "h": 592706404459,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(592706404459),
//--TRIMMABLE-BOUNDARY-START(597001371755),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 408022810731,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 876174245995,
        "f": 83886081
      },
      "n": "Pipelined",
      "d": 917611,
      "h": 597001371755,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(597001371755),
//--TRIMMABLE-BOUNDARY-START(601296339051),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 416612745323,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 884764180587,
        "f": 83918849
      },
      "n": "PreAuthenticate",
      "d": 917611,
      "h": 601296339051,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(601296339051),
//--TRIMMABLE-BOUNDARY-START(605591306347),
    {
      "p": 190644225,
      "g": {
        "r": 0,
        "d": 0,
        "h": 425202679915,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 893354115179,
        "f": 83886081
      },
      "n": "ProtocolVersion",
      "d": 917611,
      "h": 605591306347,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(605591306347),
//--TRIMMABLE-BOUNDARY-START(609886273643),
    {
      "p": 3538991,
      "g": {
        "r": 0,
        "d": 0,
        "h": 433792614507,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 901944049771,
        "f": 83918849
      },
      "n": "Proxy",
      "d": 917611,
      "h": 609886273643,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(609886273643),
//--TRIMMABLE-BOUNDARY-START(614181240939),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 442382549099,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 910533984363,
        "f": 83886081
      },
      "n": "ReadWriteTimeout",
      "d": 917611,
      "h": 614181240939,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(614181240939),
//--TRIMMABLE-BOUNDARY-START(618476208235),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 450972483691,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 919123918955,
        "f": 83886081
      },
      "n": "Referer",
      "d": 917611,
      "h": 618476208235,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(618476208235),
//--TRIMMABLE-BOUNDARY-START(622771175531),
    {
      "p": 1703938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 459562418283,
        "f": 50364417
      },
      "n": "RequestUri",
      "d": 917611,
      "h": 622771175531,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(622771175531),
//--TRIMMABLE-BOUNDARY-START(627066142827),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 468152352875,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 927713853547,
        "f": 83886081
      },
      "n": "SendChunked",
      "d": 917611,
      "h": 627066142827,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(627066142827),
//--TRIMMABLE-BOUNDARY-START(631361110123),
    {
      "p": 720946,
      "g": {
        "r": 0,
        "d": 0,
        "h": 476742287467,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 936303788139,
        "f": 83886081
      },
      "n": "ServerCertificateValidationCallback",
      "d": 917611,
      "h": 631361110123,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(631361110123),
//--TRIMMABLE-BOUNDARY-START(635656077419),
    {
      "p": 1376363,
      "g": {
        "r": 0,
        "d": 0,
        "h": 485332222059,
        "f": 50331649
      },
      "n": "ServicePoint",
      "d": 917611,
      "h": 635656077419,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(635656077419),
//--TRIMMABLE-BOUNDARY-START(983548428395),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 493922156651,
        "f": 50331777
      },
      "n": "SupportsCookieContainer",
      "d": 917611,
      "h": 983548428395,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(983548428395),
//--TRIMMABLE-BOUNDARY-START(992138362987),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 502512091243,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 944893722731,
        "f": 83918849
      },
      "n": "Timeout",
      "d": 917611,
      "h": 992138362987,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(992138362987),
//--TRIMMABLE-BOUNDARY-START(996433330283),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 511102025835,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 953483657323,
        "f": 83886081
      },
      "n": "TransferEncoding",
      "d": 917611,
      "h": 996433330283,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(996433330283),
//--TRIMMABLE-BOUNDARY-START(1000728297579),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 519691960427,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 962073591915,
        "f": 83886081
      },
      "n": "UnsafeAuthenticatedConnectionSharing",
      "d": 917611,
      "h": 1000728297579,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1000728297579),
//--TRIMMABLE-BOUNDARY-START(1005023264875),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 528281895019,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 970663526507,
        "f": 83918849
      },
      "n": "UseDefaultCredentials",
      "d": 917611,
      "h": 1005023264875,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(1005023264875),
//--TRIMMABLE-BOUNDARY-START(1009318232171),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 536871829611,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 979253461099,
        "f": 83886081
      },
      "n": "UserAgent",
      "d": 917611,
      "h": 1009318232171,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(1009318232171)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590852203),
    {
      "r": 65537,
      "n": "Abort",
      "d": 917611,
      "h": 8590852203,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590852203),
//--TRIMMABLE-BOUNDARY-START(21475754091),
    {
      "r": 65537,
      "p": [
        {
          "n": "range",
          "p": 655361
        }
      ],
      "n": "AddRange",
      "o": "@$1",
      "d": 917611,
      "h": 21475754091,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475754091),
//--TRIMMABLE-BOUNDARY-START(17180786795),
    {
      "r": 65537,
      "p": [
        {
          "n": "from",
          "p": 655361
        },
        {
          "n": "to",
          "p": 655361
        }
      ],
      "n": "AddRange",
      "d": 917611,
      "h": 17180786795,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786795),
//--TRIMMABLE-BOUNDARY-START(30065688683),
    {
      "r": 65537,
      "p": [
        {
          "n": "range",
          "p": 917505
        }
      ],
      "n": "AddRange",
      "o": "@$3",
      "d": 917611,
      "h": 30065688683,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065688683),
//--TRIMMABLE-BOUNDARY-START(25770721387),
    {
      "r": 65537,
      "p": [
        {
          "n": "from",
          "p": 917505
        },
        {
          "n": "to",
          "p": 917505
        }
      ],
      "n": "AddRange",
      "o": "@$2",
      "d": 917611,
      "h": 25770721387,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770721387),
//--TRIMMABLE-BOUNDARY-START(38655623275),
    {
      "r": 65537,
      "p": [
        {
          "n": "rangeSpecifier",
          "p": 1310721
        },
        {
          "n": "range",
          "p": 655361
        }
      ],
      "n": "AddRange",
      "o": "@$5",
      "d": 917611,
      "h": 38655623275,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(38655623275),
//--TRIMMABLE-BOUNDARY-START(34360655979),
    {
      "r": 65537,
      "p": [
        {
          "n": "rangeSpecifier",
          "p": 1310721
        },
        {
          "n": "from",
          "p": 655361
        },
        {
          "n": "to",
          "p": 655361
        }
      ],
      "n": "AddRange",
      "o": "@$4",
      "d": 917611,
      "h": 34360655979,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(34360655979),
//--TRIMMABLE-BOUNDARY-START(47245557867),
    {
      "r": 65537,
      "p": [
        {
          "n": "rangeSpecifier",
          "p": 1310721
        },
        {
          "n": "range",
          "p": 917505
        }
      ],
      "n": "AddRange",
      "o": "@$7",
      "d": 917611,
      "h": 47245557867,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(47245557867),
//--TRIMMABLE-BOUNDARY-START(42950590571),
    {
      "r": 65537,
      "p": [
        {
          "n": "rangeSpecifier",
          "p": 1310721
        },
        {
          "n": "from",
          "p": 917505
        },
        {
          "n": "to",
          "p": 917505
        }
      ],
      "n": "AddRange",
      "o": "@$6",
      "d": 917611,
      "h": 42950590571,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950590571),
//--TRIMMABLE-BOUNDARY-START(73015361643),
    {
      "r": 90570753,
      "p": [
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginGetRequestStream",
      "d": 917611,
      "h": 73015361643,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015361643),
//--TRIMMABLE-BOUNDARY-START(77310328939),
    {
      "r": 90570753,
      "p": [
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "state",
          "p": 131073
        }
      ],
      "n": "BeginGetResponse",
      "d": 917611,
      "h": 77310328939,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(77310328939),
//--TRIMMABLE-BOUNDARY-START(141734838379),
    {
      "r": 95748097,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndGetRequestStream",
      "d": 917611,
      "h": 141734838379,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(141734838379),
//--TRIMMABLE-BOUNDARY-START(137439871083),
    {
      "r": 95748097,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        },
        {
          "n": "context",
          "p": 4980783,
          "f": 2
        }
      ],
      "n": "EndGetRequestStream",
      "o": "@$1",
      "d": 917611,
      "h": 137439871083,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(137439871083),
//--TRIMMABLE-BOUNDARY-START(146029805675),
    {
      "r": 1966187,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndGetResponse",
      "d": 917611,
      "h": 146029805675,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(146029805675),
//--TRIMMABLE-BOUNDARY-START(541166796907),
    {
      "r": 65537,
      "p": [
        {
          "n": "serializationInfo",
          "p": 158859265
        },
        {
          "n": "streamingContext",
          "p": 158990337
        }
      ],
      "n": "GetObjectData",
      "d": 917611,
      "h": 541166796907,
      "f": 16809988,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "Serialization has been deprecated for HttpWebRequest.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(541166796907),
//--TRIMMABLE-BOUNDARY-START(545461764203),
    {
      "r": 95748097,
      "n": "GetRequestStream",
      "d": 917611,
      "h": 545461764203,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(545461764203),
//--TRIMMABLE-BOUNDARY-START(549756731499),
    {
      "r": 95748097,
      "p": [
        {
          "n": "context",
          "p": 4980783,
          "f": 2
        }
      ],
      "n": "GetRequestStream",
      "o": "@$1",
      "d": 917611,
      "h": 549756731499,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(549756731499),
//--TRIMMABLE-BOUNDARY-START(554051698795),
    {
      "r": 1966187,
      "n": "GetResponse",
      "d": 917611,
      "h": 554051698795,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(554051698795)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295884907),
    {
      "p": [
        {
          "n": "serializationInfo",
          "p": 158859265
        },
        {
          "n": "streamingContext",
          "p": 158990337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 917611,
      "h": 4295884907,
      "f": 16777220,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "WebRequest, HttpWebRequest, ServicePoint, and WebClient are obsolete. Use HttpClient instead.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0014",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        },
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295884907)
  ],
  "h": 917611
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.HttpWebRequest`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}HttpWebRequest`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917611)
        
        

        //--TRIMMABLE-BOUNDARY-START(524395)
        $asm.$cls(`$snr.SN.FileWebResponse`, ($self) => class FileWebResponse extends $.$snr.SN.WebResponse
        {
            //--TRIMMABLE-BOUNDARY-START(4295491691)
            $ctor$4(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295491691);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491691)
            
            //--TRIMMABLE-BOUNDARY-START(12885426283)
            /*long */ get ContentLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770328171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885426283)
            
            //--TRIMMABLE-BOUNDARY-START(17180393579)
            /*string */ get ContentType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360262763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180393579)
            
            //--TRIMMABLE-BOUNDARY-START(73014968427)
            /*System.Net.WebHeaderCollection */ get Headers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950197355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73014968427)
            
            //--TRIMMABLE-BOUNDARY-START(77309935723)
            /*System.Uri */ get ResponseUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540131947);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77309935723)
            
            //--TRIMMABLE-BOUNDARY-START(81604903019)
            /*bool */ get SupportsHeaders()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130066539);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81604903019)
            
            //--TRIMMABLE-BOUNDARY-START(8590458987)
            /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590458987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590458987)
            
            //--TRIMMABLE-BOUNDARY-START(64425033835)
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425033835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(64425033835)
            
            //--TRIMMABLE-BOUNDARY-START(68720001131)
            /*System.IO.Stream */ GetResponseStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720001131);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68720001131)
            
            //--TRIMMABLE-BOUNDARY-START(85899870315)
            /*void */ SRS$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899870315);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(85899870315)
            
            static $h = 524395;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$snr.SN.WebResponse; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885426283),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770328171,
        "f": 50364417
      },
      "n": "ContentLength",
      "d": 524395,
      "h": 12885426283,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(12885426283),
//--TRIMMABLE-BOUNDARY-START(17180393579),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360262763,
        "f": 50364417
      },
      "n": "ContentType",
      "d": 524395,
      "h": 17180393579,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180393579),
//--TRIMMABLE-BOUNDARY-START(73014968427),
    {
      "p": 589930,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950197355,
        "f": 50364417
      },
      "n": "Headers",
      "d": 524395,
      "h": 73014968427,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(73014968427),
//--TRIMMABLE-BOUNDARY-START(77309935723),
    {
      "p": 1703938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540131947,
        "f": 50364417
      },
      "n": "ResponseUri",
      "d": 524395,
      "h": 77309935723,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(77309935723),
//--TRIMMABLE-BOUNDARY-START(81604903019),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130066539,
        "f": 50364417
      },
      "n": "SupportsHeaders",
      "d": 524395,
      "h": 81604903019,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(81604903019)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590458987),
    {
      "r": 65537,
      "n": "Close",
      "d": 524395,
      "h": 8590458987,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(8590458987),
//--TRIMMABLE-BOUNDARY-START(64425033835),
    {
      "r": 65537,
      "p": [
        {
          "n": "serializationInfo",
          "p": 158859265
        },
        {
          "n": "streamingContext",
          "p": 158990337
        }
      ],
      "n": "GetObjectData",
      "d": 524395,
      "h": 64425033835,
      "f": 16809988,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "Serialization has been deprecated for FileWebResponse.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(64425033835),
//--TRIMMABLE-BOUNDARY-START(68720001131),
    {
      "r": 95748097,
      "n": "GetResponseStream",
      "d": 524395,
      "h": 68720001131,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(68720001131)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491691),
    {
      "p": [
        {
          "n": "serializationInfo",
          "p": 158859265
        },
        {
          "n": "streamingContext",
          "p": 158990337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 524395,
      "h": 4295491691,
      "f": 16777220,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "Serialization has been deprecated for FileWebResponse.",
              "t": 1310721
            }
          ]
        },
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295491691)
  ],
  "h": 524395
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.FileWebResponse`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}FileWebResponse`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524395)
        
        

        //--TRIMMABLE-BOUNDARY-START(721003)
        $asm.$cls(`$snr.SN.FtpWebResponse`, ($self) => class FtpWebResponse extends $.$snr.SN.WebResponse
        {
            //--TRIMMABLE-BOUNDARY-START(4295688299)
            $ctor$4()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295688299);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295688299)
            
            //--TRIMMABLE-BOUNDARY-START(8590655595)
            /*string? */ get BannerMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065492075);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590655595)
            
            //--TRIMMABLE-BOUNDARY-START(17180590187)
            /*long */ get ContentLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655426667);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180590187)
            
            //--TRIMMABLE-BOUNDARY-START(21475557483)
            /*string? */ get ExitMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245361259);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475557483)
            
            //--TRIMMABLE-BOUNDARY-START(115964837995)
            /*System.Net.WebHeaderCollection */ get Headers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835295851);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115964837995)
            
            //--TRIMMABLE-BOUNDARY-START(120259805291)
            /*System.DateTime */ get LastModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425230443);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120259805291)
            
            //--TRIMMABLE-BOUNDARY-START(124554772587)
            /*System.Uri */ get ResponseUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015165035);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(124554772587)
            
            //--TRIMMABLE-BOUNDARY-START(128849739883)
            /*System.Net.FtpStatusCode */ get StatusCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605099627);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(128849739883)
            
            //--TRIMMABLE-BOUNDARY-START(133144707179)
            /*string? */ get StatusDescription()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195034219);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(133144707179)
            
            //--TRIMMABLE-BOUNDARY-START(137439674475)
            /*bool */ get SupportsHeaders()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784968811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(137439674475)
            
            //--TRIMMABLE-BOUNDARY-START(141734641771)
            /*string? */ get WelcomeMessage()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374903403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(141734641771)
            
            //--TRIMMABLE-BOUNDARY-START(12885622891)
            /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885622891);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12885622891)
            
            //--TRIMMABLE-BOUNDARY-START(111669870699)
            /*System.IO.Stream */ GetResponseStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669870699);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(111669870699)
            
            //--TRIMMABLE-BOUNDARY-START(4295688299)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295688299)
            
            static $h = 721003;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$snr.SN.WebResponse; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590655595),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065492075,
        "f": 50331649
      },
      "n": "BannerMessage",
      "d": 721003,
      "h": 8590655595,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590655595),
//--TRIMMABLE-BOUNDARY-START(17180590187),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655426667,
        "f": 50364417
      },
      "n": "ContentLength",
      "d": 721003,
      "h": 17180590187,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(17180590187),
//--TRIMMABLE-BOUNDARY-START(21475557483),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245361259,
        "f": 50331649
      },
      "n": "ExitMessage",
      "d": 721003,
      "h": 21475557483,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475557483),
//--TRIMMABLE-BOUNDARY-START(115964837995),
    {
      "p": 589930,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835295851,
        "f": 50364417
      },
      "n": "Headers",
      "d": 721003,
      "h": 115964837995,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(115964837995),
//--TRIMMABLE-BOUNDARY-START(120259805291),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425230443,
        "f": 50331649
      },
      "n": "LastModified",
      "d": 721003,
      "h": 120259805291,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259805291),
//--TRIMMABLE-BOUNDARY-START(124554772587),
    {
      "p": 1703938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015165035,
        "f": 50364417
      },
      "n": "ResponseUri",
      "d": 721003,
      "h": 124554772587,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(124554772587),
//--TRIMMABLE-BOUNDARY-START(128849739883),
    {
      "p": 589931,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605099627,
        "f": 50331649
      },
      "n": "StatusCode",
      "d": 721003,
      "h": 128849739883,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849739883),
//--TRIMMABLE-BOUNDARY-START(133144707179),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195034219,
        "f": 50331649
      },
      "n": "StatusDescription",
      "d": 721003,
      "h": 133144707179,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144707179),
//--TRIMMABLE-BOUNDARY-START(137439674475),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98784968811,
        "f": 50364417
      },
      "n": "SupportsHeaders",
      "d": 721003,
      "h": 137439674475,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439674475),
//--TRIMMABLE-BOUNDARY-START(141734641771),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107374903403,
        "f": 50331649
      },
      "n": "WelcomeMessage",
      "d": 721003,
      "h": 141734641771,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141734641771)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885622891),
    {
      "r": 65537,
      "n": "Close",
      "d": 721003,
      "h": 12885622891,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12885622891),
//--TRIMMABLE-BOUNDARY-START(111669870699),
    {
      "r": 95748097,
      "n": "GetResponseStream",
      "d": 721003,
      "h": 111669870699,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(111669870699)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688299),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 721003,
      "h": 4295688299,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295688299)
  ],
  "h": 721003
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable, $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.FtpWebResponse`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}FtpWebResponse`; }
        });
        //--TRIMMABLE-BOUNDARY-END(721003)
        
        

        //--TRIMMABLE-BOUNDARY-START(852075)
        $asm.$cls(`$snr.SN.HttpContinueDelegate`, ($self) => class HttpContinueDelegate extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*void*/ Invoke(/*$.$$.S.Int32*/ StatusCode, /*$.$snwh.SN.WebHeaderCollection*/ httpHeaders)
            {
                return this.$nativeFunction.call(this.$target, StatusCode, httpHeaders);
            }
            static $h = 852075;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180721259),
    {
      "r": 65537,
      "p": [
        {
          "n": "StatusCode",
          "p": 655361
        },
        {
          "n": "httpHeaders",
          "p": 589930
        }
      ],
      "n": "Invoke",
      "d": 852075,
      "h": 17180721259,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180721259),
//--TRIMMABLE-BOUNDARY-START(8590786667),
    {
      "r": 90570753,
      "p": [
        {
          "n": "StatusCode",
          "p": 655361
        },
        {
          "n": "httpHeaders",
          "p": 589930
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 852075,
      "h": 8590786667,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590786667),
//--TRIMMABLE-BOUNDARY-START(12885753963),
    {
      "r": 65537,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 852075,
      "h": 12885753963,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885753963)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819371),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 852075,
      "h": 4295819371,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819371)
  ],
  "h": 852075
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.HttpContinueDelegate`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}HttpContinueDelegate`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852075)
        
        

        //--TRIMMABLE-BOUNDARY-START(983147)
        $asm.$cls(`$snr.SN.HttpWebResponse`, ($self) => class HttpWebResponse extends $.$snr.SN.WebResponse
        {
            //--TRIMMABLE-BOUNDARY-START(4295950443)
            $ctor$4()
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295950443);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295950443)
            
            //--TRIMMABLE-BOUNDARY-START(8590917739)
            $ctor$5(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590917739);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590917739)
            
            //--TRIMMABLE-BOUNDARY-START(12885885035)
            /*string? */ get CharacterSet()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245623403);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885885035)
            
            //--TRIMMABLE-BOUNDARY-START(21475819627)
            /*string */ get ContentEncoding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835557995);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475819627)
            
            //--TRIMMABLE-BOUNDARY-START(25770786923)
            /*long */ get ContentLength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425492587);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770786923)
            
            //--TRIMMABLE-BOUNDARY-START(30065754219)
            /*string */ get ContentType()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015427179);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065754219)
            
            //--TRIMMABLE-BOUNDARY-START(34360721515)
            /*System.Net.CookieCollection */ get Cookies()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605361771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.CookieCollection */ set Cookies(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044315243);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360721515)
            
            //--TRIMMABLE-BOUNDARY-START(184684576875)
            /*System.Net.WebHeaderCollection */ get Headers()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195296363);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(184684576875)
            
            //--TRIMMABLE-BOUNDARY-START(188979544171)
            /*bool */ get IsMutuallyAuthenticated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785230955);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(188979544171)
            
            //--TRIMMABLE-BOUNDARY-START(193274511467)
            /*System.DateTime */ get LastModified()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375165547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(193274511467)
            
            //--TRIMMABLE-BOUNDARY-START(197569478763)
            /*string */ get Method()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965100139);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(197569478763)
            
            //--TRIMMABLE-BOUNDARY-START(201864446059)
            /*System.Version */ get ProtocolVersion()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555034731);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(201864446059)
            
            //--TRIMMABLE-BOUNDARY-START(206159413355)
            /*System.Uri */ get ResponseUri()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144969323);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(206159413355)
            
            //--TRIMMABLE-BOUNDARY-START(210454380651)
            /*string */ get Server()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734903915);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(210454380651)
            
            //--TRIMMABLE-BOUNDARY-START(223339282539)
            /*System.Net.HttpStatusCode */ get StatusCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324838507);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(223339282539)
            
            //--TRIMMABLE-BOUNDARY-START(227634249835)
            /*string */ get StatusDescription()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914773099);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(227634249835)
            
            //--TRIMMABLE-BOUNDARY-START(231929217131)
            /*bool */ get SupportsHeaders()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504707691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(231929217131)
            
            //--TRIMMABLE-BOUNDARY-START(17180852331)
            /*void */ Close()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180852331);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17180852331)
            
            //--TRIMMABLE-BOUNDARY-START(38655688811)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655688811);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38655688811)
            
            //--TRIMMABLE-BOUNDARY-START(171799674987)
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799674987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(171799674987)
            
            //--TRIMMABLE-BOUNDARY-START(176094642283)
            /*string */ GetResponseHeader(/*string*/ headerName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094642283);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(176094642283)
            
            //--TRIMMABLE-BOUNDARY-START(180389609579)
            /*System.IO.Stream */ GetResponseStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389609579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(180389609579)
            
            //--TRIMMABLE-BOUNDARY-START(236224184427)
            /*void */ SRS$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224184427);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(236224184427)
            
            //--TRIMMABLE-BOUNDARY-START(4295950443)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$4();
            }
            //--TRIMMABLE-BOUNDARY-END(4295950443)
            
            static $h = 983147;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$snr.SN.WebResponse; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(12885885035),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245623403,
        "f": 50331649
      },
      "n": "CharacterSet",
      "d": 983147,
      "h": 12885885035,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885885035),
//--TRIMMABLE-BOUNDARY-START(21475819627),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835557995,
        "f": 50331649
      },
      "n": "ContentEncoding",
      "d": 983147,
      "h": 21475819627,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475819627),
//--TRIMMABLE-BOUNDARY-START(25770786923),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425492587,
        "f": 50364417
      },
      "n": "ContentLength",
      "d": 983147,
      "h": 25770786923,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(25770786923),
//--TRIMMABLE-BOUNDARY-START(30065754219),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015427179,
        "f": 50364417
      },
      "n": "ContentType",
      "d": 983147,
      "h": 30065754219,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(30065754219),
//--TRIMMABLE-BOUNDARY-START(34360721515),
    {
      "p": 1179695,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605361771,
        "f": 50331777
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044315243,
        "f": 83886209
      },
      "n": "Cookies",
      "d": 983147,
      "h": 34360721515,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(34360721515),
//--TRIMMABLE-BOUNDARY-START(184684576875),
    {
      "p": 589930,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195296363,
        "f": 50364417
      },
      "n": "Headers",
      "d": 983147,
      "h": 184684576875,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(184684576875),
//--TRIMMABLE-BOUNDARY-START(188979544171),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785230955,
        "f": 50364417
      },
      "n": "IsMutuallyAuthenticated",
      "d": 983147,
      "h": 188979544171,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(188979544171),
//--TRIMMABLE-BOUNDARY-START(193274511467),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375165547,
        "f": 50331649
      },
      "n": "LastModified",
      "d": 983147,
      "h": 193274511467,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274511467),
//--TRIMMABLE-BOUNDARY-START(197569478763),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965100139,
        "f": 50331777
      },
      "n": "Method",
      "d": 983147,
      "h": 197569478763,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(197569478763),
//--TRIMMABLE-BOUNDARY-START(201864446059),
    {
      "p": 190644225,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555034731,
        "f": 50331649
      },
      "n": "ProtocolVersion",
      "d": 983147,
      "h": 201864446059,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(201864446059),
//--TRIMMABLE-BOUNDARY-START(206159413355),
    {
      "p": 1703938,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133144969323,
        "f": 50364417
      },
      "n": "ResponseUri",
      "d": 983147,
      "h": 206159413355,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(206159413355),
//--TRIMMABLE-BOUNDARY-START(210454380651),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734903915,
        "f": 50331649
      },
      "n": "Server",
      "d": 983147,
      "h": 210454380651,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(210454380651),
//--TRIMMABLE-BOUNDARY-START(223339282539),
    {
      "p": 2752559,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324838507,
        "f": 50331777
      },
      "n": "StatusCode",
      "d": 983147,
      "h": 223339282539,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(223339282539),
//--TRIMMABLE-BOUNDARY-START(227634249835),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914773099,
        "f": 50331777
      },
      "n": "StatusDescription",
      "d": 983147,
      "h": 227634249835,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(227634249835),
//--TRIMMABLE-BOUNDARY-START(231929217131),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504707691,
        "f": 50364417
      },
      "n": "SupportsHeaders",
      "d": 983147,
      "h": 231929217131,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(231929217131)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180852331),
    {
      "r": 65537,
      "n": "Close",
      "d": 983147,
      "h": 17180852331,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(17180852331),
//--TRIMMABLE-BOUNDARY-START(38655688811),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 983147,
      "h": 38655688811,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(38655688811),
//--TRIMMABLE-BOUNDARY-START(171799674987),
    {
      "r": 65537,
      "p": [
        {
          "n": "serializationInfo",
          "p": 158859265
        },
        {
          "n": "streamingContext",
          "p": 158990337
        }
      ],
      "n": "GetObjectData",
      "d": 983147,
      "h": 171799674987,
      "f": 16809988,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "Serialization has been deprecated for HttpWebResponse.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(171799674987),
//--TRIMMABLE-BOUNDARY-START(176094642283),
    {
      "r": 1310721,
      "p": [
        {
          "n": "headerName",
          "p": 1310721
        }
      ],
      "n": "GetResponseHeader",
      "d": 983147,
      "h": 176094642283,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(176094642283),
//--TRIMMABLE-BOUNDARY-START(180389609579),
    {
      "r": 95748097,
      "n": "GetResponseStream",
      "d": 983147,
      "h": 180389609579,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180389609579)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295950443),
    {
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 983147,
      "h": 4295950443,
      "f": 16777217,
      "a": [
        {
          "t": 104464385,
          "c": 25874268161,
          "a": [
            {
              "v": "This API supports the .NET infrastructure and is not intended to be used directly from your code.",
              "t": 1310721
            },
            {
              "v": true,
              "t": 262145
            }
          ]
        },
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295950443),
//--TRIMMABLE-BOUNDARY-START(8590917739),
    {
      "p": [
        {
          "n": "serializationInfo",
          "p": 158859265
        },
        {
          "n": "streamingContext",
          "p": 158990337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 983147,
      "h": 8590917739,
      "f": 16777220,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "Serialization has been deprecated for HttpWebResponse.",
              "t": 1310721
            }
          ]
        },
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590917739)
  ],
  "h": 983147
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.HttpWebResponse`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}HttpWebResponse`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983147)
        
        

        //--TRIMMABLE-BOUNDARY-START(196715)
        $asm.$cls(`$snr.SN.BindIPEndPoint`, ($self) => class BindIPEndPoint extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*System.Net.IPEndPoint*/ Invoke(/*$.$snr.SN.ServicePoint*/ servicePoint, /*$.$snp.SN.IPEndPoint*/ remoteEndPoint, /*$.$$.S.Int32*/ retryCount)
            {
                return this.$nativeFunction.call(this.$target, servicePoint, remoteEndPoint, retryCount);
            }
            static $h = 196715;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180065899),
    {
      "r": 3276847,
      "p": [
        {
          "n": "servicePoint",
          "p": 1376363
        },
        {
          "n": "remoteEndPoint",
          "p": 3276847
        },
        {
          "n": "retryCount",
          "p": 655361
        }
      ],
      "n": "Invoke",
      "d": 196715,
      "h": 17180065899,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180065899),
//--TRIMMABLE-BOUNDARY-START(8590131307),
    {
      "r": 90570753,
      "p": [
        {
          "n": "servicePoint",
          "p": 1376363
        },
        {
          "n": "remoteEndPoint",
          "p": 3276847
        },
        {
          "n": "retryCount",
          "p": 655361
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 196715,
      "h": 8590131307,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590131307),
//--TRIMMABLE-BOUNDARY-START(12885098603),
    {
      "r": 3276847,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 196715,
      "h": 12885098603,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885098603)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295164011),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 196715,
      "h": 4295164011,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295164011)
  ],
  "h": 196715
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.BindIPEndPoint`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}BindIPEndPoint`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196715)
        
        

        //--TRIMMABLE-BOUNDARY-START(589931)
        $asm.$str(`$snr.SN.FtpStatusCode`, ($self) => class FtpStatusCode extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Undefined = 0;
            static RestartMarker = 110;
            static ServiceTemporarilyNotAvailable = 120;
            static DataAlreadyOpen = 125;
            static OpeningData = 150;
            static CommandOK = 200;
            static CommandExtraneous = 202;
            static DirectoryStatus = 212;
            static FileStatus = 213;
            static SystemType = 215;
            static SendUserCommand = 220;
            static ClosingControl = 221;
            static ClosingData = 226;
            static EnteringPassive = 227;
            static LoggedInProceed = 230;
            static ServerWantsSecureSession = 234;
            static FileActionOK = 250;
            static PathnameCreated = 257;
            static SendPasswordCommand = 331;
            static NeedLoginAccount = 332;
            static FileCommandPending = 350;
            static ServiceNotAvailable = 421;
            static CantOpenData = 425;
            static ConnectionClosed = 426;
            static ActionNotTakenFileUnavailableOrBusy = 450;
            static ActionAbortedLocalProcessingError = 451;
            static ActionNotTakenInsufficientSpace = 452;
            static CommandSyntaxError = 500;
            static ArgumentSyntaxError = 501;
            static CommandNotImplemented = 502;
            static BadCommandSequence = 503;
            static NotLoggedIn = 530;
            static AccountNeeded = 532;
            static ActionNotTakenFileUnavailable = 550;
            static ActionAbortedUnknownPageType = 551;
            static FileActionAborted = 552;
            static ActionNotTakenFilenameNotAllowed = 553;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(589931);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Undefined": 0n,
                    "RestartMarker": 110n,
                    "ServiceTemporarilyNotAvailable": 120n,
                    "DataAlreadyOpen": 125n,
                    "OpeningData": 150n,
                    "CommandOK": 200n,
                    "CommandExtraneous": 202n,
                    "DirectoryStatus": 212n,
                    "FileStatus": 213n,
                    "SystemType": 215n,
                    "SendUserCommand": 220n,
                    "ClosingControl": 221n,
                    "ClosingData": 226n,
                    "EnteringPassive": 227n,
                    "LoggedInProceed": 230n,
                    "ServerWantsSecureSession": 234n,
                    "FileActionOK": 250n,
                    "PathnameCreated": 257n,
                    "SendPasswordCommand": 331n,
                    "NeedLoginAccount": 332n,
                    "FileCommandPending": 350n,
                    "ServiceNotAvailable": 421n,
                    "CantOpenData": 425n,
                    "ConnectionClosed": 426n,
                    "ActionNotTakenFileUnavailableOrBusy": 450n,
                    "ActionAbortedLocalProcessingError": 451n,
                    "ActionNotTakenInsufficientSpace": 452n,
                    "CommandSyntaxError": 500n,
                    "ArgumentSyntaxError": 501n,
                    "CommandNotImplemented": 502n,
                    "BadCommandSequence": 503n,
                    "NotLoggedIn": 530n,
                    "AccountNeeded": 532n,
                    "ActionNotTakenFileUnavailable": 550n,
                    "ActionAbortedUnknownPageType": 551n,
                    "FileActionAborted": 552n,
                    "ActionNotTakenFilenameNotAllowed": 553n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295557227)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295557227);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557227)
            
            //--TRIMMABLE-BOUNDARY-START(4295557227)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295557227)
            
            static $h = 589931;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(163209347179),
    {
      "t": 589931,
      "n": "Undefined",
      "d": 589931,
      "h": 163209347179,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163209347179),
//--TRIMMABLE-BOUNDARY-START(133144576107),
    {
      "t": 589931,
      "n": "RestartMarker",
      "d": 589931,
      "h": 133144576107,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133144576107),
//--TRIMMABLE-BOUNDARY-START(154619412587),
    {
      "t": 589931,
      "n": "ServiceTemporarilyNotAvailable",
      "d": 589931,
      "h": 154619412587,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154619412587),
//--TRIMMABLE-BOUNDARY-START(81604968555),
    {
      "t": 589931,
      "n": "DataAlreadyOpen",
      "d": 589931,
      "h": 81604968555,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81604968555),
//--TRIMMABLE-BOUNDARY-START(124554641515),
    {
      "t": 589931,
      "n": "OpeningData",
      "d": 589931,
      "h": 124554641515,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124554641515),
//--TRIMMABLE-BOUNDARY-START(68720066667),
    {
      "t": 589931,
      "n": "CommandOK",
      "d": 589931,
      "h": 68720066667,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720066667),
//--TRIMMABLE-BOUNDARY-START(60130132075),
    {
      "t": 589931,
      "n": "CommandExtraneous",
      "d": 589931,
      "h": 60130132075,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130132075),
//--TRIMMABLE-BOUNDARY-START(85899935851),
    {
      "t": 589931,
      "n": "DirectoryStatus",
      "d": 589931,
      "h": 85899935851,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85899935851),
//--TRIMMABLE-BOUNDARY-START(107374772331),
    {
      "t": 589931,
      "n": "FileStatus",
      "d": 589931,
      "h": 107374772331,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107374772331),
//--TRIMMABLE-BOUNDARY-START(158914379883),
    {
      "t": 589931,
      "n": "SystemType",
      "d": 589931,
      "h": 158914379883,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158914379883),
//--TRIMMABLE-BOUNDARY-START(141734510699),
    {
      "t": 589931,
      "n": "SendUserCommand",
      "d": 589931,
      "h": 141734510699,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141734510699),
//--TRIMMABLE-BOUNDARY-START(51540197483),
    {
      "t": 589931,
      "n": "ClosingControl",
      "d": 589931,
      "h": 51540197483,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540197483),
//--TRIMMABLE-BOUNDARY-START(55835164779),
    {
      "t": 589931,
      "n": "ClosingData",
      "d": 589931,
      "h": 55835164779,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835164779),
//--TRIMMABLE-BOUNDARY-START(90194903147),
    {
      "t": 589931,
      "n": "EnteringPassive",
      "d": 589931,
      "h": 90194903147,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90194903147),
//--TRIMMABLE-BOUNDARY-START(111669739627),
    {
      "t": 589931,
      "n": "LoggedInProceed",
      "d": 589931,
      "h": 111669739627,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111669739627),
//--TRIMMABLE-BOUNDARY-START(146029477995),
    {
      "t": 589931,
      "n": "ServerWantsSecureSession",
      "d": 589931,
      "h": 146029477995,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146029477995),
//--TRIMMABLE-BOUNDARY-START(98784837739),
    {
      "t": 589931,
      "n": "FileActionOK",
      "d": 589931,
      "h": 98784837739,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98784837739),
//--TRIMMABLE-BOUNDARY-START(128849608811),
    {
      "t": 589931,
      "n": "PathnameCreated",
      "d": 589931,
      "h": 128849608811,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128849608811),
//--TRIMMABLE-BOUNDARY-START(137439543403),
    {
      "t": 589931,
      "n": "SendPasswordCommand",
      "d": 589931,
      "h": 137439543403,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137439543403),
//--TRIMMABLE-BOUNDARY-START(115964706923),
    {
      "t": 589931,
      "n": "NeedLoginAccount",
      "d": 589931,
      "h": 115964706923,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115964706923),
//--TRIMMABLE-BOUNDARY-START(103079805035),
    {
      "t": 589931,
      "n": "FileCommandPending",
      "d": 589931,
      "h": 103079805035,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103079805035),
//--TRIMMABLE-BOUNDARY-START(150324445291),
    {
      "t": 589931,
      "n": "ServiceNotAvailable",
      "d": 589931,
      "h": 150324445291,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150324445291),
//--TRIMMABLE-BOUNDARY-START(47245230187),
    {
      "t": 589931,
      "n": "CantOpenData",
      "d": 589931,
      "h": 47245230187,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245230187),
//--TRIMMABLE-BOUNDARY-START(77310001259),
    {
      "t": 589931,
      "n": "ConnectionClosed",
      "d": 589931,
      "h": 77310001259,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310001259),
//--TRIMMABLE-BOUNDARY-START(30065361003),
    {
      "t": 589931,
      "n": "ActionNotTakenFileUnavailableOrBusy",
      "d": 589931,
      "h": 30065361003,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065361003),
//--TRIMMABLE-BOUNDARY-START(12885491819),
    {
      "t": 589931,
      "n": "ActionAbortedLocalProcessingError",
      "d": 589931,
      "h": 12885491819,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885491819),
//--TRIMMABLE-BOUNDARY-START(34360328299),
    {
      "t": 589931,
      "n": "ActionNotTakenInsufficientSpace",
      "d": 589931,
      "h": 34360328299,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360328299),
//--TRIMMABLE-BOUNDARY-START(73015033963),
    {
      "t": 589931,
      "n": "CommandSyntaxError",
      "d": 589931,
      "h": 73015033963,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015033963),
//--TRIMMABLE-BOUNDARY-START(38655295595),
    {
      "t": 589931,
      "n": "ArgumentSyntaxError",
      "d": 589931,
      "h": 38655295595,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655295595),
//--TRIMMABLE-BOUNDARY-START(64425099371),
    {
      "t": 589931,
      "n": "CommandNotImplemented",
      "d": 589931,
      "h": 64425099371,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425099371),
//--TRIMMABLE-BOUNDARY-START(42950262891),
    {
      "t": 589931,
      "n": "BadCommandSequence",
      "d": 589931,
      "h": 42950262891,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950262891),
//--TRIMMABLE-BOUNDARY-START(120259674219),
    {
      "t": 589931,
      "n": "NotLoggedIn",
      "d": 589931,
      "h": 120259674219,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120259674219),
//--TRIMMABLE-BOUNDARY-START(8590524523),
    {
      "t": 589931,
      "n": "AccountNeeded",
      "d": 589931,
      "h": 8590524523,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590524523),
//--TRIMMABLE-BOUNDARY-START(25770393707),
    {
      "t": 589931,
      "n": "ActionNotTakenFileUnavailable",
      "d": 589931,
      "h": 25770393707,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770393707),
//--TRIMMABLE-BOUNDARY-START(17180459115),
    {
      "t": 589931,
      "n": "ActionAbortedUnknownPageType",
      "d": 589931,
      "h": 17180459115,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180459115),
//--TRIMMABLE-BOUNDARY-START(94489870443),
    {
      "t": 589931,
      "n": "FileActionAborted",
      "d": 589931,
      "h": 94489870443,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94489870443),
//--TRIMMABLE-BOUNDARY-START(21475426411),
    {
      "t": 589931,
      "n": "ActionNotTakenFilenameNotAllowed",
      "d": 589931,
      "h": 21475426411,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475426411)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295557227),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 589931,
      "h": 4295557227,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557227)
  ],
  "h": 589931
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.FtpStatusCode`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}FtpStatusCode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589931)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572971)
        $asm.$str(`$snr.SN.WebExceptionStatus`, ($self) => class WebExceptionStatus extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Success = 0;
            static NameResolutionFailure = 1;
            static ConnectFailure = 2;
            static ReceiveFailure = 3;
            static SendFailure = 4;
            static PipelineFailure = 5;
            static RequestCanceled = 6;
            static ProtocolError = 7;
            static ConnectionClosed = 8;
            static TrustFailure = 9;
            static SecureChannelFailure = 10;
            static ServerProtocolViolation = 11;
            static KeepAliveFailure = 12;
            static Pending = 13;
            static Timeout = 14;
            static ProxyNameResolutionFailure = 15;
            static UnknownError = 16;
            static MessageLengthLimitExceeded = 17;
            static CacheEntryNotFound = 18;
            static RequestProhibitedByCachePolicy = 19;
            static RequestProhibitedByProxy = 20;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1572971);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Success": 0n,
                    "NameResolutionFailure": 1n,
                    "ConnectFailure": 2n,
                    "ReceiveFailure": 3n,
                    "SendFailure": 4n,
                    "PipelineFailure": 5n,
                    "RequestCanceled": 6n,
                    "ProtocolError": 7n,
                    "ConnectionClosed": 8n,
                    "TrustFailure": 9n,
                    "SecureChannelFailure": 10n,
                    "ServerProtocolViolation": 11n,
                    "KeepAliveFailure": 12n,
                    "Pending": 13n,
                    "Timeout": 14n,
                    "ProxyNameResolutionFailure": 15n,
                    "UnknownError": 16n,
                    "MessageLengthLimitExceeded": 17n,
                    "CacheEntryNotFound": 18n,
                    "RequestProhibitedByCachePolicy": 19n,
                    "RequestProhibitedByProxy": 20n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296540267)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540267);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296540267)
            
            //--TRIMMABLE-BOUNDARY-START(4296540267)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296540267)
            
            static $h = 1572971;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(81605951595),
    {
      "t": 1572971,
      "n": "Success",
      "d": 1572971,
      "h": 81605951595,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81605951595),
//--TRIMMABLE-BOUNDARY-START(30066344043),
    {
      "t": 1572971,
      "n": "NameResolutionFailure",
      "d": 1572971,
      "h": 30066344043,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066344043),
//--TRIMMABLE-BOUNDARY-START(12886474859),
    {
      "t": 1572971,
      "n": "ConnectFailure",
      "d": 1572971,
      "h": 12886474859,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886474859),
//--TRIMMABLE-BOUNDARY-START(51541180523),
    {
      "t": 1572971,
      "n": "ReceiveFailure",
      "d": 1572971,
      "h": 51541180523,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51541180523),
//--TRIMMABLE-BOUNDARY-START(73016017003),
    {
      "t": 1572971,
      "n": "SendFailure",
      "d": 1572971,
      "h": 73016017003,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73016017003),
//--TRIMMABLE-BOUNDARY-START(38656278635),
    {
      "t": 1572971,
      "n": "PipelineFailure",
      "d": 1572971,
      "h": 38656278635,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656278635),
//--TRIMMABLE-BOUNDARY-START(55836147819),
    {
      "t": 1572971,
      "n": "RequestCanceled",
      "d": 1572971,
      "h": 55836147819,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55836147819),
//--TRIMMABLE-BOUNDARY-START(42951245931),
    {
      "t": 1572971,
      "n": "ProtocolError",
      "d": 1572971,
      "h": 42951245931,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951245931),
//--TRIMMABLE-BOUNDARY-START(17181442155),
    {
      "t": 1572971,
      "n": "ConnectionClosed",
      "d": 1572971,
      "h": 17181442155,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181442155),
//--TRIMMABLE-BOUNDARY-START(90195886187),
    {
      "t": 1572971,
      "n": "TrustFailure",
      "d": 1572971,
      "h": 90195886187,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90195886187),
//--TRIMMABLE-BOUNDARY-START(68721049707),
    {
      "t": 1572971,
      "n": "SecureChannelFailure",
      "d": 1572971,
      "h": 68721049707,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68721049707),
//--TRIMMABLE-BOUNDARY-START(77310984299),
    {
      "t": 1572971,
      "n": "ServerProtocolViolation",
      "d": 1572971,
      "h": 77310984299,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310984299),
//--TRIMMABLE-BOUNDARY-START(21476409451),
    {
      "t": 1572971,
      "n": "KeepAliveFailure",
      "d": 1572971,
      "h": 21476409451,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476409451),
//--TRIMMABLE-BOUNDARY-START(34361311339),
    {
      "t": 1572971,
      "n": "Pending",
      "d": 1572971,
      "h": 34361311339,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361311339),
//--TRIMMABLE-BOUNDARY-START(85900918891),
    {
      "t": 1572971,
      "n": "Timeout",
      "d": 1572971,
      "h": 85900918891,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85900918891),
//--TRIMMABLE-BOUNDARY-START(47246213227),
    {
      "t": 1572971,
      "n": "ProxyNameResolutionFailure",
      "d": 1572971,
      "h": 47246213227,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246213227),
//--TRIMMABLE-BOUNDARY-START(94490853483),
    {
      "t": 1572971,
      "n": "UnknownError",
      "d": 1572971,
      "h": 94490853483,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94490853483),
//--TRIMMABLE-BOUNDARY-START(25771376747),
    {
      "t": 1572971,
      "n": "MessageLengthLimitExceeded",
      "d": 1572971,
      "h": 25771376747,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771376747),
//--TRIMMABLE-BOUNDARY-START(8591507563),
    {
      "t": 1572971,
      "n": "CacheEntryNotFound",
      "d": 1572971,
      "h": 8591507563,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591507563),
//--TRIMMABLE-BOUNDARY-START(60131115115),
    {
      "t": 1572971,
      "n": "RequestProhibitedByCachePolicy",
      "d": 1572971,
      "h": 60131115115,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60131115115),
//--TRIMMABLE-BOUNDARY-START(64426082411),
    {
      "t": 1572971,
      "n": "RequestProhibitedByProxy",
      "d": 1572971,
      "h": 64426082411,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64426082411)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540267),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1572971,
      "h": 4296540267,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296540267)
  ],
  "h": 1572971
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebExceptionStatus`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebExceptionStatus`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572971)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310827)
        $asm.$str(`$snr.SN.SecurityProtocolType`, ($self) => class SecurityProtocolType extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static SystemDefault = 0;
            static Ssl3 = 48;
            static Tls = 192;
            static Tls11 = 768;
            static Tls12 = 3072;
            static Tls13 = 12288;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1310827);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "SystemDefault": 0n,
                    "Ssl3": 48n,
                    "Tls": 192n,
                    "Tls11": 768n,
                    "Tls12": 3072n,
                    "Tls13": 12288n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296278123)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296278123);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296278123)
            
            //--TRIMMABLE-BOUNDARY-START(4296278123)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296278123)
            
            static $h = 1310827;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886212715),
    {
      "t": 1310827,
      "n": "SystemDefault",
      "d": 1310827,
      "h": 12886212715,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886212715),
//--TRIMMABLE-BOUNDARY-START(8591245419),
    {
      "t": 1310827,
      "n": "Ssl3",
      "d": 1310827,
      "h": 8591245419,
      "f": 4194337,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "SecurityProtocolType.Ssl3 has been deprecated and is not supported.",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8591245419),
//--TRIMMABLE-BOUNDARY-START(17181180011),
    {
      "t": 1310827,
      "n": "Tls",
      "d": 1310827,
      "h": 17181180011,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181180011),
//--TRIMMABLE-BOUNDARY-START(21476147307),
    {
      "t": 1310827,
      "n": "Tls11",
      "d": 1310827,
      "h": 21476147307,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476147307),
//--TRIMMABLE-BOUNDARY-START(25771114603),
    {
      "t": 1310827,
      "n": "Tls12",
      "d": 1310827,
      "h": 25771114603,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771114603),
//--TRIMMABLE-BOUNDARY-START(30066081899),
    {
      "t": 1310827,
      "n": "Tls13",
      "d": 1310827,
      "h": 30066081899,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066081899)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278123),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1310827,
      "h": 4296278123,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296278123)
  ],
  "h": 1310827,
  "a": [
    {
      "t": 81264641,
      "c": 4376231937
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.SecurityProtocolType`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}SecurityProtocolType`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310827)
        
        

        //--TRIMMABLE-BOUNDARY-START(262251)
        $asm.$str(`$snr.SNC.HttpCacheAgeControl`, ($self) => class HttpCacheAgeControl extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static MinFresh = 1;
            static MaxAge = 2;
            static MaxAgeAndMinFresh = 3;
            static MaxStale = 4;
            static MaxAgeAndMaxStale = 6;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(262251);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "MinFresh": 1n,
                    "MaxAge": 2n,
                    "MaxAgeAndMinFresh": 3n,
                    "MaxStale": 4n,
                    "MaxAgeAndMaxStale": 6n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295229547)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295229547);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295229547)
            
            //--TRIMMABLE-BOUNDARY-START(4295229547)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295229547)
            
            static $h = 262251;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(30065033323),
    {
      "t": 262251,
      "n": "None",
      "d": 262251,
      "h": 30065033323,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065033323),
//--TRIMMABLE-BOUNDARY-START(25770066027),
    {
      "t": 262251,
      "n": "MinFresh",
      "d": 262251,
      "h": 25770066027,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770066027),
//--TRIMMABLE-BOUNDARY-START(8590196843),
    {
      "t": 262251,
      "n": "MaxAge",
      "d": 262251,
      "h": 8590196843,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590196843),
//--TRIMMABLE-BOUNDARY-START(17180131435),
    {
      "t": 262251,
      "n": "MaxAgeAndMinFresh",
      "d": 262251,
      "h": 17180131435,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180131435),
//--TRIMMABLE-BOUNDARY-START(21475098731),
    {
      "t": 262251,
      "n": "MaxStale",
      "d": 262251,
      "h": 21475098731,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475098731),
//--TRIMMABLE-BOUNDARY-START(12885164139),
    {
      "t": 262251,
      "n": "MaxAgeAndMaxStale",
      "d": 262251,
      "h": 12885164139,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885164139)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229547),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 262251,
      "h": 4295229547,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229547)
  ],
  "h": 262251
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Cache.HttpCacheAgeControl`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Cache${separator}HttpCacheAgeControl`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262251)
        
        

        //--TRIMMABLE-BOUNDARY-START(327787)
        $asm.$str(`$snr.SNC.HttpRequestCacheLevel`, ($self) => class HttpRequestCacheLevel extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Default = 0;
            static BypassCache = 1;
            static CacheOnly = 2;
            static CacheIfAvailable = 3;
            static Revalidate = 4;
            static Reload = 5;
            static NoCacheNoStore = 6;
            static CacheOrNextCacheOnly = 7;
            static Refresh = 8;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(327787);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Default": 0n,
                    "BypassCache": 1n,
                    "CacheOnly": 2n,
                    "CacheIfAvailable": 3n,
                    "Revalidate": 4n,
                    "Reload": 5n,
                    "NoCacheNoStore": 6n,
                    "CacheOrNextCacheOnly": 7n,
                    "Refresh": 8n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295295083)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295295083);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295083)
            
            //--TRIMMABLE-BOUNDARY-START(4295295083)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295295083)
            
            static $h = 327787;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(25770131563),
    {
      "t": 327787,
      "n": "Default",
      "d": 327787,
      "h": 25770131563,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770131563),
//--TRIMMABLE-BOUNDARY-START(8590262379),
    {
      "t": 327787,
      "n": "BypassCache",
      "d": 327787,
      "h": 8590262379,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590262379),
//--TRIMMABLE-BOUNDARY-START(17180196971),
    {
      "t": 327787,
      "n": "CacheOnly",
      "d": 327787,
      "h": 17180196971,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180196971),
//--TRIMMABLE-BOUNDARY-START(12885229675),
    {
      "t": 327787,
      "n": "CacheIfAvailable",
      "d": 327787,
      "h": 12885229675,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885229675),
//--TRIMMABLE-BOUNDARY-START(42950000747),
    {
      "t": 327787,
      "n": "Revalidate",
      "d": 327787,
      "h": 42950000747,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950000747),
//--TRIMMABLE-BOUNDARY-START(38655033451),
    {
      "t": 327787,
      "n": "Reload",
      "d": 327787,
      "h": 38655033451,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655033451),
//--TRIMMABLE-BOUNDARY-START(30065098859),
    {
      "t": 327787,
      "n": "NoCacheNoStore",
      "d": 327787,
      "h": 30065098859,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065098859),
//--TRIMMABLE-BOUNDARY-START(21475164267),
    {
      "t": 327787,
      "n": "CacheOrNextCacheOnly",
      "d": 327787,
      "h": 21475164267,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475164267),
//--TRIMMABLE-BOUNDARY-START(34360066155),
    {
      "t": 327787,
      "n": "Refresh",
      "d": 327787,
      "h": 34360066155,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360066155)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295083),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 327787,
      "h": 4295295083,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295083)
  ],
  "h": 327787
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Cache.HttpRequestCacheLevel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Cache${separator}HttpRequestCacheLevel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327787)
        
        

        //--TRIMMABLE-BOUNDARY-START(393323)
        $asm.$cls(`$snr.SNC.HttpRequestCachePolicy`, ($self) => class HttpRequestCachePolicy extends $.$snp.SNC.RequestCachePolicy
        {
            //--TRIMMABLE-BOUNDARY-START(4295360619)
            $ctor$3()
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360619);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360619)
            
            //--TRIMMABLE-BOUNDARY-START(8590327915)
            $ctor$4(/*System.DateTime*/ cacheSyncDate)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590327915);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590327915)
            
            //--TRIMMABLE-BOUNDARY-START(21475229803)
            $ctor$7(/*System.Net.Cache.HttpCacheAgeControl*/ cacheAgeControl, /*System.TimeSpan*/ ageOrFreshOrStale)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475229803);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475229803)
            
            //--TRIMMABLE-BOUNDARY-START(17180262507)
            $ctor$6(/*System.Net.Cache.HttpCacheAgeControl*/ cacheAgeControl, /*System.TimeSpan*/ maxAge, /*System.TimeSpan*/ freshOrStale)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180262507);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180262507)
            
            //--TRIMMABLE-BOUNDARY-START(12885295211)
            $ctor$5(/*System.Net.Cache.HttpCacheAgeControl*/ cacheAgeControl, /*System.TimeSpan*/ maxAge, /*System.TimeSpan*/ freshOrStale, /*System.DateTime*/ cacheSyncDate)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12885295211);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885295211)
            
            //--TRIMMABLE-BOUNDARY-START(25770197099)
            $ctor$8(/*System.Net.Cache.HttpRequestCacheLevel*/ level)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25770197099);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25770197099)
            
            //--TRIMMABLE-BOUNDARY-START(30065164395)
            /*System.DateTime */ get CacheSyncDate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655098987);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065164395)
            
            //--TRIMMABLE-BOUNDARY-START(77309804651)
            /*System.Net.Cache.HttpRequestCacheLevel */ get Level$1()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245033579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77309804651)
            
            //--TRIMMABLE-BOUNDARY-START(81604771947)
            /*System.TimeSpan */ get MaxAge()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55834968171);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81604771947)
            
            //--TRIMMABLE-BOUNDARY-START(85899739243)
            /*System.TimeSpan */ get MaxStale()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424902763);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(85899739243)
            
            //--TRIMMABLE-BOUNDARY-START(90194706539)
            /*System.TimeSpan */ get MinFresh()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014837355);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90194706539)
            
            //--TRIMMABLE-BOUNDARY-START(94489673835)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489673835);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(94489673835)
            
            //--TRIMMABLE-BOUNDARY-START(4295360619)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295360619)
            
            static $h = 393323;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$snp.SNC.RequestCachePolicy; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(30065164395),
    {
      "p": 65994753,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655098987,
        "f": 50331649
      },
      "n": "CacheSyncDate",
      "d": 393323,
      "h": 30065164395,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065164395),
//--TRIMMABLE-BOUNDARY-START(77309804651),
    {
      "p": 327787,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245033579,
        "f": 50331649
      },
      "n": "Level",
      "o": "@$1",
      "d": 393323,
      "h": 77309804651,
      "f": 538968065
    },
//--TRIMMABLE-BOUNDARY-END(77309804651),
//--TRIMMABLE-BOUNDARY-START(81604771947),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834968171,
        "f": 50331649
      },
      "n": "MaxAge",
      "d": 393323,
      "h": 81604771947,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604771947),
//--TRIMMABLE-BOUNDARY-START(85899739243),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424902763,
        "f": 50331649
      },
      "n": "MaxStale",
      "d": 393323,
      "h": 85899739243,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899739243),
//--TRIMMABLE-BOUNDARY-START(90194706539),
    {
      "p": 186646529,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014837355,
        "f": 50331649
      },
      "n": "MinFresh",
      "d": 393323,
      "h": 90194706539,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194706539)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(94489673835),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 393323,
      "h": 94489673835,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94489673835)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360619),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 393323,
      "h": 4295360619,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360619),
//--TRIMMABLE-BOUNDARY-START(8590327915),
    {
      "p": [
        {
          "n": "cacheSyncDate",
          "p": 65994753
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 393323,
      "h": 8590327915,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590327915),
//--TRIMMABLE-BOUNDARY-START(21475229803),
    {
      "p": [
        {
          "n": "cacheAgeControl",
          "p": 262251
        },
        {
          "n": "ageOrFreshOrStale",
          "p": 186646529
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 393323,
      "h": 21475229803,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475229803),
//--TRIMMABLE-BOUNDARY-START(17180262507),
    {
      "p": [
        {
          "n": "cacheAgeControl",
          "p": 262251
        },
        {
          "n": "maxAge",
          "p": 186646529
        },
        {
          "n": "freshOrStale",
          "p": 186646529
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 393323,
      "h": 17180262507,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180262507),
//--TRIMMABLE-BOUNDARY-START(12885295211),
    {
      "p": [
        {
          "n": "cacheAgeControl",
          "p": 262251
        },
        {
          "n": "maxAge",
          "p": 186646529
        },
        {
          "n": "freshOrStale",
          "p": 186646529
        },
        {
          "n": "cacheSyncDate",
          "p": 65994753
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 393323,
      "h": 12885295211,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885295211),
//--TRIMMABLE-BOUNDARY-START(25770197099),
    {
      "p": [
        {
          "n": "level",
          "p": 327787
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 393323,
      "h": 25770197099,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25770197099)
  ],
  "h": 393323
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Cache.HttpRequestCachePolicy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Cache${separator}HttpRequestCachePolicy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393323)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245291)
        $asm.$cls(`$snr.SN.ProtocolViolationException`, ($self) => class ProtocolViolationException extends $.$$.S.InvalidOperationException
        {
            //--TRIMMABLE-BOUNDARY-START(4296212587)
            $ctor$13()
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296212587);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296212587)
            
            //--TRIMMABLE-BOUNDARY-START(8591179883)
            $ctor$14(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591179883);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591179883)
            
            //--TRIMMABLE-BOUNDARY-START(12886147179)
            $ctor$15(/*string?*/ message)
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886147179);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886147179)
            
            //--TRIMMABLE-BOUNDARY-START(17181114475)
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181114475);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17181114475)
            
            //--TRIMMABLE-BOUNDARY-START(21476081771)
            /*void */ SRS$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476081771);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21476081771)
            
            //--TRIMMABLE-BOUNDARY-START(4296212587)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(4296212587)
            
            static $h = 1245291;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.InvalidOperationException; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1245291
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.ProtocolViolationException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}ProtocolViolationException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245291)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507435)
        $asm.$cls(`$snr.SN.WebException`, ($self) => class WebException extends $.$$.S.InvalidOperationException
        {
            //--TRIMMABLE-BOUNDARY-START(4296474731)
            $ctor$13()
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296474731);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296474731)
            
            //--TRIMMABLE-BOUNDARY-START(8591442027)
            $ctor$14(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591442027);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591442027)
            
            //--TRIMMABLE-BOUNDARY-START(25771311211)
            $ctor$18(/*string?*/ message)
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(25771311211);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(25771311211)
            
            //--TRIMMABLE-BOUNDARY-START(17181376619)
            $ctor$16(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181376619);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181376619)
            
            //--TRIMMABLE-BOUNDARY-START(12886409323)
            $ctor$15(/*string?*/ message, /*System.Exception?*/ innerException, /*System.Net.WebExceptionStatus*/ status, /*System.Net.WebResponse?*/ response)
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886409323);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886409323)
            
            //--TRIMMABLE-BOUNDARY-START(21476343915)
            $ctor$17(/*string?*/ message, /*System.Net.WebExceptionStatus*/ status)
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476343915);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476343915)
            
            //--TRIMMABLE-BOUNDARY-START(51541114987)
            /*System.Net.WebResponse? */ get Response()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34361245803);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51541114987)
            
            //--TRIMMABLE-BOUNDARY-START(55836082283)
            /*System.Net.WebExceptionStatus */ get Status()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42951180395);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55836082283)
            
            //--TRIMMABLE-BOUNDARY-START(47246147691)
            /*void */ GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246147691);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(47246147691)
            
            //--TRIMMABLE-BOUNDARY-START(60131049579)
            /*void */ SRS$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60131049579);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60131049579)
            
            //--TRIMMABLE-BOUNDARY-START(4296474731)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(4296474731)
            
            static $h = 1507435;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.InvalidOperationException; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1507435
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.WebException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}WebException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507435)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.ComponentModel", "NetJs.System.ObjectModel", "NetJs.System.ComponentModel.Primitives", "NetJs.System.Collections.Specialized", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression.Brotli", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Net.NetworkInformation", "NetJs.System.Security.Cryptography", "NetJs.System.Net.Security", "NetJs.System.Threading.Channels", "NetJs.System.Net.Quic", "NetJs.System.Runtime.InteropServices.JavaScript", "NetJs.System.Net.Http", "NetJs.System.Net.WebHeaderCollection"));
})();
//--TRIMMABLE-BOUNDARY-END(107)
