
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Security", 
    {"h":60012,"f":"System.Net.Security","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Security","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Security","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snsc.System.Net.Security.AuthenticatedStream", ($self) => class AuthenticatedStream extends $.$$.System.IO.Stream
        {
            $ctor$3(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.IO.Stream */ get InnerStream()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get LeaveInnerStreamOpen()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 125548;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":62193665,"g":{"r":0,"d":0,"h":12885027436,"f":50331652},"n":"InnerStream","d":125548,"h":8590060140,"f":2097156},{"p":262145,"g":{"r":0,"d":0,"h":21474962028,"f":50331905},"n":"IsAuthenticated","d":125548,"h":17179994732,"f":2097409},{"p":262145,"g":{"r":0,"d":0,"h":30064896620,"f":50331905},"n":"IsEncrypted","d":125548,"h":25769929324,"f":2097409},{"p":262145,"g":{"r":0,"d":0,"h":38654831212,"f":50331905},"n":"IsMutuallyAuthenticated","d":125548,"h":34359863916,"f":2097409},{"p":262145,"g":{"r":0,"d":0,"h":47244765804,"f":50331905},"n":"IsServer","d":125548,"h":42949798508,"f":2097409},{"p":262145,"g":{"r":0,"d":0,"h":55834700396,"f":50331905},"n":"IsSigned","d":125548,"h":51539733100,"f":2097409},{"p":262145,"g":{"r":0,"d":0,"h":64424634988,"f":50331649},"n":"LeaveInnerStreamOpen","d":125548,"h":60129667692,"f":2097153}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":125548,"h":68719602284,"f":16809988},{"r":135987201,"n":"DisposeAsync","d":125548,"h":73014569580,"f":16809985}],"c":[{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":125548,"h":4295092844,"f":16777220}],"i":[57540609,56950785],"h":125548}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.AuthenticatedStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.CipherSuitesPolicy", ($self) => class CipherSuitesPolicy extends $.$$.System.Object
        {
            $ctor$1(/*System.Collections.Generic.IEnumerable<System.Net.Security.TlsCipherSuite>*/ allowedCipherSuites)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.Generic.IEnumerable<System.Net.Security.TlsCipherSuite> */ get AllowedCipherSuites()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 191084;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.Generic.IEnumerable$$($.$snsc.System.Net.Security.TlsCipherSuite).$h,"g":{"r":0,"d":0,"h":12885092972,"f":50331649},"n":"AllowedCipherSuites","d":191084,"h":8590125676,"f":2097153,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]}],"c":[{"p":[{"n":"allowedCipherSuites","p":$.$$.System.Collections.Generic.IEnumerable$$($.$snsc.System.Net.Security.TlsCipherSuite).$h}],"n":".ctor","o":"$ctor$1","d":191084,"h":4295158380,"f":16777217,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]}],"h":191084,"a":[{"t":115146753,"c":4410114049,"a":[{"v":"android","t":1310721}]},{"t":115146753,"c":4410114049,"a":[{"v":"windows","t":1310721}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Security.CipherSuitesPolicy`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthenticationClientOptions", ($self) => class NegotiateAuthenticationClientOptions extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get AllowedImpersonationLevel()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set AllowedImpersonationLevel(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get Binding()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ set Binding(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ get Credential()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ set Credential(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Package(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get RequiredProtectionLevel()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ set RequiredProtectionLevel(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RequireMutualAuthentication()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RequireMutualAuthentication(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TargetName(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 453228;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":117112833,"g":{"r":0,"d":0,"h":12885355116,"f":50331649},"s":{"r":0,"d":0,"h":17180322412,"f":83886081},"n":"AllowedImpersonationLevel","d":453228,"h":8590387820,"f":2097153},{"p":5423861,"g":{"r":0,"d":0,"h":25770257004,"f":50331649},"s":{"r":0,"d":0,"h":30065224300,"f":83886081},"n":"Binding","d":453228,"h":21475289708,"f":2097153},{"p":3850997,"g":{"r":0,"d":0,"h":38655158892,"f":50331649},"s":{"r":0,"d":0,"h":42950126188,"f":83886081},"n":"Credential","d":453228,"h":34360191596,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":51540060780,"f":50331649},"s":{"r":0,"d":0,"h":55835028076,"f":83886081},"n":"Package","d":453228,"h":47245093484,"f":2097153},{"p":715372,"g":{"r":0,"d":0,"h":64424962668,"f":50331649},"s":{"r":0,"d":0,"h":68719929964,"f":83886081},"n":"RequiredProtectionLevel","d":453228,"h":60129995372,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":77309864556,"f":50331649},"s":{"r":0,"d":0,"h":81604831852,"f":83886081},"n":"RequireMutualAuthentication","d":453228,"h":73014897260,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":90194766444,"f":50331649},"s":{"r":0,"d":0,"h":94489733740,"f":83886081},"n":"TargetName","d":453228,"h":85899799148,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":453228,"h":4295420524,"f":16777217}],"h":453228}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationClientOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthenticationServerOptions", ($self) => class NegotiateAuthenticationServerOptions extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get Binding()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ set Binding(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ get Credential()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ set Credential(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Package(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy? */ get Policy()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy? */ set Policy(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get RequiredImpersonationLevel()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set RequiredImpersonationLevel(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get RequiredProtectionLevel()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ set RequiredProtectionLevel(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 518764;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5423861,"g":{"r":0,"d":0,"h":12885420652,"f":50331649},"s":{"r":0,"d":0,"h":17180387948,"f":83886081},"n":"Binding","d":518764,"h":8590453356,"f":2097153},{"p":3850997,"g":{"r":0,"d":0,"h":25770322540,"f":50331649},"s":{"r":0,"d":0,"h":30065289836,"f":83886081},"n":"Credential","d":518764,"h":21475355244,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":38655224428,"f":50331649},"s":{"r":0,"d":0,"h":42950191724,"f":83886081},"n":"Package","d":518764,"h":34360257132,"f":2097153},{"p":1567340,"g":{"r":0,"d":0,"h":51540126316,"f":50331649},"s":{"r":0,"d":0,"h":55835093612,"f":83886081},"n":"Policy","d":518764,"h":47245159020,"f":2097153},{"p":117112833,"g":{"r":0,"d":0,"h":64425028204,"f":50331649},"s":{"r":0,"d":0,"h":68719995500,"f":83886081},"n":"RequiredImpersonationLevel","d":518764,"h":60130060908,"f":2097153},{"p":715372,"g":{"r":0,"d":0,"h":77309930092,"f":50331649},"s":{"r":0,"d":0,"h":81604897388,"f":83886081},"n":"RequiredProtectionLevel","d":518764,"h":73014962796,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":518764,"h":4295486060,"f":16777217}],"h":518764}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationServerOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslCertificateTrust", ($self) => class SslCertificateTrust extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*System.Net.Security.SslCertificateTrust */ CreateForX509Collection(/*System.Security.Cryptography.X509Certificates.X509Certificate2Collection*/ trustList, /*bool*/ sendTrustInHandshake)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslCertificateTrust */ CreateForX509Store(/*System.Security.Cryptography.X509Certificates.X509Store*/ store, /*bool*/ sendTrustInHandshake)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1043052;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1043052,"p":[{"n":"trustList","p":28291855},{"n":"sendTrustInHandshake","p":262145,"f":65,"v":false}],"n":"CreateForX509Collection","d":1043052,"h":8590977644,"f":16777249},{"r":1043052,"p":[{"n":"store","p":30454543},{"n":"sendTrustInHandshake","p":262145,"f":65,"v":false}],"n":"CreateForX509Store","d":1043052,"h":12885944940,"f":16777249}],"c":[{"n":".ctor","o":"$ctor$1","d":1043052,"h":4296010348,"f":16777224}],"h":1043052}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Security.SslCertificateTrust`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslClientAuthenticationOptions", ($self) => class SslClientAuthenticationOptions extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AllowRenegotiation()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRenegotiation(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPkcs1Padding()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPkcs1Padding(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPssPadding()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPssPadding(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowTlsResume()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowTlsResume(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ get ApplicationProtocols()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ set ApplicationProtocols(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ get CertificateChainPolicy()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ set CertificateChainPolicy(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ get CertificateRevocationCheckMode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ set CertificateRevocationCheckMode(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ get CipherSuitesPolicy()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ set CipherSuitesPolicy(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ get ClientCertificateContext()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ set ClientCertificateContext(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection? */ get ClientCertificates()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection? */ set ClientCertificates(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get EnabledSslProtocols()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ set EnabledSslProtocols(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ set EncryptionPolicy(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.LocalCertificateSelectionCallback? */ get LocalCertificateSelectionCallback()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.LocalCertificateSelectionCallback? */ set LocalCertificateSelectionCallback(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get RemoteCertificateValidationCallback()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set RemoteCertificateValidationCallback(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetHost()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TargetHost(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1108588;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886010476,"f":50331649},"s":{"r":0,"d":0,"h":17180977772,"f":83886081},"n":"AllowRenegotiation","d":1108588,"h":8591043180,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":25770912364,"f":50331649},"s":{"r":0,"d":0,"h":30065879660,"f":83886081,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"linux","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPkcs1Padding","d":1108588,"h":21475945068,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":38655814252,"f":50331649},"s":{"r":0,"d":0,"h":42950781548,"f":83886081,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"linux","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPssPadding","d":1108588,"h":34360846956,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":51540716140,"f":50331649},"s":{"r":0,"d":0,"h":55835683436,"f":83886081},"n":"AllowTlsResume","d":1108588,"h":47245748844,"f":2097153},{"p":$.$$.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":64425618028,"f":50331649},"s":{"r":0,"d":0,"h":68720585324,"f":83886081},"n":"ApplicationProtocols","d":1108588,"h":60130650732,"f":2097153},{"p":29143823,"g":{"r":0,"d":0,"h":77310519916,"f":50331649},"s":{"r":0,"d":0,"h":81605487212,"f":83886081},"n":"CertificateChainPolicy","d":1108588,"h":73015552620,"f":2097153},{"p":30257935,"g":{"r":0,"d":0,"h":90195421804,"f":50331649},"s":{"r":0,"d":0,"h":94490389100,"f":83886081},"n":"CertificateRevocationCheckMode","d":1108588,"h":85900454508,"f":2097153},{"p":191084,"g":{"r":0,"d":0,"h":103080323692,"f":50331649},"s":{"r":0,"d":0,"h":107375290988,"f":83886081},"n":"CipherSuitesPolicy","d":1108588,"h":98785356396,"f":2097153},{"p":1370732,"g":{"r":0,"d":0,"h":115965225580,"f":50331649},"s":{"r":0,"d":0,"h":120260192876,"f":83886081},"n":"ClientCertificateContext","d":1108588,"h":111670258284,"f":2097153},{"p":28422927,"g":{"r":0,"d":0,"h":128850127468,"f":50331649},"s":{"r":0,"d":0,"h":133145094764,"f":83886081},"n":"ClientCertificates","d":1108588,"h":124555160172,"f":2097153},{"p":5620469,"g":{"r":0,"d":0,"h":141735029356,"f":50331649},"s":{"r":0,"d":0,"h":146029996652,"f":83886081},"n":"EnabledSslProtocols","d":1108588,"h":137440062060,"f":2097153},{"p":256620,"g":{"r":0,"d":0,"h":154619931244,"f":50331649},"s":{"r":0,"d":0,"h":158914898540,"f":83886081},"n":"EncryptionPolicy","d":1108588,"h":150324963948,"f":2097153},{"p":322156,"g":{"r":0,"d":0,"h":167504833132,"f":50331649},"s":{"r":0,"d":0,"h":171799800428,"f":83886081},"n":"LocalCertificateSelectionCallback","d":1108588,"h":163209865836,"f":2097153},{"p":780908,"g":{"r":0,"d":0,"h":180389735020,"f":50331649},"s":{"r":0,"d":0,"h":184684702316,"f":83886081},"n":"RemoteCertificateValidationCallback","d":1108588,"h":176094767724,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":193274636908,"f":50331649},"s":{"r":0,"d":0,"h":197569604204,"f":83886081},"n":"TargetHost","d":1108588,"h":188979669612,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":1108588,"h":4296075884,"f":16777217}],"h":1108588}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Security.SslClientAuthenticationOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslServerAuthenticationOptions", ($self) => class SslServerAuthenticationOptions extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AllowRenegotiation()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRenegotiation(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPkcs1Padding()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPkcs1Padding(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPssPadding()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPssPadding(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowTlsResume()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowTlsResume(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ get ApplicationProtocols()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ set ApplicationProtocols(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ get CertificateChainPolicy()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ set CertificateChainPolicy(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ get CertificateRevocationCheckMode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ set CertificateRevocationCheckMode(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ get CipherSuitesPolicy()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ set CipherSuitesPolicy(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ClientCertificateRequired()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ClientCertificateRequired(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get EnabledSslProtocols()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ set EnabledSslProtocols(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ set EncryptionPolicy(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get RemoteCertificateValidationCallback()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set RemoteCertificateValidationCallback(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get ServerCertificate()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ set ServerCertificate(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ get ServerCertificateContext()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ set ServerCertificateContext(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ServerCertificateSelectionCallback? */ get ServerCertificateSelectionCallback()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ServerCertificateSelectionCallback? */ set ServerCertificateSelectionCallback(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1239660;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886141548,"f":50331649},"s":{"r":0,"d":0,"h":17181108844,"f":83886081},"n":"AllowRenegotiation","d":1239660,"h":8591174252,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":25771043436,"f":50331649},"s":{"r":0,"d":0,"h":30066010732,"f":83886081,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"linux","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPkcs1Padding","d":1239660,"h":21476076140,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":38655945324,"f":50331649},"s":{"r":0,"d":0,"h":42950912620,"f":83886081,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"linux","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPssPadding","d":1239660,"h":34360978028,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":51540847212,"f":50331649},"s":{"r":0,"d":0,"h":55835814508,"f":83886081},"n":"AllowTlsResume","d":1239660,"h":47245879916,"f":2097153},{"p":$.$$.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":64425749100,"f":50331649},"s":{"r":0,"d":0,"h":68720716396,"f":83886081},"n":"ApplicationProtocols","d":1239660,"h":60130781804,"f":2097153},{"p":29143823,"g":{"r":0,"d":0,"h":77310650988,"f":50331649},"s":{"r":0,"d":0,"h":81605618284,"f":83886081},"n":"CertificateChainPolicy","d":1239660,"h":73015683692,"f":2097153},{"p":30257935,"g":{"r":0,"d":0,"h":90195552876,"f":50331649},"s":{"r":0,"d":0,"h":94490520172,"f":83886081},"n":"CertificateRevocationCheckMode","d":1239660,"h":85900585580,"f":2097153},{"p":191084,"g":{"r":0,"d":0,"h":103080454764,"f":50331649},"s":{"r":0,"d":0,"h":107375422060,"f":83886081},"n":"CipherSuitesPolicy","d":1239660,"h":98785487468,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":115965356652,"f":50331649},"s":{"r":0,"d":0,"h":120260323948,"f":83886081},"n":"ClientCertificateRequired","d":1239660,"h":111670389356,"f":2097153},{"p":5620469,"g":{"r":0,"d":0,"h":128850258540,"f":50331649},"s":{"r":0,"d":0,"h":133145225836,"f":83886081},"n":"EnabledSslProtocols","d":1239660,"h":124555291244,"f":2097153},{"p":256620,"g":{"r":0,"d":0,"h":141735160428,"f":50331649},"s":{"r":0,"d":0,"h":146030127724,"f":83886081},"n":"EncryptionPolicy","d":1239660,"h":137440193132,"f":2097153},{"p":780908,"g":{"r":0,"d":0,"h":154620062316,"f":50331649},"s":{"r":0,"d":0,"h":158915029612,"f":83886081},"n":"RemoteCertificateValidationCallback","d":1239660,"h":150325095020,"f":2097153},{"p":28160783,"g":{"r":0,"d":0,"h":167504964204,"f":50331649},"s":{"r":0,"d":0,"h":171799931500,"f":83886081},"n":"ServerCertificate","d":1239660,"h":163209996908,"f":2097153},{"p":1370732,"g":{"r":0,"d":0,"h":180389866092,"f":50331649},"s":{"r":0,"d":0,"h":184684833388,"f":83886081},"n":"ServerCertificateContext","d":1239660,"h":176094898796,"f":2097153},{"p":846444,"g":{"r":0,"d":0,"h":193274767980,"f":50331649},"s":{"r":0,"d":0,"h":197569735276,"f":83886081},"n":"ServerCertificateSelectionCallback","d":1239660,"h":188979800684,"f":2097153}],"c":[{"n":".ctor","o":"$ctor$1","d":1239660,"h":4296206956,"f":16777217}],"h":1239660}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Security.SslServerAuthenticationOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslStreamCertificateContext", ($self) => class SslStreamCertificateContext extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.ObjectModel.ReadOnlyCollection<System.Security.Cryptography.X509Certificates.X509Certificate2> */ get IntermediateCertificates()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate2 */ get TargetCertificate()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslStreamCertificateContext */ Create$1(/*System.Security.Cryptography.X509Certificates.X509Certificate2*/ target, /*System.Security.Cryptography.X509Certificates.X509Certificate2Collection?*/ additionalCertificates, /*bool*/ offline)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslStreamCertificateContext */ Create(/*System.Security.Cryptography.X509Certificates.X509Certificate2*/ target, /*System.Security.Cryptography.X509Certificates.X509Certificate2Collection?*/ additionalCertificates, /*bool*/ offline, /*System.Net.Security.SslCertificateTrust?*/ trust)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1370732;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$$.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sscr.System.Security.Cryptography.X509Certificates.X509Certificate2).$h,"g":{"r":0,"d":0,"h":12886272620,"f":50331649},"n":"IntermediateCertificates","d":1370732,"h":8591305324,"f":2097153},{"p":28226319,"g":{"r":0,"d":0,"h":21476207212,"f":50331649},"n":"TargetCertificate","d":1370732,"h":17181239916,"f":2097153}],"m":[{"r":1370732,"p":[{"n":"target","p":28226319},{"n":"additionalCertificates","p":28291855},{"n":"offline","p":262145}],"n":"Create","o":"@$1","d":1370732,"h":25771174508,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":1370732,"p":[{"n":"target","p":28226319},{"n":"additionalCertificates","p":28291855},{"n":"offline","p":262145,"f":65,"v":false},{"n":"trust","p":1043052,"f":65}],"n":"Create","d":1370732,"h":30066141804,"f":16777249}],"c":[{"n":".ctor","o":"$ctor$1","d":1370732,"h":4296338028,"f":16777224}],"h":1370732}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Security.SslStreamCertificateContext`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthentication", ($self) => class NegotiateAuthentication extends $.$$.System.Object
        {
            $ctor$1(/*System.Net.Security.NegotiateAuthenticationClientOptions*/ clientOptions)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.Security.NegotiateAuthenticationServerOptions*/ serverOptions)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get ProtectionLevel()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get RemoteIdentity()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ ComputeIntegrityCheck(/*System.ReadOnlySpan<byte>*/ message, /*System.Buffers.IBufferWriter<byte>*/ signatureWriter)
            {
            }
            /*void */ Dispose()
            {
            }
            /*byte[]? */ GetOutgoingBlob(/*System.ReadOnlySpan<byte>*/ incomingBlob, /*out System.Net.Security.NegotiateAuthenticationStatusCode*/ statusCode)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ GetOutgoingBlob$1(/*string?*/ incomingBlob, /*out System.Net.Security.NegotiateAuthenticationStatusCode*/ statusCode)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ Unwrap(/*System.ReadOnlySpan<byte>*/ input, /*System.Buffers.IBufferWriter<byte>*/ outputWriter, /*out bool*/ wasEncrypted)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ UnwrapInPlace(/*System.Span<byte>*/ input, /*out int*/ unwrappedOffset, /*out int*/ unwrappedLength, /*out bool*/ wasEncrypted)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ VerifyIntegrityCheck(/*System.ReadOnlySpan<byte>*/ message, /*System.ReadOnlySpan<byte>*/ signature)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ Wrap(/*System.ReadOnlySpan<byte>*/ input, /*System.Buffers.IBufferWriter<byte>*/ outputWriter, /*bool*/ requestEncryption, /*out bool*/ isEncrypted)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 387692;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":117112833,"g":{"r":0,"d":0,"h":17180256876,"f":50331649},"n":"ImpersonationLevel","d":387692,"h":12885289580,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":25770191468,"f":50331649},"n":"IsAuthenticated","d":387692,"h":21475224172,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":34360126060,"f":50331649},"n":"IsEncrypted","d":387692,"h":30065158764,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":42950060652,"f":50331649},"n":"IsMutuallyAuthenticated","d":387692,"h":38655093356,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":51539995244,"f":50331649},"n":"IsServer","d":387692,"h":47245027948,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":60129929836,"f":50331649},"n":"IsSigned","d":387692,"h":55834962540,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":68719864428,"f":50331649},"n":"Package","d":387692,"h":64424897132,"f":2097153},{"p":715372,"g":{"r":0,"d":0,"h":77309799020,"f":50331649},"n":"ProtectionLevel","d":387692,"h":73014831724,"f":2097153},{"p":116916225,"g":{"r":0,"d":0,"h":85899733612,"f":50331649},"n":"RemoteIdentity","d":387692,"h":81604766316,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":94489668204,"f":50331649},"n":"TargetName","d":387692,"h":90194700908,"f":2097153}],"m":[{"r":65537,"p":[{"n":"message","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"signatureWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte).$h}],"n":"ComputeIntegrityCheck","d":387692,"h":98784635500,"f":16777217},{"r":65537,"n":"Dispose","d":387692,"h":103079602796,"f":16777217},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"incomingBlob","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"statusCode","p":584300,"f":2}],"n":"GetOutgoingBlob","d":387692,"h":107374570092,"f":16777217},{"r":1310721,"p":[{"n":"incomingBlob","p":1310721},{"n":"statusCode","p":584300,"f":2}],"n":"GetOutgoingBlob","o":"@$1","d":387692,"h":111669537388,"f":16777217},{"r":584300,"p":[{"n":"input","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"outputWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte).$h},{"n":"wasEncrypted","p":262145,"f":2}],"n":"Unwrap","d":387692,"h":115964504684,"f":16777217},{"r":584300,"p":[{"n":"input","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"unwrappedOffset","p":655361,"f":2},{"n":"unwrappedLength","p":655361,"f":2},{"n":"wasEncrypted","p":262145,"f":2}],"n":"UnwrapInPlace","d":387692,"h":120259471980,"f":16777217},{"r":262145,"p":[{"n":"message","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"signature","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"VerifyIntegrityCheck","d":387692,"h":124554439276,"f":16777217},{"r":584300,"p":[{"n":"input","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"outputWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$$.System.Byte).$h},{"n":"requestEncryption","p":262145},{"n":"isEncrypted","p":262145,"f":2}],"n":"Wrap","d":387692,"h":128849406572,"f":16777217}],"c":[{"p":[{"n":"clientOptions","p":453228}],"n":".ctor","o":"$ctor$1","d":387692,"h":4295354988,"f":16777217},{"p":[{"n":"serverOptions","p":518764}],"n":".ctor","o":"$ctor$2","d":387692,"h":8590322284,"f":16777217}],"i":[57540609],"h":387692}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthentication`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy", ($self) => class ExtendedProtectionPolicy extends $.$$.System.Object
        {
            $ctor$1(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ChannelBinding*/ customChannelBinding)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ProtectionScenario*/ protectionScenario, /*System.Collections.ICollection?*/ customServiceNames)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ProtectionScenario*/ protectionScenario, /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection?*/ customServiceNames)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get CustomChannelBinding()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection? */ get CustomServiceNames()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsExtendedProtection()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.PolicyEnforcement */ get PolicyEnforcement()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ProtectionScenario */ get ProtectionScenario()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo?*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snsc.System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy.ToString.apply(this, arguments); }
            static $h = 1567340;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5423861,"g":{"r":0,"d":0,"h":30066338412,"f":50331649},"n":"CustomChannelBinding","d":1567340,"h":25771371116,"f":2097153},{"p":1763948,"g":{"r":0,"d":0,"h":38656273004,"f":50331649},"n":"CustomServiceNames","d":1567340,"h":34361305708,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":47246207596,"f":50331681},"n":"OSSupportsExtendedProtection","d":1567340,"h":42951240300,"f":2097185},{"p":1632876,"g":{"r":0,"d":0,"h":55836142188,"f":50331649},"n":"PolicyEnforcement","d":1567340,"h":51541174892,"f":2097153},{"p":1698412,"g":{"r":0,"d":0,"h":64426076780,"f":50331649},"n":"ProtectionScenario","d":1567340,"h":60131109484,"f":2097153}],"m":[{"r":1310721,"n":"ToString","d":1567340,"h":73016011372,"f":16809985}],"c":[{"p":[{"n":"info","p":113836033},{"n":"context","p":113967105}],"n":".ctor","o":"$ctor$1","d":1567340,"h":4296534636,"f":16777220,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]},{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":[{"n":"policyEnforcement","p":1632876}],"n":".ctor","o":"$ctor$5","d":1567340,"h":8591501932,"f":16777217},{"p":[{"n":"policyEnforcement","p":1632876},{"n":"customChannelBinding","p":5423861}],"n":".ctor","o":"$ctor$2","d":1567340,"h":12886469228,"f":16777217},{"p":[{"n":"policyEnforcement","p":1632876},{"n":"protectionScenario","p":1698412},{"n":"customServiceNames","p":31457281}],"n":".ctor","o":"$ctor$3","d":1567340,"h":17181436524,"f":16777217},{"p":[{"n":"policyEnforcement","p":1632876},{"n":"protectionScenario","p":1698412},{"n":"customServiceNames","p":1763948}],"n":".ctor","o":"$ctor$4","d":1567340,"h":21476403820,"f":16777217}],"i":[113246209],"h":1567340}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.SslClientHelloInfo", ($self) => class SslClientHelloInfo extends $.$$.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            $ctor$3(/*string*/ serverName, /*System.Security.Authentication.SslProtocols*/ sslProtocols)
            {
                super.$ctor$1();
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*string */ get ServerName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocols()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 1174124;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21476010604,"f":50331649},"n":"ServerName","d":1174124,"h":17181043308,"f":2097153},{"p":5620469,"g":{"r":0,"d":0,"h":30065945196,"f":50331649},"n":"SslProtocols","d":1174124,"h":25770977900,"f":2097153}],"l":[{"t":131073,"n":"_dummy","d":1174124,"h":4296141420,"f":4194306},{"t":655361,"n":"_dummyPrimitive","d":1174124,"h":8591108716,"f":4194306}],"c":[{"p":[{"n":"serverName","p":1310721},{"n":"sslProtocols","p":5620469}],"n":".ctor","o":"$ctor$3","d":1174124,"h":12886076012,"f":16777217},{"n":".ctor","o":"$ctor$2","d":1174124,"h":34360912492,"f":16777217}],"h":1174124}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Net.Security.SslClientHelloInfo`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.SslApplicationProtocol", ($self) => class SslApplicationProtocol extends $.$$.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.Security.SslApplicationProtocol*/ static Http11;
            /*System.Net.Security.SslApplicationProtocol*/ static Http2;
            /*System.Net.Security.SslApplicationProtocol*/ static Http3;
            $ctor$3(/*byte[]*/ protocol)
            {
                super.$ctor$1();
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            $ctor$4(/*string*/ protocol)
            {
                super.$ctor$1();
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*System.ReadOnlyMemory<byte> */ get Protocol()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Security.SslApplicationProtocol*/ other)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$snsc.System.Net.Security.SslApplicationProtocol.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snsc.System.Net.Security.SslApplicationProtocol.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Security.SslApplicationProtocol*/ left, /*System.Net.Security.SslApplicationProtocol*/ right)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Security.SslApplicationProtocol*/ left, /*System.Net.Security.SslApplicationProtocol*/ right)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snsc.System.Net.Security.SslApplicationProtocol.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Net.Security.SslApplicationProtocol>.Equals(System.Net.Security.SslApplicationProtocol)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Http11 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
                {
                    this.Http2 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
                {
                    this.Http3 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
            }
            static $h = 977516;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":38655683180,"f":50331649},"n":"Protocol","d":977516,"h":34360715884,"f":2097153}],"m":[{"r":262145,"p":[{"n":"other","p":977516}],"n":"Equals","o":"@$2","d":977516,"h":42950650476,"f":16777217},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":977516,"h":47245617772,"f":16809985},{"r":655361,"n":"GetHashCode","d":977516,"h":51540585068,"f":16809985},{"r":1310721,"n":"ToString","d":977516,"h":64425486956,"f":16809985}],"l":[{"t":131073,"n":"_dummy","d":977516,"h":4295944812,"f":4194306},{"t":655361,"n":"_dummyPrimitive","d":977516,"h":8590912108,"f":4194306},{"t":977516,"n":"Http11","d":977516,"h":12885879404,"f":4194337},{"t":977516,"n":"Http2","d":977516,"h":17180846700,"f":4194337},{"t":977516,"n":"Http3","d":977516,"h":21475813996,"f":4194337}],"c":[{"p":[{"n":"protocol","p":$.$typeArray($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$3","d":977516,"h":25770781292,"f":16777217},{"p":[{"n":"protocol","p":1310721}],"n":".ctor","o":"$ctor$4","d":977516,"h":30065748588,"f":16777217},{"n":".ctor","o":"$ctor$2","d":977516,"h":68720454252,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h],"h":977516}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$snsc.System.Net.Security.SslApplicationProtocol) ]; }
            static get $fullName() { return `System.Net.Security.SslApplicationProtocol`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.ExtendedProtection.ServiceNameCollection", ($self) => class ServiceNameCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2(/*System.Collections.ICollection*/ items)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ Contains(/*string?*/ searchServiceName)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection */ Merge(/*System.Collections.IEnumerable*/ serviceNames)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection */ Merge$1(/*string*/ serviceName)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1763948;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"m":[{"r":262145,"p":[{"n":"searchServiceName","p":1310721}],"n":"Contains","d":1763948,"h":8591698540,"f":16777217},{"r":1763948,"p":[{"n":"serviceNames","p":31719425}],"n":"Merge","d":1763948,"h":12886665836,"f":16777217},{"r":1763948,"p":[{"n":"serviceName","p":1310721}],"n":"Merge","o":"@$1","d":1763948,"h":17181633132,"f":16777217}],"c":[{"p":[{"n":"items","p":31457281}],"n":".ctor","o":"$ctor$2","d":1763948,"h":4296731244,"f":16777217}],"i":[31457281,31719425],"h":1763948}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Collections.ICollection, $.$$.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ServiceNameCollection`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.LocalCertificateSelectionCallback", ($self) => class LocalCertificateSelectionCallback extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate?*/ Invoke(/*$.$$.System.Object*/ sender, /*$.$$.System.String*/ targetHost, /*$.$sscr.System.Security.Cryptography.X509Certificates.X509CertificateCollection*/ localCertificates, /*$.$$.System.Nullable$$*/ remoteCertificate, /**/ acceptableIssuers)
            {
                return this.$nativeFunction.call(this.$target, sender, targetHost, localCertificates, remoteCertificate, acceptableIssuers);
            }
            static $h = 322156;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":28160783,"p":[{"n":"sender","p":131073},{"n":"targetHost","p":1310721},{"n":"localCertificates","p":28422927},{"n":"remoteCertificate","p":28160783},{"n":"acceptableIssuers","p":$.$typeArray($.$$.System.String).$h}],"n":"Invoke","d":322156,"h":8590256748,"f":16777345},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"targetHost","p":1310721},{"n":"localCertificates","p":28422927},{"n":"remoteCertificate","p":28160783},{"n":"acceptableIssuers","p":$.$typeArray($.$$.System.String).$h},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":322156,"h":12885224044,"f":16777345},{"r":28160783,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":322156,"h":17180191340,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":322156,"h":4295289452,"f":16777217}],"i":[57212929,113246209],"h":322156}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.LocalCertificateSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.RemoteCertificateValidationCallback", ($self) => class RemoteCertificateValidationCallback extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*bool*/ Invoke(/*$.$$.System.Object*/ sender, /*$.$$.System.Nullable$$*/ certificate, /*$.$$.System.Nullable$$*/ chain, /*$.$snp.System.Net.Security.SslPolicyErrors*/ sslPolicyErrors)
            {
                return this.$nativeFunction.call(this.$target, sender, certificate, chain, sslPolicyErrors);
            }
            static $h = 780908;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":262145,"p":[{"n":"sender","p":131073},{"n":"certificate","p":28160783},{"n":"chain","p":28881679},{"n":"sslPolicyErrors","p":4309749}],"n":"Invoke","d":780908,"h":8590715500,"f":16777345},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"certificate","p":28160783},{"n":"chain","p":28881679},{"n":"sslPolicyErrors","p":4309749},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":780908,"h":12885682796,"f":16777345},{"r":262145,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":780908,"h":17180650092,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":780908,"h":4295748204,"f":16777217}],"i":[57212929,113246209],"h":780908}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.RemoteCertificateValidationCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.ServerCertificateSelectionCallback", ($self) => class ServerCertificateSelectionCallback extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate*/ Invoke(/*$.$$.System.Object*/ sender, /*$.$$.System.Nullable$$*/ hostName)
            {
                return this.$nativeFunction.call(this.$target, sender, hostName);
            }
            static $h = 846444;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":28160783,"p":[{"n":"sender","p":131073},{"n":"hostName","p":1310721}],"n":"Invoke","d":846444,"h":8590781036,"f":16777345},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"hostName","p":1310721},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":846444,"h":12885748332,"f":16777345},{"r":28160783,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":846444,"h":17180715628,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":846444,"h":4295813740,"f":16777217}],"i":[57212929,113246209],"h":846444}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.ServerCertificateSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.ServerOptionsSelectionCallback", ($self) => class ServerOptionsSelectionCallback extends $.$$.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Security.SslServerAuthenticationOptions>*/ Invoke(/*$.$snsc.System.Net.Security.SslStream*/ stream, /*$.$snsc.System.Net.Security.SslClientHelloInfo*/ clientHelloInfo, /*$.$$.System.Nullable$$*/ state, /*$.$$.System.Threading.CancellationToken*/ cancellationToken)
            {
                return this.$nativeFunction.call(this.$target, stream, clientHelloInfo, state, cancellationToken);
            }
            static $h = 911980;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$snsc.System.Net.Security.SslServerAuthenticationOptions).$h,"p":[{"n":"stream","p":1305196},{"n":"clientHelloInfo","p":1174124},{"n":"state","p":131073},{"n":"cancellationToken","p":125829121}],"n":"Invoke","d":911980,"h":8590846572,"f":16777345},{"r":57016321,"p":[{"n":"stream","p":1305196},{"n":"clientHelloInfo","p":1174124},{"n":"state","p":131073},{"n":"cancellationToken","p":125829121},{"n":"callback","p":14548993},{"n":"object","p":131073}],"n":"BeginInvoke","d":911980,"h":12885813868,"f":16777345},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$snsc.System.Net.Security.SslServerAuthenticationOptions).$h,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":911980,"h":17180781164,"f":16777345}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":911980,"h":4295879276,"f":16777217}],"i":[57212929,113246209],"h":911980}; }
            static get $b() { return $.$$.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.ICloneable, $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.ServerOptionsSelectionCallback`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.EncryptionPolicy", ($self) => class EncryptionPolicy extends $.$$.System.Enum
        {
            static RequireEncryption = 0;
            static AllowNoEncryption = 1;
            static NoEncryption = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "RequireEncryption": 0n,
                    "AllowNoEncryption": 1n,
                    "NoEncryption": 2n
                };
            }
            static $h = 256620;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":256620,"n":"RequireEncryption","d":256620,"h":4295223916,"f":4194337},{"t":256620,"n":"AllowNoEncryption","d":256620,"h":8590191212,"f":4194337,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0040","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"t":256620,"n":"NoEncryption","d":256620,"h":12885158508,"f":4194337,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0040","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":256620,"h":17180125804,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":256620}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.EncryptionPolicy`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.NegotiateAuthenticationStatusCode", ($self) => class NegotiateAuthenticationStatusCode extends $.$$.System.Enum
        {
            static Completed = 0;
            static ContinueNeeded = 1;
            static GenericFailure = 2;
            static BadBinding = 3;
            static Unsupported = 4;
            static MessageAltered = 5;
            static ContextExpired = 6;
            static CredentialsExpired = 7;
            static InvalidCredentials = 8;
            static InvalidToken = 9;
            static UnknownCredentials = 10;
            static QopNotSupported = 11;
            static OutOfSequence = 12;
            static SecurityQosFailed = 13;
            static TargetUnknown = 14;
            static ImpersonationValidationFailed = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Completed": 0n,
                    "ContinueNeeded": 1n,
                    "GenericFailure": 2n,
                    "BadBinding": 3n,
                    "Unsupported": 4n,
                    "MessageAltered": 5n,
                    "ContextExpired": 6n,
                    "CredentialsExpired": 7n,
                    "InvalidCredentials": 8n,
                    "InvalidToken": 9n,
                    "UnknownCredentials": 10n,
                    "QopNotSupported": 11n,
                    "OutOfSequence": 12n,
                    "SecurityQosFailed": 13n,
                    "TargetUnknown": 14n,
                    "ImpersonationValidationFailed": 15n
                };
            }
            static $h = 584300;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":584300,"n":"Completed","d":584300,"h":4295551596,"f":4194337},{"t":584300,"n":"ContinueNeeded","d":584300,"h":8590518892,"f":4194337},{"t":584300,"n":"GenericFailure","d":584300,"h":12885486188,"f":4194337},{"t":584300,"n":"BadBinding","d":584300,"h":17180453484,"f":4194337},{"t":584300,"n":"Unsupported","d":584300,"h":21475420780,"f":4194337},{"t":584300,"n":"MessageAltered","d":584300,"h":25770388076,"f":4194337},{"t":584300,"n":"ContextExpired","d":584300,"h":30065355372,"f":4194337},{"t":584300,"n":"CredentialsExpired","d":584300,"h":34360322668,"f":4194337},{"t":584300,"n":"InvalidCredentials","d":584300,"h":38655289964,"f":4194337},{"t":584300,"n":"InvalidToken","d":584300,"h":42950257260,"f":4194337},{"t":584300,"n":"UnknownCredentials","d":584300,"h":47245224556,"f":4194337},{"t":584300,"n":"QopNotSupported","d":584300,"h":51540191852,"f":4194337},{"t":584300,"n":"OutOfSequence","d":584300,"h":55835159148,"f":4194337},{"t":584300,"n":"SecurityQosFailed","d":584300,"h":60130126444,"f":4194337},{"t":584300,"n":"TargetUnknown","d":584300,"h":64425093740,"f":4194337},{"t":584300,"n":"ImpersonationValidationFailed","d":584300,"h":68720061036,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":584300,"h":73015028332,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":584300}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationStatusCode`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.ProtectionLevel", ($self) => class ProtectionLevel extends $.$$.System.Enum
        {
            static None = 0;
            static Sign = 1;
            static EncryptAndSign = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Sign": 1n,
                    "EncryptAndSign": 2n
                };
            }
            static $h = 715372;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":715372,"n":"None","d":715372,"h":4295682668,"f":4194337},{"t":715372,"n":"Sign","d":715372,"h":8590649964,"f":4194337},{"t":715372,"n":"EncryptAndSign","d":715372,"h":12885617260,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":715372,"h":17180584556,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":715372}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.ProtectionLevel`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.TlsCipherSuite", ($self) => class TlsCipherSuite extends $.$$.System.Enum
        {
            static TLS_NULL_WITH_NULL_NULL = 0;
            static TLS_RSA_WITH_NULL_MD5 = 1;
            static TLS_RSA_WITH_NULL_SHA = 2;
            static TLS_RSA_EXPORT_WITH_RC4_40_MD5 = 3;
            static TLS_RSA_WITH_RC4_128_MD5 = 4;
            static TLS_RSA_WITH_RC4_128_SHA = 5;
            static TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5 = 6;
            static TLS_RSA_WITH_IDEA_CBC_SHA = 7;
            static TLS_RSA_EXPORT_WITH_DES40_CBC_SHA = 8;
            static TLS_RSA_WITH_DES_CBC_SHA = 9;
            static TLS_RSA_WITH_3DES_EDE_CBC_SHA = 10;
            static TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA = 11;
            static TLS_DH_DSS_WITH_DES_CBC_SHA = 12;
            static TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA = 13;
            static TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA = 14;
            static TLS_DH_RSA_WITH_DES_CBC_SHA = 15;
            static TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA = 16;
            static TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA = 17;
            static TLS_DHE_DSS_WITH_DES_CBC_SHA = 18;
            static TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA = 19;
            static TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA = 20;
            static TLS_DHE_RSA_WITH_DES_CBC_SHA = 21;
            static TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA = 22;
            static TLS_DH_anon_EXPORT_WITH_RC4_40_MD5 = 23;
            static TLS_DH_anon_WITH_RC4_128_MD5 = 24;
            static TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA = 25;
            static TLS_DH_anon_WITH_DES_CBC_SHA = 26;
            static TLS_DH_anon_WITH_3DES_EDE_CBC_SHA = 27;
            static TLS_KRB5_WITH_DES_CBC_SHA = 30;
            static TLS_KRB5_WITH_3DES_EDE_CBC_SHA = 31;
            static TLS_KRB5_WITH_RC4_128_SHA = 32;
            static TLS_KRB5_WITH_IDEA_CBC_SHA = 33;
            static TLS_KRB5_WITH_DES_CBC_MD5 = 34;
            static TLS_KRB5_WITH_3DES_EDE_CBC_MD5 = 35;
            static TLS_KRB5_WITH_RC4_128_MD5 = 36;
            static TLS_KRB5_WITH_IDEA_CBC_MD5 = 37;
            static TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA = 38;
            static TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA = 39;
            static TLS_KRB5_EXPORT_WITH_RC4_40_SHA = 40;
            static TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5 = 41;
            static TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5 = 42;
            static TLS_KRB5_EXPORT_WITH_RC4_40_MD5 = 43;
            static TLS_PSK_WITH_NULL_SHA = 44;
            static TLS_DHE_PSK_WITH_NULL_SHA = 45;
            static TLS_RSA_PSK_WITH_NULL_SHA = 46;
            static TLS_RSA_WITH_AES_128_CBC_SHA = 47;
            static TLS_DH_DSS_WITH_AES_128_CBC_SHA = 48;
            static TLS_DH_RSA_WITH_AES_128_CBC_SHA = 49;
            static TLS_DHE_DSS_WITH_AES_128_CBC_SHA = 50;
            static TLS_DHE_RSA_WITH_AES_128_CBC_SHA = 51;
            static TLS_DH_anon_WITH_AES_128_CBC_SHA = 52;
            static TLS_RSA_WITH_AES_256_CBC_SHA = 53;
            static TLS_DH_DSS_WITH_AES_256_CBC_SHA = 54;
            static TLS_DH_RSA_WITH_AES_256_CBC_SHA = 55;
            static TLS_DHE_DSS_WITH_AES_256_CBC_SHA = 56;
            static TLS_DHE_RSA_WITH_AES_256_CBC_SHA = 57;
            static TLS_DH_anon_WITH_AES_256_CBC_SHA = 58;
            static TLS_RSA_WITH_NULL_SHA256 = 59;
            static TLS_RSA_WITH_AES_128_CBC_SHA256 = 60;
            static TLS_RSA_WITH_AES_256_CBC_SHA256 = 61;
            static TLS_DH_DSS_WITH_AES_128_CBC_SHA256 = 62;
            static TLS_DH_RSA_WITH_AES_128_CBC_SHA256 = 63;
            static TLS_DHE_DSS_WITH_AES_128_CBC_SHA256 = 64;
            static TLS_RSA_WITH_CAMELLIA_128_CBC_SHA = 65;
            static TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA = 66;
            static TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA = 67;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA = 68;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA = 69;
            static TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA = 70;
            static TLS_DHE_RSA_WITH_AES_128_CBC_SHA256 = 103;
            static TLS_DH_DSS_WITH_AES_256_CBC_SHA256 = 104;
            static TLS_DH_RSA_WITH_AES_256_CBC_SHA256 = 105;
            static TLS_DHE_DSS_WITH_AES_256_CBC_SHA256 = 106;
            static TLS_DHE_RSA_WITH_AES_256_CBC_SHA256 = 107;
            static TLS_DH_anon_WITH_AES_128_CBC_SHA256 = 108;
            static TLS_DH_anon_WITH_AES_256_CBC_SHA256 = 109;
            static TLS_RSA_WITH_CAMELLIA_256_CBC_SHA = 132;
            static TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA = 133;
            static TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA = 134;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA = 135;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA = 136;
            static TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA = 137;
            static TLS_PSK_WITH_RC4_128_SHA = 138;
            static TLS_PSK_WITH_3DES_EDE_CBC_SHA = 139;
            static TLS_PSK_WITH_AES_128_CBC_SHA = 140;
            static TLS_PSK_WITH_AES_256_CBC_SHA = 141;
            static TLS_DHE_PSK_WITH_RC4_128_SHA = 142;
            static TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA = 143;
            static TLS_DHE_PSK_WITH_AES_128_CBC_SHA = 144;
            static TLS_DHE_PSK_WITH_AES_256_CBC_SHA = 145;
            static TLS_RSA_PSK_WITH_RC4_128_SHA = 146;
            static TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA = 147;
            static TLS_RSA_PSK_WITH_AES_128_CBC_SHA = 148;
            static TLS_RSA_PSK_WITH_AES_256_CBC_SHA = 149;
            static TLS_RSA_WITH_SEED_CBC_SHA = 150;
            static TLS_DH_DSS_WITH_SEED_CBC_SHA = 151;
            static TLS_DH_RSA_WITH_SEED_CBC_SHA = 152;
            static TLS_DHE_DSS_WITH_SEED_CBC_SHA = 153;
            static TLS_DHE_RSA_WITH_SEED_CBC_SHA = 154;
            static TLS_DH_anon_WITH_SEED_CBC_SHA = 155;
            static TLS_RSA_WITH_AES_128_GCM_SHA256 = 156;
            static TLS_RSA_WITH_AES_256_GCM_SHA384 = 157;
            static TLS_DHE_RSA_WITH_AES_128_GCM_SHA256 = 158;
            static TLS_DHE_RSA_WITH_AES_256_GCM_SHA384 = 159;
            static TLS_DH_RSA_WITH_AES_128_GCM_SHA256 = 160;
            static TLS_DH_RSA_WITH_AES_256_GCM_SHA384 = 161;
            static TLS_DHE_DSS_WITH_AES_128_GCM_SHA256 = 162;
            static TLS_DHE_DSS_WITH_AES_256_GCM_SHA384 = 163;
            static TLS_DH_DSS_WITH_AES_128_GCM_SHA256 = 164;
            static TLS_DH_DSS_WITH_AES_256_GCM_SHA384 = 165;
            static TLS_DH_anon_WITH_AES_128_GCM_SHA256 = 166;
            static TLS_DH_anon_WITH_AES_256_GCM_SHA384 = 167;
            static TLS_PSK_WITH_AES_128_GCM_SHA256 = 168;
            static TLS_PSK_WITH_AES_256_GCM_SHA384 = 169;
            static TLS_DHE_PSK_WITH_AES_128_GCM_SHA256 = 170;
            static TLS_DHE_PSK_WITH_AES_256_GCM_SHA384 = 171;
            static TLS_RSA_PSK_WITH_AES_128_GCM_SHA256 = 172;
            static TLS_RSA_PSK_WITH_AES_256_GCM_SHA384 = 173;
            static TLS_PSK_WITH_AES_128_CBC_SHA256 = 174;
            static TLS_PSK_WITH_AES_256_CBC_SHA384 = 175;
            static TLS_PSK_WITH_NULL_SHA256 = 176;
            static TLS_PSK_WITH_NULL_SHA384 = 177;
            static TLS_DHE_PSK_WITH_AES_128_CBC_SHA256 = 178;
            static TLS_DHE_PSK_WITH_AES_256_CBC_SHA384 = 179;
            static TLS_DHE_PSK_WITH_NULL_SHA256 = 180;
            static TLS_DHE_PSK_WITH_NULL_SHA384 = 181;
            static TLS_RSA_PSK_WITH_AES_128_CBC_SHA256 = 182;
            static TLS_RSA_PSK_WITH_AES_256_CBC_SHA384 = 183;
            static TLS_RSA_PSK_WITH_NULL_SHA256 = 184;
            static TLS_RSA_PSK_WITH_NULL_SHA384 = 185;
            static TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 186;
            static TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256 = 187;
            static TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 188;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256 = 189;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 190;
            static TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256 = 191;
            static TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 192;
            static TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256 = 193;
            static TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 194;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256 = 195;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 196;
            static TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256 = 197;
            static TLS_AES_128_GCM_SHA256 = 4865;
            static TLS_AES_256_GCM_SHA384 = 4866;
            static TLS_CHACHA20_POLY1305_SHA256 = 4867;
            static TLS_AES_128_CCM_SHA256 = 4868;
            static TLS_AES_128_CCM_8_SHA256 = 4869;
            static TLS_ECDH_ECDSA_WITH_NULL_SHA = 49153;
            static TLS_ECDH_ECDSA_WITH_RC4_128_SHA = 49154;
            static TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA = 49155;
            static TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA = 49156;
            static TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA = 49157;
            static TLS_ECDHE_ECDSA_WITH_NULL_SHA = 49158;
            static TLS_ECDHE_ECDSA_WITH_RC4_128_SHA = 49159;
            static TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA = 49160;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA = 49161;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA = 49162;
            static TLS_ECDH_RSA_WITH_NULL_SHA = 49163;
            static TLS_ECDH_RSA_WITH_RC4_128_SHA = 49164;
            static TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA = 49165;
            static TLS_ECDH_RSA_WITH_AES_128_CBC_SHA = 49166;
            static TLS_ECDH_RSA_WITH_AES_256_CBC_SHA = 49167;
            static TLS_ECDHE_RSA_WITH_NULL_SHA = 49168;
            static TLS_ECDHE_RSA_WITH_RC4_128_SHA = 49169;
            static TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA = 49170;
            static TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA = 49171;
            static TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA = 49172;
            static TLS_ECDH_anon_WITH_NULL_SHA = 49173;
            static TLS_ECDH_anon_WITH_RC4_128_SHA = 49174;
            static TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA = 49175;
            static TLS_ECDH_anon_WITH_AES_128_CBC_SHA = 49176;
            static TLS_ECDH_anon_WITH_AES_256_CBC_SHA = 49177;
            static TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA = 49178;
            static TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA = 49179;
            static TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA = 49180;
            static TLS_SRP_SHA_WITH_AES_128_CBC_SHA = 49181;
            static TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA = 49182;
            static TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA = 49183;
            static TLS_SRP_SHA_WITH_AES_256_CBC_SHA = 49184;
            static TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA = 49185;
            static TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA = 49186;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256 = 49187;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384 = 49188;
            static TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256 = 49189;
            static TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384 = 49190;
            static TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256 = 49191;
            static TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384 = 49192;
            static TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256 = 49193;
            static TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384 = 49194;
            static TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256 = 49195;
            static TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384 = 49196;
            static TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256 = 49197;
            static TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384 = 49198;
            static TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 = 49199;
            static TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 = 49200;
            static TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256 = 49201;
            static TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384 = 49202;
            static TLS_ECDHE_PSK_WITH_RC4_128_SHA = 49203;
            static TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA = 49204;
            static TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA = 49205;
            static TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA = 49206;
            static TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256 = 49207;
            static TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384 = 49208;
            static TLS_ECDHE_PSK_WITH_NULL_SHA = 49209;
            static TLS_ECDHE_PSK_WITH_NULL_SHA256 = 49210;
            static TLS_ECDHE_PSK_WITH_NULL_SHA384 = 49211;
            static TLS_RSA_WITH_ARIA_128_CBC_SHA256 = 49212;
            static TLS_RSA_WITH_ARIA_256_CBC_SHA384 = 49213;
            static TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256 = 49214;
            static TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384 = 49215;
            static TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256 = 49216;
            static TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384 = 49217;
            static TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256 = 49218;
            static TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384 = 49219;
            static TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256 = 49220;
            static TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384 = 49221;
            static TLS_DH_anon_WITH_ARIA_128_CBC_SHA256 = 49222;
            static TLS_DH_anon_WITH_ARIA_256_CBC_SHA384 = 49223;
            static TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256 = 49224;
            static TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384 = 49225;
            static TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256 = 49226;
            static TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384 = 49227;
            static TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256 = 49228;
            static TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384 = 49229;
            static TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256 = 49230;
            static TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384 = 49231;
            static TLS_RSA_WITH_ARIA_128_GCM_SHA256 = 49232;
            static TLS_RSA_WITH_ARIA_256_GCM_SHA384 = 49233;
            static TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256 = 49234;
            static TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384 = 49235;
            static TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256 = 49236;
            static TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384 = 49237;
            static TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256 = 49238;
            static TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384 = 49239;
            static TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256 = 49240;
            static TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384 = 49241;
            static TLS_DH_anon_WITH_ARIA_128_GCM_SHA256 = 49242;
            static TLS_DH_anon_WITH_ARIA_256_GCM_SHA384 = 49243;
            static TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256 = 49244;
            static TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384 = 49245;
            static TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256 = 49246;
            static TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384 = 49247;
            static TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256 = 49248;
            static TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384 = 49249;
            static TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256 = 49250;
            static TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384 = 49251;
            static TLS_PSK_WITH_ARIA_128_CBC_SHA256 = 49252;
            static TLS_PSK_WITH_ARIA_256_CBC_SHA384 = 49253;
            static TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256 = 49254;
            static TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384 = 49255;
            static TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256 = 49256;
            static TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384 = 49257;
            static TLS_PSK_WITH_ARIA_128_GCM_SHA256 = 49258;
            static TLS_PSK_WITH_ARIA_256_GCM_SHA384 = 49259;
            static TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256 = 49260;
            static TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384 = 49261;
            static TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256 = 49262;
            static TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384 = 49263;
            static TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256 = 49264;
            static TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384 = 49265;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 = 49266;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 = 49267;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 = 49268;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 = 49269;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 49270;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384 = 49271;
            static TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 49272;
            static TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384 = 49273;
            static TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49274;
            static TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49275;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49276;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49277;
            static TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49278;
            static TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49279;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256 = 49280;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384 = 49281;
            static TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256 = 49282;
            static TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384 = 49283;
            static TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256 = 49284;
            static TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384 = 49285;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 = 49286;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 = 49287;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 = 49288;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 = 49289;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49290;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49291;
            static TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49292;
            static TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49293;
            static TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49294;
            static TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49295;
            static TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49296;
            static TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49297;
            static TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49298;
            static TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49299;
            static TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49300;
            static TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49301;
            static TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49302;
            static TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49303;
            static TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49304;
            static TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49305;
            static TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49306;
            static TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49307;
            static TLS_RSA_WITH_AES_128_CCM = 49308;
            static TLS_RSA_WITH_AES_256_CCM = 49309;
            static TLS_DHE_RSA_WITH_AES_128_CCM = 49310;
            static TLS_DHE_RSA_WITH_AES_256_CCM = 49311;
            static TLS_RSA_WITH_AES_128_CCM_8 = 49312;
            static TLS_RSA_WITH_AES_256_CCM_8 = 49313;
            static TLS_DHE_RSA_WITH_AES_128_CCM_8 = 49314;
            static TLS_DHE_RSA_WITH_AES_256_CCM_8 = 49315;
            static TLS_PSK_WITH_AES_128_CCM = 49316;
            static TLS_PSK_WITH_AES_256_CCM = 49317;
            static TLS_DHE_PSK_WITH_AES_128_CCM = 49318;
            static TLS_DHE_PSK_WITH_AES_256_CCM = 49319;
            static TLS_PSK_WITH_AES_128_CCM_8 = 49320;
            static TLS_PSK_WITH_AES_256_CCM_8 = 49321;
            static TLS_PSK_DHE_WITH_AES_128_CCM_8 = 49322;
            static TLS_PSK_DHE_WITH_AES_256_CCM_8 = 49323;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CCM = 49324;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CCM = 49325;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8 = 49326;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8 = 49327;
            static TLS_ECCPWD_WITH_AES_128_GCM_SHA256 = 49328;
            static TLS_ECCPWD_WITH_AES_256_GCM_SHA384 = 49329;
            static TLS_ECCPWD_WITH_AES_128_CCM_SHA256 = 49330;
            static TLS_ECCPWD_WITH_AES_256_CCM_SHA384 = 49331;
            static TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256 = 52392;
            static TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256 = 52393;
            static TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256 = 52394;
            static TLS_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52395;
            static TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52396;
            static TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52397;
            static TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52398;
            static TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256 = 53249;
            static TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384 = 53250;
            static TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256 = 53251;
            static TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256 = 53253;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TLS_NULL_WITH_NULL_NULL": 0n,
                    "TLS_RSA_WITH_NULL_MD5": 1n,
                    "TLS_RSA_WITH_NULL_SHA": 2n,
                    "TLS_RSA_EXPORT_WITH_RC4_40_MD5": 3n,
                    "TLS_RSA_WITH_RC4_128_MD5": 4n,
                    "TLS_RSA_WITH_RC4_128_SHA": 5n,
                    "TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5": 6n,
                    "TLS_RSA_WITH_IDEA_CBC_SHA": 7n,
                    "TLS_RSA_EXPORT_WITH_DES40_CBC_SHA": 8n,
                    "TLS_RSA_WITH_DES_CBC_SHA": 9n,
                    "TLS_RSA_WITH_3DES_EDE_CBC_SHA": 10n,
                    "TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA": 11n,
                    "TLS_DH_DSS_WITH_DES_CBC_SHA": 12n,
                    "TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA": 13n,
                    "TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA": 14n,
                    "TLS_DH_RSA_WITH_DES_CBC_SHA": 15n,
                    "TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA": 16n,
                    "TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA": 17n,
                    "TLS_DHE_DSS_WITH_DES_CBC_SHA": 18n,
                    "TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA": 19n,
                    "TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA": 20n,
                    "TLS_DHE_RSA_WITH_DES_CBC_SHA": 21n,
                    "TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA": 22n,
                    "TLS_DH_anon_EXPORT_WITH_RC4_40_MD5": 23n,
                    "TLS_DH_anon_WITH_RC4_128_MD5": 24n,
                    "TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA": 25n,
                    "TLS_DH_anon_WITH_DES_CBC_SHA": 26n,
                    "TLS_DH_anon_WITH_3DES_EDE_CBC_SHA": 27n,
                    "TLS_KRB5_WITH_DES_CBC_SHA": 30n,
                    "TLS_KRB5_WITH_3DES_EDE_CBC_SHA": 31n,
                    "TLS_KRB5_WITH_RC4_128_SHA": 32n,
                    "TLS_KRB5_WITH_IDEA_CBC_SHA": 33n,
                    "TLS_KRB5_WITH_DES_CBC_MD5": 34n,
                    "TLS_KRB5_WITH_3DES_EDE_CBC_MD5": 35n,
                    "TLS_KRB5_WITH_RC4_128_MD5": 36n,
                    "TLS_KRB5_WITH_IDEA_CBC_MD5": 37n,
                    "TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA": 38n,
                    "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA": 39n,
                    "TLS_KRB5_EXPORT_WITH_RC4_40_SHA": 40n,
                    "TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5": 41n,
                    "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5": 42n,
                    "TLS_KRB5_EXPORT_WITH_RC4_40_MD5": 43n,
                    "TLS_PSK_WITH_NULL_SHA": 44n,
                    "TLS_DHE_PSK_WITH_NULL_SHA": 45n,
                    "TLS_RSA_PSK_WITH_NULL_SHA": 46n,
                    "TLS_RSA_WITH_AES_128_CBC_SHA": 47n,
                    "TLS_DH_DSS_WITH_AES_128_CBC_SHA": 48n,
                    "TLS_DH_RSA_WITH_AES_128_CBC_SHA": 49n,
                    "TLS_DHE_DSS_WITH_AES_128_CBC_SHA": 50n,
                    "TLS_DHE_RSA_WITH_AES_128_CBC_SHA": 51n,
                    "TLS_DH_anon_WITH_AES_128_CBC_SHA": 52n,
                    "TLS_RSA_WITH_AES_256_CBC_SHA": 53n,
                    "TLS_DH_DSS_WITH_AES_256_CBC_SHA": 54n,
                    "TLS_DH_RSA_WITH_AES_256_CBC_SHA": 55n,
                    "TLS_DHE_DSS_WITH_AES_256_CBC_SHA": 56n,
                    "TLS_DHE_RSA_WITH_AES_256_CBC_SHA": 57n,
                    "TLS_DH_anon_WITH_AES_256_CBC_SHA": 58n,
                    "TLS_RSA_WITH_NULL_SHA256": 59n,
                    "TLS_RSA_WITH_AES_128_CBC_SHA256": 60n,
                    "TLS_RSA_WITH_AES_256_CBC_SHA256": 61n,
                    "TLS_DH_DSS_WITH_AES_128_CBC_SHA256": 62n,
                    "TLS_DH_RSA_WITH_AES_128_CBC_SHA256": 63n,
                    "TLS_DHE_DSS_WITH_AES_128_CBC_SHA256": 64n,
                    "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA": 65n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA": 66n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA": 67n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA": 68n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA": 69n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA": 70n,
                    "TLS_DHE_RSA_WITH_AES_128_CBC_SHA256": 103n,
                    "TLS_DH_DSS_WITH_AES_256_CBC_SHA256": 104n,
                    "TLS_DH_RSA_WITH_AES_256_CBC_SHA256": 105n,
                    "TLS_DHE_DSS_WITH_AES_256_CBC_SHA256": 106n,
                    "TLS_DHE_RSA_WITH_AES_256_CBC_SHA256": 107n,
                    "TLS_DH_anon_WITH_AES_128_CBC_SHA256": 108n,
                    "TLS_DH_anon_WITH_AES_256_CBC_SHA256": 109n,
                    "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA": 132n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA": 133n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA": 134n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA": 135n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA": 136n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA": 137n,
                    "TLS_PSK_WITH_RC4_128_SHA": 138n,
                    "TLS_PSK_WITH_3DES_EDE_CBC_SHA": 139n,
                    "TLS_PSK_WITH_AES_128_CBC_SHA": 140n,
                    "TLS_PSK_WITH_AES_256_CBC_SHA": 141n,
                    "TLS_DHE_PSK_WITH_RC4_128_SHA": 142n,
                    "TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA": 143n,
                    "TLS_DHE_PSK_WITH_AES_128_CBC_SHA": 144n,
                    "TLS_DHE_PSK_WITH_AES_256_CBC_SHA": 145n,
                    "TLS_RSA_PSK_WITH_RC4_128_SHA": 146n,
                    "TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA": 147n,
                    "TLS_RSA_PSK_WITH_AES_128_CBC_SHA": 148n,
                    "TLS_RSA_PSK_WITH_AES_256_CBC_SHA": 149n,
                    "TLS_RSA_WITH_SEED_CBC_SHA": 150n,
                    "TLS_DH_DSS_WITH_SEED_CBC_SHA": 151n,
                    "TLS_DH_RSA_WITH_SEED_CBC_SHA": 152n,
                    "TLS_DHE_DSS_WITH_SEED_CBC_SHA": 153n,
                    "TLS_DHE_RSA_WITH_SEED_CBC_SHA": 154n,
                    "TLS_DH_anon_WITH_SEED_CBC_SHA": 155n,
                    "TLS_RSA_WITH_AES_128_GCM_SHA256": 156n,
                    "TLS_RSA_WITH_AES_256_GCM_SHA384": 157n,
                    "TLS_DHE_RSA_WITH_AES_128_GCM_SHA256": 158n,
                    "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384": 159n,
                    "TLS_DH_RSA_WITH_AES_128_GCM_SHA256": 160n,
                    "TLS_DH_RSA_WITH_AES_256_GCM_SHA384": 161n,
                    "TLS_DHE_DSS_WITH_AES_128_GCM_SHA256": 162n,
                    "TLS_DHE_DSS_WITH_AES_256_GCM_SHA384": 163n,
                    "TLS_DH_DSS_WITH_AES_128_GCM_SHA256": 164n,
                    "TLS_DH_DSS_WITH_AES_256_GCM_SHA384": 165n,
                    "TLS_DH_anon_WITH_AES_128_GCM_SHA256": 166n,
                    "TLS_DH_anon_WITH_AES_256_GCM_SHA384": 167n,
                    "TLS_PSK_WITH_AES_128_GCM_SHA256": 168n,
                    "TLS_PSK_WITH_AES_256_GCM_SHA384": 169n,
                    "TLS_DHE_PSK_WITH_AES_128_GCM_SHA256": 170n,
                    "TLS_DHE_PSK_WITH_AES_256_GCM_SHA384": 171n,
                    "TLS_RSA_PSK_WITH_AES_128_GCM_SHA256": 172n,
                    "TLS_RSA_PSK_WITH_AES_256_GCM_SHA384": 173n,
                    "TLS_PSK_WITH_AES_128_CBC_SHA256": 174n,
                    "TLS_PSK_WITH_AES_256_CBC_SHA384": 175n,
                    "TLS_PSK_WITH_NULL_SHA256": 176n,
                    "TLS_PSK_WITH_NULL_SHA384": 177n,
                    "TLS_DHE_PSK_WITH_AES_128_CBC_SHA256": 178n,
                    "TLS_DHE_PSK_WITH_AES_256_CBC_SHA384": 179n,
                    "TLS_DHE_PSK_WITH_NULL_SHA256": 180n,
                    "TLS_DHE_PSK_WITH_NULL_SHA384": 181n,
                    "TLS_RSA_PSK_WITH_AES_128_CBC_SHA256": 182n,
                    "TLS_RSA_PSK_WITH_AES_256_CBC_SHA384": 183n,
                    "TLS_RSA_PSK_WITH_NULL_SHA256": 184n,
                    "TLS_RSA_PSK_WITH_NULL_SHA384": 185n,
                    "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256": 186n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256": 187n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256": 188n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256": 189n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256": 190n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256": 191n,
                    "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256": 192n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256": 193n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256": 194n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256": 195n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256": 196n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256": 197n,
                    "TLS_AES_128_GCM_SHA256": 4865n,
                    "TLS_AES_256_GCM_SHA384": 4866n,
                    "TLS_CHACHA20_POLY1305_SHA256": 4867n,
                    "TLS_AES_128_CCM_SHA256": 4868n,
                    "TLS_AES_128_CCM_8_SHA256": 4869n,
                    "TLS_ECDH_ECDSA_WITH_NULL_SHA": 49153n,
                    "TLS_ECDH_ECDSA_WITH_RC4_128_SHA": 49154n,
                    "TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA": 49155n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA": 49156n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA": 49157n,
                    "TLS_ECDHE_ECDSA_WITH_NULL_SHA": 49158n,
                    "TLS_ECDHE_ECDSA_WITH_RC4_128_SHA": 49159n,
                    "TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA": 49160n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA": 49161n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA": 49162n,
                    "TLS_ECDH_RSA_WITH_NULL_SHA": 49163n,
                    "TLS_ECDH_RSA_WITH_RC4_128_SHA": 49164n,
                    "TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA": 49165n,
                    "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA": 49166n,
                    "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA": 49167n,
                    "TLS_ECDHE_RSA_WITH_NULL_SHA": 49168n,
                    "TLS_ECDHE_RSA_WITH_RC4_128_SHA": 49169n,
                    "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA": 49170n,
                    "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA": 49171n,
                    "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA": 49172n,
                    "TLS_ECDH_anon_WITH_NULL_SHA": 49173n,
                    "TLS_ECDH_anon_WITH_RC4_128_SHA": 49174n,
                    "TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA": 49175n,
                    "TLS_ECDH_anon_WITH_AES_128_CBC_SHA": 49176n,
                    "TLS_ECDH_anon_WITH_AES_256_CBC_SHA": 49177n,
                    "TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA": 49178n,
                    "TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA": 49179n,
                    "TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA": 49180n,
                    "TLS_SRP_SHA_WITH_AES_128_CBC_SHA": 49181n,
                    "TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA": 49182n,
                    "TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA": 49183n,
                    "TLS_SRP_SHA_WITH_AES_256_CBC_SHA": 49184n,
                    "TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA": 49185n,
                    "TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA": 49186n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256": 49187n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384": 49188n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256": 49189n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384": 49190n,
                    "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256": 49191n,
                    "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384": 49192n,
                    "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256": 49193n,
                    "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384": 49194n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256": 49195n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384": 49196n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256": 49197n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384": 49198n,
                    "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256": 49199n,
                    "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384": 49200n,
                    "TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256": 49201n,
                    "TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384": 49202n,
                    "TLS_ECDHE_PSK_WITH_RC4_128_SHA": 49203n,
                    "TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA": 49204n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA": 49205n,
                    "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA": 49206n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256": 49207n,
                    "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384": 49208n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA": 49209n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA256": 49210n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA384": 49211n,
                    "TLS_RSA_WITH_ARIA_128_CBC_SHA256": 49212n,
                    "TLS_RSA_WITH_ARIA_256_CBC_SHA384": 49213n,
                    "TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256": 49214n,
                    "TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384": 49215n,
                    "TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256": 49216n,
                    "TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384": 49217n,
                    "TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256": 49218n,
                    "TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384": 49219n,
                    "TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256": 49220n,
                    "TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384": 49221n,
                    "TLS_DH_anon_WITH_ARIA_128_CBC_SHA256": 49222n,
                    "TLS_DH_anon_WITH_ARIA_256_CBC_SHA384": 49223n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256": 49224n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384": 49225n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256": 49226n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384": 49227n,
                    "TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256": 49228n,
                    "TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384": 49229n,
                    "TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256": 49230n,
                    "TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384": 49231n,
                    "TLS_RSA_WITH_ARIA_128_GCM_SHA256": 49232n,
                    "TLS_RSA_WITH_ARIA_256_GCM_SHA384": 49233n,
                    "TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256": 49234n,
                    "TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384": 49235n,
                    "TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256": 49236n,
                    "TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384": 49237n,
                    "TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256": 49238n,
                    "TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384": 49239n,
                    "TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256": 49240n,
                    "TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384": 49241n,
                    "TLS_DH_anon_WITH_ARIA_128_GCM_SHA256": 49242n,
                    "TLS_DH_anon_WITH_ARIA_256_GCM_SHA384": 49243n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256": 49244n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384": 49245n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256": 49246n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384": 49247n,
                    "TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256": 49248n,
                    "TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384": 49249n,
                    "TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256": 49250n,
                    "TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384": 49251n,
                    "TLS_PSK_WITH_ARIA_128_CBC_SHA256": 49252n,
                    "TLS_PSK_WITH_ARIA_256_CBC_SHA384": 49253n,
                    "TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256": 49254n,
                    "TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384": 49255n,
                    "TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256": 49256n,
                    "TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384": 49257n,
                    "TLS_PSK_WITH_ARIA_128_GCM_SHA256": 49258n,
                    "TLS_PSK_WITH_ARIA_256_GCM_SHA384": 49259n,
                    "TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256": 49260n,
                    "TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384": 49261n,
                    "TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256": 49262n,
                    "TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384": 49263n,
                    "TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256": 49264n,
                    "TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384": 49265n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256": 49266n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384": 49267n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256": 49268n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384": 49269n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256": 49270n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384": 49271n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256": 49272n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384": 49273n,
                    "TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49274n,
                    "TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49275n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49276n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49277n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49278n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49279n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256": 49280n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384": 49281n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256": 49282n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384": 49283n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256": 49284n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384": 49285n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256": 49286n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384": 49287n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256": 49288n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384": 49289n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49290n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49291n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49292n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49293n,
                    "TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49294n,
                    "TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49295n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49296n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49297n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49298n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49299n,
                    "TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49300n,
                    "TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49301n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49302n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49303n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49304n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49305n,
                    "TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49306n,
                    "TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49307n,
                    "TLS_RSA_WITH_AES_128_CCM": 49308n,
                    "TLS_RSA_WITH_AES_256_CCM": 49309n,
                    "TLS_DHE_RSA_WITH_AES_128_CCM": 49310n,
                    "TLS_DHE_RSA_WITH_AES_256_CCM": 49311n,
                    "TLS_RSA_WITH_AES_128_CCM_8": 49312n,
                    "TLS_RSA_WITH_AES_256_CCM_8": 49313n,
                    "TLS_DHE_RSA_WITH_AES_128_CCM_8": 49314n,
                    "TLS_DHE_RSA_WITH_AES_256_CCM_8": 49315n,
                    "TLS_PSK_WITH_AES_128_CCM": 49316n,
                    "TLS_PSK_WITH_AES_256_CCM": 49317n,
                    "TLS_DHE_PSK_WITH_AES_128_CCM": 49318n,
                    "TLS_DHE_PSK_WITH_AES_256_CCM": 49319n,
                    "TLS_PSK_WITH_AES_128_CCM_8": 49320n,
                    "TLS_PSK_WITH_AES_256_CCM_8": 49321n,
                    "TLS_PSK_DHE_WITH_AES_128_CCM_8": 49322n,
                    "TLS_PSK_DHE_WITH_AES_256_CCM_8": 49323n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CCM": 49324n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CCM": 49325n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8": 49326n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8": 49327n,
                    "TLS_ECCPWD_WITH_AES_128_GCM_SHA256": 49328n,
                    "TLS_ECCPWD_WITH_AES_256_GCM_SHA384": 49329n,
                    "TLS_ECCPWD_WITH_AES_128_CCM_SHA256": 49330n,
                    "TLS_ECCPWD_WITH_AES_256_CCM_SHA384": 49331n,
                    "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256": 52392n,
                    "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256": 52393n,
                    "TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256": 52394n,
                    "TLS_PSK_WITH_CHACHA20_POLY1305_SHA256": 52395n,
                    "TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256": 52396n,
                    "TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256": 52397n,
                    "TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256": 52398n,
                    "TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256": 53249n,
                    "TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384": 53250n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256": 53251n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256": 53253n
                };
            }
            static $h = 1436268;
            static $z = 2;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.UInt16; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":589825,"l":[{"t":1436268,"n":"TLS_NULL_WITH_NULL_NULL","d":1436268,"h":4296403564,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_NULL_MD5","d":1436268,"h":8591370860,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_NULL_SHA","d":1436268,"h":12886338156,"f":4194337},{"t":1436268,"n":"TLS_RSA_EXPORT_WITH_RC4_40_MD5","d":1436268,"h":17181305452,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_RC4_128_MD5","d":1436268,"h":21476272748,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_RC4_128_SHA","d":1436268,"h":25771240044,"f":4194337},{"t":1436268,"n":"TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5","d":1436268,"h":30066207340,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_IDEA_CBC_SHA","d":1436268,"h":34361174636,"f":4194337},{"t":1436268,"n":"TLS_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1436268,"h":38656141932,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_DES_CBC_SHA","d":1436268,"h":42951109228,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":47246076524,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA","d":1436268,"h":51541043820,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_DES_CBC_SHA","d":1436268,"h":55836011116,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":60130978412,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1436268,"h":64425945708,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_DES_CBC_SHA","d":1436268,"h":68720913004,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":73015880300,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA","d":1436268,"h":77310847596,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_DES_CBC_SHA","d":1436268,"h":81605814892,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":85900782188,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1436268,"h":90195749484,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_DES_CBC_SHA","d":1436268,"h":94490716780,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":98785684076,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_EXPORT_WITH_RC4_40_MD5","d":1436268,"h":103080651372,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_RC4_128_MD5","d":1436268,"h":107375618668,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA","d":1436268,"h":111670585964,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_DES_CBC_SHA","d":1436268,"h":115965553260,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":120260520556,"f":4194337},{"t":1436268,"n":"TLS_KRB5_WITH_DES_CBC_SHA","d":1436268,"h":124555487852,"f":4194337},{"t":1436268,"n":"TLS_KRB5_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":128850455148,"f":4194337},{"t":1436268,"n":"TLS_KRB5_WITH_RC4_128_SHA","d":1436268,"h":133145422444,"f":4194337},{"t":1436268,"n":"TLS_KRB5_WITH_IDEA_CBC_SHA","d":1436268,"h":137440389740,"f":4194337},{"t":1436268,"n":"TLS_KRB5_WITH_DES_CBC_MD5","d":1436268,"h":141735357036,"f":4194337},{"t":1436268,"n":"TLS_KRB5_WITH_3DES_EDE_CBC_MD5","d":1436268,"h":146030324332,"f":4194337},{"t":1436268,"n":"TLS_KRB5_WITH_RC4_128_MD5","d":1436268,"h":150325291628,"f":4194337},{"t":1436268,"n":"TLS_KRB5_WITH_IDEA_CBC_MD5","d":1436268,"h":154620258924,"f":4194337},{"t":1436268,"n":"TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA","d":1436268,"h":158915226220,"f":4194337},{"t":1436268,"n":"TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA","d":1436268,"h":163210193516,"f":4194337},{"t":1436268,"n":"TLS_KRB5_EXPORT_WITH_RC4_40_SHA","d":1436268,"h":167505160812,"f":4194337},{"t":1436268,"n":"TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5","d":1436268,"h":171800128108,"f":4194337},{"t":1436268,"n":"TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5","d":1436268,"h":176095095404,"f":4194337},{"t":1436268,"n":"TLS_KRB5_EXPORT_WITH_RC4_40_MD5","d":1436268,"h":180390062700,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_NULL_SHA","d":1436268,"h":184685029996,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_NULL_SHA","d":1436268,"h":188979997292,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_NULL_SHA","d":1436268,"h":193274964588,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_AES_128_CBC_SHA","d":1436268,"h":197569931884,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_AES_128_CBC_SHA","d":1436268,"h":201864899180,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_AES_128_CBC_SHA","d":1436268,"h":206159866476,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_AES_128_CBC_SHA","d":1436268,"h":210454833772,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_AES_128_CBC_SHA","d":1436268,"h":214749801068,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_AES_128_CBC_SHA","d":1436268,"h":219044768364,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_AES_256_CBC_SHA","d":1436268,"h":223339735660,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_AES_256_CBC_SHA","d":1436268,"h":227634702956,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_AES_256_CBC_SHA","d":1436268,"h":231929670252,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_AES_256_CBC_SHA","d":1436268,"h":236224637548,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_AES_256_CBC_SHA","d":1436268,"h":240519604844,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_AES_256_CBC_SHA","d":1436268,"h":244814572140,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_NULL_SHA256","d":1436268,"h":249109539436,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_AES_128_CBC_SHA256","d":1436268,"h":253404506732,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_AES_256_CBC_SHA256","d":1436268,"h":257699474028,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_AES_128_CBC_SHA256","d":1436268,"h":261994441324,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_AES_128_CBC_SHA256","d":1436268,"h":266289408620,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_AES_128_CBC_SHA256","d":1436268,"h":270584375916,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1436268,"h":274879343212,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA","d":1436268,"h":279174310508,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1436268,"h":283469277804,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA","d":1436268,"h":287764245100,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1436268,"h":292059212396,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA","d":1436268,"h":296354179692,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_AES_128_CBC_SHA256","d":1436268,"h":300649146988,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_AES_256_CBC_SHA256","d":1436268,"h":304944114284,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_AES_256_CBC_SHA256","d":1436268,"h":309239081580,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_AES_256_CBC_SHA256","d":1436268,"h":313534048876,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_AES_256_CBC_SHA256","d":1436268,"h":317829016172,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_AES_128_CBC_SHA256","d":1436268,"h":322123983468,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_AES_256_CBC_SHA256","d":1436268,"h":326418950764,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1436268,"h":330713918060,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA","d":1436268,"h":335008885356,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1436268,"h":339303852652,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA","d":1436268,"h":343598819948,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1436268,"h":347893787244,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA","d":1436268,"h":352188754540,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_RC4_128_SHA","d":1436268,"h":356483721836,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":360778689132,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_AES_128_CBC_SHA","d":1436268,"h":365073656428,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_AES_256_CBC_SHA","d":1436268,"h":369368623724,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_RC4_128_SHA","d":1436268,"h":373663591020,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":377958558316,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_AES_128_CBC_SHA","d":1436268,"h":382253525612,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_AES_256_CBC_SHA","d":1436268,"h":386548492908,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_RC4_128_SHA","d":1436268,"h":390843460204,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":395138427500,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_AES_128_CBC_SHA","d":1436268,"h":399433394796,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_AES_256_CBC_SHA","d":1436268,"h":403728362092,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_SEED_CBC_SHA","d":1436268,"h":408023329388,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_SEED_CBC_SHA","d":1436268,"h":412318296684,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_SEED_CBC_SHA","d":1436268,"h":416613263980,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_SEED_CBC_SHA","d":1436268,"h":420908231276,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_SEED_CBC_SHA","d":1436268,"h":425203198572,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_SEED_CBC_SHA","d":1436268,"h":429498165868,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_AES_128_GCM_SHA256","d":1436268,"h":433793133164,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_AES_256_GCM_SHA384","d":1436268,"h":438088100460,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_AES_128_GCM_SHA256","d":1436268,"h":442383067756,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_AES_256_GCM_SHA384","d":1436268,"h":446678035052,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_AES_128_GCM_SHA256","d":1436268,"h":450973002348,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_AES_256_GCM_SHA384","d":1436268,"h":455267969644,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_AES_128_GCM_SHA256","d":1436268,"h":459562936940,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_AES_256_GCM_SHA384","d":1436268,"h":463857904236,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_AES_128_GCM_SHA256","d":1436268,"h":468152871532,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_AES_256_GCM_SHA384","d":1436268,"h":472447838828,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_AES_128_GCM_SHA256","d":1436268,"h":476742806124,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_AES_256_GCM_SHA384","d":1436268,"h":481037773420,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_AES_128_GCM_SHA256","d":1436268,"h":485332740716,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_AES_256_GCM_SHA384","d":1436268,"h":489627708012,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_AES_128_GCM_SHA256","d":1436268,"h":493922675308,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_AES_256_GCM_SHA384","d":1436268,"h":498217642604,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_AES_128_GCM_SHA256","d":1436268,"h":502512609900,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_AES_256_GCM_SHA384","d":1436268,"h":506807577196,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_AES_128_CBC_SHA256","d":1436268,"h":511102544492,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_AES_256_CBC_SHA384","d":1436268,"h":515397511788,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_NULL_SHA256","d":1436268,"h":519692479084,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_NULL_SHA384","d":1436268,"h":523987446380,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_AES_128_CBC_SHA256","d":1436268,"h":528282413676,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_AES_256_CBC_SHA384","d":1436268,"h":532577380972,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_NULL_SHA256","d":1436268,"h":536872348268,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_NULL_SHA384","d":1436268,"h":541167315564,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_AES_128_CBC_SHA256","d":1436268,"h":545462282860,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_AES_256_CBC_SHA384","d":1436268,"h":549757250156,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_NULL_SHA256","d":1436268,"h":554052217452,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_NULL_SHA384","d":1436268,"h":558347184748,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1436268,"h":562642152044,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256","d":1436268,"h":566937119340,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1436268,"h":571232086636,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256","d":1436268,"h":575527053932,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1436268,"h":579822021228,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256","d":1436268,"h":584116988524,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1436268,"h":588411955820,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256","d":1436268,"h":592706923116,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1436268,"h":597001890412,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256","d":1436268,"h":601296857708,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1436268,"h":605591825004,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256","d":1436268,"h":609886792300,"f":4194337},{"t":1436268,"n":"TLS_AES_128_GCM_SHA256","d":1436268,"h":614181759596,"f":4194337},{"t":1436268,"n":"TLS_AES_256_GCM_SHA384","d":1436268,"h":618476726892,"f":4194337},{"t":1436268,"n":"TLS_CHACHA20_POLY1305_SHA256","d":1436268,"h":622771694188,"f":4194337},{"t":1436268,"n":"TLS_AES_128_CCM_SHA256","d":1436268,"h":627066661484,"f":4194337},{"t":1436268,"n":"TLS_AES_128_CCM_8_SHA256","d":1436268,"h":631361628780,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_NULL_SHA","d":1436268,"h":635656596076,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_RC4_128_SHA","d":1436268,"h":639951563372,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":644246530668,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA","d":1436268,"h":648541497964,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA","d":1436268,"h":652836465260,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_NULL_SHA","d":1436268,"h":657131432556,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_RC4_128_SHA","d":1436268,"h":661426399852,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":665721367148,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA","d":1436268,"h":670016334444,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA","d":1436268,"h":674311301740,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_NULL_SHA","d":1436268,"h":678606269036,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_RC4_128_SHA","d":1436268,"h":682901236332,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":687196203628,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_AES_128_CBC_SHA","d":1436268,"h":691491170924,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_AES_256_CBC_SHA","d":1436268,"h":695786138220,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_NULL_SHA","d":1436268,"h":700081105516,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_RC4_128_SHA","d":1436268,"h":704376072812,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":708671040108,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA","d":1436268,"h":712966007404,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA","d":1436268,"h":717260974700,"f":4194337},{"t":1436268,"n":"TLS_ECDH_anon_WITH_NULL_SHA","d":1436268,"h":721555941996,"f":4194337},{"t":1436268,"n":"TLS_ECDH_anon_WITH_RC4_128_SHA","d":1436268,"h":725850909292,"f":4194337},{"t":1436268,"n":"TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":730145876588,"f":4194337},{"t":1436268,"n":"TLS_ECDH_anon_WITH_AES_128_CBC_SHA","d":1436268,"h":734440843884,"f":4194337},{"t":1436268,"n":"TLS_ECDH_anon_WITH_AES_256_CBC_SHA","d":1436268,"h":738735811180,"f":4194337},{"t":1436268,"n":"TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":743030778476,"f":4194337},{"t":1436268,"n":"TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":747325745772,"f":4194337},{"t":1436268,"n":"TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":751620713068,"f":4194337},{"t":1436268,"n":"TLS_SRP_SHA_WITH_AES_128_CBC_SHA","d":1436268,"h":755915680364,"f":4194337},{"t":1436268,"n":"TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA","d":1436268,"h":760210647660,"f":4194337},{"t":1436268,"n":"TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA","d":1436268,"h":764505614956,"f":4194337},{"t":1436268,"n":"TLS_SRP_SHA_WITH_AES_256_CBC_SHA","d":1436268,"h":768800582252,"f":4194337},{"t":1436268,"n":"TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA","d":1436268,"h":773095549548,"f":4194337},{"t":1436268,"n":"TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA","d":1436268,"h":777390516844,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256","d":1436268,"h":781685484140,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384","d":1436268,"h":785980451436,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256","d":1436268,"h":790275418732,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384","d":1436268,"h":794570386028,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256","d":1436268,"h":798865353324,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384","d":1436268,"h":803160320620,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256","d":1436268,"h":807455287916,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384","d":1436268,"h":811750255212,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256","d":1436268,"h":816045222508,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384","d":1436268,"h":820340189804,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256","d":1436268,"h":824635157100,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384","d":1436268,"h":828930124396,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256","d":1436268,"h":833225091692,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384","d":1436268,"h":837520058988,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256","d":1436268,"h":841815026284,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384","d":1436268,"h":846109993580,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_RC4_128_SHA","d":1436268,"h":850404960876,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA","d":1436268,"h":854699928172,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA","d":1436268,"h":858994895468,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA","d":1436268,"h":863289862764,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256","d":1436268,"h":867584830060,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384","d":1436268,"h":871879797356,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA","d":1436268,"h":876174764652,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA256","d":1436268,"h":880469731948,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA384","d":1436268,"h":884764699244,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_ARIA_128_CBC_SHA256","d":1436268,"h":889059666540,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_ARIA_256_CBC_SHA384","d":1436268,"h":893354633836,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256","d":1436268,"h":897649601132,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384","d":1436268,"h":901944568428,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256","d":1436268,"h":906239535724,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384","d":1436268,"h":910534503020,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256","d":1436268,"h":914829470316,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384","d":1436268,"h":919124437612,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256","d":1436268,"h":923419404908,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384","d":1436268,"h":927714372204,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_ARIA_128_CBC_SHA256","d":1436268,"h":932009339500,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_ARIA_256_CBC_SHA384","d":1436268,"h":936304306796,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256","d":1436268,"h":940599274092,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384","d":1436268,"h":944894241388,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256","d":1436268,"h":949189208684,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384","d":1436268,"h":953484175980,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256","d":1436268,"h":957779143276,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384","d":1436268,"h":962074110572,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256","d":1436268,"h":966369077868,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384","d":1436268,"h":970664045164,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_ARIA_128_GCM_SHA256","d":1436268,"h":974959012460,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_ARIA_256_GCM_SHA384","d":1436268,"h":979253979756,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256","d":1436268,"h":983548947052,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384","d":1436268,"h":987843914348,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256","d":1436268,"h":992138881644,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384","d":1436268,"h":996433848940,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256","d":1436268,"h":1000728816236,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384","d":1436268,"h":1005023783532,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256","d":1436268,"h":1009318750828,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384","d":1436268,"h":1013613718124,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_ARIA_128_GCM_SHA256","d":1436268,"h":1017908685420,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_ARIA_256_GCM_SHA384","d":1436268,"h":1022203652716,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256","d":1436268,"h":1026498620012,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384","d":1436268,"h":1030793587308,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256","d":1436268,"h":1035088554604,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384","d":1436268,"h":1039383521900,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256","d":1436268,"h":1043678489196,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384","d":1436268,"h":1047973456492,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256","d":1436268,"h":1052268423788,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384","d":1436268,"h":1056563391084,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_ARIA_128_CBC_SHA256","d":1436268,"h":1060858358380,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_ARIA_256_CBC_SHA384","d":1436268,"h":1065153325676,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256","d":1436268,"h":1069448292972,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384","d":1436268,"h":1073743260268,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256","d":1436268,"h":1078038227564,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384","d":1436268,"h":1082333194860,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_ARIA_128_GCM_SHA256","d":1436268,"h":1086628162156,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_ARIA_256_GCM_SHA384","d":1436268,"h":1090923129452,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256","d":1436268,"h":1095218096748,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384","d":1436268,"h":1099513064044,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256","d":1436268,"h":1103808031340,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384","d":1436268,"h":1108102998636,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256","d":1436268,"h":1112397965932,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384","d":1436268,"h":1116692933228,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256","d":1436268,"h":1120987900524,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384","d":1436268,"h":1125282867820,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256","d":1436268,"h":1129577835116,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384","d":1436268,"h":1133872802412,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1436268,"h":1138167769708,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384","d":1436268,"h":1142462737004,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1436268,"h":1146757704300,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384","d":1436268,"h":1151052671596,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1436268,"h":1155347638892,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1436268,"h":1159642606188,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1436268,"h":1163937573484,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1436268,"h":1168232540780,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1436268,"h":1172527508076,"f":4194337},{"t":1436268,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1436268,"h":1176822475372,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256","d":1436268,"h":1181117442668,"f":4194337},{"t":1436268,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384","d":1436268,"h":1185412409964,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256","d":1436268,"h":1189707377260,"f":4194337},{"t":1436268,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384","d":1436268,"h":1194002344556,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256","d":1436268,"h":1198297311852,"f":4194337},{"t":1436268,"n":"TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384","d":1436268,"h":1202592279148,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256","d":1436268,"h":1206887246444,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384","d":1436268,"h":1211182213740,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256","d":1436268,"h":1215477181036,"f":4194337},{"t":1436268,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384","d":1436268,"h":1219772148332,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1436268,"h":1224067115628,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1436268,"h":1228362082924,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1436268,"h":1232657050220,"f":4194337},{"t":1436268,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1436268,"h":1236952017516,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1436268,"h":1241246984812,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1436268,"h":1245541952108,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1436268,"h":1249836919404,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1436268,"h":1254131886700,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1436268,"h":1258426853996,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1436268,"h":1262721821292,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1436268,"h":1267016788588,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1436268,"h":1271311755884,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1436268,"h":1275606723180,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1436268,"h":1279901690476,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1436268,"h":1284196657772,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1436268,"h":1288491625068,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1436268,"h":1292786592364,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1436268,"h":1297081559660,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_AES_128_CCM","d":1436268,"h":1301376526956,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_AES_256_CCM","d":1436268,"h":1305671494252,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_AES_128_CCM","d":1436268,"h":1309966461548,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_AES_256_CCM","d":1436268,"h":1314261428844,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_AES_128_CCM_8","d":1436268,"h":1318556396140,"f":4194337},{"t":1436268,"n":"TLS_RSA_WITH_AES_256_CCM_8","d":1436268,"h":1322851363436,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_AES_128_CCM_8","d":1436268,"h":1327146330732,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_AES_256_CCM_8","d":1436268,"h":1331441298028,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_AES_128_CCM","d":1436268,"h":1335736265324,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_AES_256_CCM","d":1436268,"h":1340031232620,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_AES_128_CCM","d":1436268,"h":1344326199916,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_AES_256_CCM","d":1436268,"h":1348621167212,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_AES_128_CCM_8","d":1436268,"h":1352916134508,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_AES_256_CCM_8","d":1436268,"h":1357211101804,"f":4194337},{"t":1436268,"n":"TLS_PSK_DHE_WITH_AES_128_CCM_8","d":1436268,"h":1361506069100,"f":4194337},{"t":1436268,"n":"TLS_PSK_DHE_WITH_AES_256_CCM_8","d":1436268,"h":1365801036396,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CCM","d":1436268,"h":1370096003692,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CCM","d":1436268,"h":1374390970988,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8","d":1436268,"h":1378685938284,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8","d":1436268,"h":1382980905580,"f":4194337},{"t":1436268,"n":"TLS_ECCPWD_WITH_AES_128_GCM_SHA256","d":1436268,"h":1387275872876,"f":4194337},{"t":1436268,"n":"TLS_ECCPWD_WITH_AES_256_GCM_SHA384","d":1436268,"h":1391570840172,"f":4194337},{"t":1436268,"n":"TLS_ECCPWD_WITH_AES_128_CCM_SHA256","d":1436268,"h":1395865807468,"f":4194337},{"t":1436268,"n":"TLS_ECCPWD_WITH_AES_256_CCM_SHA384","d":1436268,"h":1400160774764,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256","d":1436268,"h":1404455742060,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256","d":1436268,"h":1408750709356,"f":4194337},{"t":1436268,"n":"TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256","d":1436268,"h":1413045676652,"f":4194337},{"t":1436268,"n":"TLS_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1436268,"h":1417340643948,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1436268,"h":1421635611244,"f":4194337},{"t":1436268,"n":"TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1436268,"h":1425930578540,"f":4194337},{"t":1436268,"n":"TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1436268,"h":1430225545836,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256","d":1436268,"h":1434520513132,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384","d":1436268,"h":1438815480428,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256","d":1436268,"h":1443110447724,"f":4194337},{"t":1436268,"n":"TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256","d":1436268,"h":1447405415020,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1436268,"h":1451700382316,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1436268,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.TlsCipherSuite`; }
        });
        
        $asm.$str("$snsc.System.Security.Authentication.ExtendedProtection.PolicyEnforcement", ($self) => class PolicyEnforcement extends $.$$.System.Enum
        {
            static Never = 0;
            static WhenSupported = 1;
            static Always = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Never": 0n,
                    "WhenSupported": 1n,
                    "Always": 2n
                };
            }
            static $h = 1632876;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1632876,"n":"Never","d":1632876,"h":4296600172,"f":4194337},{"t":1632876,"n":"WhenSupported","d":1632876,"h":8591567468,"f":4194337},{"t":1632876,"n":"Always","d":1632876,"h":12886534764,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1632876,"h":17181502060,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1632876}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.PolicyEnforcement`; }
        });
        
        $asm.$str("$snsc.System.Security.Authentication.ExtendedProtection.ProtectionScenario", ($self) => class ProtectionScenario extends $.$$.System.Enum
        {
            static TransportSelected = 0;
            static TrustedProxy = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TransportSelected": 0n,
                    "TrustedProxy": 1n
                };
            }
            static $h = 1698412;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1698412,"n":"TransportSelected","d":1698412,"h":4296665708,"f":4194337},{"t":1698412,"n":"TrustedProxy","d":1698412,"h":8591633004,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1698412,"h":12886600300,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1698412}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ProtectionScenario`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateStream", ($self) => class NegotiateStream extends $.$snsc.System.Net.Security.AuthenticatedStream
        {
            $ctor$5(/*System.IO.Stream*/ innerStream)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get RemoteIdentity()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsClient()
            {
            }
            /*void */ AuthenticateAsClient$4(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName)
            {
            }
            /*void */ AuthenticateAsClient$3(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsClient$2(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName)
            {
            }
            /*void */ AuthenticateAsClient$1(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$4(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$3(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$2(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$1(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsServer()
            {
            }
            /*void */ AuthenticateAsServer$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsServer$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsServer$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient(/*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$3(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$4(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$1(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$2(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer(/*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndAuthenticateAsClient(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndAuthenticateAsServer(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 649836;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":125548,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180519020,"f":50364417},"n":"CanRead","d":649836,"h":12885551724,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":25770453612,"f":50364417},"n":"CanSeek","d":649836,"h":21475486316,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":34360388204,"f":50364417},"n":"CanTimeout","d":649836,"h":30065420908,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":42950322796,"f":50364417},"n":"CanWrite","d":649836,"h":38655355500,"f":2129921},{"p":117112833,"g":{"r":0,"d":0,"h":51540257388,"f":50331777},"n":"ImpersonationLevel","d":649836,"h":47245290092,"f":2097281},{"p":262145,"g":{"r":0,"d":0,"h":60130191980,"f":50364417},"n":"IsAuthenticated","d":649836,"h":55835224684,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":68720126572,"f":50364417},"n":"IsEncrypted","d":649836,"h":64425159276,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":77310061164,"f":50364417},"n":"IsMutuallyAuthenticated","d":649836,"h":73015093868,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":85899995756,"f":50364417},"n":"IsServer","d":649836,"h":81605028460,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":94489930348,"f":50364417},"n":"IsSigned","d":649836,"h":90194963052,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":103079864940,"f":50364417},"n":"Length","d":649836,"h":98784897644,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":111669799532,"f":50364417},"s":{"r":0,"d":0,"h":115964766828,"f":83918849},"n":"Position","d":649836,"h":107374832236,"f":2129921},{"p":655361,"g":{"r":0,"d":0,"h":124554701420,"f":50364417},"s":{"r":0,"d":0,"h":128849668716,"f":83918849},"n":"ReadTimeout","d":649836,"h":120259734124,"f":2129921},{"p":116916225,"g":{"r":0,"d":0,"h":137439603308,"f":50331777},"n":"RemoteIdentity","d":649836,"h":133144636012,"f":2097281},{"p":655361,"g":{"r":0,"d":0,"h":146029537900,"f":50364417},"s":{"r":0,"d":0,"h":150324505196,"f":83918849},"n":"WriteTimeout","d":649836,"h":141734570604,"f":2129921}],"m":[{"r":65537,"n":"AuthenticateAsClient","d":649836,"h":154619472492,"f":16777345},{"r":65537,"p":[{"n":"credential","p":3850997},{"n":"binding","p":5423861},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClient","o":"@$4","d":649836,"h":158914439788,"f":16777345},{"r":65537,"p":[{"n":"credential","p":3850997},{"n":"binding","p":5423861},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":715372},{"n":"allowedImpersonationLevel","p":117112833}],"n":"AuthenticateAsClient","o":"@$3","d":649836,"h":163209407084,"f":16777345},{"r":65537,"p":[{"n":"credential","p":3850997},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClient","o":"@$2","d":649836,"h":167504374380,"f":16777345},{"r":65537,"p":[{"n":"credential","p":3850997},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":715372},{"n":"allowedImpersonationLevel","p":117112833}],"n":"AuthenticateAsClient","o":"@$1","d":649836,"h":171799341676,"f":16777345},{"r":133169153,"n":"AuthenticateAsClientAsync","d":649836,"h":176094308972,"f":16777345},{"r":133169153,"p":[{"n":"credential","p":3850997},{"n":"binding","p":5423861},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$4","d":649836,"h":180389276268,"f":16777345},{"r":133169153,"p":[{"n":"credential","p":3850997},{"n":"binding","p":5423861},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":715372},{"n":"allowedImpersonationLevel","p":117112833}],"n":"AuthenticateAsClientAsync","o":"@$3","d":649836,"h":184684243564,"f":16777345},{"r":133169153,"p":[{"n":"credential","p":3850997},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$2","d":649836,"h":188979210860,"f":16777345},{"r":133169153,"p":[{"n":"credential","p":3850997},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":715372},{"n":"allowedImpersonationLevel","p":117112833}],"n":"AuthenticateAsClientAsync","o":"@$1","d":649836,"h":193274178156,"f":16777345},{"r":65537,"n":"AuthenticateAsServer","d":649836,"h":197569145452,"f":16777345},{"r":65537,"p":[{"n":"credential","p":3850997},{"n":"requiredProtectionLevel","p":715372},{"n":"requiredImpersonationLevel","p":117112833}],"n":"AuthenticateAsServer","o":"@$1","d":649836,"h":201864112748,"f":16777345},{"r":65537,"p":[{"n":"credential","p":3850997},{"n":"policy","p":1567340},{"n":"requiredProtectionLevel","p":715372},{"n":"requiredImpersonationLevel","p":117112833}],"n":"AuthenticateAsServer","o":"@$2","d":649836,"h":206159080044,"f":16777345},{"r":65537,"p":[{"n":"policy","p":1567340}],"n":"AuthenticateAsServer","o":"@$3","d":649836,"h":210454047340,"f":16777345},{"r":133169153,"n":"AuthenticateAsServerAsync","d":649836,"h":214749014636,"f":16777345},{"r":133169153,"p":[{"n":"credential","p":3850997},{"n":"requiredProtectionLevel","p":715372},{"n":"requiredImpersonationLevel","p":117112833}],"n":"AuthenticateAsServerAsync","o":"@$1","d":649836,"h":219043981932,"f":16777345},{"r":133169153,"p":[{"n":"credential","p":3850997},{"n":"policy","p":1567340},{"n":"requiredProtectionLevel","p":715372},{"n":"requiredImpersonationLevel","p":117112833}],"n":"AuthenticateAsServerAsync","o":"@$2","d":649836,"h":223338949228,"f":16777345},{"r":133169153,"p":[{"n":"policy","p":1567340}],"n":"AuthenticateAsServerAsync","o":"@$3","d":649836,"h":227633916524,"f":16777345},{"r":57016321,"p":[{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","d":649836,"h":231928883820,"f":16777345},{"r":57016321,"p":[{"n":"credential","p":3850997},{"n":"binding","p":5423861},{"n":"targetName","p":1310721},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$3","d":649836,"h":236223851116,"f":16777345},{"r":57016321,"p":[{"n":"credential","p":3850997},{"n":"binding","p":5423861},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":715372},{"n":"allowedImpersonationLevel","p":117112833},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$4","d":649836,"h":240518818412,"f":16777345},{"r":57016321,"p":[{"n":"credential","p":3850997},{"n":"targetName","p":1310721},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$1","d":649836,"h":244813785708,"f":16777345},{"r":57016321,"p":[{"n":"credential","p":3850997},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":715372},{"n":"allowedImpersonationLevel","p":117112833},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$2","d":649836,"h":249108753004,"f":16777345},{"r":57016321,"p":[{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","d":649836,"h":253403720300,"f":16777345},{"r":57016321,"p":[{"n":"credential","p":3850997},{"n":"requiredProtectionLevel","p":715372},{"n":"requiredImpersonationLevel","p":117112833},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$1","d":649836,"h":257698687596,"f":16777345},{"r":57016321,"p":[{"n":"credential","p":3850997},{"n":"policy","p":1567340},{"n":"requiredProtectionLevel","p":715372},{"n":"requiredImpersonationLevel","p":117112833},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$2","d":649836,"h":261993654892,"f":16777345},{"r":57016321,"p":[{"n":"policy","p":1567340},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$3","d":649836,"h":266288622188,"f":16777345},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginRead","d":649836,"h":270583589484,"f":16809985},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":649836,"h":274878556780,"f":16809985},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":649836,"h":279173524076,"f":16809988},{"r":135987201,"n":"DisposeAsync","d":649836,"h":283468491372,"f":16809985},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAuthenticateAsClient","d":649836,"h":287763458668,"f":16777345},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAuthenticateAsServer","d":649836,"h":292058425964,"f":16777345},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":649836,"h":296353393260,"f":16809985},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":649836,"h":300648360556,"f":16809985},{"r":65537,"n":"Flush","d":649836,"h":304943327852,"f":16809985},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121}],"n":"FlushAsync","o":"@$1","d":649836,"h":309238295148,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":649836,"h":313533262444,"f":16809985},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ReadAsync","d":649836,"h":317828229740,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAsync","o":"@$2","d":649836,"h":322123197036,"f":16809985},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":649836,"h":326418164332,"f":16809985},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":649836,"h":330713131628,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":649836,"h":335008098924,"f":16809985},{"r":133169153,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"WriteAsync","d":649836,"h":339303066220,"f":16809985},{"r":135987201,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"WriteAsync","o":"@$2","d":649836,"h":343598033516,"f":16809985}],"c":[{"p":[{"n":"innerStream","p":62193665}],"n":".ctor","o":"$ctor$5","d":649836,"h":4295617132,"f":16777217},{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$4","d":649836,"h":8590584428,"f":16777217}],"i":[57540609,56950785],"h":649836}; }
            static get $b() { return $.$snsc.System.Net.Security.AuthenticatedStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.NegotiateStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslStream", ($self) => class SslStream extends $.$snsc.System.Net.Security.AuthenticatedStream
        {
            $ctor$8(/*System.IO.Stream*/ innerStream)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$7(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback, /*System.Net.Security.LocalCertificateSelectionCallback?*/ userCertificateSelectionCallback)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback, /*System.Net.Security.LocalCertificateSelectionCallback?*/ userCertificateSelectionCallback, /*System.Net.Security.EncryptionPolicy*/ encryptionPolicy)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CheckCertRevocationStatus()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.CipherAlgorithmType */ get CipherAlgorithm()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get CipherStrength()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.HashAlgorithmType */ get HashAlgorithm()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get HashStrength()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExchangeAlgorithmType */ get KeyExchangeAlgorithm()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get KeyExchangeStrength()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get LocalCertificate()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslApplicationProtocol */ get NegotiatedApplicationProtocol()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.TlsCipherSuite */ get NegotiatedCipherSuite()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get RemoteCertificate()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocol()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get TargetHostName()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.TransportContext */ get TransportContext()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsClient$3(/*System.Net.Security.SslClientAuthenticationOptions*/ sslClientAuthenticationOptions)
            {
            }
            /*void */ AuthenticateAsClient$2(/*string*/ targetHost)
            {
            }
            /*void */ AuthenticateAsClient(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation)
            {
            }
            /*void */ AuthenticateAsClient$1(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$3(/*System.Net.Security.SslClientAuthenticationOptions*/ sslClientAuthenticationOptions, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$2(/*string*/ targetHost)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$1(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsServer(/*System.Net.Security.SslServerAuthenticationOptions*/ sslServerAuthenticationOptions)
            {
            }
            /*void */ AuthenticateAsServer$3(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate)
            {
            }
            /*void */ AuthenticateAsServer$1(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation)
            {
            }
            /*void */ AuthenticateAsServer$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync(/*System.Net.Security.ServerOptionsSelectionCallback*/ optionsCallback, /*object?*/ state, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$1(/*System.Net.Security.SslServerAuthenticationOptions*/ sslServerAuthenticationOptions, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$4(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$3(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient(/*string*/ targetHost, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$1(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$1(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndAuthenticateAsClient(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndAuthenticateAsServer(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ NegotiateClientCertificateAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*System.Threading.Tasks.Task */ ShutdownAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Write$2(/*byte[]*/ buffer)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 1305196;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":125548,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30066076268,"f":50364417},"n":"CanRead","d":1305196,"h":25771108972,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":38656010860,"f":50364417},"n":"CanSeek","d":1305196,"h":34361043564,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":47245945452,"f":50364417},"n":"CanTimeout","d":1305196,"h":42950978156,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":55835880044,"f":50364417},"n":"CanWrite","d":1305196,"h":51540912748,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":64425814636,"f":50331777},"n":"CheckCertRevocationStatus","d":1305196,"h":60130847340,"f":2097281},{"p":5292789,"g":{"r":0,"d":0,"h":73015749228,"f":50331777},"n":"CipherAlgorithm","d":1305196,"h":68720781932,"f":2097281,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":81605683820,"f":50331777},"n":"CipherStrength","d":1305196,"h":77310716524,"f":2097281,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":5554933,"g":{"r":0,"d":0,"h":90195618412,"f":50331777},"n":"HashAlgorithm","d":1305196,"h":85900651116,"f":2097281,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":98785553004,"f":50331777},"n":"HashStrength","d":1305196,"h":94490585708,"f":2097281,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":107375487596,"f":50364417},"n":"IsAuthenticated","d":1305196,"h":103080520300,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":115965422188,"f":50364417},"n":"IsEncrypted","d":1305196,"h":111670454892,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":124555356780,"f":50364417},"n":"IsMutuallyAuthenticated","d":1305196,"h":120260389484,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":133145291372,"f":50364417},"n":"IsServer","d":1305196,"h":128850324076,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":141735225964,"f":50364417},"n":"IsSigned","d":1305196,"h":137440258668,"f":2129921},{"p":5358325,"g":{"r":0,"d":0,"h":150325160556,"f":50331777},"n":"KeyExchangeAlgorithm","d":1305196,"h":146030193260,"f":2097281,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":158915095148,"f":50331777},"n":"KeyExchangeStrength","d":1305196,"h":154620127852,"f":2097281,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":167505029740,"f":50364417},"n":"Length","d":1305196,"h":163210062444,"f":2129921},{"p":28160783,"g":{"r":0,"d":0,"h":176094964332,"f":50331777},"n":"LocalCertificate","d":1305196,"h":171799997036,"f":2097281},{"p":977516,"g":{"r":0,"d":0,"h":184684898924,"f":50331649},"n":"NegotiatedApplicationProtocol","d":1305196,"h":180389931628,"f":2097153},{"p":1436268,"g":{"r":0,"d":0,"h":193274833516,"f":50331777},"n":"NegotiatedCipherSuite","d":1305196,"h":188979866220,"f":2097281,"a":[{"t":23527425,"c":8613462017,"a":[{"v":false,"t":262145}]}]},{"p":917505,"g":{"r":0,"d":0,"h":201864768108,"f":50364417},"s":{"r":0,"d":0,"h":206159735404,"f":83918849},"n":"Position","d":1305196,"h":197569800812,"f":2129921},{"p":655361,"g":{"r":0,"d":0,"h":214749669996,"f":50364417},"s":{"r":0,"d":0,"h":219044637292,"f":83918849},"n":"ReadTimeout","d":1305196,"h":210454702700,"f":2129921},{"p":28160783,"g":{"r":0,"d":0,"h":227634571884,"f":50331777},"n":"RemoteCertificate","d":1305196,"h":223339604588,"f":2097281},{"p":5620469,"g":{"r":0,"d":0,"h":236224506476,"f":50331777},"n":"SslProtocol","d":1305196,"h":231929539180,"f":2097281},{"p":1310721,"g":{"r":0,"d":0,"h":244814441068,"f":50331649},"n":"TargetHostName","d":1305196,"h":240519473772,"f":2097153},{"p":5030645,"g":{"r":0,"d":0,"h":253404375660,"f":50331649},"n":"TransportContext","d":1305196,"h":249109408364,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":261994310252,"f":50364417},"s":{"r":0,"d":0,"h":266289277548,"f":83918849},"n":"WriteTimeout","d":1305196,"h":257699342956,"f":2129921}],"m":[{"r":65537,"p":[{"n":"sslClientAuthenticationOptions","p":1108588}],"n":"AuthenticateAsClient","o":"@$3","d":1305196,"h":270584244844,"f":16777217},{"r":65537,"p":[{"n":"targetHost","p":1310721}],"n":"AuthenticateAsClient","o":"@$2","d":1305196,"h":274879212140,"f":16777345},{"r":65537,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28422927},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClient","d":1305196,"h":279174179436,"f":16777345},{"r":65537,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28422927},{"n":"enabledSslProtocols","p":5620469},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClient","o":"@$1","d":1305196,"h":283469146732,"f":16777345},{"r":133169153,"p":[{"n":"sslClientAuthenticationOptions","p":1108588},{"n":"cancellationToken","p":125829121,"f":65}],"n":"AuthenticateAsClientAsync","o":"@$3","d":1305196,"h":287764114028,"f":16777217},{"r":133169153,"p":[{"n":"targetHost","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$2","d":1305196,"h":292059081324,"f":16777345},{"r":133169153,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28422927},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClientAsync","d":1305196,"h":296354048620,"f":16777345},{"r":133169153,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28422927},{"n":"enabledSslProtocols","p":5620469},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClientAsync","o":"@$1","d":1305196,"h":300649015916,"f":16777345},{"r":65537,"p":[{"n":"sslServerAuthenticationOptions","p":1239660}],"n":"AuthenticateAsServer","d":1305196,"h":304943983212,"f":16777217},{"r":65537,"p":[{"n":"serverCertificate","p":28160783}],"n":"AuthenticateAsServer","o":"@$3","d":1305196,"h":309238950508,"f":16777345},{"r":65537,"p":[{"n":"serverCertificate","p":28160783},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServer","o":"@$1","d":1305196,"h":313533917804,"f":16777345},{"r":65537,"p":[{"n":"serverCertificate","p":28160783},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5620469},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServer","o":"@$2","d":1305196,"h":317828885100,"f":16777345},{"r":133169153,"p":[{"n":"optionsCallback","p":911980},{"n":"state","p":131073},{"n":"cancellationToken","p":125829121,"f":65}],"n":"AuthenticateAsServerAsync","d":1305196,"h":322123852396,"f":16777217},{"r":133169153,"p":[{"n":"sslServerAuthenticationOptions","p":1239660},{"n":"cancellationToken","p":125829121,"f":65}],"n":"AuthenticateAsServerAsync","o":"@$1","d":1305196,"h":326418819692,"f":16777217},{"r":133169153,"p":[{"n":"serverCertificate","p":28160783}],"n":"AuthenticateAsServerAsync","o":"@$4","d":1305196,"h":330713786988,"f":16777345},{"r":133169153,"p":[{"n":"serverCertificate","p":28160783},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServerAsync","o":"@$2","d":1305196,"h":335008754284,"f":16777345},{"r":133169153,"p":[{"n":"serverCertificate","p":28160783},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5620469},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServerAsync","o":"@$3","d":1305196,"h":339303721580,"f":16777345},{"r":57016321,"p":[{"n":"targetHost","p":1310721},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","d":1305196,"h":343598688876,"f":16777345},{"r":57016321,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28422927},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$1","d":1305196,"h":347893656172,"f":16777345},{"r":57016321,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28422927},{"n":"enabledSslProtocols","p":5620469},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$2","d":1305196,"h":352188623468,"f":16777345},{"r":57016321,"p":[{"n":"serverCertificate","p":28160783},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","d":1305196,"h":356483590764,"f":16777345},{"r":57016321,"p":[{"n":"serverCertificate","p":28160783},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$1","d":1305196,"h":360778558060,"f":16777345},{"r":57016321,"p":[{"n":"serverCertificate","p":28160783},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5620469},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$2","d":1305196,"h":365073525356,"f":16777345},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginRead","d":1305196,"h":369368492652,"f":16809985},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14548993},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":1305196,"h":373663459948,"f":16809985},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1305196,"h":377958427244,"f":16809988},{"r":135987201,"n":"DisposeAsync","d":1305196,"h":382253394540,"f":16809985},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAuthenticateAsClient","d":1305196,"h":386548361836,"f":16777345},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAuthenticateAsServer","d":1305196,"h":390843329132,"f":16777345},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":1305196,"h":395138296428,"f":16809985},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":1305196,"h":399433263724,"f":16809985},{"r":65537,"n":"Flush","d":1305196,"h":408023198316,"f":16809985},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121}],"n":"FlushAsync","o":"@$1","d":1305196,"h":412318165612,"f":16809985},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121,"f":65}],"n":"NegotiateClientCertificateAsync","d":1305196,"h":416613132908,"f":16777345,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"freebsd","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"linux","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1305196,"h":420908100204,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"Read","o":"@$1","d":1305196,"h":425203067500,"f":16809985},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ReadAsync","d":1305196,"h":429498034796,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAsync","o":"@$2","d":1305196,"h":433793002092,"f":16809985},{"r":655361,"n":"ReadByte","d":1305196,"h":438087969388,"f":16809985},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":1305196,"h":442382936684,"f":16809985},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1305196,"h":446677903980,"f":16809985},{"r":133169153,"n":"ShutdownAsync","d":1305196,"h":450972871276,"f":16777345},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h}],"n":"Write","o":"@$2","d":1305196,"h":455267838572,"f":16777217},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1305196,"h":459562805868,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"Write","o":"@$1","d":1305196,"h":463857773164,"f":16809985},{"r":133169153,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"WriteAsync","d":1305196,"h":468152740460,"f":16809985},{"r":135987201,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"WriteAsync","o":"@$2","d":1305196,"h":472447707756,"f":16809985},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":1305196,"h":476742675052,"f":16809985}],"c":[{"p":[{"n":"innerStream","p":62193665}],"n":".ctor","o":"$ctor$8","d":1305196,"h":4296272492,"f":16777217},{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$7","d":1305196,"h":8591239788,"f":16777217},{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":780908}],"n":".ctor","o":"$ctor$6","d":1305196,"h":12886207084,"f":16777217},{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":780908},{"n":"userCertificateSelectionCallback","p":322156}],"n":".ctor","o":"$ctor$5","d":1305196,"h":17181174380,"f":16777217},{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":780908},{"n":"userCertificateSelectionCallback","p":322156},{"n":"encryptionPolicy","p":256620}],"n":".ctor","o":"$ctor$4","d":1305196,"h":21476141676,"f":16777217}],"i":[57540609,56950785],"h":1305196}; }
            static get $b() { return $.$snsc.System.Net.Security.AuthenticatedStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.SslStream`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.AuthenticationException", ($self) => class AuthenticationException extends $.$$.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$12(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            static $h = 1501804;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119537665,"h":1501804}; }
            static get $b() { return $.$$.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.AuthenticationException`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.InvalidCredentialException", ($self) => class InvalidCredentialException extends $.$snsc.System.Security.Authentication.AuthenticationException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$14(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$16(/*string?*/ message)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            static $h = 1829484;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1501804,"h":1829484}; }
            static get $b() { return $.$snsc.System.Security.Authentication.AuthenticationException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.InvalidCredentialException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography"))