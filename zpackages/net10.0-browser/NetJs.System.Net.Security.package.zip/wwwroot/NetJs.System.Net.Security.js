
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Security", 
    {"h":36670,"f":"System.Net.Security","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B99807a3edea449997cda60d38046fed69821a2f6","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Security","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Security","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snsc.System.Net.Security.AuthenticatedStream", ($self) => class AuthenticatedStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.IO.Stream */ get InnerStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get LeaveInnerStreamOpen()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 102206;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":62193665,"g":{"r":0,"d":0,"h":12885004094,"f":4},"n":"InnerStream","d":102206,"h":8590036798,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":21474938686,"f":257},"n":"IsAuthenticated","d":102206,"h":17179971390,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":30064873278,"f":257},"n":"IsEncrypted","d":102206,"h":25769905982,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":38654807870,"f":257},"n":"IsMutuallyAuthenticated","d":102206,"h":34359840574,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":47244742462,"f":257},"n":"IsServer","d":102206,"h":42949775166,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":55834677054,"f":257},"n":"IsSigned","d":102206,"h":51539709758,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":64424611646,"f":1},"n":"LeaveInnerStreamOpen","d":102206,"h":60129644350,"f":1}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":102206,"h":68719578942,"f":32772},{"r":136118273,"n":"DisposeAsync","d":102206,"h":73014546238,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":102206,"h":4295069502,"f":4}],"i":[57540609,56950785],"h":102206}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.AuthenticatedStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.CipherSuitesPolicy", ($self) => class CipherSuitesPolicy extends $.$spc.System.Object
        {
            $ctor$1(/*System.Collections.Generic.IEnumerable<System.Net.Security.TlsCipherSuite>*/ allowedCipherSuites)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.Generic.IEnumerable<System.Net.Security.TlsCipherSuite> */ get AllowedCipherSuites()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 167742;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$snsc.System.Net.Security.TlsCipherSuite).$h,"g":{"r":0,"d":0,"h":12885069630,"f":1},"n":"AllowedCipherSuites","d":167742,"h":8590102334,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]}],"c":[{"p":[{"n":"allowedCipherSuites","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$snsc.System.Net.Security.TlsCipherSuite).$h}],"n":".ctor","o":"$ctor$1","d":167742,"h":4295135038,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]}],"h":167742,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"windows","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.CipherSuitesPolicy`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthenticationClientOptions", ($self) => class NegotiateAuthenticationClientOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get AllowedImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set AllowedImpersonationLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get Binding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ set Binding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ get Credential()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ set Credential(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Package(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get RequiredProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ set RequiredProtectionLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RequireMutualAuthentication()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RequireMutualAuthentication(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TargetName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 429886;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":117243905,"g":{"r":0,"d":0,"h":12885331774,"f":1},"s":{"r":0,"d":0,"h":17180299070,"f":1},"n":"AllowedImpersonationLevel","d":429886,"h":8590364478,"f":1},{"p":5430086,"g":{"r":0,"d":0,"h":25770233662,"f":1},"s":{"r":0,"d":0,"h":30065200958,"f":1},"n":"Binding","d":429886,"h":21475266366,"f":1},{"p":3857222,"g":{"r":0,"d":0,"h":38655135550,"f":1},"s":{"r":0,"d":0,"h":42950102846,"f":1},"n":"Credential","d":429886,"h":34360168254,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540037438,"f":1},"s":{"r":0,"d":0,"h":55835004734,"f":1},"n":"Package","d":429886,"h":47245070142,"f":1},{"p":692030,"g":{"r":0,"d":0,"h":64424939326,"f":1},"s":{"r":0,"d":0,"h":68719906622,"f":1},"n":"RequiredProtectionLevel","d":429886,"h":60129972030,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77309841214,"f":1},"s":{"r":0,"d":0,"h":81604808510,"f":1},"n":"RequireMutualAuthentication","d":429886,"h":73014873918,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90194743102,"f":1},"s":{"r":0,"d":0,"h":94489710398,"f":1},"n":"TargetName","d":429886,"h":85899775806,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":429886,"h":4295397182,"f":1}],"h":429886}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationClientOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthenticationServerOptions", ($self) => class NegotiateAuthenticationServerOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get Binding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ set Binding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ get Credential()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ set Credential(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Package(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy? */ get Policy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy? */ set Policy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get RequiredImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set RequiredImpersonationLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get RequiredProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ set RequiredProtectionLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 495422;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5430086,"g":{"r":0,"d":0,"h":12885397310,"f":1},"s":{"r":0,"d":0,"h":17180364606,"f":1},"n":"Binding","d":495422,"h":8590430014,"f":1},{"p":3857222,"g":{"r":0,"d":0,"h":25770299198,"f":1},"s":{"r":0,"d":0,"h":30065266494,"f":1},"n":"Credential","d":495422,"h":21475331902,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38655201086,"f":1},"s":{"r":0,"d":0,"h":42950168382,"f":1},"n":"Package","d":495422,"h":34360233790,"f":1},{"p":1543998,"g":{"r":0,"d":0,"h":51540102974,"f":1},"s":{"r":0,"d":0,"h":55835070270,"f":1},"n":"Policy","d":495422,"h":47245135678,"f":1},{"p":117243905,"g":{"r":0,"d":0,"h":64425004862,"f":1},"s":{"r":0,"d":0,"h":68719972158,"f":1},"n":"RequiredImpersonationLevel","d":495422,"h":60130037566,"f":1},{"p":692030,"g":{"r":0,"d":0,"h":77309906750,"f":1},"s":{"r":0,"d":0,"h":81604874046,"f":1},"n":"RequiredProtectionLevel","d":495422,"h":73014939454,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":495422,"h":4295462718,"f":1}],"h":495422}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationServerOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslCertificateTrust", ($self) => class SslCertificateTrust extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*System.Net.Security.SslCertificateTrust */ CreateForX509Collection(/*System.Security.Cryptography.X509Certificates.X509Certificate2Collection*/ trustList, /*bool*/ sendTrustInHandshake)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslCertificateTrust */ CreateForX509Store(/*System.Security.Cryptography.X509Certificates.X509Store*/ store, /*bool*/ sendTrustInHandshake)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1019710;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1019710,"p":[{"n":"trustList","p":28294907},{"n":"sendTrustInHandshake","p":262145,"f":65,"v":false}],"n":"CreateForX509Collection","d":1019710,"h":8590954302,"f":33},{"r":1019710,"p":[{"n":"store","p":30457595},{"n":"sendTrustInHandshake","p":262145,"f":65,"v":false}],"n":"CreateForX509Store","d":1019710,"h":12885921598,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1019710,"h":4295987006,"f":8}],"h":1019710}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslCertificateTrust`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslClientAuthenticationOptions", ($self) => class SslClientAuthenticationOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AllowRenegotiation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRenegotiation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPkcs1Padding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPkcs1Padding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPssPadding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPssPadding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowTlsResume()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowTlsResume(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ get ApplicationProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ set ApplicationProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ get CertificateChainPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ set CertificateChainPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ get CertificateRevocationCheckMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ set CertificateRevocationCheckMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ get CipherSuitesPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ set CipherSuitesPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ get ClientCertificateContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ set ClientCertificateContext(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection? */ get ClientCertificates()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection? */ set ClientCertificates(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get EnabledSslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ set EnabledSslProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ set EncryptionPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.LocalCertificateSelectionCallback? */ get LocalCertificateSelectionCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.LocalCertificateSelectionCallback? */ set LocalCertificateSelectionCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get RemoteCertificateValidationCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set RemoteCertificateValidationCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetHost()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TargetHost(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1085246;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885987134,"f":1},"s":{"r":0,"d":0,"h":17180954430,"f":1},"n":"AllowRenegotiation","d":1085246,"h":8591019838,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770889022,"f":1},"s":{"r":0,"d":0,"h":30065856318,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPkcs1Padding","d":1085246,"h":21475921726,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655790910,"f":1},"s":{"r":0,"d":0,"h":42950758206,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPssPadding","d":1085246,"h":34360823614,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540692798,"f":1},"s":{"r":0,"d":0,"h":55835660094,"f":1},"n":"AllowTlsResume","d":1085246,"h":47245725502,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":64425594686,"f":1},"s":{"r":0,"d":0,"h":68720561982,"f":1},"n":"ApplicationProtocols","d":1085246,"h":60130627390,"f":1},{"p":29146875,"g":{"r":0,"d":0,"h":77310496574,"f":1},"s":{"r":0,"d":0,"h":81605463870,"f":1},"n":"CertificateChainPolicy","d":1085246,"h":73015529278,"f":1},{"p":30260987,"g":{"r":0,"d":0,"h":90195398462,"f":1},"s":{"r":0,"d":0,"h":94490365758,"f":1},"n":"CertificateRevocationCheckMode","d":1085246,"h":85900431166,"f":1},{"p":167742,"g":{"r":0,"d":0,"h":103080300350,"f":1},"s":{"r":0,"d":0,"h":107375267646,"f":1},"n":"CipherSuitesPolicy","d":1085246,"h":98785333054,"f":1},{"p":1347390,"g":{"r":0,"d":0,"h":115965202238,"f":1},"s":{"r":0,"d":0,"h":120260169534,"f":1},"n":"ClientCertificateContext","d":1085246,"h":111670234942,"f":1},{"p":28425979,"g":{"r":0,"d":0,"h":128850104126,"f":1},"s":{"r":0,"d":0,"h":133145071422,"f":1},"n":"ClientCertificates","d":1085246,"h":124555136830,"f":1},{"p":5626694,"g":{"r":0,"d":0,"h":141735006014,"f":1},"s":{"r":0,"d":0,"h":146029973310,"f":1},"n":"EnabledSslProtocols","d":1085246,"h":137440038718,"f":1},{"p":233278,"g":{"r":0,"d":0,"h":154619907902,"f":1},"s":{"r":0,"d":0,"h":158914875198,"f":1},"n":"EncryptionPolicy","d":1085246,"h":150324940606,"f":1},{"p":298814,"g":{"r":0,"d":0,"h":167504809790,"f":1},"s":{"r":0,"d":0,"h":171799777086,"f":1},"n":"LocalCertificateSelectionCallback","d":1085246,"h":163209842494,"f":1},{"p":757566,"g":{"r":0,"d":0,"h":180389711678,"f":1},"s":{"r":0,"d":0,"h":184684678974,"f":1},"n":"RemoteCertificateValidationCallback","d":1085246,"h":176094744382,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":193274613566,"f":1},"s":{"r":0,"d":0,"h":197569580862,"f":1},"n":"TargetHost","d":1085246,"h":188979646270,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1085246,"h":4296052542,"f":1}],"h":1085246}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslClientAuthenticationOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslServerAuthenticationOptions", ($self) => class SslServerAuthenticationOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AllowRenegotiation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRenegotiation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPkcs1Padding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPkcs1Padding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPssPadding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPssPadding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowTlsResume()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowTlsResume(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ get ApplicationProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ set ApplicationProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ get CertificateChainPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ set CertificateChainPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ get CertificateRevocationCheckMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ set CertificateRevocationCheckMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ get CipherSuitesPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ set CipherSuitesPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ClientCertificateRequired()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ClientCertificateRequired(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get EnabledSslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ set EnabledSslProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ set EncryptionPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get RemoteCertificateValidationCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set RemoteCertificateValidationCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get ServerCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ set ServerCertificate(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ get ServerCertificateContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ set ServerCertificateContext(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ServerCertificateSelectionCallback? */ get ServerCertificateSelectionCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ServerCertificateSelectionCallback? */ set ServerCertificateSelectionCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1216318;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886118206,"f":1},"s":{"r":0,"d":0,"h":17181085502,"f":1},"n":"AllowRenegotiation","d":1216318,"h":8591150910,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25771020094,"f":1},"s":{"r":0,"d":0,"h":30065987390,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPkcs1Padding","d":1216318,"h":21476052798,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655921982,"f":1},"s":{"r":0,"d":0,"h":42950889278,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPssPadding","d":1216318,"h":34360954686,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540823870,"f":1},"s":{"r":0,"d":0,"h":55835791166,"f":1},"n":"AllowTlsResume","d":1216318,"h":47245856574,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":64425725758,"f":1},"s":{"r":0,"d":0,"h":68720693054,"f":1},"n":"ApplicationProtocols","d":1216318,"h":60130758462,"f":1},{"p":29146875,"g":{"r":0,"d":0,"h":77310627646,"f":1},"s":{"r":0,"d":0,"h":81605594942,"f":1},"n":"CertificateChainPolicy","d":1216318,"h":73015660350,"f":1},{"p":30260987,"g":{"r":0,"d":0,"h":90195529534,"f":1},"s":{"r":0,"d":0,"h":94490496830,"f":1},"n":"CertificateRevocationCheckMode","d":1216318,"h":85900562238,"f":1},{"p":167742,"g":{"r":0,"d":0,"h":103080431422,"f":1},"s":{"r":0,"d":0,"h":107375398718,"f":1},"n":"CipherSuitesPolicy","d":1216318,"h":98785464126,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115965333310,"f":1},"s":{"r":0,"d":0,"h":120260300606,"f":1},"n":"ClientCertificateRequired","d":1216318,"h":111670366014,"f":1},{"p":5626694,"g":{"r":0,"d":0,"h":128850235198,"f":1},"s":{"r":0,"d":0,"h":133145202494,"f":1},"n":"EnabledSslProtocols","d":1216318,"h":124555267902,"f":1},{"p":233278,"g":{"r":0,"d":0,"h":141735137086,"f":1},"s":{"r":0,"d":0,"h":146030104382,"f":1},"n":"EncryptionPolicy","d":1216318,"h":137440169790,"f":1},{"p":757566,"g":{"r":0,"d":0,"h":154620038974,"f":1},"s":{"r":0,"d":0,"h":158915006270,"f":1},"n":"RemoteCertificateValidationCallback","d":1216318,"h":150325071678,"f":1},{"p":28163835,"g":{"r":0,"d":0,"h":167504940862,"f":1},"s":{"r":0,"d":0,"h":171799908158,"f":1},"n":"ServerCertificate","d":1216318,"h":163209973566,"f":1},{"p":1347390,"g":{"r":0,"d":0,"h":180389842750,"f":1},"s":{"r":0,"d":0,"h":184684810046,"f":1},"n":"ServerCertificateContext","d":1216318,"h":176094875454,"f":1},{"p":823102,"g":{"r":0,"d":0,"h":193274744638,"f":1},"s":{"r":0,"d":0,"h":197569711934,"f":1},"n":"ServerCertificateSelectionCallback","d":1216318,"h":188979777342,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1216318,"h":4296183614,"f":1}],"h":1216318}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslServerAuthenticationOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslStreamCertificateContext", ($self) => class SslStreamCertificateContext extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.ObjectModel.ReadOnlyCollection<System.Security.Cryptography.X509Certificates.X509Certificate2> */ get IntermediateCertificates()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate2 */ get TargetCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslStreamCertificateContext */ Create(/*System.Security.Cryptography.X509Certificates.X509Certificate2*/ target, /*System.Security.Cryptography.X509Certificates.X509Certificate2Collection?*/ additionalCertificates, /*bool*/ offline)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslStreamCertificateContext */ Create$1(/*System.Security.Cryptography.X509Certificates.X509Certificate2*/ target, /*System.Security.Cryptography.X509Certificates.X509Certificate2Collection?*/ additionalCertificates, /*bool*/ offline, /*System.Net.Security.SslCertificateTrust?*/ trust)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1347390;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sscr.System.Security.Cryptography.X509Certificates.X509Certificate2).$h,"g":{"r":0,"d":0,"h":12886249278,"f":1},"n":"IntermediateCertificates","d":1347390,"h":8591281982,"f":1},{"p":28229371,"g":{"r":0,"d":0,"h":21476183870,"f":1},"n":"TargetCertificate","d":1347390,"h":17181216574,"f":1}],"m":[{"r":1347390,"p":[{"n":"target","p":28229371},{"n":"additionalCertificates","p":28294907},{"n":"offline","p":262145}],"n":"Create","d":1347390,"h":25771151166,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":1347390,"p":[{"n":"target","p":28229371},{"n":"additionalCertificates","p":28294907},{"n":"offline","p":262145,"f":65,"v":false},{"n":"trust","p":1019710,"f":65}],"n":"Create","o":"@$1","d":1347390,"h":30066118462,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1347390,"h":4296314686,"f":8}],"h":1347390}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslStreamCertificateContext`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthentication", ($self) => class NegotiateAuthentication extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.Security.NegotiateAuthenticationClientOptions*/ clientOptions)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.Security.NegotiateAuthenticationServerOptions*/ serverOptions)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get ProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get RemoteIdentity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ ComputeIntegrityCheck(/*System.ReadOnlySpan<byte>*/ message, /*System.Buffers.IBufferWriter<byte>*/ signatureWriter)
            {
            }
            /*void */ Dispose()
            {
            }
            /*byte[]? */ GetOutgoingBlob(/*System.ReadOnlySpan<byte>*/ incomingBlob, /*out System.Net.Security.NegotiateAuthenticationStatusCode*/ statusCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ GetOutgoingBlob$1(/*string?*/ incomingBlob, /*out System.Net.Security.NegotiateAuthenticationStatusCode*/ statusCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ Unwrap(/*System.ReadOnlySpan<byte>*/ input, /*System.Buffers.IBufferWriter<byte>*/ outputWriter, /*out bool*/ wasEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ UnwrapInPlace(/*System.Span<byte>*/ input, /*out int*/ unwrappedOffset, /*out int*/ unwrappedLength, /*out bool*/ wasEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ VerifyIntegrityCheck(/*System.ReadOnlySpan<byte>*/ message, /*System.ReadOnlySpan<byte>*/ signature)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ Wrap(/*System.ReadOnlySpan<byte>*/ input, /*System.Buffers.IBufferWriter<byte>*/ outputWriter, /*bool*/ requestEncryption, /*out bool*/ isEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 364350;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":117243905,"g":{"r":0,"d":0,"h":17180233534,"f":1},"n":"ImpersonationLevel","d":364350,"h":12885266238,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770168126,"f":1},"n":"IsAuthenticated","d":364350,"h":21475200830,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360102718,"f":1},"n":"IsEncrypted","d":364350,"h":30065135422,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950037310,"f":1},"n":"IsMutuallyAuthenticated","d":364350,"h":38655070014,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51539971902,"f":1},"n":"IsServer","d":364350,"h":47245004606,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60129906494,"f":1},"n":"IsSigned","d":364350,"h":55834939198,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":68719841086,"f":1},"n":"Package","d":364350,"h":64424873790,"f":1},{"p":692030,"g":{"r":0,"d":0,"h":77309775678,"f":1},"n":"ProtectionLevel","d":364350,"h":73014808382,"f":1},{"p":117047297,"g":{"r":0,"d":0,"h":85899710270,"f":1},"n":"RemoteIdentity","d":364350,"h":81604742974,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":94489644862,"f":1},"n":"TargetName","d":364350,"h":90194677566,"f":1}],"m":[{"r":65537,"p":[{"n":"message","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"signatureWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h}],"n":"ComputeIntegrityCheck","d":364350,"h":98784612158,"f":1},{"r":65537,"n":"Dispose","d":364350,"h":103079579454,"f":1},{"r":0,"p":[{"n":"incomingBlob","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"statusCode","p":560958,"f":2}],"n":"GetOutgoingBlob","d":364350,"h":107374546750,"f":1},{"r":1310721,"p":[{"n":"incomingBlob","p":1310721},{"n":"statusCode","p":560958,"f":2}],"n":"GetOutgoingBlob","o":"@$1","d":364350,"h":111669514046,"f":1},{"r":560958,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"outputWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h},{"n":"wasEncrypted","p":262145,"f":2}],"n":"Unwrap","d":364350,"h":115964481342,"f":1},{"r":560958,"p":[{"n":"input","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"unwrappedOffset","p":655361,"f":2},{"n":"unwrappedLength","p":655361,"f":2},{"n":"wasEncrypted","p":262145,"f":2}],"n":"UnwrapInPlace","d":364350,"h":120259448638,"f":1},{"r":262145,"p":[{"n":"message","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"signature","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"VerifyIntegrityCheck","d":364350,"h":124554415934,"f":1},{"r":560958,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"outputWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h},{"n":"requestEncryption","p":262145},{"n":"isEncrypted","p":262145,"f":2}],"n":"Wrap","d":364350,"h":128849383230,"f":1}],"c":[{"p":[{"n":"clientOptions","p":429886}],"n":".ctor","o":"$ctor$1","d":364350,"h":4295331646,"f":1},{"p":[{"n":"serverOptions","p":495422}],"n":".ctor","o":"$ctor$2","d":364350,"h":8590298942,"f":1}],"i":[57540609],"h":364350}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthentication`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy", ($self) => class ExtendedProtectionPolicy extends $.$spc.System.Object
        {
            $ctor$1(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ChannelBinding*/ customChannelBinding)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ProtectionScenario*/ protectionScenario, /*System.Collections.ICollection?*/ customServiceNames)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ProtectionScenario*/ protectionScenario, /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection?*/ customServiceNames)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get CustomChannelBinding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection? */ get CustomServiceNames()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsExtendedProtection()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.PolicyEnforcement */ get PolicyEnforcement()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ProtectionScenario */ get ProtectionScenario()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo?*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snsc.System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy.ToString.apply(this, arguments); }
            static $h = 1543998;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5430086,"g":{"r":0,"d":0,"h":30066315070,"f":1},"n":"CustomChannelBinding","d":1543998,"h":25771347774,"f":1},{"p":1740606,"g":{"r":0,"d":0,"h":38656249662,"f":1},"n":"CustomServiceNames","d":1543998,"h":34361282366,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47246184254,"f":33},"n":"OSSupportsExtendedProtection","d":1543998,"h":42951216958,"f":33},{"p":1609534,"g":{"r":0,"d":0,"h":55836118846,"f":1},"n":"PolicyEnforcement","d":1543998,"h":51541151550,"f":1},{"p":1675070,"g":{"r":0,"d":0,"h":64426053438,"f":1},"n":"ProtectionScenario","d":1543998,"h":60131086142,"f":1}],"m":[{"r":1310721,"n":"ToString","d":1543998,"h":73015988030,"f":32769}],"c":[{"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$1","d":1543998,"h":4296511294,"f":4,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]},{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":[{"n":"policyEnforcement","p":1609534}],"n":".ctor","o":"$ctor$2","d":1543998,"h":8591478590,"f":1},{"p":[{"n":"policyEnforcement","p":1609534},{"n":"customChannelBinding","p":5430086}],"n":".ctor","o":"$ctor$3","d":1543998,"h":12886445886,"f":1},{"p":[{"n":"policyEnforcement","p":1609534},{"n":"protectionScenario","p":1675070},{"n":"customServiceNames","p":31391745}],"n":".ctor","o":"$ctor$4","d":1543998,"h":17181413182,"f":1},{"p":[{"n":"policyEnforcement","p":1609534},{"n":"protectionScenario","p":1675070},{"n":"customServiceNames","p":1740606}],"n":".ctor","o":"$ctor$5","d":1543998,"h":21476380478,"f":1}],"i":[113377281],"h":1543998}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.SslClientHelloInfo", ($self) => class SslClientHelloInfo extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            $ctor$2(/*string*/ serverName, /*System.Security.Authentication.SslProtocols*/ sslProtocols)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*string */ get ServerName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 1150782;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475987262,"f":1},"n":"ServerName","d":1150782,"h":17181019966,"f":1},{"p":5626694,"g":{"r":0,"d":0,"h":30065921854,"f":1},"n":"SslProtocols","d":1150782,"h":25770954558,"f":1}],"l":[{"t":131073,"n":"_dummy","d":1150782,"h":4296118078,"f":2},{"t":655361,"n":"_dummyPrimitive","d":1150782,"h":8591085374,"f":2}],"c":[{"p":[{"n":"serverName","p":1310721},{"n":"sslProtocols","p":5626694}],"n":".ctor","o":"$ctor$2","d":1150782,"h":12886052670,"f":1},{"n":".ctor","o":"$ctor$3","d":1150782,"h":34360889150,"f":1}],"h":1150782}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Security.SslClientHelloInfo`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.SslApplicationProtocol", ($self) => class SslApplicationProtocol extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.Security.SslApplicationProtocol*/ static Http11;
            /*System.Net.Security.SslApplicationProtocol*/ static Http2;
            /*System.Net.Security.SslApplicationProtocol*/ static Http3;
            $ctor$2(/*byte[]*/ protocol)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            $ctor$3(/*string*/ protocol)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*System.ReadOnlyMemory<byte> */ get Protocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Security.SslApplicationProtocol*/ other)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snsc.System.Net.Security.SslApplicationProtocol.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snsc.System.Net.Security.SslApplicationProtocol.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Security.SslApplicationProtocol*/ left, /*System.Net.Security.SslApplicationProtocol*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Security.SslApplicationProtocol*/ left, /*System.Net.Security.SslApplicationProtocol*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snsc.System.Net.Security.SslApplicationProtocol.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Net.Security.SslApplicationProtocol>.Equals(System.Net.Security.SslApplicationProtocol)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Http11 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
                {
                    this.Http2 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
                {
                    this.Http3 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
            }
            static $h = 954174;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":38655659838,"f":1},"n":"Protocol","d":954174,"h":34360692542,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":954174}],"n":"Equals","o":"@$2","d":954174,"h":42950627134,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":954174,"h":47245594430,"f":32769},{"r":655361,"n":"GetHashCode","d":954174,"h":51540561726,"f":32769},{"r":1310721,"n":"ToString","d":954174,"h":64425463614,"f":32769}],"l":[{"t":131073,"n":"_dummy","d":954174,"h":4295921470,"f":2},{"t":655361,"n":"_dummyPrimitive","d":954174,"h":8590888766,"f":2},{"t":954174,"n":"Http11","d":954174,"h":12885856062,"f":33},{"t":954174,"n":"Http2","d":954174,"h":17180823358,"f":33},{"t":954174,"n":"Http3","d":954174,"h":21475790654,"f":33}],"c":[{"p":[{"n":"protocol","p":0}],"n":".ctor","o":"$ctor$2","d":954174,"h":25770757950,"f":1},{"p":[{"n":"protocol","p":1310721}],"n":".ctor","o":"$ctor$3","d":954174,"h":30065725246,"f":1},{"n":".ctor","o":"$ctor$4","d":954174,"h":68720430910,"f":1}],"i":[$.$spc.System.IEquatable$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h],"h":954174}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$snsc.System.Net.Security.SslApplicationProtocol) ]; }
            static get $fullName() { return `System.Net.Security.SslApplicationProtocol`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.ExtendedProtection.ServiceNameCollection", ($self) => class ServiceNameCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2(/*System.Collections.ICollection*/ items)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ Contains(/*string?*/ searchServiceName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection */ Merge(/*System.Collections.IEnumerable*/ serviceNames)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection */ Merge$1(/*string*/ serviceName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1740606;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"m":[{"r":262145,"p":[{"n":"searchServiceName","p":1310721}],"n":"Contains","d":1740606,"h":8591675198,"f":1},{"r":1740606,"p":[{"n":"serviceNames","p":31653889}],"n":"Merge","d":1740606,"h":12886642494,"f":1},{"r":1740606,"p":[{"n":"serviceName","p":1310721}],"n":"Merge","o":"@$1","d":1740606,"h":17181609790,"f":1}],"c":[{"p":[{"n":"items","p":31391745}],"n":".ctor","o":"$ctor$2","d":1740606,"h":4296707902,"f":1}],"i":[31391745,31653889],"h":1740606}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ServiceNameCollection`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.LocalCertificateSelectionCallback", ($self) => class LocalCertificateSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate?*/ Invoke(/*$.$spc.System.Object*/ sender, /*$.$spc.System.String*/ targetHost, /*$.$sscr.System.Security.Cryptography.X509Certificates.X509CertificateCollection*/ localCertificates, /*$.$spc.System.Nullable$$*/ remoteCertificate, /**/ acceptableIssuers)
            {
                return this.$nativeFunction.call(this.$target, sender, targetHost, localCertificates, remoteCertificate, acceptableIssuers);
            }
            static $h = 298814;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":28163835,"p":[{"n":"sender","p":131073},{"n":"targetHost","p":1310721},{"n":"localCertificates","p":28425979},{"n":"remoteCertificate","p":28163835},{"n":"acceptableIssuers","p":0}],"n":"Invoke","d":298814,"h":8590233406,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"targetHost","p":1310721},{"n":"localCertificates","p":28425979},{"n":"remoteCertificate","p":28163835},{"n":"acceptableIssuers","p":0},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":298814,"h":12885200702,"f":129},{"r":28163835,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":298814,"h":17180167998,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":298814,"h":4295266110,"f":1}],"i":[57212929,113377281],"h":298814}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.LocalCertificateSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.RemoteCertificateValidationCallback", ($self) => class RemoteCertificateValidationCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*bool*/ Invoke(/*$.$spc.System.Object*/ sender, /*$.$spc.System.Nullable$$*/ certificate, /*$.$spc.System.Nullable$$*/ chain, /*$.$snp.System.Net.Security.SslPolicyErrors*/ sslPolicyErrors)
            {
                return this.$nativeFunction.call(this.$target, sender, certificate, chain, sslPolicyErrors);
            }
            static $h = 757566;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":262145,"p":[{"n":"sender","p":131073},{"n":"certificate","p":28163835},{"n":"chain","p":28884731},{"n":"sslPolicyErrors","p":4315974}],"n":"Invoke","d":757566,"h":8590692158,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"certificate","p":28163835},{"n":"chain","p":28884731},{"n":"sslPolicyErrors","p":4315974},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":757566,"h":12885659454,"f":129},{"r":262145,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":757566,"h":17180626750,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":757566,"h":4295724862,"f":1}],"i":[57212929,113377281],"h":757566}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.RemoteCertificateValidationCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.ServerCertificateSelectionCallback", ($self) => class ServerCertificateSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate*/ Invoke(/*$.$spc.System.Object*/ sender, /*$.$spc.System.Nullable$$*/ hostName)
            {
                return this.$nativeFunction.call(this.$target, sender, hostName);
            }
            static $h = 823102;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":28163835,"p":[{"n":"sender","p":131073},{"n":"hostName","p":1310721}],"n":"Invoke","d":823102,"h":8590757694,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"hostName","p":1310721},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":823102,"h":12885724990,"f":129},{"r":28163835,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":823102,"h":17180692286,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":823102,"h":4295790398,"f":1}],"i":[57212929,113377281],"h":823102}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.ServerCertificateSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.ServerOptionsSelectionCallback", ($self) => class ServerOptionsSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Security.SslServerAuthenticationOptions>*/ Invoke(/*$.$snsc.System.Net.Security.SslStream*/ stream, /*$.$snsc.System.Net.Security.SslClientHelloInfo*/ clientHelloInfo, /*$.$spc.System.Nullable$$*/ state, /*$.$spc.System.Threading.CancellationToken*/ cancellationToken)
            {
                return this.$nativeFunction.call(this.$target, stream, clientHelloInfo, state, cancellationToken);
            }
            static $h = 888638;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snsc.System.Net.Security.SslServerAuthenticationOptions).$h,"p":[{"n":"stream","p":1281854},{"n":"clientHelloInfo","p":1150782},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193}],"n":"Invoke","d":888638,"h":8590823230,"f":129},{"r":57016321,"p":[{"n":"stream","p":1281854},{"n":"clientHelloInfo","p":1150782},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":888638,"h":12885790526,"f":129},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snsc.System.Net.Security.SslServerAuthenticationOptions).$h,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":888638,"h":17180757822,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":888638,"h":4295855934,"f":1}],"i":[57212929,113377281],"h":888638}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.ServerOptionsSelectionCallback`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.EncryptionPolicy", ($self) => class EncryptionPolicy extends $.$spc.System.Enum
        {
            static RequireEncryption = 0;
            static AllowNoEncryption = 1;
            static NoEncryption = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "RequireEncryption": 0n,
                    "AllowNoEncryption": 1n,
                    "NoEncryption": 2n
                };
            }
            static $h = 233278;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":233278,"n":"RequireEncryption","d":233278,"h":4295200574,"f":33},{"t":233278,"n":"AllowNoEncryption","d":233278,"h":8590167870,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0040","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"t":233278,"n":"NoEncryption","d":233278,"h":12885135166,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0040","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":233278,"h":17180102462,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":233278}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.EncryptionPolicy`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.NegotiateAuthenticationStatusCode", ($self) => class NegotiateAuthenticationStatusCode extends $.$spc.System.Enum
        {
            static Completed = 0;
            static ContinueNeeded = 1;
            static GenericFailure = 2;
            static BadBinding = 3;
            static Unsupported = 4;
            static MessageAltered = 5;
            static ContextExpired = 6;
            static CredentialsExpired = 7;
            static InvalidCredentials = 8;
            static InvalidToken = 9;
            static UnknownCredentials = 10;
            static QopNotSupported = 11;
            static OutOfSequence = 12;
            static SecurityQosFailed = 13;
            static TargetUnknown = 14;
            static ImpersonationValidationFailed = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Completed": 0n,
                    "ContinueNeeded": 1n,
                    "GenericFailure": 2n,
                    "BadBinding": 3n,
                    "Unsupported": 4n,
                    "MessageAltered": 5n,
                    "ContextExpired": 6n,
                    "CredentialsExpired": 7n,
                    "InvalidCredentials": 8n,
                    "InvalidToken": 9n,
                    "UnknownCredentials": 10n,
                    "QopNotSupported": 11n,
                    "OutOfSequence": 12n,
                    "SecurityQosFailed": 13n,
                    "TargetUnknown": 14n,
                    "ImpersonationValidationFailed": 15n
                };
            }
            static $h = 560958;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":560958,"n":"Completed","d":560958,"h":4295528254,"f":33},{"t":560958,"n":"ContinueNeeded","d":560958,"h":8590495550,"f":33},{"t":560958,"n":"GenericFailure","d":560958,"h":12885462846,"f":33},{"t":560958,"n":"BadBinding","d":560958,"h":17180430142,"f":33},{"t":560958,"n":"Unsupported","d":560958,"h":21475397438,"f":33},{"t":560958,"n":"MessageAltered","d":560958,"h":25770364734,"f":33},{"t":560958,"n":"ContextExpired","d":560958,"h":30065332030,"f":33},{"t":560958,"n":"CredentialsExpired","d":560958,"h":34360299326,"f":33},{"t":560958,"n":"InvalidCredentials","d":560958,"h":38655266622,"f":33},{"t":560958,"n":"InvalidToken","d":560958,"h":42950233918,"f":33},{"t":560958,"n":"UnknownCredentials","d":560958,"h":47245201214,"f":33},{"t":560958,"n":"QopNotSupported","d":560958,"h":51540168510,"f":33},{"t":560958,"n":"OutOfSequence","d":560958,"h":55835135806,"f":33},{"t":560958,"n":"SecurityQosFailed","d":560958,"h":60130103102,"f":33},{"t":560958,"n":"TargetUnknown","d":560958,"h":64425070398,"f":33},{"t":560958,"n":"ImpersonationValidationFailed","d":560958,"h":68720037694,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":560958,"h":73015004990,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":560958}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationStatusCode`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.ProtectionLevel", ($self) => class ProtectionLevel extends $.$spc.System.Enum
        {
            static None = 0;
            static Sign = 1;
            static EncryptAndSign = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Sign": 1n,
                    "EncryptAndSign": 2n
                };
            }
            static $h = 692030;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":692030,"n":"None","d":692030,"h":4295659326,"f":33},{"t":692030,"n":"Sign","d":692030,"h":8590626622,"f":33},{"t":692030,"n":"EncryptAndSign","d":692030,"h":12885593918,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":692030,"h":17180561214,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":692030}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.ProtectionLevel`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.TlsCipherSuite", ($self) => class TlsCipherSuite extends $.$spc.System.Enum
        {
            static TLS_NULL_WITH_NULL_NULL = 0;
            static TLS_RSA_WITH_NULL_MD5 = 1;
            static TLS_RSA_WITH_NULL_SHA = 2;
            static TLS_RSA_EXPORT_WITH_RC4_40_MD5 = 3;
            static TLS_RSA_WITH_RC4_128_MD5 = 4;
            static TLS_RSA_WITH_RC4_128_SHA = 5;
            static TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5 = 6;
            static TLS_RSA_WITH_IDEA_CBC_SHA = 7;
            static TLS_RSA_EXPORT_WITH_DES40_CBC_SHA = 8;
            static TLS_RSA_WITH_DES_CBC_SHA = 9;
            static TLS_RSA_WITH_3DES_EDE_CBC_SHA = 10;
            static TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA = 11;
            static TLS_DH_DSS_WITH_DES_CBC_SHA = 12;
            static TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA = 13;
            static TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA = 14;
            static TLS_DH_RSA_WITH_DES_CBC_SHA = 15;
            static TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA = 16;
            static TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA = 17;
            static TLS_DHE_DSS_WITH_DES_CBC_SHA = 18;
            static TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA = 19;
            static TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA = 20;
            static TLS_DHE_RSA_WITH_DES_CBC_SHA = 21;
            static TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA = 22;
            static TLS_DH_anon_EXPORT_WITH_RC4_40_MD5 = 23;
            static TLS_DH_anon_WITH_RC4_128_MD5 = 24;
            static TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA = 25;
            static TLS_DH_anon_WITH_DES_CBC_SHA = 26;
            static TLS_DH_anon_WITH_3DES_EDE_CBC_SHA = 27;
            static TLS_KRB5_WITH_DES_CBC_SHA = 30;
            static TLS_KRB5_WITH_3DES_EDE_CBC_SHA = 31;
            static TLS_KRB5_WITH_RC4_128_SHA = 32;
            static TLS_KRB5_WITH_IDEA_CBC_SHA = 33;
            static TLS_KRB5_WITH_DES_CBC_MD5 = 34;
            static TLS_KRB5_WITH_3DES_EDE_CBC_MD5 = 35;
            static TLS_KRB5_WITH_RC4_128_MD5 = 36;
            static TLS_KRB5_WITH_IDEA_CBC_MD5 = 37;
            static TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA = 38;
            static TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA = 39;
            static TLS_KRB5_EXPORT_WITH_RC4_40_SHA = 40;
            static TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5 = 41;
            static TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5 = 42;
            static TLS_KRB5_EXPORT_WITH_RC4_40_MD5 = 43;
            static TLS_PSK_WITH_NULL_SHA = 44;
            static TLS_DHE_PSK_WITH_NULL_SHA = 45;
            static TLS_RSA_PSK_WITH_NULL_SHA = 46;
            static TLS_RSA_WITH_AES_128_CBC_SHA = 47;
            static TLS_DH_DSS_WITH_AES_128_CBC_SHA = 48;
            static TLS_DH_RSA_WITH_AES_128_CBC_SHA = 49;
            static TLS_DHE_DSS_WITH_AES_128_CBC_SHA = 50;
            static TLS_DHE_RSA_WITH_AES_128_CBC_SHA = 51;
            static TLS_DH_anon_WITH_AES_128_CBC_SHA = 52;
            static TLS_RSA_WITH_AES_256_CBC_SHA = 53;
            static TLS_DH_DSS_WITH_AES_256_CBC_SHA = 54;
            static TLS_DH_RSA_WITH_AES_256_CBC_SHA = 55;
            static TLS_DHE_DSS_WITH_AES_256_CBC_SHA = 56;
            static TLS_DHE_RSA_WITH_AES_256_CBC_SHA = 57;
            static TLS_DH_anon_WITH_AES_256_CBC_SHA = 58;
            static TLS_RSA_WITH_NULL_SHA256 = 59;
            static TLS_RSA_WITH_AES_128_CBC_SHA256 = 60;
            static TLS_RSA_WITH_AES_256_CBC_SHA256 = 61;
            static TLS_DH_DSS_WITH_AES_128_CBC_SHA256 = 62;
            static TLS_DH_RSA_WITH_AES_128_CBC_SHA256 = 63;
            static TLS_DHE_DSS_WITH_AES_128_CBC_SHA256 = 64;
            static TLS_RSA_WITH_CAMELLIA_128_CBC_SHA = 65;
            static TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA = 66;
            static TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA = 67;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA = 68;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA = 69;
            static TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA = 70;
            static TLS_DHE_RSA_WITH_AES_128_CBC_SHA256 = 103;
            static TLS_DH_DSS_WITH_AES_256_CBC_SHA256 = 104;
            static TLS_DH_RSA_WITH_AES_256_CBC_SHA256 = 105;
            static TLS_DHE_DSS_WITH_AES_256_CBC_SHA256 = 106;
            static TLS_DHE_RSA_WITH_AES_256_CBC_SHA256 = 107;
            static TLS_DH_anon_WITH_AES_128_CBC_SHA256 = 108;
            static TLS_DH_anon_WITH_AES_256_CBC_SHA256 = 109;
            static TLS_RSA_WITH_CAMELLIA_256_CBC_SHA = 132;
            static TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA = 133;
            static TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA = 134;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA = 135;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA = 136;
            static TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA = 137;
            static TLS_PSK_WITH_RC4_128_SHA = 138;
            static TLS_PSK_WITH_3DES_EDE_CBC_SHA = 139;
            static TLS_PSK_WITH_AES_128_CBC_SHA = 140;
            static TLS_PSK_WITH_AES_256_CBC_SHA = 141;
            static TLS_DHE_PSK_WITH_RC4_128_SHA = 142;
            static TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA = 143;
            static TLS_DHE_PSK_WITH_AES_128_CBC_SHA = 144;
            static TLS_DHE_PSK_WITH_AES_256_CBC_SHA = 145;
            static TLS_RSA_PSK_WITH_RC4_128_SHA = 146;
            static TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA = 147;
            static TLS_RSA_PSK_WITH_AES_128_CBC_SHA = 148;
            static TLS_RSA_PSK_WITH_AES_256_CBC_SHA = 149;
            static TLS_RSA_WITH_SEED_CBC_SHA = 150;
            static TLS_DH_DSS_WITH_SEED_CBC_SHA = 151;
            static TLS_DH_RSA_WITH_SEED_CBC_SHA = 152;
            static TLS_DHE_DSS_WITH_SEED_CBC_SHA = 153;
            static TLS_DHE_RSA_WITH_SEED_CBC_SHA = 154;
            static TLS_DH_anon_WITH_SEED_CBC_SHA = 155;
            static TLS_RSA_WITH_AES_128_GCM_SHA256 = 156;
            static TLS_RSA_WITH_AES_256_GCM_SHA384 = 157;
            static TLS_DHE_RSA_WITH_AES_128_GCM_SHA256 = 158;
            static TLS_DHE_RSA_WITH_AES_256_GCM_SHA384 = 159;
            static TLS_DH_RSA_WITH_AES_128_GCM_SHA256 = 160;
            static TLS_DH_RSA_WITH_AES_256_GCM_SHA384 = 161;
            static TLS_DHE_DSS_WITH_AES_128_GCM_SHA256 = 162;
            static TLS_DHE_DSS_WITH_AES_256_GCM_SHA384 = 163;
            static TLS_DH_DSS_WITH_AES_128_GCM_SHA256 = 164;
            static TLS_DH_DSS_WITH_AES_256_GCM_SHA384 = 165;
            static TLS_DH_anon_WITH_AES_128_GCM_SHA256 = 166;
            static TLS_DH_anon_WITH_AES_256_GCM_SHA384 = 167;
            static TLS_PSK_WITH_AES_128_GCM_SHA256 = 168;
            static TLS_PSK_WITH_AES_256_GCM_SHA384 = 169;
            static TLS_DHE_PSK_WITH_AES_128_GCM_SHA256 = 170;
            static TLS_DHE_PSK_WITH_AES_256_GCM_SHA384 = 171;
            static TLS_RSA_PSK_WITH_AES_128_GCM_SHA256 = 172;
            static TLS_RSA_PSK_WITH_AES_256_GCM_SHA384 = 173;
            static TLS_PSK_WITH_AES_128_CBC_SHA256 = 174;
            static TLS_PSK_WITH_AES_256_CBC_SHA384 = 175;
            static TLS_PSK_WITH_NULL_SHA256 = 176;
            static TLS_PSK_WITH_NULL_SHA384 = 177;
            static TLS_DHE_PSK_WITH_AES_128_CBC_SHA256 = 178;
            static TLS_DHE_PSK_WITH_AES_256_CBC_SHA384 = 179;
            static TLS_DHE_PSK_WITH_NULL_SHA256 = 180;
            static TLS_DHE_PSK_WITH_NULL_SHA384 = 181;
            static TLS_RSA_PSK_WITH_AES_128_CBC_SHA256 = 182;
            static TLS_RSA_PSK_WITH_AES_256_CBC_SHA384 = 183;
            static TLS_RSA_PSK_WITH_NULL_SHA256 = 184;
            static TLS_RSA_PSK_WITH_NULL_SHA384 = 185;
            static TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 186;
            static TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256 = 187;
            static TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 188;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256 = 189;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 190;
            static TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256 = 191;
            static TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 192;
            static TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256 = 193;
            static TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 194;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256 = 195;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 196;
            static TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256 = 197;
            static TLS_AES_128_GCM_SHA256 = 4865;
            static TLS_AES_256_GCM_SHA384 = 4866;
            static TLS_CHACHA20_POLY1305_SHA256 = 4867;
            static TLS_AES_128_CCM_SHA256 = 4868;
            static TLS_AES_128_CCM_8_SHA256 = 4869;
            static TLS_ECDH_ECDSA_WITH_NULL_SHA = 49153;
            static TLS_ECDH_ECDSA_WITH_RC4_128_SHA = 49154;
            static TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA = 49155;
            static TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA = 49156;
            static TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA = 49157;
            static TLS_ECDHE_ECDSA_WITH_NULL_SHA = 49158;
            static TLS_ECDHE_ECDSA_WITH_RC4_128_SHA = 49159;
            static TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA = 49160;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA = 49161;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA = 49162;
            static TLS_ECDH_RSA_WITH_NULL_SHA = 49163;
            static TLS_ECDH_RSA_WITH_RC4_128_SHA = 49164;
            static TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA = 49165;
            static TLS_ECDH_RSA_WITH_AES_128_CBC_SHA = 49166;
            static TLS_ECDH_RSA_WITH_AES_256_CBC_SHA = 49167;
            static TLS_ECDHE_RSA_WITH_NULL_SHA = 49168;
            static TLS_ECDHE_RSA_WITH_RC4_128_SHA = 49169;
            static TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA = 49170;
            static TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA = 49171;
            static TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA = 49172;
            static TLS_ECDH_anon_WITH_NULL_SHA = 49173;
            static TLS_ECDH_anon_WITH_RC4_128_SHA = 49174;
            static TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA = 49175;
            static TLS_ECDH_anon_WITH_AES_128_CBC_SHA = 49176;
            static TLS_ECDH_anon_WITH_AES_256_CBC_SHA = 49177;
            static TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA = 49178;
            static TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA = 49179;
            static TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA = 49180;
            static TLS_SRP_SHA_WITH_AES_128_CBC_SHA = 49181;
            static TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA = 49182;
            static TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA = 49183;
            static TLS_SRP_SHA_WITH_AES_256_CBC_SHA = 49184;
            static TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA = 49185;
            static TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA = 49186;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256 = 49187;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384 = 49188;
            static TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256 = 49189;
            static TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384 = 49190;
            static TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256 = 49191;
            static TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384 = 49192;
            static TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256 = 49193;
            static TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384 = 49194;
            static TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256 = 49195;
            static TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384 = 49196;
            static TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256 = 49197;
            static TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384 = 49198;
            static TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 = 49199;
            static TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 = 49200;
            static TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256 = 49201;
            static TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384 = 49202;
            static TLS_ECDHE_PSK_WITH_RC4_128_SHA = 49203;
            static TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA = 49204;
            static TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA = 49205;
            static TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA = 49206;
            static TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256 = 49207;
            static TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384 = 49208;
            static TLS_ECDHE_PSK_WITH_NULL_SHA = 49209;
            static TLS_ECDHE_PSK_WITH_NULL_SHA256 = 49210;
            static TLS_ECDHE_PSK_WITH_NULL_SHA384 = 49211;
            static TLS_RSA_WITH_ARIA_128_CBC_SHA256 = 49212;
            static TLS_RSA_WITH_ARIA_256_CBC_SHA384 = 49213;
            static TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256 = 49214;
            static TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384 = 49215;
            static TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256 = 49216;
            static TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384 = 49217;
            static TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256 = 49218;
            static TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384 = 49219;
            static TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256 = 49220;
            static TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384 = 49221;
            static TLS_DH_anon_WITH_ARIA_128_CBC_SHA256 = 49222;
            static TLS_DH_anon_WITH_ARIA_256_CBC_SHA384 = 49223;
            static TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256 = 49224;
            static TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384 = 49225;
            static TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256 = 49226;
            static TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384 = 49227;
            static TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256 = 49228;
            static TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384 = 49229;
            static TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256 = 49230;
            static TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384 = 49231;
            static TLS_RSA_WITH_ARIA_128_GCM_SHA256 = 49232;
            static TLS_RSA_WITH_ARIA_256_GCM_SHA384 = 49233;
            static TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256 = 49234;
            static TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384 = 49235;
            static TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256 = 49236;
            static TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384 = 49237;
            static TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256 = 49238;
            static TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384 = 49239;
            static TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256 = 49240;
            static TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384 = 49241;
            static TLS_DH_anon_WITH_ARIA_128_GCM_SHA256 = 49242;
            static TLS_DH_anon_WITH_ARIA_256_GCM_SHA384 = 49243;
            static TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256 = 49244;
            static TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384 = 49245;
            static TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256 = 49246;
            static TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384 = 49247;
            static TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256 = 49248;
            static TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384 = 49249;
            static TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256 = 49250;
            static TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384 = 49251;
            static TLS_PSK_WITH_ARIA_128_CBC_SHA256 = 49252;
            static TLS_PSK_WITH_ARIA_256_CBC_SHA384 = 49253;
            static TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256 = 49254;
            static TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384 = 49255;
            static TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256 = 49256;
            static TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384 = 49257;
            static TLS_PSK_WITH_ARIA_128_GCM_SHA256 = 49258;
            static TLS_PSK_WITH_ARIA_256_GCM_SHA384 = 49259;
            static TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256 = 49260;
            static TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384 = 49261;
            static TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256 = 49262;
            static TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384 = 49263;
            static TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256 = 49264;
            static TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384 = 49265;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 = 49266;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 = 49267;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 = 49268;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 = 49269;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 49270;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384 = 49271;
            static TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 49272;
            static TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384 = 49273;
            static TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49274;
            static TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49275;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49276;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49277;
            static TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49278;
            static TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49279;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256 = 49280;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384 = 49281;
            static TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256 = 49282;
            static TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384 = 49283;
            static TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256 = 49284;
            static TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384 = 49285;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 = 49286;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 = 49287;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 = 49288;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 = 49289;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49290;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49291;
            static TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49292;
            static TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49293;
            static TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49294;
            static TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49295;
            static TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49296;
            static TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49297;
            static TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49298;
            static TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49299;
            static TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49300;
            static TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49301;
            static TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49302;
            static TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49303;
            static TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49304;
            static TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49305;
            static TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49306;
            static TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49307;
            static TLS_RSA_WITH_AES_128_CCM = 49308;
            static TLS_RSA_WITH_AES_256_CCM = 49309;
            static TLS_DHE_RSA_WITH_AES_128_CCM = 49310;
            static TLS_DHE_RSA_WITH_AES_256_CCM = 49311;
            static TLS_RSA_WITH_AES_128_CCM_8 = 49312;
            static TLS_RSA_WITH_AES_256_CCM_8 = 49313;
            static TLS_DHE_RSA_WITH_AES_128_CCM_8 = 49314;
            static TLS_DHE_RSA_WITH_AES_256_CCM_8 = 49315;
            static TLS_PSK_WITH_AES_128_CCM = 49316;
            static TLS_PSK_WITH_AES_256_CCM = 49317;
            static TLS_DHE_PSK_WITH_AES_128_CCM = 49318;
            static TLS_DHE_PSK_WITH_AES_256_CCM = 49319;
            static TLS_PSK_WITH_AES_128_CCM_8 = 49320;
            static TLS_PSK_WITH_AES_256_CCM_8 = 49321;
            static TLS_PSK_DHE_WITH_AES_128_CCM_8 = 49322;
            static TLS_PSK_DHE_WITH_AES_256_CCM_8 = 49323;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CCM = 49324;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CCM = 49325;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8 = 49326;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8 = 49327;
            static TLS_ECCPWD_WITH_AES_128_GCM_SHA256 = 49328;
            static TLS_ECCPWD_WITH_AES_256_GCM_SHA384 = 49329;
            static TLS_ECCPWD_WITH_AES_128_CCM_SHA256 = 49330;
            static TLS_ECCPWD_WITH_AES_256_CCM_SHA384 = 49331;
            static TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256 = 52392;
            static TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256 = 52393;
            static TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256 = 52394;
            static TLS_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52395;
            static TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52396;
            static TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52397;
            static TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52398;
            static TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256 = 53249;
            static TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384 = 53250;
            static TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256 = 53251;
            static TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256 = 53253;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TLS_NULL_WITH_NULL_NULL": 0n,
                    "TLS_RSA_WITH_NULL_MD5": 1n,
                    "TLS_RSA_WITH_NULL_SHA": 2n,
                    "TLS_RSA_EXPORT_WITH_RC4_40_MD5": 3n,
                    "TLS_RSA_WITH_RC4_128_MD5": 4n,
                    "TLS_RSA_WITH_RC4_128_SHA": 5n,
                    "TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5": 6n,
                    "TLS_RSA_WITH_IDEA_CBC_SHA": 7n,
                    "TLS_RSA_EXPORT_WITH_DES40_CBC_SHA": 8n,
                    "TLS_RSA_WITH_DES_CBC_SHA": 9n,
                    "TLS_RSA_WITH_3DES_EDE_CBC_SHA": 10n,
                    "TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA": 11n,
                    "TLS_DH_DSS_WITH_DES_CBC_SHA": 12n,
                    "TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA": 13n,
                    "TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA": 14n,
                    "TLS_DH_RSA_WITH_DES_CBC_SHA": 15n,
                    "TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA": 16n,
                    "TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA": 17n,
                    "TLS_DHE_DSS_WITH_DES_CBC_SHA": 18n,
                    "TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA": 19n,
                    "TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA": 20n,
                    "TLS_DHE_RSA_WITH_DES_CBC_SHA": 21n,
                    "TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA": 22n,
                    "TLS_DH_anon_EXPORT_WITH_RC4_40_MD5": 23n,
                    "TLS_DH_anon_WITH_RC4_128_MD5": 24n,
                    "TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA": 25n,
                    "TLS_DH_anon_WITH_DES_CBC_SHA": 26n,
                    "TLS_DH_anon_WITH_3DES_EDE_CBC_SHA": 27n,
                    "TLS_KRB5_WITH_DES_CBC_SHA": 30n,
                    "TLS_KRB5_WITH_3DES_EDE_CBC_SHA": 31n,
                    "TLS_KRB5_WITH_RC4_128_SHA": 32n,
                    "TLS_KRB5_WITH_IDEA_CBC_SHA": 33n,
                    "TLS_KRB5_WITH_DES_CBC_MD5": 34n,
                    "TLS_KRB5_WITH_3DES_EDE_CBC_MD5": 35n,
                    "TLS_KRB5_WITH_RC4_128_MD5": 36n,
                    "TLS_KRB5_WITH_IDEA_CBC_MD5": 37n,
                    "TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA": 38n,
                    "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA": 39n,
                    "TLS_KRB5_EXPORT_WITH_RC4_40_SHA": 40n,
                    "TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5": 41n,
                    "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5": 42n,
                    "TLS_KRB5_EXPORT_WITH_RC4_40_MD5": 43n,
                    "TLS_PSK_WITH_NULL_SHA": 44n,
                    "TLS_DHE_PSK_WITH_NULL_SHA": 45n,
                    "TLS_RSA_PSK_WITH_NULL_SHA": 46n,
                    "TLS_RSA_WITH_AES_128_CBC_SHA": 47n,
                    "TLS_DH_DSS_WITH_AES_128_CBC_SHA": 48n,
                    "TLS_DH_RSA_WITH_AES_128_CBC_SHA": 49n,
                    "TLS_DHE_DSS_WITH_AES_128_CBC_SHA": 50n,
                    "TLS_DHE_RSA_WITH_AES_128_CBC_SHA": 51n,
                    "TLS_DH_anon_WITH_AES_128_CBC_SHA": 52n,
                    "TLS_RSA_WITH_AES_256_CBC_SHA": 53n,
                    "TLS_DH_DSS_WITH_AES_256_CBC_SHA": 54n,
                    "TLS_DH_RSA_WITH_AES_256_CBC_SHA": 55n,
                    "TLS_DHE_DSS_WITH_AES_256_CBC_SHA": 56n,
                    "TLS_DHE_RSA_WITH_AES_256_CBC_SHA": 57n,
                    "TLS_DH_anon_WITH_AES_256_CBC_SHA": 58n,
                    "TLS_RSA_WITH_NULL_SHA256": 59n,
                    "TLS_RSA_WITH_AES_128_CBC_SHA256": 60n,
                    "TLS_RSA_WITH_AES_256_CBC_SHA256": 61n,
                    "TLS_DH_DSS_WITH_AES_128_CBC_SHA256": 62n,
                    "TLS_DH_RSA_WITH_AES_128_CBC_SHA256": 63n,
                    "TLS_DHE_DSS_WITH_AES_128_CBC_SHA256": 64n,
                    "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA": 65n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA": 66n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA": 67n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA": 68n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA": 69n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA": 70n,
                    "TLS_DHE_RSA_WITH_AES_128_CBC_SHA256": 103n,
                    "TLS_DH_DSS_WITH_AES_256_CBC_SHA256": 104n,
                    "TLS_DH_RSA_WITH_AES_256_CBC_SHA256": 105n,
                    "TLS_DHE_DSS_WITH_AES_256_CBC_SHA256": 106n,
                    "TLS_DHE_RSA_WITH_AES_256_CBC_SHA256": 107n,
                    "TLS_DH_anon_WITH_AES_128_CBC_SHA256": 108n,
                    "TLS_DH_anon_WITH_AES_256_CBC_SHA256": 109n,
                    "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA": 132n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA": 133n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA": 134n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA": 135n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA": 136n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA": 137n,
                    "TLS_PSK_WITH_RC4_128_SHA": 138n,
                    "TLS_PSK_WITH_3DES_EDE_CBC_SHA": 139n,
                    "TLS_PSK_WITH_AES_128_CBC_SHA": 140n,
                    "TLS_PSK_WITH_AES_256_CBC_SHA": 141n,
                    "TLS_DHE_PSK_WITH_RC4_128_SHA": 142n,
                    "TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA": 143n,
                    "TLS_DHE_PSK_WITH_AES_128_CBC_SHA": 144n,
                    "TLS_DHE_PSK_WITH_AES_256_CBC_SHA": 145n,
                    "TLS_RSA_PSK_WITH_RC4_128_SHA": 146n,
                    "TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA": 147n,
                    "TLS_RSA_PSK_WITH_AES_128_CBC_SHA": 148n,
                    "TLS_RSA_PSK_WITH_AES_256_CBC_SHA": 149n,
                    "TLS_RSA_WITH_SEED_CBC_SHA": 150n,
                    "TLS_DH_DSS_WITH_SEED_CBC_SHA": 151n,
                    "TLS_DH_RSA_WITH_SEED_CBC_SHA": 152n,
                    "TLS_DHE_DSS_WITH_SEED_CBC_SHA": 153n,
                    "TLS_DHE_RSA_WITH_SEED_CBC_SHA": 154n,
                    "TLS_DH_anon_WITH_SEED_CBC_SHA": 155n,
                    "TLS_RSA_WITH_AES_128_GCM_SHA256": 156n,
                    "TLS_RSA_WITH_AES_256_GCM_SHA384": 157n,
                    "TLS_DHE_RSA_WITH_AES_128_GCM_SHA256": 158n,
                    "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384": 159n,
                    "TLS_DH_RSA_WITH_AES_128_GCM_SHA256": 160n,
                    "TLS_DH_RSA_WITH_AES_256_GCM_SHA384": 161n,
                    "TLS_DHE_DSS_WITH_AES_128_GCM_SHA256": 162n,
                    "TLS_DHE_DSS_WITH_AES_256_GCM_SHA384": 163n,
                    "TLS_DH_DSS_WITH_AES_128_GCM_SHA256": 164n,
                    "TLS_DH_DSS_WITH_AES_256_GCM_SHA384": 165n,
                    "TLS_DH_anon_WITH_AES_128_GCM_SHA256": 166n,
                    "TLS_DH_anon_WITH_AES_256_GCM_SHA384": 167n,
                    "TLS_PSK_WITH_AES_128_GCM_SHA256": 168n,
                    "TLS_PSK_WITH_AES_256_GCM_SHA384": 169n,
                    "TLS_DHE_PSK_WITH_AES_128_GCM_SHA256": 170n,
                    "TLS_DHE_PSK_WITH_AES_256_GCM_SHA384": 171n,
                    "TLS_RSA_PSK_WITH_AES_128_GCM_SHA256": 172n,
                    "TLS_RSA_PSK_WITH_AES_256_GCM_SHA384": 173n,
                    "TLS_PSK_WITH_AES_128_CBC_SHA256": 174n,
                    "TLS_PSK_WITH_AES_256_CBC_SHA384": 175n,
                    "TLS_PSK_WITH_NULL_SHA256": 176n,
                    "TLS_PSK_WITH_NULL_SHA384": 177n,
                    "TLS_DHE_PSK_WITH_AES_128_CBC_SHA256": 178n,
                    "TLS_DHE_PSK_WITH_AES_256_CBC_SHA384": 179n,
                    "TLS_DHE_PSK_WITH_NULL_SHA256": 180n,
                    "TLS_DHE_PSK_WITH_NULL_SHA384": 181n,
                    "TLS_RSA_PSK_WITH_AES_128_CBC_SHA256": 182n,
                    "TLS_RSA_PSK_WITH_AES_256_CBC_SHA384": 183n,
                    "TLS_RSA_PSK_WITH_NULL_SHA256": 184n,
                    "TLS_RSA_PSK_WITH_NULL_SHA384": 185n,
                    "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256": 186n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256": 187n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256": 188n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256": 189n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256": 190n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256": 191n,
                    "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256": 192n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256": 193n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256": 194n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256": 195n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256": 196n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256": 197n,
                    "TLS_AES_128_GCM_SHA256": 4865n,
                    "TLS_AES_256_GCM_SHA384": 4866n,
                    "TLS_CHACHA20_POLY1305_SHA256": 4867n,
                    "TLS_AES_128_CCM_SHA256": 4868n,
                    "TLS_AES_128_CCM_8_SHA256": 4869n,
                    "TLS_ECDH_ECDSA_WITH_NULL_SHA": 49153n,
                    "TLS_ECDH_ECDSA_WITH_RC4_128_SHA": 49154n,
                    "TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA": 49155n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA": 49156n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA": 49157n,
                    "TLS_ECDHE_ECDSA_WITH_NULL_SHA": 49158n,
                    "TLS_ECDHE_ECDSA_WITH_RC4_128_SHA": 49159n,
                    "TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA": 49160n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA": 49161n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA": 49162n,
                    "TLS_ECDH_RSA_WITH_NULL_SHA": 49163n,
                    "TLS_ECDH_RSA_WITH_RC4_128_SHA": 49164n,
                    "TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA": 49165n,
                    "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA": 49166n,
                    "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA": 49167n,
                    "TLS_ECDHE_RSA_WITH_NULL_SHA": 49168n,
                    "TLS_ECDHE_RSA_WITH_RC4_128_SHA": 49169n,
                    "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA": 49170n,
                    "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA": 49171n,
                    "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA": 49172n,
                    "TLS_ECDH_anon_WITH_NULL_SHA": 49173n,
                    "TLS_ECDH_anon_WITH_RC4_128_SHA": 49174n,
                    "TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA": 49175n,
                    "TLS_ECDH_anon_WITH_AES_128_CBC_SHA": 49176n,
                    "TLS_ECDH_anon_WITH_AES_256_CBC_SHA": 49177n,
                    "TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA": 49178n,
                    "TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA": 49179n,
                    "TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA": 49180n,
                    "TLS_SRP_SHA_WITH_AES_128_CBC_SHA": 49181n,
                    "TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA": 49182n,
                    "TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA": 49183n,
                    "TLS_SRP_SHA_WITH_AES_256_CBC_SHA": 49184n,
                    "TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA": 49185n,
                    "TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA": 49186n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256": 49187n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384": 49188n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256": 49189n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384": 49190n,
                    "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256": 49191n,
                    "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384": 49192n,
                    "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256": 49193n,
                    "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384": 49194n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256": 49195n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384": 49196n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256": 49197n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384": 49198n,
                    "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256": 49199n,
                    "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384": 49200n,
                    "TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256": 49201n,
                    "TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384": 49202n,
                    "TLS_ECDHE_PSK_WITH_RC4_128_SHA": 49203n,
                    "TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA": 49204n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA": 49205n,
                    "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA": 49206n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256": 49207n,
                    "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384": 49208n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA": 49209n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA256": 49210n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA384": 49211n,
                    "TLS_RSA_WITH_ARIA_128_CBC_SHA256": 49212n,
                    "TLS_RSA_WITH_ARIA_256_CBC_SHA384": 49213n,
                    "TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256": 49214n,
                    "TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384": 49215n,
                    "TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256": 49216n,
                    "TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384": 49217n,
                    "TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256": 49218n,
                    "TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384": 49219n,
                    "TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256": 49220n,
                    "TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384": 49221n,
                    "TLS_DH_anon_WITH_ARIA_128_CBC_SHA256": 49222n,
                    "TLS_DH_anon_WITH_ARIA_256_CBC_SHA384": 49223n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256": 49224n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384": 49225n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256": 49226n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384": 49227n,
                    "TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256": 49228n,
                    "TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384": 49229n,
                    "TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256": 49230n,
                    "TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384": 49231n,
                    "TLS_RSA_WITH_ARIA_128_GCM_SHA256": 49232n,
                    "TLS_RSA_WITH_ARIA_256_GCM_SHA384": 49233n,
                    "TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256": 49234n,
                    "TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384": 49235n,
                    "TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256": 49236n,
                    "TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384": 49237n,
                    "TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256": 49238n,
                    "TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384": 49239n,
                    "TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256": 49240n,
                    "TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384": 49241n,
                    "TLS_DH_anon_WITH_ARIA_128_GCM_SHA256": 49242n,
                    "TLS_DH_anon_WITH_ARIA_256_GCM_SHA384": 49243n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256": 49244n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384": 49245n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256": 49246n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384": 49247n,
                    "TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256": 49248n,
                    "TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384": 49249n,
                    "TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256": 49250n,
                    "TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384": 49251n,
                    "TLS_PSK_WITH_ARIA_128_CBC_SHA256": 49252n,
                    "TLS_PSK_WITH_ARIA_256_CBC_SHA384": 49253n,
                    "TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256": 49254n,
                    "TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384": 49255n,
                    "TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256": 49256n,
                    "TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384": 49257n,
                    "TLS_PSK_WITH_ARIA_128_GCM_SHA256": 49258n,
                    "TLS_PSK_WITH_ARIA_256_GCM_SHA384": 49259n,
                    "TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256": 49260n,
                    "TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384": 49261n,
                    "TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256": 49262n,
                    "TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384": 49263n,
                    "TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256": 49264n,
                    "TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384": 49265n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256": 49266n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384": 49267n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256": 49268n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384": 49269n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256": 49270n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384": 49271n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256": 49272n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384": 49273n,
                    "TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49274n,
                    "TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49275n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49276n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49277n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49278n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49279n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256": 49280n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384": 49281n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256": 49282n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384": 49283n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256": 49284n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384": 49285n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256": 49286n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384": 49287n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256": 49288n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384": 49289n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49290n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49291n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49292n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49293n,
                    "TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49294n,
                    "TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49295n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49296n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49297n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49298n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49299n,
                    "TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49300n,
                    "TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49301n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49302n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49303n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49304n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49305n,
                    "TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49306n,
                    "TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49307n,
                    "TLS_RSA_WITH_AES_128_CCM": 49308n,
                    "TLS_RSA_WITH_AES_256_CCM": 49309n,
                    "TLS_DHE_RSA_WITH_AES_128_CCM": 49310n,
                    "TLS_DHE_RSA_WITH_AES_256_CCM": 49311n,
                    "TLS_RSA_WITH_AES_128_CCM_8": 49312n,
                    "TLS_RSA_WITH_AES_256_CCM_8": 49313n,
                    "TLS_DHE_RSA_WITH_AES_128_CCM_8": 49314n,
                    "TLS_DHE_RSA_WITH_AES_256_CCM_8": 49315n,
                    "TLS_PSK_WITH_AES_128_CCM": 49316n,
                    "TLS_PSK_WITH_AES_256_CCM": 49317n,
                    "TLS_DHE_PSK_WITH_AES_128_CCM": 49318n,
                    "TLS_DHE_PSK_WITH_AES_256_CCM": 49319n,
                    "TLS_PSK_WITH_AES_128_CCM_8": 49320n,
                    "TLS_PSK_WITH_AES_256_CCM_8": 49321n,
                    "TLS_PSK_DHE_WITH_AES_128_CCM_8": 49322n,
                    "TLS_PSK_DHE_WITH_AES_256_CCM_8": 49323n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CCM": 49324n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CCM": 49325n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8": 49326n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8": 49327n,
                    "TLS_ECCPWD_WITH_AES_128_GCM_SHA256": 49328n,
                    "TLS_ECCPWD_WITH_AES_256_GCM_SHA384": 49329n,
                    "TLS_ECCPWD_WITH_AES_128_CCM_SHA256": 49330n,
                    "TLS_ECCPWD_WITH_AES_256_CCM_SHA384": 49331n,
                    "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256": 52392n,
                    "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256": 52393n,
                    "TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256": 52394n,
                    "TLS_PSK_WITH_CHACHA20_POLY1305_SHA256": 52395n,
                    "TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256": 52396n,
                    "TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256": 52397n,
                    "TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256": 52398n,
                    "TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256": 53249n,
                    "TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384": 53250n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256": 53251n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256": 53253n
                };
            }
            static $h = 1412926;
            static $z = 2;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.UInt16; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":589825,"l":[{"t":1412926,"n":"TLS_NULL_WITH_NULL_NULL","d":1412926,"h":4296380222,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_NULL_MD5","d":1412926,"h":8591347518,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_NULL_SHA","d":1412926,"h":12886314814,"f":33},{"t":1412926,"n":"TLS_RSA_EXPORT_WITH_RC4_40_MD5","d":1412926,"h":17181282110,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_RC4_128_MD5","d":1412926,"h":21476249406,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_RC4_128_SHA","d":1412926,"h":25771216702,"f":33},{"t":1412926,"n":"TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5","d":1412926,"h":30066183998,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_IDEA_CBC_SHA","d":1412926,"h":34361151294,"f":33},{"t":1412926,"n":"TLS_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1412926,"h":38656118590,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_DES_CBC_SHA","d":1412926,"h":42951085886,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":47246053182,"f":33},{"t":1412926,"n":"TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA","d":1412926,"h":51541020478,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_DES_CBC_SHA","d":1412926,"h":55835987774,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":60130955070,"f":33},{"t":1412926,"n":"TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1412926,"h":64425922366,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_DES_CBC_SHA","d":1412926,"h":68720889662,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":73015856958,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA","d":1412926,"h":77310824254,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_DES_CBC_SHA","d":1412926,"h":81605791550,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":85900758846,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1412926,"h":90195726142,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_DES_CBC_SHA","d":1412926,"h":94490693438,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":98785660734,"f":33},{"t":1412926,"n":"TLS_DH_anon_EXPORT_WITH_RC4_40_MD5","d":1412926,"h":103080628030,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_RC4_128_MD5","d":1412926,"h":107375595326,"f":33},{"t":1412926,"n":"TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA","d":1412926,"h":111670562622,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_DES_CBC_SHA","d":1412926,"h":115965529918,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":120260497214,"f":33},{"t":1412926,"n":"TLS_KRB5_WITH_DES_CBC_SHA","d":1412926,"h":124555464510,"f":33},{"t":1412926,"n":"TLS_KRB5_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":128850431806,"f":33},{"t":1412926,"n":"TLS_KRB5_WITH_RC4_128_SHA","d":1412926,"h":133145399102,"f":33},{"t":1412926,"n":"TLS_KRB5_WITH_IDEA_CBC_SHA","d":1412926,"h":137440366398,"f":33},{"t":1412926,"n":"TLS_KRB5_WITH_DES_CBC_MD5","d":1412926,"h":141735333694,"f":33},{"t":1412926,"n":"TLS_KRB5_WITH_3DES_EDE_CBC_MD5","d":1412926,"h":146030300990,"f":33},{"t":1412926,"n":"TLS_KRB5_WITH_RC4_128_MD5","d":1412926,"h":150325268286,"f":33},{"t":1412926,"n":"TLS_KRB5_WITH_IDEA_CBC_MD5","d":1412926,"h":154620235582,"f":33},{"t":1412926,"n":"TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA","d":1412926,"h":158915202878,"f":33},{"t":1412926,"n":"TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA","d":1412926,"h":163210170174,"f":33},{"t":1412926,"n":"TLS_KRB5_EXPORT_WITH_RC4_40_SHA","d":1412926,"h":167505137470,"f":33},{"t":1412926,"n":"TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5","d":1412926,"h":171800104766,"f":33},{"t":1412926,"n":"TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5","d":1412926,"h":176095072062,"f":33},{"t":1412926,"n":"TLS_KRB5_EXPORT_WITH_RC4_40_MD5","d":1412926,"h":180390039358,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_NULL_SHA","d":1412926,"h":184685006654,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_NULL_SHA","d":1412926,"h":188979973950,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_NULL_SHA","d":1412926,"h":193274941246,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_AES_128_CBC_SHA","d":1412926,"h":197569908542,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_AES_128_CBC_SHA","d":1412926,"h":201864875838,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_AES_128_CBC_SHA","d":1412926,"h":206159843134,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_AES_128_CBC_SHA","d":1412926,"h":210454810430,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_AES_128_CBC_SHA","d":1412926,"h":214749777726,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_AES_128_CBC_SHA","d":1412926,"h":219044745022,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_AES_256_CBC_SHA","d":1412926,"h":223339712318,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_AES_256_CBC_SHA","d":1412926,"h":227634679614,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_AES_256_CBC_SHA","d":1412926,"h":231929646910,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_AES_256_CBC_SHA","d":1412926,"h":236224614206,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_AES_256_CBC_SHA","d":1412926,"h":240519581502,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_AES_256_CBC_SHA","d":1412926,"h":244814548798,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_NULL_SHA256","d":1412926,"h":249109516094,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_AES_128_CBC_SHA256","d":1412926,"h":253404483390,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_AES_256_CBC_SHA256","d":1412926,"h":257699450686,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_AES_128_CBC_SHA256","d":1412926,"h":261994417982,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_AES_128_CBC_SHA256","d":1412926,"h":266289385278,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_AES_128_CBC_SHA256","d":1412926,"h":270584352574,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1412926,"h":274879319870,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA","d":1412926,"h":279174287166,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1412926,"h":283469254462,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA","d":1412926,"h":287764221758,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1412926,"h":292059189054,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA","d":1412926,"h":296354156350,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_AES_128_CBC_SHA256","d":1412926,"h":300649123646,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_AES_256_CBC_SHA256","d":1412926,"h":304944090942,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_AES_256_CBC_SHA256","d":1412926,"h":309239058238,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_AES_256_CBC_SHA256","d":1412926,"h":313534025534,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_AES_256_CBC_SHA256","d":1412926,"h":317828992830,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_AES_128_CBC_SHA256","d":1412926,"h":322123960126,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_AES_256_CBC_SHA256","d":1412926,"h":326418927422,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1412926,"h":330713894718,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA","d":1412926,"h":335008862014,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1412926,"h":339303829310,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA","d":1412926,"h":343598796606,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1412926,"h":347893763902,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA","d":1412926,"h":352188731198,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_RC4_128_SHA","d":1412926,"h":356483698494,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":360778665790,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_AES_128_CBC_SHA","d":1412926,"h":365073633086,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_AES_256_CBC_SHA","d":1412926,"h":369368600382,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_RC4_128_SHA","d":1412926,"h":373663567678,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":377958534974,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_AES_128_CBC_SHA","d":1412926,"h":382253502270,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_AES_256_CBC_SHA","d":1412926,"h":386548469566,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_RC4_128_SHA","d":1412926,"h":390843436862,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":395138404158,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_AES_128_CBC_SHA","d":1412926,"h":399433371454,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_AES_256_CBC_SHA","d":1412926,"h":403728338750,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_SEED_CBC_SHA","d":1412926,"h":408023306046,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_SEED_CBC_SHA","d":1412926,"h":412318273342,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_SEED_CBC_SHA","d":1412926,"h":416613240638,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_SEED_CBC_SHA","d":1412926,"h":420908207934,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_SEED_CBC_SHA","d":1412926,"h":425203175230,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_SEED_CBC_SHA","d":1412926,"h":429498142526,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_AES_128_GCM_SHA256","d":1412926,"h":433793109822,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_AES_256_GCM_SHA384","d":1412926,"h":438088077118,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_AES_128_GCM_SHA256","d":1412926,"h":442383044414,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_AES_256_GCM_SHA384","d":1412926,"h":446678011710,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_AES_128_GCM_SHA256","d":1412926,"h":450972979006,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_AES_256_GCM_SHA384","d":1412926,"h":455267946302,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_AES_128_GCM_SHA256","d":1412926,"h":459562913598,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_AES_256_GCM_SHA384","d":1412926,"h":463857880894,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_AES_128_GCM_SHA256","d":1412926,"h":468152848190,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_AES_256_GCM_SHA384","d":1412926,"h":472447815486,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_AES_128_GCM_SHA256","d":1412926,"h":476742782782,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_AES_256_GCM_SHA384","d":1412926,"h":481037750078,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_AES_128_GCM_SHA256","d":1412926,"h":485332717374,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_AES_256_GCM_SHA384","d":1412926,"h":489627684670,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_AES_128_GCM_SHA256","d":1412926,"h":493922651966,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_AES_256_GCM_SHA384","d":1412926,"h":498217619262,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_AES_128_GCM_SHA256","d":1412926,"h":502512586558,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_AES_256_GCM_SHA384","d":1412926,"h":506807553854,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_AES_128_CBC_SHA256","d":1412926,"h":511102521150,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_AES_256_CBC_SHA384","d":1412926,"h":515397488446,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_NULL_SHA256","d":1412926,"h":519692455742,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_NULL_SHA384","d":1412926,"h":523987423038,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_AES_128_CBC_SHA256","d":1412926,"h":528282390334,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_AES_256_CBC_SHA384","d":1412926,"h":532577357630,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_NULL_SHA256","d":1412926,"h":536872324926,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_NULL_SHA384","d":1412926,"h":541167292222,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_AES_128_CBC_SHA256","d":1412926,"h":545462259518,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_AES_256_CBC_SHA384","d":1412926,"h":549757226814,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_NULL_SHA256","d":1412926,"h":554052194110,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_NULL_SHA384","d":1412926,"h":558347161406,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1412926,"h":562642128702,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256","d":1412926,"h":566937095998,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1412926,"h":571232063294,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256","d":1412926,"h":575527030590,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1412926,"h":579821997886,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256","d":1412926,"h":584116965182,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1412926,"h":588411932478,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256","d":1412926,"h":592706899774,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1412926,"h":597001867070,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256","d":1412926,"h":601296834366,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1412926,"h":605591801662,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256","d":1412926,"h":609886768958,"f":33},{"t":1412926,"n":"TLS_AES_128_GCM_SHA256","d":1412926,"h":614181736254,"f":33},{"t":1412926,"n":"TLS_AES_256_GCM_SHA384","d":1412926,"h":618476703550,"f":33},{"t":1412926,"n":"TLS_CHACHA20_POLY1305_SHA256","d":1412926,"h":622771670846,"f":33},{"t":1412926,"n":"TLS_AES_128_CCM_SHA256","d":1412926,"h":627066638142,"f":33},{"t":1412926,"n":"TLS_AES_128_CCM_8_SHA256","d":1412926,"h":631361605438,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_NULL_SHA","d":1412926,"h":635656572734,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_RC4_128_SHA","d":1412926,"h":639951540030,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":644246507326,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA","d":1412926,"h":648541474622,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA","d":1412926,"h":652836441918,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_NULL_SHA","d":1412926,"h":657131409214,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_RC4_128_SHA","d":1412926,"h":661426376510,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":665721343806,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA","d":1412926,"h":670016311102,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA","d":1412926,"h":674311278398,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_NULL_SHA","d":1412926,"h":678606245694,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_RC4_128_SHA","d":1412926,"h":682901212990,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":687196180286,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_AES_128_CBC_SHA","d":1412926,"h":691491147582,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_AES_256_CBC_SHA","d":1412926,"h":695786114878,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_NULL_SHA","d":1412926,"h":700081082174,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_RC4_128_SHA","d":1412926,"h":704376049470,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":708671016766,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA","d":1412926,"h":712965984062,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA","d":1412926,"h":717260951358,"f":33},{"t":1412926,"n":"TLS_ECDH_anon_WITH_NULL_SHA","d":1412926,"h":721555918654,"f":33},{"t":1412926,"n":"TLS_ECDH_anon_WITH_RC4_128_SHA","d":1412926,"h":725850885950,"f":33},{"t":1412926,"n":"TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":730145853246,"f":33},{"t":1412926,"n":"TLS_ECDH_anon_WITH_AES_128_CBC_SHA","d":1412926,"h":734440820542,"f":33},{"t":1412926,"n":"TLS_ECDH_anon_WITH_AES_256_CBC_SHA","d":1412926,"h":738735787838,"f":33},{"t":1412926,"n":"TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":743030755134,"f":33},{"t":1412926,"n":"TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":747325722430,"f":33},{"t":1412926,"n":"TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":751620689726,"f":33},{"t":1412926,"n":"TLS_SRP_SHA_WITH_AES_128_CBC_SHA","d":1412926,"h":755915657022,"f":33},{"t":1412926,"n":"TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA","d":1412926,"h":760210624318,"f":33},{"t":1412926,"n":"TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA","d":1412926,"h":764505591614,"f":33},{"t":1412926,"n":"TLS_SRP_SHA_WITH_AES_256_CBC_SHA","d":1412926,"h":768800558910,"f":33},{"t":1412926,"n":"TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA","d":1412926,"h":773095526206,"f":33},{"t":1412926,"n":"TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA","d":1412926,"h":777390493502,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256","d":1412926,"h":781685460798,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384","d":1412926,"h":785980428094,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256","d":1412926,"h":790275395390,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384","d":1412926,"h":794570362686,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256","d":1412926,"h":798865329982,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384","d":1412926,"h":803160297278,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256","d":1412926,"h":807455264574,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384","d":1412926,"h":811750231870,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256","d":1412926,"h":816045199166,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384","d":1412926,"h":820340166462,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256","d":1412926,"h":824635133758,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384","d":1412926,"h":828930101054,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256","d":1412926,"h":833225068350,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384","d":1412926,"h":837520035646,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256","d":1412926,"h":841815002942,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384","d":1412926,"h":846109970238,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_RC4_128_SHA","d":1412926,"h":850404937534,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA","d":1412926,"h":854699904830,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA","d":1412926,"h":858994872126,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA","d":1412926,"h":863289839422,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256","d":1412926,"h":867584806718,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384","d":1412926,"h":871879774014,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA","d":1412926,"h":876174741310,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA256","d":1412926,"h":880469708606,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA384","d":1412926,"h":884764675902,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_ARIA_128_CBC_SHA256","d":1412926,"h":889059643198,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_ARIA_256_CBC_SHA384","d":1412926,"h":893354610494,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256","d":1412926,"h":897649577790,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384","d":1412926,"h":901944545086,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256","d":1412926,"h":906239512382,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384","d":1412926,"h":910534479678,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256","d":1412926,"h":914829446974,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384","d":1412926,"h":919124414270,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256","d":1412926,"h":923419381566,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384","d":1412926,"h":927714348862,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_ARIA_128_CBC_SHA256","d":1412926,"h":932009316158,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_ARIA_256_CBC_SHA384","d":1412926,"h":936304283454,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256","d":1412926,"h":940599250750,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384","d":1412926,"h":944894218046,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256","d":1412926,"h":949189185342,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384","d":1412926,"h":953484152638,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256","d":1412926,"h":957779119934,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384","d":1412926,"h":962074087230,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256","d":1412926,"h":966369054526,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384","d":1412926,"h":970664021822,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_ARIA_128_GCM_SHA256","d":1412926,"h":974958989118,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_ARIA_256_GCM_SHA384","d":1412926,"h":979253956414,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256","d":1412926,"h":983548923710,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384","d":1412926,"h":987843891006,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256","d":1412926,"h":992138858302,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384","d":1412926,"h":996433825598,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256","d":1412926,"h":1000728792894,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384","d":1412926,"h":1005023760190,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256","d":1412926,"h":1009318727486,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384","d":1412926,"h":1013613694782,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_ARIA_128_GCM_SHA256","d":1412926,"h":1017908662078,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_ARIA_256_GCM_SHA384","d":1412926,"h":1022203629374,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256","d":1412926,"h":1026498596670,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384","d":1412926,"h":1030793563966,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256","d":1412926,"h":1035088531262,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384","d":1412926,"h":1039383498558,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256","d":1412926,"h":1043678465854,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384","d":1412926,"h":1047973433150,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256","d":1412926,"h":1052268400446,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384","d":1412926,"h":1056563367742,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_ARIA_128_CBC_SHA256","d":1412926,"h":1060858335038,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_ARIA_256_CBC_SHA384","d":1412926,"h":1065153302334,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256","d":1412926,"h":1069448269630,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384","d":1412926,"h":1073743236926,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256","d":1412926,"h":1078038204222,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384","d":1412926,"h":1082333171518,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_ARIA_128_GCM_SHA256","d":1412926,"h":1086628138814,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_ARIA_256_GCM_SHA384","d":1412926,"h":1090923106110,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256","d":1412926,"h":1095218073406,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384","d":1412926,"h":1099513040702,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256","d":1412926,"h":1103808007998,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384","d":1412926,"h":1108102975294,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256","d":1412926,"h":1112397942590,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384","d":1412926,"h":1116692909886,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256","d":1412926,"h":1120987877182,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384","d":1412926,"h":1125282844478,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256","d":1412926,"h":1129577811774,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384","d":1412926,"h":1133872779070,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1412926,"h":1138167746366,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384","d":1412926,"h":1142462713662,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1412926,"h":1146757680958,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384","d":1412926,"h":1151052648254,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1412926,"h":1155347615550,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1412926,"h":1159642582846,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1412926,"h":1163937550142,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1412926,"h":1168232517438,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1412926,"h":1172527484734,"f":33},{"t":1412926,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1412926,"h":1176822452030,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256","d":1412926,"h":1181117419326,"f":33},{"t":1412926,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384","d":1412926,"h":1185412386622,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256","d":1412926,"h":1189707353918,"f":33},{"t":1412926,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384","d":1412926,"h":1194002321214,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256","d":1412926,"h":1198297288510,"f":33},{"t":1412926,"n":"TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384","d":1412926,"h":1202592255806,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256","d":1412926,"h":1206887223102,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384","d":1412926,"h":1211182190398,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256","d":1412926,"h":1215477157694,"f":33},{"t":1412926,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384","d":1412926,"h":1219772124990,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1412926,"h":1224067092286,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1412926,"h":1228362059582,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1412926,"h":1232657026878,"f":33},{"t":1412926,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1412926,"h":1236951994174,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1412926,"h":1241246961470,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1412926,"h":1245541928766,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1412926,"h":1249836896062,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1412926,"h":1254131863358,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1412926,"h":1258426830654,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1412926,"h":1262721797950,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1412926,"h":1267016765246,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1412926,"h":1271311732542,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1412926,"h":1275606699838,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1412926,"h":1279901667134,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1412926,"h":1284196634430,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1412926,"h":1288491601726,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1412926,"h":1292786569022,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1412926,"h":1297081536318,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_AES_128_CCM","d":1412926,"h":1301376503614,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_AES_256_CCM","d":1412926,"h":1305671470910,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_AES_128_CCM","d":1412926,"h":1309966438206,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_AES_256_CCM","d":1412926,"h":1314261405502,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_AES_128_CCM_8","d":1412926,"h":1318556372798,"f":33},{"t":1412926,"n":"TLS_RSA_WITH_AES_256_CCM_8","d":1412926,"h":1322851340094,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_AES_128_CCM_8","d":1412926,"h":1327146307390,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_AES_256_CCM_8","d":1412926,"h":1331441274686,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_AES_128_CCM","d":1412926,"h":1335736241982,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_AES_256_CCM","d":1412926,"h":1340031209278,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_AES_128_CCM","d":1412926,"h":1344326176574,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_AES_256_CCM","d":1412926,"h":1348621143870,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_AES_128_CCM_8","d":1412926,"h":1352916111166,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_AES_256_CCM_8","d":1412926,"h":1357211078462,"f":33},{"t":1412926,"n":"TLS_PSK_DHE_WITH_AES_128_CCM_8","d":1412926,"h":1361506045758,"f":33},{"t":1412926,"n":"TLS_PSK_DHE_WITH_AES_256_CCM_8","d":1412926,"h":1365801013054,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CCM","d":1412926,"h":1370095980350,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CCM","d":1412926,"h":1374390947646,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8","d":1412926,"h":1378685914942,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8","d":1412926,"h":1382980882238,"f":33},{"t":1412926,"n":"TLS_ECCPWD_WITH_AES_128_GCM_SHA256","d":1412926,"h":1387275849534,"f":33},{"t":1412926,"n":"TLS_ECCPWD_WITH_AES_256_GCM_SHA384","d":1412926,"h":1391570816830,"f":33},{"t":1412926,"n":"TLS_ECCPWD_WITH_AES_128_CCM_SHA256","d":1412926,"h":1395865784126,"f":33},{"t":1412926,"n":"TLS_ECCPWD_WITH_AES_256_CCM_SHA384","d":1412926,"h":1400160751422,"f":33},{"t":1412926,"n":"TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256","d":1412926,"h":1404455718718,"f":33},{"t":1412926,"n":"TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256","d":1412926,"h":1408750686014,"f":33},{"t":1412926,"n":"TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256","d":1412926,"h":1413045653310,"f":33},{"t":1412926,"n":"TLS_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1412926,"h":1417340620606,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1412926,"h":1421635587902,"f":33},{"t":1412926,"n":"TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1412926,"h":1425930555198,"f":33},{"t":1412926,"n":"TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1412926,"h":1430225522494,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256","d":1412926,"h":1434520489790,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384","d":1412926,"h":1438815457086,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256","d":1412926,"h":1443110424382,"f":33},{"t":1412926,"n":"TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256","d":1412926,"h":1447405391678,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1412926,"h":1451700358974,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1412926,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.TlsCipherSuite`; }
        });
        
        $asm.$str("$snsc.System.Security.Authentication.ExtendedProtection.PolicyEnforcement", ($self) => class PolicyEnforcement extends $.$spc.System.Enum
        {
            static Never = 0;
            static WhenSupported = 1;
            static Always = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Never": 0n,
                    "WhenSupported": 1n,
                    "Always": 2n
                };
            }
            static $h = 1609534;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1609534,"n":"Never","d":1609534,"h":4296576830,"f":33},{"t":1609534,"n":"WhenSupported","d":1609534,"h":8591544126,"f":33},{"t":1609534,"n":"Always","d":1609534,"h":12886511422,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1609534,"h":17181478718,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1609534}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.PolicyEnforcement`; }
        });
        
        $asm.$str("$snsc.System.Security.Authentication.ExtendedProtection.ProtectionScenario", ($self) => class ProtectionScenario extends $.$spc.System.Enum
        {
            static TransportSelected = 0;
            static TrustedProxy = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TransportSelected": 0n,
                    "TrustedProxy": 1n
                };
            }
            static $h = 1675070;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1675070,"n":"TransportSelected","d":1675070,"h":4296642366,"f":33},{"t":1675070,"n":"TrustedProxy","d":1675070,"h":8591609662,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1675070,"h":12886576958,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1675070}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ProtectionScenario`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateStream", ($self) => class NegotiateStream extends $.$snsc.System.Net.Security.AuthenticatedStream
        {
            $ctor$4(/*System.IO.Stream*/ innerStream)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get RemoteIdentity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsClient()
            {
            }
            /*void */ AuthenticateAsClient$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName)
            {
            }
            /*void */ AuthenticateAsClient$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsClient$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName)
            {
            }
            /*void */ AuthenticateAsClient$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsServer()
            {
            }
            /*void */ AuthenticateAsServer$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsServer$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsServer$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient(/*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer(/*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndAuthenticateAsClient(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndAuthenticateAsServer(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 626494;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":102206,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180495678,"f":32769},"n":"CanRead","d":626494,"h":12885528382,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":25770430270,"f":32769},"n":"CanSeek","d":626494,"h":21475462974,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":34360364862,"f":32769},"n":"CanTimeout","d":626494,"h":30065397566,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42950299454,"f":32769},"n":"CanWrite","d":626494,"h":38655332158,"f":32769},{"p":117243905,"g":{"r":0,"d":0,"h":51540234046,"f":129},"n":"ImpersonationLevel","d":626494,"h":47245266750,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":60130168638,"f":32769},"n":"IsAuthenticated","d":626494,"h":55835201342,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":68720103230,"f":32769},"n":"IsEncrypted","d":626494,"h":64425135934,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":77310037822,"f":32769},"n":"IsMutuallyAuthenticated","d":626494,"h":73015070526,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":85899972414,"f":32769},"n":"IsServer","d":626494,"h":81605005118,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":94489907006,"f":32769},"n":"IsSigned","d":626494,"h":90194939710,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":103079841598,"f":32769},"n":"Length","d":626494,"h":98784874302,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":111669776190,"f":32769},"s":{"r":0,"d":0,"h":115964743486,"f":32769},"n":"Position","d":626494,"h":107374808894,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":124554678078,"f":32769},"s":{"r":0,"d":0,"h":128849645374,"f":32769},"n":"ReadTimeout","d":626494,"h":120259710782,"f":32769},{"p":117047297,"g":{"r":0,"d":0,"h":137439579966,"f":129},"n":"RemoteIdentity","d":626494,"h":133144612670,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":146029514558,"f":32769},"s":{"r":0,"d":0,"h":150324481854,"f":32769},"n":"WriteTimeout","d":626494,"h":141734547262,"f":32769}],"m":[{"r":65537,"n":"AuthenticateAsClient","d":626494,"h":154619449150,"f":129},{"r":65537,"p":[{"n":"credential","p":3857222},{"n":"binding","p":5430086},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClient","o":"@$1","d":626494,"h":158914416446,"f":129},{"r":65537,"p":[{"n":"credential","p":3857222},{"n":"binding","p":5430086},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":692030},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClient","o":"@$2","d":626494,"h":163209383742,"f":129},{"r":65537,"p":[{"n":"credential","p":3857222},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClient","o":"@$3","d":626494,"h":167504351038,"f":129},{"r":65537,"p":[{"n":"credential","p":3857222},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":692030},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClient","o":"@$4","d":626494,"h":171799318334,"f":129},{"r":133300225,"n":"AuthenticateAsClientAsync","d":626494,"h":176094285630,"f":129},{"r":133300225,"p":[{"n":"credential","p":3857222},{"n":"binding","p":5430086},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$1","d":626494,"h":180389252926,"f":129},{"r":133300225,"p":[{"n":"credential","p":3857222},{"n":"binding","p":5430086},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":692030},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClientAsync","o":"@$2","d":626494,"h":184684220222,"f":129},{"r":133300225,"p":[{"n":"credential","p":3857222},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$3","d":626494,"h":188979187518,"f":129},{"r":133300225,"p":[{"n":"credential","p":3857222},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":692030},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClientAsync","o":"@$4","d":626494,"h":193274154814,"f":129},{"r":65537,"n":"AuthenticateAsServer","d":626494,"h":197569122110,"f":129},{"r":65537,"p":[{"n":"credential","p":3857222},{"n":"requiredProtectionLevel","p":692030},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServer","o":"@$1","d":626494,"h":201864089406,"f":129},{"r":65537,"p":[{"n":"credential","p":3857222},{"n":"policy","p":1543998},{"n":"requiredProtectionLevel","p":692030},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServer","o":"@$2","d":626494,"h":206159056702,"f":129},{"r":65537,"p":[{"n":"policy","p":1543998}],"n":"AuthenticateAsServer","o":"@$3","d":626494,"h":210454023998,"f":129},{"r":133300225,"n":"AuthenticateAsServerAsync","d":626494,"h":214748991294,"f":129},{"r":133300225,"p":[{"n":"credential","p":3857222},{"n":"requiredProtectionLevel","p":692030},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServerAsync","o":"@$1","d":626494,"h":219043958590,"f":129},{"r":133300225,"p":[{"n":"credential","p":3857222},{"n":"policy","p":1543998},{"n":"requiredProtectionLevel","p":692030},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServerAsync","o":"@$2","d":626494,"h":223338925886,"f":129},{"r":133300225,"p":[{"n":"policy","p":1543998}],"n":"AuthenticateAsServerAsync","o":"@$3","d":626494,"h":227633893182,"f":129},{"r":57016321,"p":[{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","d":626494,"h":231928860478,"f":129},{"r":57016321,"p":[{"n":"credential","p":3857222},{"n":"binding","p":5430086},{"n":"targetName","p":1310721},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$1","d":626494,"h":236223827774,"f":129},{"r":57016321,"p":[{"n":"credential","p":3857222},{"n":"binding","p":5430086},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":692030},{"n":"allowedImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$2","d":626494,"h":240518795070,"f":129},{"r":57016321,"p":[{"n":"credential","p":3857222},{"n":"targetName","p":1310721},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$3","d":626494,"h":244813762366,"f":129},{"r":57016321,"p":[{"n":"credential","p":3857222},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":692030},{"n":"allowedImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$4","d":626494,"h":249108729662,"f":129},{"r":57016321,"p":[{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","d":626494,"h":253403696958,"f":129},{"r":57016321,"p":[{"n":"credential","p":3857222},{"n":"requiredProtectionLevel","p":692030},{"n":"requiredImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$1","d":626494,"h":257698664254,"f":129},{"r":57016321,"p":[{"n":"credential","p":3857222},{"n":"policy","p":1543998},{"n":"requiredProtectionLevel","p":692030},{"n":"requiredImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$2","d":626494,"h":261993631550,"f":129},{"r":57016321,"p":[{"n":"policy","p":1543998},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$3","d":626494,"h":266288598846,"f":129},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginRead","d":626494,"h":270583566142,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":626494,"h":274878533438,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":626494,"h":279173500734,"f":32772},{"r":136118273,"n":"DisposeAsync","d":626494,"h":283468468030,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAuthenticateAsClient","d":626494,"h":287763435326,"f":129},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAuthenticateAsServer","d":626494,"h":292058402622,"f":129},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":626494,"h":296353369918,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":626494,"h":300648337214,"f":32769},{"r":65537,"n":"Flush","d":626494,"h":304943304510,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":626494,"h":309238271806,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":626494,"h":313533239102,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":626494,"h":317828206398,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":626494,"h":322123173694,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":626494,"h":326418140990,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":626494,"h":330713108286,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":626494,"h":335008075582,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":626494,"h":339303042878,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":626494,"h":343598010174,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62193665}],"n":".ctor","o":"$ctor$4","d":626494,"h":4295593790,"f":1},{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":626494,"h":8590561086,"f":1}],"i":[57540609,56950785],"h":626494}; }
            static get $b() { return $.$snsc.System.Net.Security.AuthenticatedStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.NegotiateStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslStream", ($self) => class SslStream extends $.$snsc.System.Net.Security.AuthenticatedStream
        {
            $ctor$4(/*System.IO.Stream*/ innerStream)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$7(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback, /*System.Net.Security.LocalCertificateSelectionCallback?*/ userCertificateSelectionCallback)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$8(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback, /*System.Net.Security.LocalCertificateSelectionCallback?*/ userCertificateSelectionCallback, /*System.Net.Security.EncryptionPolicy*/ encryptionPolicy)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CheckCertRevocationStatus()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.CipherAlgorithmType */ get CipherAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get CipherStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.HashAlgorithmType */ get HashAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get HashStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExchangeAlgorithmType */ get KeyExchangeAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get KeyExchangeStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get LocalCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslApplicationProtocol */ get NegotiatedApplicationProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.TlsCipherSuite */ get NegotiatedCipherSuite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get RemoteCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get TargetHostName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.TransportContext */ get TransportContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsClient(/*System.Net.Security.SslClientAuthenticationOptions*/ sslClientAuthenticationOptions)
            {
            }
            /*void */ AuthenticateAsClient$1(/*string*/ targetHost)
            {
            }
            /*void */ AuthenticateAsClient$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation)
            {
            }
            /*void */ AuthenticateAsClient$3(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync(/*System.Net.Security.SslClientAuthenticationOptions*/ sslClientAuthenticationOptions, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$1(/*string*/ targetHost)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$3(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsServer(/*System.Net.Security.SslServerAuthenticationOptions*/ sslServerAuthenticationOptions)
            {
            }
            /*void */ AuthenticateAsServer$1(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate)
            {
            }
            /*void */ AuthenticateAsServer$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation)
            {
            }
            /*void */ AuthenticateAsServer$3(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync(/*System.Net.Security.ServerOptionsSelectionCallback*/ optionsCallback, /*object?*/ state, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$1(/*System.Net.Security.SslServerAuthenticationOptions*/ sslServerAuthenticationOptions, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$3(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$4(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient(/*string*/ targetHost, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$1(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$1(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndAuthenticateAsClient(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndAuthenticateAsServer(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ NegotiateClientCertificateAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*System.Threading.Tasks.Task */ ShutdownAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Write$2(/*byte[]*/ buffer)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 1281854;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":102206,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30066052926,"f":32769},"n":"CanRead","d":1281854,"h":25771085630,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38655987518,"f":32769},"n":"CanSeek","d":1281854,"h":34361020222,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":47245922110,"f":32769},"n":"CanTimeout","d":1281854,"h":42950954814,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":55835856702,"f":32769},"n":"CanWrite","d":1281854,"h":51540889406,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":64425791294,"f":129},"n":"CheckCertRevocationStatus","d":1281854,"h":60130823998,"f":129},{"p":5299014,"g":{"r":0,"d":0,"h":73015725886,"f":129},"n":"CipherAlgorithm","d":1281854,"h":68720758590,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":81605660478,"f":129},"n":"CipherStrength","d":1281854,"h":77310693182,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":5561158,"g":{"r":0,"d":0,"h":90195595070,"f":129},"n":"HashAlgorithm","d":1281854,"h":85900627774,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":98785529662,"f":129},"n":"HashStrength","d":1281854,"h":94490562366,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":107375464254,"f":32769},"n":"IsAuthenticated","d":1281854,"h":103080496958,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":115965398846,"f":32769},"n":"IsEncrypted","d":1281854,"h":111670431550,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":124555333438,"f":32769},"n":"IsMutuallyAuthenticated","d":1281854,"h":120260366142,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":133145268030,"f":32769},"n":"IsServer","d":1281854,"h":128850300734,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":141735202622,"f":32769},"n":"IsSigned","d":1281854,"h":137440235326,"f":32769},{"p":5364550,"g":{"r":0,"d":0,"h":150325137214,"f":129},"n":"KeyExchangeAlgorithm","d":1281854,"h":146030169918,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":158915071806,"f":129},"n":"KeyExchangeStrength","d":1281854,"h":154620104510,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":167505006398,"f":32769},"n":"Length","d":1281854,"h":163210039102,"f":32769},{"p":28163835,"g":{"r":0,"d":0,"h":176094940990,"f":129},"n":"LocalCertificate","d":1281854,"h":171799973694,"f":129},{"p":954174,"g":{"r":0,"d":0,"h":184684875582,"f":1},"n":"NegotiatedApplicationProtocol","d":1281854,"h":180389908286,"f":1},{"p":1412926,"g":{"r":0,"d":0,"h":193274810174,"f":129},"n":"NegotiatedCipherSuite","d":1281854,"h":188979842878,"f":129,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"p":917505,"g":{"r":0,"d":0,"h":201864744766,"f":32769},"s":{"r":0,"d":0,"h":206159712062,"f":32769},"n":"Position","d":1281854,"h":197569777470,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":214749646654,"f":32769},"s":{"r":0,"d":0,"h":219044613950,"f":32769},"n":"ReadTimeout","d":1281854,"h":210454679358,"f":32769},{"p":28163835,"g":{"r":0,"d":0,"h":227634548542,"f":129},"n":"RemoteCertificate","d":1281854,"h":223339581246,"f":129},{"p":5626694,"g":{"r":0,"d":0,"h":236224483134,"f":129},"n":"SslProtocol","d":1281854,"h":231929515838,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":244814417726,"f":1},"n":"TargetHostName","d":1281854,"h":240519450430,"f":1},{"p":5036870,"g":{"r":0,"d":0,"h":253404352318,"f":1},"n":"TransportContext","d":1281854,"h":249109385022,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":261994286910,"f":32769},"s":{"r":0,"d":0,"h":266289254206,"f":32769},"n":"WriteTimeout","d":1281854,"h":257699319614,"f":32769}],"m":[{"r":65537,"p":[{"n":"sslClientAuthenticationOptions","p":1085246}],"n":"AuthenticateAsClient","d":1281854,"h":270584221502,"f":1},{"r":65537,"p":[{"n":"targetHost","p":1310721}],"n":"AuthenticateAsClient","o":"@$1","d":1281854,"h":274879188798,"f":129},{"r":65537,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28425979},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClient","o":"@$2","d":1281854,"h":279174156094,"f":129},{"r":65537,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28425979},{"n":"enabledSslProtocols","p":5626694},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClient","o":"@$3","d":1281854,"h":283469123390,"f":129},{"r":133300225,"p":[{"n":"sslClientAuthenticationOptions","p":1085246},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsClientAsync","d":1281854,"h":287764090686,"f":1},{"r":133300225,"p":[{"n":"targetHost","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$1","d":1281854,"h":292059057982,"f":129},{"r":133300225,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28425979},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClientAsync","o":"@$2","d":1281854,"h":296354025278,"f":129},{"r":133300225,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28425979},{"n":"enabledSslProtocols","p":5626694},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClientAsync","o":"@$3","d":1281854,"h":300648992574,"f":129},{"r":65537,"p":[{"n":"sslServerAuthenticationOptions","p":1216318}],"n":"AuthenticateAsServer","d":1281854,"h":304943959870,"f":1},{"r":65537,"p":[{"n":"serverCertificate","p":28163835}],"n":"AuthenticateAsServer","o":"@$1","d":1281854,"h":309238927166,"f":129},{"r":65537,"p":[{"n":"serverCertificate","p":28163835},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServer","o":"@$2","d":1281854,"h":313533894462,"f":129},{"r":65537,"p":[{"n":"serverCertificate","p":28163835},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5626694},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServer","o":"@$3","d":1281854,"h":317828861758,"f":129},{"r":133300225,"p":[{"n":"optionsCallback","p":888638},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsServerAsync","d":1281854,"h":322123829054,"f":1},{"r":133300225,"p":[{"n":"sslServerAuthenticationOptions","p":1216318},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsServerAsync","o":"@$1","d":1281854,"h":326418796350,"f":1},{"r":133300225,"p":[{"n":"serverCertificate","p":28163835}],"n":"AuthenticateAsServerAsync","o":"@$2","d":1281854,"h":330713763646,"f":129},{"r":133300225,"p":[{"n":"serverCertificate","p":28163835},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServerAsync","o":"@$3","d":1281854,"h":335008730942,"f":129},{"r":133300225,"p":[{"n":"serverCertificate","p":28163835},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5626694},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServerAsync","o":"@$4","d":1281854,"h":339303698238,"f":129},{"r":57016321,"p":[{"n":"targetHost","p":1310721},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","d":1281854,"h":343598665534,"f":129},{"r":57016321,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28425979},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$1","d":1281854,"h":347893632830,"f":129},{"r":57016321,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28425979},{"n":"enabledSslProtocols","p":5626694},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$2","d":1281854,"h":352188600126,"f":129},{"r":57016321,"p":[{"n":"serverCertificate","p":28163835},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","d":1281854,"h":356483567422,"f":129},{"r":57016321,"p":[{"n":"serverCertificate","p":28163835},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$1","d":1281854,"h":360778534718,"f":129},{"r":57016321,"p":[{"n":"serverCertificate","p":28163835},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5626694},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$2","d":1281854,"h":365073502014,"f":129},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginRead","d":1281854,"h":369368469310,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":1281854,"h":373663436606,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1281854,"h":377958403902,"f":32772},{"r":136118273,"n":"DisposeAsync","d":1281854,"h":382253371198,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAuthenticateAsClient","d":1281854,"h":386548338494,"f":129},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAuthenticateAsServer","d":1281854,"h":390843305790,"f":129},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":1281854,"h":395138273086,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":1281854,"h":399433240382,"f":32769},{"r":65537,"n":"Flush","d":1281854,"h":408023174974,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1281854,"h":412318142270,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"NegotiateClientCertificateAsync","d":1281854,"h":416613109566,"f":129,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1281854,"h":420908076862,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1281854,"h":425203044158,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1281854,"h":429498011454,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1281854,"h":433792978750,"f":32769},{"r":655361,"n":"ReadByte","d":1281854,"h":438087946046,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":1281854,"h":442382913342,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1281854,"h":446677880638,"f":32769},{"r":133300225,"n":"ShutdownAsync","d":1281854,"h":450972847934,"f":129},{"r":65537,"p":[{"n":"buffer","p":0}],"n":"Write","o":"@$2","d":1281854,"h":455267815230,"f":1},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1281854,"h":459562782526,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":1281854,"h":463857749822,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1281854,"h":468152717118,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1281854,"h":472447684414,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":1281854,"h":476742651710,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62193665}],"n":".ctor","o":"$ctor$4","d":1281854,"h":4296249150,"f":1},{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":1281854,"h":8591216446,"f":1},{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":757566}],"n":".ctor","o":"$ctor$6","d":1281854,"h":12886183742,"f":1},{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":757566},{"n":"userCertificateSelectionCallback","p":298814}],"n":".ctor","o":"$ctor$7","d":1281854,"h":17181151038,"f":1},{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":757566},{"n":"userCertificateSelectionCallback","p":298814},{"n":"encryptionPolicy","p":233278}],"n":".ctor","o":"$ctor$8","d":1281854,"h":21476118334,"f":1}],"i":[57540609,56950785],"h":1281854}; }
            static get $b() { return $.$snsc.System.Net.Security.AuthenticatedStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.SslStream`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.AuthenticationException", ($self) => class AuthenticationException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$12(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            static $h = 1478462;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":1478462}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.AuthenticationException`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.InvalidCredentialException", ($self) => class InvalidCredentialException extends $.$snsc.System.Security.Authentication.AuthenticationException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$14(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$16(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            static $h = 1806142;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1478462,"h":1806142}; }
            static get $b() { return $.$snsc.System.Security.Authentication.AuthenticationException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.InvalidCredentialException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography"))