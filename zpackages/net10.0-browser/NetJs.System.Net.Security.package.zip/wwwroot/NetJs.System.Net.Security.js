
//--TRIMMABLE-BOUNDARY-START(50)
(async function () {
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr) {
    "use strict";
    let _;

    
    
    
	$.$asm(
    "NetJs.System.Net.Security", 
    {
  "h": 50,
  "f": "System.Net.Security",
  "v": "1.0.35.0",
  "a": [
    {
      "t": 160038913,
      "c": 13044940801,
      "a": [
        {
          "v": ".NETCoreApp,Version=v10.0",
          "t": 1310721
        }
      ],
      "n": [
        {
          "n": "FrameworkDisplayName",
          "v": ".NET 10.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107151361,
      "c": 8697085953,
      "a": [
        {
          "v": "SIT",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107216897,
      "c": 8697151489,
      "a": [
        {
          "v": "Debug",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107675649,
      "c": 8697610241,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 107806721,
      "c": 8697741313,
      "a": [
        {
          "v": "1.0.35\u002B96771abe2820045936210554b19d0578b9bc2b1c",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108658689,
      "c": 8698593281,
      "a": [
        {
          "v": "NetJs.System.Net.Security",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108789761,
      "c": 8698724353,
      "a": [
        {
          "v": "NetJs.System.Net.Security",
          "t": 1310721
        }
      ]
    },
    {
      "t": 108920833,
      "c": 8698855425,
      "a": [
        {
          "v": "1.0.35.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160104449,
      "c": 4455071745,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    },
    {
      "t": 159842305,
      "c": 4454809601,
      "a": [
        {
          "v": "browser1.0",
          "t": 1310721
        }
      ]
    }
  ],
  "m": []
},
    function($asm)
	{
        
        
        //--TRIMMABLE-BOUNDARY-START(65586)
        $asm.$cls(`$snsc.SNS.AuthenticatedStream`, ($self) => class AuthenticatedStream extends $.$$.SI.Stream
        {
            //--TRIMMABLE-BOUNDARY-START(4295032882)
            $ctor$3(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$2();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295032882);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295032882)
            
            //--TRIMMABLE-BOUNDARY-START(77309476914)
            /*System.IO.Stream */ get InnerStream()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21474902066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77309476914)
            
            //--TRIMMABLE-BOUNDARY-START(103079280690)
            /*bool */ get LeaveInnerStreamOpen()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73014509618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103079280690)
            
            //--TRIMMABLE-BOUNDARY-START(8590000178)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590000178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(8590000178)
            
            //--TRIMMABLE-BOUNDARY-START(12884967474)
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12884967474);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12884967474)
            
            static $h = 65586;
            static $f = 0b110001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.SI.Stream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(77309476914),
    {
      "p": 95748097,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21474902066,
        "f": 50331652
      },
      "n": "InnerStream",
      "d": 65586,
      "h": 77309476914,
      "f": 2097156
    },
//--TRIMMABLE-BOUNDARY-END(77309476914),
//--TRIMMABLE-BOUNDARY-START(81604444210),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30064836658,
        "f": 50331905
      },
      "n": "IsAuthenticated",
      "d": 65586,
      "h": 81604444210,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(81604444210),
//--TRIMMABLE-BOUNDARY-START(85899411506),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38654771250,
        "f": 50331905
      },
      "n": "IsEncrypted",
      "d": 65586,
      "h": 85899411506,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(85899411506),
//--TRIMMABLE-BOUNDARY-START(90194378802),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47244705842,
        "f": 50331905
      },
      "n": "IsMutuallyAuthenticated",
      "d": 65586,
      "h": 90194378802,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(90194378802),
//--TRIMMABLE-BOUNDARY-START(94489346098),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55834640434,
        "f": 50331905
      },
      "n": "IsServer",
      "d": 65586,
      "h": 94489346098,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(94489346098),
//--TRIMMABLE-BOUNDARY-START(98784313394),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424575026,
        "f": 50331905
      },
      "n": "IsSigned",
      "d": 65586,
      "h": 98784313394,
      "f": 2097409
    },
//--TRIMMABLE-BOUNDARY-END(98784313394),
//--TRIMMABLE-BOUNDARY-START(103079280690),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73014509618,
        "f": 50331649
      },
      "n": "LeaveInnerStreamOpen",
      "d": 65586,
      "h": 103079280690,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(103079280690)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590000178),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 65586,
      "h": 8590000178,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(8590000178),
//--TRIMMABLE-BOUNDARY-START(12884967474),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 65586,
      "h": 12884967474,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(12884967474)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295032882),
    {
      "p": [
        {
          "n": "innerStream",
          "p": 95748097
        },
        {
          "n": "leaveInnerStreamOpen",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 65586,
      "h": 4295032882,
      "f": 16777220
    },
//--TRIMMABLE-BOUNDARY-END(4295032882)
  ],
  "h": 65586
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.AuthenticatedStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}AuthenticatedStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(65586)
        
        

        //--TRIMMABLE-BOUNDARY-START(131122)
        $asm.$cls(`$snsc.SNS.CipherSuitesPolicy`, ($self) => class CipherSuitesPolicy extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295098418)
            $ctor$1(/*System.Collections.Generic.IEnumerable<System.Net.Security.TlsCipherSuite>*/ allowedCipherSuites)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295098418);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295098418)
            
            //--TRIMMABLE-BOUNDARY-START(8590065714)
            /*System.Collections.Generic.IEnumerable<System.Net.Security.TlsCipherSuite> */ get AllowedCipherSuites()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180000306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590065714)
            
            static $h = 131122;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590065714),
    {
      "p": $.$$.SCG.IEnumerable$$($.$snsc.SNS.TlsCipherSuite).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 17180000306,
        "f": 50331649
      },
      "n": "AllowedCipherSuites",
      "d": 131122,
      "h": 8590065714,
      "f": 2097153,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590065714)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295098418),
    {
      "p": [
        {
          "n": "allowedCipherSuites",
          "p": $.$$.SCG.IEnumerable$$($.$snsc.SNS.TlsCipherSuite).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 131122,
      "h": 4295098418,
      "f": 16777217,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4295098418)
  ],
  "h": 131122,
  "a": [
    {
      "t": 160169985,
      "c": 13045071873,
      "a": [
        {
          "v": "android",
          "t": 1310721
        }
      ]
    },
    {
      "t": 160169985,
      "c": 13045071873,
      "a": [
        {
          "v": "windows",
          "t": 1310721
        }
      ]
    }
  ]
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.CipherSuitesPolicy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}CipherSuitesPolicy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(131122)
        
        

        //--TRIMMABLE-BOUNDARY-START(393266)
        $asm.$cls(`$snsc.SNS.NegotiateAuthenticationClientOptions`, ($self) => class NegotiateAuthenticationClientOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295360562)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295360562);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295360562)
            
            //--TRIMMABLE-BOUNDARY-START(8590327858)
            /*System.Security.Principal.TokenImpersonationLevel */ get AllowedImpersonationLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770197042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set AllowedImpersonationLevel(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784641074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590327858)
            
            //--TRIMMABLE-BOUNDARY-START(12885295154)
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get Binding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360131634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ set Binding(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374575666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885295154)
            
            //--TRIMMABLE-BOUNDARY-START(17180262450)
            /*System.Net.NetworkCredential */ get Credential()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950066226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ set Credential(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964510258);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180262450)
            
            //--TRIMMABLE-BOUNDARY-START(81604771890)
            /*string */ get Package()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540000818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Package(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554444850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81604771890)
            
            //--TRIMMABLE-BOUNDARY-START(85899739186)
            /*System.Net.Security.ProtectionLevel */ get RequiredProtectionLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129935410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ set RequiredProtectionLevel(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144379442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(85899739186)
            
            //--TRIMMABLE-BOUNDARY-START(90194706482)
            /*bool */ get RequireMutualAuthentication()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719870002);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RequireMutualAuthentication(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734314034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90194706482)
            
            //--TRIMMABLE-BOUNDARY-START(154619215922)
            /*string? */ get TargetName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309804594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TargetName(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324248626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(154619215922)
            
            //--TRIMMABLE-BOUNDARY-START(4295360562)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295360562)
            
            static $h = 393266;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590327858),
    {
      "p": 162136065,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770197042,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784641074,
        "f": 83886081
      },
      "n": "AllowedImpersonationLevel",
      "d": 393266,
      "h": 8590327858,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590327858),
//--TRIMMABLE-BOUNDARY-START(12885295154),
    {
      "p": 5373999,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360131634,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374575666,
        "f": 83886081
      },
      "n": "Binding",
      "d": 393266,
      "h": 12885295154,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885295154),
//--TRIMMABLE-BOUNDARY-START(17180262450),
    {
      "p": 3801135,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950066226,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964510258,
        "f": 83886081
      },
      "n": "Credential",
      "d": 393266,
      "h": 17180262450,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180262450),
//--TRIMMABLE-BOUNDARY-START(81604771890),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51540000818,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554444850,
        "f": 83886081
      },
      "n": "Package",
      "d": 393266,
      "h": 81604771890,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604771890),
//--TRIMMABLE-BOUNDARY-START(85899739186),
    {
      "p": 655410,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129935410,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144379442,
        "f": 83886081
      },
      "n": "RequiredProtectionLevel",
      "d": 393266,
      "h": 85899739186,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85899739186),
//--TRIMMABLE-BOUNDARY-START(90194706482),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719870002,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 141734314034,
        "f": 83886081
      },
      "n": "RequireMutualAuthentication",
      "d": 393266,
      "h": 90194706482,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(90194706482),
//--TRIMMABLE-BOUNDARY-START(154619215922),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309804594,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 150324248626,
        "f": 83886081
      },
      "n": "TargetName",
      "d": 393266,
      "h": 154619215922,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619215922)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295360562),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 393266,
      "h": 4295360562,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295360562)
  ],
  "h": 393266
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.NegotiateAuthenticationClientOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}NegotiateAuthenticationClientOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(393266)
        
        

        //--TRIMMABLE-BOUNDARY-START(458802)
        $asm.$cls(`$snsc.SNS.NegotiateAuthenticationServerOptions`, ($self) => class NegotiateAuthenticationServerOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295426098)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295426098);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295426098)
            
            //--TRIMMABLE-BOUNDARY-START(8590393394)
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get Binding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475295282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ set Binding(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194772018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590393394)
            
            //--TRIMMABLE-BOUNDARY-START(12885360690)
            /*System.Net.NetworkCredential */ get Credential()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065229874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ set Credential(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784706610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885360690)
            
            //--TRIMMABLE-BOUNDARY-START(68719935538)
            /*string */ get Package()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655164466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Package(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374641202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68719935538)
            
            //--TRIMMABLE-BOUNDARY-START(73014902834)
            /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy? */ get Policy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245099058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy? */ set Policy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964575794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73014902834)
            
            //--TRIMMABLE-BOUNDARY-START(77309870130)
            /*System.Security.Principal.TokenImpersonationLevel */ get RequiredImpersonationLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835033650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set RequiredImpersonationLevel(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554510386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77309870130)
            
            //--TRIMMABLE-BOUNDARY-START(81604837426)
            /*System.Net.Security.ProtectionLevel */ get RequiredProtectionLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64424968242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ set RequiredProtectionLevel(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144444978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81604837426)
            
            //--TRIMMABLE-BOUNDARY-START(4295426098)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295426098)
            
            static $h = 458802;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590393394),
    {
      "p": 5373999,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21475295282,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 90194772018,
        "f": 83886081
      },
      "n": "Binding",
      "d": 458802,
      "h": 8590393394,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590393394),
//--TRIMMABLE-BOUNDARY-START(12885360690),
    {
      "p": 3801135,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30065229874,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 98784706610,
        "f": 83886081
      },
      "n": "Credential",
      "d": 458802,
      "h": 12885360690,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885360690),
//--TRIMMABLE-BOUNDARY-START(68719935538),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655164466,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 107374641202,
        "f": 83886081
      },
      "n": "Package",
      "d": 458802,
      "h": 68719935538,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68719935538),
//--TRIMMABLE-BOUNDARY-START(73014902834),
    {
      "p": 1507378,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47245099058,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 115964575794,
        "f": 83886081
      },
      "n": "Policy",
      "d": 458802,
      "h": 73014902834,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(73014902834),
//--TRIMMABLE-BOUNDARY-START(77309870130),
    {
      "p": 162136065,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55835033650,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 124554510386,
        "f": 83886081
      },
      "n": "RequiredImpersonationLevel",
      "d": 458802,
      "h": 77309870130,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(77309870130),
//--TRIMMABLE-BOUNDARY-START(81604837426),
    {
      "p": 655410,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64424968242,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 133144444978,
        "f": 83886081
      },
      "n": "RequiredProtectionLevel",
      "d": 458802,
      "h": 81604837426,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81604837426)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295426098),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 458802,
      "h": 4295426098,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295426098)
  ],
  "h": 458802
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.NegotiateAuthenticationServerOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}NegotiateAuthenticationServerOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(458802)
        
        

        //--TRIMMABLE-BOUNDARY-START(983090)
        $asm.$cls(`$snsc.SNS.SslCertificateTrust`, ($self) => class SslCertificateTrust extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295950386)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295950386);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295950386)
            
            //--TRIMMABLE-BOUNDARY-START(8590917682)
            static /*System.Net.Security.SslCertificateTrust */ CreateForX509Collection(/*System.Security.Cryptography.X509Certificates.X509Certificate2Collection*/ trustList, /*bool*/ sendTrustInHandshake)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8590917682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590917682)
            
            //--TRIMMABLE-BOUNDARY-START(12885884978)
            static /*System.Net.Security.SslCertificateTrust */ CreateForX509Store(/*System.Security.Cryptography.X509Certificates.X509Store*/ store, /*bool*/ sendTrustInHandshake)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885884978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885884978)
            
            //--TRIMMABLE-BOUNDARY-START(4295950386)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4295950386)
            
            static $h = 983090;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8590917682),
    {
      "r": 983090,
      "p": [
        {
          "n": "trustList",
          "p": 28246046
        },
        {
          "n": "sendTrustInHandshake",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "CreateForX509Collection",
      "d": 983090,
      "h": 8590917682,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8590917682),
//--TRIMMABLE-BOUNDARY-START(12885884978),
    {
      "r": 983090,
      "p": [
        {
          "n": "store",
          "p": 30408734
        },
        {
          "n": "sendTrustInHandshake",
          "p": 262145,
          "f": 65,
          "v": false
        }
      ],
      "n": "CreateForX509Store",
      "d": 983090,
      "h": 12885884978,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(12885884978)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295950386),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 983090,
      "h": 4295950386,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4295950386)
  ],
  "h": 983090
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.SslCertificateTrust`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}SslCertificateTrust`; }
        });
        //--TRIMMABLE-BOUNDARY-END(983090)
        
        

        //--TRIMMABLE-BOUNDARY-START(1048626)
        $asm.$cls(`$snsc.SNS.SslClientAuthenticationOptions`, ($self) => class SslClientAuthenticationOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296015922)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296015922);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296015922)
            
            //--TRIMMABLE-BOUNDARY-START(8590983218)
            /*bool */ get AllowRenegotiation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425558066);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRenegotiation(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864511538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8590983218)
            
            //--TRIMMABLE-BOUNDARY-START(12885950514)
            /*bool */ get AllowRsaPkcs1Padding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015492658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPkcs1Padding(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210454446130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12885950514)
            
            //--TRIMMABLE-BOUNDARY-START(17180917810)
            /*bool */ get AllowRsaPssPadding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605427250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPssPadding(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219044380722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17180917810)
            
            //--TRIMMABLE-BOUNDARY-START(21475885106)
            /*bool */ get AllowTlsResume()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195361842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowTlsResume(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227634315314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21475885106)
            
            //--TRIMMABLE-BOUNDARY-START(25770852402)
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ get ApplicationProtocols()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785296434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ set ApplicationProtocols(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236224249906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770852402)
            
            //--TRIMMABLE-BOUNDARY-START(30065819698)
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ get CertificateChainPolicy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375231026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ set CertificateChainPolicy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244814184498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065819698)
            
            //--TRIMMABLE-BOUNDARY-START(34360786994)
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ get CertificateRevocationCheckMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965165618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ set CertificateRevocationCheckMode(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253404119090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360786994)
            
            //--TRIMMABLE-BOUNDARY-START(38655754290)
            /*System.Net.Security.CipherSuitesPolicy? */ get CipherSuitesPolicy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555100210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ set CipherSuitesPolicy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261994053682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655754290)
            
            //--TRIMMABLE-BOUNDARY-START(42950721586)
            /*System.Net.Security.SslStreamCertificateContext? */ get ClientCertificateContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133145034802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ set ClientCertificateContext(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583988274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950721586)
            
            //--TRIMMABLE-BOUNDARY-START(47245688882)
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection? */ get ClientCertificates()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(141734969394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection? */ set ClientCertificates(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173922866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245688882)
            
            //--TRIMMABLE-BOUNDARY-START(51540656178)
            /*System.Security.Authentication.SslProtocols */ get EnabledSslProtocols()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(150324903986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ set EnabledSslProtocols(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763857458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51540656178)
            
            //--TRIMMABLE-BOUNDARY-START(55835623474)
            /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914838578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ set EncryptionPolicy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353792050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55835623474)
            
            //--TRIMMABLE-BOUNDARY-START(188979609650)
            /*System.Net.Security.LocalCertificateSelectionCallback? */ get LocalCertificateSelectionCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504773170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.LocalCertificateSelectionCallback? */ set LocalCertificateSelectionCallback(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943726642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(188979609650)
            
            //--TRIMMABLE-BOUNDARY-START(193274576946)
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get RemoteCertificateValidationCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094707762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set RemoteCertificateValidationCallback(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533661234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(193274576946)
            
            //--TRIMMABLE-BOUNDARY-START(326418563122)
            /*string? */ get TargetHost()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684642354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TargetHost(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(322123595826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(326418563122)
            
            //--TRIMMABLE-BOUNDARY-START(4296015922)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296015922)
            
            static $h = 1048626;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8590983218),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64425558066,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 201864511538,
        "f": 83886081
      },
      "n": "AllowRenegotiation",
      "d": 1048626,
      "h": 8590983218,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8590983218),
//--TRIMMABLE-BOUNDARY-START(12885950514),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015492658,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 210454446130,
        "f": 83886081,
        "a": [
          {
            "t": 159842305,
            "c": 4454809601,
            "a": [
              {
                "v": "linux",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159842305,
            "c": 4454809601,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "AllowRsaPkcs1Padding",
      "d": 1048626,
      "h": 12885950514,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12885950514),
//--TRIMMABLE-BOUNDARY-START(17180917810),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 81605427250,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 219044380722,
        "f": 83886081,
        "a": [
          {
            "t": 159842305,
            "c": 4454809601,
            "a": [
              {
                "v": "linux",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159842305,
            "c": 4454809601,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "AllowRsaPssPadding",
      "d": 1048626,
      "h": 17180917810,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17180917810),
//--TRIMMABLE-BOUNDARY-START(21475885106),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 90195361842,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 227634315314,
        "f": 83886081
      },
      "n": "AllowTlsResume",
      "d": 1048626,
      "h": 21475885106,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21475885106),
//--TRIMMABLE-BOUNDARY-START(25770852402),
    {
      "p": $.$$.SCG.List$$($.$snsc.SNS.SslApplicationProtocol).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 98785296434,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 236224249906,
        "f": 83886081
      },
      "n": "ApplicationProtocols",
      "d": 1048626,
      "h": 25770852402,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770852402),
//--TRIMMABLE-BOUNDARY-START(30065819698),
    {
      "p": 29098014,
      "g": {
        "r": 0,
        "d": 0,
        "h": 107375231026,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 244814184498,
        "f": 83886081
      },
      "n": "CertificateChainPolicy",
      "d": 1048626,
      "h": 30065819698,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065819698),
//--TRIMMABLE-BOUNDARY-START(34360786994),
    {
      "p": 30212126,
      "g": {
        "r": 0,
        "d": 0,
        "h": 115965165618,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 253404119090,
        "f": 83886081
      },
      "n": "CertificateRevocationCheckMode",
      "d": 1048626,
      "h": 34360786994,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360786994),
//--TRIMMABLE-BOUNDARY-START(38655754290),
    {
      "p": 131122,
      "g": {
        "r": 0,
        "d": 0,
        "h": 124555100210,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 261994053682,
        "f": 83886081
      },
      "n": "CipherSuitesPolicy",
      "d": 1048626,
      "h": 38655754290,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655754290),
//--TRIMMABLE-BOUNDARY-START(42950721586),
    {
      "p": 1310770,
      "g": {
        "r": 0,
        "d": 0,
        "h": 133145034802,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 270583988274,
        "f": 83886081
      },
      "n": "ClientCertificateContext",
      "d": 1048626,
      "h": 42950721586,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950721586),
//--TRIMMABLE-BOUNDARY-START(47245688882),
    {
      "p": 28377118,
      "g": {
        "r": 0,
        "d": 0,
        "h": 141734969394,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 279173922866,
        "f": 83886081
      },
      "n": "ClientCertificates",
      "d": 1048626,
      "h": 47245688882,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245688882),
//--TRIMMABLE-BOUNDARY-START(51540656178),
    {
      "p": 5570607,
      "g": {
        "r": 0,
        "d": 0,
        "h": 150324903986,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 287763857458,
        "f": 83886081
      },
      "n": "EnabledSslProtocols",
      "d": 1048626,
      "h": 51540656178,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540656178),
//--TRIMMABLE-BOUNDARY-START(55835623474),
    {
      "p": 196658,
      "g": {
        "r": 0,
        "d": 0,
        "h": 158914838578,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 296353792050,
        "f": 83886081
      },
      "n": "EncryptionPolicy",
      "d": 1048626,
      "h": 55835623474,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(55835623474),
//--TRIMMABLE-BOUNDARY-START(188979609650),
    {
      "p": 262194,
      "g": {
        "r": 0,
        "d": 0,
        "h": 167504773170,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 304943726642,
        "f": 83886081
      },
      "n": "LocalCertificateSelectionCallback",
      "d": 1048626,
      "h": 188979609650,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188979609650),
//--TRIMMABLE-BOUNDARY-START(193274576946),
    {
      "p": 720946,
      "g": {
        "r": 0,
        "d": 0,
        "h": 176094707762,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 313533661234,
        "f": 83886081
      },
      "n": "RemoteCertificateValidationCallback",
      "d": 1048626,
      "h": 193274576946,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274576946),
//--TRIMMABLE-BOUNDARY-START(326418563122),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 184684642354,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 322123595826,
        "f": 83886081
      },
      "n": "TargetHost",
      "d": 1048626,
      "h": 326418563122,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(326418563122)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296015922),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1048626,
      "h": 4296015922,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296015922)
  ],
  "h": 1048626
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.SslClientAuthenticationOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}SslClientAuthenticationOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1048626)
        
        

        //--TRIMMABLE-BOUNDARY-START(1179698)
        $asm.$cls(`$snsc.SNS.SslServerAuthenticationOptions`, ($self) => class SslServerAuthenticationOptions extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296146994)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296146994);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296146994)
            
            //--TRIMMABLE-BOUNDARY-START(8591114290)
            /*bool */ get AllowRenegotiation()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130721842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRenegotiation(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159609906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8591114290)
            
            //--TRIMMABLE-BOUNDARY-START(12886081586)
            /*bool */ get AllowRsaPkcs1Padding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720656434);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPkcs1Padding(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749544498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12886081586)
            
            //--TRIMMABLE-BOUNDARY-START(17181048882)
            /*bool */ get AllowRsaPssPadding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310591026);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPssPadding(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339479090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17181048882)
            
            //--TRIMMABLE-BOUNDARY-START(21476016178)
            /*bool */ get AllowTlsResume()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900525618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowTlsResume(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929413682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(21476016178)
            
            //--TRIMMABLE-BOUNDARY-START(25770983474)
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ get ApplicationProtocols()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490460210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ set ApplicationProtocols(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519348274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770983474)
            
            //--TRIMMABLE-BOUNDARY-START(30065950770)
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ get CertificateChainPolicy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080394802);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ set CertificateChainPolicy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109282866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065950770)
            
            //--TRIMMABLE-BOUNDARY-START(34360918066)
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ get CertificateRevocationCheckMode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670329394);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ set CertificateRevocationCheckMode(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699217458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360918066)
            
            //--TRIMMABLE-BOUNDARY-START(38655885362)
            /*System.Net.Security.CipherSuitesPolicy? */ get CipherSuitesPolicy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260263986);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ set CipherSuitesPolicy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289152050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655885362)
            
            //--TRIMMABLE-BOUNDARY-START(42950852658)
            /*bool */ get ClientCertificateRequired()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850198578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ClientCertificateRequired(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879086642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950852658)
            
            //--TRIMMABLE-BOUNDARY-START(47245819954)
            /*System.Security.Authentication.SslProtocols */ get EnabledSslProtocols()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(137440133170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ set EnabledSslProtocols(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469021234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245819954)
            
            //--TRIMMABLE-BOUNDARY-START(51540787250)
            /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(146030067762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ set EncryptionPolicy(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292058955826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51540787250)
            
            //--TRIMMABLE-BOUNDARY-START(184684773426)
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get RemoteCertificateValidationCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154620002354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set RemoteCertificateValidationCallback(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648890418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(184684773426)
            
            //--TRIMMABLE-BOUNDARY-START(188979740722)
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get ServerCertificate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209936946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ set ServerCertificate(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238825010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(188979740722)
            
            //--TRIMMABLE-BOUNDARY-START(193274708018)
            /*System.Net.Security.SslStreamCertificateContext? */ get ServerCertificateContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799871538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ set ServerCertificateContext(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828759602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(193274708018)
            
            //--TRIMMABLE-BOUNDARY-START(197569675314)
            /*System.Net.Security.ServerCertificateSelectionCallback? */ get ServerCertificateSelectionCallback()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389806130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ServerCertificateSelectionCallback? */ set ServerCertificateSelectionCallback(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418694194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(197569675314)
            
            //--TRIMMABLE-BOUNDARY-START(4296146994)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296146994)
            
            static $h = 1179698;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(8591114290),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60130721842,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 206159609906,
        "f": 83886081
      },
      "n": "AllowRenegotiation",
      "d": 1179698,
      "h": 8591114290,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(8591114290),
//--TRIMMABLE-BOUNDARY-START(12886081586),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68720656434,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 214749544498,
        "f": 83886081,
        "a": [
          {
            "t": 159842305,
            "c": 4454809601,
            "a": [
              {
                "v": "linux",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159842305,
            "c": 4454809601,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "AllowRsaPkcs1Padding",
      "d": 1179698,
      "h": 12886081586,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(12886081586),
//--TRIMMABLE-BOUNDARY-START(17181048882),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77310591026,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 223339479090,
        "f": 83886081,
        "a": [
          {
            "t": 159842305,
            "c": 4454809601,
            "a": [
              {
                "v": "linux",
                "t": 1310721
              }
            ]
          },
          {
            "t": 159842305,
            "c": 4454809601,
            "a": [
              {
                "v": "windows",
                "t": 1310721
              }
            ]
          }
        ]
      },
      "n": "AllowRsaPssPadding",
      "d": 1179698,
      "h": 17181048882,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(17181048882),
//--TRIMMABLE-BOUNDARY-START(21476016178),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85900525618,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 231929413682,
        "f": 83886081
      },
      "n": "AllowTlsResume",
      "d": 1179698,
      "h": 21476016178,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(21476016178),
//--TRIMMABLE-BOUNDARY-START(25770983474),
    {
      "p": $.$$.SCG.List$$($.$snsc.SNS.SslApplicationProtocol).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94490460210,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 240519348274,
        "f": 83886081
      },
      "n": "ApplicationProtocols",
      "d": 1179698,
      "h": 25770983474,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25770983474),
//--TRIMMABLE-BOUNDARY-START(30065950770),
    {
      "p": 29098014,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103080394802,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 249109282866,
        "f": 83886081
      },
      "n": "CertificateChainPolicy",
      "d": 1179698,
      "h": 30065950770,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30065950770),
//--TRIMMABLE-BOUNDARY-START(34360918066),
    {
      "p": 30212126,
      "g": {
        "r": 0,
        "d": 0,
        "h": 111670329394,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 257699217458,
        "f": 83886081
      },
      "n": "CertificateRevocationCheckMode",
      "d": 1179698,
      "h": 34360918066,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34360918066),
//--TRIMMABLE-BOUNDARY-START(38655885362),
    {
      "p": 131122,
      "g": {
        "r": 0,
        "d": 0,
        "h": 120260263986,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 266289152050,
        "f": 83886081
      },
      "n": "CipherSuitesPolicy",
      "d": 1179698,
      "h": 38655885362,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655885362),
//--TRIMMABLE-BOUNDARY-START(42950852658),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 128850198578,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 274879086642,
        "f": 83886081
      },
      "n": "ClientCertificateRequired",
      "d": 1179698,
      "h": 42950852658,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950852658),
//--TRIMMABLE-BOUNDARY-START(47245819954),
    {
      "p": 5570607,
      "g": {
        "r": 0,
        "d": 0,
        "h": 137440133170,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 283469021234,
        "f": 83886081
      },
      "n": "EnabledSslProtocols",
      "d": 1179698,
      "h": 47245819954,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(47245819954),
//--TRIMMABLE-BOUNDARY-START(51540787250),
    {
      "p": 196658,
      "g": {
        "r": 0,
        "d": 0,
        "h": 146030067762,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 292058955826,
        "f": 83886081
      },
      "n": "EncryptionPolicy",
      "d": 1179698,
      "h": 51540787250,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(51540787250),
//--TRIMMABLE-BOUNDARY-START(184684773426),
    {
      "p": 720946,
      "g": {
        "r": 0,
        "d": 0,
        "h": 154620002354,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 300648890418,
        "f": 83886081
      },
      "n": "RemoteCertificateValidationCallback",
      "d": 1179698,
      "h": 184684773426,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(184684773426),
//--TRIMMABLE-BOUNDARY-START(188979740722),
    {
      "p": 28114974,
      "g": {
        "r": 0,
        "d": 0,
        "h": 163209936946,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 309238825010,
        "f": 83886081
      },
      "n": "ServerCertificate",
      "d": 1179698,
      "h": 188979740722,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(188979740722),
//--TRIMMABLE-BOUNDARY-START(193274708018),
    {
      "p": 1310770,
      "g": {
        "r": 0,
        "d": 0,
        "h": 171799871538,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 317828759602,
        "f": 83886081
      },
      "n": "ServerCertificateContext",
      "d": 1179698,
      "h": 193274708018,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(193274708018),
//--TRIMMABLE-BOUNDARY-START(197569675314),
    {
      "p": 786482,
      "g": {
        "r": 0,
        "d": 0,
        "h": 180389806130,
        "f": 50331649
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 326418694194,
        "f": 83886081
      },
      "n": "ServerCertificateSelectionCallback",
      "d": 1179698,
      "h": 197569675314,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(197569675314)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296146994),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1179698,
      "h": 4296146994,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296146994)
  ],
  "h": 1179698
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.SslServerAuthenticationOptions`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}SslServerAuthenticationOptions`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1179698)
        
        

        //--TRIMMABLE-BOUNDARY-START(1310770)
        $asm.$cls(`$snsc.SNS.SslStreamCertificateContext`, ($self) => class SslStreamCertificateContext extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296278066)
            $ctor$1()
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296278066);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296278066)
            
            //--TRIMMABLE-BOUNDARY-START(34361049138)
            /*System.Collections.ObjectModel.ReadOnlyCollection<System.Security.Cryptography.X509Certificates.X509Certificate2> */ get IntermediateCertificates()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21476147250);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34361049138)
            
            //--TRIMMABLE-BOUNDARY-START(38656016434)
            /*System.Security.Cryptography.X509Certificates.X509Certificate2 */ get TargetCertificate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066081842);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38656016434)
            
            //--TRIMMABLE-BOUNDARY-START(12886212658)
            static /*System.Net.Security.SslStreamCertificateContext */ Create$1(/*System.Security.Cryptography.X509Certificates.X509Certificate2*/ target, /*System.Security.Cryptography.X509Certificates.X509Certificate2Collection?*/ additionalCertificates, /*bool*/ offline)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886212658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12886212658)
            
            //--TRIMMABLE-BOUNDARY-START(8591245362)
            static /*System.Net.Security.SslStreamCertificateContext */ Create(/*System.Security.Cryptography.X509Certificates.X509Certificate2*/ target, /*System.Security.Cryptography.X509Certificates.X509Certificate2Collection?*/ additionalCertificates, /*bool*/ offline, /*System.Net.Security.SslCertificateTrust?*/ trust)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591245362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8591245362)
            
            //--TRIMMABLE-BOUNDARY-START(4296278066)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$1();
            }
            //--TRIMMABLE-BOUNDARY-END(4296278066)
            
            static $h = 1310770;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(34361049138),
    {
      "p": $.$$.SCO.ReadOnlyCollection$$($.$sscr.SSCX.X509Certificate2).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 21476147250,
        "f": 50331649
      },
      "n": "IntermediateCertificates",
      "d": 1310770,
      "h": 34361049138,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(34361049138),
//--TRIMMABLE-BOUNDARY-START(38656016434),
    {
      "p": 28180510,
      "g": {
        "r": 0,
        "d": 0,
        "h": 30066081842,
        "f": 50331649
      },
      "n": "TargetCertificate",
      "d": 1310770,
      "h": 38656016434,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38656016434)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12886212658),
    {
      "r": 1310770,
      "p": [
        {
          "n": "target",
          "p": 28180510
        },
        {
          "n": "additionalCertificates",
          "p": 28246046
        },
        {
          "n": "offline",
          "p": 262145
        }
      ],
      "n": "Create",
      "o": "@$1",
      "d": 1310770,
      "h": 12886212658,
      "f": 16777249,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12886212658),
//--TRIMMABLE-BOUNDARY-START(8591245362),
    {
      "r": 1310770,
      "p": [
        {
          "n": "target",
          "p": 28180510
        },
        {
          "n": "additionalCertificates",
          "p": 28246046
        },
        {
          "n": "offline",
          "p": 262145,
          "f": 65,
          "v": false
        },
        {
          "n": "trust",
          "p": 983090,
          "f": 65
        }
      ],
      "n": "Create",
      "d": 1310770,
      "h": 8591245362,
      "f": 16777249
    },
//--TRIMMABLE-BOUNDARY-END(8591245362)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296278066),
    {
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1310770,
      "h": 4296278066,
      "f": 16777224
    },
//--TRIMMABLE-BOUNDARY-END(4296278066)
  ],
  "h": 1310770
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.SslStreamCertificateContext`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}SslStreamCertificateContext`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1310770)
        
        

        //--TRIMMABLE-BOUNDARY-START(327730)
        $asm.$cls(`$snsc.SNS.NegotiateAuthentication`, ($self) => class NegotiateAuthentication extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4295295026)
            $ctor$1(/*System.Net.Security.NegotiateAuthenticationClientOptions*/ clientOptions)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295295026);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295295026)
            
            //--TRIMMABLE-BOUNDARY-START(8590262322)
            $ctor$2(/*System.Net.Security.NegotiateAuthenticationServerOptions*/ serverOptions)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590262322);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590262322)
            
            //--TRIMMABLE-BOUNDARY-START(115964444722)
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770131506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115964444722)
            
            //--TRIMMABLE-BOUNDARY-START(120259412018)
            /*bool */ get IsAuthenticated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360066098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120259412018)
            
            //--TRIMMABLE-BOUNDARY-START(124554379314)
            /*bool */ get IsEncrypted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950000690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(124554379314)
            
            //--TRIMMABLE-BOUNDARY-START(128849346610)
            /*bool */ get IsMutuallyAuthenticated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51539935282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(128849346610)
            
            //--TRIMMABLE-BOUNDARY-START(133144313906)
            /*bool */ get IsServer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60129869874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(133144313906)
            
            //--TRIMMABLE-BOUNDARY-START(137439281202)
            /*bool */ get IsSigned()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68719804466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(137439281202)
            
            //--TRIMMABLE-BOUNDARY-START(141734248498)
            /*string */ get Package()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77309739058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(141734248498)
            
            //--TRIMMABLE-BOUNDARY-START(146029215794)
            /*System.Net.Security.ProtectionLevel */ get ProtectionLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899673650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(146029215794)
            
            //--TRIMMABLE-BOUNDARY-START(150324183090)
            /*System.Security.Principal.IIdentity */ get RemoteIdentity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489608242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(150324183090)
            
            //--TRIMMABLE-BOUNDARY-START(154619150386)
            /*string? */ get TargetName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079542834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(154619150386)
            
            //--TRIMMABLE-BOUNDARY-START(12885229618)
            /*void */ ComputeIntegrityCheck(/*System.ReadOnlySpan<byte>*/ message, /*System.Buffers.IBufferWriter<byte>*/ signatureWriter)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885229618);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12885229618)
            
            //--TRIMMABLE-BOUNDARY-START(17180196914)
            /*void */ Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180196914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17180196914)
            
            //--TRIMMABLE-BOUNDARY-START(107374510130)
            /*byte[]? */ GetOutgoingBlob(/*System.ReadOnlySpan<byte>*/ incomingBlob, /*out System.Net.Security.NegotiateAuthenticationStatusCode*/ statusCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374510130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(107374510130)
            
            //--TRIMMABLE-BOUNDARY-START(111669477426)
            /*string? */ GetOutgoingBlob$1(/*string?*/ incomingBlob, /*out System.Net.Security.NegotiateAuthenticationStatusCode*/ statusCode)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669477426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(111669477426)
            
            //--TRIMMABLE-BOUNDARY-START(158914117682)
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ Unwrap(/*System.ReadOnlySpan<byte>*/ input, /*System.Buffers.IBufferWriter<byte>*/ outputWriter, /*out bool*/ wasEncrypted)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914117682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(158914117682)
            
            //--TRIMMABLE-BOUNDARY-START(163209084978)
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ UnwrapInPlace(/*System.Span<byte>*/ input, /*out int*/ unwrappedOffset, /*out int*/ unwrappedLength, /*out bool*/ wasEncrypted)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209084978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(163209084978)
            
            //--TRIMMABLE-BOUNDARY-START(167504052274)
            /*bool */ VerifyIntegrityCheck(/*System.ReadOnlySpan<byte>*/ message, /*System.ReadOnlySpan<byte>*/ signature)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504052274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(167504052274)
            
            //--TRIMMABLE-BOUNDARY-START(171799019570)
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ Wrap(/*System.ReadOnlySpan<byte>*/ input, /*System.Buffers.IBufferWriter<byte>*/ outputWriter, /*bool*/ requestEncryption, /*out bool*/ isEncrypted)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799019570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(171799019570)
            
            //--TRIMMABLE-BOUNDARY-START(4386062337)
            //Generated interface implemetation for System.IDisposable.Dispose()
            S$IDisposable$Dispose()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386062337);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Dispose(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386062337)
            
            static $h = 327730;
            static $f = 0b10010001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(115964444722),
    {
      "p": 162136065,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770131506,
        "f": 50331649
      },
      "n": "ImpersonationLevel",
      "d": 327730,
      "h": 115964444722,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(115964444722),
//--TRIMMABLE-BOUNDARY-START(120259412018),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360066098,
        "f": 50331649
      },
      "n": "IsAuthenticated",
      "d": 327730,
      "h": 120259412018,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(120259412018),
//--TRIMMABLE-BOUNDARY-START(124554379314),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 42950000690,
        "f": 50331649
      },
      "n": "IsEncrypted",
      "d": 327730,
      "h": 124554379314,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(124554379314),
//--TRIMMABLE-BOUNDARY-START(128849346610),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 51539935282,
        "f": 50331649
      },
      "n": "IsMutuallyAuthenticated",
      "d": 327730,
      "h": 128849346610,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(128849346610),
//--TRIMMABLE-BOUNDARY-START(133144313906),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 60129869874,
        "f": 50331649
      },
      "n": "IsServer",
      "d": 327730,
      "h": 133144313906,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(133144313906),
//--TRIMMABLE-BOUNDARY-START(137439281202),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 68719804466,
        "f": 50331649
      },
      "n": "IsSigned",
      "d": 327730,
      "h": 137439281202,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(137439281202),
//--TRIMMABLE-BOUNDARY-START(141734248498),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 77309739058,
        "f": 50331649
      },
      "n": "Package",
      "d": 327730,
      "h": 141734248498,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(141734248498),
//--TRIMMABLE-BOUNDARY-START(146029215794),
    {
      "p": 655410,
      "g": {
        "r": 0,
        "d": 0,
        "h": 85899673650,
        "f": 50331649
      },
      "n": "ProtectionLevel",
      "d": 327730,
      "h": 146029215794,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(146029215794),
//--TRIMMABLE-BOUNDARY-START(150324183090),
    {
      "p": 161939457,
      "g": {
        "r": 0,
        "d": 0,
        "h": 94489608242,
        "f": 50331649
      },
      "n": "RemoteIdentity",
      "d": 327730,
      "h": 150324183090,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(150324183090),
//--TRIMMABLE-BOUNDARY-START(154619150386),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 103079542834,
        "f": 50331649
      },
      "n": "TargetName",
      "d": 327730,
      "h": 154619150386,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(154619150386)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885229618),
    {
      "r": 65537,
      "p": [
        {
          "n": "message",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "signatureWriter",
          "p": $.$sm.SB.IBufferWriter$$($.$$.S.Byte).$h
        }
      ],
      "n": "ComputeIntegrityCheck",
      "d": 327730,
      "h": 12885229618,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885229618),
//--TRIMMABLE-BOUNDARY-START(17180196914),
    {
      "r": 65537,
      "n": "Dispose",
      "d": 327730,
      "h": 17180196914,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180196914),
//--TRIMMABLE-BOUNDARY-START(107374510130),
    {
      "r": $.$typeArray($.$$.S.Byte).$h,
      "p": [
        {
          "n": "incomingBlob",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "statusCode",
          "p": 524338,
          "f": 2
        }
      ],
      "n": "GetOutgoingBlob",
      "d": 327730,
      "h": 107374510130,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(107374510130),
//--TRIMMABLE-BOUNDARY-START(111669477426),
    {
      "r": 1310721,
      "p": [
        {
          "n": "incomingBlob",
          "p": 1310721
        },
        {
          "n": "statusCode",
          "p": 524338,
          "f": 2
        }
      ],
      "n": "GetOutgoingBlob",
      "o": "@$1",
      "d": 327730,
      "h": 111669477426,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(111669477426),
//--TRIMMABLE-BOUNDARY-START(158914117682),
    {
      "r": 524338,
      "p": [
        {
          "n": "input",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "outputWriter",
          "p": $.$sm.SB.IBufferWriter$$($.$$.S.Byte).$h
        },
        {
          "n": "wasEncrypted",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "Unwrap",
      "d": 327730,
      "h": 158914117682,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(158914117682),
//--TRIMMABLE-BOUNDARY-START(163209084978),
    {
      "r": 524338,
      "p": [
        {
          "n": "input",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        },
        {
          "n": "unwrappedOffset",
          "p": 655361,
          "f": 2
        },
        {
          "n": "unwrappedLength",
          "p": 655361,
          "f": 2
        },
        {
          "n": "wasEncrypted",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "UnwrapInPlace",
      "d": 327730,
      "h": 163209084978,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(163209084978),
//--TRIMMABLE-BOUNDARY-START(167504052274),
    {
      "r": 262145,
      "p": [
        {
          "n": "message",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "signature",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "VerifyIntegrityCheck",
      "d": 327730,
      "h": 167504052274,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(167504052274),
//--TRIMMABLE-BOUNDARY-START(171799019570),
    {
      "r": 524338,
      "p": [
        {
          "n": "input",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        },
        {
          "n": "outputWriter",
          "p": $.$sm.SB.IBufferWriter$$($.$$.S.Byte).$h
        },
        {
          "n": "requestEncryption",
          "p": 262145
        },
        {
          "n": "isEncrypted",
          "p": 262145,
          "f": 2
        }
      ],
      "n": "Wrap",
      "d": 327730,
      "h": 171799019570,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(171799019570)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295295026),
    {
      "p": [
        {
          "n": "clientOptions",
          "p": 393266
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 327730,
      "h": 4295295026,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295295026),
//--TRIMMABLE-BOUNDARY-START(8590262322),
    {
      "p": [
        {
          "n": "serverOptions",
          "p": 458802
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 327730,
      "h": 8590262322,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590262322)
  ],
  "h": 327730
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.NegotiateAuthentication`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}NegotiateAuthentication`; }
        });
        //--TRIMMABLE-BOUNDARY-END(327730)
        
        

        //--TRIMMABLE-BOUNDARY-START(1507378)
        $asm.$cls(`$snsc.SSAE.ExtendedProtectionPolicy`, ($self) => class ExtendedProtectionPolicy extends $.$$.S.Object
        {
            //--TRIMMABLE-BOUNDARY-START(4296474674)
            $ctor$1(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296474674);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296474674)
            
            //--TRIMMABLE-BOUNDARY-START(21476343858)
            $ctor$5(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476343858);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476343858)
            
            //--TRIMMABLE-BOUNDARY-START(8591441970)
            $ctor$2(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ChannelBinding*/ customChannelBinding)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591441970);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591441970)
            
            //--TRIMMABLE-BOUNDARY-START(12886409266)
            $ctor$3(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ProtectionScenario*/ protectionScenario, /*System.Collections.ICollection?*/ customServiceNames)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886409266);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886409266)
            
            //--TRIMMABLE-BOUNDARY-START(17181376562)
            $ctor$4(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ProtectionScenario*/ protectionScenario, /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection?*/ customServiceNames)
            {
                super.$ctor();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181376562);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181376562)
            
            //--TRIMMABLE-BOUNDARY-START(25771311154)
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get CustomChannelBinding()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38656213042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25771311154)
            
            //--TRIMMABLE-BOUNDARY-START(30066278450)
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection? */ get CustomServiceNames()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47246147634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30066278450)
            
            //--TRIMMABLE-BOUNDARY-START(77310918706)
            static /*bool */ get OSSupportsExtendedProtection()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55836082226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77310918706)
            
            //--TRIMMABLE-BOUNDARY-START(81605886002)
            /*System.Security.Authentication.ExtendedProtection.PolicyEnforcement */ get PolicyEnforcement()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64426016818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81605886002)
            
            //--TRIMMABLE-BOUNDARY-START(85900853298)
            /*System.Security.Authentication.ExtendedProtection.ProtectionScenario */ get ProtectionScenario()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015951410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(85900853298)
            
            //--TRIMMABLE-BOUNDARY-START(90195820594)
            /*void */ SRS$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo?*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195820594);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(90195820594)
            
            //--TRIMMABLE-BOUNDARY-START(94490787890)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490787890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(94490787890)
            
            static $h = 1507378;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Object; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(25771311154),
    {
      "p": 5373999,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38656213042,
        "f": 50331649
      },
      "n": "CustomChannelBinding",
      "d": 1507378,
      "h": 25771311154,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(25771311154),
//--TRIMMABLE-BOUNDARY-START(30066278450),
    {
      "p": 1703986,
      "g": {
        "r": 0,
        "d": 0,
        "h": 47246147634,
        "f": 50331649
      },
      "n": "CustomServiceNames",
      "d": 1507378,
      "h": 30066278450,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(30066278450),
//--TRIMMABLE-BOUNDARY-START(77310918706),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 55836082226,
        "f": 50331681
      },
      "n": "OSSupportsExtendedProtection",
      "d": 1507378,
      "h": 77310918706,
      "f": 2097185
    },
//--TRIMMABLE-BOUNDARY-END(77310918706),
//--TRIMMABLE-BOUNDARY-START(81605886002),
    {
      "p": 1572914,
      "g": {
        "r": 0,
        "d": 0,
        "h": 64426016818,
        "f": 50331649
      },
      "n": "PolicyEnforcement",
      "d": 1507378,
      "h": 81605886002,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(81605886002),
//--TRIMMABLE-BOUNDARY-START(85900853298),
    {
      "p": 1638450,
      "g": {
        "r": 0,
        "d": 0,
        "h": 73015951410,
        "f": 50331649
      },
      "n": "ProtectionScenario",
      "d": 1507378,
      "h": 85900853298,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(85900853298)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(94490787890),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 1507378,
      "h": 94490787890,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(94490787890)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296474674),
    {
      "p": [
        {
          "n": "info",
          "p": 158859265
        },
        {
          "n": "context",
          "p": 158990337
        }
      ],
      "n": ".ctor",
      "o": "$ctor$1",
      "d": 1507378,
      "h": 4296474674,
      "f": 16777220,
      "a": [
        {
          "t": 65011713,
          "c": 12949913601,
          "a": [
            {
              "v": 1,
              "t": 65077249
            }
          ]
        },
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "This API supports obsolete formatter-based serialization. It should not be called or extended by application code.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0051",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(4296474674),
//--TRIMMABLE-BOUNDARY-START(21476343858),
    {
      "p": [
        {
          "n": "policyEnforcement",
          "p": 1572914
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1507378,
      "h": 21476343858,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476343858),
//--TRIMMABLE-BOUNDARY-START(8591441970),
    {
      "p": [
        {
          "n": "policyEnforcement",
          "p": 1572914
        },
        {
          "n": "customChannelBinding",
          "p": 5373999
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1507378,
      "h": 8591441970,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591441970),
//--TRIMMABLE-BOUNDARY-START(12886409266),
    {
      "p": [
        {
          "n": "policyEnforcement",
          "p": 1572914
        },
        {
          "n": "protectionScenario",
          "p": 1638450
        },
        {
          "n": "customServiceNames",
          "p": 63111169
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1507378,
      "h": 12886409266,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886409266),
//--TRIMMABLE-BOUNDARY-START(17181376562),
    {
      "p": [
        {
          "n": "policyEnforcement",
          "p": 1572914
        },
        {
          "n": "protectionScenario",
          "p": 1638450
        },
        {
          "n": "customServiceNames",
          "p": 1703986
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1507378,
      "h": 17181376562,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181376562)
  ],
  "h": 1507378
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Authentication${separator}ExtendedProtection${separator}ExtendedProtectionPolicy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1507378)
        
        

        //--TRIMMABLE-BOUNDARY-START(1114162)
        $asm.$str(`$snsc.SNS.SslClientHelloInfo`, ($self) => class SslClientHelloInfo extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4296081458)
            /*object*/ _dummy = null;
            //--TRIMMABLE-BOUNDARY-END(4296081458)
            
            //--TRIMMABLE-BOUNDARY-START(8591048754)
            /*int*/ _dummyPrimitive = 0;
            //--TRIMMABLE-BOUNDARY-END(8591048754)
            
            //--TRIMMABLE-BOUNDARY-START(17180983346)
            $ctor$3(/*string*/ serverName, /*System.Security.Authentication.SslProtocols*/ sslProtocols)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180983346);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180983346)
            
            //--TRIMMABLE-BOUNDARY-START(38655819826)
            /*string */ get ServerName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770917938);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655819826)
            
            //--TRIMMABLE-BOUNDARY-START(42950787122)
            /*System.Security.Authentication.SslProtocols */ get SslProtocols()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360852530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950787122)
            
            //--TRIMMABLE-BOUNDARY-START(12886016050)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886016050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886016050)
            
            //--TRIMMABLE-BOUNDARY-START(12886016050)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12886016050)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            static $h = 1114162;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(38655819826),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 25770917938,
        "f": 50331649
      },
      "n": "ServerName",
      "d": 1114162,
      "h": 38655819826,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(38655819826),
//--TRIMMABLE-BOUNDARY-START(42950787122),
    {
      "p": 5570607,
      "g": {
        "r": 0,
        "d": 0,
        "h": 34360852530,
        "f": 50331649
      },
      "n": "SslProtocols",
      "d": 1114162,
      "h": 42950787122,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(42950787122)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4296081458),
    {
      "t": 131073,
      "n": "_dummy",
      "d": 1114162,
      "h": 4296081458,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4296081458),
//--TRIMMABLE-BOUNDARY-START(8591048754),
    {
      "t": 655361,
      "n": "_dummyPrimitive",
      "d": 1114162,
      "h": 8591048754,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8591048754)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180983346),
    {
      "p": [
        {
          "n": "serverName",
          "p": 1310721
        },
        {
          "n": "sslProtocols",
          "p": 5570607
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1114162,
      "h": 17180983346,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180983346),
//--TRIMMABLE-BOUNDARY-START(12886016050),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1114162,
      "h": 12886016050,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886016050)
  ],
  "h": 1114162
}; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.SslClientHelloInfo`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}SslClientHelloInfo`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1114162)
        
        

        //--TRIMMABLE-BOUNDARY-START(917554)
        $asm.$str(`$snsc.SNS.SslApplicationProtocol`, ($self) => class SslApplicationProtocol extends $.$$.S.ValueType
        {
            //--TRIMMABLE-BOUNDARY-START(4295884850)
            /*object*/ _dummy = null;
            //--TRIMMABLE-BOUNDARY-END(4295884850)
            
            //--TRIMMABLE-BOUNDARY-START(8590852146)
            /*int*/ _dummyPrimitive = 0;
            //--TRIMMABLE-BOUNDARY-END(8590852146)
            
            //--TRIMMABLE-BOUNDARY-START(47245557810)
            /*System.Net.Security.SslApplicationProtocol*/ static Http11;
            //--TRIMMABLE-BOUNDARY-END(47245557810)
            
            //--TRIMMABLE-BOUNDARY-START(51540525106)
            /*System.Net.Security.SslApplicationProtocol*/ static Http2;
            //--TRIMMABLE-BOUNDARY-END(51540525106)
            
            //--TRIMMABLE-BOUNDARY-START(55835492402)
            /*System.Net.Security.SslApplicationProtocol*/ static Http3;
            //--TRIMMABLE-BOUNDARY-END(55835492402)
            
            //--TRIMMABLE-BOUNDARY-START(17180786738)
            $ctor$3(/*byte[]*/ protocol)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17180786738);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17180786738)
            
            //--TRIMMABLE-BOUNDARY-START(21475754034)
            $ctor$4(/*string*/ protocol)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21475754034);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                    throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21475754034)
            
            //--TRIMMABLE-BOUNDARY-START(68720394290)
            /*System.ReadOnlyMemory<byte> */ get Protocol()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655623218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(68720394290)
            
            //--TRIMMABLE-BOUNDARY-START(30065688626)
            /*bool */ Equals$2(/*System.Net.Security.SslApplicationProtocol*/ other)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065688626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(30065688626)
            
            //--TRIMMABLE-BOUNDARY-START(25770721330)
            /*bool */ Equals$1(/*object?*/ obj)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770721330);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(25770721330)
            
            //--TRIMMABLE-BOUNDARY-START(42950590514)
            /*int */ GetHashCode()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950590514);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950590514)
            
            //--TRIMMABLE-BOUNDARY-START(60130459698)
            static /*bool */ op_Equality(/*System.Net.Security.SslApplicationProtocol*/ left, /*System.Net.Security.SslApplicationProtocol*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130459698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(60130459698)
            
            //--TRIMMABLE-BOUNDARY-START(64425426994)
            static /*bool */ op_Inequality(/*System.Net.Security.SslApplicationProtocol*/ left, /*System.Net.Security.SslApplicationProtocol*/ right)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425426994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(64425426994)
            
            //--TRIMMABLE-BOUNDARY-START(73015361586)
            /*string */ ToString()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015361586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73015361586)
            
            //--TRIMMABLE-BOUNDARY-START(4386127873)
            //Generated interface implemetation for System.IEquatable<System.Net.Security.SslApplicationProtocol>.Equals(System.Net.Security.SslApplicationProtocol)
            S$IEquatable$System$Net$Security$SslApplicationProtocol$Equals()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4386127873);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.Equals$2(...arguments);
            }
            //--TRIMMABLE-BOUNDARY-END(4386127873)
            
            //--TRIMMABLE-BOUNDARY-START(12885819442)
            //default constructor overload
            $ctor$2()
            {
                super.$ctor$1();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885819442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12885819442)
            
            //--TRIMMABLE-BOUNDARY-START(12885819442)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$2();
            }
            //--TRIMMABLE-BOUNDARY-END(12885819442)
            
            $clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //--TRIMMABLE-BOUNDARY-START(SINIT)
            //Static Initializer
            static $sinit()
            {
                {
                    //--TRIMMABLE-BOUNDARY-START(47245557810)
                    this.Http11 = $.$default($.$snsc.SNS.SslApplicationProtocol);
                    //--TRIMMABLE-BOUNDARY-END(47245557810)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(51540525106)
                    this.Http2 = $.$default($.$snsc.SNS.SslApplicationProtocol);
                    //--TRIMMABLE-BOUNDARY-END(51540525106)
                    
                }
                {
                    //--TRIMMABLE-BOUNDARY-START(55835492402)
                    this.Http3 = $.$default($.$snsc.SNS.SslApplicationProtocol);
                    //--TRIMMABLE-BOUNDARY-END(55835492402)
                    
                }
            }
            //--TRIMMABLE-BOUNDARY-END(SINIT)
            
            static $h = 917554;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.ValueType; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(68720394290),
    {
      "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h,
      "g": {
        "r": 0,
        "d": 0,
        "h": 38655623218,
        "f": 50331649
      },
      "n": "Protocol",
      "d": 917554,
      "h": 68720394290,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(68720394290)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(30065688626),
    {
      "r": 262145,
      "p": [
        {
          "n": "other",
          "p": 917554
        }
      ],
      "n": "Equals",
      "o": "@$2",
      "d": 917554,
      "h": 30065688626,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(30065688626),
//--TRIMMABLE-BOUNDARY-START(25770721330),
    {
      "r": 262145,
      "p": [
        {
          "n": "obj",
          "p": 131073
        }
      ],
      "n": "Equals",
      "o": "@$1",
      "d": 917554,
      "h": 25770721330,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(25770721330),
//--TRIMMABLE-BOUNDARY-START(42950590514),
    {
      "r": 655361,
      "n": "GetHashCode",
      "d": 917554,
      "h": 42950590514,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(42950590514),
//--TRIMMABLE-BOUNDARY-START(73015361586),
    {
      "r": 1310721,
      "n": "ToString",
      "d": 917554,
      "h": 73015361586,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(73015361586)
  ],
  "l": [
//--TRIMMABLE-BOUNDARY-START(4295884850),
    {
      "t": 131073,
      "n": "_dummy",
      "d": 917554,
      "h": 4295884850,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(4295884850),
//--TRIMMABLE-BOUNDARY-START(8590852146),
    {
      "t": 655361,
      "n": "_dummyPrimitive",
      "d": 917554,
      "h": 8590852146,
      "f": 4194306
    },
//--TRIMMABLE-BOUNDARY-END(8590852146),
//--TRIMMABLE-BOUNDARY-START(47245557810),
    {
      "t": 917554,
      "n": "Http11",
      "d": 917554,
      "h": 47245557810,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245557810),
//--TRIMMABLE-BOUNDARY-START(51540525106),
    {
      "t": 917554,
      "n": "Http2",
      "d": 917554,
      "h": 51540525106,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540525106),
//--TRIMMABLE-BOUNDARY-START(55835492402),
    {
      "t": 917554,
      "n": "Http3",
      "d": 917554,
      "h": 55835492402,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835492402)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(17180786738),
    {
      "p": [
        {
          "n": "protocol",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 917554,
      "h": 17180786738,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17180786738),
//--TRIMMABLE-BOUNDARY-START(21475754034),
    {
      "p": [
        {
          "n": "protocol",
          "p": 1310721
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 917554,
      "h": 21475754034,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21475754034),
//--TRIMMABLE-BOUNDARY-START(12885819442),
    {
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 917554,
      "h": 12885819442,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12885819442)
  ],
  "h": 917554
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IEquatable$$($.$snsc.SNS.SslApplicationProtocol) ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.SslApplicationProtocol`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}SslApplicationProtocol`; }
        });
        //--TRIMMABLE-BOUNDARY-END(917554)
        
        

        //--TRIMMABLE-BOUNDARY-START(1703986)
        $asm.$cls(`$snsc.SSAE.ServiceNameCollection`, ($self) => class ServiceNameCollection extends $.$scn.SC.ReadOnlyCollectionBase
        {
            //--TRIMMABLE-BOUNDARY-START(4296671282)
            $ctor$2(/*System.Collections.ICollection*/ items)
            {
                super.$ctor$1();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296671282);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296671282)
            
            //--TRIMMABLE-BOUNDARY-START(8591638578)
            /*bool */ Contains(/*string?*/ searchServiceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(8591638578);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(8591638578)
            
            //--TRIMMABLE-BOUNDARY-START(12886605874)
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection */ Merge(/*System.Collections.IEnumerable*/ serviceNames)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12886605874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(12886605874)
            
            //--TRIMMABLE-BOUNDARY-START(17181573170)
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection */ Merge$1(/*string*/ serviceName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17181573170);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(17181573170)
            
            static $h = 1703986;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$scn.SC.ReadOnlyCollectionBase; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(8591638578),
    {
      "r": 262145,
      "p": [
        {
          "n": "searchServiceName",
          "p": 1310721
        }
      ],
      "n": "Contains",
      "d": 1703986,
      "h": 8591638578,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591638578),
//--TRIMMABLE-BOUNDARY-START(12886605874),
    {
      "r": 1703986,
      "p": [
        {
          "n": "serviceNames",
          "p": 63373313
        }
      ],
      "n": "Merge",
      "d": 1703986,
      "h": 12886605874,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886605874),
//--TRIMMABLE-BOUNDARY-START(17181573170),
    {
      "r": 1703986,
      "p": [
        {
          "n": "serviceName",
          "p": 1310721
        }
      ],
      "n": "Merge",
      "o": "@$1",
      "d": 1703986,
      "h": 17181573170,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181573170)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296671282),
    {
      "p": [
        {
          "n": "items",
          "p": 63111169
        }
      ],
      "n": ".ctor",
      "o": "$ctor$2",
      "d": 1703986,
      "h": 4296671282,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296671282)
  ],
  "h": 1703986
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SC$1.ICollection, $.$$.SC$1.IEnumerable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Authentication.ExtendedProtection.ServiceNameCollection`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Authentication${separator}ExtendedProtection${separator}ServiceNameCollection`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1703986)
        
        

        //--TRIMMABLE-BOUNDARY-START(262194)
        $asm.$cls(`$snsc.SNS.LocalCertificateSelectionCallback`, ($self) => class LocalCertificateSelectionCallback extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate?*/ Invoke(/*$.$$.S.Object*/ sender, /*$.$$.S.String*/ targetHost, /*$.$sscr.SSCX.X509CertificateCollection*/ localCertificates, /*$.$$.S.Nullable$$*/ remoteCertificate, /**/ acceptableIssuers)
            {
                return this.$nativeFunction.call(this.$target, sender, targetHost, localCertificates, remoteCertificate, acceptableIssuers);
            }
            static $h = 262194;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180131378),
    {
      "r": 28114974,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "targetHost",
          "p": 1310721
        },
        {
          "n": "localCertificates",
          "p": 28377118
        },
        {
          "n": "remoteCertificate",
          "p": 28114974
        },
        {
          "n": "acceptableIssuers",
          "p": $.$typeArray($.$$.S.String).$h
        }
      ],
      "n": "Invoke",
      "d": 262194,
      "h": 17180131378,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180131378),
//--TRIMMABLE-BOUNDARY-START(8590196786),
    {
      "r": 90570753,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "targetHost",
          "p": 1310721
        },
        {
          "n": "localCertificates",
          "p": 28377118
        },
        {
          "n": "remoteCertificate",
          "p": 28114974
        },
        {
          "n": "acceptableIssuers",
          "p": $.$typeArray($.$$.S.String).$h
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 262194,
      "h": 8590196786,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590196786),
//--TRIMMABLE-BOUNDARY-START(12885164082),
    {
      "r": 28114974,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 262194,
      "h": 12885164082,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885164082)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295229490),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 262194,
      "h": 4295229490,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295229490)
  ],
  "h": 262194
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.LocalCertificateSelectionCallback`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}LocalCertificateSelectionCallback`; }
        });
        //--TRIMMABLE-BOUNDARY-END(262194)
        
        

        //--TRIMMABLE-BOUNDARY-START(720946)
        $asm.$cls(`$snsc.SNS.RemoteCertificateValidationCallback`, ($self) => class RemoteCertificateValidationCallback extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*bool*/ Invoke(/*$.$$.S.Object*/ sender, /*$.$$.S.Nullable$$*/ certificate, /*$.$$.S.Nullable$$*/ chain, /*$.$snp.SNS.SslPolicyErrors*/ sslPolicyErrors)
            {
                return this.$nativeFunction.call(this.$target, sender, certificate, chain, sslPolicyErrors);
            }
            static $h = 720946;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180590130),
    {
      "r": 262145,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "certificate",
          "p": 28114974
        },
        {
          "n": "chain",
          "p": 28835870
        },
        {
          "n": "sslPolicyErrors",
          "p": 4259887
        }
      ],
      "n": "Invoke",
      "d": 720946,
      "h": 17180590130,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180590130),
//--TRIMMABLE-BOUNDARY-START(8590655538),
    {
      "r": 90570753,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "certificate",
          "p": 28114974
        },
        {
          "n": "chain",
          "p": 28835870
        },
        {
          "n": "sslPolicyErrors",
          "p": 4259887
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 720946,
      "h": 8590655538,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590655538),
//--TRIMMABLE-BOUNDARY-START(12885622834),
    {
      "r": 262145,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 720946,
      "h": 12885622834,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885622834)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295688242),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 720946,
      "h": 4295688242,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295688242)
  ],
  "h": 720946
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.RemoteCertificateValidationCallback`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}RemoteCertificateValidationCallback`; }
        });
        //--TRIMMABLE-BOUNDARY-END(720946)
        
        

        //--TRIMMABLE-BOUNDARY-START(786482)
        $asm.$cls(`$snsc.SNS.ServerCertificateSelectionCallback`, ($self) => class ServerCertificateSelectionCallback extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate*/ Invoke(/*$.$$.S.Object*/ sender, /*$.$$.S.Nullable$$*/ hostName)
            {
                return this.$nativeFunction.call(this.$target, sender, hostName);
            }
            static $h = 786482;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180655666),
    {
      "r": 28114974,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "hostName",
          "p": 1310721
        }
      ],
      "n": "Invoke",
      "d": 786482,
      "h": 17180655666,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180655666),
//--TRIMMABLE-BOUNDARY-START(8590721074),
    {
      "r": 90570753,
      "p": [
        {
          "n": "sender",
          "p": 131073
        },
        {
          "n": "hostName",
          "p": 1310721
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 786482,
      "h": 8590721074,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590721074),
//--TRIMMABLE-BOUNDARY-START(12885688370),
    {
      "r": 28114974,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 786482,
      "h": 12885688370,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885688370)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295753778),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 786482,
      "h": 4295753778,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295753778)
  ],
  "h": 786482
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.ServerCertificateSelectionCallback`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}ServerCertificateSelectionCallback`; }
        });
        //--TRIMMABLE-BOUNDARY-END(786482)
        
        

        //--TRIMMABLE-BOUNDARY-START(852018)
        $asm.$cls(`$snsc.SNS.ServerOptionsSelectionCallback`, ($self) => class ServerOptionsSelectionCallback extends $.$$.S.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Security.SslServerAuthenticationOptions>*/ Invoke(/*$.$snsc.SNS.SslStream*/ stream, /*$.$snsc.SNS.SslClientHelloInfo*/ clientHelloInfo, /*$.$$.S.Nullable$$*/ state, /*$.$$.ST$1.CancellationToken*/ cancellationToken)
            {
                return this.$nativeFunction.call(this.$target, stream, clientHelloInfo, state, cancellationToken);
            }
            static $h = 852018;
            static $f = 0b10000001;
            static $k = 5;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.MulticastDelegate; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "m": [
//--TRIMMABLE-BOUNDARY-START(17180721202),
    {
      "r": $.$$.STT.ValueTask$$($.$snsc.SNS.SslServerAuthenticationOptions).$h,
      "p": [
        {
          "n": "stream",
          "p": 1245234
        },
        {
          "n": "clientHelloInfo",
          "p": 1114162
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "Invoke",
      "d": 852018,
      "h": 17180721202,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180721202),
//--TRIMMABLE-BOUNDARY-START(8590786610),
    {
      "r": 90570753,
      "p": [
        {
          "n": "stream",
          "p": 1245234
        },
        {
          "n": "clientHelloInfo",
          "p": 1114162
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        },
        {
          "n": "callback",
          "p": 46006273
        },
        {
          "n": "object",
          "p": 131073
        }
      ],
      "n": "BeginInvoke",
      "d": 852018,
      "h": 8590786610,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(8590786610),
//--TRIMMABLE-BOUNDARY-START(12885753906),
    {
      "r": $.$$.STT.ValueTask$$($.$snsc.SNS.SslServerAuthenticationOptions).$h,
      "p": [
        {
          "n": "result",
          "p": 90570753
        }
      ],
      "n": "EndInvoke",
      "d": 852018,
      "h": 12885753906,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885753906)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295819314),
    {
      "p": [
        {
          "n": "object",
          "p": 131073
        },
        {
          "n": "method",
          "p": 786433
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 852018,
      "h": 4295819314,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295819314)
  ],
  "h": 852018
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.ICloneable, $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.ServerOptionsSelectionCallback`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}ServerOptionsSelectionCallback`; }
        });
        //--TRIMMABLE-BOUNDARY-END(852018)
        
        

        //--TRIMMABLE-BOUNDARY-START(196658)
        $asm.$str(`$snsc.SNS.EncryptionPolicy`, ($self) => class EncryptionPolicy extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static RequireEncryption = 0;
            static AllowNoEncryption = 1;
            static NoEncryption = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(196658);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "RequireEncryption": 0n,
                    "AllowNoEncryption": 1n,
                    "NoEncryption": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295163954)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295163954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295163954)
            
            //--TRIMMABLE-BOUNDARY-START(4295163954)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295163954)
            
            static $h = 196658;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(17180065842),
    {
      "t": 196658,
      "n": "RequireEncryption",
      "d": 196658,
      "h": 17180065842,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180065842),
//--TRIMMABLE-BOUNDARY-START(8590131250),
    {
      "t": 196658,
      "n": "AllowNoEncryption",
      "d": 196658,
      "h": 8590131250,
      "f": 4194337,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0040",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(8590131250),
//--TRIMMABLE-BOUNDARY-START(12885098546),
    {
      "t": 196658,
      "n": "NoEncryption",
      "d": 196658,
      "h": 12885098546,
      "f": 4194337,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0040",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(12885098546)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295163954),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 196658,
      "h": 4295163954,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295163954)
  ],
  "h": 196658
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.EncryptionPolicy`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}EncryptionPolicy`; }
        });
        //--TRIMMABLE-BOUNDARY-END(196658)
        
        

        //--TRIMMABLE-BOUNDARY-START(524338)
        $asm.$str(`$snsc.SNS.NegotiateAuthenticationStatusCode`, ($self) => class NegotiateAuthenticationStatusCode extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Completed = 0;
            static ContinueNeeded = 1;
            static GenericFailure = 2;
            static BadBinding = 3;
            static Unsupported = 4;
            static MessageAltered = 5;
            static ContextExpired = 6;
            static CredentialsExpired = 7;
            static InvalidCredentials = 8;
            static InvalidToken = 9;
            static UnknownCredentials = 10;
            static QopNotSupported = 11;
            static OutOfSequence = 12;
            static SecurityQosFailed = 13;
            static TargetUnknown = 14;
            static ImpersonationValidationFailed = 15;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(524338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Completed": 0n,
                    "ContinueNeeded": 1n,
                    "GenericFailure": 2n,
                    "BadBinding": 3n,
                    "Unsupported": 4n,
                    "MessageAltered": 5n,
                    "ContextExpired": 6n,
                    "CredentialsExpired": 7n,
                    "InvalidCredentials": 8n,
                    "InvalidToken": 9n,
                    "UnknownCredentials": 10n,
                    "QopNotSupported": 11n,
                    "OutOfSequence": 12n,
                    "SecurityQosFailed": 13n,
                    "TargetUnknown": 14n,
                    "ImpersonationValidationFailed": 15n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295491634)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295491634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295491634)
            
            //--TRIMMABLE-BOUNDARY-START(4295491634)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295491634)
            
            static $h = 524338;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885426226),
    {
      "t": 524338,
      "n": "Completed",
      "d": 524338,
      "h": 12885426226,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885426226),
//--TRIMMABLE-BOUNDARY-START(21475360818),
    {
      "t": 524338,
      "n": "ContinueNeeded",
      "d": 524338,
      "h": 21475360818,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21475360818),
//--TRIMMABLE-BOUNDARY-START(30065295410),
    {
      "t": 524338,
      "n": "GenericFailure",
      "d": 524338,
      "h": 30065295410,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30065295410),
//--TRIMMABLE-BOUNDARY-START(8590458930),
    {
      "t": 524338,
      "n": "BadBinding",
      "d": 524338,
      "h": 8590458930,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590458930),
//--TRIMMABLE-BOUNDARY-START(73014968370),
    {
      "t": 524338,
      "n": "Unsupported",
      "d": 524338,
      "h": 73014968370,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73014968370),
//--TRIMMABLE-BOUNDARY-START(47245164594),
    {
      "t": 524338,
      "n": "MessageAltered",
      "d": 524338,
      "h": 47245164594,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47245164594),
//--TRIMMABLE-BOUNDARY-START(17180393522),
    {
      "t": 524338,
      "n": "ContextExpired",
      "d": 524338,
      "h": 17180393522,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180393522),
//--TRIMMABLE-BOUNDARY-START(25770328114),
    {
      "t": 524338,
      "n": "CredentialsExpired",
      "d": 524338,
      "h": 25770328114,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25770328114),
//--TRIMMABLE-BOUNDARY-START(38655230002),
    {
      "t": 524338,
      "n": "InvalidCredentials",
      "d": 524338,
      "h": 38655230002,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38655230002),
//--TRIMMABLE-BOUNDARY-START(42950197298),
    {
      "t": 524338,
      "n": "InvalidToken",
      "d": 524338,
      "h": 42950197298,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42950197298),
//--TRIMMABLE-BOUNDARY-START(68720001074),
    {
      "t": 524338,
      "n": "UnknownCredentials",
      "d": 524338,
      "h": 68720001074,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720001074),
//--TRIMMABLE-BOUNDARY-START(55835099186),
    {
      "t": 524338,
      "n": "QopNotSupported",
      "d": 524338,
      "h": 55835099186,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835099186),
//--TRIMMABLE-BOUNDARY-START(51540131890),
    {
      "t": 524338,
      "n": "OutOfSequence",
      "d": 524338,
      "h": 51540131890,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540131890),
//--TRIMMABLE-BOUNDARY-START(60130066482),
    {
      "t": 524338,
      "n": "SecurityQosFailed",
      "d": 524338,
      "h": 60130066482,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130066482),
//--TRIMMABLE-BOUNDARY-START(64425033778),
    {
      "t": 524338,
      "n": "TargetUnknown",
      "d": 524338,
      "h": 64425033778,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425033778),
//--TRIMMABLE-BOUNDARY-START(34360262706),
    {
      "t": 524338,
      "n": "ImpersonationValidationFailed",
      "d": 524338,
      "h": 34360262706,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34360262706)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295491634),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 524338,
      "h": 4295491634,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295491634)
  ],
  "h": 524338
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.NegotiateAuthenticationStatusCode`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}NegotiateAuthenticationStatusCode`; }
        });
        //--TRIMMABLE-BOUNDARY-END(524338)
        
        

        //--TRIMMABLE-BOUNDARY-START(655410)
        $asm.$str(`$snsc.SNS.ProtectionLevel`, ($self) => class ProtectionLevel extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static None = 0;
            static Sign = 1;
            static EncryptAndSign = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(655410);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "None": 0n,
                    "Sign": 1n,
                    "EncryptAndSign": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4295622706)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4295622706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295622706)
            
            //--TRIMMABLE-BOUNDARY-START(4295622706)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4295622706)
            
            static $h = 655410;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12885557298),
    {
      "t": 655410,
      "n": "None",
      "d": 655410,
      "h": 12885557298,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12885557298),
//--TRIMMABLE-BOUNDARY-START(17180524594),
    {
      "t": 655410,
      "n": "Sign",
      "d": 655410,
      "h": 17180524594,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17180524594),
//--TRIMMABLE-BOUNDARY-START(8590590002),
    {
      "t": 655410,
      "n": "EncryptAndSign",
      "d": 655410,
      "h": 8590590002,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8590590002)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4295622706),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 655410,
      "h": 4295622706,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295622706)
  ],
  "h": 655410
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.ProtectionLevel`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}ProtectionLevel`; }
        });
        //--TRIMMABLE-BOUNDARY-END(655410)
        
        

        //--TRIMMABLE-BOUNDARY-START(1376306)
        $asm.$str(`$snsc.SNS.TlsCipherSuite`, ($self) => class TlsCipherSuite extends $.$$.S.Enum$$$($self, $.$$.S.UInt16)
        {
            static TLS_NULL_WITH_NULL_NULL = 0;
            static TLS_RSA_WITH_NULL_MD5 = 1;
            static TLS_RSA_WITH_NULL_SHA = 2;
            static TLS_RSA_EXPORT_WITH_RC4_40_MD5 = 3;
            static TLS_RSA_WITH_RC4_128_MD5 = 4;
            static TLS_RSA_WITH_RC4_128_SHA = 5;
            static TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5 = 6;
            static TLS_RSA_WITH_IDEA_CBC_SHA = 7;
            static TLS_RSA_EXPORT_WITH_DES40_CBC_SHA = 8;
            static TLS_RSA_WITH_DES_CBC_SHA = 9;
            static TLS_RSA_WITH_3DES_EDE_CBC_SHA = 10;
            static TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA = 11;
            static TLS_DH_DSS_WITH_DES_CBC_SHA = 12;
            static TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA = 13;
            static TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA = 14;
            static TLS_DH_RSA_WITH_DES_CBC_SHA = 15;
            static TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA = 16;
            static TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA = 17;
            static TLS_DHE_DSS_WITH_DES_CBC_SHA = 18;
            static TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA = 19;
            static TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA = 20;
            static TLS_DHE_RSA_WITH_DES_CBC_SHA = 21;
            static TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA = 22;
            static TLS_DH_anon_EXPORT_WITH_RC4_40_MD5 = 23;
            static TLS_DH_anon_WITH_RC4_128_MD5 = 24;
            static TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA = 25;
            static TLS_DH_anon_WITH_DES_CBC_SHA = 26;
            static TLS_DH_anon_WITH_3DES_EDE_CBC_SHA = 27;
            static TLS_KRB5_WITH_DES_CBC_SHA = 30;
            static TLS_KRB5_WITH_3DES_EDE_CBC_SHA = 31;
            static TLS_KRB5_WITH_RC4_128_SHA = 32;
            static TLS_KRB5_WITH_IDEA_CBC_SHA = 33;
            static TLS_KRB5_WITH_DES_CBC_MD5 = 34;
            static TLS_KRB5_WITH_3DES_EDE_CBC_MD5 = 35;
            static TLS_KRB5_WITH_RC4_128_MD5 = 36;
            static TLS_KRB5_WITH_IDEA_CBC_MD5 = 37;
            static TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA = 38;
            static TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA = 39;
            static TLS_KRB5_EXPORT_WITH_RC4_40_SHA = 40;
            static TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5 = 41;
            static TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5 = 42;
            static TLS_KRB5_EXPORT_WITH_RC4_40_MD5 = 43;
            static TLS_PSK_WITH_NULL_SHA = 44;
            static TLS_DHE_PSK_WITH_NULL_SHA = 45;
            static TLS_RSA_PSK_WITH_NULL_SHA = 46;
            static TLS_RSA_WITH_AES_128_CBC_SHA = 47;
            static TLS_DH_DSS_WITH_AES_128_CBC_SHA = 48;
            static TLS_DH_RSA_WITH_AES_128_CBC_SHA = 49;
            static TLS_DHE_DSS_WITH_AES_128_CBC_SHA = 50;
            static TLS_DHE_RSA_WITH_AES_128_CBC_SHA = 51;
            static TLS_DH_anon_WITH_AES_128_CBC_SHA = 52;
            static TLS_RSA_WITH_AES_256_CBC_SHA = 53;
            static TLS_DH_DSS_WITH_AES_256_CBC_SHA = 54;
            static TLS_DH_RSA_WITH_AES_256_CBC_SHA = 55;
            static TLS_DHE_DSS_WITH_AES_256_CBC_SHA = 56;
            static TLS_DHE_RSA_WITH_AES_256_CBC_SHA = 57;
            static TLS_DH_anon_WITH_AES_256_CBC_SHA = 58;
            static TLS_RSA_WITH_NULL_SHA256 = 59;
            static TLS_RSA_WITH_AES_128_CBC_SHA256 = 60;
            static TLS_RSA_WITH_AES_256_CBC_SHA256 = 61;
            static TLS_DH_DSS_WITH_AES_128_CBC_SHA256 = 62;
            static TLS_DH_RSA_WITH_AES_128_CBC_SHA256 = 63;
            static TLS_DHE_DSS_WITH_AES_128_CBC_SHA256 = 64;
            static TLS_RSA_WITH_CAMELLIA_128_CBC_SHA = 65;
            static TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA = 66;
            static TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA = 67;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA = 68;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA = 69;
            static TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA = 70;
            static TLS_DHE_RSA_WITH_AES_128_CBC_SHA256 = 103;
            static TLS_DH_DSS_WITH_AES_256_CBC_SHA256 = 104;
            static TLS_DH_RSA_WITH_AES_256_CBC_SHA256 = 105;
            static TLS_DHE_DSS_WITH_AES_256_CBC_SHA256 = 106;
            static TLS_DHE_RSA_WITH_AES_256_CBC_SHA256 = 107;
            static TLS_DH_anon_WITH_AES_128_CBC_SHA256 = 108;
            static TLS_DH_anon_WITH_AES_256_CBC_SHA256 = 109;
            static TLS_RSA_WITH_CAMELLIA_256_CBC_SHA = 132;
            static TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA = 133;
            static TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA = 134;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA = 135;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA = 136;
            static TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA = 137;
            static TLS_PSK_WITH_RC4_128_SHA = 138;
            static TLS_PSK_WITH_3DES_EDE_CBC_SHA = 139;
            static TLS_PSK_WITH_AES_128_CBC_SHA = 140;
            static TLS_PSK_WITH_AES_256_CBC_SHA = 141;
            static TLS_DHE_PSK_WITH_RC4_128_SHA = 142;
            static TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA = 143;
            static TLS_DHE_PSK_WITH_AES_128_CBC_SHA = 144;
            static TLS_DHE_PSK_WITH_AES_256_CBC_SHA = 145;
            static TLS_RSA_PSK_WITH_RC4_128_SHA = 146;
            static TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA = 147;
            static TLS_RSA_PSK_WITH_AES_128_CBC_SHA = 148;
            static TLS_RSA_PSK_WITH_AES_256_CBC_SHA = 149;
            static TLS_RSA_WITH_SEED_CBC_SHA = 150;
            static TLS_DH_DSS_WITH_SEED_CBC_SHA = 151;
            static TLS_DH_RSA_WITH_SEED_CBC_SHA = 152;
            static TLS_DHE_DSS_WITH_SEED_CBC_SHA = 153;
            static TLS_DHE_RSA_WITH_SEED_CBC_SHA = 154;
            static TLS_DH_anon_WITH_SEED_CBC_SHA = 155;
            static TLS_RSA_WITH_AES_128_GCM_SHA256 = 156;
            static TLS_RSA_WITH_AES_256_GCM_SHA384 = 157;
            static TLS_DHE_RSA_WITH_AES_128_GCM_SHA256 = 158;
            static TLS_DHE_RSA_WITH_AES_256_GCM_SHA384 = 159;
            static TLS_DH_RSA_WITH_AES_128_GCM_SHA256 = 160;
            static TLS_DH_RSA_WITH_AES_256_GCM_SHA384 = 161;
            static TLS_DHE_DSS_WITH_AES_128_GCM_SHA256 = 162;
            static TLS_DHE_DSS_WITH_AES_256_GCM_SHA384 = 163;
            static TLS_DH_DSS_WITH_AES_128_GCM_SHA256 = 164;
            static TLS_DH_DSS_WITH_AES_256_GCM_SHA384 = 165;
            static TLS_DH_anon_WITH_AES_128_GCM_SHA256 = 166;
            static TLS_DH_anon_WITH_AES_256_GCM_SHA384 = 167;
            static TLS_PSK_WITH_AES_128_GCM_SHA256 = 168;
            static TLS_PSK_WITH_AES_256_GCM_SHA384 = 169;
            static TLS_DHE_PSK_WITH_AES_128_GCM_SHA256 = 170;
            static TLS_DHE_PSK_WITH_AES_256_GCM_SHA384 = 171;
            static TLS_RSA_PSK_WITH_AES_128_GCM_SHA256 = 172;
            static TLS_RSA_PSK_WITH_AES_256_GCM_SHA384 = 173;
            static TLS_PSK_WITH_AES_128_CBC_SHA256 = 174;
            static TLS_PSK_WITH_AES_256_CBC_SHA384 = 175;
            static TLS_PSK_WITH_NULL_SHA256 = 176;
            static TLS_PSK_WITH_NULL_SHA384 = 177;
            static TLS_DHE_PSK_WITH_AES_128_CBC_SHA256 = 178;
            static TLS_DHE_PSK_WITH_AES_256_CBC_SHA384 = 179;
            static TLS_DHE_PSK_WITH_NULL_SHA256 = 180;
            static TLS_DHE_PSK_WITH_NULL_SHA384 = 181;
            static TLS_RSA_PSK_WITH_AES_128_CBC_SHA256 = 182;
            static TLS_RSA_PSK_WITH_AES_256_CBC_SHA384 = 183;
            static TLS_RSA_PSK_WITH_NULL_SHA256 = 184;
            static TLS_RSA_PSK_WITH_NULL_SHA384 = 185;
            static TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 186;
            static TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256 = 187;
            static TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 188;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256 = 189;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 190;
            static TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256 = 191;
            static TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 192;
            static TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256 = 193;
            static TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 194;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256 = 195;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 196;
            static TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256 = 197;
            static TLS_AES_128_GCM_SHA256 = 4865;
            static TLS_AES_256_GCM_SHA384 = 4866;
            static TLS_CHACHA20_POLY1305_SHA256 = 4867;
            static TLS_AES_128_CCM_SHA256 = 4868;
            static TLS_AES_128_CCM_8_SHA256 = 4869;
            static TLS_ECDH_ECDSA_WITH_NULL_SHA = 49153;
            static TLS_ECDH_ECDSA_WITH_RC4_128_SHA = 49154;
            static TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA = 49155;
            static TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA = 49156;
            static TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA = 49157;
            static TLS_ECDHE_ECDSA_WITH_NULL_SHA = 49158;
            static TLS_ECDHE_ECDSA_WITH_RC4_128_SHA = 49159;
            static TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA = 49160;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA = 49161;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA = 49162;
            static TLS_ECDH_RSA_WITH_NULL_SHA = 49163;
            static TLS_ECDH_RSA_WITH_RC4_128_SHA = 49164;
            static TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA = 49165;
            static TLS_ECDH_RSA_WITH_AES_128_CBC_SHA = 49166;
            static TLS_ECDH_RSA_WITH_AES_256_CBC_SHA = 49167;
            static TLS_ECDHE_RSA_WITH_NULL_SHA = 49168;
            static TLS_ECDHE_RSA_WITH_RC4_128_SHA = 49169;
            static TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA = 49170;
            static TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA = 49171;
            static TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA = 49172;
            static TLS_ECDH_anon_WITH_NULL_SHA = 49173;
            static TLS_ECDH_anon_WITH_RC4_128_SHA = 49174;
            static TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA = 49175;
            static TLS_ECDH_anon_WITH_AES_128_CBC_SHA = 49176;
            static TLS_ECDH_anon_WITH_AES_256_CBC_SHA = 49177;
            static TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA = 49178;
            static TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA = 49179;
            static TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA = 49180;
            static TLS_SRP_SHA_WITH_AES_128_CBC_SHA = 49181;
            static TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA = 49182;
            static TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA = 49183;
            static TLS_SRP_SHA_WITH_AES_256_CBC_SHA = 49184;
            static TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA = 49185;
            static TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA = 49186;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256 = 49187;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384 = 49188;
            static TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256 = 49189;
            static TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384 = 49190;
            static TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256 = 49191;
            static TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384 = 49192;
            static TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256 = 49193;
            static TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384 = 49194;
            static TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256 = 49195;
            static TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384 = 49196;
            static TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256 = 49197;
            static TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384 = 49198;
            static TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 = 49199;
            static TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 = 49200;
            static TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256 = 49201;
            static TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384 = 49202;
            static TLS_ECDHE_PSK_WITH_RC4_128_SHA = 49203;
            static TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA = 49204;
            static TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA = 49205;
            static TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA = 49206;
            static TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256 = 49207;
            static TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384 = 49208;
            static TLS_ECDHE_PSK_WITH_NULL_SHA = 49209;
            static TLS_ECDHE_PSK_WITH_NULL_SHA256 = 49210;
            static TLS_ECDHE_PSK_WITH_NULL_SHA384 = 49211;
            static TLS_RSA_WITH_ARIA_128_CBC_SHA256 = 49212;
            static TLS_RSA_WITH_ARIA_256_CBC_SHA384 = 49213;
            static TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256 = 49214;
            static TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384 = 49215;
            static TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256 = 49216;
            static TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384 = 49217;
            static TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256 = 49218;
            static TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384 = 49219;
            static TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256 = 49220;
            static TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384 = 49221;
            static TLS_DH_anon_WITH_ARIA_128_CBC_SHA256 = 49222;
            static TLS_DH_anon_WITH_ARIA_256_CBC_SHA384 = 49223;
            static TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256 = 49224;
            static TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384 = 49225;
            static TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256 = 49226;
            static TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384 = 49227;
            static TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256 = 49228;
            static TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384 = 49229;
            static TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256 = 49230;
            static TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384 = 49231;
            static TLS_RSA_WITH_ARIA_128_GCM_SHA256 = 49232;
            static TLS_RSA_WITH_ARIA_256_GCM_SHA384 = 49233;
            static TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256 = 49234;
            static TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384 = 49235;
            static TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256 = 49236;
            static TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384 = 49237;
            static TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256 = 49238;
            static TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384 = 49239;
            static TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256 = 49240;
            static TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384 = 49241;
            static TLS_DH_anon_WITH_ARIA_128_GCM_SHA256 = 49242;
            static TLS_DH_anon_WITH_ARIA_256_GCM_SHA384 = 49243;
            static TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256 = 49244;
            static TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384 = 49245;
            static TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256 = 49246;
            static TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384 = 49247;
            static TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256 = 49248;
            static TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384 = 49249;
            static TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256 = 49250;
            static TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384 = 49251;
            static TLS_PSK_WITH_ARIA_128_CBC_SHA256 = 49252;
            static TLS_PSK_WITH_ARIA_256_CBC_SHA384 = 49253;
            static TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256 = 49254;
            static TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384 = 49255;
            static TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256 = 49256;
            static TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384 = 49257;
            static TLS_PSK_WITH_ARIA_128_GCM_SHA256 = 49258;
            static TLS_PSK_WITH_ARIA_256_GCM_SHA384 = 49259;
            static TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256 = 49260;
            static TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384 = 49261;
            static TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256 = 49262;
            static TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384 = 49263;
            static TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256 = 49264;
            static TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384 = 49265;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 = 49266;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 = 49267;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 = 49268;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 = 49269;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 49270;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384 = 49271;
            static TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 49272;
            static TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384 = 49273;
            static TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49274;
            static TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49275;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49276;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49277;
            static TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49278;
            static TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49279;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256 = 49280;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384 = 49281;
            static TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256 = 49282;
            static TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384 = 49283;
            static TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256 = 49284;
            static TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384 = 49285;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 = 49286;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 = 49287;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 = 49288;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 = 49289;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49290;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49291;
            static TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49292;
            static TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49293;
            static TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49294;
            static TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49295;
            static TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49296;
            static TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49297;
            static TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49298;
            static TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49299;
            static TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49300;
            static TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49301;
            static TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49302;
            static TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49303;
            static TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49304;
            static TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49305;
            static TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49306;
            static TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49307;
            static TLS_RSA_WITH_AES_128_CCM = 49308;
            static TLS_RSA_WITH_AES_256_CCM = 49309;
            static TLS_DHE_RSA_WITH_AES_128_CCM = 49310;
            static TLS_DHE_RSA_WITH_AES_256_CCM = 49311;
            static TLS_RSA_WITH_AES_128_CCM_8 = 49312;
            static TLS_RSA_WITH_AES_256_CCM_8 = 49313;
            static TLS_DHE_RSA_WITH_AES_128_CCM_8 = 49314;
            static TLS_DHE_RSA_WITH_AES_256_CCM_8 = 49315;
            static TLS_PSK_WITH_AES_128_CCM = 49316;
            static TLS_PSK_WITH_AES_256_CCM = 49317;
            static TLS_DHE_PSK_WITH_AES_128_CCM = 49318;
            static TLS_DHE_PSK_WITH_AES_256_CCM = 49319;
            static TLS_PSK_WITH_AES_128_CCM_8 = 49320;
            static TLS_PSK_WITH_AES_256_CCM_8 = 49321;
            static TLS_PSK_DHE_WITH_AES_128_CCM_8 = 49322;
            static TLS_PSK_DHE_WITH_AES_256_CCM_8 = 49323;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CCM = 49324;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CCM = 49325;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8 = 49326;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8 = 49327;
            static TLS_ECCPWD_WITH_AES_128_GCM_SHA256 = 49328;
            static TLS_ECCPWD_WITH_AES_256_GCM_SHA384 = 49329;
            static TLS_ECCPWD_WITH_AES_128_CCM_SHA256 = 49330;
            static TLS_ECCPWD_WITH_AES_256_CCM_SHA384 = 49331;
            static TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256 = 52392;
            static TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256 = 52393;
            static TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256 = 52394;
            static TLS_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52395;
            static TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52396;
            static TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52397;
            static TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52398;
            static TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256 = 53249;
            static TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384 = 53250;
            static TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256 = 53251;
            static TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256 = 53253;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1376306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "TLS_NULL_WITH_NULL_NULL": 0n,
                    "TLS_RSA_WITH_NULL_MD5": 1n,
                    "TLS_RSA_WITH_NULL_SHA": 2n,
                    "TLS_RSA_EXPORT_WITH_RC4_40_MD5": 3n,
                    "TLS_RSA_WITH_RC4_128_MD5": 4n,
                    "TLS_RSA_WITH_RC4_128_SHA": 5n,
                    "TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5": 6n,
                    "TLS_RSA_WITH_IDEA_CBC_SHA": 7n,
                    "TLS_RSA_EXPORT_WITH_DES40_CBC_SHA": 8n,
                    "TLS_RSA_WITH_DES_CBC_SHA": 9n,
                    "TLS_RSA_WITH_3DES_EDE_CBC_SHA": 10n,
                    "TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA": 11n,
                    "TLS_DH_DSS_WITH_DES_CBC_SHA": 12n,
                    "TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA": 13n,
                    "TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA": 14n,
                    "TLS_DH_RSA_WITH_DES_CBC_SHA": 15n,
                    "TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA": 16n,
                    "TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA": 17n,
                    "TLS_DHE_DSS_WITH_DES_CBC_SHA": 18n,
                    "TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA": 19n,
                    "TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA": 20n,
                    "TLS_DHE_RSA_WITH_DES_CBC_SHA": 21n,
                    "TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA": 22n,
                    "TLS_DH_anon_EXPORT_WITH_RC4_40_MD5": 23n,
                    "TLS_DH_anon_WITH_RC4_128_MD5": 24n,
                    "TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA": 25n,
                    "TLS_DH_anon_WITH_DES_CBC_SHA": 26n,
                    "TLS_DH_anon_WITH_3DES_EDE_CBC_SHA": 27n,
                    "TLS_KRB5_WITH_DES_CBC_SHA": 30n,
                    "TLS_KRB5_WITH_3DES_EDE_CBC_SHA": 31n,
                    "TLS_KRB5_WITH_RC4_128_SHA": 32n,
                    "TLS_KRB5_WITH_IDEA_CBC_SHA": 33n,
                    "TLS_KRB5_WITH_DES_CBC_MD5": 34n,
                    "TLS_KRB5_WITH_3DES_EDE_CBC_MD5": 35n,
                    "TLS_KRB5_WITH_RC4_128_MD5": 36n,
                    "TLS_KRB5_WITH_IDEA_CBC_MD5": 37n,
                    "TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA": 38n,
                    "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA": 39n,
                    "TLS_KRB5_EXPORT_WITH_RC4_40_SHA": 40n,
                    "TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5": 41n,
                    "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5": 42n,
                    "TLS_KRB5_EXPORT_WITH_RC4_40_MD5": 43n,
                    "TLS_PSK_WITH_NULL_SHA": 44n,
                    "TLS_DHE_PSK_WITH_NULL_SHA": 45n,
                    "TLS_RSA_PSK_WITH_NULL_SHA": 46n,
                    "TLS_RSA_WITH_AES_128_CBC_SHA": 47n,
                    "TLS_DH_DSS_WITH_AES_128_CBC_SHA": 48n,
                    "TLS_DH_RSA_WITH_AES_128_CBC_SHA": 49n,
                    "TLS_DHE_DSS_WITH_AES_128_CBC_SHA": 50n,
                    "TLS_DHE_RSA_WITH_AES_128_CBC_SHA": 51n,
                    "TLS_DH_anon_WITH_AES_128_CBC_SHA": 52n,
                    "TLS_RSA_WITH_AES_256_CBC_SHA": 53n,
                    "TLS_DH_DSS_WITH_AES_256_CBC_SHA": 54n,
                    "TLS_DH_RSA_WITH_AES_256_CBC_SHA": 55n,
                    "TLS_DHE_DSS_WITH_AES_256_CBC_SHA": 56n,
                    "TLS_DHE_RSA_WITH_AES_256_CBC_SHA": 57n,
                    "TLS_DH_anon_WITH_AES_256_CBC_SHA": 58n,
                    "TLS_RSA_WITH_NULL_SHA256": 59n,
                    "TLS_RSA_WITH_AES_128_CBC_SHA256": 60n,
                    "TLS_RSA_WITH_AES_256_CBC_SHA256": 61n,
                    "TLS_DH_DSS_WITH_AES_128_CBC_SHA256": 62n,
                    "TLS_DH_RSA_WITH_AES_128_CBC_SHA256": 63n,
                    "TLS_DHE_DSS_WITH_AES_128_CBC_SHA256": 64n,
                    "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA": 65n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA": 66n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA": 67n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA": 68n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA": 69n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA": 70n,
                    "TLS_DHE_RSA_WITH_AES_128_CBC_SHA256": 103n,
                    "TLS_DH_DSS_WITH_AES_256_CBC_SHA256": 104n,
                    "TLS_DH_RSA_WITH_AES_256_CBC_SHA256": 105n,
                    "TLS_DHE_DSS_WITH_AES_256_CBC_SHA256": 106n,
                    "TLS_DHE_RSA_WITH_AES_256_CBC_SHA256": 107n,
                    "TLS_DH_anon_WITH_AES_128_CBC_SHA256": 108n,
                    "TLS_DH_anon_WITH_AES_256_CBC_SHA256": 109n,
                    "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA": 132n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA": 133n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA": 134n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA": 135n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA": 136n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA": 137n,
                    "TLS_PSK_WITH_RC4_128_SHA": 138n,
                    "TLS_PSK_WITH_3DES_EDE_CBC_SHA": 139n,
                    "TLS_PSK_WITH_AES_128_CBC_SHA": 140n,
                    "TLS_PSK_WITH_AES_256_CBC_SHA": 141n,
                    "TLS_DHE_PSK_WITH_RC4_128_SHA": 142n,
                    "TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA": 143n,
                    "TLS_DHE_PSK_WITH_AES_128_CBC_SHA": 144n,
                    "TLS_DHE_PSK_WITH_AES_256_CBC_SHA": 145n,
                    "TLS_RSA_PSK_WITH_RC4_128_SHA": 146n,
                    "TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA": 147n,
                    "TLS_RSA_PSK_WITH_AES_128_CBC_SHA": 148n,
                    "TLS_RSA_PSK_WITH_AES_256_CBC_SHA": 149n,
                    "TLS_RSA_WITH_SEED_CBC_SHA": 150n,
                    "TLS_DH_DSS_WITH_SEED_CBC_SHA": 151n,
                    "TLS_DH_RSA_WITH_SEED_CBC_SHA": 152n,
                    "TLS_DHE_DSS_WITH_SEED_CBC_SHA": 153n,
                    "TLS_DHE_RSA_WITH_SEED_CBC_SHA": 154n,
                    "TLS_DH_anon_WITH_SEED_CBC_SHA": 155n,
                    "TLS_RSA_WITH_AES_128_GCM_SHA256": 156n,
                    "TLS_RSA_WITH_AES_256_GCM_SHA384": 157n,
                    "TLS_DHE_RSA_WITH_AES_128_GCM_SHA256": 158n,
                    "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384": 159n,
                    "TLS_DH_RSA_WITH_AES_128_GCM_SHA256": 160n,
                    "TLS_DH_RSA_WITH_AES_256_GCM_SHA384": 161n,
                    "TLS_DHE_DSS_WITH_AES_128_GCM_SHA256": 162n,
                    "TLS_DHE_DSS_WITH_AES_256_GCM_SHA384": 163n,
                    "TLS_DH_DSS_WITH_AES_128_GCM_SHA256": 164n,
                    "TLS_DH_DSS_WITH_AES_256_GCM_SHA384": 165n,
                    "TLS_DH_anon_WITH_AES_128_GCM_SHA256": 166n,
                    "TLS_DH_anon_WITH_AES_256_GCM_SHA384": 167n,
                    "TLS_PSK_WITH_AES_128_GCM_SHA256": 168n,
                    "TLS_PSK_WITH_AES_256_GCM_SHA384": 169n,
                    "TLS_DHE_PSK_WITH_AES_128_GCM_SHA256": 170n,
                    "TLS_DHE_PSK_WITH_AES_256_GCM_SHA384": 171n,
                    "TLS_RSA_PSK_WITH_AES_128_GCM_SHA256": 172n,
                    "TLS_RSA_PSK_WITH_AES_256_GCM_SHA384": 173n,
                    "TLS_PSK_WITH_AES_128_CBC_SHA256": 174n,
                    "TLS_PSK_WITH_AES_256_CBC_SHA384": 175n,
                    "TLS_PSK_WITH_NULL_SHA256": 176n,
                    "TLS_PSK_WITH_NULL_SHA384": 177n,
                    "TLS_DHE_PSK_WITH_AES_128_CBC_SHA256": 178n,
                    "TLS_DHE_PSK_WITH_AES_256_CBC_SHA384": 179n,
                    "TLS_DHE_PSK_WITH_NULL_SHA256": 180n,
                    "TLS_DHE_PSK_WITH_NULL_SHA384": 181n,
                    "TLS_RSA_PSK_WITH_AES_128_CBC_SHA256": 182n,
                    "TLS_RSA_PSK_WITH_AES_256_CBC_SHA384": 183n,
                    "TLS_RSA_PSK_WITH_NULL_SHA256": 184n,
                    "TLS_RSA_PSK_WITH_NULL_SHA384": 185n,
                    "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256": 186n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256": 187n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256": 188n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256": 189n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256": 190n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256": 191n,
                    "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256": 192n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256": 193n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256": 194n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256": 195n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256": 196n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256": 197n,
                    "TLS_AES_128_GCM_SHA256": 4865n,
                    "TLS_AES_256_GCM_SHA384": 4866n,
                    "TLS_CHACHA20_POLY1305_SHA256": 4867n,
                    "TLS_AES_128_CCM_SHA256": 4868n,
                    "TLS_AES_128_CCM_8_SHA256": 4869n,
                    "TLS_ECDH_ECDSA_WITH_NULL_SHA": 49153n,
                    "TLS_ECDH_ECDSA_WITH_RC4_128_SHA": 49154n,
                    "TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA": 49155n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA": 49156n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA": 49157n,
                    "TLS_ECDHE_ECDSA_WITH_NULL_SHA": 49158n,
                    "TLS_ECDHE_ECDSA_WITH_RC4_128_SHA": 49159n,
                    "TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA": 49160n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA": 49161n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA": 49162n,
                    "TLS_ECDH_RSA_WITH_NULL_SHA": 49163n,
                    "TLS_ECDH_RSA_WITH_RC4_128_SHA": 49164n,
                    "TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA": 49165n,
                    "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA": 49166n,
                    "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA": 49167n,
                    "TLS_ECDHE_RSA_WITH_NULL_SHA": 49168n,
                    "TLS_ECDHE_RSA_WITH_RC4_128_SHA": 49169n,
                    "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA": 49170n,
                    "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA": 49171n,
                    "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA": 49172n,
                    "TLS_ECDH_anon_WITH_NULL_SHA": 49173n,
                    "TLS_ECDH_anon_WITH_RC4_128_SHA": 49174n,
                    "TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA": 49175n,
                    "TLS_ECDH_anon_WITH_AES_128_CBC_SHA": 49176n,
                    "TLS_ECDH_anon_WITH_AES_256_CBC_SHA": 49177n,
                    "TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA": 49178n,
                    "TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA": 49179n,
                    "TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA": 49180n,
                    "TLS_SRP_SHA_WITH_AES_128_CBC_SHA": 49181n,
                    "TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA": 49182n,
                    "TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA": 49183n,
                    "TLS_SRP_SHA_WITH_AES_256_CBC_SHA": 49184n,
                    "TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA": 49185n,
                    "TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA": 49186n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256": 49187n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384": 49188n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256": 49189n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384": 49190n,
                    "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256": 49191n,
                    "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384": 49192n,
                    "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256": 49193n,
                    "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384": 49194n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256": 49195n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384": 49196n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256": 49197n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384": 49198n,
                    "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256": 49199n,
                    "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384": 49200n,
                    "TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256": 49201n,
                    "TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384": 49202n,
                    "TLS_ECDHE_PSK_WITH_RC4_128_SHA": 49203n,
                    "TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA": 49204n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA": 49205n,
                    "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA": 49206n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256": 49207n,
                    "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384": 49208n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA": 49209n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA256": 49210n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA384": 49211n,
                    "TLS_RSA_WITH_ARIA_128_CBC_SHA256": 49212n,
                    "TLS_RSA_WITH_ARIA_256_CBC_SHA384": 49213n,
                    "TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256": 49214n,
                    "TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384": 49215n,
                    "TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256": 49216n,
                    "TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384": 49217n,
                    "TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256": 49218n,
                    "TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384": 49219n,
                    "TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256": 49220n,
                    "TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384": 49221n,
                    "TLS_DH_anon_WITH_ARIA_128_CBC_SHA256": 49222n,
                    "TLS_DH_anon_WITH_ARIA_256_CBC_SHA384": 49223n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256": 49224n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384": 49225n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256": 49226n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384": 49227n,
                    "TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256": 49228n,
                    "TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384": 49229n,
                    "TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256": 49230n,
                    "TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384": 49231n,
                    "TLS_RSA_WITH_ARIA_128_GCM_SHA256": 49232n,
                    "TLS_RSA_WITH_ARIA_256_GCM_SHA384": 49233n,
                    "TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256": 49234n,
                    "TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384": 49235n,
                    "TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256": 49236n,
                    "TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384": 49237n,
                    "TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256": 49238n,
                    "TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384": 49239n,
                    "TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256": 49240n,
                    "TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384": 49241n,
                    "TLS_DH_anon_WITH_ARIA_128_GCM_SHA256": 49242n,
                    "TLS_DH_anon_WITH_ARIA_256_GCM_SHA384": 49243n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256": 49244n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384": 49245n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256": 49246n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384": 49247n,
                    "TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256": 49248n,
                    "TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384": 49249n,
                    "TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256": 49250n,
                    "TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384": 49251n,
                    "TLS_PSK_WITH_ARIA_128_CBC_SHA256": 49252n,
                    "TLS_PSK_WITH_ARIA_256_CBC_SHA384": 49253n,
                    "TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256": 49254n,
                    "TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384": 49255n,
                    "TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256": 49256n,
                    "TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384": 49257n,
                    "TLS_PSK_WITH_ARIA_128_GCM_SHA256": 49258n,
                    "TLS_PSK_WITH_ARIA_256_GCM_SHA384": 49259n,
                    "TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256": 49260n,
                    "TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384": 49261n,
                    "TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256": 49262n,
                    "TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384": 49263n,
                    "TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256": 49264n,
                    "TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384": 49265n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256": 49266n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384": 49267n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256": 49268n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384": 49269n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256": 49270n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384": 49271n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256": 49272n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384": 49273n,
                    "TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49274n,
                    "TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49275n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49276n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49277n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49278n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49279n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256": 49280n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384": 49281n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256": 49282n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384": 49283n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256": 49284n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384": 49285n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256": 49286n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384": 49287n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256": 49288n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384": 49289n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49290n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49291n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49292n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49293n,
                    "TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49294n,
                    "TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49295n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49296n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49297n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49298n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49299n,
                    "TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49300n,
                    "TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49301n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49302n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49303n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49304n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49305n,
                    "TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49306n,
                    "TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49307n,
                    "TLS_RSA_WITH_AES_128_CCM": 49308n,
                    "TLS_RSA_WITH_AES_256_CCM": 49309n,
                    "TLS_DHE_RSA_WITH_AES_128_CCM": 49310n,
                    "TLS_DHE_RSA_WITH_AES_256_CCM": 49311n,
                    "TLS_RSA_WITH_AES_128_CCM_8": 49312n,
                    "TLS_RSA_WITH_AES_256_CCM_8": 49313n,
                    "TLS_DHE_RSA_WITH_AES_128_CCM_8": 49314n,
                    "TLS_DHE_RSA_WITH_AES_256_CCM_8": 49315n,
                    "TLS_PSK_WITH_AES_128_CCM": 49316n,
                    "TLS_PSK_WITH_AES_256_CCM": 49317n,
                    "TLS_DHE_PSK_WITH_AES_128_CCM": 49318n,
                    "TLS_DHE_PSK_WITH_AES_256_CCM": 49319n,
                    "TLS_PSK_WITH_AES_128_CCM_8": 49320n,
                    "TLS_PSK_WITH_AES_256_CCM_8": 49321n,
                    "TLS_PSK_DHE_WITH_AES_128_CCM_8": 49322n,
                    "TLS_PSK_DHE_WITH_AES_256_CCM_8": 49323n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CCM": 49324n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CCM": 49325n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8": 49326n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8": 49327n,
                    "TLS_ECCPWD_WITH_AES_128_GCM_SHA256": 49328n,
                    "TLS_ECCPWD_WITH_AES_256_GCM_SHA384": 49329n,
                    "TLS_ECCPWD_WITH_AES_128_CCM_SHA256": 49330n,
                    "TLS_ECCPWD_WITH_AES_256_CCM_SHA384": 49331n,
                    "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256": 52392n,
                    "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256": 52393n,
                    "TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256": 52394n,
                    "TLS_PSK_WITH_CHACHA20_POLY1305_SHA256": 52395n,
                    "TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256": 52396n,
                    "TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256": 52397n,
                    "TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256": 52398n,
                    "TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256": 53249n,
                    "TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384": 53250n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256": 53251n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256": 53253n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296343602)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296343602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296343602)
            
            //--TRIMMABLE-BOUNDARY-START(4296343602)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296343602)
            
            static $h = 1376306;
            static $z = 2;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.UInt16; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 589825,
  "l": [
//--TRIMMABLE-BOUNDARY-START(1078038167602),
    {
      "t": 1376306,
      "n": "TLS_NULL_WITH_NULL_NULL",
      "d": 1376306,
      "h": 1078038167602,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1078038167602),
//--TRIMMABLE-BOUNDARY-START(1391570780210),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_NULL_MD5",
      "d": 1376306,
      "h": 1391570780210,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1391570780210),
//--TRIMMABLE-BOUNDARY-START(1395865747506),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_NULL_SHA",
      "d": 1376306,
      "h": 1395865747506,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1395865747506),
//--TRIMMABLE-BOUNDARY-START(1202592219186),
    {
      "t": 1376306,
      "n": "TLS_RSA_EXPORT_WITH_RC4_40_MD5",
      "d": 1376306,
      "h": 1202592219186,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1202592219186),
//--TRIMMABLE-BOUNDARY-START(1404455682098),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_RC4_128_MD5",
      "d": 1376306,
      "h": 1404455682098,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1404455682098),
//--TRIMMABLE-BOUNDARY-START(1408750649394),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_RC4_128_SHA",
      "d": 1376306,
      "h": 1408750649394,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1408750649394),
//--TRIMMABLE-BOUNDARY-START(1198297251890),
    {
      "t": 1376306,
      "n": "TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5",
      "d": 1376306,
      "h": 1198297251890,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1198297251890),
//--TRIMMABLE-BOUNDARY-START(1387275812914),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_IDEA_CBC_SHA",
      "d": 1376306,
      "h": 1387275812914,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1387275812914),
//--TRIMMABLE-BOUNDARY-START(1194002284594),
    {
      "t": 1376306,
      "n": "TLS_RSA_EXPORT_WITH_DES40_CBC_SHA",
      "d": 1376306,
      "h": 1194002284594,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1194002284594),
//--TRIMMABLE-BOUNDARY-START(1382980845618),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_DES_CBC_SHA",
      "d": 1376306,
      "h": 1382980845618,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1382980845618),
//--TRIMMABLE-BOUNDARY-START(1292786532402),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 1292786532402,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1292786532402),
//--TRIMMABLE-BOUNDARY-START(124555427890),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA",
      "d": 1376306,
      "h": 124555427890,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(124555427890),
//--TRIMMABLE-BOUNDARY-START(201864839218),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_DES_CBC_SHA",
      "d": 1376306,
      "h": 201864839218,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(201864839218),
//--TRIMMABLE-BOUNDARY-START(128850395186),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 128850395186,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(128850395186),
//--TRIMMABLE-BOUNDARY-START(210454773810),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA",
      "d": 1376306,
      "h": 210454773810,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(210454773810),
//--TRIMMABLE-BOUNDARY-START(287764185138),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_DES_CBC_SHA",
      "d": 1376306,
      "h": 287764185138,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(287764185138),
//--TRIMMABLE-BOUNDARY-START(214749741106),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 214749741106,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(214749741106),
//--TRIMMABLE-BOUNDARY-START(296354119730),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA",
      "d": 1376306,
      "h": 296354119730,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(296354119730),
//--TRIMMABLE-BOUNDARY-START(373663531058),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_DES_CBC_SHA",
      "d": 1376306,
      "h": 373663531058,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(373663531058),
//--TRIMMABLE-BOUNDARY-START(300649087026),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 300649087026,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(300649087026),
//--TRIMMABLE-BOUNDARY-START(476742746162),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA",
      "d": 1376306,
      "h": 476742746162,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(476742746162),
//--TRIMMABLE-BOUNDARY-START(575526993970),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_DES_CBC_SHA",
      "d": 1376306,
      "h": 575526993970,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(575526993970),
//--TRIMMABLE-BOUNDARY-START(481037713458),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 481037713458,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(481037713458),
//--TRIMMABLE-BOUNDARY-START(34361114674),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_EXPORT_WITH_RC4_40_MD5",
      "d": 1376306,
      "h": 34361114674,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(34361114674),
//--TRIMMABLE-BOUNDARY-START(115965493298),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_RC4_128_MD5",
      "d": 1376306,
      "h": 115965493298,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(115965493298),
//--TRIMMABLE-BOUNDARY-START(30066147378),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA",
      "d": 1376306,
      "h": 30066147378,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(30066147378),
//--TRIMMABLE-BOUNDARY-START(111670526002),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_DES_CBC_SHA",
      "d": 1376306,
      "h": 111670526002,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(111670526002),
//--TRIMMABLE-BOUNDARY-START(38656081970),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 38656081970,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(38656081970),
//--TRIMMABLE-BOUNDARY-START(1056563331122),
    {
      "t": 1376306,
      "n": "TLS_KRB5_WITH_DES_CBC_SHA",
      "d": 1376306,
      "h": 1056563331122,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1056563331122),
//--TRIMMABLE-BOUNDARY-START(1047973396530),
    {
      "t": 1376306,
      "n": "TLS_KRB5_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 1047973396530,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1047973396530),
//--TRIMMABLE-BOUNDARY-START(1073743200306),
    {
      "t": 1376306,
      "n": "TLS_KRB5_WITH_RC4_128_SHA",
      "d": 1376306,
      "h": 1073743200306,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1073743200306),
//--TRIMMABLE-BOUNDARY-START(1065153265714),
    {
      "t": 1376306,
      "n": "TLS_KRB5_WITH_IDEA_CBC_SHA",
      "d": 1376306,
      "h": 1065153265714,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1065153265714),
//--TRIMMABLE-BOUNDARY-START(1052268363826),
    {
      "t": 1376306,
      "n": "TLS_KRB5_WITH_DES_CBC_MD5",
      "d": 1376306,
      "h": 1052268363826,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1052268363826),
//--TRIMMABLE-BOUNDARY-START(1043678429234),
    {
      "t": 1376306,
      "n": "TLS_KRB5_WITH_3DES_EDE_CBC_MD5",
      "d": 1376306,
      "h": 1043678429234,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1043678429234),
//--TRIMMABLE-BOUNDARY-START(1069448233010),
    {
      "t": 1376306,
      "n": "TLS_KRB5_WITH_RC4_128_MD5",
      "d": 1376306,
      "h": 1069448233010,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1069448233010),
//--TRIMMABLE-BOUNDARY-START(1060858298418),
    {
      "t": 1376306,
      "n": "TLS_KRB5_WITH_IDEA_CBC_MD5",
      "d": 1376306,
      "h": 1060858298418,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1060858298418),
//--TRIMMABLE-BOUNDARY-START(1022203592754),
    {
      "t": 1376306,
      "n": "TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA",
      "d": 1376306,
      "h": 1022203592754,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1022203592754),
//--TRIMMABLE-BOUNDARY-START(1030793527346),
    {
      "t": 1376306,
      "n": "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA",
      "d": 1376306,
      "h": 1030793527346,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1030793527346),
//--TRIMMABLE-BOUNDARY-START(1039383461938),
    {
      "t": 1376306,
      "n": "TLS_KRB5_EXPORT_WITH_RC4_40_SHA",
      "d": 1376306,
      "h": 1039383461938,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1039383461938),
//--TRIMMABLE-BOUNDARY-START(1017908625458),
    {
      "t": 1376306,
      "n": "TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5",
      "d": 1376306,
      "h": 1017908625458,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1017908625458),
//--TRIMMABLE-BOUNDARY-START(1026498560050),
    {
      "t": 1376306,
      "n": "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5",
      "d": 1376306,
      "h": 1026498560050,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1026498560050),
//--TRIMMABLE-BOUNDARY-START(1035088494642),
    {
      "t": 1376306,
      "n": "TLS_KRB5_EXPORT_WITH_RC4_40_MD5",
      "d": 1376306,
      "h": 1035088494642,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1035088494642),
//--TRIMMABLE-BOUNDARY-START(1176822415410),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_NULL_SHA",
      "d": 1376306,
      "h": 1176822415410,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1176822415410),
//--TRIMMABLE-BOUNDARY-START(459562876978),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_NULL_SHA",
      "d": 1376306,
      "h": 459562876978,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(459562876978),
//--TRIMMABLE-BOUNDARY-START(1275606663218),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_NULL_SHA",
      "d": 1376306,
      "h": 1275606663218,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1275606663218),
//--TRIMMABLE-BOUNDARY-START(1297081499698),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 1297081499698,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1297081499698),
//--TRIMMABLE-BOUNDARY-START(133145362482),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 133145362482,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(133145362482),
//--TRIMMABLE-BOUNDARY-START(219044708402),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 219044708402,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(219044708402),
//--TRIMMABLE-BOUNDARY-START(304944054322),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 304944054322,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(304944054322),
//--TRIMMABLE-BOUNDARY-START(485332680754),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 485332680754,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(485332680754),
//--TRIMMABLE-BOUNDARY-START(42951049266),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 42951049266,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(42951049266),
//--TRIMMABLE-BOUNDARY-START(1318556336178),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 1318556336178,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1318556336178),
//--TRIMMABLE-BOUNDARY-START(146030264370),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 146030264370,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(146030264370),
//--TRIMMABLE-BOUNDARY-START(231929610290),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 231929610290,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(231929610290),
//--TRIMMABLE-BOUNDARY-START(317828956210),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 317828956210,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(317828956210),
//--TRIMMABLE-BOUNDARY-START(506807517234),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 506807517234,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(506807517234),
//--TRIMMABLE-BOUNDARY-START(55835951154),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 55835951154,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(55835951154),
//--TRIMMABLE-BOUNDARY-START(1400160714802),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_NULL_SHA256",
      "d": 1376306,
      "h": 1400160714802,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1400160714802),
//--TRIMMABLE-BOUNDARY-START(1301376466994),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_AES_128_CBC_SHA256",
      "d": 1376306,
      "h": 1301376466994,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1301376466994),
//--TRIMMABLE-BOUNDARY-START(1322851303474),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_AES_256_CBC_SHA256",
      "d": 1376306,
      "h": 1322851303474,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1322851303474),
//--TRIMMABLE-BOUNDARY-START(137440329778),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_AES_128_CBC_SHA256",
      "d": 1376306,
      "h": 137440329778,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(137440329778),
//--TRIMMABLE-BOUNDARY-START(223339675698),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_AES_128_CBC_SHA256",
      "d": 1376306,
      "h": 223339675698,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(223339675698),
//--TRIMMABLE-BOUNDARY-START(309239021618),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_AES_128_CBC_SHA256",
      "d": 1376306,
      "h": 309239021618,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(309239021618),
//--TRIMMABLE-BOUNDARY-START(1357211041842),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA",
      "d": 1376306,
      "h": 1357211041842,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1357211041842),
//--TRIMMABLE-BOUNDARY-START(176095035442),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA",
      "d": 1376306,
      "h": 176095035442,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(176095035442),
//--TRIMMABLE-BOUNDARY-START(261994381362),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA",
      "d": 1376306,
      "h": 261994381362,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(261994381362),
//--TRIMMABLE-BOUNDARY-START(347893727282),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA",
      "d": 1376306,
      "h": 347893727282,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(347893727282),
//--TRIMMABLE-BOUNDARY-START(545462222898),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA",
      "d": 1376306,
      "h": 545462222898,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(545462222898),
//--TRIMMABLE-BOUNDARY-START(85900722226),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA",
      "d": 1376306,
      "h": 85900722226,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(85900722226),
//--TRIMMABLE-BOUNDARY-START(489627648050),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_AES_128_CBC_SHA256",
      "d": 1376306,
      "h": 489627648050,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(489627648050),
//--TRIMMABLE-BOUNDARY-START(150325231666),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_AES_256_CBC_SHA256",
      "d": 1376306,
      "h": 150325231666,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(150325231666),
//--TRIMMABLE-BOUNDARY-START(236224577586),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_AES_256_CBC_SHA256",
      "d": 1376306,
      "h": 236224577586,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(236224577586),
//--TRIMMABLE-BOUNDARY-START(322123923506),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_AES_256_CBC_SHA256",
      "d": 1376306,
      "h": 322123923506,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(322123923506),
//--TRIMMABLE-BOUNDARY-START(511102484530),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_AES_256_CBC_SHA256",
      "d": 1376306,
      "h": 511102484530,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(511102484530),
//--TRIMMABLE-BOUNDARY-START(47246016562),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_AES_128_CBC_SHA256",
      "d": 1376306,
      "h": 47246016562,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(47246016562),
//--TRIMMABLE-BOUNDARY-START(60130918450),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_AES_256_CBC_SHA256",
      "d": 1376306,
      "h": 60130918450,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(60130918450),
//--TRIMMABLE-BOUNDARY-START(1370095943730),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA",
      "d": 1376306,
      "h": 1370095943730,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1370095943730),
//--TRIMMABLE-BOUNDARY-START(188979937330),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA",
      "d": 1376306,
      "h": 188979937330,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(188979937330),
//--TRIMMABLE-BOUNDARY-START(274879283250),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA",
      "d": 1376306,
      "h": 274879283250,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(274879283250),
//--TRIMMABLE-BOUNDARY-START(360778629170),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA",
      "d": 1376306,
      "h": 360778629170,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(360778629170),
//--TRIMMABLE-BOUNDARY-START(558347124786),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA",
      "d": 1376306,
      "h": 558347124786,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(558347124786),
//--TRIMMABLE-BOUNDARY-START(98785624114),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA",
      "d": 1376306,
      "h": 98785624114,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(98785624114),
//--TRIMMABLE-BOUNDARY-START(1189707317298),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_RC4_128_SHA",
      "d": 1376306,
      "h": 1189707317298,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1189707317298),
//--TRIMMABLE-BOUNDARY-START(1090923069490),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 1090923069490,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1090923069490),
//--TRIMMABLE-BOUNDARY-START(1095218036786),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 1095218036786,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1095218036786),
//--TRIMMABLE-BOUNDARY-START(1116692873266),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 1116692873266,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1116692873266),
//--TRIMMABLE-BOUNDARY-START(472447778866),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_RC4_128_SHA",
      "d": 1376306,
      "h": 472447778866,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(472447778866),
//--TRIMMABLE-BOUNDARY-START(382253465650),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 382253465650,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(382253465650),
//--TRIMMABLE-BOUNDARY-START(386548432946),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 386548432946,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(386548432946),
//--TRIMMABLE-BOUNDARY-START(403728302130),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 403728302130,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(403728302130),
//--TRIMMABLE-BOUNDARY-START(1288491565106),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_RC4_128_SHA",
      "d": 1376306,
      "h": 1288491565106,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1288491565106),
//--TRIMMABLE-BOUNDARY-START(1206887186482),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 1206887186482,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1206887186482),
//--TRIMMABLE-BOUNDARY-START(1211182153778),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 1211182153778,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1211182153778),
//--TRIMMABLE-BOUNDARY-START(1224067055666),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 1224067055666,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1224067055666),
//--TRIMMABLE-BOUNDARY-START(1413045616690),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_SEED_CBC_SHA",
      "d": 1376306,
      "h": 1413045616690,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1413045616690),
//--TRIMMABLE-BOUNDARY-START(206159806514),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_SEED_CBC_SHA",
      "d": 1376306,
      "h": 206159806514,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(206159806514),
//--TRIMMABLE-BOUNDARY-START(292059152434),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_SEED_CBC_SHA",
      "d": 1376306,
      "h": 292059152434,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(292059152434),
//--TRIMMABLE-BOUNDARY-START(377958498354),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_SEED_CBC_SHA",
      "d": 1376306,
      "h": 377958498354,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(377958498354),
//--TRIMMABLE-BOUNDARY-START(579821961266),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_SEED_CBC_SHA",
      "d": 1376306,
      "h": 579821961266,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(579821961266),
//--TRIMMABLE-BOUNDARY-START(120260460594),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_SEED_CBC_SHA",
      "d": 1376306,
      "h": 120260460594,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(120260460594),
//--TRIMMABLE-BOUNDARY-START(1314261368882),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_AES_128_GCM_SHA256",
      "d": 1376306,
      "h": 1314261368882,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1314261368882),
//--TRIMMABLE-BOUNDARY-START(1335736205362),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_AES_256_GCM_SHA384",
      "d": 1376306,
      "h": 1335736205362,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1335736205362),
//--TRIMMABLE-BOUNDARY-START(502512549938),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_AES_128_GCM_SHA256",
      "d": 1376306,
      "h": 502512549938,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(502512549938),
//--TRIMMABLE-BOUNDARY-START(523987386418),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384",
      "d": 1376306,
      "h": 523987386418,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(523987386418),
//--TRIMMABLE-BOUNDARY-START(227634642994),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_AES_128_GCM_SHA256",
      "d": 1376306,
      "h": 227634642994,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(227634642994),
//--TRIMMABLE-BOUNDARY-START(240519544882),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_AES_256_GCM_SHA384",
      "d": 1376306,
      "h": 240519544882,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(240519544882),
//--TRIMMABLE-BOUNDARY-START(313533988914),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_AES_128_GCM_SHA256",
      "d": 1376306,
      "h": 313533988914,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(313533988914),
//--TRIMMABLE-BOUNDARY-START(326418890802),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_AES_256_GCM_SHA384",
      "d": 1376306,
      "h": 326418890802,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(326418890802),
//--TRIMMABLE-BOUNDARY-START(141735297074),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_AES_128_GCM_SHA256",
      "d": 1376306,
      "h": 141735297074,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(141735297074),
//--TRIMMABLE-BOUNDARY-START(154620198962),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_AES_256_GCM_SHA384",
      "d": 1376306,
      "h": 154620198962,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(154620198962),
//--TRIMMABLE-BOUNDARY-START(51540983858),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_AES_128_GCM_SHA256",
      "d": 1376306,
      "h": 51540983858,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(51540983858),
//--TRIMMABLE-BOUNDARY-START(64425885746),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_AES_256_GCM_SHA384",
      "d": 1376306,
      "h": 64425885746,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(64425885746),
//--TRIMMABLE-BOUNDARY-START(1112397905970),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_AES_128_GCM_SHA256",
      "d": 1376306,
      "h": 1112397905970,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1112397905970),
//--TRIMMABLE-BOUNDARY-START(1133872742450),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_AES_256_GCM_SHA384",
      "d": 1376306,
      "h": 1133872742450,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1133872742450),
//--TRIMMABLE-BOUNDARY-START(399433334834),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_AES_128_GCM_SHA256",
      "d": 1376306,
      "h": 399433334834,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(399433334834),
//--TRIMMABLE-BOUNDARY-START(416613204018),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_AES_256_GCM_SHA384",
      "d": 1376306,
      "h": 416613204018,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(416613204018),
//--TRIMMABLE-BOUNDARY-START(1219772088370),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_AES_128_GCM_SHA256",
      "d": 1376306,
      "h": 1219772088370,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1219772088370),
//--TRIMMABLE-BOUNDARY-START(1232656990258),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_AES_256_GCM_SHA384",
      "d": 1376306,
      "h": 1232656990258,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1232656990258),
//--TRIMMABLE-BOUNDARY-START(1099513004082),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_AES_128_CBC_SHA256",
      "d": 1376306,
      "h": 1099513004082,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1099513004082),
//--TRIMMABLE-BOUNDARY-START(1120987840562),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_AES_256_CBC_SHA384",
      "d": 1376306,
      "h": 1120987840562,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1120987840562),
//--TRIMMABLE-BOUNDARY-START(1181117382706),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_NULL_SHA256",
      "d": 1376306,
      "h": 1181117382706,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1181117382706),
//--TRIMMABLE-BOUNDARY-START(1185412350002),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_NULL_SHA384",
      "d": 1376306,
      "h": 1185412350002,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1185412350002),
//--TRIMMABLE-BOUNDARY-START(390843400242),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_AES_128_CBC_SHA256",
      "d": 1376306,
      "h": 390843400242,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(390843400242),
//--TRIMMABLE-BOUNDARY-START(408023269426),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_AES_256_CBC_SHA384",
      "d": 1376306,
      "h": 408023269426,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(408023269426),
//--TRIMMABLE-BOUNDARY-START(463857844274),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_NULL_SHA256",
      "d": 1376306,
      "h": 463857844274,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(463857844274),
//--TRIMMABLE-BOUNDARY-START(468152811570),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_NULL_SHA384",
      "d": 1376306,
      "h": 468152811570,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(468152811570),
//--TRIMMABLE-BOUNDARY-START(1215477121074),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_AES_128_CBC_SHA256",
      "d": 1376306,
      "h": 1215477121074,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1215477121074),
//--TRIMMABLE-BOUNDARY-START(1228362022962),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_AES_256_CBC_SHA384",
      "d": 1376306,
      "h": 1228362022962,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1228362022962),
//--TRIMMABLE-BOUNDARY-START(1279901630514),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_NULL_SHA256",
      "d": 1376306,
      "h": 1279901630514,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1279901630514),
//--TRIMMABLE-BOUNDARY-START(1284196597810),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_NULL_SHA384",
      "d": 1376306,
      "h": 1284196597810,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1284196597810),
//--TRIMMABLE-BOUNDARY-START(1361506009138),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 1361506009138,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1361506009138),
//--TRIMMABLE-BOUNDARY-START(180390002738),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 180390002738,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(180390002738),
//--TRIMMABLE-BOUNDARY-START(266289348658),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 266289348658,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(266289348658),
//--TRIMMABLE-BOUNDARY-START(352188694578),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 352188694578,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(352188694578),
//--TRIMMABLE-BOUNDARY-START(549757190194),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 549757190194,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(549757190194),
//--TRIMMABLE-BOUNDARY-START(90195689522),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 90195689522,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(90195689522),
//--TRIMMABLE-BOUNDARY-START(1374390911026),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256",
      "d": 1376306,
      "h": 1374390911026,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1374390911026),
//--TRIMMABLE-BOUNDARY-START(193274904626),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256",
      "d": 1376306,
      "h": 193274904626,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(193274904626),
//--TRIMMABLE-BOUNDARY-START(279174250546),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256",
      "d": 1376306,
      "h": 279174250546,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(279174250546),
//--TRIMMABLE-BOUNDARY-START(365073596466),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256",
      "d": 1376306,
      "h": 365073596466,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(365073596466),
//--TRIMMABLE-BOUNDARY-START(562642092082),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256",
      "d": 1376306,
      "h": 562642092082,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(562642092082),
//--TRIMMABLE-BOUNDARY-START(103080591410),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256",
      "d": 1376306,
      "h": 103080591410,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(103080591410),
//--TRIMMABLE-BOUNDARY-START(17181245490),
    {
      "t": 1376306,
      "n": "TLS_AES_128_GCM_SHA256",
      "d": 1376306,
      "h": 17181245490,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181245490),
//--TRIMMABLE-BOUNDARY-START(21476212786),
    {
      "t": 1376306,
      "n": "TLS_AES_256_GCM_SHA384",
      "d": 1376306,
      "h": 21476212786,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(21476212786),
//--TRIMMABLE-BOUNDARY-START(25771180082),
    {
      "t": 1376306,
      "n": "TLS_CHACHA20_POLY1305_SHA256",
      "d": 1376306,
      "h": 25771180082,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(25771180082),
//--TRIMMABLE-BOUNDARY-START(12886278194),
    {
      "t": 1376306,
      "n": "TLS_AES_128_CCM_SHA256",
      "d": 1376306,
      "h": 12886278194,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886278194),
//--TRIMMABLE-BOUNDARY-START(8591310898),
    {
      "t": 1376306,
      "n": "TLS_AES_128_CCM_8_SHA256",
      "d": 1376306,
      "h": 8591310898,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591310898),
//--TRIMMABLE-BOUNDARY-START(687196143666),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_NULL_SHA",
      "d": 1376306,
      "h": 687196143666,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(687196143666),
//--TRIMMABLE-BOUNDARY-START(691491110962),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_RC4_128_SHA",
      "d": 1376306,
      "h": 691491110962,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(691491110962),
//--TRIMMABLE-BOUNDARY-START(622771634226),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 622771634226,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(622771634226),
//--TRIMMABLE-BOUNDARY-START(627066601522),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 627066601522,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(627066601522),
//--TRIMMABLE-BOUNDARY-START(639951503410),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 639951503410,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(639951503410),
//--TRIMMABLE-BOUNDARY-START(854699868210),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_NULL_SHA",
      "d": 1376306,
      "h": 854699868210,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(854699868210),
//--TRIMMABLE-BOUNDARY-START(858994835506),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_RC4_128_SHA",
      "d": 1376306,
      "h": 858994835506,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(858994835506),
//--TRIMMABLE-BOUNDARY-START(768800522290),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 768800522290,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(768800522290),
//--TRIMMABLE-BOUNDARY-START(773095489586),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 773095489586,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(773095489586),
//--TRIMMABLE-BOUNDARY-START(794570326066),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 794570326066,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(794570326066),
//--TRIMMABLE-BOUNDARY-START(760210587698),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_NULL_SHA",
      "d": 1376306,
      "h": 760210587698,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(760210587698),
//--TRIMMABLE-BOUNDARY-START(764505554994),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_RC4_128_SHA",
      "d": 1376306,
      "h": 764505554994,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(764505554994),
//--TRIMMABLE-BOUNDARY-START(695786078258),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 695786078258,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(695786078258),
//--TRIMMABLE-BOUNDARY-START(700081045554),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 700081045554,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(700081045554),
//--TRIMMABLE-BOUNDARY-START(712965947442),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 712965947442,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(712965947442),
//--TRIMMABLE-BOUNDARY-START(1009318690866),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_NULL_SHA",
      "d": 1376306,
      "h": 1009318690866,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1009318690866),
//--TRIMMABLE-BOUNDARY-START(1013613658162),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_RC4_128_SHA",
      "d": 1376306,
      "h": 1013613658162,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1013613658162),
//--TRIMMABLE-BOUNDARY-START(940599214130),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 940599214130,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(940599214130),
//--TRIMMABLE-BOUNDARY-START(944894181426),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 944894181426,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(944894181426),
//--TRIMMABLE-BOUNDARY-START(957779083314),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 957779083314,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(957779083314),
//--TRIMMABLE-BOUNDARY-START(614181699634),
    {
      "t": 1376306,
      "n": "TLS_ECDH_anon_WITH_NULL_SHA",
      "d": 1376306,
      "h": 614181699634,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(614181699634),
//--TRIMMABLE-BOUNDARY-START(618476666930),
    {
      "t": 1376306,
      "n": "TLS_ECDH_anon_WITH_RC4_128_SHA",
      "d": 1376306,
      "h": 618476666930,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(618476666930),
//--TRIMMABLE-BOUNDARY-START(601296797746),
    {
      "t": 1376306,
      "n": "TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 601296797746,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(601296797746),
//--TRIMMABLE-BOUNDARY-START(605591765042),
    {
      "t": 1376306,
      "n": "TLS_ECDH_anon_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 605591765042,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(605591765042),
//--TRIMMABLE-BOUNDARY-START(609886732338),
    {
      "t": 1376306,
      "n": "TLS_ECDH_anon_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 609886732338,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(609886732338),
//--TRIMMABLE-BOUNDARY-START(1443110387762),
    {
      "t": 1376306,
      "n": "TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 1443110387762,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1443110387762),
//--TRIMMABLE-BOUNDARY-START(1430225485874),
    {
      "t": 1376306,
      "n": "TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 1430225485874,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1430225485874),
//--TRIMMABLE-BOUNDARY-START(1417340583986),
    {
      "t": 1376306,
      "n": "TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 1417340583986,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1417340583986),
//--TRIMMABLE-BOUNDARY-START(1447405355058),
    {
      "t": 1376306,
      "n": "TLS_SRP_SHA_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 1447405355058,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1447405355058),
//--TRIMMABLE-BOUNDARY-START(1434520453170),
    {
      "t": 1376306,
      "n": "TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 1434520453170,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1434520453170),
//--TRIMMABLE-BOUNDARY-START(1421635551282),
    {
      "t": 1376306,
      "n": "TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 1421635551282,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1421635551282),
//--TRIMMABLE-BOUNDARY-START(1451700322354),
    {
      "t": 1376306,
      "n": "TLS_SRP_SHA_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 1451700322354,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1451700322354),
//--TRIMMABLE-BOUNDARY-START(1438815420466),
    {
      "t": 1376306,
      "n": "TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 1438815420466,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1438815420466),
//--TRIMMABLE-BOUNDARY-START(1425930518578),
    {
      "t": 1376306,
      "n": "TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 1425930518578,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1425930518578),
//--TRIMMABLE-BOUNDARY-START(777390456882),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256",
      "d": 1376306,
      "h": 777390456882,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(777390456882),
//--TRIMMABLE-BOUNDARY-START(798865293362),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384",
      "d": 1376306,
      "h": 798865293362,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(798865293362),
//--TRIMMABLE-BOUNDARY-START(631361568818),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256",
      "d": 1376306,
      "h": 631361568818,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(631361568818),
//--TRIMMABLE-BOUNDARY-START(644246470706),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384",
      "d": 1376306,
      "h": 644246470706,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(644246470706),
//--TRIMMABLE-BOUNDARY-START(949189148722),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256",
      "d": 1376306,
      "h": 949189148722,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(949189148722),
//--TRIMMABLE-BOUNDARY-START(962074050610),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384",
      "d": 1376306,
      "h": 962074050610,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(962074050610),
//--TRIMMABLE-BOUNDARY-START(704376012850),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256",
      "d": 1376306,
      "h": 704376012850,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(704376012850),
//--TRIMMABLE-BOUNDARY-START(717260914738),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384",
      "d": 1376306,
      "h": 717260914738,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(717260914738),
//--TRIMMABLE-BOUNDARY-START(790275358770),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256",
      "d": 1376306,
      "h": 790275358770,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(790275358770),
//--TRIMMABLE-BOUNDARY-START(811750195250),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384",
      "d": 1376306,
      "h": 811750195250,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(811750195250),
//--TRIMMABLE-BOUNDARY-START(635656536114),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256",
      "d": 1376306,
      "h": 635656536114,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(635656536114),
//--TRIMMABLE-BOUNDARY-START(648541438002),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384",
      "d": 1376306,
      "h": 648541438002,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(648541438002),
//--TRIMMABLE-BOUNDARY-START(953484116018),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256",
      "d": 1376306,
      "h": 953484116018,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(953484116018),
//--TRIMMABLE-BOUNDARY-START(966369017906),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384",
      "d": 1376306,
      "h": 966369017906,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(966369017906),
//--TRIMMABLE-BOUNDARY-START(708670980146),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256",
      "d": 1376306,
      "h": 708670980146,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(708670980146),
//--TRIMMABLE-BOUNDARY-START(721555882034),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384",
      "d": 1376306,
      "h": 721555882034,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(721555882034),
//--TRIMMABLE-BOUNDARY-START(936304246834),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_RC4_128_SHA",
      "d": 1376306,
      "h": 936304246834,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(936304246834),
//--TRIMMABLE-BOUNDARY-START(863289802802),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA",
      "d": 1376306,
      "h": 863289802802,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(863289802802),
//--TRIMMABLE-BOUNDARY-START(867584770098),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA",
      "d": 1376306,
      "h": 867584770098,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(867584770098),
//--TRIMMABLE-BOUNDARY-START(889059606578),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA",
      "d": 1376306,
      "h": 889059606578,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(889059606578),
//--TRIMMABLE-BOUNDARY-START(871879737394),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256",
      "d": 1376306,
      "h": 871879737394,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(871879737394),
//--TRIMMABLE-BOUNDARY-START(893354573874),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384",
      "d": 1376306,
      "h": 893354573874,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(893354573874),
//--TRIMMABLE-BOUNDARY-START(923419344946),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_NULL_SHA",
      "d": 1376306,
      "h": 923419344946,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(923419344946),
//--TRIMMABLE-BOUNDARY-START(927714312242),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_NULL_SHA256",
      "d": 1376306,
      "h": 927714312242,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(927714312242),
//--TRIMMABLE-BOUNDARY-START(932009279538),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_NULL_SHA384",
      "d": 1376306,
      "h": 932009279538,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(932009279538),
//--TRIMMABLE-BOUNDARY-START(1340031172658),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_ARIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 1340031172658,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1340031172658),
//--TRIMMABLE-BOUNDARY-START(1348621107250),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_ARIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 1348621107250,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1348621107250),
//--TRIMMABLE-BOUNDARY-START(158915166258),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 158915166258,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(158915166258),
//--TRIMMABLE-BOUNDARY-START(167505100850),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 167505100850,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(167505100850),
//--TRIMMABLE-BOUNDARY-START(244814512178),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 244814512178,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(244814512178),
//--TRIMMABLE-BOUNDARY-START(253404446770),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 253404446770,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(253404446770),
//--TRIMMABLE-BOUNDARY-START(330713858098),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 330713858098,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(330713858098),
//--TRIMMABLE-BOUNDARY-START(339303792690),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 339303792690,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(339303792690),
//--TRIMMABLE-BOUNDARY-START(528282353714),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 528282353714,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(528282353714),
//--TRIMMABLE-BOUNDARY-START(536872288306),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 536872288306,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(536872288306),
//--TRIMMABLE-BOUNDARY-START(68720853042),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_ARIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 68720853042,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(68720853042),
//--TRIMMABLE-BOUNDARY-START(77310787634),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_ARIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 77310787634,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(77310787634),
//--TRIMMABLE-BOUNDARY-START(816045162546),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 816045162546,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(816045162546),
//--TRIMMABLE-BOUNDARY-START(824635097138),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 824635097138,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(824635097138),
//--TRIMMABLE-BOUNDARY-START(652836405298),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 652836405298,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(652836405298),
//--TRIMMABLE-BOUNDARY-START(661426339890),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 661426339890,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(661426339890),
//--TRIMMABLE-BOUNDARY-START(970663985202),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 970663985202,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(970663985202),
//--TRIMMABLE-BOUNDARY-START(979253919794),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 979253919794,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(979253919794),
//--TRIMMABLE-BOUNDARY-START(725850849330),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 725850849330,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(725850849330),
//--TRIMMABLE-BOUNDARY-START(734440783922),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 734440783922,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(734440783922),
//--TRIMMABLE-BOUNDARY-START(1344326139954),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_ARIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 1344326139954,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1344326139954),
//--TRIMMABLE-BOUNDARY-START(1352916074546),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_ARIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 1352916074546,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1352916074546),
//--TRIMMABLE-BOUNDARY-START(532577321010),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 532577321010,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(532577321010),
//--TRIMMABLE-BOUNDARY-START(541167255602),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 541167255602,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(541167255602),
//--TRIMMABLE-BOUNDARY-START(249109479474),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 249109479474,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(249109479474),
//--TRIMMABLE-BOUNDARY-START(257699414066),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 257699414066,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(257699414066),
//--TRIMMABLE-BOUNDARY-START(335008825394),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 335008825394,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(335008825394),
//--TRIMMABLE-BOUNDARY-START(343598759986),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 343598759986,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(343598759986),
//--TRIMMABLE-BOUNDARY-START(163210133554),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 163210133554,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(163210133554),
//--TRIMMABLE-BOUNDARY-START(171800068146),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 171800068146,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(171800068146),
//--TRIMMABLE-BOUNDARY-START(73015820338),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_ARIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 73015820338,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(73015820338),
//--TRIMMABLE-BOUNDARY-START(81605754930),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_ARIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 81605754930,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(81605754930),
//--TRIMMABLE-BOUNDARY-START(820340129842),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 820340129842,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(820340129842),
//--TRIMMABLE-BOUNDARY-START(828930064434),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 828930064434,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(828930064434),
//--TRIMMABLE-BOUNDARY-START(657131372594),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 657131372594,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(657131372594),
//--TRIMMABLE-BOUNDARY-START(665721307186),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 665721307186,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(665721307186),
//--TRIMMABLE-BOUNDARY-START(974958952498),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 974958952498,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(974958952498),
//--TRIMMABLE-BOUNDARY-START(983548887090),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 983548887090,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(983548887090),
//--TRIMMABLE-BOUNDARY-START(730145816626),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 730145816626,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(730145816626),
//--TRIMMABLE-BOUNDARY-START(738735751218),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 738735751218,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(738735751218),
//--TRIMMABLE-BOUNDARY-START(1138167709746),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_ARIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 1138167709746,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1138167709746),
//--TRIMMABLE-BOUNDARY-START(1146757644338),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_ARIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 1146757644338,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1146757644338),
//--TRIMMABLE-BOUNDARY-START(420908171314),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 420908171314,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(420908171314),
//--TRIMMABLE-BOUNDARY-START(429498105906),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 429498105906,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(429498105906),
//--TRIMMABLE-BOUNDARY-START(1236951957554),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 1236951957554,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1236951957554),
//--TRIMMABLE-BOUNDARY-START(1245541892146),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 1245541892146,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1245541892146),
//--TRIMMABLE-BOUNDARY-START(1142462677042),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_ARIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 1142462677042,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1142462677042),
//--TRIMMABLE-BOUNDARY-START(1151052611634),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_ARIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 1151052611634,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1151052611634),
//--TRIMMABLE-BOUNDARY-START(425203138610),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 425203138610,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(425203138610),
//--TRIMMABLE-BOUNDARY-START(433793073202),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 433793073202,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(433793073202),
//--TRIMMABLE-BOUNDARY-START(1241246924850),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 1241246924850,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1241246924850),
//--TRIMMABLE-BOUNDARY-START(1249836859442),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 1249836859442,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1249836859442),
//--TRIMMABLE-BOUNDARY-START(901944508466),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 901944508466,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(901944508466),
//--TRIMMABLE-BOUNDARY-START(906239475762),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 906239475762,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(906239475762),
//--TRIMMABLE-BOUNDARY-START(833225031730),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 833225031730,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(833225031730),
//--TRIMMABLE-BOUNDARY-START(841814966322),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 841814966322,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(841814966322),
//--TRIMMABLE-BOUNDARY-START(670016274482),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 670016274482,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(670016274482),
//--TRIMMABLE-BOUNDARY-START(678606209074),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 678606209074,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(678606209074),
//--TRIMMABLE-BOUNDARY-START(987843854386),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 987843854386,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(987843854386),
//--TRIMMABLE-BOUNDARY-START(996433788978),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 996433788978,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(996433788978),
//--TRIMMABLE-BOUNDARY-START(743030718514),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 743030718514,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(743030718514),
//--TRIMMABLE-BOUNDARY-START(751620653106),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 751620653106,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(751620653106),
//--TRIMMABLE-BOUNDARY-START(1365800976434),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 1365800976434,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1365800976434),
//--TRIMMABLE-BOUNDARY-START(1378685878322),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 1378685878322,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1378685878322),
//--TRIMMABLE-BOUNDARY-START(554052157490),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 554052157490,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(554052157490),
//--TRIMMABLE-BOUNDARY-START(566937059378),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 566937059378,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(566937059378),
//--TRIMMABLE-BOUNDARY-START(270584315954),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 270584315954,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(270584315954),
//--TRIMMABLE-BOUNDARY-START(283469217842),
    {
      "t": 1376306,
      "n": "TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 283469217842,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(283469217842),
//--TRIMMABLE-BOUNDARY-START(356483661874),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 356483661874,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(356483661874),
//--TRIMMABLE-BOUNDARY-START(369368563762),
    {
      "t": 1376306,
      "n": "TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 369368563762,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(369368563762),
//--TRIMMABLE-BOUNDARY-START(184684970034),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 184684970034,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(184684970034),
//--TRIMMABLE-BOUNDARY-START(197569871922),
    {
      "t": 1376306,
      "n": "TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 197569871922,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(197569871922),
//--TRIMMABLE-BOUNDARY-START(94490656818),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 94490656818,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(94490656818),
//--TRIMMABLE-BOUNDARY-START(107375558706),
    {
      "t": 1376306,
      "n": "TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 107375558706,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(107375558706),
//--TRIMMABLE-BOUNDARY-START(837519999026),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 837519999026,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(837519999026),
//--TRIMMABLE-BOUNDARY-START(846109933618),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 846109933618,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(846109933618),
//--TRIMMABLE-BOUNDARY-START(674311241778),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 674311241778,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(674311241778),
//--TRIMMABLE-BOUNDARY-START(682901176370),
    {
      "t": 1376306,
      "n": "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 682901176370,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(682901176370),
//--TRIMMABLE-BOUNDARY-START(992138821682),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 992138821682,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(992138821682),
//--TRIMMABLE-BOUNDARY-START(1000728756274),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 1000728756274,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1000728756274),
//--TRIMMABLE-BOUNDARY-START(747325685810),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 747325685810,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(747325685810),
//--TRIMMABLE-BOUNDARY-START(755915620402),
    {
      "t": 1376306,
      "n": "TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 755915620402,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(755915620402),
//--TRIMMABLE-BOUNDARY-START(1159642546226),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 1159642546226,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1159642546226),
//--TRIMMABLE-BOUNDARY-START(1168232480818),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 1168232480818,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1168232480818),
//--TRIMMABLE-BOUNDARY-START(442383007794),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 442383007794,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(442383007794),
//--TRIMMABLE-BOUNDARY-START(450972942386),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 450972942386,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(450972942386),
//--TRIMMABLE-BOUNDARY-START(1258426794034),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256",
      "d": 1376306,
      "h": 1258426794034,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1258426794034),
//--TRIMMABLE-BOUNDARY-START(1267016728626),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384",
      "d": 1376306,
      "h": 1267016728626,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1267016728626),
//--TRIMMABLE-BOUNDARY-START(1155347578930),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 1155347578930,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1155347578930),
//--TRIMMABLE-BOUNDARY-START(1163937513522),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 1163937513522,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1163937513522),
//--TRIMMABLE-BOUNDARY-START(438088040498),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 438088040498,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(438088040498),
//--TRIMMABLE-BOUNDARY-START(446677975090),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 446677975090,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(446677975090),
//--TRIMMABLE-BOUNDARY-START(1254131826738),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 1254131826738,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1254131826738),
//--TRIMMABLE-BOUNDARY-START(1262721761330),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 1262721761330,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1262721761330),
//--TRIMMABLE-BOUNDARY-START(910534443058),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256",
      "d": 1376306,
      "h": 910534443058,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(910534443058),
//--TRIMMABLE-BOUNDARY-START(914829410354),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384",
      "d": 1376306,
      "h": 914829410354,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(914829410354),
//--TRIMMABLE-BOUNDARY-START(1305671434290),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_AES_128_CCM",
      "d": 1376306,
      "h": 1305671434290,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1305671434290),
//--TRIMMABLE-BOUNDARY-START(1327146270770),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_AES_256_CCM",
      "d": 1376306,
      "h": 1327146270770,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1327146270770),
//--TRIMMABLE-BOUNDARY-START(493922615346),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_AES_128_CCM",
      "d": 1376306,
      "h": 493922615346,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(493922615346),
//--TRIMMABLE-BOUNDARY-START(515397451826),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_AES_256_CCM",
      "d": 1376306,
      "h": 515397451826,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(515397451826),
//--TRIMMABLE-BOUNDARY-START(1309966401586),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_AES_128_CCM_8",
      "d": 1376306,
      "h": 1309966401586,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1309966401586),
//--TRIMMABLE-BOUNDARY-START(1331441238066),
    {
      "t": 1376306,
      "n": "TLS_RSA_WITH_AES_256_CCM_8",
      "d": 1376306,
      "h": 1331441238066,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1331441238066),
//--TRIMMABLE-BOUNDARY-START(498217582642),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_AES_128_CCM_8",
      "d": 1376306,
      "h": 498217582642,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(498217582642),
//--TRIMMABLE-BOUNDARY-START(519692419122),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_AES_256_CCM_8",
      "d": 1376306,
      "h": 519692419122,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(519692419122),
//--TRIMMABLE-BOUNDARY-START(1103807971378),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_AES_128_CCM",
      "d": 1376306,
      "h": 1103807971378,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1103807971378),
//--TRIMMABLE-BOUNDARY-START(1125282807858),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_AES_256_CCM",
      "d": 1376306,
      "h": 1125282807858,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1125282807858),
//--TRIMMABLE-BOUNDARY-START(395138367538),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_AES_128_CCM",
      "d": 1376306,
      "h": 395138367538,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(395138367538),
//--TRIMMABLE-BOUNDARY-START(412318236722),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_AES_256_CCM",
      "d": 1376306,
      "h": 412318236722,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(412318236722),
//--TRIMMABLE-BOUNDARY-START(1108102938674),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_AES_128_CCM_8",
      "d": 1376306,
      "h": 1108102938674,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1108102938674),
//--TRIMMABLE-BOUNDARY-START(1129577775154),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_AES_256_CCM_8",
      "d": 1376306,
      "h": 1129577775154,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1129577775154),
//--TRIMMABLE-BOUNDARY-START(1082333134898),
    {
      "t": 1376306,
      "n": "TLS_PSK_DHE_WITH_AES_128_CCM_8",
      "d": 1376306,
      "h": 1082333134898,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1082333134898),
//--TRIMMABLE-BOUNDARY-START(1086628102194),
    {
      "t": 1376306,
      "n": "TLS_PSK_DHE_WITH_AES_256_CCM_8",
      "d": 1376306,
      "h": 1086628102194,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1086628102194),
//--TRIMMABLE-BOUNDARY-START(781685424178),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_AES_128_CCM",
      "d": 1376306,
      "h": 781685424178,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(781685424178),
//--TRIMMABLE-BOUNDARY-START(803160260658),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_AES_256_CCM",
      "d": 1376306,
      "h": 803160260658,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(803160260658),
//--TRIMMABLE-BOUNDARY-START(785980391474),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8",
      "d": 1376306,
      "h": 785980391474,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(785980391474),
//--TRIMMABLE-BOUNDARY-START(807455227954),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8",
      "d": 1376306,
      "h": 807455227954,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(807455227954),
//--TRIMMABLE-BOUNDARY-START(588411895858),
    {
      "t": 1376306,
      "n": "TLS_ECCPWD_WITH_AES_128_GCM_SHA256",
      "d": 1376306,
      "h": 588411895858,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(588411895858),
//--TRIMMABLE-BOUNDARY-START(597001830450),
    {
      "t": 1376306,
      "n": "TLS_ECCPWD_WITH_AES_256_GCM_SHA384",
      "d": 1376306,
      "h": 597001830450,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(597001830450),
//--TRIMMABLE-BOUNDARY-START(584116928562),
    {
      "t": 1376306,
      "n": "TLS_ECCPWD_WITH_AES_128_CCM_SHA256",
      "d": 1376306,
      "h": 584116928562,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(584116928562),
//--TRIMMABLE-BOUNDARY-START(592706863154),
    {
      "t": 1376306,
      "n": "TLS_ECCPWD_WITH_AES_256_CCM_SHA384",
      "d": 1376306,
      "h": 592706863154,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(592706863154),
//--TRIMMABLE-BOUNDARY-START(1005023723570),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256",
      "d": 1376306,
      "h": 1005023723570,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1005023723570),
//--TRIMMABLE-BOUNDARY-START(850404900914),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256",
      "d": 1376306,
      "h": 850404900914,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(850404900914),
//--TRIMMABLE-BOUNDARY-START(571232026674),
    {
      "t": 1376306,
      "n": "TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256",
      "d": 1376306,
      "h": 571232026674,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(571232026674),
//--TRIMMABLE-BOUNDARY-START(1172527448114),
    {
      "t": 1376306,
      "n": "TLS_PSK_WITH_CHACHA20_POLY1305_SHA256",
      "d": 1376306,
      "h": 1172527448114,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1172527448114),
//--TRIMMABLE-BOUNDARY-START(919124377650),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256",
      "d": 1376306,
      "h": 919124377650,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(919124377650),
//--TRIMMABLE-BOUNDARY-START(455267909682),
    {
      "t": 1376306,
      "n": "TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256",
      "d": 1376306,
      "h": 455267909682,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(455267909682),
//--TRIMMABLE-BOUNDARY-START(1271311695922),
    {
      "t": 1376306,
      "n": "TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256",
      "d": 1376306,
      "h": 1271311695922,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(1271311695922),
//--TRIMMABLE-BOUNDARY-START(884764639282),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256",
      "d": 1376306,
      "h": 884764639282,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(884764639282),
//--TRIMMABLE-BOUNDARY-START(897649541170),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384",
      "d": 1376306,
      "h": 897649541170,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(897649541170),
//--TRIMMABLE-BOUNDARY-START(876174704690),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256",
      "d": 1376306,
      "h": 876174704690,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(876174704690),
//--TRIMMABLE-BOUNDARY-START(880469671986),
    {
      "t": 1376306,
      "n": "TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256",
      "d": 1376306,
      "h": 880469671986,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(880469671986)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296343602),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1376306,
      "h": 4296343602,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296343602)
  ],
  "h": 1376306,
  "a": [
    {
      "t": 54984705,
      "c": 8644919297,
      "a": [
        {
          "v": false,
          "t": 262145
        }
      ]
    }
  ]
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.TlsCipherSuite`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}TlsCipherSuite`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1376306)
        
        

        //--TRIMMABLE-BOUNDARY-START(1572914)
        $asm.$str(`$snsc.SSAE.PolicyEnforcement`, ($self) => class PolicyEnforcement extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static Never = 0;
            static WhenSupported = 1;
            static Always = 2;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1572914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "Never": 0n,
                    "WhenSupported": 1n,
                    "Always": 2n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296540210)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296540210);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296540210)
            
            //--TRIMMABLE-BOUNDARY-START(4296540210)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296540210)
            
            static $h = 1572914;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(12886474802),
    {
      "t": 1572914,
      "n": "Never",
      "d": 1572914,
      "h": 12886474802,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886474802),
//--TRIMMABLE-BOUNDARY-START(17181442098),
    {
      "t": 1572914,
      "n": "WhenSupported",
      "d": 1572914,
      "h": 17181442098,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(17181442098),
//--TRIMMABLE-BOUNDARY-START(8591507506),
    {
      "t": 1572914,
      "n": "Always",
      "d": 1572914,
      "h": 8591507506,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591507506)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296540210),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1572914,
      "h": 4296540210,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296540210)
  ],
  "h": 1572914
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Authentication.ExtendedProtection.PolicyEnforcement`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Authentication${separator}ExtendedProtection${separator}PolicyEnforcement`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1572914)
        
        

        //--TRIMMABLE-BOUNDARY-START(1638450)
        $asm.$str(`$snsc.SSAE.ProtectionScenario`, ($self) => class ProtectionScenario extends $.$$.S.Enum$$$($self, $.$$.S.UInt32)
        {
            static TransportSelected = 0;
            static TrustedProxy = 1;
            static $map;
            static get Map()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(1638450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this.$map ??= 
                {
                    "TransportSelected": 0n,
                    "TrustedProxy": 1n
                };
            }
            //--TRIMMABLE-BOUNDARY-START(4296605746)
            //default constructor overload
            $ctor$3()
            {
                super.$ctor$2();
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(4296605746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296605746)
            
            //--TRIMMABLE-BOUNDARY-START(4296605746)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$3();
            }
            //--TRIMMABLE-BOUNDARY-END(4296605746)
            
            static $h = 1638450;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.Enum; }
            static get $eut() { return $.$$.S.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "u": 655361,
  "l": [
//--TRIMMABLE-BOUNDARY-START(8591573042),
    {
      "t": 1638450,
      "n": "TransportSelected",
      "d": 1638450,
      "h": 8591573042,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(8591573042),
//--TRIMMABLE-BOUNDARY-START(12886540338),
    {
      "t": 1638450,
      "n": "TrustedProxy",
      "d": 1638450,
      "h": 12886540338,
      "f": 4194337
    },
//--TRIMMABLE-BOUNDARY-END(12886540338)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(4296605746),
    {
      "n": ".ctor",
      "o": "$ctor$3",
      "d": 1638450,
      "h": 4296605746,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296605746)
  ],
  "h": 1638450
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IComparable, $.$$.S.ISpanFormattable, $.$$.S.IFormattable, $.$$.S.IConvertible ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Authentication.ExtendedProtection.ProtectionScenario`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Authentication${separator}ExtendedProtection${separator}ProtectionScenario`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1638450)
        
        

        //--TRIMMABLE-BOUNDARY-START(589874)
        $asm.$cls(`$snsc.SNS.NegotiateStream`, ($self) => class NegotiateStream extends $.$snsc.SNS.AuthenticatedStream
        {
            //--TRIMMABLE-BOUNDARY-START(8590524466)
            $ctor$5(/*System.IO.Stream*/ innerStream)
            {
                super.$ctor$3(null, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8590524466);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8590524466)
            
            //--TRIMMABLE-BOUNDARY-START(4295557170)
            $ctor$4(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$3(null, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4295557170);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4295557170)
            
            //--TRIMMABLE-BOUNDARY-START(137439543346)
            /*bool */ get CanRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274118194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(137439543346)
            
            //--TRIMMABLE-BOUNDARY-START(141734510642)
            /*bool */ get CanSeek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(201864052786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(141734510642)
            
            //--TRIMMABLE-BOUNDARY-START(146029477938)
            /*bool */ get CanTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(210453987378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(146029477938)
            
            //--TRIMMABLE-BOUNDARY-START(150324445234)
            /*bool */ get CanWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(219043921970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(150324445234)
            
            //--TRIMMABLE-BOUNDARY-START(317828169778)
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(227633856562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(317828169778)
            
            //--TRIMMABLE-BOUNDARY-START(322123137074)
            /*bool */ get IsAuthenticated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(236223791154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(322123137074)
            
            //--TRIMMABLE-BOUNDARY-START(326418104370)
            /*bool */ get IsEncrypted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(244813725746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(326418104370)
            
            //--TRIMMABLE-BOUNDARY-START(330713071666)
            /*bool */ get IsMutuallyAuthenticated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(253403660338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(330713071666)
            
            //--TRIMMABLE-BOUNDARY-START(335008038962)
            /*bool */ get IsServer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(261993594930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(335008038962)
            
            //--TRIMMABLE-BOUNDARY-START(339303006258)
            /*bool */ get IsSigned()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(270583529522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(339303006258)
            
            //--TRIMMABLE-BOUNDARY-START(343597973554)
            /*long */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(279173464114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(343597973554)
            
            //--TRIMMABLE-BOUNDARY-START(347892940850)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(287763398706);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(382252679218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(347892940850)
            
            //--TRIMMABLE-BOUNDARY-START(365072810034)
            /*int */ get ReadTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(296353333298);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(390842613810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(365072810034)
            
            //--TRIMMABLE-BOUNDARY-START(369367777330)
            /*System.Security.Principal.IIdentity */ get RemoteIdentity()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(304943267890);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(369367777330)
            
            //--TRIMMABLE-BOUNDARY-START(420907384882)
            /*int */ get WriteTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(313533202482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(399432548402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(420907384882)
            
            //--TRIMMABLE-BOUNDARY-START(12885491762)
            /*void */ AuthenticateAsClient()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(12885491762);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(12885491762)
            
            //--TRIMMABLE-BOUNDARY-START(21475426354)
            /*void */ AuthenticateAsClient$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(21475426354);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(21475426354)
            
            //--TRIMMABLE-BOUNDARY-START(17180459058)
            /*void */ AuthenticateAsClient$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(17180459058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(17180459058)
            
            //--TRIMMABLE-BOUNDARY-START(30065360946)
            /*void */ AuthenticateAsClient$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30065360946);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30065360946)
            
            //--TRIMMABLE-BOUNDARY-START(25770393650)
            /*void */ AuthenticateAsClient$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25770393650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25770393650)
            
            //--TRIMMABLE-BOUNDARY-START(34360328242)
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360328242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(34360328242)
            
            //--TRIMMABLE-BOUNDARY-START(42950262834)
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950262834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950262834)
            
            //--TRIMMABLE-BOUNDARY-START(38655295538)
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655295538);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(38655295538)
            
            //--TRIMMABLE-BOUNDARY-START(51540197426)
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540197426);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51540197426)
            
            //--TRIMMABLE-BOUNDARY-START(47245230130)
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245230130);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245230130)
            
            //--TRIMMABLE-BOUNDARY-START(55835164722)
            /*void */ AuthenticateAsServer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835164722);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(55835164722)
            
            //--TRIMMABLE-BOUNDARY-START(60130132018)
            /*void */ AuthenticateAsServer$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130132018);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60130132018)
            
            //--TRIMMABLE-BOUNDARY-START(64425099314)
            /*void */ AuthenticateAsServer$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425099314);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(64425099314)
            
            //--TRIMMABLE-BOUNDARY-START(68720066610)
            /*void */ AuthenticateAsServer$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720066610);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(68720066610)
            
            //--TRIMMABLE-BOUNDARY-START(73015033906)
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015033906);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(73015033906)
            
            //--TRIMMABLE-BOUNDARY-START(77310001202)
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310001202);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77310001202)
            
            //--TRIMMABLE-BOUNDARY-START(81604968498)
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81604968498);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81604968498)
            
            //--TRIMMABLE-BOUNDARY-START(85899935794)
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85899935794);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(85899935794)
            
            //--TRIMMABLE-BOUNDARY-START(90194903090)
            /*System.IAsyncResult */ BeginAuthenticateAsClient(/*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90194903090);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90194903090)
            
            //--TRIMMABLE-BOUNDARY-START(94489870386)
            /*System.IAsyncResult */ BeginAuthenticateAsClient$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94489870386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(94489870386)
            
            //--TRIMMABLE-BOUNDARY-START(98784837682)
            /*System.IAsyncResult */ BeginAuthenticateAsClient$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98784837682);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(98784837682)
            
            //--TRIMMABLE-BOUNDARY-START(103079804978)
            /*System.IAsyncResult */ BeginAuthenticateAsClient$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103079804978);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103079804978)
            
            //--TRIMMABLE-BOUNDARY-START(107374772274)
            /*System.IAsyncResult */ BeginAuthenticateAsClient$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107374772274);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(107374772274)
            
            //--TRIMMABLE-BOUNDARY-START(111669739570)
            /*System.IAsyncResult */ BeginAuthenticateAsServer(/*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111669739570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(111669739570)
            
            //--TRIMMABLE-BOUNDARY-START(115964706866)
            /*System.IAsyncResult */ BeginAuthenticateAsServer$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115964706866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115964706866)
            
            //--TRIMMABLE-BOUNDARY-START(120259674162)
            /*System.IAsyncResult */ BeginAuthenticateAsServer$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120259674162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120259674162)
            
            //--TRIMMABLE-BOUNDARY-START(124554641458)
            /*System.IAsyncResult */ BeginAuthenticateAsServer$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124554641458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(124554641458)
            
            //--TRIMMABLE-BOUNDARY-START(128849608754)
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128849608754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(128849608754)
            
            //--TRIMMABLE-BOUNDARY-START(133144576050)
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(133144576050);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(133144576050)
            
            //--TRIMMABLE-BOUNDARY-START(154619412530)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(154619412530);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(154619412530)
            
            //--TRIMMABLE-BOUNDARY-START(158914379826)
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(158914379826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(158914379826)
            
            //--TRIMMABLE-BOUNDARY-START(163209347122)
            /*void */ EndAuthenticateAsClient(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163209347122);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(163209347122)
            
            //--TRIMMABLE-BOUNDARY-START(167504314418)
            /*void */ EndAuthenticateAsServer(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504314418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(167504314418)
            
            //--TRIMMABLE-BOUNDARY-START(171799281714)
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799281714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(171799281714)
            
            //--TRIMMABLE-BOUNDARY-START(176094249010)
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094249010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(176094249010)
            
            //--TRIMMABLE-BOUNDARY-START(180389216306)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389216306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(180389216306)
            
            //--TRIMMABLE-BOUNDARY-START(184684183602)
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684183602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(184684183602)
            
            //--TRIMMABLE-BOUNDARY-START(352187908146)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352187908146);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(352187908146)
            
            //--TRIMMABLE-BOUNDARY-START(356482875442)
            /*System.Threading.Tasks.Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(356482875442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(356482875442)
            
            //--TRIMMABLE-BOUNDARY-START(360777842738)
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360777842738);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(360777842738)
            
            //--TRIMMABLE-BOUNDARY-START(373662744626)
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(373662744626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(373662744626)
            
            //--TRIMMABLE-BOUNDARY-START(403727515698)
            /*void */ SetLength(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403727515698);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(403727515698)
            
            //--TRIMMABLE-BOUNDARY-START(408022482994)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(408022482994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(408022482994)
            
            //--TRIMMABLE-BOUNDARY-START(412317450290)
            /*System.Threading.Tasks.Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412317450290);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(412317450290)
            
            //--TRIMMABLE-BOUNDARY-START(416612417586)
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(416612417586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(416612417586)
            
            static $h = 589874;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$snsc.SNS.AuthenticatedStream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(137439543346),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 193274118194,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 589874,
      "h": 137439543346,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137439543346),
//--TRIMMABLE-BOUNDARY-START(141734510642),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 201864052786,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 589874,
      "h": 141734510642,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141734510642),
//--TRIMMABLE-BOUNDARY-START(146029477938),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 210453987378,
        "f": 50364417
      },
      "n": "CanTimeout",
      "d": 589874,
      "h": 146029477938,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146029477938),
//--TRIMMABLE-BOUNDARY-START(150324445234),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 219043921970,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 589874,
      "h": 150324445234,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(150324445234),
//--TRIMMABLE-BOUNDARY-START(317828169778),
    {
      "p": 162136065,
      "g": {
        "r": 0,
        "d": 0,
        "h": 227633856562,
        "f": 50331777
      },
      "n": "ImpersonationLevel",
      "d": 589874,
      "h": 317828169778,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(317828169778),
//--TRIMMABLE-BOUNDARY-START(322123137074),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 236223791154,
        "f": 50364417
      },
      "n": "IsAuthenticated",
      "d": 589874,
      "h": 322123137074,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(322123137074),
//--TRIMMABLE-BOUNDARY-START(326418104370),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 244813725746,
        "f": 50364417
      },
      "n": "IsEncrypted",
      "d": 589874,
      "h": 326418104370,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(326418104370),
//--TRIMMABLE-BOUNDARY-START(330713071666),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 253403660338,
        "f": 50364417
      },
      "n": "IsMutuallyAuthenticated",
      "d": 589874,
      "h": 330713071666,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(330713071666),
//--TRIMMABLE-BOUNDARY-START(335008038962),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 261993594930,
        "f": 50364417
      },
      "n": "IsServer",
      "d": 589874,
      "h": 335008038962,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(335008038962),
//--TRIMMABLE-BOUNDARY-START(339303006258),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 270583529522,
        "f": 50364417
      },
      "n": "IsSigned",
      "d": 589874,
      "h": 339303006258,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(339303006258),
//--TRIMMABLE-BOUNDARY-START(343597973554),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 279173464114,
        "f": 50364417
      },
      "n": "Length",
      "d": 589874,
      "h": 343597973554,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(343597973554),
//--TRIMMABLE-BOUNDARY-START(347892940850),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 287763398706,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 382252679218,
        "f": 83918849
      },
      "n": "Position",
      "d": 589874,
      "h": 347892940850,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(347892940850),
//--TRIMMABLE-BOUNDARY-START(365072810034),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 296353333298,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 390842613810,
        "f": 83918849
      },
      "n": "ReadTimeout",
      "d": 589874,
      "h": 365072810034,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(365072810034),
//--TRIMMABLE-BOUNDARY-START(369367777330),
    {
      "p": 161939457,
      "g": {
        "r": 0,
        "d": 0,
        "h": 304943267890,
        "f": 50331777
      },
      "n": "RemoteIdentity",
      "d": 589874,
      "h": 369367777330,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(369367777330),
//--TRIMMABLE-BOUNDARY-START(420907384882),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 313533202482,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 399432548402,
        "f": 83918849
      },
      "n": "WriteTimeout",
      "d": 589874,
      "h": 420907384882,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(420907384882)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(12885491762),
    {
      "r": 65537,
      "n": "AuthenticateAsClient",
      "d": 589874,
      "h": 12885491762,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(12885491762),
//--TRIMMABLE-BOUNDARY-START(21475426354),
    {
      "r": 65537,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "binding",
          "p": 5373999
        },
        {
          "n": "targetName",
          "p": 1310721
        }
      ],
      "n": "AuthenticateAsClient",
      "o": "@$2",
      "d": 589874,
      "h": 21475426354,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(21475426354),
//--TRIMMABLE-BOUNDARY-START(17180459058),
    {
      "r": 65537,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "binding",
          "p": 5373999
        },
        {
          "n": "targetName",
          "p": 1310721
        },
        {
          "n": "requiredProtectionLevel",
          "p": 655410
        },
        {
          "n": "allowedImpersonationLevel",
          "p": 162136065
        }
      ],
      "n": "AuthenticateAsClient",
      "o": "@$1",
      "d": 589874,
      "h": 17180459058,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(17180459058),
//--TRIMMABLE-BOUNDARY-START(30065360946),
    {
      "r": 65537,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "targetName",
          "p": 1310721
        }
      ],
      "n": "AuthenticateAsClient",
      "o": "@$4",
      "d": 589874,
      "h": 30065360946,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(30065360946),
//--TRIMMABLE-BOUNDARY-START(25770393650),
    {
      "r": 65537,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "targetName",
          "p": 1310721
        },
        {
          "n": "requiredProtectionLevel",
          "p": 655410
        },
        {
          "n": "allowedImpersonationLevel",
          "p": 162136065
        }
      ],
      "n": "AuthenticateAsClient",
      "o": "@$3",
      "d": 589874,
      "h": 25770393650,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(25770393650),
//--TRIMMABLE-BOUNDARY-START(34360328242),
    {
      "r": 178454529,
      "n": "AuthenticateAsClientAsync",
      "d": 589874,
      "h": 34360328242,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(34360328242),
//--TRIMMABLE-BOUNDARY-START(42950262834),
    {
      "r": 178454529,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "binding",
          "p": 5373999
        },
        {
          "n": "targetName",
          "p": 1310721
        }
      ],
      "n": "AuthenticateAsClientAsync",
      "o": "@$2",
      "d": 589874,
      "h": 42950262834,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(42950262834),
//--TRIMMABLE-BOUNDARY-START(38655295538),
    {
      "r": 178454529,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "binding",
          "p": 5373999
        },
        {
          "n": "targetName",
          "p": 1310721
        },
        {
          "n": "requiredProtectionLevel",
          "p": 655410
        },
        {
          "n": "allowedImpersonationLevel",
          "p": 162136065
        }
      ],
      "n": "AuthenticateAsClientAsync",
      "o": "@$1",
      "d": 589874,
      "h": 38655295538,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(38655295538),
//--TRIMMABLE-BOUNDARY-START(51540197426),
    {
      "r": 178454529,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "targetName",
          "p": 1310721
        }
      ],
      "n": "AuthenticateAsClientAsync",
      "o": "@$4",
      "d": 589874,
      "h": 51540197426,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(51540197426),
//--TRIMMABLE-BOUNDARY-START(47245230130),
    {
      "r": 178454529,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "targetName",
          "p": 1310721
        },
        {
          "n": "requiredProtectionLevel",
          "p": 655410
        },
        {
          "n": "allowedImpersonationLevel",
          "p": 162136065
        }
      ],
      "n": "AuthenticateAsClientAsync",
      "o": "@$3",
      "d": 589874,
      "h": 47245230130,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(47245230130),
//--TRIMMABLE-BOUNDARY-START(55835164722),
    {
      "r": 65537,
      "n": "AuthenticateAsServer",
      "d": 589874,
      "h": 55835164722,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(55835164722),
//--TRIMMABLE-BOUNDARY-START(60130132018),
    {
      "r": 65537,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "requiredProtectionLevel",
          "p": 655410
        },
        {
          "n": "requiredImpersonationLevel",
          "p": 162136065
        }
      ],
      "n": "AuthenticateAsServer",
      "o": "@$1",
      "d": 589874,
      "h": 60130132018,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(60130132018),
//--TRIMMABLE-BOUNDARY-START(64425099314),
    {
      "r": 65537,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "policy",
          "p": 1507378
        },
        {
          "n": "requiredProtectionLevel",
          "p": 655410
        },
        {
          "n": "requiredImpersonationLevel",
          "p": 162136065
        }
      ],
      "n": "AuthenticateAsServer",
      "o": "@$2",
      "d": 589874,
      "h": 64425099314,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64425099314),
//--TRIMMABLE-BOUNDARY-START(68720066610),
    {
      "r": 65537,
      "p": [
        {
          "n": "policy",
          "p": 1507378
        }
      ],
      "n": "AuthenticateAsServer",
      "o": "@$3",
      "d": 589874,
      "h": 68720066610,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(68720066610),
//--TRIMMABLE-BOUNDARY-START(73015033906),
    {
      "r": 178454529,
      "n": "AuthenticateAsServerAsync",
      "d": 589874,
      "h": 73015033906,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(73015033906),
//--TRIMMABLE-BOUNDARY-START(77310001202),
    {
      "r": 178454529,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "requiredProtectionLevel",
          "p": 655410
        },
        {
          "n": "requiredImpersonationLevel",
          "p": 162136065
        }
      ],
      "n": "AuthenticateAsServerAsync",
      "o": "@$1",
      "d": 589874,
      "h": 77310001202,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(77310001202),
//--TRIMMABLE-BOUNDARY-START(81604968498),
    {
      "r": 178454529,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "policy",
          "p": 1507378
        },
        {
          "n": "requiredProtectionLevel",
          "p": 655410
        },
        {
          "n": "requiredImpersonationLevel",
          "p": 162136065
        }
      ],
      "n": "AuthenticateAsServerAsync",
      "o": "@$2",
      "d": 589874,
      "h": 81604968498,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(81604968498),
//--TRIMMABLE-BOUNDARY-START(85899935794),
    {
      "r": 178454529,
      "p": [
        {
          "n": "policy",
          "p": 1507378
        }
      ],
      "n": "AuthenticateAsServerAsync",
      "o": "@$3",
      "d": 589874,
      "h": 85899935794,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(85899935794),
//--TRIMMABLE-BOUNDARY-START(90194903090),
    {
      "r": 90570753,
      "p": [
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginAuthenticateAsClient",
      "d": 589874,
      "h": 90194903090,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(90194903090),
//--TRIMMABLE-BOUNDARY-START(94489870386),
    {
      "r": 90570753,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "binding",
          "p": 5373999
        },
        {
          "n": "targetName",
          "p": 1310721
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginAuthenticateAsClient",
      "o": "@$1",
      "d": 589874,
      "h": 94489870386,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(94489870386),
//--TRIMMABLE-BOUNDARY-START(98784837682),
    {
      "r": 90570753,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "binding",
          "p": 5373999
        },
        {
          "n": "targetName",
          "p": 1310721
        },
        {
          "n": "requiredProtectionLevel",
          "p": 655410
        },
        {
          "n": "allowedImpersonationLevel",
          "p": 162136065
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginAuthenticateAsClient",
      "o": "@$2",
      "d": 589874,
      "h": 98784837682,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(98784837682),
//--TRIMMABLE-BOUNDARY-START(103079804978),
    {
      "r": 90570753,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "targetName",
          "p": 1310721
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginAuthenticateAsClient",
      "o": "@$3",
      "d": 589874,
      "h": 103079804978,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(103079804978),
//--TRIMMABLE-BOUNDARY-START(107374772274),
    {
      "r": 90570753,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "targetName",
          "p": 1310721
        },
        {
          "n": "requiredProtectionLevel",
          "p": 655410
        },
        {
          "n": "allowedImpersonationLevel",
          "p": 162136065
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginAuthenticateAsClient",
      "o": "@$4",
      "d": 589874,
      "h": 107374772274,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(107374772274),
//--TRIMMABLE-BOUNDARY-START(111669739570),
    {
      "r": 90570753,
      "p": [
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginAuthenticateAsServer",
      "d": 589874,
      "h": 111669739570,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(111669739570),
//--TRIMMABLE-BOUNDARY-START(115964706866),
    {
      "r": 90570753,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "requiredProtectionLevel",
          "p": 655410
        },
        {
          "n": "requiredImpersonationLevel",
          "p": 162136065
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginAuthenticateAsServer",
      "o": "@$1",
      "d": 589874,
      "h": 115964706866,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(115964706866),
//--TRIMMABLE-BOUNDARY-START(120259674162),
    {
      "r": 90570753,
      "p": [
        {
          "n": "credential",
          "p": 3801135
        },
        {
          "n": "policy",
          "p": 1507378
        },
        {
          "n": "requiredProtectionLevel",
          "p": 655410
        },
        {
          "n": "requiredImpersonationLevel",
          "p": 162136065
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginAuthenticateAsServer",
      "o": "@$2",
      "d": 589874,
      "h": 120259674162,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(120259674162),
//--TRIMMABLE-BOUNDARY-START(124554641458),
    {
      "r": 90570753,
      "p": [
        {
          "n": "policy",
          "p": 1507378
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginAuthenticateAsServer",
      "o": "@$3",
      "d": 589874,
      "h": 124554641458,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(124554641458),
//--TRIMMABLE-BOUNDARY-START(128849608754),
    {
      "r": 90570753,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginRead",
      "d": 589874,
      "h": 128849608754,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128849608754),
//--TRIMMABLE-BOUNDARY-START(133144576050),
    {
      "r": 90570753,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginWrite",
      "d": 589874,
      "h": 133144576050,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(133144576050),
//--TRIMMABLE-BOUNDARY-START(154619412530),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 589874,
      "h": 154619412530,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(154619412530),
//--TRIMMABLE-BOUNDARY-START(158914379826),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 589874,
      "h": 158914379826,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(158914379826),
//--TRIMMABLE-BOUNDARY-START(163209347122),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndAuthenticateAsClient",
      "d": 589874,
      "h": 163209347122,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(163209347122),
//--TRIMMABLE-BOUNDARY-START(167504314418),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndAuthenticateAsServer",
      "d": 589874,
      "h": 167504314418,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(167504314418),
//--TRIMMABLE-BOUNDARY-START(171799281714),
    {
      "r": 655361,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndRead",
      "d": 589874,
      "h": 171799281714,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(171799281714),
//--TRIMMABLE-BOUNDARY-START(176094249010),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndWrite",
      "d": 589874,
      "h": 176094249010,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(176094249010),
//--TRIMMABLE-BOUNDARY-START(180389216306),
    {
      "r": 65537,
      "n": "Flush",
      "d": 589874,
      "h": 180389216306,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180389216306),
//--TRIMMABLE-BOUNDARY-START(184684183602),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "FlushAsync",
      "o": "@$1",
      "d": 589874,
      "h": 184684183602,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184684183602),
//--TRIMMABLE-BOUNDARY-START(352187908146),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 589874,
      "h": 352187908146,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(352187908146),
//--TRIMMABLE-BOUNDARY-START(356482875442),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAsync",
      "d": 589874,
      "h": 356482875442,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(356482875442),
//--TRIMMABLE-BOUNDARY-START(360777842738),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 589874,
      "h": 360777842738,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(360777842738),
//--TRIMMABLE-BOUNDARY-START(373662744626),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 95289345
        }
      ],
      "n": "Seek",
      "d": 589874,
      "h": 373662744626,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(373662744626),
//--TRIMMABLE-BOUNDARY-START(403727515698),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 589874,
      "h": 403727515698,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(403727515698),
//--TRIMMABLE-BOUNDARY-START(408022482994),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 589874,
      "h": 408022482994,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(408022482994),
//--TRIMMABLE-BOUNDARY-START(412317450290),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "WriteAsync",
      "d": 589874,
      "h": 412317450290,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(412317450290),
//--TRIMMABLE-BOUNDARY-START(416612417586),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 589874,
      "h": 416612417586,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(416612417586)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(8590524466),
    {
      "p": [
        {
          "n": "innerStream",
          "p": 95748097
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 589874,
      "h": 8590524466,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8590524466),
//--TRIMMABLE-BOUNDARY-START(4295557170),
    {
      "p": [
        {
          "n": "innerStream",
          "p": 95748097
        },
        {
          "n": "leaveInnerStreamOpen",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 589874,
      "h": 4295557170,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4295557170)
  ],
  "h": 589874
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.NegotiateStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}NegotiateStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(589874)
        
        

        //--TRIMMABLE-BOUNDARY-START(1245234)
        $asm.$cls(`$snsc.SNS.SslStream`, ($self) => class SslStream extends $.$snsc.SNS.AuthenticatedStream
        {
            //--TRIMMABLE-BOUNDARY-START(21476081714)
            $ctor$8(/*System.IO.Stream*/ innerStream)
            {
                super.$ctor$3(null, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(21476081714);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(21476081714)
            
            //--TRIMMABLE-BOUNDARY-START(17181114418)
            $ctor$7(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$3(null, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181114418);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181114418)
            
            //--TRIMMABLE-BOUNDARY-START(12886147122)
            $ctor$6(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback)
            {
                super.$ctor$3(null, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886147122);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886147122)
            
            //--TRIMMABLE-BOUNDARY-START(8591179826)
            $ctor$5(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback, /*System.Net.Security.LocalCertificateSelectionCallback?*/ userCertificateSelectionCallback)
            {
                super.$ctor$3(null, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591179826);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591179826)
            
            //--TRIMMABLE-BOUNDARY-START(4296212530)
            $ctor$4(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback, /*System.Net.Security.LocalCertificateSelectionCallback?*/ userCertificateSelectionCallback, /*System.Net.Security.EncryptionPolicy*/ encryptionPolicy)
            {
                super.$ctor$3(null, false);
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296212530);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296212530)
            
            //--TRIMMABLE-BOUNDARY-START(133145231410)
            /*bool */ get CanRead()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(206159675442);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(133145231410)
            
            //--TRIMMABLE-BOUNDARY-START(137440198706)
            /*bool */ get CanSeek()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(214749610034);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(137440198706)
            
            //--TRIMMABLE-BOUNDARY-START(141735166002)
            /*bool */ get CanTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(223339544626);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(141735166002)
            
            //--TRIMMABLE-BOUNDARY-START(146030133298)
            /*bool */ get CanWrite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(231929479218);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(146030133298)
            
            //--TRIMMABLE-BOUNDARY-START(150325100594)
            /*bool */ get CheckCertRevocationStatus()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(240519413810);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(150325100594)
            
            //--TRIMMABLE-BOUNDARY-START(154620067890)
            /*System.Security.Authentication.CipherAlgorithmType */ get CipherAlgorithm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(249109348402);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(154620067890)
            
            //--TRIMMABLE-BOUNDARY-START(158915035186)
            /*int */ get CipherStrength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(257699282994);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(158915035186)
            
            //--TRIMMABLE-BOUNDARY-START(433792942130)
            /*System.Security.Authentication.HashAlgorithmType */ get HashAlgorithm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(266289217586);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(433792942130)
            
            //--TRIMMABLE-BOUNDARY-START(438087909426)
            /*int */ get HashStrength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(274879152178);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(438087909426)
            
            //--TRIMMABLE-BOUNDARY-START(442382876722)
            /*bool */ get IsAuthenticated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(283469086770);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(442382876722)
            
            //--TRIMMABLE-BOUNDARY-START(446677844018)
            /*bool */ get IsEncrypted()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(292059021362);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(446677844018)
            
            //--TRIMMABLE-BOUNDARY-START(450972811314)
            /*bool */ get IsMutuallyAuthenticated()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(300648955954);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(450972811314)
            
            //--TRIMMABLE-BOUNDARY-START(455267778610)
            /*bool */ get IsServer()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(309238890546);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(455267778610)
            
            //--TRIMMABLE-BOUNDARY-START(459562745906)
            /*bool */ get IsSigned()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(317828825138);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(459562745906)
            
            //--TRIMMABLE-BOUNDARY-START(463857713202)
            /*System.Security.Authentication.ExchangeAlgorithmType */ get KeyExchangeAlgorithm()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(326418759730);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(463857713202)
            
            //--TRIMMABLE-BOUNDARY-START(468152680498)
            /*int */ get KeyExchangeStrength()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(335008694322);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(468152680498)
            
            //--TRIMMABLE-BOUNDARY-START(472447647794)
            /*long */ get Length()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(343598628914);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(472447647794)
            
            //--TRIMMABLE-BOUNDARY-START(476742615090)
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get LocalCertificate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(352188563506);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(476742615090)
            
            //--TRIMMABLE-BOUNDARY-START(485332549682)
            /*System.Net.Security.SslApplicationProtocol */ get NegotiatedApplicationProtocol()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(360778498098);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(485332549682)
            
            //--TRIMMABLE-BOUNDARY-START(489627516978)
            /*System.Net.Security.TlsCipherSuite */ get NegotiatedCipherSuite()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(369368432690);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(489627516978)
            
            //--TRIMMABLE-BOUNDARY-START(493922484274)
            /*long */ get Position()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(377958367282);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(536872157234);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(493922484274)
            
            //--TRIMMABLE-BOUNDARY-START(519692288050)
            /*int */ get ReadTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(386548301874);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(545462091826);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(519692288050)
            
            //--TRIMMABLE-BOUNDARY-START(523987255346)
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get RemoteCertificate()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(395138236466);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(523987255346)
            
            //--TRIMMABLE-BOUNDARY-START(566936928306)
            /*System.Security.Authentication.SslProtocols */ get SslProtocol()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(403728171058);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(566936928306)
            
            //--TRIMMABLE-BOUNDARY-START(571231895602)
            /*string */ get TargetHostName()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(412318105650);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(571231895602)
            
            //--TRIMMABLE-BOUNDARY-START(575526862898)
            /*System.Net.TransportContext */ get TransportContext()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(420908040242);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(575526862898)
            
            //--TRIMMABLE-BOUNDARY-START(605591633970)
            /*int */ get WriteTimeout()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(429497974834);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(554052026418);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(605591633970)
            
            //--TRIMMABLE-BOUNDARY-START(25771049010)
            /*void */ AuthenticateAsClient(/*System.Net.Security.SslClientAuthenticationOptions*/ sslClientAuthenticationOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(25771049010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(25771049010)
            
            //--TRIMMABLE-BOUNDARY-START(38655950898)
            /*void */ AuthenticateAsClient$3(/*string*/ targetHost)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(38655950898);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(38655950898)
            
            //--TRIMMABLE-BOUNDARY-START(30066016306)
            /*void */ AuthenticateAsClient$1(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(30066016306);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(30066016306)
            
            //--TRIMMABLE-BOUNDARY-START(34360983602)
            /*void */ AuthenticateAsClient$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(34360983602);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(34360983602)
            
            //--TRIMMABLE-BOUNDARY-START(42950918194)
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync(/*System.Net.Security.SslClientAuthenticationOptions*/ sslClientAuthenticationOptions, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(42950918194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(42950918194)
            
            //--TRIMMABLE-BOUNDARY-START(55835820082)
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$3(/*string*/ targetHost)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(55835820082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(55835820082)
            
            //--TRIMMABLE-BOUNDARY-START(47245885490)
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$1(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(47245885490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(47245885490)
            
            //--TRIMMABLE-BOUNDARY-START(51540852786)
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(51540852786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(51540852786)
            
            //--TRIMMABLE-BOUNDARY-START(60130787378)
            /*void */ AuthenticateAsServer(/*System.Net.Security.SslServerAuthenticationOptions*/ sslServerAuthenticationOptions)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(60130787378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(60130787378)
            
            //--TRIMMABLE-BOUNDARY-START(73015689266)
            /*void */ AuthenticateAsServer$3(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(73015689266);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(73015689266)
            
            //--TRIMMABLE-BOUNDARY-START(64425754674)
            /*void */ AuthenticateAsServer$1(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(64425754674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(64425754674)
            
            //--TRIMMABLE-BOUNDARY-START(68720721970)
            /*void */ AuthenticateAsServer$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(68720721970);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(68720721970)
            
            //--TRIMMABLE-BOUNDARY-START(77310656562)
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync(/*System.Net.Security.ServerOptionsSelectionCallback*/ optionsCallback, /*object?*/ state, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(77310656562);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(77310656562)
            
            //--TRIMMABLE-BOUNDARY-START(81605623858)
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$1(/*System.Net.Security.SslServerAuthenticationOptions*/ sslServerAuthenticationOptions, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(81605623858);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(81605623858)
            
            //--TRIMMABLE-BOUNDARY-START(94490525746)
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$4(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(94490525746);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(94490525746)
            
            //--TRIMMABLE-BOUNDARY-START(85900591154)
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(85900591154);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(85900591154)
            
            //--TRIMMABLE-BOUNDARY-START(90195558450)
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$3(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(90195558450);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(90195558450)
            
            //--TRIMMABLE-BOUNDARY-START(98785493042)
            /*System.IAsyncResult */ BeginAuthenticateAsClient(/*string*/ targetHost, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(98785493042);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(98785493042)
            
            //--TRIMMABLE-BOUNDARY-START(103080460338)
            /*System.IAsyncResult */ BeginAuthenticateAsClient$1(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(103080460338);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(103080460338)
            
            //--TRIMMABLE-BOUNDARY-START(107375427634)
            /*System.IAsyncResult */ BeginAuthenticateAsClient$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(107375427634);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(107375427634)
            
            //--TRIMMABLE-BOUNDARY-START(111670394930)
            /*System.IAsyncResult */ BeginAuthenticateAsServer(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(111670394930);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(111670394930)
            
            //--TRIMMABLE-BOUNDARY-START(115965362226)
            /*System.IAsyncResult */ BeginAuthenticateAsServer$1(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(115965362226);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(115965362226)
            
            //--TRIMMABLE-BOUNDARY-START(120260329522)
            /*System.IAsyncResult */ BeginAuthenticateAsServer$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(120260329522);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(120260329522)
            
            //--TRIMMABLE-BOUNDARY-START(124555296818)
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(124555296818);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(124555296818)
            
            //--TRIMMABLE-BOUNDARY-START(128850264114)
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(128850264114);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(128850264114)
            
            //--TRIMMABLE-BOUNDARY-START(163210002482)
            /*void */ Dispose$1(/*bool*/ disposing)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(163210002482);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(163210002482)
            
            //--TRIMMABLE-BOUNDARY-START(167504969778)
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(167504969778);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(167504969778)
            
            //--TRIMMABLE-BOUNDARY-START(171799937074)
            /*void */ EndAuthenticateAsClient(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(171799937074);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(171799937074)
            
            //--TRIMMABLE-BOUNDARY-START(176094904370)
            /*void */ EndAuthenticateAsServer(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(176094904370);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(176094904370)
            
            //--TRIMMABLE-BOUNDARY-START(180389871666)
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(180389871666);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(180389871666)
            
            //--TRIMMABLE-BOUNDARY-START(184684838962)
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(184684838962);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(184684838962)
            
            $dtor()
            {
            }
            //--TRIMMABLE-BOUNDARY-START(193274773554)
            /*void */ Flush()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(193274773554);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(193274773554)
            
            //--TRIMMABLE-BOUNDARY-START(197569740850)
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(197569740850);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(197569740850)
            
            //--TRIMMABLE-BOUNDARY-START(481037582386)
            /*System.Threading.Tasks.Task */ NegotiateClientCertificateAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(481037582386);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(481037582386)
            
            //--TRIMMABLE-BOUNDARY-START(498217451570)
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(498217451570);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(498217451570)
            
            //--TRIMMABLE-BOUNDARY-START(502512418866)
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(502512418866);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(502512418866)
            
            //--TRIMMABLE-BOUNDARY-START(506807386162)
            /*System.Threading.Tasks.Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(506807386162);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(506807386162)
            
            //--TRIMMABLE-BOUNDARY-START(511102353458)
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(511102353458);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(511102353458)
            
            //--TRIMMABLE-BOUNDARY-START(515397320754)
            /*int */ ReadByte()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(515397320754);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(515397320754)
            
            //--TRIMMABLE-BOUNDARY-START(528282222642)
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(528282222642);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(528282222642)
            
            //--TRIMMABLE-BOUNDARY-START(558346993714)
            /*void */ SetLength(/*long*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(558346993714);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(558346993714)
            
            //--TRIMMABLE-BOUNDARY-START(562641961010)
            /*System.Threading.Tasks.Task */ ShutdownAsync()
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(562641961010);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(562641961010)
            
            //--TRIMMABLE-BOUNDARY-START(584116797490)
            /*void */ Write$2(/*byte[]*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(584116797490);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(584116797490)
            
            //--TRIMMABLE-BOUNDARY-START(579821830194)
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(579821830194);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(579821830194)
            
            //--TRIMMABLE-BOUNDARY-START(588411764786)
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(588411764786);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(588411764786)
            
            //--TRIMMABLE-BOUNDARY-START(592706732082)
            /*System.Threading.Tasks.Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(592706732082);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(592706732082)
            
            //--TRIMMABLE-BOUNDARY-START(597001699378)
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(597001699378);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
                throw new $.$$.S.PlatformNotSupportedException().$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(597001699378)
            
            //--TRIMMABLE-BOUNDARY-START(601296666674)
            /*void */ WriteByte(/*byte*/ value)
            {
                //--TRIMMABLE-BOUNDARY-START(TRACE)
                $.$trace(601296666674);
                //--TRIMMABLE-BOUNDARY-END(TRACE)
            }
            //--TRIMMABLE-BOUNDARY-END(601296666674)
            
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 1245234;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$snsc.SNS.AuthenticatedStream; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "p": [
//--TRIMMABLE-BOUNDARY-START(133145231410),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 206159675442,
        "f": 50364417
      },
      "n": "CanRead",
      "d": 1245234,
      "h": 133145231410,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(133145231410),
//--TRIMMABLE-BOUNDARY-START(137440198706),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 214749610034,
        "f": 50364417
      },
      "n": "CanSeek",
      "d": 1245234,
      "h": 137440198706,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(137440198706),
//--TRIMMABLE-BOUNDARY-START(141735166002),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 223339544626,
        "f": 50364417
      },
      "n": "CanTimeout",
      "d": 1245234,
      "h": 141735166002,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(141735166002),
//--TRIMMABLE-BOUNDARY-START(146030133298),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 231929479218,
        "f": 50364417
      },
      "n": "CanWrite",
      "d": 1245234,
      "h": 146030133298,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(146030133298),
//--TRIMMABLE-BOUNDARY-START(150325100594),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 240519413810,
        "f": 50331777
      },
      "n": "CheckCertRevocationStatus",
      "d": 1245234,
      "h": 150325100594,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(150325100594),
//--TRIMMABLE-BOUNDARY-START(154620067890),
    {
      "p": 5242927,
      "g": {
        "r": 0,
        "d": 0,
        "h": 249109348402,
        "f": 50331777
      },
      "n": "CipherAlgorithm",
      "d": 1245234,
      "h": 154620067890,
      "f": 2097281,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0058",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(154620067890),
//--TRIMMABLE-BOUNDARY-START(158915035186),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 257699282994,
        "f": 50331777
      },
      "n": "CipherStrength",
      "d": 1245234,
      "h": 158915035186,
      "f": 2097281,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0058",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(158915035186),
//--TRIMMABLE-BOUNDARY-START(433792942130),
    {
      "p": 5505071,
      "g": {
        "r": 0,
        "d": 0,
        "h": 266289217586,
        "f": 50331777
      },
      "n": "HashAlgorithm",
      "d": 1245234,
      "h": 433792942130,
      "f": 2097281,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0058",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(433792942130),
//--TRIMMABLE-BOUNDARY-START(438087909426),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 274879152178,
        "f": 50331777
      },
      "n": "HashStrength",
      "d": 1245234,
      "h": 438087909426,
      "f": 2097281,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0058",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(438087909426),
//--TRIMMABLE-BOUNDARY-START(442382876722),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 283469086770,
        "f": 50364417
      },
      "n": "IsAuthenticated",
      "d": 1245234,
      "h": 442382876722,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(442382876722),
//--TRIMMABLE-BOUNDARY-START(446677844018),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 292059021362,
        "f": 50364417
      },
      "n": "IsEncrypted",
      "d": 1245234,
      "h": 446677844018,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(446677844018),
//--TRIMMABLE-BOUNDARY-START(450972811314),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 300648955954,
        "f": 50364417
      },
      "n": "IsMutuallyAuthenticated",
      "d": 1245234,
      "h": 450972811314,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(450972811314),
//--TRIMMABLE-BOUNDARY-START(455267778610),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 309238890546,
        "f": 50364417
      },
      "n": "IsServer",
      "d": 1245234,
      "h": 455267778610,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(455267778610),
//--TRIMMABLE-BOUNDARY-START(459562745906),
    {
      "p": 262145,
      "g": {
        "r": 0,
        "d": 0,
        "h": 317828825138,
        "f": 50364417
      },
      "n": "IsSigned",
      "d": 1245234,
      "h": 459562745906,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(459562745906),
//--TRIMMABLE-BOUNDARY-START(463857713202),
    {
      "p": 5308463,
      "g": {
        "r": 0,
        "d": 0,
        "h": 326418759730,
        "f": 50331777
      },
      "n": "KeyExchangeAlgorithm",
      "d": 1245234,
      "h": 463857713202,
      "f": 2097281,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0058",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(463857713202),
//--TRIMMABLE-BOUNDARY-START(468152680498),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 335008694322,
        "f": 50331777
      },
      "n": "KeyExchangeStrength",
      "d": 1245234,
      "h": 468152680498,
      "f": 2097281,
      "a": [
        {
          "t": 104464385,
          "c": 30169235457,
          "a": [
            {
              "v": "KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.",
              "t": 1310721
            }
          ],
          "n": [
            {
              "n": "DiagnosticId",
              "v": "SYSLIB0058",
              "t": 1310721
            },
            {
              "n": "UrlFormat",
              "v": "https://aka.ms/dotnet-warnings/{0}",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(468152680498),
//--TRIMMABLE-BOUNDARY-START(472447647794),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 343598628914,
        "f": 50364417
      },
      "n": "Length",
      "d": 1245234,
      "h": 472447647794,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(472447647794),
//--TRIMMABLE-BOUNDARY-START(476742615090),
    {
      "p": 28114974,
      "g": {
        "r": 0,
        "d": 0,
        "h": 352188563506,
        "f": 50331777
      },
      "n": "LocalCertificate",
      "d": 1245234,
      "h": 476742615090,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(476742615090),
//--TRIMMABLE-BOUNDARY-START(485332549682),
    {
      "p": 917554,
      "g": {
        "r": 0,
        "d": 0,
        "h": 360778498098,
        "f": 50331649
      },
      "n": "NegotiatedApplicationProtocol",
      "d": 1245234,
      "h": 485332549682,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(485332549682),
//--TRIMMABLE-BOUNDARY-START(489627516978),
    {
      "p": 1376306,
      "g": {
        "r": 0,
        "d": 0,
        "h": 369368432690,
        "f": 50331777
      },
      "n": "NegotiatedCipherSuite",
      "d": 1245234,
      "h": 489627516978,
      "f": 2097281,
      "a": [
        {
          "t": 54984705,
          "c": 8644919297,
          "a": [
            {
              "v": false,
              "t": 262145
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(489627516978),
//--TRIMMABLE-BOUNDARY-START(493922484274),
    {
      "p": 917505,
      "g": {
        "r": 0,
        "d": 0,
        "h": 377958367282,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 536872157234,
        "f": 83918849
      },
      "n": "Position",
      "d": 1245234,
      "h": 493922484274,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(493922484274),
//--TRIMMABLE-BOUNDARY-START(519692288050),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 386548301874,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 545462091826,
        "f": 83918849
      },
      "n": "ReadTimeout",
      "d": 1245234,
      "h": 519692288050,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(519692288050),
//--TRIMMABLE-BOUNDARY-START(523987255346),
    {
      "p": 28114974,
      "g": {
        "r": 0,
        "d": 0,
        "h": 395138236466,
        "f": 50331777
      },
      "n": "RemoteCertificate",
      "d": 1245234,
      "h": 523987255346,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(523987255346),
//--TRIMMABLE-BOUNDARY-START(566936928306),
    {
      "p": 5570607,
      "g": {
        "r": 0,
        "d": 0,
        "h": 403728171058,
        "f": 50331777
      },
      "n": "SslProtocol",
      "d": 1245234,
      "h": 566936928306,
      "f": 2097281
    },
//--TRIMMABLE-BOUNDARY-END(566936928306),
//--TRIMMABLE-BOUNDARY-START(571231895602),
    {
      "p": 1310721,
      "g": {
        "r": 0,
        "d": 0,
        "h": 412318105650,
        "f": 50331649
      },
      "n": "TargetHostName",
      "d": 1245234,
      "h": 571231895602,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(571231895602),
//--TRIMMABLE-BOUNDARY-START(575526862898),
    {
      "p": 4980783,
      "g": {
        "r": 0,
        "d": 0,
        "h": 420908040242,
        "f": 50331649
      },
      "n": "TransportContext",
      "d": 1245234,
      "h": 575526862898,
      "f": 2097153
    },
//--TRIMMABLE-BOUNDARY-END(575526862898),
//--TRIMMABLE-BOUNDARY-START(605591633970),
    {
      "p": 655361,
      "g": {
        "r": 0,
        "d": 0,
        "h": 429497974834,
        "f": 50364417
      },
      "s": {
        "r": 0,
        "d": 0,
        "h": 554052026418,
        "f": 83918849
      },
      "n": "WriteTimeout",
      "d": 1245234,
      "h": 605591633970,
      "f": 2129921
    },
//--TRIMMABLE-BOUNDARY-END(605591633970)
  ],
  "m": [
//--TRIMMABLE-BOUNDARY-START(25771049010),
    {
      "r": 65537,
      "p": [
        {
          "n": "sslClientAuthenticationOptions",
          "p": 1048626
        }
      ],
      "n": "AuthenticateAsClient",
      "d": 1245234,
      "h": 25771049010,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(25771049010),
//--TRIMMABLE-BOUNDARY-START(38655950898),
    {
      "r": 65537,
      "p": [
        {
          "n": "targetHost",
          "p": 1310721
        }
      ],
      "n": "AuthenticateAsClient",
      "o": "@$3",
      "d": 1245234,
      "h": 38655950898,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(38655950898),
//--TRIMMABLE-BOUNDARY-START(30066016306),
    {
      "r": 65537,
      "p": [
        {
          "n": "targetHost",
          "p": 1310721
        },
        {
          "n": "clientCertificates",
          "p": 28377118
        },
        {
          "n": "checkCertificateRevocation",
          "p": 262145
        }
      ],
      "n": "AuthenticateAsClient",
      "o": "@$1",
      "d": 1245234,
      "h": 30066016306,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(30066016306),
//--TRIMMABLE-BOUNDARY-START(34360983602),
    {
      "r": 65537,
      "p": [
        {
          "n": "targetHost",
          "p": 1310721
        },
        {
          "n": "clientCertificates",
          "p": 28377118
        },
        {
          "n": "enabledSslProtocols",
          "p": 5570607
        },
        {
          "n": "checkCertificateRevocation",
          "p": 262145
        }
      ],
      "n": "AuthenticateAsClient",
      "o": "@$2",
      "d": 1245234,
      "h": 34360983602,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(34360983602),
//--TRIMMABLE-BOUNDARY-START(42950918194),
    {
      "r": 178454529,
      "p": [
        {
          "n": "sslClientAuthenticationOptions",
          "p": 1048626
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "AuthenticateAsClientAsync",
      "d": 1245234,
      "h": 42950918194,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(42950918194),
//--TRIMMABLE-BOUNDARY-START(55835820082),
    {
      "r": 178454529,
      "p": [
        {
          "n": "targetHost",
          "p": 1310721
        }
      ],
      "n": "AuthenticateAsClientAsync",
      "o": "@$3",
      "d": 1245234,
      "h": 55835820082,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(55835820082),
//--TRIMMABLE-BOUNDARY-START(47245885490),
    {
      "r": 178454529,
      "p": [
        {
          "n": "targetHost",
          "p": 1310721
        },
        {
          "n": "clientCertificates",
          "p": 28377118
        },
        {
          "n": "checkCertificateRevocation",
          "p": 262145
        }
      ],
      "n": "AuthenticateAsClientAsync",
      "o": "@$1",
      "d": 1245234,
      "h": 47245885490,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(47245885490),
//--TRIMMABLE-BOUNDARY-START(51540852786),
    {
      "r": 178454529,
      "p": [
        {
          "n": "targetHost",
          "p": 1310721
        },
        {
          "n": "clientCertificates",
          "p": 28377118
        },
        {
          "n": "enabledSslProtocols",
          "p": 5570607
        },
        {
          "n": "checkCertificateRevocation",
          "p": 262145
        }
      ],
      "n": "AuthenticateAsClientAsync",
      "o": "@$2",
      "d": 1245234,
      "h": 51540852786,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(51540852786),
//--TRIMMABLE-BOUNDARY-START(60130787378),
    {
      "r": 65537,
      "p": [
        {
          "n": "sslServerAuthenticationOptions",
          "p": 1179698
        }
      ],
      "n": "AuthenticateAsServer",
      "d": 1245234,
      "h": 60130787378,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(60130787378),
//--TRIMMABLE-BOUNDARY-START(73015689266),
    {
      "r": 65537,
      "p": [
        {
          "n": "serverCertificate",
          "p": 28114974
        }
      ],
      "n": "AuthenticateAsServer",
      "o": "@$3",
      "d": 1245234,
      "h": 73015689266,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(73015689266),
//--TRIMMABLE-BOUNDARY-START(64425754674),
    {
      "r": 65537,
      "p": [
        {
          "n": "serverCertificate",
          "p": 28114974
        },
        {
          "n": "clientCertificateRequired",
          "p": 262145
        },
        {
          "n": "checkCertificateRevocation",
          "p": 262145
        }
      ],
      "n": "AuthenticateAsServer",
      "o": "@$1",
      "d": 1245234,
      "h": 64425754674,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(64425754674),
//--TRIMMABLE-BOUNDARY-START(68720721970),
    {
      "r": 65537,
      "p": [
        {
          "n": "serverCertificate",
          "p": 28114974
        },
        {
          "n": "clientCertificateRequired",
          "p": 262145
        },
        {
          "n": "enabledSslProtocols",
          "p": 5570607
        },
        {
          "n": "checkCertificateRevocation",
          "p": 262145
        }
      ],
      "n": "AuthenticateAsServer",
      "o": "@$2",
      "d": 1245234,
      "h": 68720721970,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(68720721970),
//--TRIMMABLE-BOUNDARY-START(77310656562),
    {
      "r": 178454529,
      "p": [
        {
          "n": "optionsCallback",
          "p": 852018
        },
        {
          "n": "state",
          "p": 131073
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "AuthenticateAsServerAsync",
      "d": 1245234,
      "h": 77310656562,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(77310656562),
//--TRIMMABLE-BOUNDARY-START(81605623858),
    {
      "r": 178454529,
      "p": [
        {
          "n": "sslServerAuthenticationOptions",
          "p": 1179698
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "AuthenticateAsServerAsync",
      "o": "@$1",
      "d": 1245234,
      "h": 81605623858,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(81605623858),
//--TRIMMABLE-BOUNDARY-START(94490525746),
    {
      "r": 178454529,
      "p": [
        {
          "n": "serverCertificate",
          "p": 28114974
        }
      ],
      "n": "AuthenticateAsServerAsync",
      "o": "@$4",
      "d": 1245234,
      "h": 94490525746,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(94490525746),
//--TRIMMABLE-BOUNDARY-START(85900591154),
    {
      "r": 178454529,
      "p": [
        {
          "n": "serverCertificate",
          "p": 28114974
        },
        {
          "n": "clientCertificateRequired",
          "p": 262145
        },
        {
          "n": "checkCertificateRevocation",
          "p": 262145
        }
      ],
      "n": "AuthenticateAsServerAsync",
      "o": "@$2",
      "d": 1245234,
      "h": 85900591154,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(85900591154),
//--TRIMMABLE-BOUNDARY-START(90195558450),
    {
      "r": 178454529,
      "p": [
        {
          "n": "serverCertificate",
          "p": 28114974
        },
        {
          "n": "clientCertificateRequired",
          "p": 262145
        },
        {
          "n": "enabledSslProtocols",
          "p": 5570607
        },
        {
          "n": "checkCertificateRevocation",
          "p": 262145
        }
      ],
      "n": "AuthenticateAsServerAsync",
      "o": "@$3",
      "d": 1245234,
      "h": 90195558450,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(90195558450),
//--TRIMMABLE-BOUNDARY-START(98785493042),
    {
      "r": 90570753,
      "p": [
        {
          "n": "targetHost",
          "p": 1310721
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginAuthenticateAsClient",
      "d": 1245234,
      "h": 98785493042,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(98785493042),
//--TRIMMABLE-BOUNDARY-START(103080460338),
    {
      "r": 90570753,
      "p": [
        {
          "n": "targetHost",
          "p": 1310721
        },
        {
          "n": "clientCertificates",
          "p": 28377118
        },
        {
          "n": "checkCertificateRevocation",
          "p": 262145
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginAuthenticateAsClient",
      "o": "@$1",
      "d": 1245234,
      "h": 103080460338,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(103080460338),
//--TRIMMABLE-BOUNDARY-START(107375427634),
    {
      "r": 90570753,
      "p": [
        {
          "n": "targetHost",
          "p": 1310721
        },
        {
          "n": "clientCertificates",
          "p": 28377118
        },
        {
          "n": "enabledSslProtocols",
          "p": 5570607
        },
        {
          "n": "checkCertificateRevocation",
          "p": 262145
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginAuthenticateAsClient",
      "o": "@$2",
      "d": 1245234,
      "h": 107375427634,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(107375427634),
//--TRIMMABLE-BOUNDARY-START(111670394930),
    {
      "r": 90570753,
      "p": [
        {
          "n": "serverCertificate",
          "p": 28114974
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginAuthenticateAsServer",
      "d": 1245234,
      "h": 111670394930,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(111670394930),
//--TRIMMABLE-BOUNDARY-START(115965362226),
    {
      "r": 90570753,
      "p": [
        {
          "n": "serverCertificate",
          "p": 28114974
        },
        {
          "n": "clientCertificateRequired",
          "p": 262145
        },
        {
          "n": "checkCertificateRevocation",
          "p": 262145
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginAuthenticateAsServer",
      "o": "@$1",
      "d": 1245234,
      "h": 115965362226,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(115965362226),
//--TRIMMABLE-BOUNDARY-START(120260329522),
    {
      "r": 90570753,
      "p": [
        {
          "n": "serverCertificate",
          "p": 28114974
        },
        {
          "n": "clientCertificateRequired",
          "p": 262145
        },
        {
          "n": "enabledSslProtocols",
          "p": 5570607
        },
        {
          "n": "checkCertificateRevocation",
          "p": 262145
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginAuthenticateAsServer",
      "o": "@$2",
      "d": 1245234,
      "h": 120260329522,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(120260329522),
//--TRIMMABLE-BOUNDARY-START(124555296818),
    {
      "r": 90570753,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginRead",
      "d": 1245234,
      "h": 124555296818,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(124555296818),
//--TRIMMABLE-BOUNDARY-START(128850264114),
    {
      "r": 90570753,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "asyncCallback",
          "p": 46006273
        },
        {
          "n": "asyncState",
          "p": 131073
        }
      ],
      "n": "BeginWrite",
      "d": 1245234,
      "h": 128850264114,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(128850264114),
//--TRIMMABLE-BOUNDARY-START(163210002482),
    {
      "r": 65537,
      "p": [
        {
          "n": "disposing",
          "p": 262145
        }
      ],
      "n": "Dispose",
      "o": "@$1",
      "d": 1245234,
      "h": 163210002482,
      "f": 16809988
    },
//--TRIMMABLE-BOUNDARY-END(163210002482),
//--TRIMMABLE-BOUNDARY-START(167504969778),
    {
      "r": 181338113,
      "n": "DisposeAsync",
      "d": 1245234,
      "h": 167504969778,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(167504969778),
//--TRIMMABLE-BOUNDARY-START(171799937074),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndAuthenticateAsClient",
      "d": 1245234,
      "h": 171799937074,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(171799937074),
//--TRIMMABLE-BOUNDARY-START(176094904370),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndAuthenticateAsServer",
      "d": 1245234,
      "h": 176094904370,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(176094904370),
//--TRIMMABLE-BOUNDARY-START(180389871666),
    {
      "r": 655361,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndRead",
      "d": 1245234,
      "h": 180389871666,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(180389871666),
//--TRIMMABLE-BOUNDARY-START(184684838962),
    {
      "r": 65537,
      "p": [
        {
          "n": "asyncResult",
          "p": 90570753
        }
      ],
      "n": "EndWrite",
      "d": 1245234,
      "h": 184684838962,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(184684838962),
//--TRIMMABLE-BOUNDARY-START(193274773554),
    {
      "r": 65537,
      "n": "Flush",
      "d": 1245234,
      "h": 193274773554,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(193274773554),
//--TRIMMABLE-BOUNDARY-START(197569740850),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "FlushAsync",
      "o": "@$1",
      "d": 1245234,
      "h": 197569740850,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(197569740850),
//--TRIMMABLE-BOUNDARY-START(481037582386),
    {
      "r": 178454529,
      "p": [
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "NegotiateClientCertificateAsync",
      "d": 1245234,
      "h": 481037582386,
      "f": 16777345,
      "a": [
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "freebsd",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "linux",
              "t": 1310721
            }
          ]
        },
        {
          "t": 159842305,
          "c": 4454809601,
          "a": [
            {
              "v": "windows",
              "t": 1310721
            }
          ]
        }
      ]
    },
//--TRIMMABLE-BOUNDARY-END(481037582386),
//--TRIMMABLE-BOUNDARY-START(498217451570),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Read",
      "d": 1245234,
      "h": 498217451570,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(498217451570),
//--TRIMMABLE-BOUNDARY-START(502512418866),
    {
      "r": 655361,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Span$$($.$$.S.Byte).$h
        }
      ],
      "n": "Read",
      "o": "@$1",
      "d": 1245234,
      "h": 502512418866,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(502512418866),
//--TRIMMABLE-BOUNDARY-START(506807386162),
    {
      "r": $.$$.STT.Task$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "ReadAsync",
      "d": 1245234,
      "h": 506807386162,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(506807386162),
//--TRIMMABLE-BOUNDARY-START(511102353458),
    {
      "r": $.$$.STT.ValueTask$$($.$$.S.Int32).$h,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.Memory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "ReadAsync",
      "o": "@$2",
      "d": 1245234,
      "h": 511102353458,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(511102353458),
//--TRIMMABLE-BOUNDARY-START(515397320754),
    {
      "r": 655361,
      "n": "ReadByte",
      "d": 1245234,
      "h": 515397320754,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(515397320754),
//--TRIMMABLE-BOUNDARY-START(528282222642),
    {
      "r": 917505,
      "p": [
        {
          "n": "offset",
          "p": 917505
        },
        {
          "n": "origin",
          "p": 95289345
        }
      ],
      "n": "Seek",
      "d": 1245234,
      "h": 528282222642,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(528282222642),
//--TRIMMABLE-BOUNDARY-START(558346993714),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 917505
        }
      ],
      "n": "SetLength",
      "d": 1245234,
      "h": 558346993714,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(558346993714),
//--TRIMMABLE-BOUNDARY-START(562641961010),
    {
      "r": 178454529,
      "n": "ShutdownAsync",
      "d": 1245234,
      "h": 562641961010,
      "f": 16777345
    },
//--TRIMMABLE-BOUNDARY-END(562641961010),
//--TRIMMABLE-BOUNDARY-START(584116797490),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        }
      ],
      "n": "Write",
      "o": "@$2",
      "d": 1245234,
      "h": 584116797490,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(584116797490),
//--TRIMMABLE-BOUNDARY-START(579821830194),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        }
      ],
      "n": "Write",
      "d": 1245234,
      "h": 579821830194,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(579821830194),
//--TRIMMABLE-BOUNDARY-START(588411764786),
    {
      "r": 65537,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlySpan$$($.$$.S.Byte).$h
        }
      ],
      "n": "Write",
      "o": "@$1",
      "d": 1245234,
      "h": 588411764786,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(588411764786),
//--TRIMMABLE-BOUNDARY-START(592706732082),
    {
      "r": 178454529,
      "p": [
        {
          "n": "buffer",
          "p": $.$typeArray($.$$.S.Byte).$h
        },
        {
          "n": "offset",
          "p": 655361
        },
        {
          "n": "count",
          "p": 655361
        },
        {
          "n": "cancellationToken",
          "p": 170852353
        }
      ],
      "n": "WriteAsync",
      "d": 1245234,
      "h": 592706732082,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(592706732082),
//--TRIMMABLE-BOUNDARY-START(597001699378),
    {
      "r": 181338113,
      "p": [
        {
          "n": "buffer",
          "p": $.$$.S.ReadOnlyMemory$$($.$$.S.Byte).$h
        },
        {
          "n": "cancellationToken",
          "p": 170852353,
          "f": 65
        }
      ],
      "n": "WriteAsync",
      "o": "@$2",
      "d": 1245234,
      "h": 597001699378,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(597001699378),
//--TRIMMABLE-BOUNDARY-START(601296666674),
    {
      "r": 65537,
      "p": [
        {
          "n": "value",
          "p": 393217
        }
      ],
      "n": "WriteByte",
      "d": 1245234,
      "h": 601296666674,
      "f": 16809985
    },
//--TRIMMABLE-BOUNDARY-END(601296666674)
  ],
  "c": [
//--TRIMMABLE-BOUNDARY-START(21476081714),
    {
      "p": [
        {
          "n": "innerStream",
          "p": 95748097
        }
      ],
      "n": ".ctor",
      "o": "$ctor$8",
      "d": 1245234,
      "h": 21476081714,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(21476081714),
//--TRIMMABLE-BOUNDARY-START(17181114418),
    {
      "p": [
        {
          "n": "innerStream",
          "p": 95748097
        },
        {
          "n": "leaveInnerStreamOpen",
          "p": 262145
        }
      ],
      "n": ".ctor",
      "o": "$ctor$7",
      "d": 1245234,
      "h": 17181114418,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(17181114418),
//--TRIMMABLE-BOUNDARY-START(12886147122),
    {
      "p": [
        {
          "n": "innerStream",
          "p": 95748097
        },
        {
          "n": "leaveInnerStreamOpen",
          "p": 262145
        },
        {
          "n": "userCertificateValidationCallback",
          "p": 720946
        }
      ],
      "n": ".ctor",
      "o": "$ctor$6",
      "d": 1245234,
      "h": 12886147122,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(12886147122),
//--TRIMMABLE-BOUNDARY-START(8591179826),
    {
      "p": [
        {
          "n": "innerStream",
          "p": 95748097
        },
        {
          "n": "leaveInnerStreamOpen",
          "p": 262145
        },
        {
          "n": "userCertificateValidationCallback",
          "p": 720946
        },
        {
          "n": "userCertificateSelectionCallback",
          "p": 262194
        }
      ],
      "n": ".ctor",
      "o": "$ctor$5",
      "d": 1245234,
      "h": 8591179826,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(8591179826),
//--TRIMMABLE-BOUNDARY-START(4296212530),
    {
      "p": [
        {
          "n": "innerStream",
          "p": 95748097
        },
        {
          "n": "leaveInnerStreamOpen",
          "p": 262145
        },
        {
          "n": "userCertificateValidationCallback",
          "p": 720946
        },
        {
          "n": "userCertificateSelectionCallback",
          "p": 262194
        },
        {
          "n": "encryptionPolicy",
          "p": 196658
        }
      ],
      "n": ".ctor",
      "o": "$ctor$4",
      "d": 1245234,
      "h": 4296212530,
      "f": 16777217
    },
//--TRIMMABLE-BOUNDARY-END(4296212530)
  ],
  "h": 1245234
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.S.IDisposable, $.$$.S.IAsyncDisposable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Net.Security.SslStream`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Net${separator}Security${separator}SslStream`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1245234)
        
        

        //--TRIMMABLE-BOUNDARY-START(1441842)
        $asm.$cls(`$snsc.SSA.AuthenticationException`, ($self) => class AuthenticationException extends $.$$.S.SystemException
        {
            //--TRIMMABLE-BOUNDARY-START(4296409138)
            $ctor$9()
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296409138);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296409138)
            
            //--TRIMMABLE-BOUNDARY-START(8591376434)
            $ctor$10(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591376434);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591376434)
            
            //--TRIMMABLE-BOUNDARY-START(17181311026)
            $ctor$12(/*string?*/ message)
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181311026);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181311026)
            
            //--TRIMMABLE-BOUNDARY-START(12886343730)
            $ctor$11(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$5();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886343730);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886343730)
            
            //--TRIMMABLE-BOUNDARY-START(4296409138)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$9();
            }
            //--TRIMMABLE-BOUNDARY-END(4296409138)
            
            static $h = 1441842;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$$.S.SystemException; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1441842
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Authentication.AuthenticationException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Authentication${separator}AuthenticationException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1441842)
        
        

        //--TRIMMABLE-BOUNDARY-START(1769522)
        $asm.$cls(`$snsc.SSA.InvalidCredentialException`, ($self) => class InvalidCredentialException extends $.$snsc.SSA.AuthenticationException
        {
            //--TRIMMABLE-BOUNDARY-START(4296736818)
            $ctor$13()
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(4296736818);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(4296736818)
            
            //--TRIMMABLE-BOUNDARY-START(8591704114)
            $ctor$14(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(8591704114);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(8591704114)
            
            //--TRIMMABLE-BOUNDARY-START(17181638706)
            $ctor$16(/*string?*/ message)
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(17181638706);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(17181638706)
            
            //--TRIMMABLE-BOUNDARY-START(12886671410)
            $ctor$15(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$9();
                {
                    //--TRIMMABLE-BOUNDARY-START(TRACE)
                    $.$trace(12886671410);
                    //--TRIMMABLE-BOUNDARY-END(TRACE)
                }
                return this;
            }
            //--TRIMMABLE-BOUNDARY-END(12886671410)
            
            //--TRIMMABLE-BOUNDARY-START(4296736818)
            //generic new constructor
            $gctor()
            {
                return this.$ctor$13();
            }
            //--TRIMMABLE-BOUNDARY-END(4296736818)
            
            static $h = 1769522;
            static $f = 0b10001;
            static $k = 1;
            static $$b;
            static get $b() { return this.$$b ??= $.$snsc.SSA.AuthenticationException; }
            static $$md;
            static get $md() { return this.$$md ??= {
  "h": 1769522
}; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.SRS.ISerializable ]; }
            static $$fullName;
            static get $fullName() { return this.$$fullName ??= `System.Security.Authentication.InvalidCredentialException`; }
            static $$getFullName = {};
            static $getFullName(separator) { return this.$$getFullName[separator] ??= `System${separator}Security${separator}Authentication${separator}InvalidCredentialException`; }
        });
        //--TRIMMABLE-BOUNDARY-END(1769522)
	});
})(window, window.NetJs.$boot(), ...await window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography"));
})();
//--TRIMMABLE-BOUNDARY-END(50)
