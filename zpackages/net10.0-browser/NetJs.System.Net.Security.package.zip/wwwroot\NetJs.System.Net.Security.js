
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $srn, $ssc, $sris, $scsl, $sfa, $sic, $sim, $sl, $snp, $sspw, $sci, $sdd, $srm, $snnr, $sds, $sns, $sscr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Security", 
    {"h":37265,"f":"System.Net.Security","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B760b8187d87d291733fdcda9f4d484d24d61a938","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Security","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Security","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snsc.System.Net.Security.AuthenticatedStream", ($self) => class AuthenticatedStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.IO.Stream */ get InnerStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get LeaveInnerStreamOpen()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 102801;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":62128129,"g":{"r":0,"d":0,"h":12885004689,"f":4},"n":"InnerStream","d":102801,"h":8590037393,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":21474939281,"f":257},"n":"IsAuthenticated","d":102801,"h":17179971985,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":30064873873,"f":257},"n":"IsEncrypted","d":102801,"h":25769906577,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":38654808465,"f":257},"n":"IsMutuallyAuthenticated","d":102801,"h":34359841169,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":47244743057,"f":257},"n":"IsServer","d":102801,"h":42949775761,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":55834677649,"f":257},"n":"IsSigned","d":102801,"h":51539710353,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":64424612241,"f":1},"n":"LeaveInnerStreamOpen","d":102801,"h":60129644945,"f":1}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":102801,"h":68719579537,"f":32772},{"r":136118273,"n":"DisposeAsync","d":102801,"h":73014546833,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":102801,"h":4295070097,"f":4}],"i":[57475073,56885249],"h":102801}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.AuthenticatedStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.CipherSuitesPolicy", ($self) => class CipherSuitesPolicy extends $.$spc.System.Object
        {
            $ctor$1(/*System.Collections.Generic.IEnumerable<System.Net.Security.TlsCipherSuite>*/ allowedCipherSuites)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.Generic.IEnumerable<System.Net.Security.TlsCipherSuite> */ get AllowedCipherSuites()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 168337;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$snsc.System.Net.Security.TlsCipherSuite).$h,"g":{"r":0,"d":0,"h":12885070225,"f":1},"n":"AllowedCipherSuites","d":168337,"h":8590102929,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}],"c":[{"p":[{"n":"allowedCipherSuites","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$snsc.System.Net.Security.TlsCipherSuite).$h}],"n":".ctor","o":"$ctor$1","d":168337,"h":4295135633,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}],"h":168337,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"windows","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.CipherSuitesPolicy`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthenticationClientOptions", ($self) => class NegotiateAuthenticationClientOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get AllowedImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set AllowedImpersonationLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get Binding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ set Binding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ get Credential()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ set Credential(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Package(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get RequiredProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ set RequiredProtectionLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RequireMutualAuthentication()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RequireMutualAuthentication(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TargetName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 430481;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":117243905,"g":{"r":0,"d":0,"h":12885332369,"f":1},"s":{"r":0,"d":0,"h":17180299665,"f":1},"n":"AllowedImpersonationLevel","d":430481,"h":8590365073,"f":1},{"p":5435866,"g":{"r":0,"d":0,"h":25770234257,"f":1},"s":{"r":0,"d":0,"h":30065201553,"f":1},"n":"Binding","d":430481,"h":21475266961,"f":1},{"p":3863002,"g":{"r":0,"d":0,"h":38655136145,"f":1},"s":{"r":0,"d":0,"h":42950103441,"f":1},"n":"Credential","d":430481,"h":34360168849,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540038033,"f":1},"s":{"r":0,"d":0,"h":55835005329,"f":1},"n":"Package","d":430481,"h":47245070737,"f":1},{"p":692625,"g":{"r":0,"d":0,"h":64424939921,"f":1},"s":{"r":0,"d":0,"h":68719907217,"f":1},"n":"RequiredProtectionLevel","d":430481,"h":60129972625,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77309841809,"f":1},"s":{"r":0,"d":0,"h":81604809105,"f":1},"n":"RequireMutualAuthentication","d":430481,"h":73014874513,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90194743697,"f":1},"s":{"r":0,"d":0,"h":94489710993,"f":1},"n":"TargetName","d":430481,"h":85899776401,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":430481,"h":4295397777,"f":1}],"h":430481}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationClientOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthenticationServerOptions", ($self) => class NegotiateAuthenticationServerOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get Binding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ set Binding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ get Credential()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ set Credential(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Package(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy? */ get Policy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy? */ set Policy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get RequiredImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set RequiredImpersonationLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get RequiredProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ set RequiredProtectionLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 496017;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5435866,"g":{"r":0,"d":0,"h":12885397905,"f":1},"s":{"r":0,"d":0,"h":17180365201,"f":1},"n":"Binding","d":496017,"h":8590430609,"f":1},{"p":3863002,"g":{"r":0,"d":0,"h":25770299793,"f":1},"s":{"r":0,"d":0,"h":30065267089,"f":1},"n":"Credential","d":496017,"h":21475332497,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38655201681,"f":1},"s":{"r":0,"d":0,"h":42950168977,"f":1},"n":"Package","d":496017,"h":34360234385,"f":1},{"p":1544593,"g":{"r":0,"d":0,"h":51540103569,"f":1},"s":{"r":0,"d":0,"h":55835070865,"f":1},"n":"Policy","d":496017,"h":47245136273,"f":1},{"p":117243905,"g":{"r":0,"d":0,"h":64425005457,"f":1},"s":{"r":0,"d":0,"h":68719972753,"f":1},"n":"RequiredImpersonationLevel","d":496017,"h":60130038161,"f":1},{"p":692625,"g":{"r":0,"d":0,"h":77309907345,"f":1},"s":{"r":0,"d":0,"h":81604874641,"f":1},"n":"RequiredProtectionLevel","d":496017,"h":73014940049,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":496017,"h":4295463313,"f":1}],"h":496017}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationServerOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslCertificateTrust", ($self) => class SslCertificateTrust extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*System.Net.Security.SslCertificateTrust */ CreateForX509Collection(/*System.Security.Cryptography.X509Certificates.X509Certificate2Collection*/ trustList, /*bool*/ sendTrustInHandshake)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslCertificateTrust */ CreateForX509Store(/*System.Security.Cryptography.X509Certificates.X509Store*/ store, /*bool*/ sendTrustInHandshake)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1020305;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1020305,"p":[{"n":"trustList","p":28290437},{"n":"sendTrustInHandshake","p":262145,"f":65,"v":false}],"n":"CreateForX509Collection","d":1020305,"h":8590954897,"f":33},{"r":1020305,"p":[{"n":"store","p":30453125},{"n":"sendTrustInHandshake","p":262145,"f":65,"v":false}],"n":"CreateForX509Store","d":1020305,"h":12885922193,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1020305,"h":4295987601,"f":8}],"h":1020305}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslCertificateTrust`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslClientAuthenticationOptions", ($self) => class SslClientAuthenticationOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AllowRenegotiation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRenegotiation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPkcs1Padding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPkcs1Padding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPssPadding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPssPadding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowTlsResume()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowTlsResume(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ get ApplicationProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ set ApplicationProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ get CertificateChainPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ set CertificateChainPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ get CertificateRevocationCheckMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ set CertificateRevocationCheckMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ get CipherSuitesPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ set CipherSuitesPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ get ClientCertificateContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ set ClientCertificateContext(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection? */ get ClientCertificates()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection? */ set ClientCertificates(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get EnabledSslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ set EnabledSslProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ set EncryptionPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.LocalCertificateSelectionCallback? */ get LocalCertificateSelectionCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.LocalCertificateSelectionCallback? */ set LocalCertificateSelectionCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get RemoteCertificateValidationCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set RemoteCertificateValidationCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetHost()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TargetHost(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1085841;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885987729,"f":1},"s":{"r":0,"d":0,"h":17180955025,"f":1},"n":"AllowRenegotiation","d":1085841,"h":8591020433,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770889617,"f":1},"s":{"r":0,"d":0,"h":30065856913,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPkcs1Padding","d":1085841,"h":21475922321,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655791505,"f":1},"s":{"r":0,"d":0,"h":42950758801,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPssPadding","d":1085841,"h":34360824209,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540693393,"f":1},"s":{"r":0,"d":0,"h":55835660689,"f":1},"n":"AllowTlsResume","d":1085841,"h":47245726097,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":64425595281,"f":1},"s":{"r":0,"d":0,"h":68720562577,"f":1},"n":"ApplicationProtocols","d":1085841,"h":60130627985,"f":1},{"p":29142405,"g":{"r":0,"d":0,"h":77310497169,"f":1},"s":{"r":0,"d":0,"h":81605464465,"f":1},"n":"CertificateChainPolicy","d":1085841,"h":73015529873,"f":1},{"p":30256517,"g":{"r":0,"d":0,"h":90195399057,"f":1},"s":{"r":0,"d":0,"h":94490366353,"f":1},"n":"CertificateRevocationCheckMode","d":1085841,"h":85900431761,"f":1},{"p":168337,"g":{"r":0,"d":0,"h":103080300945,"f":1},"s":{"r":0,"d":0,"h":107375268241,"f":1},"n":"CipherSuitesPolicy","d":1085841,"h":98785333649,"f":1},{"p":1347985,"g":{"r":0,"d":0,"h":115965202833,"f":1},"s":{"r":0,"d":0,"h":120260170129,"f":1},"n":"ClientCertificateContext","d":1085841,"h":111670235537,"f":1},{"p":28421509,"g":{"r":0,"d":0,"h":128850104721,"f":1},"s":{"r":0,"d":0,"h":133145072017,"f":1},"n":"ClientCertificates","d":1085841,"h":124555137425,"f":1},{"p":5632474,"g":{"r":0,"d":0,"h":141735006609,"f":1},"s":{"r":0,"d":0,"h":146029973905,"f":1},"n":"EnabledSslProtocols","d":1085841,"h":137440039313,"f":1},{"p":233873,"g":{"r":0,"d":0,"h":154619908497,"f":1},"s":{"r":0,"d":0,"h":158914875793,"f":1},"n":"EncryptionPolicy","d":1085841,"h":150324941201,"f":1},{"p":299409,"g":{"r":0,"d":0,"h":167504810385,"f":1},"s":{"r":0,"d":0,"h":171799777681,"f":1},"n":"LocalCertificateSelectionCallback","d":1085841,"h":163209843089,"f":1},{"p":758161,"g":{"r":0,"d":0,"h":180389712273,"f":1},"s":{"r":0,"d":0,"h":184684679569,"f":1},"n":"RemoteCertificateValidationCallback","d":1085841,"h":176094744977,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":193274614161,"f":1},"s":{"r":0,"d":0,"h":197569581457,"f":1},"n":"TargetHost","d":1085841,"h":188979646865,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1085841,"h":4296053137,"f":1}],"h":1085841}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslClientAuthenticationOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslServerAuthenticationOptions", ($self) => class SslServerAuthenticationOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AllowRenegotiation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRenegotiation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPkcs1Padding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPkcs1Padding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPssPadding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPssPadding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowTlsResume()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowTlsResume(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ get ApplicationProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ set ApplicationProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ get CertificateChainPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ set CertificateChainPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ get CertificateRevocationCheckMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ set CertificateRevocationCheckMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ get CipherSuitesPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ set CipherSuitesPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ClientCertificateRequired()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ClientCertificateRequired(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get EnabledSslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ set EnabledSslProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ set EncryptionPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get RemoteCertificateValidationCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set RemoteCertificateValidationCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get ServerCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ set ServerCertificate(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ get ServerCertificateContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ set ServerCertificateContext(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ServerCertificateSelectionCallback? */ get ServerCertificateSelectionCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ServerCertificateSelectionCallback? */ set ServerCertificateSelectionCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1216913;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886118801,"f":1},"s":{"r":0,"d":0,"h":17181086097,"f":1},"n":"AllowRenegotiation","d":1216913,"h":8591151505,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25771020689,"f":1},"s":{"r":0,"d":0,"h":30065987985,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPkcs1Padding","d":1216913,"h":21476053393,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655922577,"f":1},"s":{"r":0,"d":0,"h":42950889873,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPssPadding","d":1216913,"h":34360955281,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540824465,"f":1},"s":{"r":0,"d":0,"h":55835791761,"f":1},"n":"AllowTlsResume","d":1216913,"h":47245857169,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":64425726353,"f":1},"s":{"r":0,"d":0,"h":68720693649,"f":1},"n":"ApplicationProtocols","d":1216913,"h":60130759057,"f":1},{"p":29142405,"g":{"r":0,"d":0,"h":77310628241,"f":1},"s":{"r":0,"d":0,"h":81605595537,"f":1},"n":"CertificateChainPolicy","d":1216913,"h":73015660945,"f":1},{"p":30256517,"g":{"r":0,"d":0,"h":90195530129,"f":1},"s":{"r":0,"d":0,"h":94490497425,"f":1},"n":"CertificateRevocationCheckMode","d":1216913,"h":85900562833,"f":1},{"p":168337,"g":{"r":0,"d":0,"h":103080432017,"f":1},"s":{"r":0,"d":0,"h":107375399313,"f":1},"n":"CipherSuitesPolicy","d":1216913,"h":98785464721,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115965333905,"f":1},"s":{"r":0,"d":0,"h":120260301201,"f":1},"n":"ClientCertificateRequired","d":1216913,"h":111670366609,"f":1},{"p":5632474,"g":{"r":0,"d":0,"h":128850235793,"f":1},"s":{"r":0,"d":0,"h":133145203089,"f":1},"n":"EnabledSslProtocols","d":1216913,"h":124555268497,"f":1},{"p":233873,"g":{"r":0,"d":0,"h":141735137681,"f":1},"s":{"r":0,"d":0,"h":146030104977,"f":1},"n":"EncryptionPolicy","d":1216913,"h":137440170385,"f":1},{"p":758161,"g":{"r":0,"d":0,"h":154620039569,"f":1},"s":{"r":0,"d":0,"h":158915006865,"f":1},"n":"RemoteCertificateValidationCallback","d":1216913,"h":150325072273,"f":1},{"p":28159365,"g":{"r":0,"d":0,"h":167504941457,"f":1},"s":{"r":0,"d":0,"h":171799908753,"f":1},"n":"ServerCertificate","d":1216913,"h":163209974161,"f":1},{"p":1347985,"g":{"r":0,"d":0,"h":180389843345,"f":1},"s":{"r":0,"d":0,"h":184684810641,"f":1},"n":"ServerCertificateContext","d":1216913,"h":176094876049,"f":1},{"p":823697,"g":{"r":0,"d":0,"h":193274745233,"f":1},"s":{"r":0,"d":0,"h":197569712529,"f":1},"n":"ServerCertificateSelectionCallback","d":1216913,"h":188979777937,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1216913,"h":4296184209,"f":1}],"h":1216913}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslServerAuthenticationOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslStreamCertificateContext", ($self) => class SslStreamCertificateContext extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.ObjectModel.ReadOnlyCollection<System.Security.Cryptography.X509Certificates.X509Certificate2> */ get IntermediateCertificates()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate2 */ get TargetCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslStreamCertificateContext */ Create(/*System.Security.Cryptography.X509Certificates.X509Certificate2*/ target, /*System.Security.Cryptography.X509Certificates.X509Certificate2Collection?*/ additionalCertificates, /*bool*/ offline)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslStreamCertificateContext */ Create$1(/*System.Security.Cryptography.X509Certificates.X509Certificate2*/ target, /*System.Security.Cryptography.X509Certificates.X509Certificate2Collection?*/ additionalCertificates, /*bool*/ offline, /*System.Net.Security.SslCertificateTrust?*/ trust)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1347985;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sscr.System.Security.Cryptography.X509Certificates.X509Certificate2).$h,"g":{"r":0,"d":0,"h":12886249873,"f":1},"n":"IntermediateCertificates","d":1347985,"h":8591282577,"f":1},{"p":28224901,"g":{"r":0,"d":0,"h":21476184465,"f":1},"n":"TargetCertificate","d":1347985,"h":17181217169,"f":1}],"m":[{"r":1347985,"p":[{"n":"target","p":28224901},{"n":"additionalCertificates","p":28290437},{"n":"offline","p":262145}],"n":"Create","d":1347985,"h":25771151761,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":1347985,"p":[{"n":"target","p":28224901},{"n":"additionalCertificates","p":28290437},{"n":"offline","p":262145,"f":65,"v":false},{"n":"trust","p":1020305,"f":65}],"n":"Create","o":"@$1","d":1347985,"h":30066119057,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1347985,"h":4296315281,"f":8}],"h":1347985}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslStreamCertificateContext`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthentication", ($self) => class NegotiateAuthentication extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.Security.NegotiateAuthenticationClientOptions*/ clientOptions)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.Security.NegotiateAuthenticationServerOptions*/ serverOptions)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get ProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get RemoteIdentity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ ComputeIntegrityCheck(/*System.ReadOnlySpan<byte>*/ message, /*System.Buffers.IBufferWriter<byte>*/ signatureWriter)
            {
            }
            /*void */ Dispose()
            {
            }
            /*byte[]? */ GetOutgoingBlob(/*System.ReadOnlySpan<byte>*/ incomingBlob, /*out System.Net.Security.NegotiateAuthenticationStatusCode*/ statusCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ GetOutgoingBlob$1(/*string?*/ incomingBlob, /*out System.Net.Security.NegotiateAuthenticationStatusCode*/ statusCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ Unwrap(/*System.ReadOnlySpan<byte>*/ input, /*System.Buffers.IBufferWriter<byte>*/ outputWriter, /*out bool*/ wasEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ UnwrapInPlace(/*System.Span<byte>*/ input, /*out int*/ unwrappedOffset, /*out int*/ unwrappedLength, /*out bool*/ wasEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ VerifyIntegrityCheck(/*System.ReadOnlySpan<byte>*/ message, /*System.ReadOnlySpan<byte>*/ signature)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ Wrap(/*System.ReadOnlySpan<byte>*/ input, /*System.Buffers.IBufferWriter<byte>*/ outputWriter, /*bool*/ requestEncryption, /*out bool*/ isEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 364945;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":117243905,"g":{"r":0,"d":0,"h":17180234129,"f":1},"n":"ImpersonationLevel","d":364945,"h":12885266833,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770168721,"f":1},"n":"IsAuthenticated","d":364945,"h":21475201425,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360103313,"f":1},"n":"IsEncrypted","d":364945,"h":30065136017,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950037905,"f":1},"n":"IsMutuallyAuthenticated","d":364945,"h":38655070609,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51539972497,"f":1},"n":"IsServer","d":364945,"h":47245005201,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60129907089,"f":1},"n":"IsSigned","d":364945,"h":55834939793,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":68719841681,"f":1},"n":"Package","d":364945,"h":64424874385,"f":1},{"p":692625,"g":{"r":0,"d":0,"h":77309776273,"f":1},"n":"ProtectionLevel","d":364945,"h":73014808977,"f":1},{"p":117047297,"g":{"r":0,"d":0,"h":85899710865,"f":1},"n":"RemoteIdentity","d":364945,"h":81604743569,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":94489645457,"f":1},"n":"TargetName","d":364945,"h":90194678161,"f":1}],"m":[{"r":65537,"p":[{"n":"message","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"signatureWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h}],"n":"ComputeIntegrityCheck","d":364945,"h":98784612753,"f":1},{"r":65537,"n":"Dispose","d":364945,"h":103079580049,"f":1},{"r":0,"p":[{"n":"incomingBlob","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"statusCode","p":561553,"f":2}],"n":"GetOutgoingBlob","d":364945,"h":107374547345,"f":1},{"r":1310721,"p":[{"n":"incomingBlob","p":1310721},{"n":"statusCode","p":561553,"f":2}],"n":"GetOutgoingBlob","o":"@$1","d":364945,"h":111669514641,"f":1},{"r":561553,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"outputWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h},{"n":"wasEncrypted","p":262145,"f":2}],"n":"Unwrap","d":364945,"h":115964481937,"f":1},{"r":561553,"p":[{"n":"input","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"unwrappedOffset","p":655361,"f":2},{"n":"unwrappedLength","p":655361,"f":2},{"n":"wasEncrypted","p":262145,"f":2}],"n":"UnwrapInPlace","d":364945,"h":120259449233,"f":1},{"r":262145,"p":[{"n":"message","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"signature","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"VerifyIntegrityCheck","d":364945,"h":124554416529,"f":1},{"r":561553,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"outputWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h},{"n":"requestEncryption","p":262145},{"n":"isEncrypted","p":262145,"f":2}],"n":"Wrap","d":364945,"h":128849383825,"f":1}],"c":[{"p":[{"n":"clientOptions","p":430481}],"n":".ctor","o":"$ctor$1","d":364945,"h":4295332241,"f":1},{"p":[{"n":"serverOptions","p":496017}],"n":".ctor","o":"$ctor$2","d":364945,"h":8590299537,"f":1}],"i":[57475073],"h":364945}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthentication`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy", ($self) => class ExtendedProtectionPolicy extends $.$spc.System.Object
        {
            $ctor$1(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ChannelBinding*/ customChannelBinding)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ProtectionScenario*/ protectionScenario, /*System.Collections.ICollection?*/ customServiceNames)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ProtectionScenario*/ protectionScenario, /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection?*/ customServiceNames)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get CustomChannelBinding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection? */ get CustomServiceNames()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsExtendedProtection()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.PolicyEnforcement */ get PolicyEnforcement()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ProtectionScenario */ get ProtectionScenario()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo?*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snsc.System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy.ToString.apply(this, arguments); }
            static $h = 1544593;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5435866,"g":{"r":0,"d":0,"h":30066315665,"f":1},"n":"CustomChannelBinding","d":1544593,"h":25771348369,"f":1},{"p":1741201,"g":{"r":0,"d":0,"h":38656250257,"f":1},"n":"CustomServiceNames","d":1544593,"h":34361282961,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47246184849,"f":33},"n":"OSSupportsExtendedProtection","d":1544593,"h":42951217553,"f":33},{"p":1610129,"g":{"r":0,"d":0,"h":55836119441,"f":1},"n":"PolicyEnforcement","d":1544593,"h":51541152145,"f":1},{"p":1675665,"g":{"r":0,"d":0,"h":64426054033,"f":1},"n":"ProtectionScenario","d":1544593,"h":60131086737,"f":1}],"m":[{"r":1310721,"n":"ToString","d":1544593,"h":73015988625,"f":32769}],"c":[{"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$1","d":1544593,"h":4296511889,"f":4,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":[{"n":"policyEnforcement","p":1610129}],"n":".ctor","o":"$ctor$2","d":1544593,"h":8591479185,"f":1},{"p":[{"n":"policyEnforcement","p":1610129},{"n":"customChannelBinding","p":5435866}],"n":".ctor","o":"$ctor$3","d":1544593,"h":12886446481,"f":1},{"p":[{"n":"policyEnforcement","p":1610129},{"n":"protectionScenario","p":1675665},{"n":"customServiceNames","p":31326209}],"n":".ctor","o":"$ctor$4","d":1544593,"h":17181413777,"f":1},{"p":[{"n":"policyEnforcement","p":1610129},{"n":"protectionScenario","p":1675665},{"n":"customServiceNames","p":1741201}],"n":".ctor","o":"$ctor$5","d":1544593,"h":21476381073,"f":1}],"i":[113377281],"h":1544593}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.SslClientHelloInfo", ($self) => class SslClientHelloInfo extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            $ctor$2(/*string*/ serverName, /*System.Security.Authentication.SslProtocols*/ sslProtocols)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*string */ get ServerName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 1151377;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475987857,"f":1},"n":"ServerName","d":1151377,"h":17181020561,"f":1},{"p":5632474,"g":{"r":0,"d":0,"h":30065922449,"f":1},"n":"SslProtocols","d":1151377,"h":25770955153,"f":1}],"l":[{"t":131073,"n":"_dummy","d":1151377,"h":4296118673,"f":2},{"t":655361,"n":"_dummyPrimitive","d":1151377,"h":8591085969,"f":2}],"c":[{"p":[{"n":"serverName","p":1310721},{"n":"sslProtocols","p":5632474}],"n":".ctor","o":"$ctor$2","d":1151377,"h":12886053265,"f":1},{"n":".ctor","o":"$ctor$3","d":1151377,"h":34360889745,"f":1}],"h":1151377}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Security.SslClientHelloInfo`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.SslApplicationProtocol", ($self) => class SslApplicationProtocol extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.Security.SslApplicationProtocol*/ static Http11;
            /*System.Net.Security.SslApplicationProtocol*/ static Http2;
            /*System.Net.Security.SslApplicationProtocol*/ static Http3;
            $ctor$2(/*byte[]*/ protocol)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            $ctor$3(/*string*/ protocol)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*System.ReadOnlyMemory<byte> */ get Protocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Security.SslApplicationProtocol*/ other)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snsc.System.Net.Security.SslApplicationProtocol.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snsc.System.Net.Security.SslApplicationProtocol.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Security.SslApplicationProtocol*/ left, /*System.Net.Security.SslApplicationProtocol*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Security.SslApplicationProtocol*/ left, /*System.Net.Security.SslApplicationProtocol*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snsc.System.Net.Security.SslApplicationProtocol.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Net.Security.SslApplicationProtocol>.Equals(System.Net.Security.SslApplicationProtocol)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Http11 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
                {
                    this.Http2 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
                {
                    this.Http3 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
            }
            static $h = 954769;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":38655660433,"f":1},"n":"Protocol","d":954769,"h":34360693137,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":954769}],"n":"Equals","o":"@$2","d":954769,"h":42950627729,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":954769,"h":47245595025,"f":32769},{"r":655361,"n":"GetHashCode","d":954769,"h":51540562321,"f":32769},{"r":1310721,"n":"ToString","d":954769,"h":64425464209,"f":32769}],"l":[{"t":131073,"n":"_dummy","d":954769,"h":4295922065,"f":2},{"t":655361,"n":"_dummyPrimitive","d":954769,"h":8590889361,"f":2},{"t":954769,"n":"Http11","d":954769,"h":12885856657,"f":33},{"t":954769,"n":"Http2","d":954769,"h":17180823953,"f":33},{"t":954769,"n":"Http3","d":954769,"h":21475791249,"f":33}],"c":[{"p":[{"n":"protocol","p":0}],"n":".ctor","o":"$ctor$2","d":954769,"h":25770758545,"f":1},{"p":[{"n":"protocol","p":1310721}],"n":".ctor","o":"$ctor$3","d":954769,"h":30065725841,"f":1},{"n":".ctor","o":"$ctor$4","d":954769,"h":68720431505,"f":1}],"i":[$.$spc.System.IEquatable$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h],"h":954769}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$snsc.System.Net.Security.SslApplicationProtocol) ]; }
            static get $fullName() { return `System.Net.Security.SslApplicationProtocol`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.ExtendedProtection.ServiceNameCollection", ($self) => class ServiceNameCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2(/*System.Collections.ICollection*/ items)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ Contains(/*string?*/ searchServiceName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection */ Merge(/*System.Collections.IEnumerable*/ serviceNames)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection */ Merge$1(/*string*/ serviceName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1741201;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"m":[{"r":262145,"p":[{"n":"searchServiceName","p":1310721}],"n":"Contains","d":1741201,"h":8591675793,"f":1},{"r":1741201,"p":[{"n":"serviceNames","p":31588353}],"n":"Merge","d":1741201,"h":12886643089,"f":1},{"r":1741201,"p":[{"n":"serviceName","p":1310721}],"n":"Merge","o":"@$1","d":1741201,"h":17181610385,"f":1}],"c":[{"p":[{"n":"items","p":31326209}],"n":".ctor","o":"$ctor$2","d":1741201,"h":4296708497,"f":1}],"i":[31326209,31588353],"h":1741201}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ServiceNameCollection`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.EncryptionPolicy", ($self) => class EncryptionPolicy extends $.$spc.System.Enum
        {
            static RequireEncryption = 0;
            static AllowNoEncryption = 1;
            static NoEncryption = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "RequireEncryption": 0n,
                    "AllowNoEncryption": 1n,
                    "NoEncryption": 2n
                };
            }
            static $h = 233873;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":233873,"n":"RequireEncryption","d":233873,"h":4295201169,"f":33},{"t":233873,"n":"AllowNoEncryption","d":233873,"h":8590168465,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0040","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"t":233873,"n":"NoEncryption","d":233873,"h":12885135761,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0040","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":233873,"h":17180103057,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":233873}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.EncryptionPolicy`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.NegotiateAuthenticationStatusCode", ($self) => class NegotiateAuthenticationStatusCode extends $.$spc.System.Enum
        {
            static Completed = 0;
            static ContinueNeeded = 1;
            static GenericFailure = 2;
            static BadBinding = 3;
            static Unsupported = 4;
            static MessageAltered = 5;
            static ContextExpired = 6;
            static CredentialsExpired = 7;
            static InvalidCredentials = 8;
            static InvalidToken = 9;
            static UnknownCredentials = 10;
            static QopNotSupported = 11;
            static OutOfSequence = 12;
            static SecurityQosFailed = 13;
            static TargetUnknown = 14;
            static ImpersonationValidationFailed = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Completed": 0n,
                    "ContinueNeeded": 1n,
                    "GenericFailure": 2n,
                    "BadBinding": 3n,
                    "Unsupported": 4n,
                    "MessageAltered": 5n,
                    "ContextExpired": 6n,
                    "CredentialsExpired": 7n,
                    "InvalidCredentials": 8n,
                    "InvalidToken": 9n,
                    "UnknownCredentials": 10n,
                    "QopNotSupported": 11n,
                    "OutOfSequence": 12n,
                    "SecurityQosFailed": 13n,
                    "TargetUnknown": 14n,
                    "ImpersonationValidationFailed": 15n
                };
            }
            static $h = 561553;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":561553,"n":"Completed","d":561553,"h":4295528849,"f":33},{"t":561553,"n":"ContinueNeeded","d":561553,"h":8590496145,"f":33},{"t":561553,"n":"GenericFailure","d":561553,"h":12885463441,"f":33},{"t":561553,"n":"BadBinding","d":561553,"h":17180430737,"f":33},{"t":561553,"n":"Unsupported","d":561553,"h":21475398033,"f":33},{"t":561553,"n":"MessageAltered","d":561553,"h":25770365329,"f":33},{"t":561553,"n":"ContextExpired","d":561553,"h":30065332625,"f":33},{"t":561553,"n":"CredentialsExpired","d":561553,"h":34360299921,"f":33},{"t":561553,"n":"InvalidCredentials","d":561553,"h":38655267217,"f":33},{"t":561553,"n":"InvalidToken","d":561553,"h":42950234513,"f":33},{"t":561553,"n":"UnknownCredentials","d":561553,"h":47245201809,"f":33},{"t":561553,"n":"QopNotSupported","d":561553,"h":51540169105,"f":33},{"t":561553,"n":"OutOfSequence","d":561553,"h":55835136401,"f":33},{"t":561553,"n":"SecurityQosFailed","d":561553,"h":60130103697,"f":33},{"t":561553,"n":"TargetUnknown","d":561553,"h":64425070993,"f":33},{"t":561553,"n":"ImpersonationValidationFailed","d":561553,"h":68720038289,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":561553,"h":73015005585,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":561553}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationStatusCode`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.ProtectionLevel", ($self) => class ProtectionLevel extends $.$spc.System.Enum
        {
            static None = 0;
            static Sign = 1;
            static EncryptAndSign = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Sign": 1n,
                    "EncryptAndSign": 2n
                };
            }
            static $h = 692625;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":692625,"n":"None","d":692625,"h":4295659921,"f":33},{"t":692625,"n":"Sign","d":692625,"h":8590627217,"f":33},{"t":692625,"n":"EncryptAndSign","d":692625,"h":12885594513,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":692625,"h":17180561809,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":692625}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.ProtectionLevel`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.TlsCipherSuite", ($self) => class TlsCipherSuite extends $.$spc.System.Enum
        {
            static TLS_NULL_WITH_NULL_NULL = 0;
            static TLS_RSA_WITH_NULL_MD5 = 1;
            static TLS_RSA_WITH_NULL_SHA = 2;
            static TLS_RSA_EXPORT_WITH_RC4_40_MD5 = 3;
            static TLS_RSA_WITH_RC4_128_MD5 = 4;
            static TLS_RSA_WITH_RC4_128_SHA = 5;
            static TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5 = 6;
            static TLS_RSA_WITH_IDEA_CBC_SHA = 7;
            static TLS_RSA_EXPORT_WITH_DES40_CBC_SHA = 8;
            static TLS_RSA_WITH_DES_CBC_SHA = 9;
            static TLS_RSA_WITH_3DES_EDE_CBC_SHA = 10;
            static TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA = 11;
            static TLS_DH_DSS_WITH_DES_CBC_SHA = 12;
            static TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA = 13;
            static TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA = 14;
            static TLS_DH_RSA_WITH_DES_CBC_SHA = 15;
            static TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA = 16;
            static TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA = 17;
            static TLS_DHE_DSS_WITH_DES_CBC_SHA = 18;
            static TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA = 19;
            static TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA = 20;
            static TLS_DHE_RSA_WITH_DES_CBC_SHA = 21;
            static TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA = 22;
            static TLS_DH_anon_EXPORT_WITH_RC4_40_MD5 = 23;
            static TLS_DH_anon_WITH_RC4_128_MD5 = 24;
            static TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA = 25;
            static TLS_DH_anon_WITH_DES_CBC_SHA = 26;
            static TLS_DH_anon_WITH_3DES_EDE_CBC_SHA = 27;
            static TLS_KRB5_WITH_DES_CBC_SHA = 30;
            static TLS_KRB5_WITH_3DES_EDE_CBC_SHA = 31;
            static TLS_KRB5_WITH_RC4_128_SHA = 32;
            static TLS_KRB5_WITH_IDEA_CBC_SHA = 33;
            static TLS_KRB5_WITH_DES_CBC_MD5 = 34;
            static TLS_KRB5_WITH_3DES_EDE_CBC_MD5 = 35;
            static TLS_KRB5_WITH_RC4_128_MD5 = 36;
            static TLS_KRB5_WITH_IDEA_CBC_MD5 = 37;
            static TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA = 38;
            static TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA = 39;
            static TLS_KRB5_EXPORT_WITH_RC4_40_SHA = 40;
            static TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5 = 41;
            static TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5 = 42;
            static TLS_KRB5_EXPORT_WITH_RC4_40_MD5 = 43;
            static TLS_PSK_WITH_NULL_SHA = 44;
            static TLS_DHE_PSK_WITH_NULL_SHA = 45;
            static TLS_RSA_PSK_WITH_NULL_SHA = 46;
            static TLS_RSA_WITH_AES_128_CBC_SHA = 47;
            static TLS_DH_DSS_WITH_AES_128_CBC_SHA = 48;
            static TLS_DH_RSA_WITH_AES_128_CBC_SHA = 49;
            static TLS_DHE_DSS_WITH_AES_128_CBC_SHA = 50;
            static TLS_DHE_RSA_WITH_AES_128_CBC_SHA = 51;
            static TLS_DH_anon_WITH_AES_128_CBC_SHA = 52;
            static TLS_RSA_WITH_AES_256_CBC_SHA = 53;
            static TLS_DH_DSS_WITH_AES_256_CBC_SHA = 54;
            static TLS_DH_RSA_WITH_AES_256_CBC_SHA = 55;
            static TLS_DHE_DSS_WITH_AES_256_CBC_SHA = 56;
            static TLS_DHE_RSA_WITH_AES_256_CBC_SHA = 57;
            static TLS_DH_anon_WITH_AES_256_CBC_SHA = 58;
            static TLS_RSA_WITH_NULL_SHA256 = 59;
            static TLS_RSA_WITH_AES_128_CBC_SHA256 = 60;
            static TLS_RSA_WITH_AES_256_CBC_SHA256 = 61;
            static TLS_DH_DSS_WITH_AES_128_CBC_SHA256 = 62;
            static TLS_DH_RSA_WITH_AES_128_CBC_SHA256 = 63;
            static TLS_DHE_DSS_WITH_AES_128_CBC_SHA256 = 64;
            static TLS_RSA_WITH_CAMELLIA_128_CBC_SHA = 65;
            static TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA = 66;
            static TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA = 67;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA = 68;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA = 69;
            static TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA = 70;
            static TLS_DHE_RSA_WITH_AES_128_CBC_SHA256 = 103;
            static TLS_DH_DSS_WITH_AES_256_CBC_SHA256 = 104;
            static TLS_DH_RSA_WITH_AES_256_CBC_SHA256 = 105;
            static TLS_DHE_DSS_WITH_AES_256_CBC_SHA256 = 106;
            static TLS_DHE_RSA_WITH_AES_256_CBC_SHA256 = 107;
            static TLS_DH_anon_WITH_AES_128_CBC_SHA256 = 108;
            static TLS_DH_anon_WITH_AES_256_CBC_SHA256 = 109;
            static TLS_RSA_WITH_CAMELLIA_256_CBC_SHA = 132;
            static TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA = 133;
            static TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA = 134;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA = 135;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA = 136;
            static TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA = 137;
            static TLS_PSK_WITH_RC4_128_SHA = 138;
            static TLS_PSK_WITH_3DES_EDE_CBC_SHA = 139;
            static TLS_PSK_WITH_AES_128_CBC_SHA = 140;
            static TLS_PSK_WITH_AES_256_CBC_SHA = 141;
            static TLS_DHE_PSK_WITH_RC4_128_SHA = 142;
            static TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA = 143;
            static TLS_DHE_PSK_WITH_AES_128_CBC_SHA = 144;
            static TLS_DHE_PSK_WITH_AES_256_CBC_SHA = 145;
            static TLS_RSA_PSK_WITH_RC4_128_SHA = 146;
            static TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA = 147;
            static TLS_RSA_PSK_WITH_AES_128_CBC_SHA = 148;
            static TLS_RSA_PSK_WITH_AES_256_CBC_SHA = 149;
            static TLS_RSA_WITH_SEED_CBC_SHA = 150;
            static TLS_DH_DSS_WITH_SEED_CBC_SHA = 151;
            static TLS_DH_RSA_WITH_SEED_CBC_SHA = 152;
            static TLS_DHE_DSS_WITH_SEED_CBC_SHA = 153;
            static TLS_DHE_RSA_WITH_SEED_CBC_SHA = 154;
            static TLS_DH_anon_WITH_SEED_CBC_SHA = 155;
            static TLS_RSA_WITH_AES_128_GCM_SHA256 = 156;
            static TLS_RSA_WITH_AES_256_GCM_SHA384 = 157;
            static TLS_DHE_RSA_WITH_AES_128_GCM_SHA256 = 158;
            static TLS_DHE_RSA_WITH_AES_256_GCM_SHA384 = 159;
            static TLS_DH_RSA_WITH_AES_128_GCM_SHA256 = 160;
            static TLS_DH_RSA_WITH_AES_256_GCM_SHA384 = 161;
            static TLS_DHE_DSS_WITH_AES_128_GCM_SHA256 = 162;
            static TLS_DHE_DSS_WITH_AES_256_GCM_SHA384 = 163;
            static TLS_DH_DSS_WITH_AES_128_GCM_SHA256 = 164;
            static TLS_DH_DSS_WITH_AES_256_GCM_SHA384 = 165;
            static TLS_DH_anon_WITH_AES_128_GCM_SHA256 = 166;
            static TLS_DH_anon_WITH_AES_256_GCM_SHA384 = 167;
            static TLS_PSK_WITH_AES_128_GCM_SHA256 = 168;
            static TLS_PSK_WITH_AES_256_GCM_SHA384 = 169;
            static TLS_DHE_PSK_WITH_AES_128_GCM_SHA256 = 170;
            static TLS_DHE_PSK_WITH_AES_256_GCM_SHA384 = 171;
            static TLS_RSA_PSK_WITH_AES_128_GCM_SHA256 = 172;
            static TLS_RSA_PSK_WITH_AES_256_GCM_SHA384 = 173;
            static TLS_PSK_WITH_AES_128_CBC_SHA256 = 174;
            static TLS_PSK_WITH_AES_256_CBC_SHA384 = 175;
            static TLS_PSK_WITH_NULL_SHA256 = 176;
            static TLS_PSK_WITH_NULL_SHA384 = 177;
            static TLS_DHE_PSK_WITH_AES_128_CBC_SHA256 = 178;
            static TLS_DHE_PSK_WITH_AES_256_CBC_SHA384 = 179;
            static TLS_DHE_PSK_WITH_NULL_SHA256 = 180;
            static TLS_DHE_PSK_WITH_NULL_SHA384 = 181;
            static TLS_RSA_PSK_WITH_AES_128_CBC_SHA256 = 182;
            static TLS_RSA_PSK_WITH_AES_256_CBC_SHA384 = 183;
            static TLS_RSA_PSK_WITH_NULL_SHA256 = 184;
            static TLS_RSA_PSK_WITH_NULL_SHA384 = 185;
            static TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 186;
            static TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256 = 187;
            static TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 188;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256 = 189;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 190;
            static TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256 = 191;
            static TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 192;
            static TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256 = 193;
            static TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 194;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256 = 195;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 196;
            static TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256 = 197;
            static TLS_AES_128_GCM_SHA256 = 4865;
            static TLS_AES_256_GCM_SHA384 = 4866;
            static TLS_CHACHA20_POLY1305_SHA256 = 4867;
            static TLS_AES_128_CCM_SHA256 = 4868;
            static TLS_AES_128_CCM_8_SHA256 = 4869;
            static TLS_ECDH_ECDSA_WITH_NULL_SHA = 49153;
            static TLS_ECDH_ECDSA_WITH_RC4_128_SHA = 49154;
            static TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA = 49155;
            static TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA = 49156;
            static TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA = 49157;
            static TLS_ECDHE_ECDSA_WITH_NULL_SHA = 49158;
            static TLS_ECDHE_ECDSA_WITH_RC4_128_SHA = 49159;
            static TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA = 49160;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA = 49161;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA = 49162;
            static TLS_ECDH_RSA_WITH_NULL_SHA = 49163;
            static TLS_ECDH_RSA_WITH_RC4_128_SHA = 49164;
            static TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA = 49165;
            static TLS_ECDH_RSA_WITH_AES_128_CBC_SHA = 49166;
            static TLS_ECDH_RSA_WITH_AES_256_CBC_SHA = 49167;
            static TLS_ECDHE_RSA_WITH_NULL_SHA = 49168;
            static TLS_ECDHE_RSA_WITH_RC4_128_SHA = 49169;
            static TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA = 49170;
            static TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA = 49171;
            static TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA = 49172;
            static TLS_ECDH_anon_WITH_NULL_SHA = 49173;
            static TLS_ECDH_anon_WITH_RC4_128_SHA = 49174;
            static TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA = 49175;
            static TLS_ECDH_anon_WITH_AES_128_CBC_SHA = 49176;
            static TLS_ECDH_anon_WITH_AES_256_CBC_SHA = 49177;
            static TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA = 49178;
            static TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA = 49179;
            static TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA = 49180;
            static TLS_SRP_SHA_WITH_AES_128_CBC_SHA = 49181;
            static TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA = 49182;
            static TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA = 49183;
            static TLS_SRP_SHA_WITH_AES_256_CBC_SHA = 49184;
            static TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA = 49185;
            static TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA = 49186;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256 = 49187;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384 = 49188;
            static TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256 = 49189;
            static TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384 = 49190;
            static TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256 = 49191;
            static TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384 = 49192;
            static TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256 = 49193;
            static TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384 = 49194;
            static TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256 = 49195;
            static TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384 = 49196;
            static TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256 = 49197;
            static TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384 = 49198;
            static TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 = 49199;
            static TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 = 49200;
            static TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256 = 49201;
            static TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384 = 49202;
            static TLS_ECDHE_PSK_WITH_RC4_128_SHA = 49203;
            static TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA = 49204;
            static TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA = 49205;
            static TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA = 49206;
            static TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256 = 49207;
            static TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384 = 49208;
            static TLS_ECDHE_PSK_WITH_NULL_SHA = 49209;
            static TLS_ECDHE_PSK_WITH_NULL_SHA256 = 49210;
            static TLS_ECDHE_PSK_WITH_NULL_SHA384 = 49211;
            static TLS_RSA_WITH_ARIA_128_CBC_SHA256 = 49212;
            static TLS_RSA_WITH_ARIA_256_CBC_SHA384 = 49213;
            static TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256 = 49214;
            static TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384 = 49215;
            static TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256 = 49216;
            static TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384 = 49217;
            static TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256 = 49218;
            static TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384 = 49219;
            static TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256 = 49220;
            static TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384 = 49221;
            static TLS_DH_anon_WITH_ARIA_128_CBC_SHA256 = 49222;
            static TLS_DH_anon_WITH_ARIA_256_CBC_SHA384 = 49223;
            static TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256 = 49224;
            static TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384 = 49225;
            static TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256 = 49226;
            static TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384 = 49227;
            static TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256 = 49228;
            static TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384 = 49229;
            static TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256 = 49230;
            static TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384 = 49231;
            static TLS_RSA_WITH_ARIA_128_GCM_SHA256 = 49232;
            static TLS_RSA_WITH_ARIA_256_GCM_SHA384 = 49233;
            static TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256 = 49234;
            static TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384 = 49235;
            static TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256 = 49236;
            static TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384 = 49237;
            static TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256 = 49238;
            static TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384 = 49239;
            static TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256 = 49240;
            static TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384 = 49241;
            static TLS_DH_anon_WITH_ARIA_128_GCM_SHA256 = 49242;
            static TLS_DH_anon_WITH_ARIA_256_GCM_SHA384 = 49243;
            static TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256 = 49244;
            static TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384 = 49245;
            static TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256 = 49246;
            static TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384 = 49247;
            static TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256 = 49248;
            static TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384 = 49249;
            static TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256 = 49250;
            static TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384 = 49251;
            static TLS_PSK_WITH_ARIA_128_CBC_SHA256 = 49252;
            static TLS_PSK_WITH_ARIA_256_CBC_SHA384 = 49253;
            static TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256 = 49254;
            static TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384 = 49255;
            static TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256 = 49256;
            static TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384 = 49257;
            static TLS_PSK_WITH_ARIA_128_GCM_SHA256 = 49258;
            static TLS_PSK_WITH_ARIA_256_GCM_SHA384 = 49259;
            static TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256 = 49260;
            static TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384 = 49261;
            static TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256 = 49262;
            static TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384 = 49263;
            static TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256 = 49264;
            static TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384 = 49265;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 = 49266;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 = 49267;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 = 49268;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 = 49269;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 49270;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384 = 49271;
            static TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 49272;
            static TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384 = 49273;
            static TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49274;
            static TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49275;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49276;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49277;
            static TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49278;
            static TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49279;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256 = 49280;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384 = 49281;
            static TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256 = 49282;
            static TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384 = 49283;
            static TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256 = 49284;
            static TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384 = 49285;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 = 49286;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 = 49287;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 = 49288;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 = 49289;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49290;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49291;
            static TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49292;
            static TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49293;
            static TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49294;
            static TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49295;
            static TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49296;
            static TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49297;
            static TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49298;
            static TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49299;
            static TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49300;
            static TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49301;
            static TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49302;
            static TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49303;
            static TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49304;
            static TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49305;
            static TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49306;
            static TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49307;
            static TLS_RSA_WITH_AES_128_CCM = 49308;
            static TLS_RSA_WITH_AES_256_CCM = 49309;
            static TLS_DHE_RSA_WITH_AES_128_CCM = 49310;
            static TLS_DHE_RSA_WITH_AES_256_CCM = 49311;
            static TLS_RSA_WITH_AES_128_CCM_8 = 49312;
            static TLS_RSA_WITH_AES_256_CCM_8 = 49313;
            static TLS_DHE_RSA_WITH_AES_128_CCM_8 = 49314;
            static TLS_DHE_RSA_WITH_AES_256_CCM_8 = 49315;
            static TLS_PSK_WITH_AES_128_CCM = 49316;
            static TLS_PSK_WITH_AES_256_CCM = 49317;
            static TLS_DHE_PSK_WITH_AES_128_CCM = 49318;
            static TLS_DHE_PSK_WITH_AES_256_CCM = 49319;
            static TLS_PSK_WITH_AES_128_CCM_8 = 49320;
            static TLS_PSK_WITH_AES_256_CCM_8 = 49321;
            static TLS_PSK_DHE_WITH_AES_128_CCM_8 = 49322;
            static TLS_PSK_DHE_WITH_AES_256_CCM_8 = 49323;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CCM = 49324;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CCM = 49325;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8 = 49326;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8 = 49327;
            static TLS_ECCPWD_WITH_AES_128_GCM_SHA256 = 49328;
            static TLS_ECCPWD_WITH_AES_256_GCM_SHA384 = 49329;
            static TLS_ECCPWD_WITH_AES_128_CCM_SHA256 = 49330;
            static TLS_ECCPWD_WITH_AES_256_CCM_SHA384 = 49331;
            static TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256 = 52392;
            static TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256 = 52393;
            static TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256 = 52394;
            static TLS_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52395;
            static TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52396;
            static TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52397;
            static TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52398;
            static TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256 = 53249;
            static TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384 = 53250;
            static TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256 = 53251;
            static TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256 = 53253;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TLS_NULL_WITH_NULL_NULL": 0n,
                    "TLS_RSA_WITH_NULL_MD5": 1n,
                    "TLS_RSA_WITH_NULL_SHA": 2n,
                    "TLS_RSA_EXPORT_WITH_RC4_40_MD5": 3n,
                    "TLS_RSA_WITH_RC4_128_MD5": 4n,
                    "TLS_RSA_WITH_RC4_128_SHA": 5n,
                    "TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5": 6n,
                    "TLS_RSA_WITH_IDEA_CBC_SHA": 7n,
                    "TLS_RSA_EXPORT_WITH_DES40_CBC_SHA": 8n,
                    "TLS_RSA_WITH_DES_CBC_SHA": 9n,
                    "TLS_RSA_WITH_3DES_EDE_CBC_SHA": 10n,
                    "TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA": 11n,
                    "TLS_DH_DSS_WITH_DES_CBC_SHA": 12n,
                    "TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA": 13n,
                    "TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA": 14n,
                    "TLS_DH_RSA_WITH_DES_CBC_SHA": 15n,
                    "TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA": 16n,
                    "TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA": 17n,
                    "TLS_DHE_DSS_WITH_DES_CBC_SHA": 18n,
                    "TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA": 19n,
                    "TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA": 20n,
                    "TLS_DHE_RSA_WITH_DES_CBC_SHA": 21n,
                    "TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA": 22n,
                    "TLS_DH_anon_EXPORT_WITH_RC4_40_MD5": 23n,
                    "TLS_DH_anon_WITH_RC4_128_MD5": 24n,
                    "TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA": 25n,
                    "TLS_DH_anon_WITH_DES_CBC_SHA": 26n,
                    "TLS_DH_anon_WITH_3DES_EDE_CBC_SHA": 27n,
                    "TLS_KRB5_WITH_DES_CBC_SHA": 30n,
                    "TLS_KRB5_WITH_3DES_EDE_CBC_SHA": 31n,
                    "TLS_KRB5_WITH_RC4_128_SHA": 32n,
                    "TLS_KRB5_WITH_IDEA_CBC_SHA": 33n,
                    "TLS_KRB5_WITH_DES_CBC_MD5": 34n,
                    "TLS_KRB5_WITH_3DES_EDE_CBC_MD5": 35n,
                    "TLS_KRB5_WITH_RC4_128_MD5": 36n,
                    "TLS_KRB5_WITH_IDEA_CBC_MD5": 37n,
                    "TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA": 38n,
                    "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA": 39n,
                    "TLS_KRB5_EXPORT_WITH_RC4_40_SHA": 40n,
                    "TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5": 41n,
                    "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5": 42n,
                    "TLS_KRB5_EXPORT_WITH_RC4_40_MD5": 43n,
                    "TLS_PSK_WITH_NULL_SHA": 44n,
                    "TLS_DHE_PSK_WITH_NULL_SHA": 45n,
                    "TLS_RSA_PSK_WITH_NULL_SHA": 46n,
                    "TLS_RSA_WITH_AES_128_CBC_SHA": 47n,
                    "TLS_DH_DSS_WITH_AES_128_CBC_SHA": 48n,
                    "TLS_DH_RSA_WITH_AES_128_CBC_SHA": 49n,
                    "TLS_DHE_DSS_WITH_AES_128_CBC_SHA": 50n,
                    "TLS_DHE_RSA_WITH_AES_128_CBC_SHA": 51n,
                    "TLS_DH_anon_WITH_AES_128_CBC_SHA": 52n,
                    "TLS_RSA_WITH_AES_256_CBC_SHA": 53n,
                    "TLS_DH_DSS_WITH_AES_256_CBC_SHA": 54n,
                    "TLS_DH_RSA_WITH_AES_256_CBC_SHA": 55n,
                    "TLS_DHE_DSS_WITH_AES_256_CBC_SHA": 56n,
                    "TLS_DHE_RSA_WITH_AES_256_CBC_SHA": 57n,
                    "TLS_DH_anon_WITH_AES_256_CBC_SHA": 58n,
                    "TLS_RSA_WITH_NULL_SHA256": 59n,
                    "TLS_RSA_WITH_AES_128_CBC_SHA256": 60n,
                    "TLS_RSA_WITH_AES_256_CBC_SHA256": 61n,
                    "TLS_DH_DSS_WITH_AES_128_CBC_SHA256": 62n,
                    "TLS_DH_RSA_WITH_AES_128_CBC_SHA256": 63n,
                    "TLS_DHE_DSS_WITH_AES_128_CBC_SHA256": 64n,
                    "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA": 65n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA": 66n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA": 67n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA": 68n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA": 69n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA": 70n,
                    "TLS_DHE_RSA_WITH_AES_128_CBC_SHA256": 103n,
                    "TLS_DH_DSS_WITH_AES_256_CBC_SHA256": 104n,
                    "TLS_DH_RSA_WITH_AES_256_CBC_SHA256": 105n,
                    "TLS_DHE_DSS_WITH_AES_256_CBC_SHA256": 106n,
                    "TLS_DHE_RSA_WITH_AES_256_CBC_SHA256": 107n,
                    "TLS_DH_anon_WITH_AES_128_CBC_SHA256": 108n,
                    "TLS_DH_anon_WITH_AES_256_CBC_SHA256": 109n,
                    "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA": 132n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA": 133n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA": 134n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA": 135n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA": 136n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA": 137n,
                    "TLS_PSK_WITH_RC4_128_SHA": 138n,
                    "TLS_PSK_WITH_3DES_EDE_CBC_SHA": 139n,
                    "TLS_PSK_WITH_AES_128_CBC_SHA": 140n,
                    "TLS_PSK_WITH_AES_256_CBC_SHA": 141n,
                    "TLS_DHE_PSK_WITH_RC4_128_SHA": 142n,
                    "TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA": 143n,
                    "TLS_DHE_PSK_WITH_AES_128_CBC_SHA": 144n,
                    "TLS_DHE_PSK_WITH_AES_256_CBC_SHA": 145n,
                    "TLS_RSA_PSK_WITH_RC4_128_SHA": 146n,
                    "TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA": 147n,
                    "TLS_RSA_PSK_WITH_AES_128_CBC_SHA": 148n,
                    "TLS_RSA_PSK_WITH_AES_256_CBC_SHA": 149n,
                    "TLS_RSA_WITH_SEED_CBC_SHA": 150n,
                    "TLS_DH_DSS_WITH_SEED_CBC_SHA": 151n,
                    "TLS_DH_RSA_WITH_SEED_CBC_SHA": 152n,
                    "TLS_DHE_DSS_WITH_SEED_CBC_SHA": 153n,
                    "TLS_DHE_RSA_WITH_SEED_CBC_SHA": 154n,
                    "TLS_DH_anon_WITH_SEED_CBC_SHA": 155n,
                    "TLS_RSA_WITH_AES_128_GCM_SHA256": 156n,
                    "TLS_RSA_WITH_AES_256_GCM_SHA384": 157n,
                    "TLS_DHE_RSA_WITH_AES_128_GCM_SHA256": 158n,
                    "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384": 159n,
                    "TLS_DH_RSA_WITH_AES_128_GCM_SHA256": 160n,
                    "TLS_DH_RSA_WITH_AES_256_GCM_SHA384": 161n,
                    "TLS_DHE_DSS_WITH_AES_128_GCM_SHA256": 162n,
                    "TLS_DHE_DSS_WITH_AES_256_GCM_SHA384": 163n,
                    "TLS_DH_DSS_WITH_AES_128_GCM_SHA256": 164n,
                    "TLS_DH_DSS_WITH_AES_256_GCM_SHA384": 165n,
                    "TLS_DH_anon_WITH_AES_128_GCM_SHA256": 166n,
                    "TLS_DH_anon_WITH_AES_256_GCM_SHA384": 167n,
                    "TLS_PSK_WITH_AES_128_GCM_SHA256": 168n,
                    "TLS_PSK_WITH_AES_256_GCM_SHA384": 169n,
                    "TLS_DHE_PSK_WITH_AES_128_GCM_SHA256": 170n,
                    "TLS_DHE_PSK_WITH_AES_256_GCM_SHA384": 171n,
                    "TLS_RSA_PSK_WITH_AES_128_GCM_SHA256": 172n,
                    "TLS_RSA_PSK_WITH_AES_256_GCM_SHA384": 173n,
                    "TLS_PSK_WITH_AES_128_CBC_SHA256": 174n,
                    "TLS_PSK_WITH_AES_256_CBC_SHA384": 175n,
                    "TLS_PSK_WITH_NULL_SHA256": 176n,
                    "TLS_PSK_WITH_NULL_SHA384": 177n,
                    "TLS_DHE_PSK_WITH_AES_128_CBC_SHA256": 178n,
                    "TLS_DHE_PSK_WITH_AES_256_CBC_SHA384": 179n,
                    "TLS_DHE_PSK_WITH_NULL_SHA256": 180n,
                    "TLS_DHE_PSK_WITH_NULL_SHA384": 181n,
                    "TLS_RSA_PSK_WITH_AES_128_CBC_SHA256": 182n,
                    "TLS_RSA_PSK_WITH_AES_256_CBC_SHA384": 183n,
                    "TLS_RSA_PSK_WITH_NULL_SHA256": 184n,
                    "TLS_RSA_PSK_WITH_NULL_SHA384": 185n,
                    "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256": 186n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256": 187n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256": 188n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256": 189n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256": 190n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256": 191n,
                    "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256": 192n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256": 193n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256": 194n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256": 195n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256": 196n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256": 197n,
                    "TLS_AES_128_GCM_SHA256": 4865n,
                    "TLS_AES_256_GCM_SHA384": 4866n,
                    "TLS_CHACHA20_POLY1305_SHA256": 4867n,
                    "TLS_AES_128_CCM_SHA256": 4868n,
                    "TLS_AES_128_CCM_8_SHA256": 4869n,
                    "TLS_ECDH_ECDSA_WITH_NULL_SHA": 49153n,
                    "TLS_ECDH_ECDSA_WITH_RC4_128_SHA": 49154n,
                    "TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA": 49155n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA": 49156n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA": 49157n,
                    "TLS_ECDHE_ECDSA_WITH_NULL_SHA": 49158n,
                    "TLS_ECDHE_ECDSA_WITH_RC4_128_SHA": 49159n,
                    "TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA": 49160n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA": 49161n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA": 49162n,
                    "TLS_ECDH_RSA_WITH_NULL_SHA": 49163n,
                    "TLS_ECDH_RSA_WITH_RC4_128_SHA": 49164n,
                    "TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA": 49165n,
                    "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA": 49166n,
                    "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA": 49167n,
                    "TLS_ECDHE_RSA_WITH_NULL_SHA": 49168n,
                    "TLS_ECDHE_RSA_WITH_RC4_128_SHA": 49169n,
                    "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA": 49170n,
                    "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA": 49171n,
                    "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA": 49172n,
                    "TLS_ECDH_anon_WITH_NULL_SHA": 49173n,
                    "TLS_ECDH_anon_WITH_RC4_128_SHA": 49174n,
                    "TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA": 49175n,
                    "TLS_ECDH_anon_WITH_AES_128_CBC_SHA": 49176n,
                    "TLS_ECDH_anon_WITH_AES_256_CBC_SHA": 49177n,
                    "TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA": 49178n,
                    "TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA": 49179n,
                    "TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA": 49180n,
                    "TLS_SRP_SHA_WITH_AES_128_CBC_SHA": 49181n,
                    "TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA": 49182n,
                    "TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA": 49183n,
                    "TLS_SRP_SHA_WITH_AES_256_CBC_SHA": 49184n,
                    "TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA": 49185n,
                    "TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA": 49186n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256": 49187n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384": 49188n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256": 49189n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384": 49190n,
                    "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256": 49191n,
                    "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384": 49192n,
                    "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256": 49193n,
                    "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384": 49194n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256": 49195n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384": 49196n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256": 49197n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384": 49198n,
                    "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256": 49199n,
                    "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384": 49200n,
                    "TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256": 49201n,
                    "TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384": 49202n,
                    "TLS_ECDHE_PSK_WITH_RC4_128_SHA": 49203n,
                    "TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA": 49204n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA": 49205n,
                    "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA": 49206n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256": 49207n,
                    "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384": 49208n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA": 49209n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA256": 49210n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA384": 49211n,
                    "TLS_RSA_WITH_ARIA_128_CBC_SHA256": 49212n,
                    "TLS_RSA_WITH_ARIA_256_CBC_SHA384": 49213n,
                    "TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256": 49214n,
                    "TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384": 49215n,
                    "TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256": 49216n,
                    "TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384": 49217n,
                    "TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256": 49218n,
                    "TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384": 49219n,
                    "TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256": 49220n,
                    "TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384": 49221n,
                    "TLS_DH_anon_WITH_ARIA_128_CBC_SHA256": 49222n,
                    "TLS_DH_anon_WITH_ARIA_256_CBC_SHA384": 49223n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256": 49224n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384": 49225n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256": 49226n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384": 49227n,
                    "TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256": 49228n,
                    "TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384": 49229n,
                    "TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256": 49230n,
                    "TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384": 49231n,
                    "TLS_RSA_WITH_ARIA_128_GCM_SHA256": 49232n,
                    "TLS_RSA_WITH_ARIA_256_GCM_SHA384": 49233n,
                    "TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256": 49234n,
                    "TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384": 49235n,
                    "TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256": 49236n,
                    "TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384": 49237n,
                    "TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256": 49238n,
                    "TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384": 49239n,
                    "TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256": 49240n,
                    "TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384": 49241n,
                    "TLS_DH_anon_WITH_ARIA_128_GCM_SHA256": 49242n,
                    "TLS_DH_anon_WITH_ARIA_256_GCM_SHA384": 49243n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256": 49244n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384": 49245n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256": 49246n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384": 49247n,
                    "TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256": 49248n,
                    "TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384": 49249n,
                    "TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256": 49250n,
                    "TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384": 49251n,
                    "TLS_PSK_WITH_ARIA_128_CBC_SHA256": 49252n,
                    "TLS_PSK_WITH_ARIA_256_CBC_SHA384": 49253n,
                    "TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256": 49254n,
                    "TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384": 49255n,
                    "TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256": 49256n,
                    "TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384": 49257n,
                    "TLS_PSK_WITH_ARIA_128_GCM_SHA256": 49258n,
                    "TLS_PSK_WITH_ARIA_256_GCM_SHA384": 49259n,
                    "TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256": 49260n,
                    "TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384": 49261n,
                    "TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256": 49262n,
                    "TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384": 49263n,
                    "TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256": 49264n,
                    "TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384": 49265n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256": 49266n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384": 49267n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256": 49268n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384": 49269n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256": 49270n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384": 49271n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256": 49272n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384": 49273n,
                    "TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49274n,
                    "TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49275n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49276n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49277n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49278n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49279n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256": 49280n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384": 49281n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256": 49282n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384": 49283n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256": 49284n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384": 49285n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256": 49286n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384": 49287n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256": 49288n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384": 49289n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49290n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49291n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49292n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49293n,
                    "TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49294n,
                    "TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49295n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49296n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49297n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49298n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49299n,
                    "TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49300n,
                    "TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49301n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49302n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49303n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49304n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49305n,
                    "TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49306n,
                    "TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49307n,
                    "TLS_RSA_WITH_AES_128_CCM": 49308n,
                    "TLS_RSA_WITH_AES_256_CCM": 49309n,
                    "TLS_DHE_RSA_WITH_AES_128_CCM": 49310n,
                    "TLS_DHE_RSA_WITH_AES_256_CCM": 49311n,
                    "TLS_RSA_WITH_AES_128_CCM_8": 49312n,
                    "TLS_RSA_WITH_AES_256_CCM_8": 49313n,
                    "TLS_DHE_RSA_WITH_AES_128_CCM_8": 49314n,
                    "TLS_DHE_RSA_WITH_AES_256_CCM_8": 49315n,
                    "TLS_PSK_WITH_AES_128_CCM": 49316n,
                    "TLS_PSK_WITH_AES_256_CCM": 49317n,
                    "TLS_DHE_PSK_WITH_AES_128_CCM": 49318n,
                    "TLS_DHE_PSK_WITH_AES_256_CCM": 49319n,
                    "TLS_PSK_WITH_AES_128_CCM_8": 49320n,
                    "TLS_PSK_WITH_AES_256_CCM_8": 49321n,
                    "TLS_PSK_DHE_WITH_AES_128_CCM_8": 49322n,
                    "TLS_PSK_DHE_WITH_AES_256_CCM_8": 49323n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CCM": 49324n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CCM": 49325n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8": 49326n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8": 49327n,
                    "TLS_ECCPWD_WITH_AES_128_GCM_SHA256": 49328n,
                    "TLS_ECCPWD_WITH_AES_256_GCM_SHA384": 49329n,
                    "TLS_ECCPWD_WITH_AES_128_CCM_SHA256": 49330n,
                    "TLS_ECCPWD_WITH_AES_256_CCM_SHA384": 49331n,
                    "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256": 52392n,
                    "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256": 52393n,
                    "TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256": 52394n,
                    "TLS_PSK_WITH_CHACHA20_POLY1305_SHA256": 52395n,
                    "TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256": 52396n,
                    "TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256": 52397n,
                    "TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256": 52398n,
                    "TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256": 53249n,
                    "TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384": 53250n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256": 53251n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256": 53253n
                };
            }
            static $h = 1413521;
            static $z = 2;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.UInt16; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":589825,"l":[{"t":1413521,"n":"TLS_NULL_WITH_NULL_NULL","d":1413521,"h":4296380817,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_NULL_MD5","d":1413521,"h":8591348113,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_NULL_SHA","d":1413521,"h":12886315409,"f":33},{"t":1413521,"n":"TLS_RSA_EXPORT_WITH_RC4_40_MD5","d":1413521,"h":17181282705,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_RC4_128_MD5","d":1413521,"h":21476250001,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_RC4_128_SHA","d":1413521,"h":25771217297,"f":33},{"t":1413521,"n":"TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5","d":1413521,"h":30066184593,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_IDEA_CBC_SHA","d":1413521,"h":34361151889,"f":33},{"t":1413521,"n":"TLS_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1413521,"h":38656119185,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_DES_CBC_SHA","d":1413521,"h":42951086481,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":47246053777,"f":33},{"t":1413521,"n":"TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA","d":1413521,"h":51541021073,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_DES_CBC_SHA","d":1413521,"h":55835988369,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":60130955665,"f":33},{"t":1413521,"n":"TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1413521,"h":64425922961,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_DES_CBC_SHA","d":1413521,"h":68720890257,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":73015857553,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA","d":1413521,"h":77310824849,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_DES_CBC_SHA","d":1413521,"h":81605792145,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":85900759441,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1413521,"h":90195726737,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_DES_CBC_SHA","d":1413521,"h":94490694033,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":98785661329,"f":33},{"t":1413521,"n":"TLS_DH_anon_EXPORT_WITH_RC4_40_MD5","d":1413521,"h":103080628625,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_RC4_128_MD5","d":1413521,"h":107375595921,"f":33},{"t":1413521,"n":"TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA","d":1413521,"h":111670563217,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_DES_CBC_SHA","d":1413521,"h":115965530513,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":120260497809,"f":33},{"t":1413521,"n":"TLS_KRB5_WITH_DES_CBC_SHA","d":1413521,"h":124555465105,"f":33},{"t":1413521,"n":"TLS_KRB5_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":128850432401,"f":33},{"t":1413521,"n":"TLS_KRB5_WITH_RC4_128_SHA","d":1413521,"h":133145399697,"f":33},{"t":1413521,"n":"TLS_KRB5_WITH_IDEA_CBC_SHA","d":1413521,"h":137440366993,"f":33},{"t":1413521,"n":"TLS_KRB5_WITH_DES_CBC_MD5","d":1413521,"h":141735334289,"f":33},{"t":1413521,"n":"TLS_KRB5_WITH_3DES_EDE_CBC_MD5","d":1413521,"h":146030301585,"f":33},{"t":1413521,"n":"TLS_KRB5_WITH_RC4_128_MD5","d":1413521,"h":150325268881,"f":33},{"t":1413521,"n":"TLS_KRB5_WITH_IDEA_CBC_MD5","d":1413521,"h":154620236177,"f":33},{"t":1413521,"n":"TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA","d":1413521,"h":158915203473,"f":33},{"t":1413521,"n":"TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA","d":1413521,"h":163210170769,"f":33},{"t":1413521,"n":"TLS_KRB5_EXPORT_WITH_RC4_40_SHA","d":1413521,"h":167505138065,"f":33},{"t":1413521,"n":"TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5","d":1413521,"h":171800105361,"f":33},{"t":1413521,"n":"TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5","d":1413521,"h":176095072657,"f":33},{"t":1413521,"n":"TLS_KRB5_EXPORT_WITH_RC4_40_MD5","d":1413521,"h":180390039953,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_NULL_SHA","d":1413521,"h":184685007249,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_NULL_SHA","d":1413521,"h":188979974545,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_NULL_SHA","d":1413521,"h":193274941841,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_AES_128_CBC_SHA","d":1413521,"h":197569909137,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_AES_128_CBC_SHA","d":1413521,"h":201864876433,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_AES_128_CBC_SHA","d":1413521,"h":206159843729,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_AES_128_CBC_SHA","d":1413521,"h":210454811025,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_AES_128_CBC_SHA","d":1413521,"h":214749778321,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_AES_128_CBC_SHA","d":1413521,"h":219044745617,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_AES_256_CBC_SHA","d":1413521,"h":223339712913,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_AES_256_CBC_SHA","d":1413521,"h":227634680209,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_AES_256_CBC_SHA","d":1413521,"h":231929647505,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_AES_256_CBC_SHA","d":1413521,"h":236224614801,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_AES_256_CBC_SHA","d":1413521,"h":240519582097,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_AES_256_CBC_SHA","d":1413521,"h":244814549393,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_NULL_SHA256","d":1413521,"h":249109516689,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_AES_128_CBC_SHA256","d":1413521,"h":253404483985,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_AES_256_CBC_SHA256","d":1413521,"h":257699451281,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_AES_128_CBC_SHA256","d":1413521,"h":261994418577,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_AES_128_CBC_SHA256","d":1413521,"h":266289385873,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_AES_128_CBC_SHA256","d":1413521,"h":270584353169,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1413521,"h":274879320465,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA","d":1413521,"h":279174287761,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1413521,"h":283469255057,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA","d":1413521,"h":287764222353,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1413521,"h":292059189649,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA","d":1413521,"h":296354156945,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_AES_128_CBC_SHA256","d":1413521,"h":300649124241,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_AES_256_CBC_SHA256","d":1413521,"h":304944091537,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_AES_256_CBC_SHA256","d":1413521,"h":309239058833,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_AES_256_CBC_SHA256","d":1413521,"h":313534026129,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_AES_256_CBC_SHA256","d":1413521,"h":317828993425,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_AES_128_CBC_SHA256","d":1413521,"h":322123960721,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_AES_256_CBC_SHA256","d":1413521,"h":326418928017,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1413521,"h":330713895313,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA","d":1413521,"h":335008862609,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1413521,"h":339303829905,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA","d":1413521,"h":343598797201,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1413521,"h":347893764497,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA","d":1413521,"h":352188731793,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_RC4_128_SHA","d":1413521,"h":356483699089,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":360778666385,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_AES_128_CBC_SHA","d":1413521,"h":365073633681,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_AES_256_CBC_SHA","d":1413521,"h":369368600977,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_RC4_128_SHA","d":1413521,"h":373663568273,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":377958535569,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_AES_128_CBC_SHA","d":1413521,"h":382253502865,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_AES_256_CBC_SHA","d":1413521,"h":386548470161,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_RC4_128_SHA","d":1413521,"h":390843437457,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":395138404753,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_AES_128_CBC_SHA","d":1413521,"h":399433372049,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_AES_256_CBC_SHA","d":1413521,"h":403728339345,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_SEED_CBC_SHA","d":1413521,"h":408023306641,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_SEED_CBC_SHA","d":1413521,"h":412318273937,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_SEED_CBC_SHA","d":1413521,"h":416613241233,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_SEED_CBC_SHA","d":1413521,"h":420908208529,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_SEED_CBC_SHA","d":1413521,"h":425203175825,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_SEED_CBC_SHA","d":1413521,"h":429498143121,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_AES_128_GCM_SHA256","d":1413521,"h":433793110417,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_AES_256_GCM_SHA384","d":1413521,"h":438088077713,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_AES_128_GCM_SHA256","d":1413521,"h":442383045009,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_AES_256_GCM_SHA384","d":1413521,"h":446678012305,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_AES_128_GCM_SHA256","d":1413521,"h":450972979601,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_AES_256_GCM_SHA384","d":1413521,"h":455267946897,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_AES_128_GCM_SHA256","d":1413521,"h":459562914193,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_AES_256_GCM_SHA384","d":1413521,"h":463857881489,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_AES_128_GCM_SHA256","d":1413521,"h":468152848785,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_AES_256_GCM_SHA384","d":1413521,"h":472447816081,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_AES_128_GCM_SHA256","d":1413521,"h":476742783377,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_AES_256_GCM_SHA384","d":1413521,"h":481037750673,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_AES_128_GCM_SHA256","d":1413521,"h":485332717969,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_AES_256_GCM_SHA384","d":1413521,"h":489627685265,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_AES_128_GCM_SHA256","d":1413521,"h":493922652561,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_AES_256_GCM_SHA384","d":1413521,"h":498217619857,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_AES_128_GCM_SHA256","d":1413521,"h":502512587153,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_AES_256_GCM_SHA384","d":1413521,"h":506807554449,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_AES_128_CBC_SHA256","d":1413521,"h":511102521745,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_AES_256_CBC_SHA384","d":1413521,"h":515397489041,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_NULL_SHA256","d":1413521,"h":519692456337,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_NULL_SHA384","d":1413521,"h":523987423633,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_AES_128_CBC_SHA256","d":1413521,"h":528282390929,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_AES_256_CBC_SHA384","d":1413521,"h":532577358225,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_NULL_SHA256","d":1413521,"h":536872325521,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_NULL_SHA384","d":1413521,"h":541167292817,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_AES_128_CBC_SHA256","d":1413521,"h":545462260113,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_AES_256_CBC_SHA384","d":1413521,"h":549757227409,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_NULL_SHA256","d":1413521,"h":554052194705,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_NULL_SHA384","d":1413521,"h":558347162001,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1413521,"h":562642129297,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256","d":1413521,"h":566937096593,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1413521,"h":571232063889,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256","d":1413521,"h":575527031185,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1413521,"h":579821998481,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256","d":1413521,"h":584116965777,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1413521,"h":588411933073,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256","d":1413521,"h":592706900369,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1413521,"h":597001867665,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256","d":1413521,"h":601296834961,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1413521,"h":605591802257,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256","d":1413521,"h":609886769553,"f":33},{"t":1413521,"n":"TLS_AES_128_GCM_SHA256","d":1413521,"h":614181736849,"f":33},{"t":1413521,"n":"TLS_AES_256_GCM_SHA384","d":1413521,"h":618476704145,"f":33},{"t":1413521,"n":"TLS_CHACHA20_POLY1305_SHA256","d":1413521,"h":622771671441,"f":33},{"t":1413521,"n":"TLS_AES_128_CCM_SHA256","d":1413521,"h":627066638737,"f":33},{"t":1413521,"n":"TLS_AES_128_CCM_8_SHA256","d":1413521,"h":631361606033,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_NULL_SHA","d":1413521,"h":635656573329,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_RC4_128_SHA","d":1413521,"h":639951540625,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":644246507921,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA","d":1413521,"h":648541475217,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA","d":1413521,"h":652836442513,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_NULL_SHA","d":1413521,"h":657131409809,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_RC4_128_SHA","d":1413521,"h":661426377105,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":665721344401,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA","d":1413521,"h":670016311697,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA","d":1413521,"h":674311278993,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_NULL_SHA","d":1413521,"h":678606246289,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_RC4_128_SHA","d":1413521,"h":682901213585,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":687196180881,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_AES_128_CBC_SHA","d":1413521,"h":691491148177,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_AES_256_CBC_SHA","d":1413521,"h":695786115473,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_NULL_SHA","d":1413521,"h":700081082769,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_RC4_128_SHA","d":1413521,"h":704376050065,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":708671017361,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA","d":1413521,"h":712965984657,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA","d":1413521,"h":717260951953,"f":33},{"t":1413521,"n":"TLS_ECDH_anon_WITH_NULL_SHA","d":1413521,"h":721555919249,"f":33},{"t":1413521,"n":"TLS_ECDH_anon_WITH_RC4_128_SHA","d":1413521,"h":725850886545,"f":33},{"t":1413521,"n":"TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":730145853841,"f":33},{"t":1413521,"n":"TLS_ECDH_anon_WITH_AES_128_CBC_SHA","d":1413521,"h":734440821137,"f":33},{"t":1413521,"n":"TLS_ECDH_anon_WITH_AES_256_CBC_SHA","d":1413521,"h":738735788433,"f":33},{"t":1413521,"n":"TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":743030755729,"f":33},{"t":1413521,"n":"TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":747325723025,"f":33},{"t":1413521,"n":"TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":751620690321,"f":33},{"t":1413521,"n":"TLS_SRP_SHA_WITH_AES_128_CBC_SHA","d":1413521,"h":755915657617,"f":33},{"t":1413521,"n":"TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA","d":1413521,"h":760210624913,"f":33},{"t":1413521,"n":"TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA","d":1413521,"h":764505592209,"f":33},{"t":1413521,"n":"TLS_SRP_SHA_WITH_AES_256_CBC_SHA","d":1413521,"h":768800559505,"f":33},{"t":1413521,"n":"TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA","d":1413521,"h":773095526801,"f":33},{"t":1413521,"n":"TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA","d":1413521,"h":777390494097,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256","d":1413521,"h":781685461393,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384","d":1413521,"h":785980428689,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256","d":1413521,"h":790275395985,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384","d":1413521,"h":794570363281,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256","d":1413521,"h":798865330577,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384","d":1413521,"h":803160297873,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256","d":1413521,"h":807455265169,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384","d":1413521,"h":811750232465,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256","d":1413521,"h":816045199761,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384","d":1413521,"h":820340167057,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256","d":1413521,"h":824635134353,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384","d":1413521,"h":828930101649,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256","d":1413521,"h":833225068945,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384","d":1413521,"h":837520036241,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256","d":1413521,"h":841815003537,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384","d":1413521,"h":846109970833,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_RC4_128_SHA","d":1413521,"h":850404938129,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA","d":1413521,"h":854699905425,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA","d":1413521,"h":858994872721,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA","d":1413521,"h":863289840017,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256","d":1413521,"h":867584807313,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384","d":1413521,"h":871879774609,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA","d":1413521,"h":876174741905,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA256","d":1413521,"h":880469709201,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA384","d":1413521,"h":884764676497,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_ARIA_128_CBC_SHA256","d":1413521,"h":889059643793,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_ARIA_256_CBC_SHA384","d":1413521,"h":893354611089,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256","d":1413521,"h":897649578385,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384","d":1413521,"h":901944545681,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256","d":1413521,"h":906239512977,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384","d":1413521,"h":910534480273,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256","d":1413521,"h":914829447569,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384","d":1413521,"h":919124414865,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256","d":1413521,"h":923419382161,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384","d":1413521,"h":927714349457,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_ARIA_128_CBC_SHA256","d":1413521,"h":932009316753,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_ARIA_256_CBC_SHA384","d":1413521,"h":936304284049,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256","d":1413521,"h":940599251345,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384","d":1413521,"h":944894218641,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256","d":1413521,"h":949189185937,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384","d":1413521,"h":953484153233,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256","d":1413521,"h":957779120529,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384","d":1413521,"h":962074087825,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256","d":1413521,"h":966369055121,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384","d":1413521,"h":970664022417,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_ARIA_128_GCM_SHA256","d":1413521,"h":974958989713,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_ARIA_256_GCM_SHA384","d":1413521,"h":979253957009,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256","d":1413521,"h":983548924305,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384","d":1413521,"h":987843891601,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256","d":1413521,"h":992138858897,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384","d":1413521,"h":996433826193,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256","d":1413521,"h":1000728793489,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384","d":1413521,"h":1005023760785,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256","d":1413521,"h":1009318728081,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384","d":1413521,"h":1013613695377,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_ARIA_128_GCM_SHA256","d":1413521,"h":1017908662673,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_ARIA_256_GCM_SHA384","d":1413521,"h":1022203629969,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256","d":1413521,"h":1026498597265,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384","d":1413521,"h":1030793564561,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256","d":1413521,"h":1035088531857,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384","d":1413521,"h":1039383499153,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256","d":1413521,"h":1043678466449,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384","d":1413521,"h":1047973433745,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256","d":1413521,"h":1052268401041,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384","d":1413521,"h":1056563368337,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_ARIA_128_CBC_SHA256","d":1413521,"h":1060858335633,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_ARIA_256_CBC_SHA384","d":1413521,"h":1065153302929,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256","d":1413521,"h":1069448270225,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384","d":1413521,"h":1073743237521,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256","d":1413521,"h":1078038204817,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384","d":1413521,"h":1082333172113,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_ARIA_128_GCM_SHA256","d":1413521,"h":1086628139409,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_ARIA_256_GCM_SHA384","d":1413521,"h":1090923106705,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256","d":1413521,"h":1095218074001,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384","d":1413521,"h":1099513041297,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256","d":1413521,"h":1103808008593,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384","d":1413521,"h":1108102975889,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256","d":1413521,"h":1112397943185,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384","d":1413521,"h":1116692910481,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256","d":1413521,"h":1120987877777,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384","d":1413521,"h":1125282845073,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256","d":1413521,"h":1129577812369,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384","d":1413521,"h":1133872779665,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1413521,"h":1138167746961,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384","d":1413521,"h":1142462714257,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1413521,"h":1146757681553,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384","d":1413521,"h":1151052648849,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1413521,"h":1155347616145,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1413521,"h":1159642583441,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1413521,"h":1163937550737,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1413521,"h":1168232518033,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1413521,"h":1172527485329,"f":33},{"t":1413521,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1413521,"h":1176822452625,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256","d":1413521,"h":1181117419921,"f":33},{"t":1413521,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384","d":1413521,"h":1185412387217,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256","d":1413521,"h":1189707354513,"f":33},{"t":1413521,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384","d":1413521,"h":1194002321809,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256","d":1413521,"h":1198297289105,"f":33},{"t":1413521,"n":"TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384","d":1413521,"h":1202592256401,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256","d":1413521,"h":1206887223697,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384","d":1413521,"h":1211182190993,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256","d":1413521,"h":1215477158289,"f":33},{"t":1413521,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384","d":1413521,"h":1219772125585,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1413521,"h":1224067092881,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1413521,"h":1228362060177,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1413521,"h":1232657027473,"f":33},{"t":1413521,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1413521,"h":1236951994769,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1413521,"h":1241246962065,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1413521,"h":1245541929361,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1413521,"h":1249836896657,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1413521,"h":1254131863953,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1413521,"h":1258426831249,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1413521,"h":1262721798545,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1413521,"h":1267016765841,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1413521,"h":1271311733137,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1413521,"h":1275606700433,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1413521,"h":1279901667729,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1413521,"h":1284196635025,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1413521,"h":1288491602321,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1413521,"h":1292786569617,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1413521,"h":1297081536913,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_AES_128_CCM","d":1413521,"h":1301376504209,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_AES_256_CCM","d":1413521,"h":1305671471505,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_AES_128_CCM","d":1413521,"h":1309966438801,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_AES_256_CCM","d":1413521,"h":1314261406097,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_AES_128_CCM_8","d":1413521,"h":1318556373393,"f":33},{"t":1413521,"n":"TLS_RSA_WITH_AES_256_CCM_8","d":1413521,"h":1322851340689,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_AES_128_CCM_8","d":1413521,"h":1327146307985,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_AES_256_CCM_8","d":1413521,"h":1331441275281,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_AES_128_CCM","d":1413521,"h":1335736242577,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_AES_256_CCM","d":1413521,"h":1340031209873,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_AES_128_CCM","d":1413521,"h":1344326177169,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_AES_256_CCM","d":1413521,"h":1348621144465,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_AES_128_CCM_8","d":1413521,"h":1352916111761,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_AES_256_CCM_8","d":1413521,"h":1357211079057,"f":33},{"t":1413521,"n":"TLS_PSK_DHE_WITH_AES_128_CCM_8","d":1413521,"h":1361506046353,"f":33},{"t":1413521,"n":"TLS_PSK_DHE_WITH_AES_256_CCM_8","d":1413521,"h":1365801013649,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CCM","d":1413521,"h":1370095980945,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CCM","d":1413521,"h":1374390948241,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8","d":1413521,"h":1378685915537,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8","d":1413521,"h":1382980882833,"f":33},{"t":1413521,"n":"TLS_ECCPWD_WITH_AES_128_GCM_SHA256","d":1413521,"h":1387275850129,"f":33},{"t":1413521,"n":"TLS_ECCPWD_WITH_AES_256_GCM_SHA384","d":1413521,"h":1391570817425,"f":33},{"t":1413521,"n":"TLS_ECCPWD_WITH_AES_128_CCM_SHA256","d":1413521,"h":1395865784721,"f":33},{"t":1413521,"n":"TLS_ECCPWD_WITH_AES_256_CCM_SHA384","d":1413521,"h":1400160752017,"f":33},{"t":1413521,"n":"TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256","d":1413521,"h":1404455719313,"f":33},{"t":1413521,"n":"TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256","d":1413521,"h":1408750686609,"f":33},{"t":1413521,"n":"TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256","d":1413521,"h":1413045653905,"f":33},{"t":1413521,"n":"TLS_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1413521,"h":1417340621201,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1413521,"h":1421635588497,"f":33},{"t":1413521,"n":"TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1413521,"h":1425930555793,"f":33},{"t":1413521,"n":"TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1413521,"h":1430225523089,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256","d":1413521,"h":1434520490385,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384","d":1413521,"h":1438815457681,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256","d":1413521,"h":1443110424977,"f":33},{"t":1413521,"n":"TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256","d":1413521,"h":1447405392273,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1413521,"h":1451700359569,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1413521,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.TlsCipherSuite`; }
        });
        
        $asm.$str("$snsc.System.Security.Authentication.ExtendedProtection.PolicyEnforcement", ($self) => class PolicyEnforcement extends $.$spc.System.Enum
        {
            static Never = 0;
            static WhenSupported = 1;
            static Always = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Never": 0n,
                    "WhenSupported": 1n,
                    "Always": 2n
                };
            }
            static $h = 1610129;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1610129,"n":"Never","d":1610129,"h":4296577425,"f":33},{"t":1610129,"n":"WhenSupported","d":1610129,"h":8591544721,"f":33},{"t":1610129,"n":"Always","d":1610129,"h":12886512017,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1610129,"h":17181479313,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1610129}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.PolicyEnforcement`; }
        });
        
        $asm.$str("$snsc.System.Security.Authentication.ExtendedProtection.ProtectionScenario", ($self) => class ProtectionScenario extends $.$spc.System.Enum
        {
            static TransportSelected = 0;
            static TrustedProxy = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TransportSelected": 0n,
                    "TrustedProxy": 1n
                };
            }
            static $h = 1675665;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1675665,"n":"TransportSelected","d":1675665,"h":4296642961,"f":33},{"t":1675665,"n":"TrustedProxy","d":1675665,"h":8591610257,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1675665,"h":12886577553,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1675665}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ProtectionScenario`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateStream", ($self) => class NegotiateStream extends $.$snsc.System.Net.Security.AuthenticatedStream
        {
            $ctor$4(/*System.IO.Stream*/ innerStream)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get RemoteIdentity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsClient()
            {
            }
            /*void */ AuthenticateAsClient$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName)
            {
            }
            /*void */ AuthenticateAsClient$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsClient$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName)
            {
            }
            /*void */ AuthenticateAsClient$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsServer()
            {
            }
            /*void */ AuthenticateAsServer$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsServer$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsServer$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient(/*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer(/*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndAuthenticateAsClient(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndAuthenticateAsServer(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 627089;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":102801,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180496273,"f":32769},"n":"CanRead","d":627089,"h":12885528977,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":25770430865,"f":32769},"n":"CanSeek","d":627089,"h":21475463569,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":34360365457,"f":32769},"n":"CanTimeout","d":627089,"h":30065398161,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42950300049,"f":32769},"n":"CanWrite","d":627089,"h":38655332753,"f":32769},{"p":117243905,"g":{"r":0,"d":0,"h":51540234641,"f":129},"n":"ImpersonationLevel","d":627089,"h":47245267345,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":60130169233,"f":32769},"n":"IsAuthenticated","d":627089,"h":55835201937,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":68720103825,"f":32769},"n":"IsEncrypted","d":627089,"h":64425136529,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":77310038417,"f":32769},"n":"IsMutuallyAuthenticated","d":627089,"h":73015071121,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":85899973009,"f":32769},"n":"IsServer","d":627089,"h":81605005713,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":94489907601,"f":32769},"n":"IsSigned","d":627089,"h":90194940305,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":103079842193,"f":32769},"n":"Length","d":627089,"h":98784874897,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":111669776785,"f":32769},"s":{"r":0,"d":0,"h":115964744081,"f":32769},"n":"Position","d":627089,"h":107374809489,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":124554678673,"f":32769},"s":{"r":0,"d":0,"h":128849645969,"f":32769},"n":"ReadTimeout","d":627089,"h":120259711377,"f":32769},{"p":117047297,"g":{"r":0,"d":0,"h":137439580561,"f":129},"n":"RemoteIdentity","d":627089,"h":133144613265,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":146029515153,"f":32769},"s":{"r":0,"d":0,"h":150324482449,"f":32769},"n":"WriteTimeout","d":627089,"h":141734547857,"f":32769}],"m":[{"r":65537,"n":"AuthenticateAsClient","d":627089,"h":154619449745,"f":129},{"r":65537,"p":[{"n":"credential","p":3863002},{"n":"binding","p":5435866},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClient","o":"@$1","d":627089,"h":158914417041,"f":129},{"r":65537,"p":[{"n":"credential","p":3863002},{"n":"binding","p":5435866},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":692625},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClient","o":"@$2","d":627089,"h":163209384337,"f":129},{"r":65537,"p":[{"n":"credential","p":3863002},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClient","o":"@$3","d":627089,"h":167504351633,"f":129},{"r":65537,"p":[{"n":"credential","p":3863002},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":692625},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClient","o":"@$4","d":627089,"h":171799318929,"f":129},{"r":133300225,"n":"AuthenticateAsClientAsync","d":627089,"h":176094286225,"f":129},{"r":133300225,"p":[{"n":"credential","p":3863002},{"n":"binding","p":5435866},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$1","d":627089,"h":180389253521,"f":129},{"r":133300225,"p":[{"n":"credential","p":3863002},{"n":"binding","p":5435866},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":692625},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClientAsync","o":"@$2","d":627089,"h":184684220817,"f":129},{"r":133300225,"p":[{"n":"credential","p":3863002},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$3","d":627089,"h":188979188113,"f":129},{"r":133300225,"p":[{"n":"credential","p":3863002},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":692625},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClientAsync","o":"@$4","d":627089,"h":193274155409,"f":129},{"r":65537,"n":"AuthenticateAsServer","d":627089,"h":197569122705,"f":129},{"r":65537,"p":[{"n":"credential","p":3863002},{"n":"requiredProtectionLevel","p":692625},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServer","o":"@$1","d":627089,"h":201864090001,"f":129},{"r":65537,"p":[{"n":"credential","p":3863002},{"n":"policy","p":1544593},{"n":"requiredProtectionLevel","p":692625},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServer","o":"@$2","d":627089,"h":206159057297,"f":129},{"r":65537,"p":[{"n":"policy","p":1544593}],"n":"AuthenticateAsServer","o":"@$3","d":627089,"h":210454024593,"f":129},{"r":133300225,"n":"AuthenticateAsServerAsync","d":627089,"h":214748991889,"f":129},{"r":133300225,"p":[{"n":"credential","p":3863002},{"n":"requiredProtectionLevel","p":692625},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServerAsync","o":"@$1","d":627089,"h":219043959185,"f":129},{"r":133300225,"p":[{"n":"credential","p":3863002},{"n":"policy","p":1544593},{"n":"requiredProtectionLevel","p":692625},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServerAsync","o":"@$2","d":627089,"h":223338926481,"f":129},{"r":133300225,"p":[{"n":"policy","p":1544593}],"n":"AuthenticateAsServerAsync","o":"@$3","d":627089,"h":227633893777,"f":129},{"r":56950785,"p":[{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","d":627089,"h":231928861073,"f":129},{"r":56950785,"p":[{"n":"credential","p":3863002},{"n":"binding","p":5435866},{"n":"targetName","p":1310721},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$1","d":627089,"h":236223828369,"f":129},{"r":56950785,"p":[{"n":"credential","p":3863002},{"n":"binding","p":5435866},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":692625},{"n":"allowedImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$2","d":627089,"h":240518795665,"f":129},{"r":56950785,"p":[{"n":"credential","p":3863002},{"n":"targetName","p":1310721},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$3","d":627089,"h":244813762961,"f":129},{"r":56950785,"p":[{"n":"credential","p":3863002},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":692625},{"n":"allowedImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$4","d":627089,"h":249108730257,"f":129},{"r":56950785,"p":[{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","d":627089,"h":253403697553,"f":129},{"r":56950785,"p":[{"n":"credential","p":3863002},{"n":"requiredProtectionLevel","p":692625},{"n":"requiredImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$1","d":627089,"h":257698664849,"f":129},{"r":56950785,"p":[{"n":"credential","p":3863002},{"n":"policy","p":1544593},{"n":"requiredProtectionLevel","p":692625},{"n":"requiredImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$2","d":627089,"h":261993632145,"f":129},{"r":56950785,"p":[{"n":"policy","p":1544593},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$3","d":627089,"h":266288599441,"f":129},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginRead","d":627089,"h":270583566737,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":627089,"h":274878534033,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":627089,"h":279173501329,"f":32772},{"r":136118273,"n":"DisposeAsync","d":627089,"h":283468468625,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAuthenticateAsClient","d":627089,"h":287763435921,"f":129},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAuthenticateAsServer","d":627089,"h":292058403217,"f":129},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":627089,"h":296353370513,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":627089,"h":300648337809,"f":32769},{"r":65537,"n":"Flush","d":627089,"h":304943305105,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":627089,"h":309238272401,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":627089,"h":313533239697,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":627089,"h":317828206993,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":627089,"h":322123174289,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":627089,"h":326418141585,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":627089,"h":330713108881,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":627089,"h":335008076177,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":627089,"h":339303043473,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":627089,"h":343598010769,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62128129}],"n":".ctor","o":"$ctor$4","d":627089,"h":4295594385,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":627089,"h":8590561681,"f":1}],"i":[57475073,56885249],"h":627089}; }
            static get $b() { return $.$snsc.System.Net.Security.AuthenticatedStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.NegotiateStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslStream", ($self) => class SslStream extends $.$snsc.System.Net.Security.AuthenticatedStream
        {
            $ctor$4(/*System.IO.Stream*/ innerStream)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$7(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback, /*System.Net.Security.LocalCertificateSelectionCallback?*/ userCertificateSelectionCallback)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$8(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback, /*System.Net.Security.LocalCertificateSelectionCallback?*/ userCertificateSelectionCallback, /*System.Net.Security.EncryptionPolicy*/ encryptionPolicy)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CheckCertRevocationStatus()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.CipherAlgorithmType */ get CipherAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get CipherStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.HashAlgorithmType */ get HashAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get HashStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExchangeAlgorithmType */ get KeyExchangeAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get KeyExchangeStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get LocalCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslApplicationProtocol */ get NegotiatedApplicationProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.TlsCipherSuite */ get NegotiatedCipherSuite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get RemoteCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get TargetHostName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.TransportContext */ get TransportContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsClient(/*System.Net.Security.SslClientAuthenticationOptions*/ sslClientAuthenticationOptions)
            {
            }
            /*void */ AuthenticateAsClient$1(/*string*/ targetHost)
            {
            }
            /*void */ AuthenticateAsClient$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation)
            {
            }
            /*void */ AuthenticateAsClient$3(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync(/*System.Net.Security.SslClientAuthenticationOptions*/ sslClientAuthenticationOptions, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$1(/*string*/ targetHost)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$3(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsServer(/*System.Net.Security.SslServerAuthenticationOptions*/ sslServerAuthenticationOptions)
            {
            }
            /*void */ AuthenticateAsServer$1(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate)
            {
            }
            /*void */ AuthenticateAsServer$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation)
            {
            }
            /*void */ AuthenticateAsServer$3(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync(/*System.Net.Security.ServerOptionsSelectionCallback*/ optionsCallback, /*object?*/ state, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$1(/*System.Net.Security.SslServerAuthenticationOptions*/ sslServerAuthenticationOptions, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$3(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$4(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient(/*string*/ targetHost, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$1(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$1(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndAuthenticateAsClient(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndAuthenticateAsServer(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ NegotiateClientCertificateAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*System.Threading.Tasks.Task */ ShutdownAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Write$2(/*byte[]*/ buffer)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 1282449;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":102801,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30066053521,"f":32769},"n":"CanRead","d":1282449,"h":25771086225,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38655988113,"f":32769},"n":"CanSeek","d":1282449,"h":34361020817,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":47245922705,"f":32769},"n":"CanTimeout","d":1282449,"h":42950955409,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":55835857297,"f":32769},"n":"CanWrite","d":1282449,"h":51540890001,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":64425791889,"f":129},"n":"CheckCertRevocationStatus","d":1282449,"h":60130824593,"f":129},{"p":5304794,"g":{"r":0,"d":0,"h":73015726481,"f":129},"n":"CipherAlgorithm","d":1282449,"h":68720759185,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":81605661073,"f":129},"n":"CipherStrength","d":1282449,"h":77310693777,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":5566938,"g":{"r":0,"d":0,"h":90195595665,"f":129},"n":"HashAlgorithm","d":1282449,"h":85900628369,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":98785530257,"f":129},"n":"HashStrength","d":1282449,"h":94490562961,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":107375464849,"f":32769},"n":"IsAuthenticated","d":1282449,"h":103080497553,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":115965399441,"f":32769},"n":"IsEncrypted","d":1282449,"h":111670432145,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":124555334033,"f":32769},"n":"IsMutuallyAuthenticated","d":1282449,"h":120260366737,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":133145268625,"f":32769},"n":"IsServer","d":1282449,"h":128850301329,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":141735203217,"f":32769},"n":"IsSigned","d":1282449,"h":137440235921,"f":32769},{"p":5370330,"g":{"r":0,"d":0,"h":150325137809,"f":129},"n":"KeyExchangeAlgorithm","d":1282449,"h":146030170513,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":158915072401,"f":129},"n":"KeyExchangeStrength","d":1282449,"h":154620105105,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":167505006993,"f":32769},"n":"Length","d":1282449,"h":163210039697,"f":32769},{"p":28159365,"g":{"r":0,"d":0,"h":176094941585,"f":129},"n":"LocalCertificate","d":1282449,"h":171799974289,"f":129},{"p":954769,"g":{"r":0,"d":0,"h":184684876177,"f":1},"n":"NegotiatedApplicationProtocol","d":1282449,"h":180389908881,"f":1},{"p":1413521,"g":{"r":0,"d":0,"h":193274810769,"f":129},"n":"NegotiatedCipherSuite","d":1282449,"h":188979843473,"f":129,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"p":917505,"g":{"r":0,"d":0,"h":201864745361,"f":32769},"s":{"r":0,"d":0,"h":206159712657,"f":32769},"n":"Position","d":1282449,"h":197569778065,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":214749647249,"f":32769},"s":{"r":0,"d":0,"h":219044614545,"f":32769},"n":"ReadTimeout","d":1282449,"h":210454679953,"f":32769},{"p":28159365,"g":{"r":0,"d":0,"h":227634549137,"f":129},"n":"RemoteCertificate","d":1282449,"h":223339581841,"f":129},{"p":5632474,"g":{"r":0,"d":0,"h":236224483729,"f":129},"n":"SslProtocol","d":1282449,"h":231929516433,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":244814418321,"f":1},"n":"TargetHostName","d":1282449,"h":240519451025,"f":1},{"p":5042650,"g":{"r":0,"d":0,"h":253404352913,"f":1},"n":"TransportContext","d":1282449,"h":249109385617,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":261994287505,"f":32769},"s":{"r":0,"d":0,"h":266289254801,"f":32769},"n":"WriteTimeout","d":1282449,"h":257699320209,"f":32769}],"m":[{"r":65537,"p":[{"n":"sslClientAuthenticationOptions","p":1085841}],"n":"AuthenticateAsClient","d":1282449,"h":270584222097,"f":1},{"r":65537,"p":[{"n":"targetHost","p":1310721}],"n":"AuthenticateAsClient","o":"@$1","d":1282449,"h":274879189393,"f":129},{"r":65537,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28421509},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClient","o":"@$2","d":1282449,"h":279174156689,"f":129},{"r":65537,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28421509},{"n":"enabledSslProtocols","p":5632474},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClient","o":"@$3","d":1282449,"h":283469123985,"f":129},{"r":133300225,"p":[{"n":"sslClientAuthenticationOptions","p":1085841},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsClientAsync","d":1282449,"h":287764091281,"f":1},{"r":133300225,"p":[{"n":"targetHost","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$1","d":1282449,"h":292059058577,"f":129},{"r":133300225,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28421509},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClientAsync","o":"@$2","d":1282449,"h":296354025873,"f":129},{"r":133300225,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28421509},{"n":"enabledSslProtocols","p":5632474},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClientAsync","o":"@$3","d":1282449,"h":300648993169,"f":129},{"r":65537,"p":[{"n":"sslServerAuthenticationOptions","p":1216913}],"n":"AuthenticateAsServer","d":1282449,"h":304943960465,"f":1},{"r":65537,"p":[{"n":"serverCertificate","p":28159365}],"n":"AuthenticateAsServer","o":"@$1","d":1282449,"h":309238927761,"f":129},{"r":65537,"p":[{"n":"serverCertificate","p":28159365},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServer","o":"@$2","d":1282449,"h":313533895057,"f":129},{"r":65537,"p":[{"n":"serverCertificate","p":28159365},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5632474},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServer","o":"@$3","d":1282449,"h":317828862353,"f":129},{"r":133300225,"p":[{"n":"optionsCallback","p":889233},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsServerAsync","d":1282449,"h":322123829649,"f":1},{"r":133300225,"p":[{"n":"sslServerAuthenticationOptions","p":1216913},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsServerAsync","o":"@$1","d":1282449,"h":326418796945,"f":1},{"r":133300225,"p":[{"n":"serverCertificate","p":28159365}],"n":"AuthenticateAsServerAsync","o":"@$2","d":1282449,"h":330713764241,"f":129},{"r":133300225,"p":[{"n":"serverCertificate","p":28159365},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServerAsync","o":"@$3","d":1282449,"h":335008731537,"f":129},{"r":133300225,"p":[{"n":"serverCertificate","p":28159365},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5632474},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServerAsync","o":"@$4","d":1282449,"h":339303698833,"f":129},{"r":56950785,"p":[{"n":"targetHost","p":1310721},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","d":1282449,"h":343598666129,"f":129},{"r":56950785,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28421509},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$1","d":1282449,"h":347893633425,"f":129},{"r":56950785,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28421509},{"n":"enabledSslProtocols","p":5632474},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$2","d":1282449,"h":352188600721,"f":129},{"r":56950785,"p":[{"n":"serverCertificate","p":28159365},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","d":1282449,"h":356483568017,"f":129},{"r":56950785,"p":[{"n":"serverCertificate","p":28159365},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$1","d":1282449,"h":360778535313,"f":129},{"r":56950785,"p":[{"n":"serverCertificate","p":28159365},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5632474},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$2","d":1282449,"h":365073502609,"f":129},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginRead","d":1282449,"h":369368469905,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":1282449,"h":373663437201,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1282449,"h":377958404497,"f":32772},{"r":136118273,"n":"DisposeAsync","d":1282449,"h":382253371793,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAuthenticateAsClient","d":1282449,"h":386548339089,"f":129},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAuthenticateAsServer","d":1282449,"h":390843306385,"f":129},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":1282449,"h":395138273681,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":1282449,"h":399433240977,"f":32769},{"r":65537,"n":"Flush","d":1282449,"h":408023175569,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1282449,"h":412318142865,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"NegotiateClientCertificateAsync","d":1282449,"h":416613110161,"f":129,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1282449,"h":420908077457,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1282449,"h":425203044753,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1282449,"h":429498012049,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1282449,"h":433792979345,"f":32769},{"r":655361,"n":"ReadByte","d":1282449,"h":438087946641,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1282449,"h":442382913937,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1282449,"h":446677881233,"f":32769},{"r":133300225,"n":"ShutdownAsync","d":1282449,"h":450972848529,"f":129},{"r":65537,"p":[{"n":"buffer","p":0}],"n":"Write","o":"@$2","d":1282449,"h":455267815825,"f":1},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1282449,"h":459562783121,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":1282449,"h":463857750417,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1282449,"h":468152717713,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1282449,"h":472447685009,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":1282449,"h":476742652305,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62128129}],"n":".ctor","o":"$ctor$4","d":1282449,"h":4296249745,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":1282449,"h":8591217041,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":758161}],"n":".ctor","o":"$ctor$6","d":1282449,"h":12886184337,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":758161},{"n":"userCertificateSelectionCallback","p":299409}],"n":".ctor","o":"$ctor$7","d":1282449,"h":17181151633,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":758161},{"n":"userCertificateSelectionCallback","p":299409},{"n":"encryptionPolicy","p":233873}],"n":".ctor","o":"$ctor$8","d":1282449,"h":21476118929,"f":1}],"i":[57475073,56885249],"h":1282449}; }
            static get $b() { return $.$snsc.System.Net.Security.AuthenticatedStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.SslStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.LocalCertificateSelectionCallback", ($self) => class LocalCertificateSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate?*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$spc.System.String*/ $targetHost, /*$.$sscr.System.Security.Cryptography.X509Certificates.X509CertificateCollection*/ $localCertificates, /*$.$spc.System.Nullable$$*/ $remoteCertificate, /**/ $acceptableIssuers)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 299409;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":28159365,"p":[{"n":"sender","p":131073},{"n":"targetHost","p":1310721},{"n":"localCertificates","p":28421509},{"n":"remoteCertificate","p":28159365},{"n":"acceptableIssuers","p":0}],"n":"Invoke","d":299409,"h":8590234001,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"targetHost","p":1310721},{"n":"localCertificates","p":28421509},{"n":"remoteCertificate","p":28159365},{"n":"acceptableIssuers","p":0},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":299409,"h":12885201297,"f":129},{"r":28159365,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":299409,"h":17180168593,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":299409,"h":4295266705,"f":1}],"i":[57147393,113377281],"h":299409}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.LocalCertificateSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.RemoteCertificateValidationCallback", ($self) => class RemoteCertificateValidationCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*bool*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$spc.System.Nullable$$*/ $certificate, /*$.$spc.System.Nullable$$*/ $chain, /*$.$snp.System.Net.Security.SslPolicyErrors*/ $sslPolicyErrors)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 758161;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":262145,"p":[{"n":"sender","p":131073},{"n":"certificate","p":28159365},{"n":"chain","p":28880261},{"n":"sslPolicyErrors","p":4321754}],"n":"Invoke","d":758161,"h":8590692753,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"certificate","p":28159365},{"n":"chain","p":28880261},{"n":"sslPolicyErrors","p":4321754},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":758161,"h":12885660049,"f":129},{"r":262145,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":758161,"h":17180627345,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":758161,"h":4295725457,"f":1}],"i":[57147393,113377281],"h":758161}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.RemoteCertificateValidationCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.ServerCertificateSelectionCallback", ($self) => class ServerCertificateSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$spc.System.Nullable$$*/ $hostName)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 823697;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":28159365,"p":[{"n":"sender","p":131073},{"n":"hostName","p":1310721}],"n":"Invoke","d":823697,"h":8590758289,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"hostName","p":1310721},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":823697,"h":12885725585,"f":129},{"r":28159365,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":823697,"h":17180692881,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":823697,"h":4295790993,"f":1}],"i":[57147393,113377281],"h":823697}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.ServerCertificateSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.ServerOptionsSelectionCallback", ($self) => class ServerOptionsSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Security.SslServerAuthenticationOptions>*/ Invoke(/*$.$snsc.System.Net.Security.SslStream*/ $stream, /*$.$snsc.System.Net.Security.SslClientHelloInfo*/ $clientHelloInfo, /*$.$spc.System.Nullable$$*/ $state, /*$.$spc.System.Threading.CancellationToken*/ $cancellationToken)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 889233;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snsc.System.Net.Security.SslServerAuthenticationOptions).$h,"p":[{"n":"stream","p":1282449},{"n":"clientHelloInfo","p":1151377},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193}],"n":"Invoke","d":889233,"h":8590823825,"f":129},{"r":56950785,"p":[{"n":"stream","p":1282449},{"n":"clientHelloInfo","p":1151377},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":889233,"h":12885791121,"f":129},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snsc.System.Net.Security.SslServerAuthenticationOptions).$h,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":889233,"h":17180758417,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":889233,"h":4295856529,"f":1}],"i":[57147393,113377281],"h":889233}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.ServerOptionsSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.AuthenticationException", ($self) => class AuthenticationException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$12(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            static $h = 1479057;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":1479057}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.AuthenticationException`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.InvalidCredentialException", ($self) => class InvalidCredentialException extends $.$snsc.System.Security.Authentication.AuthenticationException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$14(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$16(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            static $h = 1806737;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1479057,"h":1806737}; }
            static get $b() { return $.$snsc.System.Security.Authentication.AuthenticationException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.InvalidCredentialException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.Numerics", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Console", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Net.NameResolution", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography"))