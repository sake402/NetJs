
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $srn, $ssc, $sris, $scsl, $sfa, $sic, $sim, $sl, $snp, $sspw, $sci, $sdd, $srm, $snnr, $sds, $sns, $sscr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Security", 
    {"h":57445,"f":"System.Net.Security","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bbeaaf5d41a0179d1ed930cf3efa03ea73d37a2ca","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Security","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Security","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snsc.System.Net.Security.AuthenticatedStream", ($self) => class AuthenticatedStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.IO.Stream */ get InnerStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get LeaveInnerStreamOpen()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 122981;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":62128129,"g":{"r":0,"d":0,"h":12885024869,"f":4},"n":"InnerStream","d":122981,"h":8590057573,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":21474959461,"f":257},"n":"IsAuthenticated","d":122981,"h":17179992165,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":30064894053,"f":257},"n":"IsEncrypted","d":122981,"h":25769926757,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":38654828645,"f":257},"n":"IsMutuallyAuthenticated","d":122981,"h":34359861349,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":47244763237,"f":257},"n":"IsServer","d":122981,"h":42949795941,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":55834697829,"f":257},"n":"IsSigned","d":122981,"h":51539730533,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":64424632421,"f":1},"n":"LeaveInnerStreamOpen","d":122981,"h":60129665125,"f":1}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":122981,"h":68719599717,"f":32772},{"r":136118273,"n":"DisposeAsync","d":122981,"h":73014567013,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":122981,"h":4295090277,"f":4}],"i":[57475073,56885249],"h":122981}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.AuthenticatedStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.CipherSuitesPolicy", ($self) => class CipherSuitesPolicy extends $.$spc.System.Object
        {
            $ctor$1(/*System.Collections.Generic.IEnumerable<System.Net.Security.TlsCipherSuite>*/ allowedCipherSuites)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.Generic.IEnumerable<System.Net.Security.TlsCipherSuite> */ get AllowedCipherSuites()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 188517;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$snsc.System.Net.Security.TlsCipherSuite).$h,"g":{"r":0,"d":0,"h":12885090405,"f":1},"n":"AllowedCipherSuites","d":188517,"h":8590123109,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}],"c":[{"p":[{"n":"allowedCipherSuites","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$snsc.System.Net.Security.TlsCipherSuite).$h}],"n":".ctor","o":"$ctor$1","d":188517,"h":4295155813,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}],"h":188517,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"windows","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.CipherSuitesPolicy`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthenticationClientOptions", ($self) => class NegotiateAuthenticationClientOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get AllowedImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set AllowedImpersonationLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get Binding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ set Binding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ get Credential()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ set Credential(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Package(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get RequiredProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ set RequiredProtectionLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RequireMutualAuthentication()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RequireMutualAuthentication(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TargetName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 450661;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":117243905,"g":{"r":0,"d":0,"h":12885352549,"f":1},"s":{"r":0,"d":0,"h":17180319845,"f":1},"n":"AllowedImpersonationLevel","d":450661,"h":8590385253,"f":1},{"p":5412298,"g":{"r":0,"d":0,"h":25770254437,"f":1},"s":{"r":0,"d":0,"h":30065221733,"f":1},"n":"Binding","d":450661,"h":21475287141,"f":1},{"p":3839434,"g":{"r":0,"d":0,"h":38655156325,"f":1},"s":{"r":0,"d":0,"h":42950123621,"f":1},"n":"Credential","d":450661,"h":34360189029,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540058213,"f":1},"s":{"r":0,"d":0,"h":55835025509,"f":1},"n":"Package","d":450661,"h":47245090917,"f":1},{"p":712805,"g":{"r":0,"d":0,"h":64424960101,"f":1},"s":{"r":0,"d":0,"h":68719927397,"f":1},"n":"RequiredProtectionLevel","d":450661,"h":60129992805,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77309861989,"f":1},"s":{"r":0,"d":0,"h":81604829285,"f":1},"n":"RequireMutualAuthentication","d":450661,"h":73014894693,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90194763877,"f":1},"s":{"r":0,"d":0,"h":94489731173,"f":1},"n":"TargetName","d":450661,"h":85899796581,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":450661,"h":4295417957,"f":1}],"h":450661}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationClientOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthenticationServerOptions", ($self) => class NegotiateAuthenticationServerOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get Binding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ set Binding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ get Credential()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ set Credential(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Package(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy? */ get Policy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy? */ set Policy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get RequiredImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set RequiredImpersonationLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get RequiredProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ set RequiredProtectionLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 516197;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5412298,"g":{"r":0,"d":0,"h":12885418085,"f":1},"s":{"r":0,"d":0,"h":17180385381,"f":1},"n":"Binding","d":516197,"h":8590450789,"f":1},{"p":3839434,"g":{"r":0,"d":0,"h":25770319973,"f":1},"s":{"r":0,"d":0,"h":30065287269,"f":1},"n":"Credential","d":516197,"h":21475352677,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38655221861,"f":1},"s":{"r":0,"d":0,"h":42950189157,"f":1},"n":"Package","d":516197,"h":34360254565,"f":1},{"p":1564773,"g":{"r":0,"d":0,"h":51540123749,"f":1},"s":{"r":0,"d":0,"h":55835091045,"f":1},"n":"Policy","d":516197,"h":47245156453,"f":1},{"p":117243905,"g":{"r":0,"d":0,"h":64425025637,"f":1},"s":{"r":0,"d":0,"h":68719992933,"f":1},"n":"RequiredImpersonationLevel","d":516197,"h":60130058341,"f":1},{"p":712805,"g":{"r":0,"d":0,"h":77309927525,"f":1},"s":{"r":0,"d":0,"h":81604894821,"f":1},"n":"RequiredProtectionLevel","d":516197,"h":73014960229,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":516197,"h":4295483493,"f":1}],"h":516197}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationServerOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslCertificateTrust", ($self) => class SslCertificateTrust extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*System.Net.Security.SslCertificateTrust */ CreateForX509Collection(/*System.Security.Cryptography.X509Certificates.X509Certificate2Collection*/ trustList, /*bool*/ sendTrustInHandshake)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslCertificateTrust */ CreateForX509Store(/*System.Security.Cryptography.X509Certificates.X509Store*/ store, /*bool*/ sendTrustInHandshake)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1040485;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1040485,"p":[{"n":"trustList","p":28305598},{"n":"sendTrustInHandshake","p":262145,"f":65,"v":false}],"n":"CreateForX509Collection","d":1040485,"h":8590975077,"f":33},{"r":1040485,"p":[{"n":"store","p":30468286},{"n":"sendTrustInHandshake","p":262145,"f":65,"v":false}],"n":"CreateForX509Store","d":1040485,"h":12885942373,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1040485,"h":4296007781,"f":8}],"h":1040485}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslCertificateTrust`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslClientAuthenticationOptions", ($self) => class SslClientAuthenticationOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AllowRenegotiation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRenegotiation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPkcs1Padding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPkcs1Padding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPssPadding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPssPadding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowTlsResume()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowTlsResume(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ get ApplicationProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ set ApplicationProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ get CertificateChainPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ set CertificateChainPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ get CertificateRevocationCheckMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ set CertificateRevocationCheckMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ get CipherSuitesPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ set CipherSuitesPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ get ClientCertificateContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ set ClientCertificateContext(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection? */ get ClientCertificates()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection? */ set ClientCertificates(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get EnabledSslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ set EnabledSslProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ set EncryptionPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.LocalCertificateSelectionCallback? */ get LocalCertificateSelectionCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.LocalCertificateSelectionCallback? */ set LocalCertificateSelectionCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get RemoteCertificateValidationCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set RemoteCertificateValidationCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetHost()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TargetHost(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1106021;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886007909,"f":1},"s":{"r":0,"d":0,"h":17180975205,"f":1},"n":"AllowRenegotiation","d":1106021,"h":8591040613,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770909797,"f":1},"s":{"r":0,"d":0,"h":30065877093,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPkcs1Padding","d":1106021,"h":21475942501,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655811685,"f":1},"s":{"r":0,"d":0,"h":42950778981,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPssPadding","d":1106021,"h":34360844389,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540713573,"f":1},"s":{"r":0,"d":0,"h":55835680869,"f":1},"n":"AllowTlsResume","d":1106021,"h":47245746277,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":64425615461,"f":1},"s":{"r":0,"d":0,"h":68720582757,"f":1},"n":"ApplicationProtocols","d":1106021,"h":60130648165,"f":1},{"p":29157566,"g":{"r":0,"d":0,"h":77310517349,"f":1},"s":{"r":0,"d":0,"h":81605484645,"f":1},"n":"CertificateChainPolicy","d":1106021,"h":73015550053,"f":1},{"p":30271678,"g":{"r":0,"d":0,"h":90195419237,"f":1},"s":{"r":0,"d":0,"h":94490386533,"f":1},"n":"CertificateRevocationCheckMode","d":1106021,"h":85900451941,"f":1},{"p":188517,"g":{"r":0,"d":0,"h":103080321125,"f":1},"s":{"r":0,"d":0,"h":107375288421,"f":1},"n":"CipherSuitesPolicy","d":1106021,"h":98785353829,"f":1},{"p":1368165,"g":{"r":0,"d":0,"h":115965223013,"f":1},"s":{"r":0,"d":0,"h":120260190309,"f":1},"n":"ClientCertificateContext","d":1106021,"h":111670255717,"f":1},{"p":28436670,"g":{"r":0,"d":0,"h":128850124901,"f":1},"s":{"r":0,"d":0,"h":133145092197,"f":1},"n":"ClientCertificates","d":1106021,"h":124555157605,"f":1},{"p":5608906,"g":{"r":0,"d":0,"h":141735026789,"f":1},"s":{"r":0,"d":0,"h":146029994085,"f":1},"n":"EnabledSslProtocols","d":1106021,"h":137440059493,"f":1},{"p":254053,"g":{"r":0,"d":0,"h":154619928677,"f":1},"s":{"r":0,"d":0,"h":158914895973,"f":1},"n":"EncryptionPolicy","d":1106021,"h":150324961381,"f":1},{"p":319589,"g":{"r":0,"d":0,"h":167504830565,"f":1},"s":{"r":0,"d":0,"h":171799797861,"f":1},"n":"LocalCertificateSelectionCallback","d":1106021,"h":163209863269,"f":1},{"p":778341,"g":{"r":0,"d":0,"h":180389732453,"f":1},"s":{"r":0,"d":0,"h":184684699749,"f":1},"n":"RemoteCertificateValidationCallback","d":1106021,"h":176094765157,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":193274634341,"f":1},"s":{"r":0,"d":0,"h":197569601637,"f":1},"n":"TargetHost","d":1106021,"h":188979667045,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1106021,"h":4296073317,"f":1}],"h":1106021}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslClientAuthenticationOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslServerAuthenticationOptions", ($self) => class SslServerAuthenticationOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AllowRenegotiation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRenegotiation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPkcs1Padding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPkcs1Padding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPssPadding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPssPadding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowTlsResume()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowTlsResume(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ get ApplicationProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ set ApplicationProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ get CertificateChainPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ set CertificateChainPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ get CertificateRevocationCheckMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ set CertificateRevocationCheckMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ get CipherSuitesPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ set CipherSuitesPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ClientCertificateRequired()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ClientCertificateRequired(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get EnabledSslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ set EnabledSslProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ set EncryptionPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get RemoteCertificateValidationCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set RemoteCertificateValidationCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get ServerCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ set ServerCertificate(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ get ServerCertificateContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ set ServerCertificateContext(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ServerCertificateSelectionCallback? */ get ServerCertificateSelectionCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ServerCertificateSelectionCallback? */ set ServerCertificateSelectionCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1237093;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886138981,"f":1},"s":{"r":0,"d":0,"h":17181106277,"f":1},"n":"AllowRenegotiation","d":1237093,"h":8591171685,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25771040869,"f":1},"s":{"r":0,"d":0,"h":30066008165,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPkcs1Padding","d":1237093,"h":21476073573,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655942757,"f":1},"s":{"r":0,"d":0,"h":42950910053,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPssPadding","d":1237093,"h":34360975461,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540844645,"f":1},"s":{"r":0,"d":0,"h":55835811941,"f":1},"n":"AllowTlsResume","d":1237093,"h":47245877349,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":64425746533,"f":1},"s":{"r":0,"d":0,"h":68720713829,"f":1},"n":"ApplicationProtocols","d":1237093,"h":60130779237,"f":1},{"p":29157566,"g":{"r":0,"d":0,"h":77310648421,"f":1},"s":{"r":0,"d":0,"h":81605615717,"f":1},"n":"CertificateChainPolicy","d":1237093,"h":73015681125,"f":1},{"p":30271678,"g":{"r":0,"d":0,"h":90195550309,"f":1},"s":{"r":0,"d":0,"h":94490517605,"f":1},"n":"CertificateRevocationCheckMode","d":1237093,"h":85900583013,"f":1},{"p":188517,"g":{"r":0,"d":0,"h":103080452197,"f":1},"s":{"r":0,"d":0,"h":107375419493,"f":1},"n":"CipherSuitesPolicy","d":1237093,"h":98785484901,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115965354085,"f":1},"s":{"r":0,"d":0,"h":120260321381,"f":1},"n":"ClientCertificateRequired","d":1237093,"h":111670386789,"f":1},{"p":5608906,"g":{"r":0,"d":0,"h":128850255973,"f":1},"s":{"r":0,"d":0,"h":133145223269,"f":1},"n":"EnabledSslProtocols","d":1237093,"h":124555288677,"f":1},{"p":254053,"g":{"r":0,"d":0,"h":141735157861,"f":1},"s":{"r":0,"d":0,"h":146030125157,"f":1},"n":"EncryptionPolicy","d":1237093,"h":137440190565,"f":1},{"p":778341,"g":{"r":0,"d":0,"h":154620059749,"f":1},"s":{"r":0,"d":0,"h":158915027045,"f":1},"n":"RemoteCertificateValidationCallback","d":1237093,"h":150325092453,"f":1},{"p":28174526,"g":{"r":0,"d":0,"h":167504961637,"f":1},"s":{"r":0,"d":0,"h":171799928933,"f":1},"n":"ServerCertificate","d":1237093,"h":163209994341,"f":1},{"p":1368165,"g":{"r":0,"d":0,"h":180389863525,"f":1},"s":{"r":0,"d":0,"h":184684830821,"f":1},"n":"ServerCertificateContext","d":1237093,"h":176094896229,"f":1},{"p":843877,"g":{"r":0,"d":0,"h":193274765413,"f":1},"s":{"r":0,"d":0,"h":197569732709,"f":1},"n":"ServerCertificateSelectionCallback","d":1237093,"h":188979798117,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1237093,"h":4296204389,"f":1}],"h":1237093}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslServerAuthenticationOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslStreamCertificateContext", ($self) => class SslStreamCertificateContext extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.ObjectModel.ReadOnlyCollection<System.Security.Cryptography.X509Certificates.X509Certificate2> */ get IntermediateCertificates()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate2 */ get TargetCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslStreamCertificateContext */ Create(/*System.Security.Cryptography.X509Certificates.X509Certificate2*/ target, /*System.Security.Cryptography.X509Certificates.X509Certificate2Collection?*/ additionalCertificates, /*bool*/ offline)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslStreamCertificateContext */ Create$1(/*System.Security.Cryptography.X509Certificates.X509Certificate2*/ target, /*System.Security.Cryptography.X509Certificates.X509Certificate2Collection?*/ additionalCertificates, /*bool*/ offline, /*System.Net.Security.SslCertificateTrust?*/ trust)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1368165;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sscr.System.Security.Cryptography.X509Certificates.X509Certificate2).$h,"g":{"r":0,"d":0,"h":12886270053,"f":1},"n":"IntermediateCertificates","d":1368165,"h":8591302757,"f":1},{"p":28240062,"g":{"r":0,"d":0,"h":21476204645,"f":1},"n":"TargetCertificate","d":1368165,"h":17181237349,"f":1}],"m":[{"r":1368165,"p":[{"n":"target","p":28240062},{"n":"additionalCertificates","p":28305598},{"n":"offline","p":262145}],"n":"Create","d":1368165,"h":25771171941,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":1368165,"p":[{"n":"target","p":28240062},{"n":"additionalCertificates","p":28305598},{"n":"offline","p":262145,"f":65,"v":false},{"n":"trust","p":1040485,"f":65}],"n":"Create","o":"@$1","d":1368165,"h":30066139237,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1368165,"h":4296335461,"f":8}],"h":1368165}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslStreamCertificateContext`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthentication", ($self) => class NegotiateAuthentication extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.Security.NegotiateAuthenticationClientOptions*/ clientOptions)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.Security.NegotiateAuthenticationServerOptions*/ serverOptions)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get ProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get RemoteIdentity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ ComputeIntegrityCheck(/*System.ReadOnlySpan<byte>*/ message, /*System.Buffers.IBufferWriter<byte>*/ signatureWriter)
            {
            }
            /*void */ Dispose()
            {
            }
            /*byte[]? */ GetOutgoingBlob(/*System.ReadOnlySpan<byte>*/ incomingBlob, /*out System.Net.Security.NegotiateAuthenticationStatusCode*/ statusCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ GetOutgoingBlob$1(/*string?*/ incomingBlob, /*out System.Net.Security.NegotiateAuthenticationStatusCode*/ statusCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ Unwrap(/*System.ReadOnlySpan<byte>*/ input, /*System.Buffers.IBufferWriter<byte>*/ outputWriter, /*out bool*/ wasEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ UnwrapInPlace(/*System.Span<byte>*/ input, /*out int*/ unwrappedOffset, /*out int*/ unwrappedLength, /*out bool*/ wasEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ VerifyIntegrityCheck(/*System.ReadOnlySpan<byte>*/ message, /*System.ReadOnlySpan<byte>*/ signature)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ Wrap(/*System.ReadOnlySpan<byte>*/ input, /*System.Buffers.IBufferWriter<byte>*/ outputWriter, /*bool*/ requestEncryption, /*out bool*/ isEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 385125;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":117243905,"g":{"r":0,"d":0,"h":17180254309,"f":1},"n":"ImpersonationLevel","d":385125,"h":12885287013,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770188901,"f":1},"n":"IsAuthenticated","d":385125,"h":21475221605,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360123493,"f":1},"n":"IsEncrypted","d":385125,"h":30065156197,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950058085,"f":1},"n":"IsMutuallyAuthenticated","d":385125,"h":38655090789,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51539992677,"f":1},"n":"IsServer","d":385125,"h":47245025381,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60129927269,"f":1},"n":"IsSigned","d":385125,"h":55834959973,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":68719861861,"f":1},"n":"Package","d":385125,"h":64424894565,"f":1},{"p":712805,"g":{"r":0,"d":0,"h":77309796453,"f":1},"n":"ProtectionLevel","d":385125,"h":73014829157,"f":1},{"p":117047297,"g":{"r":0,"d":0,"h":85899731045,"f":1},"n":"RemoteIdentity","d":385125,"h":81604763749,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":94489665637,"f":1},"n":"TargetName","d":385125,"h":90194698341,"f":1}],"m":[{"r":65537,"p":[{"n":"message","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"signatureWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h}],"n":"ComputeIntegrityCheck","d":385125,"h":98784632933,"f":1},{"r":65537,"n":"Dispose","d":385125,"h":103079600229,"f":1},{"r":0,"p":[{"n":"incomingBlob","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"statusCode","p":581733,"f":2}],"n":"GetOutgoingBlob","d":385125,"h":107374567525,"f":1},{"r":1310721,"p":[{"n":"incomingBlob","p":1310721},{"n":"statusCode","p":581733,"f":2}],"n":"GetOutgoingBlob","o":"@$1","d":385125,"h":111669534821,"f":1},{"r":581733,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"outputWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h},{"n":"wasEncrypted","p":262145,"f":2}],"n":"Unwrap","d":385125,"h":115964502117,"f":1},{"r":581733,"p":[{"n":"input","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"unwrappedOffset","p":655361,"f":2},{"n":"unwrappedLength","p":655361,"f":2},{"n":"wasEncrypted","p":262145,"f":2}],"n":"UnwrapInPlace","d":385125,"h":120259469413,"f":1},{"r":262145,"p":[{"n":"message","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"signature","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"VerifyIntegrityCheck","d":385125,"h":124554436709,"f":1},{"r":581733,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"outputWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h},{"n":"requestEncryption","p":262145},{"n":"isEncrypted","p":262145,"f":2}],"n":"Wrap","d":385125,"h":128849404005,"f":1}],"c":[{"p":[{"n":"clientOptions","p":450661}],"n":".ctor","o":"$ctor$1","d":385125,"h":4295352421,"f":1},{"p":[{"n":"serverOptions","p":516197}],"n":".ctor","o":"$ctor$2","d":385125,"h":8590319717,"f":1}],"i":[57475073],"h":385125}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthentication`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy", ($self) => class ExtendedProtectionPolicy extends $.$spc.System.Object
        {
            $ctor$1(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ChannelBinding*/ customChannelBinding)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ProtectionScenario*/ protectionScenario, /*System.Collections.ICollection?*/ customServiceNames)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ProtectionScenario*/ protectionScenario, /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection?*/ customServiceNames)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get CustomChannelBinding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection? */ get CustomServiceNames()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsExtendedProtection()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.PolicyEnforcement */ get PolicyEnforcement()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ProtectionScenario */ get ProtectionScenario()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo?*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snsc.System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy.ToString.apply(this, arguments); }
            static $h = 1564773;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5412298,"g":{"r":0,"d":0,"h":30066335845,"f":1},"n":"CustomChannelBinding","d":1564773,"h":25771368549,"f":1},{"p":1761381,"g":{"r":0,"d":0,"h":38656270437,"f":1},"n":"CustomServiceNames","d":1564773,"h":34361303141,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47246205029,"f":33},"n":"OSSupportsExtendedProtection","d":1564773,"h":42951237733,"f":33},{"p":1630309,"g":{"r":0,"d":0,"h":55836139621,"f":1},"n":"PolicyEnforcement","d":1564773,"h":51541172325,"f":1},{"p":1695845,"g":{"r":0,"d":0,"h":64426074213,"f":1},"n":"ProtectionScenario","d":1564773,"h":60131106917,"f":1}],"m":[{"r":1310721,"n":"ToString","d":1564773,"h":73016008805,"f":32769}],"c":[{"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$1","d":1564773,"h":4296532069,"f":4,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":[{"n":"policyEnforcement","p":1630309}],"n":".ctor","o":"$ctor$2","d":1564773,"h":8591499365,"f":1},{"p":[{"n":"policyEnforcement","p":1630309},{"n":"customChannelBinding","p":5412298}],"n":".ctor","o":"$ctor$3","d":1564773,"h":12886466661,"f":1},{"p":[{"n":"policyEnforcement","p":1630309},{"n":"protectionScenario","p":1695845},{"n":"customServiceNames","p":31326209}],"n":".ctor","o":"$ctor$4","d":1564773,"h":17181433957,"f":1},{"p":[{"n":"policyEnforcement","p":1630309},{"n":"protectionScenario","p":1695845},{"n":"customServiceNames","p":1761381}],"n":".ctor","o":"$ctor$5","d":1564773,"h":21476401253,"f":1}],"i":[113377281],"h":1564773}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.SslClientHelloInfo", ($self) => class SslClientHelloInfo extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            $ctor$2(/*string*/ serverName, /*System.Security.Authentication.SslProtocols*/ sslProtocols)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*string */ get ServerName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 1171557;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21476008037,"f":1},"n":"ServerName","d":1171557,"h":17181040741,"f":1},{"p":5608906,"g":{"r":0,"d":0,"h":30065942629,"f":1},"n":"SslProtocols","d":1171557,"h":25770975333,"f":1}],"l":[{"t":131073,"n":"_dummy","d":1171557,"h":4296138853,"f":2},{"t":655361,"n":"_dummyPrimitive","d":1171557,"h":8591106149,"f":2}],"c":[{"p":[{"n":"serverName","p":1310721},{"n":"sslProtocols","p":5608906}],"n":".ctor","o":"$ctor$2","d":1171557,"h":12886073445,"f":1},{"n":".ctor","o":"$ctor$3","d":1171557,"h":34360909925,"f":1}],"h":1171557}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Security.SslClientHelloInfo`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.SslApplicationProtocol", ($self) => class SslApplicationProtocol extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.Security.SslApplicationProtocol*/ static Http11;
            /*System.Net.Security.SslApplicationProtocol*/ static Http2;
            /*System.Net.Security.SslApplicationProtocol*/ static Http3;
            $ctor$2(/*byte[]*/ protocol)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            $ctor$3(/*string*/ protocol)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*System.ReadOnlyMemory<byte> */ get Protocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Security.SslApplicationProtocol*/ other)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snsc.System.Net.Security.SslApplicationProtocol.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snsc.System.Net.Security.SslApplicationProtocol.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Security.SslApplicationProtocol*/ left, /*System.Net.Security.SslApplicationProtocol*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Security.SslApplicationProtocol*/ left, /*System.Net.Security.SslApplicationProtocol*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snsc.System.Net.Security.SslApplicationProtocol.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Net.Security.SslApplicationProtocol>.Equals(System.Net.Security.SslApplicationProtocol)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Http11 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
                {
                    this.Http2 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
                {
                    this.Http3 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
            }
            static $h = 974949;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":38655680613,"f":1},"n":"Protocol","d":974949,"h":34360713317,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":974949}],"n":"Equals","o":"@$2","d":974949,"h":42950647909,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":974949,"h":47245615205,"f":32769},{"r":655361,"n":"GetHashCode","d":974949,"h":51540582501,"f":32769},{"r":1310721,"n":"ToString","d":974949,"h":64425484389,"f":32769}],"l":[{"t":131073,"n":"_dummy","d":974949,"h":4295942245,"f":2},{"t":655361,"n":"_dummyPrimitive","d":974949,"h":8590909541,"f":2},{"t":974949,"n":"Http11","d":974949,"h":12885876837,"f":33},{"t":974949,"n":"Http2","d":974949,"h":17180844133,"f":33},{"t":974949,"n":"Http3","d":974949,"h":21475811429,"f":33}],"c":[{"p":[{"n":"protocol","p":0}],"n":".ctor","o":"$ctor$2","d":974949,"h":25770778725,"f":1},{"p":[{"n":"protocol","p":1310721}],"n":".ctor","o":"$ctor$3","d":974949,"h":30065746021,"f":1},{"n":".ctor","o":"$ctor$4","d":974949,"h":68720451685,"f":1}],"i":[$.$spc.System.IEquatable$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h],"h":974949}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$snsc.System.Net.Security.SslApplicationProtocol) ]; }
            static get $fullName() { return `System.Net.Security.SslApplicationProtocol`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.ExtendedProtection.ServiceNameCollection", ($self) => class ServiceNameCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2(/*System.Collections.ICollection*/ items)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ Contains(/*string?*/ searchServiceName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection */ Merge(/*System.Collections.IEnumerable*/ serviceNames)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection */ Merge$1(/*string*/ serviceName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1761381;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"m":[{"r":262145,"p":[{"n":"searchServiceName","p":1310721}],"n":"Contains","d":1761381,"h":8591695973,"f":1},{"r":1761381,"p":[{"n":"serviceNames","p":31588353}],"n":"Merge","d":1761381,"h":12886663269,"f":1},{"r":1761381,"p":[{"n":"serviceName","p":1310721}],"n":"Merge","o":"@$1","d":1761381,"h":17181630565,"f":1}],"c":[{"p":[{"n":"items","p":31326209}],"n":".ctor","o":"$ctor$2","d":1761381,"h":4296728677,"f":1}],"i":[31326209,31588353],"h":1761381}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ServiceNameCollection`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.EncryptionPolicy", ($self) => class EncryptionPolicy extends $.$spc.System.Enum
        {
            static RequireEncryption = 0;
            static AllowNoEncryption = 1;
            static NoEncryption = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "RequireEncryption": 0n,
                    "AllowNoEncryption": 1n,
                    "NoEncryption": 2n
                };
            }
            static $h = 254053;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":254053,"n":"RequireEncryption","d":254053,"h":4295221349,"f":33},{"t":254053,"n":"AllowNoEncryption","d":254053,"h":8590188645,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0040","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"t":254053,"n":"NoEncryption","d":254053,"h":12885155941,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0040","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":254053,"h":17180123237,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":254053}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.EncryptionPolicy`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.NegotiateAuthenticationStatusCode", ($self) => class NegotiateAuthenticationStatusCode extends $.$spc.System.Enum
        {
            static Completed = 0;
            static ContinueNeeded = 1;
            static GenericFailure = 2;
            static BadBinding = 3;
            static Unsupported = 4;
            static MessageAltered = 5;
            static ContextExpired = 6;
            static CredentialsExpired = 7;
            static InvalidCredentials = 8;
            static InvalidToken = 9;
            static UnknownCredentials = 10;
            static QopNotSupported = 11;
            static OutOfSequence = 12;
            static SecurityQosFailed = 13;
            static TargetUnknown = 14;
            static ImpersonationValidationFailed = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Completed": 0n,
                    "ContinueNeeded": 1n,
                    "GenericFailure": 2n,
                    "BadBinding": 3n,
                    "Unsupported": 4n,
                    "MessageAltered": 5n,
                    "ContextExpired": 6n,
                    "CredentialsExpired": 7n,
                    "InvalidCredentials": 8n,
                    "InvalidToken": 9n,
                    "UnknownCredentials": 10n,
                    "QopNotSupported": 11n,
                    "OutOfSequence": 12n,
                    "SecurityQosFailed": 13n,
                    "TargetUnknown": 14n,
                    "ImpersonationValidationFailed": 15n
                };
            }
            static $h = 581733;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":581733,"n":"Completed","d":581733,"h":4295549029,"f":33},{"t":581733,"n":"ContinueNeeded","d":581733,"h":8590516325,"f":33},{"t":581733,"n":"GenericFailure","d":581733,"h":12885483621,"f":33},{"t":581733,"n":"BadBinding","d":581733,"h":17180450917,"f":33},{"t":581733,"n":"Unsupported","d":581733,"h":21475418213,"f":33},{"t":581733,"n":"MessageAltered","d":581733,"h":25770385509,"f":33},{"t":581733,"n":"ContextExpired","d":581733,"h":30065352805,"f":33},{"t":581733,"n":"CredentialsExpired","d":581733,"h":34360320101,"f":33},{"t":581733,"n":"InvalidCredentials","d":581733,"h":38655287397,"f":33},{"t":581733,"n":"InvalidToken","d":581733,"h":42950254693,"f":33},{"t":581733,"n":"UnknownCredentials","d":581733,"h":47245221989,"f":33},{"t":581733,"n":"QopNotSupported","d":581733,"h":51540189285,"f":33},{"t":581733,"n":"OutOfSequence","d":581733,"h":55835156581,"f":33},{"t":581733,"n":"SecurityQosFailed","d":581733,"h":60130123877,"f":33},{"t":581733,"n":"TargetUnknown","d":581733,"h":64425091173,"f":33},{"t":581733,"n":"ImpersonationValidationFailed","d":581733,"h":68720058469,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":581733,"h":73015025765,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":581733}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationStatusCode`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.ProtectionLevel", ($self) => class ProtectionLevel extends $.$spc.System.Enum
        {
            static None = 0;
            static Sign = 1;
            static EncryptAndSign = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Sign": 1n,
                    "EncryptAndSign": 2n
                };
            }
            static $h = 712805;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":712805,"n":"None","d":712805,"h":4295680101,"f":33},{"t":712805,"n":"Sign","d":712805,"h":8590647397,"f":33},{"t":712805,"n":"EncryptAndSign","d":712805,"h":12885614693,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":712805,"h":17180581989,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":712805}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.ProtectionLevel`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.TlsCipherSuite", ($self) => class TlsCipherSuite extends $.$spc.System.Enum
        {
            static TLS_NULL_WITH_NULL_NULL = 0;
            static TLS_RSA_WITH_NULL_MD5 = 1;
            static TLS_RSA_WITH_NULL_SHA = 2;
            static TLS_RSA_EXPORT_WITH_RC4_40_MD5 = 3;
            static TLS_RSA_WITH_RC4_128_MD5 = 4;
            static TLS_RSA_WITH_RC4_128_SHA = 5;
            static TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5 = 6;
            static TLS_RSA_WITH_IDEA_CBC_SHA = 7;
            static TLS_RSA_EXPORT_WITH_DES40_CBC_SHA = 8;
            static TLS_RSA_WITH_DES_CBC_SHA = 9;
            static TLS_RSA_WITH_3DES_EDE_CBC_SHA = 10;
            static TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA = 11;
            static TLS_DH_DSS_WITH_DES_CBC_SHA = 12;
            static TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA = 13;
            static TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA = 14;
            static TLS_DH_RSA_WITH_DES_CBC_SHA = 15;
            static TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA = 16;
            static TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA = 17;
            static TLS_DHE_DSS_WITH_DES_CBC_SHA = 18;
            static TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA = 19;
            static TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA = 20;
            static TLS_DHE_RSA_WITH_DES_CBC_SHA = 21;
            static TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA = 22;
            static TLS_DH_anon_EXPORT_WITH_RC4_40_MD5 = 23;
            static TLS_DH_anon_WITH_RC4_128_MD5 = 24;
            static TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA = 25;
            static TLS_DH_anon_WITH_DES_CBC_SHA = 26;
            static TLS_DH_anon_WITH_3DES_EDE_CBC_SHA = 27;
            static TLS_KRB5_WITH_DES_CBC_SHA = 30;
            static TLS_KRB5_WITH_3DES_EDE_CBC_SHA = 31;
            static TLS_KRB5_WITH_RC4_128_SHA = 32;
            static TLS_KRB5_WITH_IDEA_CBC_SHA = 33;
            static TLS_KRB5_WITH_DES_CBC_MD5 = 34;
            static TLS_KRB5_WITH_3DES_EDE_CBC_MD5 = 35;
            static TLS_KRB5_WITH_RC4_128_MD5 = 36;
            static TLS_KRB5_WITH_IDEA_CBC_MD5 = 37;
            static TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA = 38;
            static TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA = 39;
            static TLS_KRB5_EXPORT_WITH_RC4_40_SHA = 40;
            static TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5 = 41;
            static TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5 = 42;
            static TLS_KRB5_EXPORT_WITH_RC4_40_MD5 = 43;
            static TLS_PSK_WITH_NULL_SHA = 44;
            static TLS_DHE_PSK_WITH_NULL_SHA = 45;
            static TLS_RSA_PSK_WITH_NULL_SHA = 46;
            static TLS_RSA_WITH_AES_128_CBC_SHA = 47;
            static TLS_DH_DSS_WITH_AES_128_CBC_SHA = 48;
            static TLS_DH_RSA_WITH_AES_128_CBC_SHA = 49;
            static TLS_DHE_DSS_WITH_AES_128_CBC_SHA = 50;
            static TLS_DHE_RSA_WITH_AES_128_CBC_SHA = 51;
            static TLS_DH_anon_WITH_AES_128_CBC_SHA = 52;
            static TLS_RSA_WITH_AES_256_CBC_SHA = 53;
            static TLS_DH_DSS_WITH_AES_256_CBC_SHA = 54;
            static TLS_DH_RSA_WITH_AES_256_CBC_SHA = 55;
            static TLS_DHE_DSS_WITH_AES_256_CBC_SHA = 56;
            static TLS_DHE_RSA_WITH_AES_256_CBC_SHA = 57;
            static TLS_DH_anon_WITH_AES_256_CBC_SHA = 58;
            static TLS_RSA_WITH_NULL_SHA256 = 59;
            static TLS_RSA_WITH_AES_128_CBC_SHA256 = 60;
            static TLS_RSA_WITH_AES_256_CBC_SHA256 = 61;
            static TLS_DH_DSS_WITH_AES_128_CBC_SHA256 = 62;
            static TLS_DH_RSA_WITH_AES_128_CBC_SHA256 = 63;
            static TLS_DHE_DSS_WITH_AES_128_CBC_SHA256 = 64;
            static TLS_RSA_WITH_CAMELLIA_128_CBC_SHA = 65;
            static TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA = 66;
            static TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA = 67;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA = 68;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA = 69;
            static TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA = 70;
            static TLS_DHE_RSA_WITH_AES_128_CBC_SHA256 = 103;
            static TLS_DH_DSS_WITH_AES_256_CBC_SHA256 = 104;
            static TLS_DH_RSA_WITH_AES_256_CBC_SHA256 = 105;
            static TLS_DHE_DSS_WITH_AES_256_CBC_SHA256 = 106;
            static TLS_DHE_RSA_WITH_AES_256_CBC_SHA256 = 107;
            static TLS_DH_anon_WITH_AES_128_CBC_SHA256 = 108;
            static TLS_DH_anon_WITH_AES_256_CBC_SHA256 = 109;
            static TLS_RSA_WITH_CAMELLIA_256_CBC_SHA = 132;
            static TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA = 133;
            static TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA = 134;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA = 135;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA = 136;
            static TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA = 137;
            static TLS_PSK_WITH_RC4_128_SHA = 138;
            static TLS_PSK_WITH_3DES_EDE_CBC_SHA = 139;
            static TLS_PSK_WITH_AES_128_CBC_SHA = 140;
            static TLS_PSK_WITH_AES_256_CBC_SHA = 141;
            static TLS_DHE_PSK_WITH_RC4_128_SHA = 142;
            static TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA = 143;
            static TLS_DHE_PSK_WITH_AES_128_CBC_SHA = 144;
            static TLS_DHE_PSK_WITH_AES_256_CBC_SHA = 145;
            static TLS_RSA_PSK_WITH_RC4_128_SHA = 146;
            static TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA = 147;
            static TLS_RSA_PSK_WITH_AES_128_CBC_SHA = 148;
            static TLS_RSA_PSK_WITH_AES_256_CBC_SHA = 149;
            static TLS_RSA_WITH_SEED_CBC_SHA = 150;
            static TLS_DH_DSS_WITH_SEED_CBC_SHA = 151;
            static TLS_DH_RSA_WITH_SEED_CBC_SHA = 152;
            static TLS_DHE_DSS_WITH_SEED_CBC_SHA = 153;
            static TLS_DHE_RSA_WITH_SEED_CBC_SHA = 154;
            static TLS_DH_anon_WITH_SEED_CBC_SHA = 155;
            static TLS_RSA_WITH_AES_128_GCM_SHA256 = 156;
            static TLS_RSA_WITH_AES_256_GCM_SHA384 = 157;
            static TLS_DHE_RSA_WITH_AES_128_GCM_SHA256 = 158;
            static TLS_DHE_RSA_WITH_AES_256_GCM_SHA384 = 159;
            static TLS_DH_RSA_WITH_AES_128_GCM_SHA256 = 160;
            static TLS_DH_RSA_WITH_AES_256_GCM_SHA384 = 161;
            static TLS_DHE_DSS_WITH_AES_128_GCM_SHA256 = 162;
            static TLS_DHE_DSS_WITH_AES_256_GCM_SHA384 = 163;
            static TLS_DH_DSS_WITH_AES_128_GCM_SHA256 = 164;
            static TLS_DH_DSS_WITH_AES_256_GCM_SHA384 = 165;
            static TLS_DH_anon_WITH_AES_128_GCM_SHA256 = 166;
            static TLS_DH_anon_WITH_AES_256_GCM_SHA384 = 167;
            static TLS_PSK_WITH_AES_128_GCM_SHA256 = 168;
            static TLS_PSK_WITH_AES_256_GCM_SHA384 = 169;
            static TLS_DHE_PSK_WITH_AES_128_GCM_SHA256 = 170;
            static TLS_DHE_PSK_WITH_AES_256_GCM_SHA384 = 171;
            static TLS_RSA_PSK_WITH_AES_128_GCM_SHA256 = 172;
            static TLS_RSA_PSK_WITH_AES_256_GCM_SHA384 = 173;
            static TLS_PSK_WITH_AES_128_CBC_SHA256 = 174;
            static TLS_PSK_WITH_AES_256_CBC_SHA384 = 175;
            static TLS_PSK_WITH_NULL_SHA256 = 176;
            static TLS_PSK_WITH_NULL_SHA384 = 177;
            static TLS_DHE_PSK_WITH_AES_128_CBC_SHA256 = 178;
            static TLS_DHE_PSK_WITH_AES_256_CBC_SHA384 = 179;
            static TLS_DHE_PSK_WITH_NULL_SHA256 = 180;
            static TLS_DHE_PSK_WITH_NULL_SHA384 = 181;
            static TLS_RSA_PSK_WITH_AES_128_CBC_SHA256 = 182;
            static TLS_RSA_PSK_WITH_AES_256_CBC_SHA384 = 183;
            static TLS_RSA_PSK_WITH_NULL_SHA256 = 184;
            static TLS_RSA_PSK_WITH_NULL_SHA384 = 185;
            static TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 186;
            static TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256 = 187;
            static TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 188;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256 = 189;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 190;
            static TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256 = 191;
            static TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 192;
            static TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256 = 193;
            static TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 194;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256 = 195;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 196;
            static TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256 = 197;
            static TLS_AES_128_GCM_SHA256 = 4865;
            static TLS_AES_256_GCM_SHA384 = 4866;
            static TLS_CHACHA20_POLY1305_SHA256 = 4867;
            static TLS_AES_128_CCM_SHA256 = 4868;
            static TLS_AES_128_CCM_8_SHA256 = 4869;
            static TLS_ECDH_ECDSA_WITH_NULL_SHA = 49153;
            static TLS_ECDH_ECDSA_WITH_RC4_128_SHA = 49154;
            static TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA = 49155;
            static TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA = 49156;
            static TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA = 49157;
            static TLS_ECDHE_ECDSA_WITH_NULL_SHA = 49158;
            static TLS_ECDHE_ECDSA_WITH_RC4_128_SHA = 49159;
            static TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA = 49160;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA = 49161;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA = 49162;
            static TLS_ECDH_RSA_WITH_NULL_SHA = 49163;
            static TLS_ECDH_RSA_WITH_RC4_128_SHA = 49164;
            static TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA = 49165;
            static TLS_ECDH_RSA_WITH_AES_128_CBC_SHA = 49166;
            static TLS_ECDH_RSA_WITH_AES_256_CBC_SHA = 49167;
            static TLS_ECDHE_RSA_WITH_NULL_SHA = 49168;
            static TLS_ECDHE_RSA_WITH_RC4_128_SHA = 49169;
            static TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA = 49170;
            static TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA = 49171;
            static TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA = 49172;
            static TLS_ECDH_anon_WITH_NULL_SHA = 49173;
            static TLS_ECDH_anon_WITH_RC4_128_SHA = 49174;
            static TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA = 49175;
            static TLS_ECDH_anon_WITH_AES_128_CBC_SHA = 49176;
            static TLS_ECDH_anon_WITH_AES_256_CBC_SHA = 49177;
            static TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA = 49178;
            static TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA = 49179;
            static TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA = 49180;
            static TLS_SRP_SHA_WITH_AES_128_CBC_SHA = 49181;
            static TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA = 49182;
            static TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA = 49183;
            static TLS_SRP_SHA_WITH_AES_256_CBC_SHA = 49184;
            static TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA = 49185;
            static TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA = 49186;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256 = 49187;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384 = 49188;
            static TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256 = 49189;
            static TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384 = 49190;
            static TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256 = 49191;
            static TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384 = 49192;
            static TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256 = 49193;
            static TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384 = 49194;
            static TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256 = 49195;
            static TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384 = 49196;
            static TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256 = 49197;
            static TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384 = 49198;
            static TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 = 49199;
            static TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 = 49200;
            static TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256 = 49201;
            static TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384 = 49202;
            static TLS_ECDHE_PSK_WITH_RC4_128_SHA = 49203;
            static TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA = 49204;
            static TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA = 49205;
            static TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA = 49206;
            static TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256 = 49207;
            static TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384 = 49208;
            static TLS_ECDHE_PSK_WITH_NULL_SHA = 49209;
            static TLS_ECDHE_PSK_WITH_NULL_SHA256 = 49210;
            static TLS_ECDHE_PSK_WITH_NULL_SHA384 = 49211;
            static TLS_RSA_WITH_ARIA_128_CBC_SHA256 = 49212;
            static TLS_RSA_WITH_ARIA_256_CBC_SHA384 = 49213;
            static TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256 = 49214;
            static TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384 = 49215;
            static TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256 = 49216;
            static TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384 = 49217;
            static TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256 = 49218;
            static TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384 = 49219;
            static TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256 = 49220;
            static TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384 = 49221;
            static TLS_DH_anon_WITH_ARIA_128_CBC_SHA256 = 49222;
            static TLS_DH_anon_WITH_ARIA_256_CBC_SHA384 = 49223;
            static TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256 = 49224;
            static TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384 = 49225;
            static TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256 = 49226;
            static TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384 = 49227;
            static TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256 = 49228;
            static TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384 = 49229;
            static TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256 = 49230;
            static TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384 = 49231;
            static TLS_RSA_WITH_ARIA_128_GCM_SHA256 = 49232;
            static TLS_RSA_WITH_ARIA_256_GCM_SHA384 = 49233;
            static TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256 = 49234;
            static TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384 = 49235;
            static TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256 = 49236;
            static TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384 = 49237;
            static TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256 = 49238;
            static TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384 = 49239;
            static TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256 = 49240;
            static TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384 = 49241;
            static TLS_DH_anon_WITH_ARIA_128_GCM_SHA256 = 49242;
            static TLS_DH_anon_WITH_ARIA_256_GCM_SHA384 = 49243;
            static TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256 = 49244;
            static TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384 = 49245;
            static TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256 = 49246;
            static TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384 = 49247;
            static TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256 = 49248;
            static TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384 = 49249;
            static TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256 = 49250;
            static TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384 = 49251;
            static TLS_PSK_WITH_ARIA_128_CBC_SHA256 = 49252;
            static TLS_PSK_WITH_ARIA_256_CBC_SHA384 = 49253;
            static TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256 = 49254;
            static TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384 = 49255;
            static TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256 = 49256;
            static TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384 = 49257;
            static TLS_PSK_WITH_ARIA_128_GCM_SHA256 = 49258;
            static TLS_PSK_WITH_ARIA_256_GCM_SHA384 = 49259;
            static TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256 = 49260;
            static TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384 = 49261;
            static TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256 = 49262;
            static TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384 = 49263;
            static TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256 = 49264;
            static TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384 = 49265;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 = 49266;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 = 49267;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 = 49268;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 = 49269;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 49270;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384 = 49271;
            static TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 49272;
            static TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384 = 49273;
            static TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49274;
            static TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49275;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49276;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49277;
            static TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49278;
            static TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49279;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256 = 49280;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384 = 49281;
            static TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256 = 49282;
            static TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384 = 49283;
            static TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256 = 49284;
            static TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384 = 49285;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 = 49286;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 = 49287;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 = 49288;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 = 49289;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49290;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49291;
            static TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49292;
            static TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49293;
            static TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49294;
            static TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49295;
            static TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49296;
            static TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49297;
            static TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49298;
            static TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49299;
            static TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49300;
            static TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49301;
            static TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49302;
            static TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49303;
            static TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49304;
            static TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49305;
            static TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49306;
            static TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49307;
            static TLS_RSA_WITH_AES_128_CCM = 49308;
            static TLS_RSA_WITH_AES_256_CCM = 49309;
            static TLS_DHE_RSA_WITH_AES_128_CCM = 49310;
            static TLS_DHE_RSA_WITH_AES_256_CCM = 49311;
            static TLS_RSA_WITH_AES_128_CCM_8 = 49312;
            static TLS_RSA_WITH_AES_256_CCM_8 = 49313;
            static TLS_DHE_RSA_WITH_AES_128_CCM_8 = 49314;
            static TLS_DHE_RSA_WITH_AES_256_CCM_8 = 49315;
            static TLS_PSK_WITH_AES_128_CCM = 49316;
            static TLS_PSK_WITH_AES_256_CCM = 49317;
            static TLS_DHE_PSK_WITH_AES_128_CCM = 49318;
            static TLS_DHE_PSK_WITH_AES_256_CCM = 49319;
            static TLS_PSK_WITH_AES_128_CCM_8 = 49320;
            static TLS_PSK_WITH_AES_256_CCM_8 = 49321;
            static TLS_PSK_DHE_WITH_AES_128_CCM_8 = 49322;
            static TLS_PSK_DHE_WITH_AES_256_CCM_8 = 49323;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CCM = 49324;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CCM = 49325;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8 = 49326;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8 = 49327;
            static TLS_ECCPWD_WITH_AES_128_GCM_SHA256 = 49328;
            static TLS_ECCPWD_WITH_AES_256_GCM_SHA384 = 49329;
            static TLS_ECCPWD_WITH_AES_128_CCM_SHA256 = 49330;
            static TLS_ECCPWD_WITH_AES_256_CCM_SHA384 = 49331;
            static TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256 = 52392;
            static TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256 = 52393;
            static TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256 = 52394;
            static TLS_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52395;
            static TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52396;
            static TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52397;
            static TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52398;
            static TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256 = 53249;
            static TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384 = 53250;
            static TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256 = 53251;
            static TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256 = 53253;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TLS_NULL_WITH_NULL_NULL": 0n,
                    "TLS_RSA_WITH_NULL_MD5": 1n,
                    "TLS_RSA_WITH_NULL_SHA": 2n,
                    "TLS_RSA_EXPORT_WITH_RC4_40_MD5": 3n,
                    "TLS_RSA_WITH_RC4_128_MD5": 4n,
                    "TLS_RSA_WITH_RC4_128_SHA": 5n,
                    "TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5": 6n,
                    "TLS_RSA_WITH_IDEA_CBC_SHA": 7n,
                    "TLS_RSA_EXPORT_WITH_DES40_CBC_SHA": 8n,
                    "TLS_RSA_WITH_DES_CBC_SHA": 9n,
                    "TLS_RSA_WITH_3DES_EDE_CBC_SHA": 10n,
                    "TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA": 11n,
                    "TLS_DH_DSS_WITH_DES_CBC_SHA": 12n,
                    "TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA": 13n,
                    "TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA": 14n,
                    "TLS_DH_RSA_WITH_DES_CBC_SHA": 15n,
                    "TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA": 16n,
                    "TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA": 17n,
                    "TLS_DHE_DSS_WITH_DES_CBC_SHA": 18n,
                    "TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA": 19n,
                    "TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA": 20n,
                    "TLS_DHE_RSA_WITH_DES_CBC_SHA": 21n,
                    "TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA": 22n,
                    "TLS_DH_anon_EXPORT_WITH_RC4_40_MD5": 23n,
                    "TLS_DH_anon_WITH_RC4_128_MD5": 24n,
                    "TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA": 25n,
                    "TLS_DH_anon_WITH_DES_CBC_SHA": 26n,
                    "TLS_DH_anon_WITH_3DES_EDE_CBC_SHA": 27n,
                    "TLS_KRB5_WITH_DES_CBC_SHA": 30n,
                    "TLS_KRB5_WITH_3DES_EDE_CBC_SHA": 31n,
                    "TLS_KRB5_WITH_RC4_128_SHA": 32n,
                    "TLS_KRB5_WITH_IDEA_CBC_SHA": 33n,
                    "TLS_KRB5_WITH_DES_CBC_MD5": 34n,
                    "TLS_KRB5_WITH_3DES_EDE_CBC_MD5": 35n,
                    "TLS_KRB5_WITH_RC4_128_MD5": 36n,
                    "TLS_KRB5_WITH_IDEA_CBC_MD5": 37n,
                    "TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA": 38n,
                    "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA": 39n,
                    "TLS_KRB5_EXPORT_WITH_RC4_40_SHA": 40n,
                    "TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5": 41n,
                    "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5": 42n,
                    "TLS_KRB5_EXPORT_WITH_RC4_40_MD5": 43n,
                    "TLS_PSK_WITH_NULL_SHA": 44n,
                    "TLS_DHE_PSK_WITH_NULL_SHA": 45n,
                    "TLS_RSA_PSK_WITH_NULL_SHA": 46n,
                    "TLS_RSA_WITH_AES_128_CBC_SHA": 47n,
                    "TLS_DH_DSS_WITH_AES_128_CBC_SHA": 48n,
                    "TLS_DH_RSA_WITH_AES_128_CBC_SHA": 49n,
                    "TLS_DHE_DSS_WITH_AES_128_CBC_SHA": 50n,
                    "TLS_DHE_RSA_WITH_AES_128_CBC_SHA": 51n,
                    "TLS_DH_anon_WITH_AES_128_CBC_SHA": 52n,
                    "TLS_RSA_WITH_AES_256_CBC_SHA": 53n,
                    "TLS_DH_DSS_WITH_AES_256_CBC_SHA": 54n,
                    "TLS_DH_RSA_WITH_AES_256_CBC_SHA": 55n,
                    "TLS_DHE_DSS_WITH_AES_256_CBC_SHA": 56n,
                    "TLS_DHE_RSA_WITH_AES_256_CBC_SHA": 57n,
                    "TLS_DH_anon_WITH_AES_256_CBC_SHA": 58n,
                    "TLS_RSA_WITH_NULL_SHA256": 59n,
                    "TLS_RSA_WITH_AES_128_CBC_SHA256": 60n,
                    "TLS_RSA_WITH_AES_256_CBC_SHA256": 61n,
                    "TLS_DH_DSS_WITH_AES_128_CBC_SHA256": 62n,
                    "TLS_DH_RSA_WITH_AES_128_CBC_SHA256": 63n,
                    "TLS_DHE_DSS_WITH_AES_128_CBC_SHA256": 64n,
                    "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA": 65n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA": 66n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA": 67n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA": 68n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA": 69n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA": 70n,
                    "TLS_DHE_RSA_WITH_AES_128_CBC_SHA256": 103n,
                    "TLS_DH_DSS_WITH_AES_256_CBC_SHA256": 104n,
                    "TLS_DH_RSA_WITH_AES_256_CBC_SHA256": 105n,
                    "TLS_DHE_DSS_WITH_AES_256_CBC_SHA256": 106n,
                    "TLS_DHE_RSA_WITH_AES_256_CBC_SHA256": 107n,
                    "TLS_DH_anon_WITH_AES_128_CBC_SHA256": 108n,
                    "TLS_DH_anon_WITH_AES_256_CBC_SHA256": 109n,
                    "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA": 132n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA": 133n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA": 134n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA": 135n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA": 136n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA": 137n,
                    "TLS_PSK_WITH_RC4_128_SHA": 138n,
                    "TLS_PSK_WITH_3DES_EDE_CBC_SHA": 139n,
                    "TLS_PSK_WITH_AES_128_CBC_SHA": 140n,
                    "TLS_PSK_WITH_AES_256_CBC_SHA": 141n,
                    "TLS_DHE_PSK_WITH_RC4_128_SHA": 142n,
                    "TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA": 143n,
                    "TLS_DHE_PSK_WITH_AES_128_CBC_SHA": 144n,
                    "TLS_DHE_PSK_WITH_AES_256_CBC_SHA": 145n,
                    "TLS_RSA_PSK_WITH_RC4_128_SHA": 146n,
                    "TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA": 147n,
                    "TLS_RSA_PSK_WITH_AES_128_CBC_SHA": 148n,
                    "TLS_RSA_PSK_WITH_AES_256_CBC_SHA": 149n,
                    "TLS_RSA_WITH_SEED_CBC_SHA": 150n,
                    "TLS_DH_DSS_WITH_SEED_CBC_SHA": 151n,
                    "TLS_DH_RSA_WITH_SEED_CBC_SHA": 152n,
                    "TLS_DHE_DSS_WITH_SEED_CBC_SHA": 153n,
                    "TLS_DHE_RSA_WITH_SEED_CBC_SHA": 154n,
                    "TLS_DH_anon_WITH_SEED_CBC_SHA": 155n,
                    "TLS_RSA_WITH_AES_128_GCM_SHA256": 156n,
                    "TLS_RSA_WITH_AES_256_GCM_SHA384": 157n,
                    "TLS_DHE_RSA_WITH_AES_128_GCM_SHA256": 158n,
                    "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384": 159n,
                    "TLS_DH_RSA_WITH_AES_128_GCM_SHA256": 160n,
                    "TLS_DH_RSA_WITH_AES_256_GCM_SHA384": 161n,
                    "TLS_DHE_DSS_WITH_AES_128_GCM_SHA256": 162n,
                    "TLS_DHE_DSS_WITH_AES_256_GCM_SHA384": 163n,
                    "TLS_DH_DSS_WITH_AES_128_GCM_SHA256": 164n,
                    "TLS_DH_DSS_WITH_AES_256_GCM_SHA384": 165n,
                    "TLS_DH_anon_WITH_AES_128_GCM_SHA256": 166n,
                    "TLS_DH_anon_WITH_AES_256_GCM_SHA384": 167n,
                    "TLS_PSK_WITH_AES_128_GCM_SHA256": 168n,
                    "TLS_PSK_WITH_AES_256_GCM_SHA384": 169n,
                    "TLS_DHE_PSK_WITH_AES_128_GCM_SHA256": 170n,
                    "TLS_DHE_PSK_WITH_AES_256_GCM_SHA384": 171n,
                    "TLS_RSA_PSK_WITH_AES_128_GCM_SHA256": 172n,
                    "TLS_RSA_PSK_WITH_AES_256_GCM_SHA384": 173n,
                    "TLS_PSK_WITH_AES_128_CBC_SHA256": 174n,
                    "TLS_PSK_WITH_AES_256_CBC_SHA384": 175n,
                    "TLS_PSK_WITH_NULL_SHA256": 176n,
                    "TLS_PSK_WITH_NULL_SHA384": 177n,
                    "TLS_DHE_PSK_WITH_AES_128_CBC_SHA256": 178n,
                    "TLS_DHE_PSK_WITH_AES_256_CBC_SHA384": 179n,
                    "TLS_DHE_PSK_WITH_NULL_SHA256": 180n,
                    "TLS_DHE_PSK_WITH_NULL_SHA384": 181n,
                    "TLS_RSA_PSK_WITH_AES_128_CBC_SHA256": 182n,
                    "TLS_RSA_PSK_WITH_AES_256_CBC_SHA384": 183n,
                    "TLS_RSA_PSK_WITH_NULL_SHA256": 184n,
                    "TLS_RSA_PSK_WITH_NULL_SHA384": 185n,
                    "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256": 186n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256": 187n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256": 188n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256": 189n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256": 190n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256": 191n,
                    "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256": 192n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256": 193n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256": 194n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256": 195n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256": 196n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256": 197n,
                    "TLS_AES_128_GCM_SHA256": 4865n,
                    "TLS_AES_256_GCM_SHA384": 4866n,
                    "TLS_CHACHA20_POLY1305_SHA256": 4867n,
                    "TLS_AES_128_CCM_SHA256": 4868n,
                    "TLS_AES_128_CCM_8_SHA256": 4869n,
                    "TLS_ECDH_ECDSA_WITH_NULL_SHA": 49153n,
                    "TLS_ECDH_ECDSA_WITH_RC4_128_SHA": 49154n,
                    "TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA": 49155n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA": 49156n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA": 49157n,
                    "TLS_ECDHE_ECDSA_WITH_NULL_SHA": 49158n,
                    "TLS_ECDHE_ECDSA_WITH_RC4_128_SHA": 49159n,
                    "TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA": 49160n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA": 49161n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA": 49162n,
                    "TLS_ECDH_RSA_WITH_NULL_SHA": 49163n,
                    "TLS_ECDH_RSA_WITH_RC4_128_SHA": 49164n,
                    "TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA": 49165n,
                    "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA": 49166n,
                    "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA": 49167n,
                    "TLS_ECDHE_RSA_WITH_NULL_SHA": 49168n,
                    "TLS_ECDHE_RSA_WITH_RC4_128_SHA": 49169n,
                    "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA": 49170n,
                    "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA": 49171n,
                    "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA": 49172n,
                    "TLS_ECDH_anon_WITH_NULL_SHA": 49173n,
                    "TLS_ECDH_anon_WITH_RC4_128_SHA": 49174n,
                    "TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA": 49175n,
                    "TLS_ECDH_anon_WITH_AES_128_CBC_SHA": 49176n,
                    "TLS_ECDH_anon_WITH_AES_256_CBC_SHA": 49177n,
                    "TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA": 49178n,
                    "TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA": 49179n,
                    "TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA": 49180n,
                    "TLS_SRP_SHA_WITH_AES_128_CBC_SHA": 49181n,
                    "TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA": 49182n,
                    "TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA": 49183n,
                    "TLS_SRP_SHA_WITH_AES_256_CBC_SHA": 49184n,
                    "TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA": 49185n,
                    "TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA": 49186n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256": 49187n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384": 49188n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256": 49189n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384": 49190n,
                    "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256": 49191n,
                    "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384": 49192n,
                    "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256": 49193n,
                    "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384": 49194n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256": 49195n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384": 49196n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256": 49197n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384": 49198n,
                    "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256": 49199n,
                    "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384": 49200n,
                    "TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256": 49201n,
                    "TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384": 49202n,
                    "TLS_ECDHE_PSK_WITH_RC4_128_SHA": 49203n,
                    "TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA": 49204n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA": 49205n,
                    "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA": 49206n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256": 49207n,
                    "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384": 49208n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA": 49209n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA256": 49210n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA384": 49211n,
                    "TLS_RSA_WITH_ARIA_128_CBC_SHA256": 49212n,
                    "TLS_RSA_WITH_ARIA_256_CBC_SHA384": 49213n,
                    "TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256": 49214n,
                    "TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384": 49215n,
                    "TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256": 49216n,
                    "TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384": 49217n,
                    "TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256": 49218n,
                    "TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384": 49219n,
                    "TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256": 49220n,
                    "TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384": 49221n,
                    "TLS_DH_anon_WITH_ARIA_128_CBC_SHA256": 49222n,
                    "TLS_DH_anon_WITH_ARIA_256_CBC_SHA384": 49223n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256": 49224n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384": 49225n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256": 49226n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384": 49227n,
                    "TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256": 49228n,
                    "TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384": 49229n,
                    "TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256": 49230n,
                    "TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384": 49231n,
                    "TLS_RSA_WITH_ARIA_128_GCM_SHA256": 49232n,
                    "TLS_RSA_WITH_ARIA_256_GCM_SHA384": 49233n,
                    "TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256": 49234n,
                    "TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384": 49235n,
                    "TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256": 49236n,
                    "TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384": 49237n,
                    "TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256": 49238n,
                    "TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384": 49239n,
                    "TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256": 49240n,
                    "TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384": 49241n,
                    "TLS_DH_anon_WITH_ARIA_128_GCM_SHA256": 49242n,
                    "TLS_DH_anon_WITH_ARIA_256_GCM_SHA384": 49243n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256": 49244n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384": 49245n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256": 49246n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384": 49247n,
                    "TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256": 49248n,
                    "TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384": 49249n,
                    "TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256": 49250n,
                    "TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384": 49251n,
                    "TLS_PSK_WITH_ARIA_128_CBC_SHA256": 49252n,
                    "TLS_PSK_WITH_ARIA_256_CBC_SHA384": 49253n,
                    "TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256": 49254n,
                    "TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384": 49255n,
                    "TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256": 49256n,
                    "TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384": 49257n,
                    "TLS_PSK_WITH_ARIA_128_GCM_SHA256": 49258n,
                    "TLS_PSK_WITH_ARIA_256_GCM_SHA384": 49259n,
                    "TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256": 49260n,
                    "TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384": 49261n,
                    "TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256": 49262n,
                    "TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384": 49263n,
                    "TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256": 49264n,
                    "TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384": 49265n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256": 49266n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384": 49267n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256": 49268n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384": 49269n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256": 49270n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384": 49271n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256": 49272n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384": 49273n,
                    "TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49274n,
                    "TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49275n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49276n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49277n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49278n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49279n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256": 49280n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384": 49281n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256": 49282n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384": 49283n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256": 49284n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384": 49285n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256": 49286n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384": 49287n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256": 49288n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384": 49289n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49290n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49291n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49292n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49293n,
                    "TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49294n,
                    "TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49295n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49296n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49297n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49298n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49299n,
                    "TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49300n,
                    "TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49301n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49302n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49303n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49304n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49305n,
                    "TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49306n,
                    "TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49307n,
                    "TLS_RSA_WITH_AES_128_CCM": 49308n,
                    "TLS_RSA_WITH_AES_256_CCM": 49309n,
                    "TLS_DHE_RSA_WITH_AES_128_CCM": 49310n,
                    "TLS_DHE_RSA_WITH_AES_256_CCM": 49311n,
                    "TLS_RSA_WITH_AES_128_CCM_8": 49312n,
                    "TLS_RSA_WITH_AES_256_CCM_8": 49313n,
                    "TLS_DHE_RSA_WITH_AES_128_CCM_8": 49314n,
                    "TLS_DHE_RSA_WITH_AES_256_CCM_8": 49315n,
                    "TLS_PSK_WITH_AES_128_CCM": 49316n,
                    "TLS_PSK_WITH_AES_256_CCM": 49317n,
                    "TLS_DHE_PSK_WITH_AES_128_CCM": 49318n,
                    "TLS_DHE_PSK_WITH_AES_256_CCM": 49319n,
                    "TLS_PSK_WITH_AES_128_CCM_8": 49320n,
                    "TLS_PSK_WITH_AES_256_CCM_8": 49321n,
                    "TLS_PSK_DHE_WITH_AES_128_CCM_8": 49322n,
                    "TLS_PSK_DHE_WITH_AES_256_CCM_8": 49323n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CCM": 49324n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CCM": 49325n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8": 49326n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8": 49327n,
                    "TLS_ECCPWD_WITH_AES_128_GCM_SHA256": 49328n,
                    "TLS_ECCPWD_WITH_AES_256_GCM_SHA384": 49329n,
                    "TLS_ECCPWD_WITH_AES_128_CCM_SHA256": 49330n,
                    "TLS_ECCPWD_WITH_AES_256_CCM_SHA384": 49331n,
                    "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256": 52392n,
                    "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256": 52393n,
                    "TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256": 52394n,
                    "TLS_PSK_WITH_CHACHA20_POLY1305_SHA256": 52395n,
                    "TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256": 52396n,
                    "TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256": 52397n,
                    "TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256": 52398n,
                    "TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256": 53249n,
                    "TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384": 53250n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256": 53251n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256": 53253n
                };
            }
            static $h = 1433701;
            static $z = 2;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.UInt16; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":589825,"l":[{"t":1433701,"n":"TLS_NULL_WITH_NULL_NULL","d":1433701,"h":4296400997,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_NULL_MD5","d":1433701,"h":8591368293,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_NULL_SHA","d":1433701,"h":12886335589,"f":33},{"t":1433701,"n":"TLS_RSA_EXPORT_WITH_RC4_40_MD5","d":1433701,"h":17181302885,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_RC4_128_MD5","d":1433701,"h":21476270181,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_RC4_128_SHA","d":1433701,"h":25771237477,"f":33},{"t":1433701,"n":"TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5","d":1433701,"h":30066204773,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_IDEA_CBC_SHA","d":1433701,"h":34361172069,"f":33},{"t":1433701,"n":"TLS_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1433701,"h":38656139365,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_DES_CBC_SHA","d":1433701,"h":42951106661,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":47246073957,"f":33},{"t":1433701,"n":"TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA","d":1433701,"h":51541041253,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_DES_CBC_SHA","d":1433701,"h":55836008549,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":60130975845,"f":33},{"t":1433701,"n":"TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1433701,"h":64425943141,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_DES_CBC_SHA","d":1433701,"h":68720910437,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":73015877733,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA","d":1433701,"h":77310845029,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_DES_CBC_SHA","d":1433701,"h":81605812325,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":85900779621,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1433701,"h":90195746917,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_DES_CBC_SHA","d":1433701,"h":94490714213,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":98785681509,"f":33},{"t":1433701,"n":"TLS_DH_anon_EXPORT_WITH_RC4_40_MD5","d":1433701,"h":103080648805,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_RC4_128_MD5","d":1433701,"h":107375616101,"f":33},{"t":1433701,"n":"TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA","d":1433701,"h":111670583397,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_DES_CBC_SHA","d":1433701,"h":115965550693,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":120260517989,"f":33},{"t":1433701,"n":"TLS_KRB5_WITH_DES_CBC_SHA","d":1433701,"h":124555485285,"f":33},{"t":1433701,"n":"TLS_KRB5_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":128850452581,"f":33},{"t":1433701,"n":"TLS_KRB5_WITH_RC4_128_SHA","d":1433701,"h":133145419877,"f":33},{"t":1433701,"n":"TLS_KRB5_WITH_IDEA_CBC_SHA","d":1433701,"h":137440387173,"f":33},{"t":1433701,"n":"TLS_KRB5_WITH_DES_CBC_MD5","d":1433701,"h":141735354469,"f":33},{"t":1433701,"n":"TLS_KRB5_WITH_3DES_EDE_CBC_MD5","d":1433701,"h":146030321765,"f":33},{"t":1433701,"n":"TLS_KRB5_WITH_RC4_128_MD5","d":1433701,"h":150325289061,"f":33},{"t":1433701,"n":"TLS_KRB5_WITH_IDEA_CBC_MD5","d":1433701,"h":154620256357,"f":33},{"t":1433701,"n":"TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA","d":1433701,"h":158915223653,"f":33},{"t":1433701,"n":"TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA","d":1433701,"h":163210190949,"f":33},{"t":1433701,"n":"TLS_KRB5_EXPORT_WITH_RC4_40_SHA","d":1433701,"h":167505158245,"f":33},{"t":1433701,"n":"TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5","d":1433701,"h":171800125541,"f":33},{"t":1433701,"n":"TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5","d":1433701,"h":176095092837,"f":33},{"t":1433701,"n":"TLS_KRB5_EXPORT_WITH_RC4_40_MD5","d":1433701,"h":180390060133,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_NULL_SHA","d":1433701,"h":184685027429,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_NULL_SHA","d":1433701,"h":188979994725,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_NULL_SHA","d":1433701,"h":193274962021,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_AES_128_CBC_SHA","d":1433701,"h":197569929317,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_AES_128_CBC_SHA","d":1433701,"h":201864896613,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_AES_128_CBC_SHA","d":1433701,"h":206159863909,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_AES_128_CBC_SHA","d":1433701,"h":210454831205,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_AES_128_CBC_SHA","d":1433701,"h":214749798501,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_AES_128_CBC_SHA","d":1433701,"h":219044765797,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_AES_256_CBC_SHA","d":1433701,"h":223339733093,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_AES_256_CBC_SHA","d":1433701,"h":227634700389,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_AES_256_CBC_SHA","d":1433701,"h":231929667685,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_AES_256_CBC_SHA","d":1433701,"h":236224634981,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_AES_256_CBC_SHA","d":1433701,"h":240519602277,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_AES_256_CBC_SHA","d":1433701,"h":244814569573,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_NULL_SHA256","d":1433701,"h":249109536869,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_AES_128_CBC_SHA256","d":1433701,"h":253404504165,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_AES_256_CBC_SHA256","d":1433701,"h":257699471461,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_AES_128_CBC_SHA256","d":1433701,"h":261994438757,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_AES_128_CBC_SHA256","d":1433701,"h":266289406053,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_AES_128_CBC_SHA256","d":1433701,"h":270584373349,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1433701,"h":274879340645,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA","d":1433701,"h":279174307941,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1433701,"h":283469275237,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA","d":1433701,"h":287764242533,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1433701,"h":292059209829,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA","d":1433701,"h":296354177125,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_AES_128_CBC_SHA256","d":1433701,"h":300649144421,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_AES_256_CBC_SHA256","d":1433701,"h":304944111717,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_AES_256_CBC_SHA256","d":1433701,"h":309239079013,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_AES_256_CBC_SHA256","d":1433701,"h":313534046309,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_AES_256_CBC_SHA256","d":1433701,"h":317829013605,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_AES_128_CBC_SHA256","d":1433701,"h":322123980901,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_AES_256_CBC_SHA256","d":1433701,"h":326418948197,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1433701,"h":330713915493,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA","d":1433701,"h":335008882789,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1433701,"h":339303850085,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA","d":1433701,"h":343598817381,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1433701,"h":347893784677,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA","d":1433701,"h":352188751973,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_RC4_128_SHA","d":1433701,"h":356483719269,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":360778686565,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_AES_128_CBC_SHA","d":1433701,"h":365073653861,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_AES_256_CBC_SHA","d":1433701,"h":369368621157,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_RC4_128_SHA","d":1433701,"h":373663588453,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":377958555749,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_AES_128_CBC_SHA","d":1433701,"h":382253523045,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_AES_256_CBC_SHA","d":1433701,"h":386548490341,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_RC4_128_SHA","d":1433701,"h":390843457637,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":395138424933,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_AES_128_CBC_SHA","d":1433701,"h":399433392229,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_AES_256_CBC_SHA","d":1433701,"h":403728359525,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_SEED_CBC_SHA","d":1433701,"h":408023326821,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_SEED_CBC_SHA","d":1433701,"h":412318294117,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_SEED_CBC_SHA","d":1433701,"h":416613261413,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_SEED_CBC_SHA","d":1433701,"h":420908228709,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_SEED_CBC_SHA","d":1433701,"h":425203196005,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_SEED_CBC_SHA","d":1433701,"h":429498163301,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_AES_128_GCM_SHA256","d":1433701,"h":433793130597,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_AES_256_GCM_SHA384","d":1433701,"h":438088097893,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_AES_128_GCM_SHA256","d":1433701,"h":442383065189,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_AES_256_GCM_SHA384","d":1433701,"h":446678032485,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_AES_128_GCM_SHA256","d":1433701,"h":450972999781,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_AES_256_GCM_SHA384","d":1433701,"h":455267967077,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_AES_128_GCM_SHA256","d":1433701,"h":459562934373,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_AES_256_GCM_SHA384","d":1433701,"h":463857901669,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_AES_128_GCM_SHA256","d":1433701,"h":468152868965,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_AES_256_GCM_SHA384","d":1433701,"h":472447836261,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_AES_128_GCM_SHA256","d":1433701,"h":476742803557,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_AES_256_GCM_SHA384","d":1433701,"h":481037770853,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_AES_128_GCM_SHA256","d":1433701,"h":485332738149,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_AES_256_GCM_SHA384","d":1433701,"h":489627705445,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_AES_128_GCM_SHA256","d":1433701,"h":493922672741,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_AES_256_GCM_SHA384","d":1433701,"h":498217640037,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_AES_128_GCM_SHA256","d":1433701,"h":502512607333,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_AES_256_GCM_SHA384","d":1433701,"h":506807574629,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_AES_128_CBC_SHA256","d":1433701,"h":511102541925,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_AES_256_CBC_SHA384","d":1433701,"h":515397509221,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_NULL_SHA256","d":1433701,"h":519692476517,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_NULL_SHA384","d":1433701,"h":523987443813,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_AES_128_CBC_SHA256","d":1433701,"h":528282411109,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_AES_256_CBC_SHA384","d":1433701,"h":532577378405,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_NULL_SHA256","d":1433701,"h":536872345701,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_NULL_SHA384","d":1433701,"h":541167312997,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_AES_128_CBC_SHA256","d":1433701,"h":545462280293,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_AES_256_CBC_SHA384","d":1433701,"h":549757247589,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_NULL_SHA256","d":1433701,"h":554052214885,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_NULL_SHA384","d":1433701,"h":558347182181,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1433701,"h":562642149477,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256","d":1433701,"h":566937116773,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1433701,"h":571232084069,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256","d":1433701,"h":575527051365,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1433701,"h":579822018661,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256","d":1433701,"h":584116985957,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1433701,"h":588411953253,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256","d":1433701,"h":592706920549,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1433701,"h":597001887845,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256","d":1433701,"h":601296855141,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1433701,"h":605591822437,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256","d":1433701,"h":609886789733,"f":33},{"t":1433701,"n":"TLS_AES_128_GCM_SHA256","d":1433701,"h":614181757029,"f":33},{"t":1433701,"n":"TLS_AES_256_GCM_SHA384","d":1433701,"h":618476724325,"f":33},{"t":1433701,"n":"TLS_CHACHA20_POLY1305_SHA256","d":1433701,"h":622771691621,"f":33},{"t":1433701,"n":"TLS_AES_128_CCM_SHA256","d":1433701,"h":627066658917,"f":33},{"t":1433701,"n":"TLS_AES_128_CCM_8_SHA256","d":1433701,"h":631361626213,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_NULL_SHA","d":1433701,"h":635656593509,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_RC4_128_SHA","d":1433701,"h":639951560805,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":644246528101,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA","d":1433701,"h":648541495397,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA","d":1433701,"h":652836462693,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_NULL_SHA","d":1433701,"h":657131429989,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_RC4_128_SHA","d":1433701,"h":661426397285,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":665721364581,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA","d":1433701,"h":670016331877,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA","d":1433701,"h":674311299173,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_NULL_SHA","d":1433701,"h":678606266469,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_RC4_128_SHA","d":1433701,"h":682901233765,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":687196201061,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_AES_128_CBC_SHA","d":1433701,"h":691491168357,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_AES_256_CBC_SHA","d":1433701,"h":695786135653,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_NULL_SHA","d":1433701,"h":700081102949,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_RC4_128_SHA","d":1433701,"h":704376070245,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":708671037541,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA","d":1433701,"h":712966004837,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA","d":1433701,"h":717260972133,"f":33},{"t":1433701,"n":"TLS_ECDH_anon_WITH_NULL_SHA","d":1433701,"h":721555939429,"f":33},{"t":1433701,"n":"TLS_ECDH_anon_WITH_RC4_128_SHA","d":1433701,"h":725850906725,"f":33},{"t":1433701,"n":"TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":730145874021,"f":33},{"t":1433701,"n":"TLS_ECDH_anon_WITH_AES_128_CBC_SHA","d":1433701,"h":734440841317,"f":33},{"t":1433701,"n":"TLS_ECDH_anon_WITH_AES_256_CBC_SHA","d":1433701,"h":738735808613,"f":33},{"t":1433701,"n":"TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":743030775909,"f":33},{"t":1433701,"n":"TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":747325743205,"f":33},{"t":1433701,"n":"TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":751620710501,"f":33},{"t":1433701,"n":"TLS_SRP_SHA_WITH_AES_128_CBC_SHA","d":1433701,"h":755915677797,"f":33},{"t":1433701,"n":"TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA","d":1433701,"h":760210645093,"f":33},{"t":1433701,"n":"TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA","d":1433701,"h":764505612389,"f":33},{"t":1433701,"n":"TLS_SRP_SHA_WITH_AES_256_CBC_SHA","d":1433701,"h":768800579685,"f":33},{"t":1433701,"n":"TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA","d":1433701,"h":773095546981,"f":33},{"t":1433701,"n":"TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA","d":1433701,"h":777390514277,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256","d":1433701,"h":781685481573,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384","d":1433701,"h":785980448869,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256","d":1433701,"h":790275416165,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384","d":1433701,"h":794570383461,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256","d":1433701,"h":798865350757,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384","d":1433701,"h":803160318053,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256","d":1433701,"h":807455285349,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384","d":1433701,"h":811750252645,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256","d":1433701,"h":816045219941,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384","d":1433701,"h":820340187237,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256","d":1433701,"h":824635154533,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384","d":1433701,"h":828930121829,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256","d":1433701,"h":833225089125,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384","d":1433701,"h":837520056421,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256","d":1433701,"h":841815023717,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384","d":1433701,"h":846109991013,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_RC4_128_SHA","d":1433701,"h":850404958309,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA","d":1433701,"h":854699925605,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA","d":1433701,"h":858994892901,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA","d":1433701,"h":863289860197,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256","d":1433701,"h":867584827493,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384","d":1433701,"h":871879794789,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA","d":1433701,"h":876174762085,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA256","d":1433701,"h":880469729381,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA384","d":1433701,"h":884764696677,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_ARIA_128_CBC_SHA256","d":1433701,"h":889059663973,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_ARIA_256_CBC_SHA384","d":1433701,"h":893354631269,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256","d":1433701,"h":897649598565,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384","d":1433701,"h":901944565861,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256","d":1433701,"h":906239533157,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384","d":1433701,"h":910534500453,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256","d":1433701,"h":914829467749,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384","d":1433701,"h":919124435045,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256","d":1433701,"h":923419402341,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384","d":1433701,"h":927714369637,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_ARIA_128_CBC_SHA256","d":1433701,"h":932009336933,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_ARIA_256_CBC_SHA384","d":1433701,"h":936304304229,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256","d":1433701,"h":940599271525,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384","d":1433701,"h":944894238821,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256","d":1433701,"h":949189206117,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384","d":1433701,"h":953484173413,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256","d":1433701,"h":957779140709,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384","d":1433701,"h":962074108005,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256","d":1433701,"h":966369075301,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384","d":1433701,"h":970664042597,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_ARIA_128_GCM_SHA256","d":1433701,"h":974959009893,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_ARIA_256_GCM_SHA384","d":1433701,"h":979253977189,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256","d":1433701,"h":983548944485,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384","d":1433701,"h":987843911781,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256","d":1433701,"h":992138879077,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384","d":1433701,"h":996433846373,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256","d":1433701,"h":1000728813669,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384","d":1433701,"h":1005023780965,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256","d":1433701,"h":1009318748261,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384","d":1433701,"h":1013613715557,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_ARIA_128_GCM_SHA256","d":1433701,"h":1017908682853,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_ARIA_256_GCM_SHA384","d":1433701,"h":1022203650149,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256","d":1433701,"h":1026498617445,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384","d":1433701,"h":1030793584741,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256","d":1433701,"h":1035088552037,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384","d":1433701,"h":1039383519333,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256","d":1433701,"h":1043678486629,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384","d":1433701,"h":1047973453925,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256","d":1433701,"h":1052268421221,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384","d":1433701,"h":1056563388517,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_ARIA_128_CBC_SHA256","d":1433701,"h":1060858355813,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_ARIA_256_CBC_SHA384","d":1433701,"h":1065153323109,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256","d":1433701,"h":1069448290405,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384","d":1433701,"h":1073743257701,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256","d":1433701,"h":1078038224997,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384","d":1433701,"h":1082333192293,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_ARIA_128_GCM_SHA256","d":1433701,"h":1086628159589,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_ARIA_256_GCM_SHA384","d":1433701,"h":1090923126885,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256","d":1433701,"h":1095218094181,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384","d":1433701,"h":1099513061477,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256","d":1433701,"h":1103808028773,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384","d":1433701,"h":1108102996069,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256","d":1433701,"h":1112397963365,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384","d":1433701,"h":1116692930661,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256","d":1433701,"h":1120987897957,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384","d":1433701,"h":1125282865253,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256","d":1433701,"h":1129577832549,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384","d":1433701,"h":1133872799845,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1433701,"h":1138167767141,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384","d":1433701,"h":1142462734437,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1433701,"h":1146757701733,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384","d":1433701,"h":1151052669029,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1433701,"h":1155347636325,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1433701,"h":1159642603621,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1433701,"h":1163937570917,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1433701,"h":1168232538213,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1433701,"h":1172527505509,"f":33},{"t":1433701,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1433701,"h":1176822472805,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256","d":1433701,"h":1181117440101,"f":33},{"t":1433701,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384","d":1433701,"h":1185412407397,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256","d":1433701,"h":1189707374693,"f":33},{"t":1433701,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384","d":1433701,"h":1194002341989,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256","d":1433701,"h":1198297309285,"f":33},{"t":1433701,"n":"TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384","d":1433701,"h":1202592276581,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256","d":1433701,"h":1206887243877,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384","d":1433701,"h":1211182211173,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256","d":1433701,"h":1215477178469,"f":33},{"t":1433701,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384","d":1433701,"h":1219772145765,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1433701,"h":1224067113061,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1433701,"h":1228362080357,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1433701,"h":1232657047653,"f":33},{"t":1433701,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1433701,"h":1236952014949,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1433701,"h":1241246982245,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1433701,"h":1245541949541,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1433701,"h":1249836916837,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1433701,"h":1254131884133,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1433701,"h":1258426851429,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1433701,"h":1262721818725,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1433701,"h":1267016786021,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1433701,"h":1271311753317,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1433701,"h":1275606720613,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1433701,"h":1279901687909,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1433701,"h":1284196655205,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1433701,"h":1288491622501,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1433701,"h":1292786589797,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1433701,"h":1297081557093,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_AES_128_CCM","d":1433701,"h":1301376524389,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_AES_256_CCM","d":1433701,"h":1305671491685,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_AES_128_CCM","d":1433701,"h":1309966458981,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_AES_256_CCM","d":1433701,"h":1314261426277,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_AES_128_CCM_8","d":1433701,"h":1318556393573,"f":33},{"t":1433701,"n":"TLS_RSA_WITH_AES_256_CCM_8","d":1433701,"h":1322851360869,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_AES_128_CCM_8","d":1433701,"h":1327146328165,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_AES_256_CCM_8","d":1433701,"h":1331441295461,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_AES_128_CCM","d":1433701,"h":1335736262757,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_AES_256_CCM","d":1433701,"h":1340031230053,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_AES_128_CCM","d":1433701,"h":1344326197349,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_AES_256_CCM","d":1433701,"h":1348621164645,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_AES_128_CCM_8","d":1433701,"h":1352916131941,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_AES_256_CCM_8","d":1433701,"h":1357211099237,"f":33},{"t":1433701,"n":"TLS_PSK_DHE_WITH_AES_128_CCM_8","d":1433701,"h":1361506066533,"f":33},{"t":1433701,"n":"TLS_PSK_DHE_WITH_AES_256_CCM_8","d":1433701,"h":1365801033829,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CCM","d":1433701,"h":1370096001125,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CCM","d":1433701,"h":1374390968421,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8","d":1433701,"h":1378685935717,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8","d":1433701,"h":1382980903013,"f":33},{"t":1433701,"n":"TLS_ECCPWD_WITH_AES_128_GCM_SHA256","d":1433701,"h":1387275870309,"f":33},{"t":1433701,"n":"TLS_ECCPWD_WITH_AES_256_GCM_SHA384","d":1433701,"h":1391570837605,"f":33},{"t":1433701,"n":"TLS_ECCPWD_WITH_AES_128_CCM_SHA256","d":1433701,"h":1395865804901,"f":33},{"t":1433701,"n":"TLS_ECCPWD_WITH_AES_256_CCM_SHA384","d":1433701,"h":1400160772197,"f":33},{"t":1433701,"n":"TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256","d":1433701,"h":1404455739493,"f":33},{"t":1433701,"n":"TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256","d":1433701,"h":1408750706789,"f":33},{"t":1433701,"n":"TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256","d":1433701,"h":1413045674085,"f":33},{"t":1433701,"n":"TLS_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1433701,"h":1417340641381,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1433701,"h":1421635608677,"f":33},{"t":1433701,"n":"TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1433701,"h":1425930575973,"f":33},{"t":1433701,"n":"TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1433701,"h":1430225543269,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256","d":1433701,"h":1434520510565,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384","d":1433701,"h":1438815477861,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256","d":1433701,"h":1443110445157,"f":33},{"t":1433701,"n":"TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256","d":1433701,"h":1447405412453,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1433701,"h":1451700379749,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1433701,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.TlsCipherSuite`; }
        });
        
        $asm.$str("$snsc.System.Security.Authentication.ExtendedProtection.PolicyEnforcement", ($self) => class PolicyEnforcement extends $.$spc.System.Enum
        {
            static Never = 0;
            static WhenSupported = 1;
            static Always = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Never": 0n,
                    "WhenSupported": 1n,
                    "Always": 2n
                };
            }
            static $h = 1630309;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1630309,"n":"Never","d":1630309,"h":4296597605,"f":33},{"t":1630309,"n":"WhenSupported","d":1630309,"h":8591564901,"f":33},{"t":1630309,"n":"Always","d":1630309,"h":12886532197,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1630309,"h":17181499493,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1630309}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.PolicyEnforcement`; }
        });
        
        $asm.$str("$snsc.System.Security.Authentication.ExtendedProtection.ProtectionScenario", ($self) => class ProtectionScenario extends $.$spc.System.Enum
        {
            static TransportSelected = 0;
            static TrustedProxy = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TransportSelected": 0n,
                    "TrustedProxy": 1n
                };
            }
            static $h = 1695845;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1695845,"n":"TransportSelected","d":1695845,"h":4296663141,"f":33},{"t":1695845,"n":"TrustedProxy","d":1695845,"h":8591630437,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1695845,"h":12886597733,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1695845}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ProtectionScenario`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateStream", ($self) => class NegotiateStream extends $.$snsc.System.Net.Security.AuthenticatedStream
        {
            $ctor$4(/*System.IO.Stream*/ innerStream)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get RemoteIdentity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsClient()
            {
            }
            /*void */ AuthenticateAsClient$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName)
            {
            }
            /*void */ AuthenticateAsClient$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsClient$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName)
            {
            }
            /*void */ AuthenticateAsClient$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsServer()
            {
            }
            /*void */ AuthenticateAsServer$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsServer$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsServer$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient(/*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer(/*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndAuthenticateAsClient(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndAuthenticateAsServer(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 647269;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":122981,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180516453,"f":32769},"n":"CanRead","d":647269,"h":12885549157,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":25770451045,"f":32769},"n":"CanSeek","d":647269,"h":21475483749,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":34360385637,"f":32769},"n":"CanTimeout","d":647269,"h":30065418341,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42950320229,"f":32769},"n":"CanWrite","d":647269,"h":38655352933,"f":32769},{"p":117243905,"g":{"r":0,"d":0,"h":51540254821,"f":129},"n":"ImpersonationLevel","d":647269,"h":47245287525,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":60130189413,"f":32769},"n":"IsAuthenticated","d":647269,"h":55835222117,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":68720124005,"f":32769},"n":"IsEncrypted","d":647269,"h":64425156709,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":77310058597,"f":32769},"n":"IsMutuallyAuthenticated","d":647269,"h":73015091301,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":85899993189,"f":32769},"n":"IsServer","d":647269,"h":81605025893,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":94489927781,"f":32769},"n":"IsSigned","d":647269,"h":90194960485,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":103079862373,"f":32769},"n":"Length","d":647269,"h":98784895077,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":111669796965,"f":32769},"s":{"r":0,"d":0,"h":115964764261,"f":32769},"n":"Position","d":647269,"h":107374829669,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":124554698853,"f":32769},"s":{"r":0,"d":0,"h":128849666149,"f":32769},"n":"ReadTimeout","d":647269,"h":120259731557,"f":32769},{"p":117047297,"g":{"r":0,"d":0,"h":137439600741,"f":129},"n":"RemoteIdentity","d":647269,"h":133144633445,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":146029535333,"f":32769},"s":{"r":0,"d":0,"h":150324502629,"f":32769},"n":"WriteTimeout","d":647269,"h":141734568037,"f":32769}],"m":[{"r":65537,"n":"AuthenticateAsClient","d":647269,"h":154619469925,"f":129},{"r":65537,"p":[{"n":"credential","p":3839434},{"n":"binding","p":5412298},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClient","o":"@$1","d":647269,"h":158914437221,"f":129},{"r":65537,"p":[{"n":"credential","p":3839434},{"n":"binding","p":5412298},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":712805},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClient","o":"@$2","d":647269,"h":163209404517,"f":129},{"r":65537,"p":[{"n":"credential","p":3839434},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClient","o":"@$3","d":647269,"h":167504371813,"f":129},{"r":65537,"p":[{"n":"credential","p":3839434},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":712805},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClient","o":"@$4","d":647269,"h":171799339109,"f":129},{"r":133300225,"n":"AuthenticateAsClientAsync","d":647269,"h":176094306405,"f":129},{"r":133300225,"p":[{"n":"credential","p":3839434},{"n":"binding","p":5412298},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$1","d":647269,"h":180389273701,"f":129},{"r":133300225,"p":[{"n":"credential","p":3839434},{"n":"binding","p":5412298},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":712805},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClientAsync","o":"@$2","d":647269,"h":184684240997,"f":129},{"r":133300225,"p":[{"n":"credential","p":3839434},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$3","d":647269,"h":188979208293,"f":129},{"r":133300225,"p":[{"n":"credential","p":3839434},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":712805},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClientAsync","o":"@$4","d":647269,"h":193274175589,"f":129},{"r":65537,"n":"AuthenticateAsServer","d":647269,"h":197569142885,"f":129},{"r":65537,"p":[{"n":"credential","p":3839434},{"n":"requiredProtectionLevel","p":712805},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServer","o":"@$1","d":647269,"h":201864110181,"f":129},{"r":65537,"p":[{"n":"credential","p":3839434},{"n":"policy","p":1564773},{"n":"requiredProtectionLevel","p":712805},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServer","o":"@$2","d":647269,"h":206159077477,"f":129},{"r":65537,"p":[{"n":"policy","p":1564773}],"n":"AuthenticateAsServer","o":"@$3","d":647269,"h":210454044773,"f":129},{"r":133300225,"n":"AuthenticateAsServerAsync","d":647269,"h":214749012069,"f":129},{"r":133300225,"p":[{"n":"credential","p":3839434},{"n":"requiredProtectionLevel","p":712805},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServerAsync","o":"@$1","d":647269,"h":219043979365,"f":129},{"r":133300225,"p":[{"n":"credential","p":3839434},{"n":"policy","p":1564773},{"n":"requiredProtectionLevel","p":712805},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServerAsync","o":"@$2","d":647269,"h":223338946661,"f":129},{"r":133300225,"p":[{"n":"policy","p":1564773}],"n":"AuthenticateAsServerAsync","o":"@$3","d":647269,"h":227633913957,"f":129},{"r":56950785,"p":[{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","d":647269,"h":231928881253,"f":129},{"r":56950785,"p":[{"n":"credential","p":3839434},{"n":"binding","p":5412298},{"n":"targetName","p":1310721},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$1","d":647269,"h":236223848549,"f":129},{"r":56950785,"p":[{"n":"credential","p":3839434},{"n":"binding","p":5412298},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":712805},{"n":"allowedImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$2","d":647269,"h":240518815845,"f":129},{"r":56950785,"p":[{"n":"credential","p":3839434},{"n":"targetName","p":1310721},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$3","d":647269,"h":244813783141,"f":129},{"r":56950785,"p":[{"n":"credential","p":3839434},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":712805},{"n":"allowedImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$4","d":647269,"h":249108750437,"f":129},{"r":56950785,"p":[{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","d":647269,"h":253403717733,"f":129},{"r":56950785,"p":[{"n":"credential","p":3839434},{"n":"requiredProtectionLevel","p":712805},{"n":"requiredImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$1","d":647269,"h":257698685029,"f":129},{"r":56950785,"p":[{"n":"credential","p":3839434},{"n":"policy","p":1564773},{"n":"requiredProtectionLevel","p":712805},{"n":"requiredImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$2","d":647269,"h":261993652325,"f":129},{"r":56950785,"p":[{"n":"policy","p":1564773},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$3","d":647269,"h":266288619621,"f":129},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginRead","d":647269,"h":270583586917,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":647269,"h":274878554213,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":647269,"h":279173521509,"f":32772},{"r":136118273,"n":"DisposeAsync","d":647269,"h":283468488805,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAuthenticateAsClient","d":647269,"h":287763456101,"f":129},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAuthenticateAsServer","d":647269,"h":292058423397,"f":129},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":647269,"h":296353390693,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":647269,"h":300648357989,"f":32769},{"r":65537,"n":"Flush","d":647269,"h":304943325285,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":647269,"h":309238292581,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":647269,"h":313533259877,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":647269,"h":317828227173,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":647269,"h":322123194469,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":647269,"h":326418161765,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":647269,"h":330713129061,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":647269,"h":335008096357,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":647269,"h":339303063653,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":647269,"h":343598030949,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62128129}],"n":".ctor","o":"$ctor$4","d":647269,"h":4295614565,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":647269,"h":8590581861,"f":1}],"i":[57475073,56885249],"h":647269}; }
            static get $b() { return $.$snsc.System.Net.Security.AuthenticatedStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.NegotiateStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslStream", ($self) => class SslStream extends $.$snsc.System.Net.Security.AuthenticatedStream
        {
            $ctor$4(/*System.IO.Stream*/ innerStream)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$7(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback, /*System.Net.Security.LocalCertificateSelectionCallback?*/ userCertificateSelectionCallback)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$8(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback, /*System.Net.Security.LocalCertificateSelectionCallback?*/ userCertificateSelectionCallback, /*System.Net.Security.EncryptionPolicy*/ encryptionPolicy)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CheckCertRevocationStatus()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.CipherAlgorithmType */ get CipherAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get CipherStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.HashAlgorithmType */ get HashAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get HashStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExchangeAlgorithmType */ get KeyExchangeAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get KeyExchangeStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get LocalCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslApplicationProtocol */ get NegotiatedApplicationProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.TlsCipherSuite */ get NegotiatedCipherSuite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get RemoteCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get TargetHostName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.TransportContext */ get TransportContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsClient(/*System.Net.Security.SslClientAuthenticationOptions*/ sslClientAuthenticationOptions)
            {
            }
            /*void */ AuthenticateAsClient$1(/*string*/ targetHost)
            {
            }
            /*void */ AuthenticateAsClient$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation)
            {
            }
            /*void */ AuthenticateAsClient$3(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync(/*System.Net.Security.SslClientAuthenticationOptions*/ sslClientAuthenticationOptions, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$1(/*string*/ targetHost)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$3(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsServer(/*System.Net.Security.SslServerAuthenticationOptions*/ sslServerAuthenticationOptions)
            {
            }
            /*void */ AuthenticateAsServer$1(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate)
            {
            }
            /*void */ AuthenticateAsServer$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation)
            {
            }
            /*void */ AuthenticateAsServer$3(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync(/*System.Net.Security.ServerOptionsSelectionCallback*/ optionsCallback, /*object?*/ state, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$1(/*System.Net.Security.SslServerAuthenticationOptions*/ sslServerAuthenticationOptions, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$3(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$4(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient(/*string*/ targetHost, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$1(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$1(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndAuthenticateAsClient(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndAuthenticateAsServer(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ NegotiateClientCertificateAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*System.Threading.Tasks.Task */ ShutdownAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Write$2(/*byte[]*/ buffer)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 1302629;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":122981,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30066073701,"f":32769},"n":"CanRead","d":1302629,"h":25771106405,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38656008293,"f":32769},"n":"CanSeek","d":1302629,"h":34361040997,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":47245942885,"f":32769},"n":"CanTimeout","d":1302629,"h":42950975589,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":55835877477,"f":32769},"n":"CanWrite","d":1302629,"h":51540910181,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":64425812069,"f":129},"n":"CheckCertRevocationStatus","d":1302629,"h":60130844773,"f":129},{"p":5281226,"g":{"r":0,"d":0,"h":73015746661,"f":129},"n":"CipherAlgorithm","d":1302629,"h":68720779365,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":81605681253,"f":129},"n":"CipherStrength","d":1302629,"h":77310713957,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":5543370,"g":{"r":0,"d":0,"h":90195615845,"f":129},"n":"HashAlgorithm","d":1302629,"h":85900648549,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":98785550437,"f":129},"n":"HashStrength","d":1302629,"h":94490583141,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":107375485029,"f":32769},"n":"IsAuthenticated","d":1302629,"h":103080517733,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":115965419621,"f":32769},"n":"IsEncrypted","d":1302629,"h":111670452325,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":124555354213,"f":32769},"n":"IsMutuallyAuthenticated","d":1302629,"h":120260386917,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":133145288805,"f":32769},"n":"IsServer","d":1302629,"h":128850321509,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":141735223397,"f":32769},"n":"IsSigned","d":1302629,"h":137440256101,"f":32769},{"p":5346762,"g":{"r":0,"d":0,"h":150325157989,"f":129},"n":"KeyExchangeAlgorithm","d":1302629,"h":146030190693,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":158915092581,"f":129},"n":"KeyExchangeStrength","d":1302629,"h":154620125285,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":167505027173,"f":32769},"n":"Length","d":1302629,"h":163210059877,"f":32769},{"p":28174526,"g":{"r":0,"d":0,"h":176094961765,"f":129},"n":"LocalCertificate","d":1302629,"h":171799994469,"f":129},{"p":974949,"g":{"r":0,"d":0,"h":184684896357,"f":1},"n":"NegotiatedApplicationProtocol","d":1302629,"h":180389929061,"f":1},{"p":1433701,"g":{"r":0,"d":0,"h":193274830949,"f":129},"n":"NegotiatedCipherSuite","d":1302629,"h":188979863653,"f":129,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"p":917505,"g":{"r":0,"d":0,"h":201864765541,"f":32769},"s":{"r":0,"d":0,"h":206159732837,"f":32769},"n":"Position","d":1302629,"h":197569798245,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":214749667429,"f":32769},"s":{"r":0,"d":0,"h":219044634725,"f":32769},"n":"ReadTimeout","d":1302629,"h":210454700133,"f":32769},{"p":28174526,"g":{"r":0,"d":0,"h":227634569317,"f":129},"n":"RemoteCertificate","d":1302629,"h":223339602021,"f":129},{"p":5608906,"g":{"r":0,"d":0,"h":236224503909,"f":129},"n":"SslProtocol","d":1302629,"h":231929536613,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":244814438501,"f":1},"n":"TargetHostName","d":1302629,"h":240519471205,"f":1},{"p":5019082,"g":{"r":0,"d":0,"h":253404373093,"f":1},"n":"TransportContext","d":1302629,"h":249109405797,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":261994307685,"f":32769},"s":{"r":0,"d":0,"h":266289274981,"f":32769},"n":"WriteTimeout","d":1302629,"h":257699340389,"f":32769}],"m":[{"r":65537,"p":[{"n":"sslClientAuthenticationOptions","p":1106021}],"n":"AuthenticateAsClient","d":1302629,"h":270584242277,"f":1},{"r":65537,"p":[{"n":"targetHost","p":1310721}],"n":"AuthenticateAsClient","o":"@$1","d":1302629,"h":274879209573,"f":129},{"r":65537,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28436670},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClient","o":"@$2","d":1302629,"h":279174176869,"f":129},{"r":65537,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28436670},{"n":"enabledSslProtocols","p":5608906},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClient","o":"@$3","d":1302629,"h":283469144165,"f":129},{"r":133300225,"p":[{"n":"sslClientAuthenticationOptions","p":1106021},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsClientAsync","d":1302629,"h":287764111461,"f":1},{"r":133300225,"p":[{"n":"targetHost","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$1","d":1302629,"h":292059078757,"f":129},{"r":133300225,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28436670},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClientAsync","o":"@$2","d":1302629,"h":296354046053,"f":129},{"r":133300225,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28436670},{"n":"enabledSslProtocols","p":5608906},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClientAsync","o":"@$3","d":1302629,"h":300649013349,"f":129},{"r":65537,"p":[{"n":"sslServerAuthenticationOptions","p":1237093}],"n":"AuthenticateAsServer","d":1302629,"h":304943980645,"f":1},{"r":65537,"p":[{"n":"serverCertificate","p":28174526}],"n":"AuthenticateAsServer","o":"@$1","d":1302629,"h":309238947941,"f":129},{"r":65537,"p":[{"n":"serverCertificate","p":28174526},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServer","o":"@$2","d":1302629,"h":313533915237,"f":129},{"r":65537,"p":[{"n":"serverCertificate","p":28174526},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5608906},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServer","o":"@$3","d":1302629,"h":317828882533,"f":129},{"r":133300225,"p":[{"n":"optionsCallback","p":909413},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsServerAsync","d":1302629,"h":322123849829,"f":1},{"r":133300225,"p":[{"n":"sslServerAuthenticationOptions","p":1237093},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsServerAsync","o":"@$1","d":1302629,"h":326418817125,"f":1},{"r":133300225,"p":[{"n":"serverCertificate","p":28174526}],"n":"AuthenticateAsServerAsync","o":"@$2","d":1302629,"h":330713784421,"f":129},{"r":133300225,"p":[{"n":"serverCertificate","p":28174526},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServerAsync","o":"@$3","d":1302629,"h":335008751717,"f":129},{"r":133300225,"p":[{"n":"serverCertificate","p":28174526},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5608906},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServerAsync","o":"@$4","d":1302629,"h":339303719013,"f":129},{"r":56950785,"p":[{"n":"targetHost","p":1310721},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","d":1302629,"h":343598686309,"f":129},{"r":56950785,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28436670},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$1","d":1302629,"h":347893653605,"f":129},{"r":56950785,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28436670},{"n":"enabledSslProtocols","p":5608906},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$2","d":1302629,"h":352188620901,"f":129},{"r":56950785,"p":[{"n":"serverCertificate","p":28174526},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","d":1302629,"h":356483588197,"f":129},{"r":56950785,"p":[{"n":"serverCertificate","p":28174526},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$1","d":1302629,"h":360778555493,"f":129},{"r":56950785,"p":[{"n":"serverCertificate","p":28174526},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5608906},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$2","d":1302629,"h":365073522789,"f":129},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginRead","d":1302629,"h":369368490085,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":1302629,"h":373663457381,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1302629,"h":377958424677,"f":32772},{"r":136118273,"n":"DisposeAsync","d":1302629,"h":382253391973,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAuthenticateAsClient","d":1302629,"h":386548359269,"f":129},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAuthenticateAsServer","d":1302629,"h":390843326565,"f":129},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":1302629,"h":395138293861,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":1302629,"h":399433261157,"f":32769},{"r":65537,"n":"Flush","d":1302629,"h":408023195749,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1302629,"h":412318163045,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"NegotiateClientCertificateAsync","d":1302629,"h":416613130341,"f":129,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1302629,"h":420908097637,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1302629,"h":425203064933,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1302629,"h":429498032229,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1302629,"h":433792999525,"f":32769},{"r":655361,"n":"ReadByte","d":1302629,"h":438087966821,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1302629,"h":442382934117,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1302629,"h":446677901413,"f":32769},{"r":133300225,"n":"ShutdownAsync","d":1302629,"h":450972868709,"f":129},{"r":65537,"p":[{"n":"buffer","p":0}],"n":"Write","o":"@$2","d":1302629,"h":455267836005,"f":1},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1302629,"h":459562803301,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":1302629,"h":463857770597,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1302629,"h":468152737893,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1302629,"h":472447705189,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":1302629,"h":476742672485,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62128129}],"n":".ctor","o":"$ctor$4","d":1302629,"h":4296269925,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":1302629,"h":8591237221,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":778341}],"n":".ctor","o":"$ctor$6","d":1302629,"h":12886204517,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":778341},{"n":"userCertificateSelectionCallback","p":319589}],"n":".ctor","o":"$ctor$7","d":1302629,"h":17181171813,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":778341},{"n":"userCertificateSelectionCallback","p":319589},{"n":"encryptionPolicy","p":254053}],"n":".ctor","o":"$ctor$8","d":1302629,"h":21476139109,"f":1}],"i":[57475073,56885249],"h":1302629}; }
            static get $b() { return $.$snsc.System.Net.Security.AuthenticatedStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.SslStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.LocalCertificateSelectionCallback", ($self) => class LocalCertificateSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate?*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$spc.System.String*/ $targetHost, /*$.$sscr.System.Security.Cryptography.X509Certificates.X509CertificateCollection*/ $localCertificates, /*$.$spc.System.Nullable$$*/ $remoteCertificate, /**/ $acceptableIssuers)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 319589;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":28174526,"p":[{"n":"sender","p":131073},{"n":"targetHost","p":1310721},{"n":"localCertificates","p":28436670},{"n":"remoteCertificate","p":28174526},{"n":"acceptableIssuers","p":0}],"n":"Invoke","d":319589,"h":8590254181,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"targetHost","p":1310721},{"n":"localCertificates","p":28436670},{"n":"remoteCertificate","p":28174526},{"n":"acceptableIssuers","p":0},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":319589,"h":12885221477,"f":129},{"r":28174526,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":319589,"h":17180188773,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":319589,"h":4295286885,"f":1}],"i":[57147393,113377281],"h":319589}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.LocalCertificateSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.RemoteCertificateValidationCallback", ($self) => class RemoteCertificateValidationCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*bool*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$spc.System.Nullable$$*/ $certificate, /*$.$spc.System.Nullable$$*/ $chain, /*$.$snp.System.Net.Security.SslPolicyErrors*/ $sslPolicyErrors)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 778341;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":262145,"p":[{"n":"sender","p":131073},{"n":"certificate","p":28174526},{"n":"chain","p":28895422},{"n":"sslPolicyErrors","p":4298186}],"n":"Invoke","d":778341,"h":8590712933,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"certificate","p":28174526},{"n":"chain","p":28895422},{"n":"sslPolicyErrors","p":4298186},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":778341,"h":12885680229,"f":129},{"r":262145,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":778341,"h":17180647525,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":778341,"h":4295745637,"f":1}],"i":[57147393,113377281],"h":778341}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.RemoteCertificateValidationCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.ServerCertificateSelectionCallback", ($self) => class ServerCertificateSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$spc.System.Nullable$$*/ $hostName)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 843877;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":28174526,"p":[{"n":"sender","p":131073},{"n":"hostName","p":1310721}],"n":"Invoke","d":843877,"h":8590778469,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"hostName","p":1310721},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":843877,"h":12885745765,"f":129},{"r":28174526,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":843877,"h":17180713061,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":843877,"h":4295811173,"f":1}],"i":[57147393,113377281],"h":843877}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.ServerCertificateSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.ServerOptionsSelectionCallback", ($self) => class ServerOptionsSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Security.SslServerAuthenticationOptions>*/ Invoke(/*$.$snsc.System.Net.Security.SslStream*/ $stream, /*$.$snsc.System.Net.Security.SslClientHelloInfo*/ $clientHelloInfo, /*$.$spc.System.Nullable$$*/ $state, /*$.$spc.System.Threading.CancellationToken*/ $cancellationToken)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 909413;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snsc.System.Net.Security.SslServerAuthenticationOptions).$h,"p":[{"n":"stream","p":1302629},{"n":"clientHelloInfo","p":1171557},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193}],"n":"Invoke","d":909413,"h":8590844005,"f":129},{"r":56950785,"p":[{"n":"stream","p":1302629},{"n":"clientHelloInfo","p":1171557},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":909413,"h":12885811301,"f":129},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snsc.System.Net.Security.SslServerAuthenticationOptions).$h,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":909413,"h":17180778597,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":909413,"h":4295876709,"f":1}],"i":[57147393,113377281],"h":909413}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.ServerOptionsSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.AuthenticationException", ($self) => class AuthenticationException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$12(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            static $h = 1499237;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":1499237}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.AuthenticationException`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.InvalidCredentialException", ($self) => class InvalidCredentialException extends $.$snsc.System.Security.Authentication.AuthenticationException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$14(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$16(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            static $h = 1826917;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1499237,"h":1826917}; }
            static get $b() { return $.$snsc.System.Security.Authentication.AuthenticationException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.InvalidCredentialException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.Numerics", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Console", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Net.NameResolution", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography"))