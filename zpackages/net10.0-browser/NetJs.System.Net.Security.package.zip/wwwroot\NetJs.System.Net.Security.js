
(function ($global, $, $spc, $mwp, $sc, $sdt, $st, $scc, $sm, $snv, $spu, $sr, $sris, $sri, $sl, $sci, $scn, $stee, $scsl, $stt, $sttp, $sdd, $sic, $sim, $srm, $sds, $srn, $sfa, $snp, $ssc, $sspw, $sto, $snnr, $sns, $sscr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Security", 
    {"h":53356,"f":"System.Net.Security","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bf7a34a6f78fee11131301a9f55ca16a968616013","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Security","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Security","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snsc.System.Net.Security.AuthenticatedStream", ($self) => class AuthenticatedStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.IO.Stream */ get InnerStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get LeaveInnerStreamOpen()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 118892;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":62193665,"g":{"r":0,"d":0,"h":12885020780,"f":4},"n":"InnerStream","d":118892,"h":8590053484,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":21474955372,"f":257},"n":"IsAuthenticated","d":118892,"h":17179988076,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":30064889964,"f":257},"n":"IsEncrypted","d":118892,"h":25769922668,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":38654824556,"f":257},"n":"IsMutuallyAuthenticated","d":118892,"h":34359857260,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":47244759148,"f":257},"n":"IsServer","d":118892,"h":42949791852,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":55834693740,"f":257},"n":"IsSigned","d":118892,"h":51539726444,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":64424628332,"f":1},"n":"LeaveInnerStreamOpen","d":118892,"h":60129661036,"f":1}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":118892,"h":68719595628,"f":32772},{"r":136118273,"n":"DisposeAsync","d":118892,"h":73014562924,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":118892,"h":4295086188,"f":4}],"i":[57540609,56950785],"h":118892}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.AuthenticatedStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.CipherSuitesPolicy", ($self) => class CipherSuitesPolicy extends $.$spc.System.Object
        {
            $ctor$1(/*System.Collections.Generic.IEnumerable<System.Net.Security.TlsCipherSuite>*/ allowedCipherSuites)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.Generic.IEnumerable<System.Net.Security.TlsCipherSuite> */ get AllowedCipherSuites()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 184428;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$snsc.System.Net.Security.TlsCipherSuite).$h,"g":{"r":0,"d":0,"h":12885086316,"f":1},"n":"AllowedCipherSuites","d":184428,"h":8590119020,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]}],"c":[{"p":[{"n":"allowedCipherSuites","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$snsc.System.Net.Security.TlsCipherSuite).$h}],"n":".ctor","o":"$ctor$1","d":184428,"h":4295151724,"f":1,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]}],"h":184428,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"windows","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.CipherSuitesPolicy`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthenticationClientOptions", ($self) => class NegotiateAuthenticationClientOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get AllowedImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set AllowedImpersonationLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get Binding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ set Binding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ get Credential()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ set Credential(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Package(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get RequiredProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ set RequiredProtectionLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RequireMutualAuthentication()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RequireMutualAuthentication(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TargetName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 446572;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":117243905,"g":{"r":0,"d":0,"h":12885348460,"f":1},"s":{"r":0,"d":0,"h":17180315756,"f":1},"n":"AllowedImpersonationLevel","d":446572,"h":8590381164,"f":1},{"p":5415410,"g":{"r":0,"d":0,"h":25770250348,"f":1},"s":{"r":0,"d":0,"h":30065217644,"f":1},"n":"Binding","d":446572,"h":21475283052,"f":1},{"p":3842546,"g":{"r":0,"d":0,"h":38655152236,"f":1},"s":{"r":0,"d":0,"h":42950119532,"f":1},"n":"Credential","d":446572,"h":34360184940,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540054124,"f":1},"s":{"r":0,"d":0,"h":55835021420,"f":1},"n":"Package","d":446572,"h":47245086828,"f":1},{"p":708716,"g":{"r":0,"d":0,"h":64424956012,"f":1},"s":{"r":0,"d":0,"h":68719923308,"f":1},"n":"RequiredProtectionLevel","d":446572,"h":60129988716,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77309857900,"f":1},"s":{"r":0,"d":0,"h":81604825196,"f":1},"n":"RequireMutualAuthentication","d":446572,"h":73014890604,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90194759788,"f":1},"s":{"r":0,"d":0,"h":94489727084,"f":1},"n":"TargetName","d":446572,"h":85899792492,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":446572,"h":4295413868,"f":1}],"h":446572}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationClientOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthenticationServerOptions", ($self) => class NegotiateAuthenticationServerOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get Binding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ set Binding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ get Credential()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ set Credential(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Package(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy? */ get Policy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy? */ set Policy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get RequiredImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set RequiredImpersonationLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get RequiredProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ set RequiredProtectionLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 512108;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5415410,"g":{"r":0,"d":0,"h":12885413996,"f":1},"s":{"r":0,"d":0,"h":17180381292,"f":1},"n":"Binding","d":512108,"h":8590446700,"f":1},{"p":3842546,"g":{"r":0,"d":0,"h":25770315884,"f":1},"s":{"r":0,"d":0,"h":30065283180,"f":1},"n":"Credential","d":512108,"h":21475348588,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38655217772,"f":1},"s":{"r":0,"d":0,"h":42950185068,"f":1},"n":"Package","d":512108,"h":34360250476,"f":1},{"p":1560684,"g":{"r":0,"d":0,"h":51540119660,"f":1},"s":{"r":0,"d":0,"h":55835086956,"f":1},"n":"Policy","d":512108,"h":47245152364,"f":1},{"p":117243905,"g":{"r":0,"d":0,"h":64425021548,"f":1},"s":{"r":0,"d":0,"h":68719988844,"f":1},"n":"RequiredImpersonationLevel","d":512108,"h":60130054252,"f":1},{"p":708716,"g":{"r":0,"d":0,"h":77309923436,"f":1},"s":{"r":0,"d":0,"h":81604890732,"f":1},"n":"RequiredProtectionLevel","d":512108,"h":73014956140,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":512108,"h":4295479404,"f":1}],"h":512108}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationServerOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslCertificateTrust", ($self) => class SslCertificateTrust extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*System.Net.Security.SslCertificateTrust */ CreateForX509Collection(/*System.Security.Cryptography.X509Certificates.X509Certificate2Collection*/ trustList, /*bool*/ sendTrustInHandshake)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslCertificateTrust */ CreateForX509Store(/*System.Security.Cryptography.X509Certificates.X509Store*/ store, /*bool*/ sendTrustInHandshake)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1036396;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1036396,"p":[{"n":"trustList","p":28299725},{"n":"sendTrustInHandshake","p":262145,"f":65,"v":false}],"n":"CreateForX509Collection","d":1036396,"h":8590970988,"f":33},{"r":1036396,"p":[{"n":"store","p":30462413},{"n":"sendTrustInHandshake","p":262145,"f":65,"v":false}],"n":"CreateForX509Store","d":1036396,"h":12885938284,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1036396,"h":4296003692,"f":8}],"h":1036396}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslCertificateTrust`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslClientAuthenticationOptions", ($self) => class SslClientAuthenticationOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AllowRenegotiation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRenegotiation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPkcs1Padding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPkcs1Padding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPssPadding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPssPadding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowTlsResume()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowTlsResume(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ get ApplicationProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ set ApplicationProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ get CertificateChainPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ set CertificateChainPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ get CertificateRevocationCheckMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ set CertificateRevocationCheckMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ get CipherSuitesPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ set CipherSuitesPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ get ClientCertificateContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ set ClientCertificateContext(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection? */ get ClientCertificates()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection? */ set ClientCertificates(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get EnabledSslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ set EnabledSslProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ set EncryptionPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.LocalCertificateSelectionCallback? */ get LocalCertificateSelectionCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.LocalCertificateSelectionCallback? */ set LocalCertificateSelectionCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get RemoteCertificateValidationCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set RemoteCertificateValidationCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetHost()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TargetHost(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1101932;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886003820,"f":1},"s":{"r":0,"d":0,"h":17180971116,"f":1},"n":"AllowRenegotiation","d":1101932,"h":8591036524,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770905708,"f":1},"s":{"r":0,"d":0,"h":30065873004,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPkcs1Padding","d":1101932,"h":21475938412,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655807596,"f":1},"s":{"r":0,"d":0,"h":42950774892,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPssPadding","d":1101932,"h":34360840300,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540709484,"f":1},"s":{"r":0,"d":0,"h":55835676780,"f":1},"n":"AllowTlsResume","d":1101932,"h":47245742188,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":64425611372,"f":1},"s":{"r":0,"d":0,"h":68720578668,"f":1},"n":"ApplicationProtocols","d":1101932,"h":60130644076,"f":1},{"p":29151693,"g":{"r":0,"d":0,"h":77310513260,"f":1},"s":{"r":0,"d":0,"h":81605480556,"f":1},"n":"CertificateChainPolicy","d":1101932,"h":73015545964,"f":1},{"p":30265805,"g":{"r":0,"d":0,"h":90195415148,"f":1},"s":{"r":0,"d":0,"h":94490382444,"f":1},"n":"CertificateRevocationCheckMode","d":1101932,"h":85900447852,"f":1},{"p":184428,"g":{"r":0,"d":0,"h":103080317036,"f":1},"s":{"r":0,"d":0,"h":107375284332,"f":1},"n":"CipherSuitesPolicy","d":1101932,"h":98785349740,"f":1},{"p":1364076,"g":{"r":0,"d":0,"h":115965218924,"f":1},"s":{"r":0,"d":0,"h":120260186220,"f":1},"n":"ClientCertificateContext","d":1101932,"h":111670251628,"f":1},{"p":28430797,"g":{"r":0,"d":0,"h":128850120812,"f":1},"s":{"r":0,"d":0,"h":133145088108,"f":1},"n":"ClientCertificates","d":1101932,"h":124555153516,"f":1},{"p":5612018,"g":{"r":0,"d":0,"h":141735022700,"f":1},"s":{"r":0,"d":0,"h":146029989996,"f":1},"n":"EnabledSslProtocols","d":1101932,"h":137440055404,"f":1},{"p":249964,"g":{"r":0,"d":0,"h":154619924588,"f":1},"s":{"r":0,"d":0,"h":158914891884,"f":1},"n":"EncryptionPolicy","d":1101932,"h":150324957292,"f":1},{"p":315500,"g":{"r":0,"d":0,"h":167504826476,"f":1},"s":{"r":0,"d":0,"h":171799793772,"f":1},"n":"LocalCertificateSelectionCallback","d":1101932,"h":163209859180,"f":1},{"p":774252,"g":{"r":0,"d":0,"h":180389728364,"f":1},"s":{"r":0,"d":0,"h":184684695660,"f":1},"n":"RemoteCertificateValidationCallback","d":1101932,"h":176094761068,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":193274630252,"f":1},"s":{"r":0,"d":0,"h":197569597548,"f":1},"n":"TargetHost","d":1101932,"h":188979662956,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1101932,"h":4296069228,"f":1}],"h":1101932}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslClientAuthenticationOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslServerAuthenticationOptions", ($self) => class SslServerAuthenticationOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AllowRenegotiation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRenegotiation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPkcs1Padding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPkcs1Padding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPssPadding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPssPadding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowTlsResume()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowTlsResume(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ get ApplicationProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ set ApplicationProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ get CertificateChainPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ set CertificateChainPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ get CertificateRevocationCheckMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ set CertificateRevocationCheckMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ get CipherSuitesPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ set CipherSuitesPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ClientCertificateRequired()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ClientCertificateRequired(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get EnabledSslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ set EnabledSslProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ set EncryptionPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get RemoteCertificateValidationCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set RemoteCertificateValidationCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get ServerCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ set ServerCertificate(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ get ServerCertificateContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ set ServerCertificateContext(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ServerCertificateSelectionCallback? */ get ServerCertificateSelectionCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ServerCertificateSelectionCallback? */ set ServerCertificateSelectionCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1233004;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886134892,"f":1},"s":{"r":0,"d":0,"h":17181102188,"f":1},"n":"AllowRenegotiation","d":1233004,"h":8591167596,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25771036780,"f":1},"s":{"r":0,"d":0,"h":30066004076,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPkcs1Padding","d":1233004,"h":21476069484,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655938668,"f":1},"s":{"r":0,"d":0,"h":42950905964,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPssPadding","d":1233004,"h":34360971372,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540840556,"f":1},"s":{"r":0,"d":0,"h":55835807852,"f":1},"n":"AllowTlsResume","d":1233004,"h":47245873260,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":64425742444,"f":1},"s":{"r":0,"d":0,"h":68720709740,"f":1},"n":"ApplicationProtocols","d":1233004,"h":60130775148,"f":1},{"p":29151693,"g":{"r":0,"d":0,"h":77310644332,"f":1},"s":{"r":0,"d":0,"h":81605611628,"f":1},"n":"CertificateChainPolicy","d":1233004,"h":73015677036,"f":1},{"p":30265805,"g":{"r":0,"d":0,"h":90195546220,"f":1},"s":{"r":0,"d":0,"h":94490513516,"f":1},"n":"CertificateRevocationCheckMode","d":1233004,"h":85900578924,"f":1},{"p":184428,"g":{"r":0,"d":0,"h":103080448108,"f":1},"s":{"r":0,"d":0,"h":107375415404,"f":1},"n":"CipherSuitesPolicy","d":1233004,"h":98785480812,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115965349996,"f":1},"s":{"r":0,"d":0,"h":120260317292,"f":1},"n":"ClientCertificateRequired","d":1233004,"h":111670382700,"f":1},{"p":5612018,"g":{"r":0,"d":0,"h":128850251884,"f":1},"s":{"r":0,"d":0,"h":133145219180,"f":1},"n":"EnabledSslProtocols","d":1233004,"h":124555284588,"f":1},{"p":249964,"g":{"r":0,"d":0,"h":141735153772,"f":1},"s":{"r":0,"d":0,"h":146030121068,"f":1},"n":"EncryptionPolicy","d":1233004,"h":137440186476,"f":1},{"p":774252,"g":{"r":0,"d":0,"h":154620055660,"f":1},"s":{"r":0,"d":0,"h":158915022956,"f":1},"n":"RemoteCertificateValidationCallback","d":1233004,"h":150325088364,"f":1},{"p":28168653,"g":{"r":0,"d":0,"h":167504957548,"f":1},"s":{"r":0,"d":0,"h":171799924844,"f":1},"n":"ServerCertificate","d":1233004,"h":163209990252,"f":1},{"p":1364076,"g":{"r":0,"d":0,"h":180389859436,"f":1},"s":{"r":0,"d":0,"h":184684826732,"f":1},"n":"ServerCertificateContext","d":1233004,"h":176094892140,"f":1},{"p":839788,"g":{"r":0,"d":0,"h":193274761324,"f":1},"s":{"r":0,"d":0,"h":197569728620,"f":1},"n":"ServerCertificateSelectionCallback","d":1233004,"h":188979794028,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1233004,"h":4296200300,"f":1}],"h":1233004}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslServerAuthenticationOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslStreamCertificateContext", ($self) => class SslStreamCertificateContext extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.ObjectModel.ReadOnlyCollection<System.Security.Cryptography.X509Certificates.X509Certificate2> */ get IntermediateCertificates()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate2 */ get TargetCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslStreamCertificateContext */ Create(/*System.Security.Cryptography.X509Certificates.X509Certificate2*/ target, /*System.Security.Cryptography.X509Certificates.X509Certificate2Collection?*/ additionalCertificates, /*bool*/ offline)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslStreamCertificateContext */ Create$1(/*System.Security.Cryptography.X509Certificates.X509Certificate2*/ target, /*System.Security.Cryptography.X509Certificates.X509Certificate2Collection?*/ additionalCertificates, /*bool*/ offline, /*System.Net.Security.SslCertificateTrust?*/ trust)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1364076;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sscr.System.Security.Cryptography.X509Certificates.X509Certificate2).$h,"g":{"r":0,"d":0,"h":12886265964,"f":1},"n":"IntermediateCertificates","d":1364076,"h":8591298668,"f":1},{"p":28234189,"g":{"r":0,"d":0,"h":21476200556,"f":1},"n":"TargetCertificate","d":1364076,"h":17181233260,"f":1}],"m":[{"r":1364076,"p":[{"n":"target","p":28234189},{"n":"additionalCertificates","p":28299725},{"n":"offline","p":262145}],"n":"Create","d":1364076,"h":25771167852,"f":33,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]}]},{"r":1364076,"p":[{"n":"target","p":28234189},{"n":"additionalCertificates","p":28299725},{"n":"offline","p":262145,"f":65,"v":false},{"n":"trust","p":1036396,"f":65}],"n":"Create","o":"@$1","d":1364076,"h":30066135148,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1364076,"h":4296331372,"f":8}],"h":1364076}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslStreamCertificateContext`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthentication", ($self) => class NegotiateAuthentication extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.Security.NegotiateAuthenticationClientOptions*/ clientOptions)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.Security.NegotiateAuthenticationServerOptions*/ serverOptions)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get ProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get RemoteIdentity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ ComputeIntegrityCheck(/*System.ReadOnlySpan<byte>*/ message, /*System.Buffers.IBufferWriter<byte>*/ signatureWriter)
            {
            }
            /*void */ Dispose()
            {
            }
            /*byte[]? */ GetOutgoingBlob(/*System.ReadOnlySpan<byte>*/ incomingBlob, /*out System.Net.Security.NegotiateAuthenticationStatusCode*/ statusCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ GetOutgoingBlob$1(/*string?*/ incomingBlob, /*out System.Net.Security.NegotiateAuthenticationStatusCode*/ statusCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ Unwrap(/*System.ReadOnlySpan<byte>*/ input, /*System.Buffers.IBufferWriter<byte>*/ outputWriter, /*out bool*/ wasEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ UnwrapInPlace(/*System.Span<byte>*/ input, /*out int*/ unwrappedOffset, /*out int*/ unwrappedLength, /*out bool*/ wasEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ VerifyIntegrityCheck(/*System.ReadOnlySpan<byte>*/ message, /*System.ReadOnlySpan<byte>*/ signature)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ Wrap(/*System.ReadOnlySpan<byte>*/ input, /*System.Buffers.IBufferWriter<byte>*/ outputWriter, /*bool*/ requestEncryption, /*out bool*/ isEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 381036;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":117243905,"g":{"r":0,"d":0,"h":17180250220,"f":1},"n":"ImpersonationLevel","d":381036,"h":12885282924,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770184812,"f":1},"n":"IsAuthenticated","d":381036,"h":21475217516,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360119404,"f":1},"n":"IsEncrypted","d":381036,"h":30065152108,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950053996,"f":1},"n":"IsMutuallyAuthenticated","d":381036,"h":38655086700,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51539988588,"f":1},"n":"IsServer","d":381036,"h":47245021292,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60129923180,"f":1},"n":"IsSigned","d":381036,"h":55834955884,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":68719857772,"f":1},"n":"Package","d":381036,"h":64424890476,"f":1},{"p":708716,"g":{"r":0,"d":0,"h":77309792364,"f":1},"n":"ProtectionLevel","d":381036,"h":73014825068,"f":1},{"p":117047297,"g":{"r":0,"d":0,"h":85899726956,"f":1},"n":"RemoteIdentity","d":381036,"h":81604759660,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":94489661548,"f":1},"n":"TargetName","d":381036,"h":90194694252,"f":1}],"m":[{"r":65537,"p":[{"n":"message","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"signatureWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h}],"n":"ComputeIntegrityCheck","d":381036,"h":98784628844,"f":1},{"r":65537,"n":"Dispose","d":381036,"h":103079596140,"f":1},{"r":0,"p":[{"n":"incomingBlob","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"statusCode","p":577644,"f":2}],"n":"GetOutgoingBlob","d":381036,"h":107374563436,"f":1},{"r":1310721,"p":[{"n":"incomingBlob","p":1310721},{"n":"statusCode","p":577644,"f":2}],"n":"GetOutgoingBlob","o":"@$1","d":381036,"h":111669530732,"f":1},{"r":577644,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"outputWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h},{"n":"wasEncrypted","p":262145,"f":2}],"n":"Unwrap","d":381036,"h":115964498028,"f":1},{"r":577644,"p":[{"n":"input","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"unwrappedOffset","p":655361,"f":2},{"n":"unwrappedLength","p":655361,"f":2},{"n":"wasEncrypted","p":262145,"f":2}],"n":"UnwrapInPlace","d":381036,"h":120259465324,"f":1},{"r":262145,"p":[{"n":"message","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"signature","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"VerifyIntegrityCheck","d":381036,"h":124554432620,"f":1},{"r":577644,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"outputWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h},{"n":"requestEncryption","p":262145},{"n":"isEncrypted","p":262145,"f":2}],"n":"Wrap","d":381036,"h":128849399916,"f":1}],"c":[{"p":[{"n":"clientOptions","p":446572}],"n":".ctor","o":"$ctor$1","d":381036,"h":4295348332,"f":1},{"p":[{"n":"serverOptions","p":512108}],"n":".ctor","o":"$ctor$2","d":381036,"h":8590315628,"f":1}],"i":[57540609],"h":381036}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthentication`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy", ($self) => class ExtendedProtectionPolicy extends $.$spc.System.Object
        {
            $ctor$1(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ChannelBinding*/ customChannelBinding)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ProtectionScenario*/ protectionScenario, /*System.Collections.ICollection?*/ customServiceNames)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ProtectionScenario*/ protectionScenario, /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection?*/ customServiceNames)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get CustomChannelBinding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection? */ get CustomServiceNames()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsExtendedProtection()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.PolicyEnforcement */ get PolicyEnforcement()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ProtectionScenario */ get ProtectionScenario()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo?*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snsc.System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy.ToString.apply(this, arguments); }
            static $h = 1560684;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5415410,"g":{"r":0,"d":0,"h":30066331756,"f":1},"n":"CustomChannelBinding","d":1560684,"h":25771364460,"f":1},{"p":1757292,"g":{"r":0,"d":0,"h":38656266348,"f":1},"n":"CustomServiceNames","d":1560684,"h":34361299052,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47246200940,"f":33},"n":"OSSupportsExtendedProtection","d":1560684,"h":42951233644,"f":33},{"p":1626220,"g":{"r":0,"d":0,"h":55836135532,"f":1},"n":"PolicyEnforcement","d":1560684,"h":51541168236,"f":1},{"p":1691756,"g":{"r":0,"d":0,"h":64426070124,"f":1},"n":"ProtectionScenario","d":1560684,"h":60131102828,"f":1}],"m":[{"r":1310721,"n":"ToString","d":1560684,"h":73016004716,"f":32769}],"c":[{"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$1","d":1560684,"h":4296527980,"f":4,"a":[{"t":33226753,"c":4328194049,"a":[{"v":1,"t":33292289}]},{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":[{"n":"policyEnforcement","p":1626220}],"n":".ctor","o":"$ctor$2","d":1560684,"h":8591495276,"f":1},{"p":[{"n":"policyEnforcement","p":1626220},{"n":"customChannelBinding","p":5415410}],"n":".ctor","o":"$ctor$3","d":1560684,"h":12886462572,"f":1},{"p":[{"n":"policyEnforcement","p":1626220},{"n":"protectionScenario","p":1691756},{"n":"customServiceNames","p":31391745}],"n":".ctor","o":"$ctor$4","d":1560684,"h":17181429868,"f":1},{"p":[{"n":"policyEnforcement","p":1626220},{"n":"protectionScenario","p":1691756},{"n":"customServiceNames","p":1757292}],"n":".ctor","o":"$ctor$5","d":1560684,"h":21476397164,"f":1}],"i":[113377281],"h":1560684}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.SslClientHelloInfo", ($self) => class SslClientHelloInfo extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            $ctor$2(/*string*/ serverName, /*System.Security.Authentication.SslProtocols*/ sslProtocols)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*string */ get ServerName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 1167468;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21476003948,"f":1},"n":"ServerName","d":1167468,"h":17181036652,"f":1},{"p":5612018,"g":{"r":0,"d":0,"h":30065938540,"f":1},"n":"SslProtocols","d":1167468,"h":25770971244,"f":1}],"l":[{"t":131073,"n":"_dummy","d":1167468,"h":4296134764,"f":2},{"t":655361,"n":"_dummyPrimitive","d":1167468,"h":8591102060,"f":2}],"c":[{"p":[{"n":"serverName","p":1310721},{"n":"sslProtocols","p":5612018}],"n":".ctor","o":"$ctor$2","d":1167468,"h":12886069356,"f":1},{"n":".ctor","o":"$ctor$3","d":1167468,"h":34360905836,"f":1}],"h":1167468}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Security.SslClientHelloInfo`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.SslApplicationProtocol", ($self) => class SslApplicationProtocol extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.Security.SslApplicationProtocol*/ static Http11;
            /*System.Net.Security.SslApplicationProtocol*/ static Http2;
            /*System.Net.Security.SslApplicationProtocol*/ static Http3;
            $ctor$2(/*byte[]*/ protocol)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            $ctor$3(/*string*/ protocol)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*System.ReadOnlyMemory<byte> */ get Protocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Security.SslApplicationProtocol*/ other)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snsc.System.Net.Security.SslApplicationProtocol.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snsc.System.Net.Security.SslApplicationProtocol.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Security.SslApplicationProtocol*/ left, /*System.Net.Security.SslApplicationProtocol*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Security.SslApplicationProtocol*/ left, /*System.Net.Security.SslApplicationProtocol*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snsc.System.Net.Security.SslApplicationProtocol.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Net.Security.SslApplicationProtocol>.Equals(System.Net.Security.SslApplicationProtocol)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Http11 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
                {
                    this.Http2 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
                {
                    this.Http3 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
            }
            static $h = 970860;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":38655676524,"f":1},"n":"Protocol","d":970860,"h":34360709228,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":970860}],"n":"Equals","o":"@$2","d":970860,"h":42950643820,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":970860,"h":47245611116,"f":32769},{"r":655361,"n":"GetHashCode","d":970860,"h":51540578412,"f":32769},{"r":1310721,"n":"ToString","d":970860,"h":64425480300,"f":32769}],"l":[{"t":131073,"n":"_dummy","d":970860,"h":4295938156,"f":2},{"t":655361,"n":"_dummyPrimitive","d":970860,"h":8590905452,"f":2},{"t":970860,"n":"Http11","d":970860,"h":12885872748,"f":33},{"t":970860,"n":"Http2","d":970860,"h":17180840044,"f":33},{"t":970860,"n":"Http3","d":970860,"h":21475807340,"f":33}],"c":[{"p":[{"n":"protocol","p":0}],"n":".ctor","o":"$ctor$2","d":970860,"h":25770774636,"f":1},{"p":[{"n":"protocol","p":1310721}],"n":".ctor","o":"$ctor$3","d":970860,"h":30065741932,"f":1},{"n":".ctor","o":"$ctor$4","d":970860,"h":68720447596,"f":1}],"i":[$.$spc.System.IEquatable$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h],"h":970860}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$snsc.System.Net.Security.SslApplicationProtocol) ]; }
            static get $fullName() { return `System.Net.Security.SslApplicationProtocol`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.ExtendedProtection.ServiceNameCollection", ($self) => class ServiceNameCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2(/*System.Collections.ICollection*/ items)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ Contains(/*string?*/ searchServiceName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection */ Merge(/*System.Collections.IEnumerable*/ serviceNames)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection */ Merge$1(/*string*/ serviceName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1757292;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"m":[{"r":262145,"p":[{"n":"searchServiceName","p":1310721}],"n":"Contains","d":1757292,"h":8591691884,"f":1},{"r":1757292,"p":[{"n":"serviceNames","p":31653889}],"n":"Merge","d":1757292,"h":12886659180,"f":1},{"r":1757292,"p":[{"n":"serviceName","p":1310721}],"n":"Merge","o":"@$1","d":1757292,"h":17181626476,"f":1}],"c":[{"p":[{"n":"items","p":31391745}],"n":".ctor","o":"$ctor$2","d":1757292,"h":4296724588,"f":1}],"i":[31391745,31653889],"h":1757292}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ServiceNameCollection`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.LocalCertificateSelectionCallback", ($self) => class LocalCertificateSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate?*/ Invoke(/*$.$spc.System.Object*/ sender, /*$.$spc.System.String*/ targetHost, /*$.$sscr.System.Security.Cryptography.X509Certificates.X509CertificateCollection*/ localCertificates, /*$.$spc.System.Nullable$$*/ remoteCertificate, /**/ acceptableIssuers)
            {
                return this.$nativeFunction.call(this.$target, sender, targetHost, localCertificates, remoteCertificate, acceptableIssuers);
            }
            static $h = 315500;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":28168653,"p":[{"n":"sender","p":131073},{"n":"targetHost","p":1310721},{"n":"localCertificates","p":28430797},{"n":"remoteCertificate","p":28168653},{"n":"acceptableIssuers","p":0}],"n":"Invoke","d":315500,"h":8590250092,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"targetHost","p":1310721},{"n":"localCertificates","p":28430797},{"n":"remoteCertificate","p":28168653},{"n":"acceptableIssuers","p":0},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":315500,"h":12885217388,"f":129},{"r":28168653,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":315500,"h":17180184684,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":315500,"h":4295282796,"f":1}],"i":[57212929,113377281],"h":315500}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.LocalCertificateSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.RemoteCertificateValidationCallback", ($self) => class RemoteCertificateValidationCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*bool*/ Invoke(/*$.$spc.System.Object*/ sender, /*$.$spc.System.Nullable$$*/ certificate, /*$.$spc.System.Nullable$$*/ chain, /*$.$snp.System.Net.Security.SslPolicyErrors*/ sslPolicyErrors)
            {
                return this.$nativeFunction.call(this.$target, sender, certificate, chain, sslPolicyErrors);
            }
            static $h = 774252;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":262145,"p":[{"n":"sender","p":131073},{"n":"certificate","p":28168653},{"n":"chain","p":28889549},{"n":"sslPolicyErrors","p":4301298}],"n":"Invoke","d":774252,"h":8590708844,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"certificate","p":28168653},{"n":"chain","p":28889549},{"n":"sslPolicyErrors","p":4301298},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":774252,"h":12885676140,"f":129},{"r":262145,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":774252,"h":17180643436,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":774252,"h":4295741548,"f":1}],"i":[57212929,113377281],"h":774252}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.RemoteCertificateValidationCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.ServerCertificateSelectionCallback", ($self) => class ServerCertificateSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate*/ Invoke(/*$.$spc.System.Object*/ sender, /*$.$spc.System.Nullable$$*/ hostName)
            {
                return this.$nativeFunction.call(this.$target, sender, hostName);
            }
            static $h = 839788;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":28168653,"p":[{"n":"sender","p":131073},{"n":"hostName","p":1310721}],"n":"Invoke","d":839788,"h":8590774380,"f":129},{"r":57016321,"p":[{"n":"sender","p":131073},{"n":"hostName","p":1310721},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":839788,"h":12885741676,"f":129},{"r":28168653,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":839788,"h":17180708972,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":839788,"h":4295807084,"f":1}],"i":[57212929,113377281],"h":839788}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.ServerCertificateSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.ServerOptionsSelectionCallback", ($self) => class ServerOptionsSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn, anmodel)
            {
                this.$target = target;
                this.$nativeFunction = fn;
                if (anmodel) this.$nfmodel = anmodel;
                if (typeof(target) === 'object') this._target = target;
                return this;
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Security.SslServerAuthenticationOptions>*/ Invoke(/*$.$snsc.System.Net.Security.SslStream*/ stream, /*$.$snsc.System.Net.Security.SslClientHelloInfo*/ clientHelloInfo, /*$.$spc.System.Nullable$$*/ state, /*$.$spc.System.Threading.CancellationToken*/ cancellationToken)
            {
                return this.$nativeFunction.call(this.$target, stream, clientHelloInfo, state, cancellationToken);
            }
            static $h = 905324;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snsc.System.Net.Security.SslServerAuthenticationOptions).$h,"p":[{"n":"stream","p":1298540},{"n":"clientHelloInfo","p":1167468},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193}],"n":"Invoke","d":905324,"h":8590839916,"f":129},{"r":57016321,"p":[{"n":"stream","p":1298540},{"n":"clientHelloInfo","p":1167468},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193},{"n":"callback","p":14483457},{"n":"object","p":131073}],"n":"BeginInvoke","d":905324,"h":12885807212,"f":129},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snsc.System.Net.Security.SslServerAuthenticationOptions).$h,"p":[{"n":"result","p":57016321}],"n":"EndInvoke","d":905324,"h":17180774508,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":905324,"h":4295872620,"f":1}],"i":[57212929,113377281],"h":905324}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.ServerOptionsSelectionCallback`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.EncryptionPolicy", ($self) => class EncryptionPolicy extends $.$spc.System.Enum
        {
            static RequireEncryption = 0;
            static AllowNoEncryption = 1;
            static NoEncryption = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "RequireEncryption": 0n,
                    "AllowNoEncryption": 1n,
                    "NoEncryption": 2n
                };
            }
            static $h = 249964;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":249964,"n":"RequireEncryption","d":249964,"h":4295217260,"f":33},{"t":249964,"n":"AllowNoEncryption","d":249964,"h":8590184556,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0040","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"t":249964,"n":"NoEncryption","d":249964,"h":12885151852,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0040","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":249964,"h":17180119148,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":249964}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.EncryptionPolicy`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.NegotiateAuthenticationStatusCode", ($self) => class NegotiateAuthenticationStatusCode extends $.$spc.System.Enum
        {
            static Completed = 0;
            static ContinueNeeded = 1;
            static GenericFailure = 2;
            static BadBinding = 3;
            static Unsupported = 4;
            static MessageAltered = 5;
            static ContextExpired = 6;
            static CredentialsExpired = 7;
            static InvalidCredentials = 8;
            static InvalidToken = 9;
            static UnknownCredentials = 10;
            static QopNotSupported = 11;
            static OutOfSequence = 12;
            static SecurityQosFailed = 13;
            static TargetUnknown = 14;
            static ImpersonationValidationFailed = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Completed": 0n,
                    "ContinueNeeded": 1n,
                    "GenericFailure": 2n,
                    "BadBinding": 3n,
                    "Unsupported": 4n,
                    "MessageAltered": 5n,
                    "ContextExpired": 6n,
                    "CredentialsExpired": 7n,
                    "InvalidCredentials": 8n,
                    "InvalidToken": 9n,
                    "UnknownCredentials": 10n,
                    "QopNotSupported": 11n,
                    "OutOfSequence": 12n,
                    "SecurityQosFailed": 13n,
                    "TargetUnknown": 14n,
                    "ImpersonationValidationFailed": 15n
                };
            }
            static $h = 577644;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":577644,"n":"Completed","d":577644,"h":4295544940,"f":33},{"t":577644,"n":"ContinueNeeded","d":577644,"h":8590512236,"f":33},{"t":577644,"n":"GenericFailure","d":577644,"h":12885479532,"f":33},{"t":577644,"n":"BadBinding","d":577644,"h":17180446828,"f":33},{"t":577644,"n":"Unsupported","d":577644,"h":21475414124,"f":33},{"t":577644,"n":"MessageAltered","d":577644,"h":25770381420,"f":33},{"t":577644,"n":"ContextExpired","d":577644,"h":30065348716,"f":33},{"t":577644,"n":"CredentialsExpired","d":577644,"h":34360316012,"f":33},{"t":577644,"n":"InvalidCredentials","d":577644,"h":38655283308,"f":33},{"t":577644,"n":"InvalidToken","d":577644,"h":42950250604,"f":33},{"t":577644,"n":"UnknownCredentials","d":577644,"h":47245217900,"f":33},{"t":577644,"n":"QopNotSupported","d":577644,"h":51540185196,"f":33},{"t":577644,"n":"OutOfSequence","d":577644,"h":55835152492,"f":33},{"t":577644,"n":"SecurityQosFailed","d":577644,"h":60130119788,"f":33},{"t":577644,"n":"TargetUnknown","d":577644,"h":64425087084,"f":33},{"t":577644,"n":"ImpersonationValidationFailed","d":577644,"h":68720054380,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":577644,"h":73015021676,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":577644}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationStatusCode`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.ProtectionLevel", ($self) => class ProtectionLevel extends $.$spc.System.Enum
        {
            static None = 0;
            static Sign = 1;
            static EncryptAndSign = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Sign": 1n,
                    "EncryptAndSign": 2n
                };
            }
            static $h = 708716;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":708716,"n":"None","d":708716,"h":4295676012,"f":33},{"t":708716,"n":"Sign","d":708716,"h":8590643308,"f":33},{"t":708716,"n":"EncryptAndSign","d":708716,"h":12885610604,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":708716,"h":17180577900,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":708716}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.ProtectionLevel`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.TlsCipherSuite", ($self) => class TlsCipherSuite extends $.$spc.System.Enum
        {
            static TLS_NULL_WITH_NULL_NULL = 0;
            static TLS_RSA_WITH_NULL_MD5 = 1;
            static TLS_RSA_WITH_NULL_SHA = 2;
            static TLS_RSA_EXPORT_WITH_RC4_40_MD5 = 3;
            static TLS_RSA_WITH_RC4_128_MD5 = 4;
            static TLS_RSA_WITH_RC4_128_SHA = 5;
            static TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5 = 6;
            static TLS_RSA_WITH_IDEA_CBC_SHA = 7;
            static TLS_RSA_EXPORT_WITH_DES40_CBC_SHA = 8;
            static TLS_RSA_WITH_DES_CBC_SHA = 9;
            static TLS_RSA_WITH_3DES_EDE_CBC_SHA = 10;
            static TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA = 11;
            static TLS_DH_DSS_WITH_DES_CBC_SHA = 12;
            static TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA = 13;
            static TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA = 14;
            static TLS_DH_RSA_WITH_DES_CBC_SHA = 15;
            static TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA = 16;
            static TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA = 17;
            static TLS_DHE_DSS_WITH_DES_CBC_SHA = 18;
            static TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA = 19;
            static TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA = 20;
            static TLS_DHE_RSA_WITH_DES_CBC_SHA = 21;
            static TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA = 22;
            static TLS_DH_anon_EXPORT_WITH_RC4_40_MD5 = 23;
            static TLS_DH_anon_WITH_RC4_128_MD5 = 24;
            static TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA = 25;
            static TLS_DH_anon_WITH_DES_CBC_SHA = 26;
            static TLS_DH_anon_WITH_3DES_EDE_CBC_SHA = 27;
            static TLS_KRB5_WITH_DES_CBC_SHA = 30;
            static TLS_KRB5_WITH_3DES_EDE_CBC_SHA = 31;
            static TLS_KRB5_WITH_RC4_128_SHA = 32;
            static TLS_KRB5_WITH_IDEA_CBC_SHA = 33;
            static TLS_KRB5_WITH_DES_CBC_MD5 = 34;
            static TLS_KRB5_WITH_3DES_EDE_CBC_MD5 = 35;
            static TLS_KRB5_WITH_RC4_128_MD5 = 36;
            static TLS_KRB5_WITH_IDEA_CBC_MD5 = 37;
            static TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA = 38;
            static TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA = 39;
            static TLS_KRB5_EXPORT_WITH_RC4_40_SHA = 40;
            static TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5 = 41;
            static TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5 = 42;
            static TLS_KRB5_EXPORT_WITH_RC4_40_MD5 = 43;
            static TLS_PSK_WITH_NULL_SHA = 44;
            static TLS_DHE_PSK_WITH_NULL_SHA = 45;
            static TLS_RSA_PSK_WITH_NULL_SHA = 46;
            static TLS_RSA_WITH_AES_128_CBC_SHA = 47;
            static TLS_DH_DSS_WITH_AES_128_CBC_SHA = 48;
            static TLS_DH_RSA_WITH_AES_128_CBC_SHA = 49;
            static TLS_DHE_DSS_WITH_AES_128_CBC_SHA = 50;
            static TLS_DHE_RSA_WITH_AES_128_CBC_SHA = 51;
            static TLS_DH_anon_WITH_AES_128_CBC_SHA = 52;
            static TLS_RSA_WITH_AES_256_CBC_SHA = 53;
            static TLS_DH_DSS_WITH_AES_256_CBC_SHA = 54;
            static TLS_DH_RSA_WITH_AES_256_CBC_SHA = 55;
            static TLS_DHE_DSS_WITH_AES_256_CBC_SHA = 56;
            static TLS_DHE_RSA_WITH_AES_256_CBC_SHA = 57;
            static TLS_DH_anon_WITH_AES_256_CBC_SHA = 58;
            static TLS_RSA_WITH_NULL_SHA256 = 59;
            static TLS_RSA_WITH_AES_128_CBC_SHA256 = 60;
            static TLS_RSA_WITH_AES_256_CBC_SHA256 = 61;
            static TLS_DH_DSS_WITH_AES_128_CBC_SHA256 = 62;
            static TLS_DH_RSA_WITH_AES_128_CBC_SHA256 = 63;
            static TLS_DHE_DSS_WITH_AES_128_CBC_SHA256 = 64;
            static TLS_RSA_WITH_CAMELLIA_128_CBC_SHA = 65;
            static TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA = 66;
            static TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA = 67;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA = 68;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA = 69;
            static TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA = 70;
            static TLS_DHE_RSA_WITH_AES_128_CBC_SHA256 = 103;
            static TLS_DH_DSS_WITH_AES_256_CBC_SHA256 = 104;
            static TLS_DH_RSA_WITH_AES_256_CBC_SHA256 = 105;
            static TLS_DHE_DSS_WITH_AES_256_CBC_SHA256 = 106;
            static TLS_DHE_RSA_WITH_AES_256_CBC_SHA256 = 107;
            static TLS_DH_anon_WITH_AES_128_CBC_SHA256 = 108;
            static TLS_DH_anon_WITH_AES_256_CBC_SHA256 = 109;
            static TLS_RSA_WITH_CAMELLIA_256_CBC_SHA = 132;
            static TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA = 133;
            static TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA = 134;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA = 135;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA = 136;
            static TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA = 137;
            static TLS_PSK_WITH_RC4_128_SHA = 138;
            static TLS_PSK_WITH_3DES_EDE_CBC_SHA = 139;
            static TLS_PSK_WITH_AES_128_CBC_SHA = 140;
            static TLS_PSK_WITH_AES_256_CBC_SHA = 141;
            static TLS_DHE_PSK_WITH_RC4_128_SHA = 142;
            static TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA = 143;
            static TLS_DHE_PSK_WITH_AES_128_CBC_SHA = 144;
            static TLS_DHE_PSK_WITH_AES_256_CBC_SHA = 145;
            static TLS_RSA_PSK_WITH_RC4_128_SHA = 146;
            static TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA = 147;
            static TLS_RSA_PSK_WITH_AES_128_CBC_SHA = 148;
            static TLS_RSA_PSK_WITH_AES_256_CBC_SHA = 149;
            static TLS_RSA_WITH_SEED_CBC_SHA = 150;
            static TLS_DH_DSS_WITH_SEED_CBC_SHA = 151;
            static TLS_DH_RSA_WITH_SEED_CBC_SHA = 152;
            static TLS_DHE_DSS_WITH_SEED_CBC_SHA = 153;
            static TLS_DHE_RSA_WITH_SEED_CBC_SHA = 154;
            static TLS_DH_anon_WITH_SEED_CBC_SHA = 155;
            static TLS_RSA_WITH_AES_128_GCM_SHA256 = 156;
            static TLS_RSA_WITH_AES_256_GCM_SHA384 = 157;
            static TLS_DHE_RSA_WITH_AES_128_GCM_SHA256 = 158;
            static TLS_DHE_RSA_WITH_AES_256_GCM_SHA384 = 159;
            static TLS_DH_RSA_WITH_AES_128_GCM_SHA256 = 160;
            static TLS_DH_RSA_WITH_AES_256_GCM_SHA384 = 161;
            static TLS_DHE_DSS_WITH_AES_128_GCM_SHA256 = 162;
            static TLS_DHE_DSS_WITH_AES_256_GCM_SHA384 = 163;
            static TLS_DH_DSS_WITH_AES_128_GCM_SHA256 = 164;
            static TLS_DH_DSS_WITH_AES_256_GCM_SHA384 = 165;
            static TLS_DH_anon_WITH_AES_128_GCM_SHA256 = 166;
            static TLS_DH_anon_WITH_AES_256_GCM_SHA384 = 167;
            static TLS_PSK_WITH_AES_128_GCM_SHA256 = 168;
            static TLS_PSK_WITH_AES_256_GCM_SHA384 = 169;
            static TLS_DHE_PSK_WITH_AES_128_GCM_SHA256 = 170;
            static TLS_DHE_PSK_WITH_AES_256_GCM_SHA384 = 171;
            static TLS_RSA_PSK_WITH_AES_128_GCM_SHA256 = 172;
            static TLS_RSA_PSK_WITH_AES_256_GCM_SHA384 = 173;
            static TLS_PSK_WITH_AES_128_CBC_SHA256 = 174;
            static TLS_PSK_WITH_AES_256_CBC_SHA384 = 175;
            static TLS_PSK_WITH_NULL_SHA256 = 176;
            static TLS_PSK_WITH_NULL_SHA384 = 177;
            static TLS_DHE_PSK_WITH_AES_128_CBC_SHA256 = 178;
            static TLS_DHE_PSK_WITH_AES_256_CBC_SHA384 = 179;
            static TLS_DHE_PSK_WITH_NULL_SHA256 = 180;
            static TLS_DHE_PSK_WITH_NULL_SHA384 = 181;
            static TLS_RSA_PSK_WITH_AES_128_CBC_SHA256 = 182;
            static TLS_RSA_PSK_WITH_AES_256_CBC_SHA384 = 183;
            static TLS_RSA_PSK_WITH_NULL_SHA256 = 184;
            static TLS_RSA_PSK_WITH_NULL_SHA384 = 185;
            static TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 186;
            static TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256 = 187;
            static TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 188;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256 = 189;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 190;
            static TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256 = 191;
            static TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 192;
            static TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256 = 193;
            static TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 194;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256 = 195;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 196;
            static TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256 = 197;
            static TLS_AES_128_GCM_SHA256 = 4865;
            static TLS_AES_256_GCM_SHA384 = 4866;
            static TLS_CHACHA20_POLY1305_SHA256 = 4867;
            static TLS_AES_128_CCM_SHA256 = 4868;
            static TLS_AES_128_CCM_8_SHA256 = 4869;
            static TLS_ECDH_ECDSA_WITH_NULL_SHA = 49153;
            static TLS_ECDH_ECDSA_WITH_RC4_128_SHA = 49154;
            static TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA = 49155;
            static TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA = 49156;
            static TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA = 49157;
            static TLS_ECDHE_ECDSA_WITH_NULL_SHA = 49158;
            static TLS_ECDHE_ECDSA_WITH_RC4_128_SHA = 49159;
            static TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA = 49160;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA = 49161;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA = 49162;
            static TLS_ECDH_RSA_WITH_NULL_SHA = 49163;
            static TLS_ECDH_RSA_WITH_RC4_128_SHA = 49164;
            static TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA = 49165;
            static TLS_ECDH_RSA_WITH_AES_128_CBC_SHA = 49166;
            static TLS_ECDH_RSA_WITH_AES_256_CBC_SHA = 49167;
            static TLS_ECDHE_RSA_WITH_NULL_SHA = 49168;
            static TLS_ECDHE_RSA_WITH_RC4_128_SHA = 49169;
            static TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA = 49170;
            static TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA = 49171;
            static TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA = 49172;
            static TLS_ECDH_anon_WITH_NULL_SHA = 49173;
            static TLS_ECDH_anon_WITH_RC4_128_SHA = 49174;
            static TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA = 49175;
            static TLS_ECDH_anon_WITH_AES_128_CBC_SHA = 49176;
            static TLS_ECDH_anon_WITH_AES_256_CBC_SHA = 49177;
            static TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA = 49178;
            static TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA = 49179;
            static TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA = 49180;
            static TLS_SRP_SHA_WITH_AES_128_CBC_SHA = 49181;
            static TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA = 49182;
            static TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA = 49183;
            static TLS_SRP_SHA_WITH_AES_256_CBC_SHA = 49184;
            static TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA = 49185;
            static TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA = 49186;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256 = 49187;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384 = 49188;
            static TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256 = 49189;
            static TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384 = 49190;
            static TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256 = 49191;
            static TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384 = 49192;
            static TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256 = 49193;
            static TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384 = 49194;
            static TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256 = 49195;
            static TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384 = 49196;
            static TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256 = 49197;
            static TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384 = 49198;
            static TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 = 49199;
            static TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 = 49200;
            static TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256 = 49201;
            static TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384 = 49202;
            static TLS_ECDHE_PSK_WITH_RC4_128_SHA = 49203;
            static TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA = 49204;
            static TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA = 49205;
            static TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA = 49206;
            static TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256 = 49207;
            static TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384 = 49208;
            static TLS_ECDHE_PSK_WITH_NULL_SHA = 49209;
            static TLS_ECDHE_PSK_WITH_NULL_SHA256 = 49210;
            static TLS_ECDHE_PSK_WITH_NULL_SHA384 = 49211;
            static TLS_RSA_WITH_ARIA_128_CBC_SHA256 = 49212;
            static TLS_RSA_WITH_ARIA_256_CBC_SHA384 = 49213;
            static TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256 = 49214;
            static TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384 = 49215;
            static TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256 = 49216;
            static TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384 = 49217;
            static TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256 = 49218;
            static TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384 = 49219;
            static TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256 = 49220;
            static TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384 = 49221;
            static TLS_DH_anon_WITH_ARIA_128_CBC_SHA256 = 49222;
            static TLS_DH_anon_WITH_ARIA_256_CBC_SHA384 = 49223;
            static TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256 = 49224;
            static TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384 = 49225;
            static TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256 = 49226;
            static TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384 = 49227;
            static TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256 = 49228;
            static TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384 = 49229;
            static TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256 = 49230;
            static TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384 = 49231;
            static TLS_RSA_WITH_ARIA_128_GCM_SHA256 = 49232;
            static TLS_RSA_WITH_ARIA_256_GCM_SHA384 = 49233;
            static TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256 = 49234;
            static TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384 = 49235;
            static TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256 = 49236;
            static TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384 = 49237;
            static TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256 = 49238;
            static TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384 = 49239;
            static TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256 = 49240;
            static TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384 = 49241;
            static TLS_DH_anon_WITH_ARIA_128_GCM_SHA256 = 49242;
            static TLS_DH_anon_WITH_ARIA_256_GCM_SHA384 = 49243;
            static TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256 = 49244;
            static TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384 = 49245;
            static TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256 = 49246;
            static TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384 = 49247;
            static TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256 = 49248;
            static TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384 = 49249;
            static TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256 = 49250;
            static TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384 = 49251;
            static TLS_PSK_WITH_ARIA_128_CBC_SHA256 = 49252;
            static TLS_PSK_WITH_ARIA_256_CBC_SHA384 = 49253;
            static TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256 = 49254;
            static TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384 = 49255;
            static TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256 = 49256;
            static TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384 = 49257;
            static TLS_PSK_WITH_ARIA_128_GCM_SHA256 = 49258;
            static TLS_PSK_WITH_ARIA_256_GCM_SHA384 = 49259;
            static TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256 = 49260;
            static TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384 = 49261;
            static TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256 = 49262;
            static TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384 = 49263;
            static TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256 = 49264;
            static TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384 = 49265;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 = 49266;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 = 49267;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 = 49268;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 = 49269;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 49270;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384 = 49271;
            static TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 49272;
            static TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384 = 49273;
            static TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49274;
            static TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49275;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49276;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49277;
            static TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49278;
            static TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49279;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256 = 49280;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384 = 49281;
            static TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256 = 49282;
            static TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384 = 49283;
            static TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256 = 49284;
            static TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384 = 49285;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 = 49286;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 = 49287;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 = 49288;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 = 49289;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49290;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49291;
            static TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49292;
            static TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49293;
            static TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49294;
            static TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49295;
            static TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49296;
            static TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49297;
            static TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49298;
            static TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49299;
            static TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49300;
            static TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49301;
            static TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49302;
            static TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49303;
            static TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49304;
            static TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49305;
            static TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49306;
            static TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49307;
            static TLS_RSA_WITH_AES_128_CCM = 49308;
            static TLS_RSA_WITH_AES_256_CCM = 49309;
            static TLS_DHE_RSA_WITH_AES_128_CCM = 49310;
            static TLS_DHE_RSA_WITH_AES_256_CCM = 49311;
            static TLS_RSA_WITH_AES_128_CCM_8 = 49312;
            static TLS_RSA_WITH_AES_256_CCM_8 = 49313;
            static TLS_DHE_RSA_WITH_AES_128_CCM_8 = 49314;
            static TLS_DHE_RSA_WITH_AES_256_CCM_8 = 49315;
            static TLS_PSK_WITH_AES_128_CCM = 49316;
            static TLS_PSK_WITH_AES_256_CCM = 49317;
            static TLS_DHE_PSK_WITH_AES_128_CCM = 49318;
            static TLS_DHE_PSK_WITH_AES_256_CCM = 49319;
            static TLS_PSK_WITH_AES_128_CCM_8 = 49320;
            static TLS_PSK_WITH_AES_256_CCM_8 = 49321;
            static TLS_PSK_DHE_WITH_AES_128_CCM_8 = 49322;
            static TLS_PSK_DHE_WITH_AES_256_CCM_8 = 49323;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CCM = 49324;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CCM = 49325;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8 = 49326;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8 = 49327;
            static TLS_ECCPWD_WITH_AES_128_GCM_SHA256 = 49328;
            static TLS_ECCPWD_WITH_AES_256_GCM_SHA384 = 49329;
            static TLS_ECCPWD_WITH_AES_128_CCM_SHA256 = 49330;
            static TLS_ECCPWD_WITH_AES_256_CCM_SHA384 = 49331;
            static TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256 = 52392;
            static TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256 = 52393;
            static TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256 = 52394;
            static TLS_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52395;
            static TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52396;
            static TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52397;
            static TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52398;
            static TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256 = 53249;
            static TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384 = 53250;
            static TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256 = 53251;
            static TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256 = 53253;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TLS_NULL_WITH_NULL_NULL": 0n,
                    "TLS_RSA_WITH_NULL_MD5": 1n,
                    "TLS_RSA_WITH_NULL_SHA": 2n,
                    "TLS_RSA_EXPORT_WITH_RC4_40_MD5": 3n,
                    "TLS_RSA_WITH_RC4_128_MD5": 4n,
                    "TLS_RSA_WITH_RC4_128_SHA": 5n,
                    "TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5": 6n,
                    "TLS_RSA_WITH_IDEA_CBC_SHA": 7n,
                    "TLS_RSA_EXPORT_WITH_DES40_CBC_SHA": 8n,
                    "TLS_RSA_WITH_DES_CBC_SHA": 9n,
                    "TLS_RSA_WITH_3DES_EDE_CBC_SHA": 10n,
                    "TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA": 11n,
                    "TLS_DH_DSS_WITH_DES_CBC_SHA": 12n,
                    "TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA": 13n,
                    "TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA": 14n,
                    "TLS_DH_RSA_WITH_DES_CBC_SHA": 15n,
                    "TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA": 16n,
                    "TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA": 17n,
                    "TLS_DHE_DSS_WITH_DES_CBC_SHA": 18n,
                    "TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA": 19n,
                    "TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA": 20n,
                    "TLS_DHE_RSA_WITH_DES_CBC_SHA": 21n,
                    "TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA": 22n,
                    "TLS_DH_anon_EXPORT_WITH_RC4_40_MD5": 23n,
                    "TLS_DH_anon_WITH_RC4_128_MD5": 24n,
                    "TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA": 25n,
                    "TLS_DH_anon_WITH_DES_CBC_SHA": 26n,
                    "TLS_DH_anon_WITH_3DES_EDE_CBC_SHA": 27n,
                    "TLS_KRB5_WITH_DES_CBC_SHA": 30n,
                    "TLS_KRB5_WITH_3DES_EDE_CBC_SHA": 31n,
                    "TLS_KRB5_WITH_RC4_128_SHA": 32n,
                    "TLS_KRB5_WITH_IDEA_CBC_SHA": 33n,
                    "TLS_KRB5_WITH_DES_CBC_MD5": 34n,
                    "TLS_KRB5_WITH_3DES_EDE_CBC_MD5": 35n,
                    "TLS_KRB5_WITH_RC4_128_MD5": 36n,
                    "TLS_KRB5_WITH_IDEA_CBC_MD5": 37n,
                    "TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA": 38n,
                    "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA": 39n,
                    "TLS_KRB5_EXPORT_WITH_RC4_40_SHA": 40n,
                    "TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5": 41n,
                    "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5": 42n,
                    "TLS_KRB5_EXPORT_WITH_RC4_40_MD5": 43n,
                    "TLS_PSK_WITH_NULL_SHA": 44n,
                    "TLS_DHE_PSK_WITH_NULL_SHA": 45n,
                    "TLS_RSA_PSK_WITH_NULL_SHA": 46n,
                    "TLS_RSA_WITH_AES_128_CBC_SHA": 47n,
                    "TLS_DH_DSS_WITH_AES_128_CBC_SHA": 48n,
                    "TLS_DH_RSA_WITH_AES_128_CBC_SHA": 49n,
                    "TLS_DHE_DSS_WITH_AES_128_CBC_SHA": 50n,
                    "TLS_DHE_RSA_WITH_AES_128_CBC_SHA": 51n,
                    "TLS_DH_anon_WITH_AES_128_CBC_SHA": 52n,
                    "TLS_RSA_WITH_AES_256_CBC_SHA": 53n,
                    "TLS_DH_DSS_WITH_AES_256_CBC_SHA": 54n,
                    "TLS_DH_RSA_WITH_AES_256_CBC_SHA": 55n,
                    "TLS_DHE_DSS_WITH_AES_256_CBC_SHA": 56n,
                    "TLS_DHE_RSA_WITH_AES_256_CBC_SHA": 57n,
                    "TLS_DH_anon_WITH_AES_256_CBC_SHA": 58n,
                    "TLS_RSA_WITH_NULL_SHA256": 59n,
                    "TLS_RSA_WITH_AES_128_CBC_SHA256": 60n,
                    "TLS_RSA_WITH_AES_256_CBC_SHA256": 61n,
                    "TLS_DH_DSS_WITH_AES_128_CBC_SHA256": 62n,
                    "TLS_DH_RSA_WITH_AES_128_CBC_SHA256": 63n,
                    "TLS_DHE_DSS_WITH_AES_128_CBC_SHA256": 64n,
                    "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA": 65n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA": 66n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA": 67n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA": 68n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA": 69n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA": 70n,
                    "TLS_DHE_RSA_WITH_AES_128_CBC_SHA256": 103n,
                    "TLS_DH_DSS_WITH_AES_256_CBC_SHA256": 104n,
                    "TLS_DH_RSA_WITH_AES_256_CBC_SHA256": 105n,
                    "TLS_DHE_DSS_WITH_AES_256_CBC_SHA256": 106n,
                    "TLS_DHE_RSA_WITH_AES_256_CBC_SHA256": 107n,
                    "TLS_DH_anon_WITH_AES_128_CBC_SHA256": 108n,
                    "TLS_DH_anon_WITH_AES_256_CBC_SHA256": 109n,
                    "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA": 132n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA": 133n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA": 134n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA": 135n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA": 136n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA": 137n,
                    "TLS_PSK_WITH_RC4_128_SHA": 138n,
                    "TLS_PSK_WITH_3DES_EDE_CBC_SHA": 139n,
                    "TLS_PSK_WITH_AES_128_CBC_SHA": 140n,
                    "TLS_PSK_WITH_AES_256_CBC_SHA": 141n,
                    "TLS_DHE_PSK_WITH_RC4_128_SHA": 142n,
                    "TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA": 143n,
                    "TLS_DHE_PSK_WITH_AES_128_CBC_SHA": 144n,
                    "TLS_DHE_PSK_WITH_AES_256_CBC_SHA": 145n,
                    "TLS_RSA_PSK_WITH_RC4_128_SHA": 146n,
                    "TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA": 147n,
                    "TLS_RSA_PSK_WITH_AES_128_CBC_SHA": 148n,
                    "TLS_RSA_PSK_WITH_AES_256_CBC_SHA": 149n,
                    "TLS_RSA_WITH_SEED_CBC_SHA": 150n,
                    "TLS_DH_DSS_WITH_SEED_CBC_SHA": 151n,
                    "TLS_DH_RSA_WITH_SEED_CBC_SHA": 152n,
                    "TLS_DHE_DSS_WITH_SEED_CBC_SHA": 153n,
                    "TLS_DHE_RSA_WITH_SEED_CBC_SHA": 154n,
                    "TLS_DH_anon_WITH_SEED_CBC_SHA": 155n,
                    "TLS_RSA_WITH_AES_128_GCM_SHA256": 156n,
                    "TLS_RSA_WITH_AES_256_GCM_SHA384": 157n,
                    "TLS_DHE_RSA_WITH_AES_128_GCM_SHA256": 158n,
                    "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384": 159n,
                    "TLS_DH_RSA_WITH_AES_128_GCM_SHA256": 160n,
                    "TLS_DH_RSA_WITH_AES_256_GCM_SHA384": 161n,
                    "TLS_DHE_DSS_WITH_AES_128_GCM_SHA256": 162n,
                    "TLS_DHE_DSS_WITH_AES_256_GCM_SHA384": 163n,
                    "TLS_DH_DSS_WITH_AES_128_GCM_SHA256": 164n,
                    "TLS_DH_DSS_WITH_AES_256_GCM_SHA384": 165n,
                    "TLS_DH_anon_WITH_AES_128_GCM_SHA256": 166n,
                    "TLS_DH_anon_WITH_AES_256_GCM_SHA384": 167n,
                    "TLS_PSK_WITH_AES_128_GCM_SHA256": 168n,
                    "TLS_PSK_WITH_AES_256_GCM_SHA384": 169n,
                    "TLS_DHE_PSK_WITH_AES_128_GCM_SHA256": 170n,
                    "TLS_DHE_PSK_WITH_AES_256_GCM_SHA384": 171n,
                    "TLS_RSA_PSK_WITH_AES_128_GCM_SHA256": 172n,
                    "TLS_RSA_PSK_WITH_AES_256_GCM_SHA384": 173n,
                    "TLS_PSK_WITH_AES_128_CBC_SHA256": 174n,
                    "TLS_PSK_WITH_AES_256_CBC_SHA384": 175n,
                    "TLS_PSK_WITH_NULL_SHA256": 176n,
                    "TLS_PSK_WITH_NULL_SHA384": 177n,
                    "TLS_DHE_PSK_WITH_AES_128_CBC_SHA256": 178n,
                    "TLS_DHE_PSK_WITH_AES_256_CBC_SHA384": 179n,
                    "TLS_DHE_PSK_WITH_NULL_SHA256": 180n,
                    "TLS_DHE_PSK_WITH_NULL_SHA384": 181n,
                    "TLS_RSA_PSK_WITH_AES_128_CBC_SHA256": 182n,
                    "TLS_RSA_PSK_WITH_AES_256_CBC_SHA384": 183n,
                    "TLS_RSA_PSK_WITH_NULL_SHA256": 184n,
                    "TLS_RSA_PSK_WITH_NULL_SHA384": 185n,
                    "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256": 186n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256": 187n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256": 188n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256": 189n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256": 190n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256": 191n,
                    "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256": 192n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256": 193n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256": 194n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256": 195n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256": 196n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256": 197n,
                    "TLS_AES_128_GCM_SHA256": 4865n,
                    "TLS_AES_256_GCM_SHA384": 4866n,
                    "TLS_CHACHA20_POLY1305_SHA256": 4867n,
                    "TLS_AES_128_CCM_SHA256": 4868n,
                    "TLS_AES_128_CCM_8_SHA256": 4869n,
                    "TLS_ECDH_ECDSA_WITH_NULL_SHA": 49153n,
                    "TLS_ECDH_ECDSA_WITH_RC4_128_SHA": 49154n,
                    "TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA": 49155n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA": 49156n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA": 49157n,
                    "TLS_ECDHE_ECDSA_WITH_NULL_SHA": 49158n,
                    "TLS_ECDHE_ECDSA_WITH_RC4_128_SHA": 49159n,
                    "TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA": 49160n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA": 49161n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA": 49162n,
                    "TLS_ECDH_RSA_WITH_NULL_SHA": 49163n,
                    "TLS_ECDH_RSA_WITH_RC4_128_SHA": 49164n,
                    "TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA": 49165n,
                    "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA": 49166n,
                    "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA": 49167n,
                    "TLS_ECDHE_RSA_WITH_NULL_SHA": 49168n,
                    "TLS_ECDHE_RSA_WITH_RC4_128_SHA": 49169n,
                    "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA": 49170n,
                    "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA": 49171n,
                    "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA": 49172n,
                    "TLS_ECDH_anon_WITH_NULL_SHA": 49173n,
                    "TLS_ECDH_anon_WITH_RC4_128_SHA": 49174n,
                    "TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA": 49175n,
                    "TLS_ECDH_anon_WITH_AES_128_CBC_SHA": 49176n,
                    "TLS_ECDH_anon_WITH_AES_256_CBC_SHA": 49177n,
                    "TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA": 49178n,
                    "TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA": 49179n,
                    "TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA": 49180n,
                    "TLS_SRP_SHA_WITH_AES_128_CBC_SHA": 49181n,
                    "TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA": 49182n,
                    "TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA": 49183n,
                    "TLS_SRP_SHA_WITH_AES_256_CBC_SHA": 49184n,
                    "TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA": 49185n,
                    "TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA": 49186n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256": 49187n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384": 49188n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256": 49189n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384": 49190n,
                    "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256": 49191n,
                    "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384": 49192n,
                    "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256": 49193n,
                    "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384": 49194n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256": 49195n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384": 49196n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256": 49197n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384": 49198n,
                    "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256": 49199n,
                    "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384": 49200n,
                    "TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256": 49201n,
                    "TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384": 49202n,
                    "TLS_ECDHE_PSK_WITH_RC4_128_SHA": 49203n,
                    "TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA": 49204n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA": 49205n,
                    "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA": 49206n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256": 49207n,
                    "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384": 49208n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA": 49209n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA256": 49210n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA384": 49211n,
                    "TLS_RSA_WITH_ARIA_128_CBC_SHA256": 49212n,
                    "TLS_RSA_WITH_ARIA_256_CBC_SHA384": 49213n,
                    "TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256": 49214n,
                    "TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384": 49215n,
                    "TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256": 49216n,
                    "TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384": 49217n,
                    "TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256": 49218n,
                    "TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384": 49219n,
                    "TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256": 49220n,
                    "TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384": 49221n,
                    "TLS_DH_anon_WITH_ARIA_128_CBC_SHA256": 49222n,
                    "TLS_DH_anon_WITH_ARIA_256_CBC_SHA384": 49223n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256": 49224n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384": 49225n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256": 49226n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384": 49227n,
                    "TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256": 49228n,
                    "TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384": 49229n,
                    "TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256": 49230n,
                    "TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384": 49231n,
                    "TLS_RSA_WITH_ARIA_128_GCM_SHA256": 49232n,
                    "TLS_RSA_WITH_ARIA_256_GCM_SHA384": 49233n,
                    "TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256": 49234n,
                    "TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384": 49235n,
                    "TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256": 49236n,
                    "TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384": 49237n,
                    "TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256": 49238n,
                    "TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384": 49239n,
                    "TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256": 49240n,
                    "TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384": 49241n,
                    "TLS_DH_anon_WITH_ARIA_128_GCM_SHA256": 49242n,
                    "TLS_DH_anon_WITH_ARIA_256_GCM_SHA384": 49243n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256": 49244n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384": 49245n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256": 49246n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384": 49247n,
                    "TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256": 49248n,
                    "TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384": 49249n,
                    "TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256": 49250n,
                    "TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384": 49251n,
                    "TLS_PSK_WITH_ARIA_128_CBC_SHA256": 49252n,
                    "TLS_PSK_WITH_ARIA_256_CBC_SHA384": 49253n,
                    "TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256": 49254n,
                    "TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384": 49255n,
                    "TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256": 49256n,
                    "TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384": 49257n,
                    "TLS_PSK_WITH_ARIA_128_GCM_SHA256": 49258n,
                    "TLS_PSK_WITH_ARIA_256_GCM_SHA384": 49259n,
                    "TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256": 49260n,
                    "TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384": 49261n,
                    "TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256": 49262n,
                    "TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384": 49263n,
                    "TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256": 49264n,
                    "TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384": 49265n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256": 49266n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384": 49267n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256": 49268n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384": 49269n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256": 49270n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384": 49271n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256": 49272n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384": 49273n,
                    "TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49274n,
                    "TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49275n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49276n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49277n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49278n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49279n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256": 49280n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384": 49281n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256": 49282n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384": 49283n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256": 49284n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384": 49285n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256": 49286n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384": 49287n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256": 49288n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384": 49289n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49290n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49291n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49292n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49293n,
                    "TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49294n,
                    "TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49295n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49296n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49297n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49298n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49299n,
                    "TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49300n,
                    "TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49301n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49302n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49303n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49304n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49305n,
                    "TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49306n,
                    "TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49307n,
                    "TLS_RSA_WITH_AES_128_CCM": 49308n,
                    "TLS_RSA_WITH_AES_256_CCM": 49309n,
                    "TLS_DHE_RSA_WITH_AES_128_CCM": 49310n,
                    "TLS_DHE_RSA_WITH_AES_256_CCM": 49311n,
                    "TLS_RSA_WITH_AES_128_CCM_8": 49312n,
                    "TLS_RSA_WITH_AES_256_CCM_8": 49313n,
                    "TLS_DHE_RSA_WITH_AES_128_CCM_8": 49314n,
                    "TLS_DHE_RSA_WITH_AES_256_CCM_8": 49315n,
                    "TLS_PSK_WITH_AES_128_CCM": 49316n,
                    "TLS_PSK_WITH_AES_256_CCM": 49317n,
                    "TLS_DHE_PSK_WITH_AES_128_CCM": 49318n,
                    "TLS_DHE_PSK_WITH_AES_256_CCM": 49319n,
                    "TLS_PSK_WITH_AES_128_CCM_8": 49320n,
                    "TLS_PSK_WITH_AES_256_CCM_8": 49321n,
                    "TLS_PSK_DHE_WITH_AES_128_CCM_8": 49322n,
                    "TLS_PSK_DHE_WITH_AES_256_CCM_8": 49323n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CCM": 49324n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CCM": 49325n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8": 49326n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8": 49327n,
                    "TLS_ECCPWD_WITH_AES_128_GCM_SHA256": 49328n,
                    "TLS_ECCPWD_WITH_AES_256_GCM_SHA384": 49329n,
                    "TLS_ECCPWD_WITH_AES_128_CCM_SHA256": 49330n,
                    "TLS_ECCPWD_WITH_AES_256_CCM_SHA384": 49331n,
                    "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256": 52392n,
                    "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256": 52393n,
                    "TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256": 52394n,
                    "TLS_PSK_WITH_CHACHA20_POLY1305_SHA256": 52395n,
                    "TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256": 52396n,
                    "TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256": 52397n,
                    "TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256": 52398n,
                    "TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256": 53249n,
                    "TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384": 53250n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256": 53251n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256": 53253n
                };
            }
            static $h = 1429612;
            static $z = 2;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.UInt16; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":589825,"l":[{"t":1429612,"n":"TLS_NULL_WITH_NULL_NULL","d":1429612,"h":4296396908,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_NULL_MD5","d":1429612,"h":8591364204,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_NULL_SHA","d":1429612,"h":12886331500,"f":33},{"t":1429612,"n":"TLS_RSA_EXPORT_WITH_RC4_40_MD5","d":1429612,"h":17181298796,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_RC4_128_MD5","d":1429612,"h":21476266092,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_RC4_128_SHA","d":1429612,"h":25771233388,"f":33},{"t":1429612,"n":"TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5","d":1429612,"h":30066200684,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_IDEA_CBC_SHA","d":1429612,"h":34361167980,"f":33},{"t":1429612,"n":"TLS_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1429612,"h":38656135276,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_DES_CBC_SHA","d":1429612,"h":42951102572,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":47246069868,"f":33},{"t":1429612,"n":"TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA","d":1429612,"h":51541037164,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_DES_CBC_SHA","d":1429612,"h":55836004460,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":60130971756,"f":33},{"t":1429612,"n":"TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1429612,"h":64425939052,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_DES_CBC_SHA","d":1429612,"h":68720906348,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":73015873644,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA","d":1429612,"h":77310840940,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_DES_CBC_SHA","d":1429612,"h":81605808236,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":85900775532,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1429612,"h":90195742828,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_DES_CBC_SHA","d":1429612,"h":94490710124,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":98785677420,"f":33},{"t":1429612,"n":"TLS_DH_anon_EXPORT_WITH_RC4_40_MD5","d":1429612,"h":103080644716,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_RC4_128_MD5","d":1429612,"h":107375612012,"f":33},{"t":1429612,"n":"TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA","d":1429612,"h":111670579308,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_DES_CBC_SHA","d":1429612,"h":115965546604,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":120260513900,"f":33},{"t":1429612,"n":"TLS_KRB5_WITH_DES_CBC_SHA","d":1429612,"h":124555481196,"f":33},{"t":1429612,"n":"TLS_KRB5_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":128850448492,"f":33},{"t":1429612,"n":"TLS_KRB5_WITH_RC4_128_SHA","d":1429612,"h":133145415788,"f":33},{"t":1429612,"n":"TLS_KRB5_WITH_IDEA_CBC_SHA","d":1429612,"h":137440383084,"f":33},{"t":1429612,"n":"TLS_KRB5_WITH_DES_CBC_MD5","d":1429612,"h":141735350380,"f":33},{"t":1429612,"n":"TLS_KRB5_WITH_3DES_EDE_CBC_MD5","d":1429612,"h":146030317676,"f":33},{"t":1429612,"n":"TLS_KRB5_WITH_RC4_128_MD5","d":1429612,"h":150325284972,"f":33},{"t":1429612,"n":"TLS_KRB5_WITH_IDEA_CBC_MD5","d":1429612,"h":154620252268,"f":33},{"t":1429612,"n":"TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA","d":1429612,"h":158915219564,"f":33},{"t":1429612,"n":"TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA","d":1429612,"h":163210186860,"f":33},{"t":1429612,"n":"TLS_KRB5_EXPORT_WITH_RC4_40_SHA","d":1429612,"h":167505154156,"f":33},{"t":1429612,"n":"TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5","d":1429612,"h":171800121452,"f":33},{"t":1429612,"n":"TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5","d":1429612,"h":176095088748,"f":33},{"t":1429612,"n":"TLS_KRB5_EXPORT_WITH_RC4_40_MD5","d":1429612,"h":180390056044,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_NULL_SHA","d":1429612,"h":184685023340,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_NULL_SHA","d":1429612,"h":188979990636,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_NULL_SHA","d":1429612,"h":193274957932,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_AES_128_CBC_SHA","d":1429612,"h":197569925228,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_AES_128_CBC_SHA","d":1429612,"h":201864892524,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_AES_128_CBC_SHA","d":1429612,"h":206159859820,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_AES_128_CBC_SHA","d":1429612,"h":210454827116,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_AES_128_CBC_SHA","d":1429612,"h":214749794412,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_AES_128_CBC_SHA","d":1429612,"h":219044761708,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_AES_256_CBC_SHA","d":1429612,"h":223339729004,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_AES_256_CBC_SHA","d":1429612,"h":227634696300,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_AES_256_CBC_SHA","d":1429612,"h":231929663596,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_AES_256_CBC_SHA","d":1429612,"h":236224630892,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_AES_256_CBC_SHA","d":1429612,"h":240519598188,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_AES_256_CBC_SHA","d":1429612,"h":244814565484,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_NULL_SHA256","d":1429612,"h":249109532780,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_AES_128_CBC_SHA256","d":1429612,"h":253404500076,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_AES_256_CBC_SHA256","d":1429612,"h":257699467372,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_AES_128_CBC_SHA256","d":1429612,"h":261994434668,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_AES_128_CBC_SHA256","d":1429612,"h":266289401964,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_AES_128_CBC_SHA256","d":1429612,"h":270584369260,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1429612,"h":274879336556,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA","d":1429612,"h":279174303852,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1429612,"h":283469271148,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA","d":1429612,"h":287764238444,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1429612,"h":292059205740,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA","d":1429612,"h":296354173036,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_AES_128_CBC_SHA256","d":1429612,"h":300649140332,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_AES_256_CBC_SHA256","d":1429612,"h":304944107628,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_AES_256_CBC_SHA256","d":1429612,"h":309239074924,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_AES_256_CBC_SHA256","d":1429612,"h":313534042220,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_AES_256_CBC_SHA256","d":1429612,"h":317829009516,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_AES_128_CBC_SHA256","d":1429612,"h":322123976812,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_AES_256_CBC_SHA256","d":1429612,"h":326418944108,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1429612,"h":330713911404,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA","d":1429612,"h":335008878700,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1429612,"h":339303845996,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA","d":1429612,"h":343598813292,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1429612,"h":347893780588,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA","d":1429612,"h":352188747884,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_RC4_128_SHA","d":1429612,"h":356483715180,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":360778682476,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_AES_128_CBC_SHA","d":1429612,"h":365073649772,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_AES_256_CBC_SHA","d":1429612,"h":369368617068,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_RC4_128_SHA","d":1429612,"h":373663584364,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":377958551660,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_AES_128_CBC_SHA","d":1429612,"h":382253518956,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_AES_256_CBC_SHA","d":1429612,"h":386548486252,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_RC4_128_SHA","d":1429612,"h":390843453548,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":395138420844,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_AES_128_CBC_SHA","d":1429612,"h":399433388140,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_AES_256_CBC_SHA","d":1429612,"h":403728355436,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_SEED_CBC_SHA","d":1429612,"h":408023322732,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_SEED_CBC_SHA","d":1429612,"h":412318290028,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_SEED_CBC_SHA","d":1429612,"h":416613257324,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_SEED_CBC_SHA","d":1429612,"h":420908224620,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_SEED_CBC_SHA","d":1429612,"h":425203191916,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_SEED_CBC_SHA","d":1429612,"h":429498159212,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_AES_128_GCM_SHA256","d":1429612,"h":433793126508,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_AES_256_GCM_SHA384","d":1429612,"h":438088093804,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_AES_128_GCM_SHA256","d":1429612,"h":442383061100,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_AES_256_GCM_SHA384","d":1429612,"h":446678028396,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_AES_128_GCM_SHA256","d":1429612,"h":450972995692,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_AES_256_GCM_SHA384","d":1429612,"h":455267962988,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_AES_128_GCM_SHA256","d":1429612,"h":459562930284,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_AES_256_GCM_SHA384","d":1429612,"h":463857897580,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_AES_128_GCM_SHA256","d":1429612,"h":468152864876,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_AES_256_GCM_SHA384","d":1429612,"h":472447832172,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_AES_128_GCM_SHA256","d":1429612,"h":476742799468,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_AES_256_GCM_SHA384","d":1429612,"h":481037766764,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_AES_128_GCM_SHA256","d":1429612,"h":485332734060,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_AES_256_GCM_SHA384","d":1429612,"h":489627701356,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_AES_128_GCM_SHA256","d":1429612,"h":493922668652,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_AES_256_GCM_SHA384","d":1429612,"h":498217635948,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_AES_128_GCM_SHA256","d":1429612,"h":502512603244,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_AES_256_GCM_SHA384","d":1429612,"h":506807570540,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_AES_128_CBC_SHA256","d":1429612,"h":511102537836,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_AES_256_CBC_SHA384","d":1429612,"h":515397505132,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_NULL_SHA256","d":1429612,"h":519692472428,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_NULL_SHA384","d":1429612,"h":523987439724,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_AES_128_CBC_SHA256","d":1429612,"h":528282407020,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_AES_256_CBC_SHA384","d":1429612,"h":532577374316,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_NULL_SHA256","d":1429612,"h":536872341612,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_NULL_SHA384","d":1429612,"h":541167308908,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_AES_128_CBC_SHA256","d":1429612,"h":545462276204,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_AES_256_CBC_SHA384","d":1429612,"h":549757243500,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_NULL_SHA256","d":1429612,"h":554052210796,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_NULL_SHA384","d":1429612,"h":558347178092,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1429612,"h":562642145388,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256","d":1429612,"h":566937112684,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1429612,"h":571232079980,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256","d":1429612,"h":575527047276,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1429612,"h":579822014572,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256","d":1429612,"h":584116981868,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1429612,"h":588411949164,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256","d":1429612,"h":592706916460,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1429612,"h":597001883756,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256","d":1429612,"h":601296851052,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1429612,"h":605591818348,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256","d":1429612,"h":609886785644,"f":33},{"t":1429612,"n":"TLS_AES_128_GCM_SHA256","d":1429612,"h":614181752940,"f":33},{"t":1429612,"n":"TLS_AES_256_GCM_SHA384","d":1429612,"h":618476720236,"f":33},{"t":1429612,"n":"TLS_CHACHA20_POLY1305_SHA256","d":1429612,"h":622771687532,"f":33},{"t":1429612,"n":"TLS_AES_128_CCM_SHA256","d":1429612,"h":627066654828,"f":33},{"t":1429612,"n":"TLS_AES_128_CCM_8_SHA256","d":1429612,"h":631361622124,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_NULL_SHA","d":1429612,"h":635656589420,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_RC4_128_SHA","d":1429612,"h":639951556716,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":644246524012,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA","d":1429612,"h":648541491308,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA","d":1429612,"h":652836458604,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_NULL_SHA","d":1429612,"h":657131425900,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_RC4_128_SHA","d":1429612,"h":661426393196,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":665721360492,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA","d":1429612,"h":670016327788,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA","d":1429612,"h":674311295084,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_NULL_SHA","d":1429612,"h":678606262380,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_RC4_128_SHA","d":1429612,"h":682901229676,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":687196196972,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_AES_128_CBC_SHA","d":1429612,"h":691491164268,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_AES_256_CBC_SHA","d":1429612,"h":695786131564,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_NULL_SHA","d":1429612,"h":700081098860,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_RC4_128_SHA","d":1429612,"h":704376066156,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":708671033452,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA","d":1429612,"h":712966000748,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA","d":1429612,"h":717260968044,"f":33},{"t":1429612,"n":"TLS_ECDH_anon_WITH_NULL_SHA","d":1429612,"h":721555935340,"f":33},{"t":1429612,"n":"TLS_ECDH_anon_WITH_RC4_128_SHA","d":1429612,"h":725850902636,"f":33},{"t":1429612,"n":"TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":730145869932,"f":33},{"t":1429612,"n":"TLS_ECDH_anon_WITH_AES_128_CBC_SHA","d":1429612,"h":734440837228,"f":33},{"t":1429612,"n":"TLS_ECDH_anon_WITH_AES_256_CBC_SHA","d":1429612,"h":738735804524,"f":33},{"t":1429612,"n":"TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":743030771820,"f":33},{"t":1429612,"n":"TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":747325739116,"f":33},{"t":1429612,"n":"TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":751620706412,"f":33},{"t":1429612,"n":"TLS_SRP_SHA_WITH_AES_128_CBC_SHA","d":1429612,"h":755915673708,"f":33},{"t":1429612,"n":"TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA","d":1429612,"h":760210641004,"f":33},{"t":1429612,"n":"TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA","d":1429612,"h":764505608300,"f":33},{"t":1429612,"n":"TLS_SRP_SHA_WITH_AES_256_CBC_SHA","d":1429612,"h":768800575596,"f":33},{"t":1429612,"n":"TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA","d":1429612,"h":773095542892,"f":33},{"t":1429612,"n":"TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA","d":1429612,"h":777390510188,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256","d":1429612,"h":781685477484,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384","d":1429612,"h":785980444780,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256","d":1429612,"h":790275412076,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384","d":1429612,"h":794570379372,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256","d":1429612,"h":798865346668,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384","d":1429612,"h":803160313964,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256","d":1429612,"h":807455281260,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384","d":1429612,"h":811750248556,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256","d":1429612,"h":816045215852,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384","d":1429612,"h":820340183148,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256","d":1429612,"h":824635150444,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384","d":1429612,"h":828930117740,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256","d":1429612,"h":833225085036,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384","d":1429612,"h":837520052332,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256","d":1429612,"h":841815019628,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384","d":1429612,"h":846109986924,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_RC4_128_SHA","d":1429612,"h":850404954220,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA","d":1429612,"h":854699921516,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA","d":1429612,"h":858994888812,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA","d":1429612,"h":863289856108,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256","d":1429612,"h":867584823404,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384","d":1429612,"h":871879790700,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA","d":1429612,"h":876174757996,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA256","d":1429612,"h":880469725292,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA384","d":1429612,"h":884764692588,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_ARIA_128_CBC_SHA256","d":1429612,"h":889059659884,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_ARIA_256_CBC_SHA384","d":1429612,"h":893354627180,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256","d":1429612,"h":897649594476,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384","d":1429612,"h":901944561772,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256","d":1429612,"h":906239529068,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384","d":1429612,"h":910534496364,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256","d":1429612,"h":914829463660,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384","d":1429612,"h":919124430956,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256","d":1429612,"h":923419398252,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384","d":1429612,"h":927714365548,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_ARIA_128_CBC_SHA256","d":1429612,"h":932009332844,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_ARIA_256_CBC_SHA384","d":1429612,"h":936304300140,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256","d":1429612,"h":940599267436,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384","d":1429612,"h":944894234732,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256","d":1429612,"h":949189202028,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384","d":1429612,"h":953484169324,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256","d":1429612,"h":957779136620,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384","d":1429612,"h":962074103916,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256","d":1429612,"h":966369071212,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384","d":1429612,"h":970664038508,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_ARIA_128_GCM_SHA256","d":1429612,"h":974959005804,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_ARIA_256_GCM_SHA384","d":1429612,"h":979253973100,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256","d":1429612,"h":983548940396,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384","d":1429612,"h":987843907692,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256","d":1429612,"h":992138874988,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384","d":1429612,"h":996433842284,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256","d":1429612,"h":1000728809580,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384","d":1429612,"h":1005023776876,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256","d":1429612,"h":1009318744172,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384","d":1429612,"h":1013613711468,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_ARIA_128_GCM_SHA256","d":1429612,"h":1017908678764,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_ARIA_256_GCM_SHA384","d":1429612,"h":1022203646060,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256","d":1429612,"h":1026498613356,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384","d":1429612,"h":1030793580652,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256","d":1429612,"h":1035088547948,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384","d":1429612,"h":1039383515244,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256","d":1429612,"h":1043678482540,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384","d":1429612,"h":1047973449836,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256","d":1429612,"h":1052268417132,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384","d":1429612,"h":1056563384428,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_ARIA_128_CBC_SHA256","d":1429612,"h":1060858351724,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_ARIA_256_CBC_SHA384","d":1429612,"h":1065153319020,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256","d":1429612,"h":1069448286316,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384","d":1429612,"h":1073743253612,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256","d":1429612,"h":1078038220908,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384","d":1429612,"h":1082333188204,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_ARIA_128_GCM_SHA256","d":1429612,"h":1086628155500,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_ARIA_256_GCM_SHA384","d":1429612,"h":1090923122796,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256","d":1429612,"h":1095218090092,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384","d":1429612,"h":1099513057388,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256","d":1429612,"h":1103808024684,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384","d":1429612,"h":1108102991980,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256","d":1429612,"h":1112397959276,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384","d":1429612,"h":1116692926572,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256","d":1429612,"h":1120987893868,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384","d":1429612,"h":1125282861164,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256","d":1429612,"h":1129577828460,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384","d":1429612,"h":1133872795756,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1429612,"h":1138167763052,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384","d":1429612,"h":1142462730348,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1429612,"h":1146757697644,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384","d":1429612,"h":1151052664940,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1429612,"h":1155347632236,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1429612,"h":1159642599532,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1429612,"h":1163937566828,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1429612,"h":1168232534124,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1429612,"h":1172527501420,"f":33},{"t":1429612,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1429612,"h":1176822468716,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256","d":1429612,"h":1181117436012,"f":33},{"t":1429612,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384","d":1429612,"h":1185412403308,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256","d":1429612,"h":1189707370604,"f":33},{"t":1429612,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384","d":1429612,"h":1194002337900,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256","d":1429612,"h":1198297305196,"f":33},{"t":1429612,"n":"TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384","d":1429612,"h":1202592272492,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256","d":1429612,"h":1206887239788,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384","d":1429612,"h":1211182207084,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256","d":1429612,"h":1215477174380,"f":33},{"t":1429612,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384","d":1429612,"h":1219772141676,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1429612,"h":1224067108972,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1429612,"h":1228362076268,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1429612,"h":1232657043564,"f":33},{"t":1429612,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1429612,"h":1236952010860,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1429612,"h":1241246978156,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1429612,"h":1245541945452,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1429612,"h":1249836912748,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1429612,"h":1254131880044,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1429612,"h":1258426847340,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1429612,"h":1262721814636,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1429612,"h":1267016781932,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1429612,"h":1271311749228,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1429612,"h":1275606716524,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1429612,"h":1279901683820,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1429612,"h":1284196651116,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1429612,"h":1288491618412,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1429612,"h":1292786585708,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1429612,"h":1297081553004,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_AES_128_CCM","d":1429612,"h":1301376520300,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_AES_256_CCM","d":1429612,"h":1305671487596,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_AES_128_CCM","d":1429612,"h":1309966454892,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_AES_256_CCM","d":1429612,"h":1314261422188,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_AES_128_CCM_8","d":1429612,"h":1318556389484,"f":33},{"t":1429612,"n":"TLS_RSA_WITH_AES_256_CCM_8","d":1429612,"h":1322851356780,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_AES_128_CCM_8","d":1429612,"h":1327146324076,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_AES_256_CCM_8","d":1429612,"h":1331441291372,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_AES_128_CCM","d":1429612,"h":1335736258668,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_AES_256_CCM","d":1429612,"h":1340031225964,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_AES_128_CCM","d":1429612,"h":1344326193260,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_AES_256_CCM","d":1429612,"h":1348621160556,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_AES_128_CCM_8","d":1429612,"h":1352916127852,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_AES_256_CCM_8","d":1429612,"h":1357211095148,"f":33},{"t":1429612,"n":"TLS_PSK_DHE_WITH_AES_128_CCM_8","d":1429612,"h":1361506062444,"f":33},{"t":1429612,"n":"TLS_PSK_DHE_WITH_AES_256_CCM_8","d":1429612,"h":1365801029740,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CCM","d":1429612,"h":1370095997036,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CCM","d":1429612,"h":1374390964332,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8","d":1429612,"h":1378685931628,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8","d":1429612,"h":1382980898924,"f":33},{"t":1429612,"n":"TLS_ECCPWD_WITH_AES_128_GCM_SHA256","d":1429612,"h":1387275866220,"f":33},{"t":1429612,"n":"TLS_ECCPWD_WITH_AES_256_GCM_SHA384","d":1429612,"h":1391570833516,"f":33},{"t":1429612,"n":"TLS_ECCPWD_WITH_AES_128_CCM_SHA256","d":1429612,"h":1395865800812,"f":33},{"t":1429612,"n":"TLS_ECCPWD_WITH_AES_256_CCM_SHA384","d":1429612,"h":1400160768108,"f":33},{"t":1429612,"n":"TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256","d":1429612,"h":1404455735404,"f":33},{"t":1429612,"n":"TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256","d":1429612,"h":1408750702700,"f":33},{"t":1429612,"n":"TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256","d":1429612,"h":1413045669996,"f":33},{"t":1429612,"n":"TLS_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1429612,"h":1417340637292,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1429612,"h":1421635604588,"f":33},{"t":1429612,"n":"TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1429612,"h":1425930571884,"f":33},{"t":1429612,"n":"TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1429612,"h":1430225539180,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256","d":1429612,"h":1434520506476,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384","d":1429612,"h":1438815473772,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256","d":1429612,"h":1443110441068,"f":33},{"t":1429612,"n":"TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256","d":1429612,"h":1447405408364,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1429612,"h":1451700375660,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1429612,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.TlsCipherSuite`; }
        });
        
        $asm.$str("$snsc.System.Security.Authentication.ExtendedProtection.PolicyEnforcement", ($self) => class PolicyEnforcement extends $.$spc.System.Enum
        {
            static Never = 0;
            static WhenSupported = 1;
            static Always = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Never": 0n,
                    "WhenSupported": 1n,
                    "Always": 2n
                };
            }
            static $h = 1626220;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1626220,"n":"Never","d":1626220,"h":4296593516,"f":33},{"t":1626220,"n":"WhenSupported","d":1626220,"h":8591560812,"f":33},{"t":1626220,"n":"Always","d":1626220,"h":12886528108,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1626220,"h":17181495404,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1626220}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.PolicyEnforcement`; }
        });
        
        $asm.$str("$snsc.System.Security.Authentication.ExtendedProtection.ProtectionScenario", ($self) => class ProtectionScenario extends $.$spc.System.Enum
        {
            static TransportSelected = 0;
            static TrustedProxy = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TransportSelected": 0n,
                    "TrustedProxy": 1n
                };
            }
            static $h = 1691756;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1691756,"n":"TransportSelected","d":1691756,"h":4296659052,"f":33},{"t":1691756,"n":"TrustedProxy","d":1691756,"h":8591626348,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1691756,"h":12886593644,"f":1}],"i":[57278465,63832065,57737217,57409537],"h":1691756}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ProtectionScenario`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateStream", ($self) => class NegotiateStream extends $.$snsc.System.Net.Security.AuthenticatedStream
        {
            $ctor$4(/*System.IO.Stream*/ innerStream)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get RemoteIdentity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsClient()
            {
            }
            /*void */ AuthenticateAsClient$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName)
            {
            }
            /*void */ AuthenticateAsClient$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsClient$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName)
            {
            }
            /*void */ AuthenticateAsClient$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsServer()
            {
            }
            /*void */ AuthenticateAsServer$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsServer$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsServer$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient(/*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer(/*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndAuthenticateAsClient(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndAuthenticateAsServer(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 643180;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":118892,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180512364,"f":32769},"n":"CanRead","d":643180,"h":12885545068,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":25770446956,"f":32769},"n":"CanSeek","d":643180,"h":21475479660,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":34360381548,"f":32769},"n":"CanTimeout","d":643180,"h":30065414252,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42950316140,"f":32769},"n":"CanWrite","d":643180,"h":38655348844,"f":32769},{"p":117243905,"g":{"r":0,"d":0,"h":51540250732,"f":129},"n":"ImpersonationLevel","d":643180,"h":47245283436,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":60130185324,"f":32769},"n":"IsAuthenticated","d":643180,"h":55835218028,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":68720119916,"f":32769},"n":"IsEncrypted","d":643180,"h":64425152620,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":77310054508,"f":32769},"n":"IsMutuallyAuthenticated","d":643180,"h":73015087212,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":85899989100,"f":32769},"n":"IsServer","d":643180,"h":81605021804,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":94489923692,"f":32769},"n":"IsSigned","d":643180,"h":90194956396,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":103079858284,"f":32769},"n":"Length","d":643180,"h":98784890988,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":111669792876,"f":32769},"s":{"r":0,"d":0,"h":115964760172,"f":32769},"n":"Position","d":643180,"h":107374825580,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":124554694764,"f":32769},"s":{"r":0,"d":0,"h":128849662060,"f":32769},"n":"ReadTimeout","d":643180,"h":120259727468,"f":32769},{"p":117047297,"g":{"r":0,"d":0,"h":137439596652,"f":129},"n":"RemoteIdentity","d":643180,"h":133144629356,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":146029531244,"f":32769},"s":{"r":0,"d":0,"h":150324498540,"f":32769},"n":"WriteTimeout","d":643180,"h":141734563948,"f":32769}],"m":[{"r":65537,"n":"AuthenticateAsClient","d":643180,"h":154619465836,"f":129},{"r":65537,"p":[{"n":"credential","p":3842546},{"n":"binding","p":5415410},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClient","o":"@$1","d":643180,"h":158914433132,"f":129},{"r":65537,"p":[{"n":"credential","p":3842546},{"n":"binding","p":5415410},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":708716},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClient","o":"@$2","d":643180,"h":163209400428,"f":129},{"r":65537,"p":[{"n":"credential","p":3842546},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClient","o":"@$3","d":643180,"h":167504367724,"f":129},{"r":65537,"p":[{"n":"credential","p":3842546},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":708716},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClient","o":"@$4","d":643180,"h":171799335020,"f":129},{"r":133300225,"n":"AuthenticateAsClientAsync","d":643180,"h":176094302316,"f":129},{"r":133300225,"p":[{"n":"credential","p":3842546},{"n":"binding","p":5415410},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$1","d":643180,"h":180389269612,"f":129},{"r":133300225,"p":[{"n":"credential","p":3842546},{"n":"binding","p":5415410},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":708716},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClientAsync","o":"@$2","d":643180,"h":184684236908,"f":129},{"r":133300225,"p":[{"n":"credential","p":3842546},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$3","d":643180,"h":188979204204,"f":129},{"r":133300225,"p":[{"n":"credential","p":3842546},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":708716},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClientAsync","o":"@$4","d":643180,"h":193274171500,"f":129},{"r":65537,"n":"AuthenticateAsServer","d":643180,"h":197569138796,"f":129},{"r":65537,"p":[{"n":"credential","p":3842546},{"n":"requiredProtectionLevel","p":708716},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServer","o":"@$1","d":643180,"h":201864106092,"f":129},{"r":65537,"p":[{"n":"credential","p":3842546},{"n":"policy","p":1560684},{"n":"requiredProtectionLevel","p":708716},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServer","o":"@$2","d":643180,"h":206159073388,"f":129},{"r":65537,"p":[{"n":"policy","p":1560684}],"n":"AuthenticateAsServer","o":"@$3","d":643180,"h":210454040684,"f":129},{"r":133300225,"n":"AuthenticateAsServerAsync","d":643180,"h":214749007980,"f":129},{"r":133300225,"p":[{"n":"credential","p":3842546},{"n":"requiredProtectionLevel","p":708716},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServerAsync","o":"@$1","d":643180,"h":219043975276,"f":129},{"r":133300225,"p":[{"n":"credential","p":3842546},{"n":"policy","p":1560684},{"n":"requiredProtectionLevel","p":708716},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServerAsync","o":"@$2","d":643180,"h":223338942572,"f":129},{"r":133300225,"p":[{"n":"policy","p":1560684}],"n":"AuthenticateAsServerAsync","o":"@$3","d":643180,"h":227633909868,"f":129},{"r":57016321,"p":[{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","d":643180,"h":231928877164,"f":129},{"r":57016321,"p":[{"n":"credential","p":3842546},{"n":"binding","p":5415410},{"n":"targetName","p":1310721},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$1","d":643180,"h":236223844460,"f":129},{"r":57016321,"p":[{"n":"credential","p":3842546},{"n":"binding","p":5415410},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":708716},{"n":"allowedImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$2","d":643180,"h":240518811756,"f":129},{"r":57016321,"p":[{"n":"credential","p":3842546},{"n":"targetName","p":1310721},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$3","d":643180,"h":244813779052,"f":129},{"r":57016321,"p":[{"n":"credential","p":3842546},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":708716},{"n":"allowedImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$4","d":643180,"h":249108746348,"f":129},{"r":57016321,"p":[{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","d":643180,"h":253403713644,"f":129},{"r":57016321,"p":[{"n":"credential","p":3842546},{"n":"requiredProtectionLevel","p":708716},{"n":"requiredImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$1","d":643180,"h":257698680940,"f":129},{"r":57016321,"p":[{"n":"credential","p":3842546},{"n":"policy","p":1560684},{"n":"requiredProtectionLevel","p":708716},{"n":"requiredImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$2","d":643180,"h":261993648236,"f":129},{"r":57016321,"p":[{"n":"policy","p":1560684},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$3","d":643180,"h":266288615532,"f":129},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginRead","d":643180,"h":270583582828,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":643180,"h":274878550124,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":643180,"h":279173517420,"f":32772},{"r":136118273,"n":"DisposeAsync","d":643180,"h":283468484716,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAuthenticateAsClient","d":643180,"h":287763452012,"f":129},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAuthenticateAsServer","d":643180,"h":292058419308,"f":129},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":643180,"h":296353386604,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":643180,"h":300648353900,"f":32769},{"r":65537,"n":"Flush","d":643180,"h":304943321196,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":643180,"h":309238288492,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":643180,"h":313533255788,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":643180,"h":317828223084,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":643180,"h":322123190380,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":643180,"h":326418157676,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":643180,"h":330713124972,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":643180,"h":335008092268,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":643180,"h":339303059564,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":643180,"h":343598026860,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62193665}],"n":".ctor","o":"$ctor$4","d":643180,"h":4295610476,"f":1},{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":643180,"h":8590577772,"f":1}],"i":[57540609,56950785],"h":643180}; }
            static get $b() { return $.$snsc.System.Net.Security.AuthenticatedStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.NegotiateStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslStream", ($self) => class SslStream extends $.$snsc.System.Net.Security.AuthenticatedStream
        {
            $ctor$4(/*System.IO.Stream*/ innerStream)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$7(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback, /*System.Net.Security.LocalCertificateSelectionCallback?*/ userCertificateSelectionCallback)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$8(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback, /*System.Net.Security.LocalCertificateSelectionCallback?*/ userCertificateSelectionCallback, /*System.Net.Security.EncryptionPolicy*/ encryptionPolicy)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CheckCertRevocationStatus()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.CipherAlgorithmType */ get CipherAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get CipherStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.HashAlgorithmType */ get HashAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get HashStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExchangeAlgorithmType */ get KeyExchangeAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get KeyExchangeStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get LocalCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslApplicationProtocol */ get NegotiatedApplicationProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.TlsCipherSuite */ get NegotiatedCipherSuite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get RemoteCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get TargetHostName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.TransportContext */ get TransportContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsClient(/*System.Net.Security.SslClientAuthenticationOptions*/ sslClientAuthenticationOptions)
            {
            }
            /*void */ AuthenticateAsClient$1(/*string*/ targetHost)
            {
            }
            /*void */ AuthenticateAsClient$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation)
            {
            }
            /*void */ AuthenticateAsClient$3(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync(/*System.Net.Security.SslClientAuthenticationOptions*/ sslClientAuthenticationOptions, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$1(/*string*/ targetHost)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$3(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsServer(/*System.Net.Security.SslServerAuthenticationOptions*/ sslServerAuthenticationOptions)
            {
            }
            /*void */ AuthenticateAsServer$1(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate)
            {
            }
            /*void */ AuthenticateAsServer$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation)
            {
            }
            /*void */ AuthenticateAsServer$3(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync(/*System.Net.Security.ServerOptionsSelectionCallback*/ optionsCallback, /*object?*/ state, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$1(/*System.Net.Security.SslServerAuthenticationOptions*/ sslServerAuthenticationOptions, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$3(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$4(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient(/*string*/ targetHost, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$1(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$1(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndAuthenticateAsClient(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndAuthenticateAsServer(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ NegotiateClientCertificateAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*System.Threading.Tasks.Task */ ShutdownAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Write$2(/*byte[]*/ buffer)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 1298540;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":118892,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30066069612,"f":32769},"n":"CanRead","d":1298540,"h":25771102316,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38656004204,"f":32769},"n":"CanSeek","d":1298540,"h":34361036908,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":47245938796,"f":32769},"n":"CanTimeout","d":1298540,"h":42950971500,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":55835873388,"f":32769},"n":"CanWrite","d":1298540,"h":51540906092,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":64425807980,"f":129},"n":"CheckCertRevocationStatus","d":1298540,"h":60130840684,"f":129},{"p":5284338,"g":{"r":0,"d":0,"h":73015742572,"f":129},"n":"CipherAlgorithm","d":1298540,"h":68720775276,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":81605677164,"f":129},"n":"CipherStrength","d":1298540,"h":77310709868,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":5546482,"g":{"r":0,"d":0,"h":90195611756,"f":129},"n":"HashAlgorithm","d":1298540,"h":85900644460,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":98785546348,"f":129},"n":"HashStrength","d":1298540,"h":94490579052,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":107375480940,"f":32769},"n":"IsAuthenticated","d":1298540,"h":103080513644,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":115965415532,"f":32769},"n":"IsEncrypted","d":1298540,"h":111670448236,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":124555350124,"f":32769},"n":"IsMutuallyAuthenticated","d":1298540,"h":120260382828,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":133145284716,"f":32769},"n":"IsServer","d":1298540,"h":128850317420,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":141735219308,"f":32769},"n":"IsSigned","d":1298540,"h":137440252012,"f":32769},{"p":5349874,"g":{"r":0,"d":0,"h":150325153900,"f":129},"n":"KeyExchangeAlgorithm","d":1298540,"h":146030186604,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":158915088492,"f":129},"n":"KeyExchangeStrength","d":1298540,"h":154620121196,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":167505023084,"f":32769},"n":"Length","d":1298540,"h":163210055788,"f":32769},{"p":28168653,"g":{"r":0,"d":0,"h":176094957676,"f":129},"n":"LocalCertificate","d":1298540,"h":171799990380,"f":129},{"p":970860,"g":{"r":0,"d":0,"h":184684892268,"f":1},"n":"NegotiatedApplicationProtocol","d":1298540,"h":180389924972,"f":1},{"p":1429612,"g":{"r":0,"d":0,"h":193274826860,"f":129},"n":"NegotiatedCipherSuite","d":1298540,"h":188979859564,"f":129,"a":[{"t":23461889,"c":8613396481,"a":[{"v":false,"t":262145}]}]},{"p":917505,"g":{"r":0,"d":0,"h":201864761452,"f":32769},"s":{"r":0,"d":0,"h":206159728748,"f":32769},"n":"Position","d":1298540,"h":197569794156,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":214749663340,"f":32769},"s":{"r":0,"d":0,"h":219044630636,"f":32769},"n":"ReadTimeout","d":1298540,"h":210454696044,"f":32769},{"p":28168653,"g":{"r":0,"d":0,"h":227634565228,"f":129},"n":"RemoteCertificate","d":1298540,"h":223339597932,"f":129},{"p":5612018,"g":{"r":0,"d":0,"h":236224499820,"f":129},"n":"SslProtocol","d":1298540,"h":231929532524,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":244814434412,"f":1},"n":"TargetHostName","d":1298540,"h":240519467116,"f":1},{"p":5022194,"g":{"r":0,"d":0,"h":253404369004,"f":1},"n":"TransportContext","d":1298540,"h":249109401708,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":261994303596,"f":32769},"s":{"r":0,"d":0,"h":266289270892,"f":32769},"n":"WriteTimeout","d":1298540,"h":257699336300,"f":32769}],"m":[{"r":65537,"p":[{"n":"sslClientAuthenticationOptions","p":1101932}],"n":"AuthenticateAsClient","d":1298540,"h":270584238188,"f":1},{"r":65537,"p":[{"n":"targetHost","p":1310721}],"n":"AuthenticateAsClient","o":"@$1","d":1298540,"h":274879205484,"f":129},{"r":65537,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28430797},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClient","o":"@$2","d":1298540,"h":279174172780,"f":129},{"r":65537,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28430797},{"n":"enabledSslProtocols","p":5612018},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClient","o":"@$3","d":1298540,"h":283469140076,"f":129},{"r":133300225,"p":[{"n":"sslClientAuthenticationOptions","p":1101932},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsClientAsync","d":1298540,"h":287764107372,"f":1},{"r":133300225,"p":[{"n":"targetHost","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$1","d":1298540,"h":292059074668,"f":129},{"r":133300225,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28430797},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClientAsync","o":"@$2","d":1298540,"h":296354041964,"f":129},{"r":133300225,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28430797},{"n":"enabledSslProtocols","p":5612018},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClientAsync","o":"@$3","d":1298540,"h":300649009260,"f":129},{"r":65537,"p":[{"n":"sslServerAuthenticationOptions","p":1233004}],"n":"AuthenticateAsServer","d":1298540,"h":304943976556,"f":1},{"r":65537,"p":[{"n":"serverCertificate","p":28168653}],"n":"AuthenticateAsServer","o":"@$1","d":1298540,"h":309238943852,"f":129},{"r":65537,"p":[{"n":"serverCertificate","p":28168653},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServer","o":"@$2","d":1298540,"h":313533911148,"f":129},{"r":65537,"p":[{"n":"serverCertificate","p":28168653},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5612018},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServer","o":"@$3","d":1298540,"h":317828878444,"f":129},{"r":133300225,"p":[{"n":"optionsCallback","p":905324},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsServerAsync","d":1298540,"h":322123845740,"f":1},{"r":133300225,"p":[{"n":"sslServerAuthenticationOptions","p":1233004},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsServerAsync","o":"@$1","d":1298540,"h":326418813036,"f":1},{"r":133300225,"p":[{"n":"serverCertificate","p":28168653}],"n":"AuthenticateAsServerAsync","o":"@$2","d":1298540,"h":330713780332,"f":129},{"r":133300225,"p":[{"n":"serverCertificate","p":28168653},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServerAsync","o":"@$3","d":1298540,"h":335008747628,"f":129},{"r":133300225,"p":[{"n":"serverCertificate","p":28168653},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5612018},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServerAsync","o":"@$4","d":1298540,"h":339303714924,"f":129},{"r":57016321,"p":[{"n":"targetHost","p":1310721},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","d":1298540,"h":343598682220,"f":129},{"r":57016321,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28430797},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$1","d":1298540,"h":347893649516,"f":129},{"r":57016321,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28430797},{"n":"enabledSslProtocols","p":5612018},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$2","d":1298540,"h":352188616812,"f":129},{"r":57016321,"p":[{"n":"serverCertificate","p":28168653},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","d":1298540,"h":356483584108,"f":129},{"r":57016321,"p":[{"n":"serverCertificate","p":28168653},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$1","d":1298540,"h":360778551404,"f":129},{"r":57016321,"p":[{"n":"serverCertificate","p":28168653},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5612018},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$2","d":1298540,"h":365073518700,"f":129},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginRead","d":1298540,"h":369368485996,"f":32769},{"r":57016321,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14483457},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":1298540,"h":373663453292,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1298540,"h":377958420588,"f":32772},{"r":136118273,"n":"DisposeAsync","d":1298540,"h":382253387884,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAuthenticateAsClient","d":1298540,"h":386548355180,"f":129},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAuthenticateAsServer","d":1298540,"h":390843322476,"f":129},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":1298540,"h":395138289772,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":1298540,"h":399433257068,"f":32769},{"r":65537,"n":"Flush","d":1298540,"h":408023191660,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1298540,"h":412318158956,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"NegotiateClientCertificateAsync","d":1298540,"h":416613126252,"f":129,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1298540,"h":420908093548,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1298540,"h":425203060844,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1298540,"h":429498028140,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1298540,"h":433792995436,"f":32769},{"r":655361,"n":"ReadByte","d":1298540,"h":438087962732,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":1298540,"h":442382930028,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1298540,"h":446677897324,"f":32769},{"r":133300225,"n":"ShutdownAsync","d":1298540,"h":450972864620,"f":129},{"r":65537,"p":[{"n":"buffer","p":0}],"n":"Write","o":"@$2","d":1298540,"h":455267831916,"f":1},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1298540,"h":459562799212,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":1298540,"h":463857766508,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1298540,"h":468152733804,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1298540,"h":472447701100,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":1298540,"h":476742668396,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62193665}],"n":".ctor","o":"$ctor$4","d":1298540,"h":4296265836,"f":1},{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":1298540,"h":8591233132,"f":1},{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":774252}],"n":".ctor","o":"$ctor$6","d":1298540,"h":12886200428,"f":1},{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":774252},{"n":"userCertificateSelectionCallback","p":315500}],"n":".ctor","o":"$ctor$7","d":1298540,"h":17181167724,"f":1},{"p":[{"n":"innerStream","p":62193665},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":774252},{"n":"userCertificateSelectionCallback","p":315500},{"n":"encryptionPolicy","p":249964}],"n":".ctor","o":"$ctor$8","d":1298540,"h":21476135020,"f":1}],"i":[57540609,56950785],"h":1298540}; }
            static get $b() { return $.$snsc.System.Net.Security.AuthenticatedStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.SslStream`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.AuthenticationException", ($self) => class AuthenticationException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$12(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            static $h = 1495148;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":1495148}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.AuthenticationException`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.InvalidCredentialException", ($self) => class InvalidCredentialException extends $.$snsc.System.Security.Authentication.AuthenticationException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$14(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$16(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            static $h = 1822828;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1495148,"h":1822828}; }
            static get $b() { return $.$snsc.System.Security.Authentication.AuthenticationException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.InvalidCredentialException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Runtime.InteropServices", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Collections.Immutable", "NetJs.System.Collections.NonGeneric", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Reflection.Metadata", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Runtime.Numerics", "NetJs.System.Formats.Asn1", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography"))