
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $srn, $ssc, $sris, $scsl, $sfa, $sic, $sim, $sl, $snp, $sspw, $sci, $sdd, $srm, $snnr, $sds, $sns, $sscr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Security", 
    {"h":33541,"f":"System.Net.Security","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002B5b8aaafb3aebad7fc7141c6e509af03c92d8b793","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Security","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Security","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snsc.System.Net.Security.AuthenticatedStream", ($self) => class AuthenticatedStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.IO.Stream */ get InnerStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get LeaveInnerStreamOpen()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 99077;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":62128129,"g":{"r":0,"d":0,"h":12885000965,"f":4},"n":"InnerStream","d":99077,"h":8590033669,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":21474935557,"f":257},"n":"IsAuthenticated","d":99077,"h":17179968261,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":30064870149,"f":257},"n":"IsEncrypted","d":99077,"h":25769902853,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":38654804741,"f":257},"n":"IsMutuallyAuthenticated","d":99077,"h":34359837445,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":47244739333,"f":257},"n":"IsServer","d":99077,"h":42949772037,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":55834673925,"f":257},"n":"IsSigned","d":99077,"h":51539706629,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":64424608517,"f":1},"n":"LeaveInnerStreamOpen","d":99077,"h":60129641221,"f":1}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":99077,"h":68719575813,"f":32772},{"r":136118273,"n":"DisposeAsync","d":99077,"h":73014543109,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":99077,"h":4295066373,"f":4}],"i":[57475073,56885249],"h":99077}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.AuthenticatedStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.CipherSuitesPolicy", ($self) => class CipherSuitesPolicy extends $.$spc.System.Object
        {
            $ctor$1(/*System.Collections.Generic.IEnumerable<System.Net.Security.TlsCipherSuite>*/ allowedCipherSuites)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.Generic.IEnumerable<System.Net.Security.TlsCipherSuite> */ get AllowedCipherSuites()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 164613;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$snsc.System.Net.Security.TlsCipherSuite).$h,"g":{"r":0,"d":0,"h":12885066501,"f":1},"n":"AllowedCipherSuites","d":164613,"h":8590099205,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}],"c":[{"p":[{"n":"allowedCipherSuites","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$snsc.System.Net.Security.TlsCipherSuite).$h}],"n":".ctor","o":"$ctor$1","d":164613,"h":4295131909,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}],"h":164613,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"windows","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.CipherSuitesPolicy`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthenticationClientOptions", ($self) => class NegotiateAuthenticationClientOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get AllowedImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set AllowedImpersonationLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get Binding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ set Binding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ get Credential()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ set Credential(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Package(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get RequiredProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ set RequiredProtectionLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RequireMutualAuthentication()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RequireMutualAuthentication(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TargetName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 426757;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":117243905,"g":{"r":0,"d":0,"h":12885328645,"f":1},"s":{"r":0,"d":0,"h":17180295941,"f":1},"n":"AllowedImpersonationLevel","d":426757,"h":8590361349,"f":1},{"p":5431052,"g":{"r":0,"d":0,"h":25770230533,"f":1},"s":{"r":0,"d":0,"h":30065197829,"f":1},"n":"Binding","d":426757,"h":21475263237,"f":1},{"p":3858188,"g":{"r":0,"d":0,"h":38655132421,"f":1},"s":{"r":0,"d":0,"h":42950099717,"f":1},"n":"Credential","d":426757,"h":34360165125,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540034309,"f":1},"s":{"r":0,"d":0,"h":55835001605,"f":1},"n":"Package","d":426757,"h":47245067013,"f":1},{"p":688901,"g":{"r":0,"d":0,"h":64424936197,"f":1},"s":{"r":0,"d":0,"h":68719903493,"f":1},"n":"RequiredProtectionLevel","d":426757,"h":60129968901,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77309838085,"f":1},"s":{"r":0,"d":0,"h":81604805381,"f":1},"n":"RequireMutualAuthentication","d":426757,"h":73014870789,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90194739973,"f":1},"s":{"r":0,"d":0,"h":94489707269,"f":1},"n":"TargetName","d":426757,"h":85899772677,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":426757,"h":4295394053,"f":1}],"h":426757}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationClientOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthenticationServerOptions", ($self) => class NegotiateAuthenticationServerOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get Binding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ set Binding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ get Credential()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ set Credential(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Package(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy? */ get Policy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy? */ set Policy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get RequiredImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set RequiredImpersonationLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get RequiredProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ set RequiredProtectionLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 492293;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5431052,"g":{"r":0,"d":0,"h":12885394181,"f":1},"s":{"r":0,"d":0,"h":17180361477,"f":1},"n":"Binding","d":492293,"h":8590426885,"f":1},{"p":3858188,"g":{"r":0,"d":0,"h":25770296069,"f":1},"s":{"r":0,"d":0,"h":30065263365,"f":1},"n":"Credential","d":492293,"h":21475328773,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38655197957,"f":1},"s":{"r":0,"d":0,"h":42950165253,"f":1},"n":"Package","d":492293,"h":34360230661,"f":1},{"p":1540869,"g":{"r":0,"d":0,"h":51540099845,"f":1},"s":{"r":0,"d":0,"h":55835067141,"f":1},"n":"Policy","d":492293,"h":47245132549,"f":1},{"p":117243905,"g":{"r":0,"d":0,"h":64425001733,"f":1},"s":{"r":0,"d":0,"h":68719969029,"f":1},"n":"RequiredImpersonationLevel","d":492293,"h":60130034437,"f":1},{"p":688901,"g":{"r":0,"d":0,"h":77309903621,"f":1},"s":{"r":0,"d":0,"h":81604870917,"f":1},"n":"RequiredProtectionLevel","d":492293,"h":73014936325,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":492293,"h":4295459589,"f":1}],"h":492293}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationServerOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslCertificateTrust", ($self) => class SslCertificateTrust extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*System.Net.Security.SslCertificateTrust */ CreateForX509Collection(/*System.Security.Cryptography.X509Certificates.X509Certificate2Collection*/ trustList, /*bool*/ sendTrustInHandshake)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslCertificateTrust */ CreateForX509Store(/*System.Security.Cryptography.X509Certificates.X509Store*/ store, /*bool*/ sendTrustInHandshake)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1016581;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1016581,"p":[{"n":"trustList","p":28280350},{"n":"sendTrustInHandshake","p":262145,"f":65,"v":false}],"n":"CreateForX509Collection","d":1016581,"h":8590951173,"f":33},{"r":1016581,"p":[{"n":"store","p":30443038},{"n":"sendTrustInHandshake","p":262145,"f":65,"v":false}],"n":"CreateForX509Store","d":1016581,"h":12885918469,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1016581,"h":4295983877,"f":8}],"h":1016581}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslCertificateTrust`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslClientAuthenticationOptions", ($self) => class SslClientAuthenticationOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AllowRenegotiation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRenegotiation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPkcs1Padding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPkcs1Padding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPssPadding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPssPadding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowTlsResume()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowTlsResume(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ get ApplicationProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ set ApplicationProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ get CertificateChainPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ set CertificateChainPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ get CertificateRevocationCheckMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ set CertificateRevocationCheckMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ get CipherSuitesPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ set CipherSuitesPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ get ClientCertificateContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ set ClientCertificateContext(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection? */ get ClientCertificates()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection? */ set ClientCertificates(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get EnabledSslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ set EnabledSslProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ set EncryptionPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.LocalCertificateSelectionCallback? */ get LocalCertificateSelectionCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.LocalCertificateSelectionCallback? */ set LocalCertificateSelectionCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get RemoteCertificateValidationCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set RemoteCertificateValidationCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetHost()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TargetHost(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1082117;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885984005,"f":1},"s":{"r":0,"d":0,"h":17180951301,"f":1},"n":"AllowRenegotiation","d":1082117,"h":8591016709,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770885893,"f":1},"s":{"r":0,"d":0,"h":30065853189,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPkcs1Padding","d":1082117,"h":21475918597,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655787781,"f":1},"s":{"r":0,"d":0,"h":42950755077,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPssPadding","d":1082117,"h":34360820485,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540689669,"f":1},"s":{"r":0,"d":0,"h":55835656965,"f":1},"n":"AllowTlsResume","d":1082117,"h":47245722373,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":64425591557,"f":1},"s":{"r":0,"d":0,"h":68720558853,"f":1},"n":"ApplicationProtocols","d":1082117,"h":60130624261,"f":1},{"p":29132318,"g":{"r":0,"d":0,"h":77310493445,"f":1},"s":{"r":0,"d":0,"h":81605460741,"f":1},"n":"CertificateChainPolicy","d":1082117,"h":73015526149,"f":1},{"p":30246430,"g":{"r":0,"d":0,"h":90195395333,"f":1},"s":{"r":0,"d":0,"h":94490362629,"f":1},"n":"CertificateRevocationCheckMode","d":1082117,"h":85900428037,"f":1},{"p":164613,"g":{"r":0,"d":0,"h":103080297221,"f":1},"s":{"r":0,"d":0,"h":107375264517,"f":1},"n":"CipherSuitesPolicy","d":1082117,"h":98785329925,"f":1},{"p":1344261,"g":{"r":0,"d":0,"h":115965199109,"f":1},"s":{"r":0,"d":0,"h":120260166405,"f":1},"n":"ClientCertificateContext","d":1082117,"h":111670231813,"f":1},{"p":28411422,"g":{"r":0,"d":0,"h":128850100997,"f":1},"s":{"r":0,"d":0,"h":133145068293,"f":1},"n":"ClientCertificates","d":1082117,"h":124555133701,"f":1},{"p":5627660,"g":{"r":0,"d":0,"h":141735002885,"f":1},"s":{"r":0,"d":0,"h":146029970181,"f":1},"n":"EnabledSslProtocols","d":1082117,"h":137440035589,"f":1},{"p":230149,"g":{"r":0,"d":0,"h":154619904773,"f":1},"s":{"r":0,"d":0,"h":158914872069,"f":1},"n":"EncryptionPolicy","d":1082117,"h":150324937477,"f":1},{"p":295685,"g":{"r":0,"d":0,"h":167504806661,"f":1},"s":{"r":0,"d":0,"h":171799773957,"f":1},"n":"LocalCertificateSelectionCallback","d":1082117,"h":163209839365,"f":1},{"p":754437,"g":{"r":0,"d":0,"h":180389708549,"f":1},"s":{"r":0,"d":0,"h":184684675845,"f":1},"n":"RemoteCertificateValidationCallback","d":1082117,"h":176094741253,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":193274610437,"f":1},"s":{"r":0,"d":0,"h":197569577733,"f":1},"n":"TargetHost","d":1082117,"h":188979643141,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1082117,"h":4296049413,"f":1}],"h":1082117}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslClientAuthenticationOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslServerAuthenticationOptions", ($self) => class SslServerAuthenticationOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AllowRenegotiation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRenegotiation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPkcs1Padding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPkcs1Padding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPssPadding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPssPadding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowTlsResume()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowTlsResume(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ get ApplicationProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ set ApplicationProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ get CertificateChainPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ set CertificateChainPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ get CertificateRevocationCheckMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ set CertificateRevocationCheckMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ get CipherSuitesPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ set CipherSuitesPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ClientCertificateRequired()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ClientCertificateRequired(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get EnabledSslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ set EnabledSslProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ set EncryptionPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get RemoteCertificateValidationCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set RemoteCertificateValidationCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get ServerCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ set ServerCertificate(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ get ServerCertificateContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ set ServerCertificateContext(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ServerCertificateSelectionCallback? */ get ServerCertificateSelectionCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ServerCertificateSelectionCallback? */ set ServerCertificateSelectionCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1213189;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886115077,"f":1},"s":{"r":0,"d":0,"h":17181082373,"f":1},"n":"AllowRenegotiation","d":1213189,"h":8591147781,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25771016965,"f":1},"s":{"r":0,"d":0,"h":30065984261,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPkcs1Padding","d":1213189,"h":21476049669,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655918853,"f":1},"s":{"r":0,"d":0,"h":42950886149,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPssPadding","d":1213189,"h":34360951557,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540820741,"f":1},"s":{"r":0,"d":0,"h":55835788037,"f":1},"n":"AllowTlsResume","d":1213189,"h":47245853445,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":64425722629,"f":1},"s":{"r":0,"d":0,"h":68720689925,"f":1},"n":"ApplicationProtocols","d":1213189,"h":60130755333,"f":1},{"p":29132318,"g":{"r":0,"d":0,"h":77310624517,"f":1},"s":{"r":0,"d":0,"h":81605591813,"f":1},"n":"CertificateChainPolicy","d":1213189,"h":73015657221,"f":1},{"p":30246430,"g":{"r":0,"d":0,"h":90195526405,"f":1},"s":{"r":0,"d":0,"h":94490493701,"f":1},"n":"CertificateRevocationCheckMode","d":1213189,"h":85900559109,"f":1},{"p":164613,"g":{"r":0,"d":0,"h":103080428293,"f":1},"s":{"r":0,"d":0,"h":107375395589,"f":1},"n":"CipherSuitesPolicy","d":1213189,"h":98785460997,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115965330181,"f":1},"s":{"r":0,"d":0,"h":120260297477,"f":1},"n":"ClientCertificateRequired","d":1213189,"h":111670362885,"f":1},{"p":5627660,"g":{"r":0,"d":0,"h":128850232069,"f":1},"s":{"r":0,"d":0,"h":133145199365,"f":1},"n":"EnabledSslProtocols","d":1213189,"h":124555264773,"f":1},{"p":230149,"g":{"r":0,"d":0,"h":141735133957,"f":1},"s":{"r":0,"d":0,"h":146030101253,"f":1},"n":"EncryptionPolicy","d":1213189,"h":137440166661,"f":1},{"p":754437,"g":{"r":0,"d":0,"h":154620035845,"f":1},"s":{"r":0,"d":0,"h":158915003141,"f":1},"n":"RemoteCertificateValidationCallback","d":1213189,"h":150325068549,"f":1},{"p":28149278,"g":{"r":0,"d":0,"h":167504937733,"f":1},"s":{"r":0,"d":0,"h":171799905029,"f":1},"n":"ServerCertificate","d":1213189,"h":163209970437,"f":1},{"p":1344261,"g":{"r":0,"d":0,"h":180389839621,"f":1},"s":{"r":0,"d":0,"h":184684806917,"f":1},"n":"ServerCertificateContext","d":1213189,"h":176094872325,"f":1},{"p":819973,"g":{"r":0,"d":0,"h":193274741509,"f":1},"s":{"r":0,"d":0,"h":197569708805,"f":1},"n":"ServerCertificateSelectionCallback","d":1213189,"h":188979774213,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1213189,"h":4296180485,"f":1}],"h":1213189}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslServerAuthenticationOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslStreamCertificateContext", ($self) => class SslStreamCertificateContext extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.ObjectModel.ReadOnlyCollection<System.Security.Cryptography.X509Certificates.X509Certificate2> */ get IntermediateCertificates()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate2 */ get TargetCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslStreamCertificateContext */ Create(/*System.Security.Cryptography.X509Certificates.X509Certificate2*/ target, /*System.Security.Cryptography.X509Certificates.X509Certificate2Collection?*/ additionalCertificates, /*bool*/ offline)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslStreamCertificateContext */ Create$1(/*System.Security.Cryptography.X509Certificates.X509Certificate2*/ target, /*System.Security.Cryptography.X509Certificates.X509Certificate2Collection?*/ additionalCertificates, /*bool*/ offline, /*System.Net.Security.SslCertificateTrust?*/ trust)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1344261;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sscr.System.Security.Cryptography.X509Certificates.X509Certificate2).$h,"g":{"r":0,"d":0,"h":12886246149,"f":1},"n":"IntermediateCertificates","d":1344261,"h":8591278853,"f":1},{"p":28214814,"g":{"r":0,"d":0,"h":21476180741,"f":1},"n":"TargetCertificate","d":1344261,"h":17181213445,"f":1}],"m":[{"r":1344261,"p":[{"n":"target","p":28214814},{"n":"additionalCertificates","p":28280350},{"n":"offline","p":262145}],"n":"Create","d":1344261,"h":25771148037,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":1344261,"p":[{"n":"target","p":28214814},{"n":"additionalCertificates","p":28280350},{"n":"offline","p":262145,"f":65,"v":false},{"n":"trust","p":1016581,"f":65}],"n":"Create","o":"@$1","d":1344261,"h":30066115333,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1344261,"h":4296311557,"f":8}],"h":1344261}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslStreamCertificateContext`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthentication", ($self) => class NegotiateAuthentication extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.Security.NegotiateAuthenticationClientOptions*/ clientOptions)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.Security.NegotiateAuthenticationServerOptions*/ serverOptions)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get ProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get RemoteIdentity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ ComputeIntegrityCheck(/*System.ReadOnlySpan<byte>*/ message, /*System.Buffers.IBufferWriter<byte>*/ signatureWriter)
            {
            }
            /*void */ Dispose()
            {
            }
            /*byte[]? */ GetOutgoingBlob(/*System.ReadOnlySpan<byte>*/ incomingBlob, /*out System.Net.Security.NegotiateAuthenticationStatusCode*/ statusCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ GetOutgoingBlob$1(/*string?*/ incomingBlob, /*out System.Net.Security.NegotiateAuthenticationStatusCode*/ statusCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ Unwrap(/*System.ReadOnlySpan<byte>*/ input, /*System.Buffers.IBufferWriter<byte>*/ outputWriter, /*out bool*/ wasEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ UnwrapInPlace(/*System.Span<byte>*/ input, /*out int*/ unwrappedOffset, /*out int*/ unwrappedLength, /*out bool*/ wasEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ VerifyIntegrityCheck(/*System.ReadOnlySpan<byte>*/ message, /*System.ReadOnlySpan<byte>*/ signature)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ Wrap(/*System.ReadOnlySpan<byte>*/ input, /*System.Buffers.IBufferWriter<byte>*/ outputWriter, /*bool*/ requestEncryption, /*out bool*/ isEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 361221;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":117243905,"g":{"r":0,"d":0,"h":17180230405,"f":1},"n":"ImpersonationLevel","d":361221,"h":12885263109,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770164997,"f":1},"n":"IsAuthenticated","d":361221,"h":21475197701,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360099589,"f":1},"n":"IsEncrypted","d":361221,"h":30065132293,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950034181,"f":1},"n":"IsMutuallyAuthenticated","d":361221,"h":38655066885,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51539968773,"f":1},"n":"IsServer","d":361221,"h":47245001477,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60129903365,"f":1},"n":"IsSigned","d":361221,"h":55834936069,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":68719837957,"f":1},"n":"Package","d":361221,"h":64424870661,"f":1},{"p":688901,"g":{"r":0,"d":0,"h":77309772549,"f":1},"n":"ProtectionLevel","d":361221,"h":73014805253,"f":1},{"p":117047297,"g":{"r":0,"d":0,"h":85899707141,"f":1},"n":"RemoteIdentity","d":361221,"h":81604739845,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":94489641733,"f":1},"n":"TargetName","d":361221,"h":90194674437,"f":1}],"m":[{"r":65537,"p":[{"n":"message","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"signatureWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h}],"n":"ComputeIntegrityCheck","d":361221,"h":98784609029,"f":1},{"r":65537,"n":"Dispose","d":361221,"h":103079576325,"f":1},{"r":0,"p":[{"n":"incomingBlob","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"statusCode","p":557829,"f":2}],"n":"GetOutgoingBlob","d":361221,"h":107374543621,"f":1},{"r":1310721,"p":[{"n":"incomingBlob","p":1310721},{"n":"statusCode","p":557829,"f":2}],"n":"GetOutgoingBlob","o":"@$1","d":361221,"h":111669510917,"f":1},{"r":557829,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"outputWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h},{"n":"wasEncrypted","p":262145,"f":2}],"n":"Unwrap","d":361221,"h":115964478213,"f":1},{"r":557829,"p":[{"n":"input","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"unwrappedOffset","p":655361,"f":2},{"n":"unwrappedLength","p":655361,"f":2},{"n":"wasEncrypted","p":262145,"f":2}],"n":"UnwrapInPlace","d":361221,"h":120259445509,"f":1},{"r":262145,"p":[{"n":"message","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"signature","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"VerifyIntegrityCheck","d":361221,"h":124554412805,"f":1},{"r":557829,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"outputWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h},{"n":"requestEncryption","p":262145},{"n":"isEncrypted","p":262145,"f":2}],"n":"Wrap","d":361221,"h":128849380101,"f":1}],"c":[{"p":[{"n":"clientOptions","p":426757}],"n":".ctor","o":"$ctor$1","d":361221,"h":4295328517,"f":1},{"p":[{"n":"serverOptions","p":492293}],"n":".ctor","o":"$ctor$2","d":361221,"h":8590295813,"f":1}],"i":[57475073],"h":361221}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthentication`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy", ($self) => class ExtendedProtectionPolicy extends $.$spc.System.Object
        {
            $ctor$1(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ChannelBinding*/ customChannelBinding)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ProtectionScenario*/ protectionScenario, /*System.Collections.ICollection?*/ customServiceNames)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ProtectionScenario*/ protectionScenario, /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection?*/ customServiceNames)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get CustomChannelBinding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection? */ get CustomServiceNames()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsExtendedProtection()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.PolicyEnforcement */ get PolicyEnforcement()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ProtectionScenario */ get ProtectionScenario()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo?*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snsc.System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy.ToString.apply(this, arguments); }
            static $h = 1540869;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5431052,"g":{"r":0,"d":0,"h":30066311941,"f":1},"n":"CustomChannelBinding","d":1540869,"h":25771344645,"f":1},{"p":1737477,"g":{"r":0,"d":0,"h":38656246533,"f":1},"n":"CustomServiceNames","d":1540869,"h":34361279237,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47246181125,"f":33},"n":"OSSupportsExtendedProtection","d":1540869,"h":42951213829,"f":33},{"p":1606405,"g":{"r":0,"d":0,"h":55836115717,"f":1},"n":"PolicyEnforcement","d":1540869,"h":51541148421,"f":1},{"p":1671941,"g":{"r":0,"d":0,"h":64426050309,"f":1},"n":"ProtectionScenario","d":1540869,"h":60131083013,"f":1}],"m":[{"r":1310721,"n":"ToString","d":1540869,"h":73015984901,"f":32769}],"c":[{"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$1","d":1540869,"h":4296508165,"f":4,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":[{"n":"policyEnforcement","p":1606405}],"n":".ctor","o":"$ctor$2","d":1540869,"h":8591475461,"f":1},{"p":[{"n":"policyEnforcement","p":1606405},{"n":"customChannelBinding","p":5431052}],"n":".ctor","o":"$ctor$3","d":1540869,"h":12886442757,"f":1},{"p":[{"n":"policyEnforcement","p":1606405},{"n":"protectionScenario","p":1671941},{"n":"customServiceNames","p":31326209}],"n":".ctor","o":"$ctor$4","d":1540869,"h":17181410053,"f":1},{"p":[{"n":"policyEnforcement","p":1606405},{"n":"protectionScenario","p":1671941},{"n":"customServiceNames","p":1737477}],"n":".ctor","o":"$ctor$5","d":1540869,"h":21476377349,"f":1}],"i":[113377281],"h":1540869}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.SslClientHelloInfo", ($self) => class SslClientHelloInfo extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            $ctor$2(/*string*/ serverName, /*System.Security.Authentication.SslProtocols*/ sslProtocols)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*string */ get ServerName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 1147653;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21475984133,"f":1},"n":"ServerName","d":1147653,"h":17181016837,"f":1},{"p":5627660,"g":{"r":0,"d":0,"h":30065918725,"f":1},"n":"SslProtocols","d":1147653,"h":25770951429,"f":1}],"l":[{"t":131073,"n":"_dummy","d":1147653,"h":4296114949,"f":2},{"t":655361,"n":"_dummyPrimitive","d":1147653,"h":8591082245,"f":2}],"c":[{"p":[{"n":"serverName","p":1310721},{"n":"sslProtocols","p":5627660}],"n":".ctor","o":"$ctor$2","d":1147653,"h":12886049541,"f":1},{"n":".ctor","o":"$ctor$3","d":1147653,"h":34360886021,"f":1}],"h":1147653}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Security.SslClientHelloInfo`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.SslApplicationProtocol", ($self) => class SslApplicationProtocol extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.Security.SslApplicationProtocol*/ static Http11;
            /*System.Net.Security.SslApplicationProtocol*/ static Http2;
            /*System.Net.Security.SslApplicationProtocol*/ static Http3;
            $ctor$2(/*byte[]*/ protocol)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            $ctor$3(/*string*/ protocol)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*System.ReadOnlyMemory<byte> */ get Protocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Security.SslApplicationProtocol*/ other)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snsc.System.Net.Security.SslApplicationProtocol.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snsc.System.Net.Security.SslApplicationProtocol.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Security.SslApplicationProtocol*/ left, /*System.Net.Security.SslApplicationProtocol*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Security.SslApplicationProtocol*/ left, /*System.Net.Security.SslApplicationProtocol*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snsc.System.Net.Security.SslApplicationProtocol.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Net.Security.SslApplicationProtocol>.Equals(System.Net.Security.SslApplicationProtocol)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Http11 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
                {
                    this.Http2 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
                {
                    this.Http3 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
            }
            static $h = 951045;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":38655656709,"f":1},"n":"Protocol","d":951045,"h":34360689413,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":951045}],"n":"Equals","o":"@$2","d":951045,"h":42950624005,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":951045,"h":47245591301,"f":32769},{"r":655361,"n":"GetHashCode","d":951045,"h":51540558597,"f":32769},{"r":1310721,"n":"ToString","d":951045,"h":64425460485,"f":32769}],"l":[{"t":131073,"n":"_dummy","d":951045,"h":4295918341,"f":2},{"t":655361,"n":"_dummyPrimitive","d":951045,"h":8590885637,"f":2},{"t":951045,"n":"Http11","d":951045,"h":12885852933,"f":33},{"t":951045,"n":"Http2","d":951045,"h":17180820229,"f":33},{"t":951045,"n":"Http3","d":951045,"h":21475787525,"f":33}],"c":[{"p":[{"n":"protocol","p":0}],"n":".ctor","o":"$ctor$2","d":951045,"h":25770754821,"f":1},{"p":[{"n":"protocol","p":1310721}],"n":".ctor","o":"$ctor$3","d":951045,"h":30065722117,"f":1},{"n":".ctor","o":"$ctor$4","d":951045,"h":68720427781,"f":1}],"i":[$.$spc.System.IEquatable$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h],"h":951045}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$snsc.System.Net.Security.SslApplicationProtocol) ]; }
            static get $fullName() { return `System.Net.Security.SslApplicationProtocol`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.ExtendedProtection.ServiceNameCollection", ($self) => class ServiceNameCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2(/*System.Collections.ICollection*/ items)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ Contains(/*string?*/ searchServiceName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection */ Merge(/*System.Collections.IEnumerable*/ serviceNames)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection */ Merge$1(/*string*/ serviceName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1737477;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"m":[{"r":262145,"p":[{"n":"searchServiceName","p":1310721}],"n":"Contains","d":1737477,"h":8591672069,"f":1},{"r":1737477,"p":[{"n":"serviceNames","p":31588353}],"n":"Merge","d":1737477,"h":12886639365,"f":1},{"r":1737477,"p":[{"n":"serviceName","p":1310721}],"n":"Merge","o":"@$1","d":1737477,"h":17181606661,"f":1}],"c":[{"p":[{"n":"items","p":31326209}],"n":".ctor","o":"$ctor$2","d":1737477,"h":4296704773,"f":1}],"i":[31326209,31588353],"h":1737477}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ServiceNameCollection`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.EncryptionPolicy", ($self) => class EncryptionPolicy extends $.$spc.System.Enum
        {
            static RequireEncryption = 0;
            static AllowNoEncryption = 1;
            static NoEncryption = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "RequireEncryption": 0n,
                    "AllowNoEncryption": 1n,
                    "NoEncryption": 2n
                };
            }
            static $h = 230149;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":230149,"n":"RequireEncryption","d":230149,"h":4295197445,"f":33},{"t":230149,"n":"AllowNoEncryption","d":230149,"h":8590164741,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0040","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"t":230149,"n":"NoEncryption","d":230149,"h":12885132037,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0040","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":230149,"h":17180099333,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":230149}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.EncryptionPolicy`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.NegotiateAuthenticationStatusCode", ($self) => class NegotiateAuthenticationStatusCode extends $.$spc.System.Enum
        {
            static Completed = 0;
            static ContinueNeeded = 1;
            static GenericFailure = 2;
            static BadBinding = 3;
            static Unsupported = 4;
            static MessageAltered = 5;
            static ContextExpired = 6;
            static CredentialsExpired = 7;
            static InvalidCredentials = 8;
            static InvalidToken = 9;
            static UnknownCredentials = 10;
            static QopNotSupported = 11;
            static OutOfSequence = 12;
            static SecurityQosFailed = 13;
            static TargetUnknown = 14;
            static ImpersonationValidationFailed = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Completed": 0n,
                    "ContinueNeeded": 1n,
                    "GenericFailure": 2n,
                    "BadBinding": 3n,
                    "Unsupported": 4n,
                    "MessageAltered": 5n,
                    "ContextExpired": 6n,
                    "CredentialsExpired": 7n,
                    "InvalidCredentials": 8n,
                    "InvalidToken": 9n,
                    "UnknownCredentials": 10n,
                    "QopNotSupported": 11n,
                    "OutOfSequence": 12n,
                    "SecurityQosFailed": 13n,
                    "TargetUnknown": 14n,
                    "ImpersonationValidationFailed": 15n
                };
            }
            static $h = 557829;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":557829,"n":"Completed","d":557829,"h":4295525125,"f":33},{"t":557829,"n":"ContinueNeeded","d":557829,"h":8590492421,"f":33},{"t":557829,"n":"GenericFailure","d":557829,"h":12885459717,"f":33},{"t":557829,"n":"BadBinding","d":557829,"h":17180427013,"f":33},{"t":557829,"n":"Unsupported","d":557829,"h":21475394309,"f":33},{"t":557829,"n":"MessageAltered","d":557829,"h":25770361605,"f":33},{"t":557829,"n":"ContextExpired","d":557829,"h":30065328901,"f":33},{"t":557829,"n":"CredentialsExpired","d":557829,"h":34360296197,"f":33},{"t":557829,"n":"InvalidCredentials","d":557829,"h":38655263493,"f":33},{"t":557829,"n":"InvalidToken","d":557829,"h":42950230789,"f":33},{"t":557829,"n":"UnknownCredentials","d":557829,"h":47245198085,"f":33},{"t":557829,"n":"QopNotSupported","d":557829,"h":51540165381,"f":33},{"t":557829,"n":"OutOfSequence","d":557829,"h":55835132677,"f":33},{"t":557829,"n":"SecurityQosFailed","d":557829,"h":60130099973,"f":33},{"t":557829,"n":"TargetUnknown","d":557829,"h":64425067269,"f":33},{"t":557829,"n":"ImpersonationValidationFailed","d":557829,"h":68720034565,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":557829,"h":73015001861,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":557829}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationStatusCode`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.ProtectionLevel", ($self) => class ProtectionLevel extends $.$spc.System.Enum
        {
            static None = 0;
            static Sign = 1;
            static EncryptAndSign = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Sign": 1n,
                    "EncryptAndSign": 2n
                };
            }
            static $h = 688901;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":688901,"n":"None","d":688901,"h":4295656197,"f":33},{"t":688901,"n":"Sign","d":688901,"h":8590623493,"f":33},{"t":688901,"n":"EncryptAndSign","d":688901,"h":12885590789,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":688901,"h":17180558085,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":688901}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.ProtectionLevel`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.TlsCipherSuite", ($self) => class TlsCipherSuite extends $.$spc.System.Enum
        {
            static TLS_NULL_WITH_NULL_NULL = 0;
            static TLS_RSA_WITH_NULL_MD5 = 1;
            static TLS_RSA_WITH_NULL_SHA = 2;
            static TLS_RSA_EXPORT_WITH_RC4_40_MD5 = 3;
            static TLS_RSA_WITH_RC4_128_MD5 = 4;
            static TLS_RSA_WITH_RC4_128_SHA = 5;
            static TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5 = 6;
            static TLS_RSA_WITH_IDEA_CBC_SHA = 7;
            static TLS_RSA_EXPORT_WITH_DES40_CBC_SHA = 8;
            static TLS_RSA_WITH_DES_CBC_SHA = 9;
            static TLS_RSA_WITH_3DES_EDE_CBC_SHA = 10;
            static TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA = 11;
            static TLS_DH_DSS_WITH_DES_CBC_SHA = 12;
            static TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA = 13;
            static TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA = 14;
            static TLS_DH_RSA_WITH_DES_CBC_SHA = 15;
            static TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA = 16;
            static TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA = 17;
            static TLS_DHE_DSS_WITH_DES_CBC_SHA = 18;
            static TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA = 19;
            static TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA = 20;
            static TLS_DHE_RSA_WITH_DES_CBC_SHA = 21;
            static TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA = 22;
            static TLS_DH_anon_EXPORT_WITH_RC4_40_MD5 = 23;
            static TLS_DH_anon_WITH_RC4_128_MD5 = 24;
            static TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA = 25;
            static TLS_DH_anon_WITH_DES_CBC_SHA = 26;
            static TLS_DH_anon_WITH_3DES_EDE_CBC_SHA = 27;
            static TLS_KRB5_WITH_DES_CBC_SHA = 30;
            static TLS_KRB5_WITH_3DES_EDE_CBC_SHA = 31;
            static TLS_KRB5_WITH_RC4_128_SHA = 32;
            static TLS_KRB5_WITH_IDEA_CBC_SHA = 33;
            static TLS_KRB5_WITH_DES_CBC_MD5 = 34;
            static TLS_KRB5_WITH_3DES_EDE_CBC_MD5 = 35;
            static TLS_KRB5_WITH_RC4_128_MD5 = 36;
            static TLS_KRB5_WITH_IDEA_CBC_MD5 = 37;
            static TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA = 38;
            static TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA = 39;
            static TLS_KRB5_EXPORT_WITH_RC4_40_SHA = 40;
            static TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5 = 41;
            static TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5 = 42;
            static TLS_KRB5_EXPORT_WITH_RC4_40_MD5 = 43;
            static TLS_PSK_WITH_NULL_SHA = 44;
            static TLS_DHE_PSK_WITH_NULL_SHA = 45;
            static TLS_RSA_PSK_WITH_NULL_SHA = 46;
            static TLS_RSA_WITH_AES_128_CBC_SHA = 47;
            static TLS_DH_DSS_WITH_AES_128_CBC_SHA = 48;
            static TLS_DH_RSA_WITH_AES_128_CBC_SHA = 49;
            static TLS_DHE_DSS_WITH_AES_128_CBC_SHA = 50;
            static TLS_DHE_RSA_WITH_AES_128_CBC_SHA = 51;
            static TLS_DH_anon_WITH_AES_128_CBC_SHA = 52;
            static TLS_RSA_WITH_AES_256_CBC_SHA = 53;
            static TLS_DH_DSS_WITH_AES_256_CBC_SHA = 54;
            static TLS_DH_RSA_WITH_AES_256_CBC_SHA = 55;
            static TLS_DHE_DSS_WITH_AES_256_CBC_SHA = 56;
            static TLS_DHE_RSA_WITH_AES_256_CBC_SHA = 57;
            static TLS_DH_anon_WITH_AES_256_CBC_SHA = 58;
            static TLS_RSA_WITH_NULL_SHA256 = 59;
            static TLS_RSA_WITH_AES_128_CBC_SHA256 = 60;
            static TLS_RSA_WITH_AES_256_CBC_SHA256 = 61;
            static TLS_DH_DSS_WITH_AES_128_CBC_SHA256 = 62;
            static TLS_DH_RSA_WITH_AES_128_CBC_SHA256 = 63;
            static TLS_DHE_DSS_WITH_AES_128_CBC_SHA256 = 64;
            static TLS_RSA_WITH_CAMELLIA_128_CBC_SHA = 65;
            static TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA = 66;
            static TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA = 67;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA = 68;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA = 69;
            static TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA = 70;
            static TLS_DHE_RSA_WITH_AES_128_CBC_SHA256 = 103;
            static TLS_DH_DSS_WITH_AES_256_CBC_SHA256 = 104;
            static TLS_DH_RSA_WITH_AES_256_CBC_SHA256 = 105;
            static TLS_DHE_DSS_WITH_AES_256_CBC_SHA256 = 106;
            static TLS_DHE_RSA_WITH_AES_256_CBC_SHA256 = 107;
            static TLS_DH_anon_WITH_AES_128_CBC_SHA256 = 108;
            static TLS_DH_anon_WITH_AES_256_CBC_SHA256 = 109;
            static TLS_RSA_WITH_CAMELLIA_256_CBC_SHA = 132;
            static TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA = 133;
            static TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA = 134;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA = 135;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA = 136;
            static TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA = 137;
            static TLS_PSK_WITH_RC4_128_SHA = 138;
            static TLS_PSK_WITH_3DES_EDE_CBC_SHA = 139;
            static TLS_PSK_WITH_AES_128_CBC_SHA = 140;
            static TLS_PSK_WITH_AES_256_CBC_SHA = 141;
            static TLS_DHE_PSK_WITH_RC4_128_SHA = 142;
            static TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA = 143;
            static TLS_DHE_PSK_WITH_AES_128_CBC_SHA = 144;
            static TLS_DHE_PSK_WITH_AES_256_CBC_SHA = 145;
            static TLS_RSA_PSK_WITH_RC4_128_SHA = 146;
            static TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA = 147;
            static TLS_RSA_PSK_WITH_AES_128_CBC_SHA = 148;
            static TLS_RSA_PSK_WITH_AES_256_CBC_SHA = 149;
            static TLS_RSA_WITH_SEED_CBC_SHA = 150;
            static TLS_DH_DSS_WITH_SEED_CBC_SHA = 151;
            static TLS_DH_RSA_WITH_SEED_CBC_SHA = 152;
            static TLS_DHE_DSS_WITH_SEED_CBC_SHA = 153;
            static TLS_DHE_RSA_WITH_SEED_CBC_SHA = 154;
            static TLS_DH_anon_WITH_SEED_CBC_SHA = 155;
            static TLS_RSA_WITH_AES_128_GCM_SHA256 = 156;
            static TLS_RSA_WITH_AES_256_GCM_SHA384 = 157;
            static TLS_DHE_RSA_WITH_AES_128_GCM_SHA256 = 158;
            static TLS_DHE_RSA_WITH_AES_256_GCM_SHA384 = 159;
            static TLS_DH_RSA_WITH_AES_128_GCM_SHA256 = 160;
            static TLS_DH_RSA_WITH_AES_256_GCM_SHA384 = 161;
            static TLS_DHE_DSS_WITH_AES_128_GCM_SHA256 = 162;
            static TLS_DHE_DSS_WITH_AES_256_GCM_SHA384 = 163;
            static TLS_DH_DSS_WITH_AES_128_GCM_SHA256 = 164;
            static TLS_DH_DSS_WITH_AES_256_GCM_SHA384 = 165;
            static TLS_DH_anon_WITH_AES_128_GCM_SHA256 = 166;
            static TLS_DH_anon_WITH_AES_256_GCM_SHA384 = 167;
            static TLS_PSK_WITH_AES_128_GCM_SHA256 = 168;
            static TLS_PSK_WITH_AES_256_GCM_SHA384 = 169;
            static TLS_DHE_PSK_WITH_AES_128_GCM_SHA256 = 170;
            static TLS_DHE_PSK_WITH_AES_256_GCM_SHA384 = 171;
            static TLS_RSA_PSK_WITH_AES_128_GCM_SHA256 = 172;
            static TLS_RSA_PSK_WITH_AES_256_GCM_SHA384 = 173;
            static TLS_PSK_WITH_AES_128_CBC_SHA256 = 174;
            static TLS_PSK_WITH_AES_256_CBC_SHA384 = 175;
            static TLS_PSK_WITH_NULL_SHA256 = 176;
            static TLS_PSK_WITH_NULL_SHA384 = 177;
            static TLS_DHE_PSK_WITH_AES_128_CBC_SHA256 = 178;
            static TLS_DHE_PSK_WITH_AES_256_CBC_SHA384 = 179;
            static TLS_DHE_PSK_WITH_NULL_SHA256 = 180;
            static TLS_DHE_PSK_WITH_NULL_SHA384 = 181;
            static TLS_RSA_PSK_WITH_AES_128_CBC_SHA256 = 182;
            static TLS_RSA_PSK_WITH_AES_256_CBC_SHA384 = 183;
            static TLS_RSA_PSK_WITH_NULL_SHA256 = 184;
            static TLS_RSA_PSK_WITH_NULL_SHA384 = 185;
            static TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 186;
            static TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256 = 187;
            static TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 188;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256 = 189;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 190;
            static TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256 = 191;
            static TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 192;
            static TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256 = 193;
            static TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 194;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256 = 195;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 196;
            static TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256 = 197;
            static TLS_AES_128_GCM_SHA256 = 4865;
            static TLS_AES_256_GCM_SHA384 = 4866;
            static TLS_CHACHA20_POLY1305_SHA256 = 4867;
            static TLS_AES_128_CCM_SHA256 = 4868;
            static TLS_AES_128_CCM_8_SHA256 = 4869;
            static TLS_ECDH_ECDSA_WITH_NULL_SHA = 49153;
            static TLS_ECDH_ECDSA_WITH_RC4_128_SHA = 49154;
            static TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA = 49155;
            static TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA = 49156;
            static TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA = 49157;
            static TLS_ECDHE_ECDSA_WITH_NULL_SHA = 49158;
            static TLS_ECDHE_ECDSA_WITH_RC4_128_SHA = 49159;
            static TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA = 49160;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA = 49161;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA = 49162;
            static TLS_ECDH_RSA_WITH_NULL_SHA = 49163;
            static TLS_ECDH_RSA_WITH_RC4_128_SHA = 49164;
            static TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA = 49165;
            static TLS_ECDH_RSA_WITH_AES_128_CBC_SHA = 49166;
            static TLS_ECDH_RSA_WITH_AES_256_CBC_SHA = 49167;
            static TLS_ECDHE_RSA_WITH_NULL_SHA = 49168;
            static TLS_ECDHE_RSA_WITH_RC4_128_SHA = 49169;
            static TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA = 49170;
            static TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA = 49171;
            static TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA = 49172;
            static TLS_ECDH_anon_WITH_NULL_SHA = 49173;
            static TLS_ECDH_anon_WITH_RC4_128_SHA = 49174;
            static TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA = 49175;
            static TLS_ECDH_anon_WITH_AES_128_CBC_SHA = 49176;
            static TLS_ECDH_anon_WITH_AES_256_CBC_SHA = 49177;
            static TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA = 49178;
            static TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA = 49179;
            static TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA = 49180;
            static TLS_SRP_SHA_WITH_AES_128_CBC_SHA = 49181;
            static TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA = 49182;
            static TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA = 49183;
            static TLS_SRP_SHA_WITH_AES_256_CBC_SHA = 49184;
            static TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA = 49185;
            static TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA = 49186;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256 = 49187;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384 = 49188;
            static TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256 = 49189;
            static TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384 = 49190;
            static TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256 = 49191;
            static TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384 = 49192;
            static TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256 = 49193;
            static TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384 = 49194;
            static TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256 = 49195;
            static TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384 = 49196;
            static TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256 = 49197;
            static TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384 = 49198;
            static TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 = 49199;
            static TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 = 49200;
            static TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256 = 49201;
            static TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384 = 49202;
            static TLS_ECDHE_PSK_WITH_RC4_128_SHA = 49203;
            static TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA = 49204;
            static TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA = 49205;
            static TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA = 49206;
            static TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256 = 49207;
            static TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384 = 49208;
            static TLS_ECDHE_PSK_WITH_NULL_SHA = 49209;
            static TLS_ECDHE_PSK_WITH_NULL_SHA256 = 49210;
            static TLS_ECDHE_PSK_WITH_NULL_SHA384 = 49211;
            static TLS_RSA_WITH_ARIA_128_CBC_SHA256 = 49212;
            static TLS_RSA_WITH_ARIA_256_CBC_SHA384 = 49213;
            static TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256 = 49214;
            static TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384 = 49215;
            static TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256 = 49216;
            static TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384 = 49217;
            static TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256 = 49218;
            static TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384 = 49219;
            static TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256 = 49220;
            static TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384 = 49221;
            static TLS_DH_anon_WITH_ARIA_128_CBC_SHA256 = 49222;
            static TLS_DH_anon_WITH_ARIA_256_CBC_SHA384 = 49223;
            static TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256 = 49224;
            static TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384 = 49225;
            static TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256 = 49226;
            static TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384 = 49227;
            static TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256 = 49228;
            static TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384 = 49229;
            static TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256 = 49230;
            static TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384 = 49231;
            static TLS_RSA_WITH_ARIA_128_GCM_SHA256 = 49232;
            static TLS_RSA_WITH_ARIA_256_GCM_SHA384 = 49233;
            static TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256 = 49234;
            static TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384 = 49235;
            static TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256 = 49236;
            static TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384 = 49237;
            static TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256 = 49238;
            static TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384 = 49239;
            static TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256 = 49240;
            static TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384 = 49241;
            static TLS_DH_anon_WITH_ARIA_128_GCM_SHA256 = 49242;
            static TLS_DH_anon_WITH_ARIA_256_GCM_SHA384 = 49243;
            static TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256 = 49244;
            static TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384 = 49245;
            static TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256 = 49246;
            static TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384 = 49247;
            static TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256 = 49248;
            static TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384 = 49249;
            static TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256 = 49250;
            static TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384 = 49251;
            static TLS_PSK_WITH_ARIA_128_CBC_SHA256 = 49252;
            static TLS_PSK_WITH_ARIA_256_CBC_SHA384 = 49253;
            static TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256 = 49254;
            static TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384 = 49255;
            static TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256 = 49256;
            static TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384 = 49257;
            static TLS_PSK_WITH_ARIA_128_GCM_SHA256 = 49258;
            static TLS_PSK_WITH_ARIA_256_GCM_SHA384 = 49259;
            static TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256 = 49260;
            static TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384 = 49261;
            static TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256 = 49262;
            static TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384 = 49263;
            static TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256 = 49264;
            static TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384 = 49265;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 = 49266;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 = 49267;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 = 49268;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 = 49269;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 49270;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384 = 49271;
            static TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 49272;
            static TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384 = 49273;
            static TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49274;
            static TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49275;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49276;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49277;
            static TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49278;
            static TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49279;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256 = 49280;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384 = 49281;
            static TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256 = 49282;
            static TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384 = 49283;
            static TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256 = 49284;
            static TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384 = 49285;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 = 49286;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 = 49287;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 = 49288;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 = 49289;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49290;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49291;
            static TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49292;
            static TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49293;
            static TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49294;
            static TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49295;
            static TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49296;
            static TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49297;
            static TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49298;
            static TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49299;
            static TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49300;
            static TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49301;
            static TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49302;
            static TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49303;
            static TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49304;
            static TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49305;
            static TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49306;
            static TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49307;
            static TLS_RSA_WITH_AES_128_CCM = 49308;
            static TLS_RSA_WITH_AES_256_CCM = 49309;
            static TLS_DHE_RSA_WITH_AES_128_CCM = 49310;
            static TLS_DHE_RSA_WITH_AES_256_CCM = 49311;
            static TLS_RSA_WITH_AES_128_CCM_8 = 49312;
            static TLS_RSA_WITH_AES_256_CCM_8 = 49313;
            static TLS_DHE_RSA_WITH_AES_128_CCM_8 = 49314;
            static TLS_DHE_RSA_WITH_AES_256_CCM_8 = 49315;
            static TLS_PSK_WITH_AES_128_CCM = 49316;
            static TLS_PSK_WITH_AES_256_CCM = 49317;
            static TLS_DHE_PSK_WITH_AES_128_CCM = 49318;
            static TLS_DHE_PSK_WITH_AES_256_CCM = 49319;
            static TLS_PSK_WITH_AES_128_CCM_8 = 49320;
            static TLS_PSK_WITH_AES_256_CCM_8 = 49321;
            static TLS_PSK_DHE_WITH_AES_128_CCM_8 = 49322;
            static TLS_PSK_DHE_WITH_AES_256_CCM_8 = 49323;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CCM = 49324;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CCM = 49325;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8 = 49326;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8 = 49327;
            static TLS_ECCPWD_WITH_AES_128_GCM_SHA256 = 49328;
            static TLS_ECCPWD_WITH_AES_256_GCM_SHA384 = 49329;
            static TLS_ECCPWD_WITH_AES_128_CCM_SHA256 = 49330;
            static TLS_ECCPWD_WITH_AES_256_CCM_SHA384 = 49331;
            static TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256 = 52392;
            static TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256 = 52393;
            static TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256 = 52394;
            static TLS_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52395;
            static TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52396;
            static TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52397;
            static TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52398;
            static TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256 = 53249;
            static TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384 = 53250;
            static TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256 = 53251;
            static TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256 = 53253;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TLS_NULL_WITH_NULL_NULL": 0n,
                    "TLS_RSA_WITH_NULL_MD5": 1n,
                    "TLS_RSA_WITH_NULL_SHA": 2n,
                    "TLS_RSA_EXPORT_WITH_RC4_40_MD5": 3n,
                    "TLS_RSA_WITH_RC4_128_MD5": 4n,
                    "TLS_RSA_WITH_RC4_128_SHA": 5n,
                    "TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5": 6n,
                    "TLS_RSA_WITH_IDEA_CBC_SHA": 7n,
                    "TLS_RSA_EXPORT_WITH_DES40_CBC_SHA": 8n,
                    "TLS_RSA_WITH_DES_CBC_SHA": 9n,
                    "TLS_RSA_WITH_3DES_EDE_CBC_SHA": 10n,
                    "TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA": 11n,
                    "TLS_DH_DSS_WITH_DES_CBC_SHA": 12n,
                    "TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA": 13n,
                    "TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA": 14n,
                    "TLS_DH_RSA_WITH_DES_CBC_SHA": 15n,
                    "TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA": 16n,
                    "TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA": 17n,
                    "TLS_DHE_DSS_WITH_DES_CBC_SHA": 18n,
                    "TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA": 19n,
                    "TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA": 20n,
                    "TLS_DHE_RSA_WITH_DES_CBC_SHA": 21n,
                    "TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA": 22n,
                    "TLS_DH_anon_EXPORT_WITH_RC4_40_MD5": 23n,
                    "TLS_DH_anon_WITH_RC4_128_MD5": 24n,
                    "TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA": 25n,
                    "TLS_DH_anon_WITH_DES_CBC_SHA": 26n,
                    "TLS_DH_anon_WITH_3DES_EDE_CBC_SHA": 27n,
                    "TLS_KRB5_WITH_DES_CBC_SHA": 30n,
                    "TLS_KRB5_WITH_3DES_EDE_CBC_SHA": 31n,
                    "TLS_KRB5_WITH_RC4_128_SHA": 32n,
                    "TLS_KRB5_WITH_IDEA_CBC_SHA": 33n,
                    "TLS_KRB5_WITH_DES_CBC_MD5": 34n,
                    "TLS_KRB5_WITH_3DES_EDE_CBC_MD5": 35n,
                    "TLS_KRB5_WITH_RC4_128_MD5": 36n,
                    "TLS_KRB5_WITH_IDEA_CBC_MD5": 37n,
                    "TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA": 38n,
                    "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA": 39n,
                    "TLS_KRB5_EXPORT_WITH_RC4_40_SHA": 40n,
                    "TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5": 41n,
                    "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5": 42n,
                    "TLS_KRB5_EXPORT_WITH_RC4_40_MD5": 43n,
                    "TLS_PSK_WITH_NULL_SHA": 44n,
                    "TLS_DHE_PSK_WITH_NULL_SHA": 45n,
                    "TLS_RSA_PSK_WITH_NULL_SHA": 46n,
                    "TLS_RSA_WITH_AES_128_CBC_SHA": 47n,
                    "TLS_DH_DSS_WITH_AES_128_CBC_SHA": 48n,
                    "TLS_DH_RSA_WITH_AES_128_CBC_SHA": 49n,
                    "TLS_DHE_DSS_WITH_AES_128_CBC_SHA": 50n,
                    "TLS_DHE_RSA_WITH_AES_128_CBC_SHA": 51n,
                    "TLS_DH_anon_WITH_AES_128_CBC_SHA": 52n,
                    "TLS_RSA_WITH_AES_256_CBC_SHA": 53n,
                    "TLS_DH_DSS_WITH_AES_256_CBC_SHA": 54n,
                    "TLS_DH_RSA_WITH_AES_256_CBC_SHA": 55n,
                    "TLS_DHE_DSS_WITH_AES_256_CBC_SHA": 56n,
                    "TLS_DHE_RSA_WITH_AES_256_CBC_SHA": 57n,
                    "TLS_DH_anon_WITH_AES_256_CBC_SHA": 58n,
                    "TLS_RSA_WITH_NULL_SHA256": 59n,
                    "TLS_RSA_WITH_AES_128_CBC_SHA256": 60n,
                    "TLS_RSA_WITH_AES_256_CBC_SHA256": 61n,
                    "TLS_DH_DSS_WITH_AES_128_CBC_SHA256": 62n,
                    "TLS_DH_RSA_WITH_AES_128_CBC_SHA256": 63n,
                    "TLS_DHE_DSS_WITH_AES_128_CBC_SHA256": 64n,
                    "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA": 65n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA": 66n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA": 67n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA": 68n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA": 69n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA": 70n,
                    "TLS_DHE_RSA_WITH_AES_128_CBC_SHA256": 103n,
                    "TLS_DH_DSS_WITH_AES_256_CBC_SHA256": 104n,
                    "TLS_DH_RSA_WITH_AES_256_CBC_SHA256": 105n,
                    "TLS_DHE_DSS_WITH_AES_256_CBC_SHA256": 106n,
                    "TLS_DHE_RSA_WITH_AES_256_CBC_SHA256": 107n,
                    "TLS_DH_anon_WITH_AES_128_CBC_SHA256": 108n,
                    "TLS_DH_anon_WITH_AES_256_CBC_SHA256": 109n,
                    "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA": 132n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA": 133n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA": 134n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA": 135n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA": 136n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA": 137n,
                    "TLS_PSK_WITH_RC4_128_SHA": 138n,
                    "TLS_PSK_WITH_3DES_EDE_CBC_SHA": 139n,
                    "TLS_PSK_WITH_AES_128_CBC_SHA": 140n,
                    "TLS_PSK_WITH_AES_256_CBC_SHA": 141n,
                    "TLS_DHE_PSK_WITH_RC4_128_SHA": 142n,
                    "TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA": 143n,
                    "TLS_DHE_PSK_WITH_AES_128_CBC_SHA": 144n,
                    "TLS_DHE_PSK_WITH_AES_256_CBC_SHA": 145n,
                    "TLS_RSA_PSK_WITH_RC4_128_SHA": 146n,
                    "TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA": 147n,
                    "TLS_RSA_PSK_WITH_AES_128_CBC_SHA": 148n,
                    "TLS_RSA_PSK_WITH_AES_256_CBC_SHA": 149n,
                    "TLS_RSA_WITH_SEED_CBC_SHA": 150n,
                    "TLS_DH_DSS_WITH_SEED_CBC_SHA": 151n,
                    "TLS_DH_RSA_WITH_SEED_CBC_SHA": 152n,
                    "TLS_DHE_DSS_WITH_SEED_CBC_SHA": 153n,
                    "TLS_DHE_RSA_WITH_SEED_CBC_SHA": 154n,
                    "TLS_DH_anon_WITH_SEED_CBC_SHA": 155n,
                    "TLS_RSA_WITH_AES_128_GCM_SHA256": 156n,
                    "TLS_RSA_WITH_AES_256_GCM_SHA384": 157n,
                    "TLS_DHE_RSA_WITH_AES_128_GCM_SHA256": 158n,
                    "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384": 159n,
                    "TLS_DH_RSA_WITH_AES_128_GCM_SHA256": 160n,
                    "TLS_DH_RSA_WITH_AES_256_GCM_SHA384": 161n,
                    "TLS_DHE_DSS_WITH_AES_128_GCM_SHA256": 162n,
                    "TLS_DHE_DSS_WITH_AES_256_GCM_SHA384": 163n,
                    "TLS_DH_DSS_WITH_AES_128_GCM_SHA256": 164n,
                    "TLS_DH_DSS_WITH_AES_256_GCM_SHA384": 165n,
                    "TLS_DH_anon_WITH_AES_128_GCM_SHA256": 166n,
                    "TLS_DH_anon_WITH_AES_256_GCM_SHA384": 167n,
                    "TLS_PSK_WITH_AES_128_GCM_SHA256": 168n,
                    "TLS_PSK_WITH_AES_256_GCM_SHA384": 169n,
                    "TLS_DHE_PSK_WITH_AES_128_GCM_SHA256": 170n,
                    "TLS_DHE_PSK_WITH_AES_256_GCM_SHA384": 171n,
                    "TLS_RSA_PSK_WITH_AES_128_GCM_SHA256": 172n,
                    "TLS_RSA_PSK_WITH_AES_256_GCM_SHA384": 173n,
                    "TLS_PSK_WITH_AES_128_CBC_SHA256": 174n,
                    "TLS_PSK_WITH_AES_256_CBC_SHA384": 175n,
                    "TLS_PSK_WITH_NULL_SHA256": 176n,
                    "TLS_PSK_WITH_NULL_SHA384": 177n,
                    "TLS_DHE_PSK_WITH_AES_128_CBC_SHA256": 178n,
                    "TLS_DHE_PSK_WITH_AES_256_CBC_SHA384": 179n,
                    "TLS_DHE_PSK_WITH_NULL_SHA256": 180n,
                    "TLS_DHE_PSK_WITH_NULL_SHA384": 181n,
                    "TLS_RSA_PSK_WITH_AES_128_CBC_SHA256": 182n,
                    "TLS_RSA_PSK_WITH_AES_256_CBC_SHA384": 183n,
                    "TLS_RSA_PSK_WITH_NULL_SHA256": 184n,
                    "TLS_RSA_PSK_WITH_NULL_SHA384": 185n,
                    "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256": 186n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256": 187n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256": 188n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256": 189n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256": 190n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256": 191n,
                    "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256": 192n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256": 193n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256": 194n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256": 195n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256": 196n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256": 197n,
                    "TLS_AES_128_GCM_SHA256": 4865n,
                    "TLS_AES_256_GCM_SHA384": 4866n,
                    "TLS_CHACHA20_POLY1305_SHA256": 4867n,
                    "TLS_AES_128_CCM_SHA256": 4868n,
                    "TLS_AES_128_CCM_8_SHA256": 4869n,
                    "TLS_ECDH_ECDSA_WITH_NULL_SHA": 49153n,
                    "TLS_ECDH_ECDSA_WITH_RC4_128_SHA": 49154n,
                    "TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA": 49155n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA": 49156n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA": 49157n,
                    "TLS_ECDHE_ECDSA_WITH_NULL_SHA": 49158n,
                    "TLS_ECDHE_ECDSA_WITH_RC4_128_SHA": 49159n,
                    "TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA": 49160n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA": 49161n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA": 49162n,
                    "TLS_ECDH_RSA_WITH_NULL_SHA": 49163n,
                    "TLS_ECDH_RSA_WITH_RC4_128_SHA": 49164n,
                    "TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA": 49165n,
                    "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA": 49166n,
                    "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA": 49167n,
                    "TLS_ECDHE_RSA_WITH_NULL_SHA": 49168n,
                    "TLS_ECDHE_RSA_WITH_RC4_128_SHA": 49169n,
                    "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA": 49170n,
                    "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA": 49171n,
                    "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA": 49172n,
                    "TLS_ECDH_anon_WITH_NULL_SHA": 49173n,
                    "TLS_ECDH_anon_WITH_RC4_128_SHA": 49174n,
                    "TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA": 49175n,
                    "TLS_ECDH_anon_WITH_AES_128_CBC_SHA": 49176n,
                    "TLS_ECDH_anon_WITH_AES_256_CBC_SHA": 49177n,
                    "TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA": 49178n,
                    "TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA": 49179n,
                    "TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA": 49180n,
                    "TLS_SRP_SHA_WITH_AES_128_CBC_SHA": 49181n,
                    "TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA": 49182n,
                    "TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA": 49183n,
                    "TLS_SRP_SHA_WITH_AES_256_CBC_SHA": 49184n,
                    "TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA": 49185n,
                    "TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA": 49186n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256": 49187n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384": 49188n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256": 49189n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384": 49190n,
                    "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256": 49191n,
                    "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384": 49192n,
                    "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256": 49193n,
                    "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384": 49194n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256": 49195n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384": 49196n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256": 49197n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384": 49198n,
                    "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256": 49199n,
                    "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384": 49200n,
                    "TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256": 49201n,
                    "TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384": 49202n,
                    "TLS_ECDHE_PSK_WITH_RC4_128_SHA": 49203n,
                    "TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA": 49204n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA": 49205n,
                    "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA": 49206n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256": 49207n,
                    "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384": 49208n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA": 49209n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA256": 49210n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA384": 49211n,
                    "TLS_RSA_WITH_ARIA_128_CBC_SHA256": 49212n,
                    "TLS_RSA_WITH_ARIA_256_CBC_SHA384": 49213n,
                    "TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256": 49214n,
                    "TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384": 49215n,
                    "TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256": 49216n,
                    "TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384": 49217n,
                    "TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256": 49218n,
                    "TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384": 49219n,
                    "TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256": 49220n,
                    "TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384": 49221n,
                    "TLS_DH_anon_WITH_ARIA_128_CBC_SHA256": 49222n,
                    "TLS_DH_anon_WITH_ARIA_256_CBC_SHA384": 49223n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256": 49224n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384": 49225n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256": 49226n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384": 49227n,
                    "TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256": 49228n,
                    "TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384": 49229n,
                    "TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256": 49230n,
                    "TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384": 49231n,
                    "TLS_RSA_WITH_ARIA_128_GCM_SHA256": 49232n,
                    "TLS_RSA_WITH_ARIA_256_GCM_SHA384": 49233n,
                    "TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256": 49234n,
                    "TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384": 49235n,
                    "TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256": 49236n,
                    "TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384": 49237n,
                    "TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256": 49238n,
                    "TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384": 49239n,
                    "TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256": 49240n,
                    "TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384": 49241n,
                    "TLS_DH_anon_WITH_ARIA_128_GCM_SHA256": 49242n,
                    "TLS_DH_anon_WITH_ARIA_256_GCM_SHA384": 49243n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256": 49244n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384": 49245n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256": 49246n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384": 49247n,
                    "TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256": 49248n,
                    "TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384": 49249n,
                    "TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256": 49250n,
                    "TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384": 49251n,
                    "TLS_PSK_WITH_ARIA_128_CBC_SHA256": 49252n,
                    "TLS_PSK_WITH_ARIA_256_CBC_SHA384": 49253n,
                    "TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256": 49254n,
                    "TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384": 49255n,
                    "TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256": 49256n,
                    "TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384": 49257n,
                    "TLS_PSK_WITH_ARIA_128_GCM_SHA256": 49258n,
                    "TLS_PSK_WITH_ARIA_256_GCM_SHA384": 49259n,
                    "TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256": 49260n,
                    "TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384": 49261n,
                    "TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256": 49262n,
                    "TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384": 49263n,
                    "TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256": 49264n,
                    "TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384": 49265n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256": 49266n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384": 49267n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256": 49268n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384": 49269n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256": 49270n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384": 49271n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256": 49272n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384": 49273n,
                    "TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49274n,
                    "TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49275n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49276n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49277n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49278n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49279n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256": 49280n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384": 49281n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256": 49282n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384": 49283n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256": 49284n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384": 49285n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256": 49286n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384": 49287n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256": 49288n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384": 49289n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49290n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49291n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49292n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49293n,
                    "TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49294n,
                    "TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49295n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49296n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49297n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49298n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49299n,
                    "TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49300n,
                    "TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49301n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49302n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49303n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49304n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49305n,
                    "TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49306n,
                    "TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49307n,
                    "TLS_RSA_WITH_AES_128_CCM": 49308n,
                    "TLS_RSA_WITH_AES_256_CCM": 49309n,
                    "TLS_DHE_RSA_WITH_AES_128_CCM": 49310n,
                    "TLS_DHE_RSA_WITH_AES_256_CCM": 49311n,
                    "TLS_RSA_WITH_AES_128_CCM_8": 49312n,
                    "TLS_RSA_WITH_AES_256_CCM_8": 49313n,
                    "TLS_DHE_RSA_WITH_AES_128_CCM_8": 49314n,
                    "TLS_DHE_RSA_WITH_AES_256_CCM_8": 49315n,
                    "TLS_PSK_WITH_AES_128_CCM": 49316n,
                    "TLS_PSK_WITH_AES_256_CCM": 49317n,
                    "TLS_DHE_PSK_WITH_AES_128_CCM": 49318n,
                    "TLS_DHE_PSK_WITH_AES_256_CCM": 49319n,
                    "TLS_PSK_WITH_AES_128_CCM_8": 49320n,
                    "TLS_PSK_WITH_AES_256_CCM_8": 49321n,
                    "TLS_PSK_DHE_WITH_AES_128_CCM_8": 49322n,
                    "TLS_PSK_DHE_WITH_AES_256_CCM_8": 49323n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CCM": 49324n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CCM": 49325n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8": 49326n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8": 49327n,
                    "TLS_ECCPWD_WITH_AES_128_GCM_SHA256": 49328n,
                    "TLS_ECCPWD_WITH_AES_256_GCM_SHA384": 49329n,
                    "TLS_ECCPWD_WITH_AES_128_CCM_SHA256": 49330n,
                    "TLS_ECCPWD_WITH_AES_256_CCM_SHA384": 49331n,
                    "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256": 52392n,
                    "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256": 52393n,
                    "TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256": 52394n,
                    "TLS_PSK_WITH_CHACHA20_POLY1305_SHA256": 52395n,
                    "TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256": 52396n,
                    "TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256": 52397n,
                    "TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256": 52398n,
                    "TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256": 53249n,
                    "TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384": 53250n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256": 53251n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256": 53253n
                };
            }
            static $h = 1409797;
            static $z = 2;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.UInt16; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":589825,"l":[{"t":1409797,"n":"TLS_NULL_WITH_NULL_NULL","d":1409797,"h":4296377093,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_NULL_MD5","d":1409797,"h":8591344389,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_NULL_SHA","d":1409797,"h":12886311685,"f":33},{"t":1409797,"n":"TLS_RSA_EXPORT_WITH_RC4_40_MD5","d":1409797,"h":17181278981,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_RC4_128_MD5","d":1409797,"h":21476246277,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_RC4_128_SHA","d":1409797,"h":25771213573,"f":33},{"t":1409797,"n":"TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5","d":1409797,"h":30066180869,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_IDEA_CBC_SHA","d":1409797,"h":34361148165,"f":33},{"t":1409797,"n":"TLS_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1409797,"h":38656115461,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_DES_CBC_SHA","d":1409797,"h":42951082757,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":47246050053,"f":33},{"t":1409797,"n":"TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA","d":1409797,"h":51541017349,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_DES_CBC_SHA","d":1409797,"h":55835984645,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":60130951941,"f":33},{"t":1409797,"n":"TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1409797,"h":64425919237,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_DES_CBC_SHA","d":1409797,"h":68720886533,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":73015853829,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA","d":1409797,"h":77310821125,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_DES_CBC_SHA","d":1409797,"h":81605788421,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":85900755717,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1409797,"h":90195723013,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_DES_CBC_SHA","d":1409797,"h":94490690309,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":98785657605,"f":33},{"t":1409797,"n":"TLS_DH_anon_EXPORT_WITH_RC4_40_MD5","d":1409797,"h":103080624901,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_RC4_128_MD5","d":1409797,"h":107375592197,"f":33},{"t":1409797,"n":"TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA","d":1409797,"h":111670559493,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_DES_CBC_SHA","d":1409797,"h":115965526789,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":120260494085,"f":33},{"t":1409797,"n":"TLS_KRB5_WITH_DES_CBC_SHA","d":1409797,"h":124555461381,"f":33},{"t":1409797,"n":"TLS_KRB5_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":128850428677,"f":33},{"t":1409797,"n":"TLS_KRB5_WITH_RC4_128_SHA","d":1409797,"h":133145395973,"f":33},{"t":1409797,"n":"TLS_KRB5_WITH_IDEA_CBC_SHA","d":1409797,"h":137440363269,"f":33},{"t":1409797,"n":"TLS_KRB5_WITH_DES_CBC_MD5","d":1409797,"h":141735330565,"f":33},{"t":1409797,"n":"TLS_KRB5_WITH_3DES_EDE_CBC_MD5","d":1409797,"h":146030297861,"f":33},{"t":1409797,"n":"TLS_KRB5_WITH_RC4_128_MD5","d":1409797,"h":150325265157,"f":33},{"t":1409797,"n":"TLS_KRB5_WITH_IDEA_CBC_MD5","d":1409797,"h":154620232453,"f":33},{"t":1409797,"n":"TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA","d":1409797,"h":158915199749,"f":33},{"t":1409797,"n":"TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA","d":1409797,"h":163210167045,"f":33},{"t":1409797,"n":"TLS_KRB5_EXPORT_WITH_RC4_40_SHA","d":1409797,"h":167505134341,"f":33},{"t":1409797,"n":"TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5","d":1409797,"h":171800101637,"f":33},{"t":1409797,"n":"TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5","d":1409797,"h":176095068933,"f":33},{"t":1409797,"n":"TLS_KRB5_EXPORT_WITH_RC4_40_MD5","d":1409797,"h":180390036229,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_NULL_SHA","d":1409797,"h":184685003525,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_NULL_SHA","d":1409797,"h":188979970821,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_NULL_SHA","d":1409797,"h":193274938117,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_AES_128_CBC_SHA","d":1409797,"h":197569905413,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_AES_128_CBC_SHA","d":1409797,"h":201864872709,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_AES_128_CBC_SHA","d":1409797,"h":206159840005,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_AES_128_CBC_SHA","d":1409797,"h":210454807301,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_AES_128_CBC_SHA","d":1409797,"h":214749774597,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_AES_128_CBC_SHA","d":1409797,"h":219044741893,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_AES_256_CBC_SHA","d":1409797,"h":223339709189,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_AES_256_CBC_SHA","d":1409797,"h":227634676485,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_AES_256_CBC_SHA","d":1409797,"h":231929643781,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_AES_256_CBC_SHA","d":1409797,"h":236224611077,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_AES_256_CBC_SHA","d":1409797,"h":240519578373,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_AES_256_CBC_SHA","d":1409797,"h":244814545669,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_NULL_SHA256","d":1409797,"h":249109512965,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_AES_128_CBC_SHA256","d":1409797,"h":253404480261,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_AES_256_CBC_SHA256","d":1409797,"h":257699447557,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_AES_128_CBC_SHA256","d":1409797,"h":261994414853,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_AES_128_CBC_SHA256","d":1409797,"h":266289382149,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_AES_128_CBC_SHA256","d":1409797,"h":270584349445,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1409797,"h":274879316741,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA","d":1409797,"h":279174284037,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1409797,"h":283469251333,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA","d":1409797,"h":287764218629,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1409797,"h":292059185925,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA","d":1409797,"h":296354153221,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_AES_128_CBC_SHA256","d":1409797,"h":300649120517,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_AES_256_CBC_SHA256","d":1409797,"h":304944087813,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_AES_256_CBC_SHA256","d":1409797,"h":309239055109,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_AES_256_CBC_SHA256","d":1409797,"h":313534022405,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_AES_256_CBC_SHA256","d":1409797,"h":317828989701,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_AES_128_CBC_SHA256","d":1409797,"h":322123956997,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_AES_256_CBC_SHA256","d":1409797,"h":326418924293,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1409797,"h":330713891589,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA","d":1409797,"h":335008858885,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1409797,"h":339303826181,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA","d":1409797,"h":343598793477,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1409797,"h":347893760773,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA","d":1409797,"h":352188728069,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_RC4_128_SHA","d":1409797,"h":356483695365,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":360778662661,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_AES_128_CBC_SHA","d":1409797,"h":365073629957,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_AES_256_CBC_SHA","d":1409797,"h":369368597253,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_RC4_128_SHA","d":1409797,"h":373663564549,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":377958531845,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_AES_128_CBC_SHA","d":1409797,"h":382253499141,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_AES_256_CBC_SHA","d":1409797,"h":386548466437,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_RC4_128_SHA","d":1409797,"h":390843433733,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":395138401029,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_AES_128_CBC_SHA","d":1409797,"h":399433368325,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_AES_256_CBC_SHA","d":1409797,"h":403728335621,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_SEED_CBC_SHA","d":1409797,"h":408023302917,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_SEED_CBC_SHA","d":1409797,"h":412318270213,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_SEED_CBC_SHA","d":1409797,"h":416613237509,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_SEED_CBC_SHA","d":1409797,"h":420908204805,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_SEED_CBC_SHA","d":1409797,"h":425203172101,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_SEED_CBC_SHA","d":1409797,"h":429498139397,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_AES_128_GCM_SHA256","d":1409797,"h":433793106693,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_AES_256_GCM_SHA384","d":1409797,"h":438088073989,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_AES_128_GCM_SHA256","d":1409797,"h":442383041285,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_AES_256_GCM_SHA384","d":1409797,"h":446678008581,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_AES_128_GCM_SHA256","d":1409797,"h":450972975877,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_AES_256_GCM_SHA384","d":1409797,"h":455267943173,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_AES_128_GCM_SHA256","d":1409797,"h":459562910469,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_AES_256_GCM_SHA384","d":1409797,"h":463857877765,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_AES_128_GCM_SHA256","d":1409797,"h":468152845061,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_AES_256_GCM_SHA384","d":1409797,"h":472447812357,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_AES_128_GCM_SHA256","d":1409797,"h":476742779653,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_AES_256_GCM_SHA384","d":1409797,"h":481037746949,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_AES_128_GCM_SHA256","d":1409797,"h":485332714245,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_AES_256_GCM_SHA384","d":1409797,"h":489627681541,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_AES_128_GCM_SHA256","d":1409797,"h":493922648837,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_AES_256_GCM_SHA384","d":1409797,"h":498217616133,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_AES_128_GCM_SHA256","d":1409797,"h":502512583429,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_AES_256_GCM_SHA384","d":1409797,"h":506807550725,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_AES_128_CBC_SHA256","d":1409797,"h":511102518021,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_AES_256_CBC_SHA384","d":1409797,"h":515397485317,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_NULL_SHA256","d":1409797,"h":519692452613,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_NULL_SHA384","d":1409797,"h":523987419909,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_AES_128_CBC_SHA256","d":1409797,"h":528282387205,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_AES_256_CBC_SHA384","d":1409797,"h":532577354501,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_NULL_SHA256","d":1409797,"h":536872321797,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_NULL_SHA384","d":1409797,"h":541167289093,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_AES_128_CBC_SHA256","d":1409797,"h":545462256389,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_AES_256_CBC_SHA384","d":1409797,"h":549757223685,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_NULL_SHA256","d":1409797,"h":554052190981,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_NULL_SHA384","d":1409797,"h":558347158277,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1409797,"h":562642125573,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256","d":1409797,"h":566937092869,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1409797,"h":571232060165,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256","d":1409797,"h":575527027461,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1409797,"h":579821994757,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256","d":1409797,"h":584116962053,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1409797,"h":588411929349,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256","d":1409797,"h":592706896645,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1409797,"h":597001863941,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256","d":1409797,"h":601296831237,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1409797,"h":605591798533,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256","d":1409797,"h":609886765829,"f":33},{"t":1409797,"n":"TLS_AES_128_GCM_SHA256","d":1409797,"h":614181733125,"f":33},{"t":1409797,"n":"TLS_AES_256_GCM_SHA384","d":1409797,"h":618476700421,"f":33},{"t":1409797,"n":"TLS_CHACHA20_POLY1305_SHA256","d":1409797,"h":622771667717,"f":33},{"t":1409797,"n":"TLS_AES_128_CCM_SHA256","d":1409797,"h":627066635013,"f":33},{"t":1409797,"n":"TLS_AES_128_CCM_8_SHA256","d":1409797,"h":631361602309,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_NULL_SHA","d":1409797,"h":635656569605,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_RC4_128_SHA","d":1409797,"h":639951536901,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":644246504197,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA","d":1409797,"h":648541471493,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA","d":1409797,"h":652836438789,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_NULL_SHA","d":1409797,"h":657131406085,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_RC4_128_SHA","d":1409797,"h":661426373381,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":665721340677,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA","d":1409797,"h":670016307973,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA","d":1409797,"h":674311275269,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_NULL_SHA","d":1409797,"h":678606242565,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_RC4_128_SHA","d":1409797,"h":682901209861,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":687196177157,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_AES_128_CBC_SHA","d":1409797,"h":691491144453,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_AES_256_CBC_SHA","d":1409797,"h":695786111749,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_NULL_SHA","d":1409797,"h":700081079045,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_RC4_128_SHA","d":1409797,"h":704376046341,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":708671013637,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA","d":1409797,"h":712965980933,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA","d":1409797,"h":717260948229,"f":33},{"t":1409797,"n":"TLS_ECDH_anon_WITH_NULL_SHA","d":1409797,"h":721555915525,"f":33},{"t":1409797,"n":"TLS_ECDH_anon_WITH_RC4_128_SHA","d":1409797,"h":725850882821,"f":33},{"t":1409797,"n":"TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":730145850117,"f":33},{"t":1409797,"n":"TLS_ECDH_anon_WITH_AES_128_CBC_SHA","d":1409797,"h":734440817413,"f":33},{"t":1409797,"n":"TLS_ECDH_anon_WITH_AES_256_CBC_SHA","d":1409797,"h":738735784709,"f":33},{"t":1409797,"n":"TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":743030752005,"f":33},{"t":1409797,"n":"TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":747325719301,"f":33},{"t":1409797,"n":"TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":751620686597,"f":33},{"t":1409797,"n":"TLS_SRP_SHA_WITH_AES_128_CBC_SHA","d":1409797,"h":755915653893,"f":33},{"t":1409797,"n":"TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA","d":1409797,"h":760210621189,"f":33},{"t":1409797,"n":"TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA","d":1409797,"h":764505588485,"f":33},{"t":1409797,"n":"TLS_SRP_SHA_WITH_AES_256_CBC_SHA","d":1409797,"h":768800555781,"f":33},{"t":1409797,"n":"TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA","d":1409797,"h":773095523077,"f":33},{"t":1409797,"n":"TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA","d":1409797,"h":777390490373,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256","d":1409797,"h":781685457669,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384","d":1409797,"h":785980424965,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256","d":1409797,"h":790275392261,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384","d":1409797,"h":794570359557,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256","d":1409797,"h":798865326853,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384","d":1409797,"h":803160294149,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256","d":1409797,"h":807455261445,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384","d":1409797,"h":811750228741,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256","d":1409797,"h":816045196037,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384","d":1409797,"h":820340163333,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256","d":1409797,"h":824635130629,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384","d":1409797,"h":828930097925,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256","d":1409797,"h":833225065221,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384","d":1409797,"h":837520032517,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256","d":1409797,"h":841814999813,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384","d":1409797,"h":846109967109,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_RC4_128_SHA","d":1409797,"h":850404934405,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA","d":1409797,"h":854699901701,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA","d":1409797,"h":858994868997,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA","d":1409797,"h":863289836293,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256","d":1409797,"h":867584803589,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384","d":1409797,"h":871879770885,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA","d":1409797,"h":876174738181,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA256","d":1409797,"h":880469705477,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA384","d":1409797,"h":884764672773,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_ARIA_128_CBC_SHA256","d":1409797,"h":889059640069,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_ARIA_256_CBC_SHA384","d":1409797,"h":893354607365,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256","d":1409797,"h":897649574661,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384","d":1409797,"h":901944541957,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256","d":1409797,"h":906239509253,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384","d":1409797,"h":910534476549,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256","d":1409797,"h":914829443845,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384","d":1409797,"h":919124411141,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256","d":1409797,"h":923419378437,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384","d":1409797,"h":927714345733,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_ARIA_128_CBC_SHA256","d":1409797,"h":932009313029,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_ARIA_256_CBC_SHA384","d":1409797,"h":936304280325,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256","d":1409797,"h":940599247621,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384","d":1409797,"h":944894214917,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256","d":1409797,"h":949189182213,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384","d":1409797,"h":953484149509,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256","d":1409797,"h":957779116805,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384","d":1409797,"h":962074084101,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256","d":1409797,"h":966369051397,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384","d":1409797,"h":970664018693,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_ARIA_128_GCM_SHA256","d":1409797,"h":974958985989,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_ARIA_256_GCM_SHA384","d":1409797,"h":979253953285,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256","d":1409797,"h":983548920581,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384","d":1409797,"h":987843887877,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256","d":1409797,"h":992138855173,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384","d":1409797,"h":996433822469,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256","d":1409797,"h":1000728789765,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384","d":1409797,"h":1005023757061,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256","d":1409797,"h":1009318724357,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384","d":1409797,"h":1013613691653,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_ARIA_128_GCM_SHA256","d":1409797,"h":1017908658949,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_ARIA_256_GCM_SHA384","d":1409797,"h":1022203626245,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256","d":1409797,"h":1026498593541,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384","d":1409797,"h":1030793560837,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256","d":1409797,"h":1035088528133,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384","d":1409797,"h":1039383495429,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256","d":1409797,"h":1043678462725,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384","d":1409797,"h":1047973430021,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256","d":1409797,"h":1052268397317,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384","d":1409797,"h":1056563364613,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_ARIA_128_CBC_SHA256","d":1409797,"h":1060858331909,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_ARIA_256_CBC_SHA384","d":1409797,"h":1065153299205,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256","d":1409797,"h":1069448266501,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384","d":1409797,"h":1073743233797,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256","d":1409797,"h":1078038201093,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384","d":1409797,"h":1082333168389,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_ARIA_128_GCM_SHA256","d":1409797,"h":1086628135685,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_ARIA_256_GCM_SHA384","d":1409797,"h":1090923102981,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256","d":1409797,"h":1095218070277,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384","d":1409797,"h":1099513037573,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256","d":1409797,"h":1103808004869,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384","d":1409797,"h":1108102972165,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256","d":1409797,"h":1112397939461,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384","d":1409797,"h":1116692906757,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256","d":1409797,"h":1120987874053,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384","d":1409797,"h":1125282841349,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256","d":1409797,"h":1129577808645,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384","d":1409797,"h":1133872775941,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1409797,"h":1138167743237,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384","d":1409797,"h":1142462710533,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1409797,"h":1146757677829,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384","d":1409797,"h":1151052645125,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1409797,"h":1155347612421,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1409797,"h":1159642579717,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1409797,"h":1163937547013,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1409797,"h":1168232514309,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1409797,"h":1172527481605,"f":33},{"t":1409797,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1409797,"h":1176822448901,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256","d":1409797,"h":1181117416197,"f":33},{"t":1409797,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384","d":1409797,"h":1185412383493,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256","d":1409797,"h":1189707350789,"f":33},{"t":1409797,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384","d":1409797,"h":1194002318085,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256","d":1409797,"h":1198297285381,"f":33},{"t":1409797,"n":"TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384","d":1409797,"h":1202592252677,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256","d":1409797,"h":1206887219973,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384","d":1409797,"h":1211182187269,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256","d":1409797,"h":1215477154565,"f":33},{"t":1409797,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384","d":1409797,"h":1219772121861,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1409797,"h":1224067089157,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1409797,"h":1228362056453,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1409797,"h":1232657023749,"f":33},{"t":1409797,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1409797,"h":1236951991045,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1409797,"h":1241246958341,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1409797,"h":1245541925637,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1409797,"h":1249836892933,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1409797,"h":1254131860229,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1409797,"h":1258426827525,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1409797,"h":1262721794821,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1409797,"h":1267016762117,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1409797,"h":1271311729413,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1409797,"h":1275606696709,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1409797,"h":1279901664005,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1409797,"h":1284196631301,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1409797,"h":1288491598597,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1409797,"h":1292786565893,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1409797,"h":1297081533189,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_AES_128_CCM","d":1409797,"h":1301376500485,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_AES_256_CCM","d":1409797,"h":1305671467781,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_AES_128_CCM","d":1409797,"h":1309966435077,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_AES_256_CCM","d":1409797,"h":1314261402373,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_AES_128_CCM_8","d":1409797,"h":1318556369669,"f":33},{"t":1409797,"n":"TLS_RSA_WITH_AES_256_CCM_8","d":1409797,"h":1322851336965,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_AES_128_CCM_8","d":1409797,"h":1327146304261,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_AES_256_CCM_8","d":1409797,"h":1331441271557,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_AES_128_CCM","d":1409797,"h":1335736238853,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_AES_256_CCM","d":1409797,"h":1340031206149,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_AES_128_CCM","d":1409797,"h":1344326173445,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_AES_256_CCM","d":1409797,"h":1348621140741,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_AES_128_CCM_8","d":1409797,"h":1352916108037,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_AES_256_CCM_8","d":1409797,"h":1357211075333,"f":33},{"t":1409797,"n":"TLS_PSK_DHE_WITH_AES_128_CCM_8","d":1409797,"h":1361506042629,"f":33},{"t":1409797,"n":"TLS_PSK_DHE_WITH_AES_256_CCM_8","d":1409797,"h":1365801009925,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CCM","d":1409797,"h":1370095977221,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CCM","d":1409797,"h":1374390944517,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8","d":1409797,"h":1378685911813,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8","d":1409797,"h":1382980879109,"f":33},{"t":1409797,"n":"TLS_ECCPWD_WITH_AES_128_GCM_SHA256","d":1409797,"h":1387275846405,"f":33},{"t":1409797,"n":"TLS_ECCPWD_WITH_AES_256_GCM_SHA384","d":1409797,"h":1391570813701,"f":33},{"t":1409797,"n":"TLS_ECCPWD_WITH_AES_128_CCM_SHA256","d":1409797,"h":1395865780997,"f":33},{"t":1409797,"n":"TLS_ECCPWD_WITH_AES_256_CCM_SHA384","d":1409797,"h":1400160748293,"f":33},{"t":1409797,"n":"TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256","d":1409797,"h":1404455715589,"f":33},{"t":1409797,"n":"TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256","d":1409797,"h":1408750682885,"f":33},{"t":1409797,"n":"TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256","d":1409797,"h":1413045650181,"f":33},{"t":1409797,"n":"TLS_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1409797,"h":1417340617477,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1409797,"h":1421635584773,"f":33},{"t":1409797,"n":"TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1409797,"h":1425930552069,"f":33},{"t":1409797,"n":"TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1409797,"h":1430225519365,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256","d":1409797,"h":1434520486661,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384","d":1409797,"h":1438815453957,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256","d":1409797,"h":1443110421253,"f":33},{"t":1409797,"n":"TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256","d":1409797,"h":1447405388549,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1409797,"h":1451700355845,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1409797,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.TlsCipherSuite`; }
        });
        
        $asm.$str("$snsc.System.Security.Authentication.ExtendedProtection.PolicyEnforcement", ($self) => class PolicyEnforcement extends $.$spc.System.Enum
        {
            static Never = 0;
            static WhenSupported = 1;
            static Always = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Never": 0n,
                    "WhenSupported": 1n,
                    "Always": 2n
                };
            }
            static $h = 1606405;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1606405,"n":"Never","d":1606405,"h":4296573701,"f":33},{"t":1606405,"n":"WhenSupported","d":1606405,"h":8591540997,"f":33},{"t":1606405,"n":"Always","d":1606405,"h":12886508293,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1606405,"h":17181475589,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1606405}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.PolicyEnforcement`; }
        });
        
        $asm.$str("$snsc.System.Security.Authentication.ExtendedProtection.ProtectionScenario", ($self) => class ProtectionScenario extends $.$spc.System.Enum
        {
            static TransportSelected = 0;
            static TrustedProxy = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TransportSelected": 0n,
                    "TrustedProxy": 1n
                };
            }
            static $h = 1671941;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1671941,"n":"TransportSelected","d":1671941,"h":4296639237,"f":33},{"t":1671941,"n":"TrustedProxy","d":1671941,"h":8591606533,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1671941,"h":12886573829,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1671941}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ProtectionScenario`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateStream", ($self) => class NegotiateStream extends $.$snsc.System.Net.Security.AuthenticatedStream
        {
            $ctor$4(/*System.IO.Stream*/ innerStream)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get RemoteIdentity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsClient()
            {
            }
            /*void */ AuthenticateAsClient$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName)
            {
            }
            /*void */ AuthenticateAsClient$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsClient$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName)
            {
            }
            /*void */ AuthenticateAsClient$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsServer()
            {
            }
            /*void */ AuthenticateAsServer$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsServer$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsServer$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient(/*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer(/*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndAuthenticateAsClient(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndAuthenticateAsServer(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 623365;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":99077,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180492549,"f":32769},"n":"CanRead","d":623365,"h":12885525253,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":25770427141,"f":32769},"n":"CanSeek","d":623365,"h":21475459845,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":34360361733,"f":32769},"n":"CanTimeout","d":623365,"h":30065394437,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42950296325,"f":32769},"n":"CanWrite","d":623365,"h":38655329029,"f":32769},{"p":117243905,"g":{"r":0,"d":0,"h":51540230917,"f":129},"n":"ImpersonationLevel","d":623365,"h":47245263621,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":60130165509,"f":32769},"n":"IsAuthenticated","d":623365,"h":55835198213,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":68720100101,"f":32769},"n":"IsEncrypted","d":623365,"h":64425132805,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":77310034693,"f":32769},"n":"IsMutuallyAuthenticated","d":623365,"h":73015067397,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":85899969285,"f":32769},"n":"IsServer","d":623365,"h":81605001989,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":94489903877,"f":32769},"n":"IsSigned","d":623365,"h":90194936581,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":103079838469,"f":32769},"n":"Length","d":623365,"h":98784871173,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":111669773061,"f":32769},"s":{"r":0,"d":0,"h":115964740357,"f":32769},"n":"Position","d":623365,"h":107374805765,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":124554674949,"f":32769},"s":{"r":0,"d":0,"h":128849642245,"f":32769},"n":"ReadTimeout","d":623365,"h":120259707653,"f":32769},{"p":117047297,"g":{"r":0,"d":0,"h":137439576837,"f":129},"n":"RemoteIdentity","d":623365,"h":133144609541,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":146029511429,"f":32769},"s":{"r":0,"d":0,"h":150324478725,"f":32769},"n":"WriteTimeout","d":623365,"h":141734544133,"f":32769}],"m":[{"r":65537,"n":"AuthenticateAsClient","d":623365,"h":154619446021,"f":129},{"r":65537,"p":[{"n":"credential","p":3858188},{"n":"binding","p":5431052},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClient","o":"@$1","d":623365,"h":158914413317,"f":129},{"r":65537,"p":[{"n":"credential","p":3858188},{"n":"binding","p":5431052},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":688901},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClient","o":"@$2","d":623365,"h":163209380613,"f":129},{"r":65537,"p":[{"n":"credential","p":3858188},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClient","o":"@$3","d":623365,"h":167504347909,"f":129},{"r":65537,"p":[{"n":"credential","p":3858188},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":688901},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClient","o":"@$4","d":623365,"h":171799315205,"f":129},{"r":133300225,"n":"AuthenticateAsClientAsync","d":623365,"h":176094282501,"f":129},{"r":133300225,"p":[{"n":"credential","p":3858188},{"n":"binding","p":5431052},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$1","d":623365,"h":180389249797,"f":129},{"r":133300225,"p":[{"n":"credential","p":3858188},{"n":"binding","p":5431052},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":688901},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClientAsync","o":"@$2","d":623365,"h":184684217093,"f":129},{"r":133300225,"p":[{"n":"credential","p":3858188},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$3","d":623365,"h":188979184389,"f":129},{"r":133300225,"p":[{"n":"credential","p":3858188},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":688901},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClientAsync","o":"@$4","d":623365,"h":193274151685,"f":129},{"r":65537,"n":"AuthenticateAsServer","d":623365,"h":197569118981,"f":129},{"r":65537,"p":[{"n":"credential","p":3858188},{"n":"requiredProtectionLevel","p":688901},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServer","o":"@$1","d":623365,"h":201864086277,"f":129},{"r":65537,"p":[{"n":"credential","p":3858188},{"n":"policy","p":1540869},{"n":"requiredProtectionLevel","p":688901},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServer","o":"@$2","d":623365,"h":206159053573,"f":129},{"r":65537,"p":[{"n":"policy","p":1540869}],"n":"AuthenticateAsServer","o":"@$3","d":623365,"h":210454020869,"f":129},{"r":133300225,"n":"AuthenticateAsServerAsync","d":623365,"h":214748988165,"f":129},{"r":133300225,"p":[{"n":"credential","p":3858188},{"n":"requiredProtectionLevel","p":688901},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServerAsync","o":"@$1","d":623365,"h":219043955461,"f":129},{"r":133300225,"p":[{"n":"credential","p":3858188},{"n":"policy","p":1540869},{"n":"requiredProtectionLevel","p":688901},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServerAsync","o":"@$2","d":623365,"h":223338922757,"f":129},{"r":133300225,"p":[{"n":"policy","p":1540869}],"n":"AuthenticateAsServerAsync","o":"@$3","d":623365,"h":227633890053,"f":129},{"r":56950785,"p":[{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","d":623365,"h":231928857349,"f":129},{"r":56950785,"p":[{"n":"credential","p":3858188},{"n":"binding","p":5431052},{"n":"targetName","p":1310721},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$1","d":623365,"h":236223824645,"f":129},{"r":56950785,"p":[{"n":"credential","p":3858188},{"n":"binding","p":5431052},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":688901},{"n":"allowedImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$2","d":623365,"h":240518791941,"f":129},{"r":56950785,"p":[{"n":"credential","p":3858188},{"n":"targetName","p":1310721},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$3","d":623365,"h":244813759237,"f":129},{"r":56950785,"p":[{"n":"credential","p":3858188},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":688901},{"n":"allowedImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$4","d":623365,"h":249108726533,"f":129},{"r":56950785,"p":[{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","d":623365,"h":253403693829,"f":129},{"r":56950785,"p":[{"n":"credential","p":3858188},{"n":"requiredProtectionLevel","p":688901},{"n":"requiredImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$1","d":623365,"h":257698661125,"f":129},{"r":56950785,"p":[{"n":"credential","p":3858188},{"n":"policy","p":1540869},{"n":"requiredProtectionLevel","p":688901},{"n":"requiredImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$2","d":623365,"h":261993628421,"f":129},{"r":56950785,"p":[{"n":"policy","p":1540869},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$3","d":623365,"h":266288595717,"f":129},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginRead","d":623365,"h":270583563013,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":623365,"h":274878530309,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":623365,"h":279173497605,"f":32772},{"r":136118273,"n":"DisposeAsync","d":623365,"h":283468464901,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAuthenticateAsClient","d":623365,"h":287763432197,"f":129},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAuthenticateAsServer","d":623365,"h":292058399493,"f":129},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":623365,"h":296353366789,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":623365,"h":300648334085,"f":32769},{"r":65537,"n":"Flush","d":623365,"h":304943301381,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":623365,"h":309238268677,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":623365,"h":313533235973,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":623365,"h":317828203269,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":623365,"h":322123170565,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":623365,"h":326418137861,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":623365,"h":330713105157,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":623365,"h":335008072453,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":623365,"h":339303039749,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":623365,"h":343598007045,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62128129}],"n":".ctor","o":"$ctor$4","d":623365,"h":4295590661,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":623365,"h":8590557957,"f":1}],"i":[57475073,56885249],"h":623365}; }
            static get $b() { return $.$snsc.System.Net.Security.AuthenticatedStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.NegotiateStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslStream", ($self) => class SslStream extends $.$snsc.System.Net.Security.AuthenticatedStream
        {
            $ctor$4(/*System.IO.Stream*/ innerStream)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$7(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback, /*System.Net.Security.LocalCertificateSelectionCallback?*/ userCertificateSelectionCallback)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$8(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback, /*System.Net.Security.LocalCertificateSelectionCallback?*/ userCertificateSelectionCallback, /*System.Net.Security.EncryptionPolicy*/ encryptionPolicy)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CheckCertRevocationStatus()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.CipherAlgorithmType */ get CipherAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get CipherStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.HashAlgorithmType */ get HashAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get HashStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExchangeAlgorithmType */ get KeyExchangeAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get KeyExchangeStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get LocalCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslApplicationProtocol */ get NegotiatedApplicationProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.TlsCipherSuite */ get NegotiatedCipherSuite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get RemoteCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get TargetHostName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.TransportContext */ get TransportContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsClient(/*System.Net.Security.SslClientAuthenticationOptions*/ sslClientAuthenticationOptions)
            {
            }
            /*void */ AuthenticateAsClient$1(/*string*/ targetHost)
            {
            }
            /*void */ AuthenticateAsClient$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation)
            {
            }
            /*void */ AuthenticateAsClient$3(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync(/*System.Net.Security.SslClientAuthenticationOptions*/ sslClientAuthenticationOptions, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$1(/*string*/ targetHost)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$3(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsServer(/*System.Net.Security.SslServerAuthenticationOptions*/ sslServerAuthenticationOptions)
            {
            }
            /*void */ AuthenticateAsServer$1(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate)
            {
            }
            /*void */ AuthenticateAsServer$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation)
            {
            }
            /*void */ AuthenticateAsServer$3(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync(/*System.Net.Security.ServerOptionsSelectionCallback*/ optionsCallback, /*object?*/ state, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$1(/*System.Net.Security.SslServerAuthenticationOptions*/ sslServerAuthenticationOptions, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$3(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$4(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient(/*string*/ targetHost, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$1(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$1(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndAuthenticateAsClient(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndAuthenticateAsServer(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ NegotiateClientCertificateAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*System.Threading.Tasks.Task */ ShutdownAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Write$2(/*byte[]*/ buffer)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 1278725;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":99077,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30066049797,"f":32769},"n":"CanRead","d":1278725,"h":25771082501,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38655984389,"f":32769},"n":"CanSeek","d":1278725,"h":34361017093,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":47245918981,"f":32769},"n":"CanTimeout","d":1278725,"h":42950951685,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":55835853573,"f":32769},"n":"CanWrite","d":1278725,"h":51540886277,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":64425788165,"f":129},"n":"CheckCertRevocationStatus","d":1278725,"h":60130820869,"f":129},{"p":5299980,"g":{"r":0,"d":0,"h":73015722757,"f":129},"n":"CipherAlgorithm","d":1278725,"h":68720755461,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":81605657349,"f":129},"n":"CipherStrength","d":1278725,"h":77310690053,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":5562124,"g":{"r":0,"d":0,"h":90195591941,"f":129},"n":"HashAlgorithm","d":1278725,"h":85900624645,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":98785526533,"f":129},"n":"HashStrength","d":1278725,"h":94490559237,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":107375461125,"f":32769},"n":"IsAuthenticated","d":1278725,"h":103080493829,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":115965395717,"f":32769},"n":"IsEncrypted","d":1278725,"h":111670428421,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":124555330309,"f":32769},"n":"IsMutuallyAuthenticated","d":1278725,"h":120260363013,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":133145264901,"f":32769},"n":"IsServer","d":1278725,"h":128850297605,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":141735199493,"f":32769},"n":"IsSigned","d":1278725,"h":137440232197,"f":32769},{"p":5365516,"g":{"r":0,"d":0,"h":150325134085,"f":129},"n":"KeyExchangeAlgorithm","d":1278725,"h":146030166789,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":158915068677,"f":129},"n":"KeyExchangeStrength","d":1278725,"h":154620101381,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":167505003269,"f":32769},"n":"Length","d":1278725,"h":163210035973,"f":32769},{"p":28149278,"g":{"r":0,"d":0,"h":176094937861,"f":129},"n":"LocalCertificate","d":1278725,"h":171799970565,"f":129},{"p":951045,"g":{"r":0,"d":0,"h":184684872453,"f":1},"n":"NegotiatedApplicationProtocol","d":1278725,"h":180389905157,"f":1},{"p":1409797,"g":{"r":0,"d":0,"h":193274807045,"f":129},"n":"NegotiatedCipherSuite","d":1278725,"h":188979839749,"f":129,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"p":917505,"g":{"r":0,"d":0,"h":201864741637,"f":32769},"s":{"r":0,"d":0,"h":206159708933,"f":32769},"n":"Position","d":1278725,"h":197569774341,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":214749643525,"f":32769},"s":{"r":0,"d":0,"h":219044610821,"f":32769},"n":"ReadTimeout","d":1278725,"h":210454676229,"f":32769},{"p":28149278,"g":{"r":0,"d":0,"h":227634545413,"f":129},"n":"RemoteCertificate","d":1278725,"h":223339578117,"f":129},{"p":5627660,"g":{"r":0,"d":0,"h":236224480005,"f":129},"n":"SslProtocol","d":1278725,"h":231929512709,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":244814414597,"f":1},"n":"TargetHostName","d":1278725,"h":240519447301,"f":1},{"p":5037836,"g":{"r":0,"d":0,"h":253404349189,"f":1},"n":"TransportContext","d":1278725,"h":249109381893,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":261994283781,"f":32769},"s":{"r":0,"d":0,"h":266289251077,"f":32769},"n":"WriteTimeout","d":1278725,"h":257699316485,"f":32769}],"m":[{"r":65537,"p":[{"n":"sslClientAuthenticationOptions","p":1082117}],"n":"AuthenticateAsClient","d":1278725,"h":270584218373,"f":1},{"r":65537,"p":[{"n":"targetHost","p":1310721}],"n":"AuthenticateAsClient","o":"@$1","d":1278725,"h":274879185669,"f":129},{"r":65537,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28411422},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClient","o":"@$2","d":1278725,"h":279174152965,"f":129},{"r":65537,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28411422},{"n":"enabledSslProtocols","p":5627660},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClient","o":"@$3","d":1278725,"h":283469120261,"f":129},{"r":133300225,"p":[{"n":"sslClientAuthenticationOptions","p":1082117},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsClientAsync","d":1278725,"h":287764087557,"f":1},{"r":133300225,"p":[{"n":"targetHost","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$1","d":1278725,"h":292059054853,"f":129},{"r":133300225,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28411422},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClientAsync","o":"@$2","d":1278725,"h":296354022149,"f":129},{"r":133300225,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28411422},{"n":"enabledSslProtocols","p":5627660},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClientAsync","o":"@$3","d":1278725,"h":300648989445,"f":129},{"r":65537,"p":[{"n":"sslServerAuthenticationOptions","p":1213189}],"n":"AuthenticateAsServer","d":1278725,"h":304943956741,"f":1},{"r":65537,"p":[{"n":"serverCertificate","p":28149278}],"n":"AuthenticateAsServer","o":"@$1","d":1278725,"h":309238924037,"f":129},{"r":65537,"p":[{"n":"serverCertificate","p":28149278},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServer","o":"@$2","d":1278725,"h":313533891333,"f":129},{"r":65537,"p":[{"n":"serverCertificate","p":28149278},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5627660},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServer","o":"@$3","d":1278725,"h":317828858629,"f":129},{"r":133300225,"p":[{"n":"optionsCallback","p":885509},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsServerAsync","d":1278725,"h":322123825925,"f":1},{"r":133300225,"p":[{"n":"sslServerAuthenticationOptions","p":1213189},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsServerAsync","o":"@$1","d":1278725,"h":326418793221,"f":1},{"r":133300225,"p":[{"n":"serverCertificate","p":28149278}],"n":"AuthenticateAsServerAsync","o":"@$2","d":1278725,"h":330713760517,"f":129},{"r":133300225,"p":[{"n":"serverCertificate","p":28149278},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServerAsync","o":"@$3","d":1278725,"h":335008727813,"f":129},{"r":133300225,"p":[{"n":"serverCertificate","p":28149278},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5627660},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServerAsync","o":"@$4","d":1278725,"h":339303695109,"f":129},{"r":56950785,"p":[{"n":"targetHost","p":1310721},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","d":1278725,"h":343598662405,"f":129},{"r":56950785,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28411422},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$1","d":1278725,"h":347893629701,"f":129},{"r":56950785,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28411422},{"n":"enabledSslProtocols","p":5627660},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$2","d":1278725,"h":352188596997,"f":129},{"r":56950785,"p":[{"n":"serverCertificate","p":28149278},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","d":1278725,"h":356483564293,"f":129},{"r":56950785,"p":[{"n":"serverCertificate","p":28149278},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$1","d":1278725,"h":360778531589,"f":129},{"r":56950785,"p":[{"n":"serverCertificate","p":28149278},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5627660},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$2","d":1278725,"h":365073498885,"f":129},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginRead","d":1278725,"h":369368466181,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":1278725,"h":373663433477,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1278725,"h":377958400773,"f":32772},{"r":136118273,"n":"DisposeAsync","d":1278725,"h":382253368069,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAuthenticateAsClient","d":1278725,"h":386548335365,"f":129},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAuthenticateAsServer","d":1278725,"h":390843302661,"f":129},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":1278725,"h":395138269957,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":1278725,"h":399433237253,"f":32769},{"r":65537,"n":"Flush","d":1278725,"h":408023171845,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1278725,"h":412318139141,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"NegotiateClientCertificateAsync","d":1278725,"h":416613106437,"f":129,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1278725,"h":420908073733,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1278725,"h":425203041029,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1278725,"h":429498008325,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1278725,"h":433792975621,"f":32769},{"r":655361,"n":"ReadByte","d":1278725,"h":438087942917,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1278725,"h":442382910213,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1278725,"h":446677877509,"f":32769},{"r":133300225,"n":"ShutdownAsync","d":1278725,"h":450972844805,"f":129},{"r":65537,"p":[{"n":"buffer","p":0}],"n":"Write","o":"@$2","d":1278725,"h":455267812101,"f":1},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1278725,"h":459562779397,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":1278725,"h":463857746693,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1278725,"h":468152713989,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1278725,"h":472447681285,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":1278725,"h":476742648581,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62128129}],"n":".ctor","o":"$ctor$4","d":1278725,"h":4296246021,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":1278725,"h":8591213317,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":754437}],"n":".ctor","o":"$ctor$6","d":1278725,"h":12886180613,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":754437},{"n":"userCertificateSelectionCallback","p":295685}],"n":".ctor","o":"$ctor$7","d":1278725,"h":17181147909,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":754437},{"n":"userCertificateSelectionCallback","p":295685},{"n":"encryptionPolicy","p":230149}],"n":".ctor","o":"$ctor$8","d":1278725,"h":21476115205,"f":1}],"i":[57475073,56885249],"h":1278725}; }
            static get $b() { return $.$snsc.System.Net.Security.AuthenticatedStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.SslStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.LocalCertificateSelectionCallback", ($self) => class LocalCertificateSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate?*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$spc.System.String*/ $targetHost, /*$.$sscr.System.Security.Cryptography.X509Certificates.X509CertificateCollection*/ $localCertificates, /*$.$spc.System.Nullable$$*/ $remoteCertificate, /**/ $acceptableIssuers)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 295685;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":28149278,"p":[{"n":"sender","p":131073},{"n":"targetHost","p":1310721},{"n":"localCertificates","p":28411422},{"n":"remoteCertificate","p":28149278},{"n":"acceptableIssuers","p":0}],"n":"Invoke","d":295685,"h":8590230277,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"targetHost","p":1310721},{"n":"localCertificates","p":28411422},{"n":"remoteCertificate","p":28149278},{"n":"acceptableIssuers","p":0},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":295685,"h":12885197573,"f":129},{"r":28149278,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":295685,"h":17180164869,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":295685,"h":4295262981,"f":1}],"i":[57147393,113377281],"h":295685}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.LocalCertificateSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.RemoteCertificateValidationCallback", ($self) => class RemoteCertificateValidationCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*bool*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$spc.System.Nullable$$*/ $certificate, /*$.$spc.System.Nullable$$*/ $chain, /*$.$snp.System.Net.Security.SslPolicyErrors*/ $sslPolicyErrors)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 754437;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":262145,"p":[{"n":"sender","p":131073},{"n":"certificate","p":28149278},{"n":"chain","p":28870174},{"n":"sslPolicyErrors","p":4316940}],"n":"Invoke","d":754437,"h":8590689029,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"certificate","p":28149278},{"n":"chain","p":28870174},{"n":"sslPolicyErrors","p":4316940},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":754437,"h":12885656325,"f":129},{"r":262145,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":754437,"h":17180623621,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":754437,"h":4295721733,"f":1}],"i":[57147393,113377281],"h":754437}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.RemoteCertificateValidationCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.ServerCertificateSelectionCallback", ($self) => class ServerCertificateSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$spc.System.Nullable$$*/ $hostName)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 819973;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":28149278,"p":[{"n":"sender","p":131073},{"n":"hostName","p":1310721}],"n":"Invoke","d":819973,"h":8590754565,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"hostName","p":1310721},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":819973,"h":12885721861,"f":129},{"r":28149278,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":819973,"h":17180689157,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":819973,"h":4295787269,"f":1}],"i":[57147393,113377281],"h":819973}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.ServerCertificateSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.ServerOptionsSelectionCallback", ($self) => class ServerOptionsSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Security.SslServerAuthenticationOptions>*/ Invoke(/*$.$snsc.System.Net.Security.SslStream*/ $stream, /*$.$snsc.System.Net.Security.SslClientHelloInfo*/ $clientHelloInfo, /*$.$spc.System.Nullable$$*/ $state, /*$.$spc.System.Threading.CancellationToken*/ $cancellationToken)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 885509;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snsc.System.Net.Security.SslServerAuthenticationOptions).$h,"p":[{"n":"stream","p":1278725},{"n":"clientHelloInfo","p":1147653},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193}],"n":"Invoke","d":885509,"h":8590820101,"f":129},{"r":56950785,"p":[{"n":"stream","p":1278725},{"n":"clientHelloInfo","p":1147653},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":885509,"h":12885787397,"f":129},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snsc.System.Net.Security.SslServerAuthenticationOptions).$h,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":885509,"h":17180754693,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":885509,"h":4295852805,"f":1}],"i":[57147393,113377281],"h":885509}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.ServerOptionsSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.AuthenticationException", ($self) => class AuthenticationException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$12(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            static $h = 1475333;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":1475333}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.AuthenticationException`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.InvalidCredentialException", ($self) => class InvalidCredentialException extends $.$snsc.System.Security.Authentication.AuthenticationException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$14(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$16(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            static $h = 1803013;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1475333,"h":1803013}; }
            static get $b() { return $.$snsc.System.Security.Authentication.AuthenticationException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.InvalidCredentialException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.Numerics", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Console", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Net.NameResolution", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography"))