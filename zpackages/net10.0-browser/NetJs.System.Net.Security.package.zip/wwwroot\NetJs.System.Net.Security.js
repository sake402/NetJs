
(function ($global, $, $spc, $mwp, $sc, $sdt, $sm, $snv, $spu, $sri, $stee, $st, $sto, $stt, $sttp, $sr, $scc, $scn, $srn, $ssc, $sris, $scsl, $sfa, $sic, $sim, $sl, $snp, $sspw, $sci, $sdd, $srm, $snnr, $sds, $sns, $sscr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Security", 
    {"h":60646,"f":"System.Net.Security","v":"1.0.35.0","a":[{"t":115146753,"c":13000048641,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Bb2f64e36cd2325469603c9f9f7251f0c62e9b41f","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Security","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Security","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115212289,"c":4410179585,"a":[{"v":"browser1.0","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$snsc.System.Net.Security.AuthenticatedStream", ($self) => class AuthenticatedStream extends $.$spc.System.IO.Stream
        {
            $ctor$3(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*System.IO.Stream */ get InnerStream()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get LeaveInnerStreamOpen()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 126182;
            static $f = 0b110001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62128129,"p":[{"p":62128129,"g":{"r":0,"d":0,"h":12885028070,"f":4},"n":"InnerStream","d":126182,"h":8590060774,"f":4},{"p":262145,"g":{"r":0,"d":0,"h":21474962662,"f":257},"n":"IsAuthenticated","d":126182,"h":17179995366,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":30064897254,"f":257},"n":"IsEncrypted","d":126182,"h":25769929958,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":38654831846,"f":257},"n":"IsMutuallyAuthenticated","d":126182,"h":34359864550,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":47244766438,"f":257},"n":"IsServer","d":126182,"h":42949799142,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":55834701030,"f":257},"n":"IsSigned","d":126182,"h":51539733734,"f":257},{"p":262145,"g":{"r":0,"d":0,"h":64424635622,"f":1},"n":"LeaveInnerStreamOpen","d":126182,"h":60129668326,"f":1}],"m":[{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":126182,"h":68719602918,"f":32772},{"r":136118273,"n":"DisposeAsync","d":126182,"h":73014570214,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$3","d":126182,"h":4295093478,"f":4}],"i":[57475073,56885249],"h":126182}; }
            static get $b() { return $.$spc.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.AuthenticatedStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.CipherSuitesPolicy", ($self) => class CipherSuitesPolicy extends $.$spc.System.Object
        {
            $ctor$1(/*System.Collections.Generic.IEnumerable<System.Net.Security.TlsCipherSuite>*/ allowedCipherSuites)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.Generic.IEnumerable<System.Net.Security.TlsCipherSuite> */ get AllowedCipherSuites()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 191718;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.Generic.IEnumerable$$($.$snsc.System.Net.Security.TlsCipherSuite).$h,"g":{"r":0,"d":0,"h":12885093606,"f":1},"n":"AllowedCipherSuites","d":191718,"h":8590126310,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}],"c":[{"p":[{"n":"allowedCipherSuites","p":$.$spc.System.Collections.Generic.IEnumerable$$($.$snsc.System.Net.Security.TlsCipherSuite).$h}],"n":".ctor","o":"$ctor$1","d":191718,"h":4295159014,"f":1,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}],"h":191718,"a":[{"t":115277825,"c":4410245121,"a":[{"v":"android","t":1310721}]},{"t":115277825,"c":4410245121,"a":[{"v":"windows","t":1310721}]}]}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.CipherSuitesPolicy`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthenticationClientOptions", ($self) => class NegotiateAuthenticationClientOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get AllowedImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set AllowedImpersonationLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get Binding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ set Binding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ get Credential()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ set Credential(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Package(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get RequiredProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ set RequiredProtectionLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get RequireMutualAuthentication()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set RequireMutualAuthentication(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TargetName(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 453862;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":117243905,"g":{"r":0,"d":0,"h":12885355750,"f":1},"s":{"r":0,"d":0,"h":17180323046,"f":1},"n":"AllowedImpersonationLevel","d":453862,"h":8590388454,"f":1},{"p":5414875,"g":{"r":0,"d":0,"h":25770257638,"f":1},"s":{"r":0,"d":0,"h":30065224934,"f":1},"n":"Binding","d":453862,"h":21475290342,"f":1},{"p":3842011,"g":{"r":0,"d":0,"h":38655159526,"f":1},"s":{"r":0,"d":0,"h":42950126822,"f":1},"n":"Credential","d":453862,"h":34360192230,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":51540061414,"f":1},"s":{"r":0,"d":0,"h":55835028710,"f":1},"n":"Package","d":453862,"h":47245094118,"f":1},{"p":716006,"g":{"r":0,"d":0,"h":64424963302,"f":1},"s":{"r":0,"d":0,"h":68719930598,"f":1},"n":"RequiredProtectionLevel","d":453862,"h":60129996006,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":77309865190,"f":1},"s":{"r":0,"d":0,"h":81604832486,"f":1},"n":"RequireMutualAuthentication","d":453862,"h":73014897894,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":90194767078,"f":1},"s":{"r":0,"d":0,"h":94489734374,"f":1},"n":"TargetName","d":453862,"h":85899799782,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":453862,"h":4295421158,"f":1}],"h":453862}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationClientOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthenticationServerOptions", ($self) => class NegotiateAuthenticationServerOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get Binding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ set Binding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ get Credential()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.NetworkCredential */ set Credential(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ set Package(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy? */ get Policy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy? */ set Policy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get RequiredImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ set RequiredImpersonationLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get RequiredProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ set RequiredProtectionLevel(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 519398;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5414875,"g":{"r":0,"d":0,"h":12885421286,"f":1},"s":{"r":0,"d":0,"h":17180388582,"f":1},"n":"Binding","d":519398,"h":8590453990,"f":1},{"p":3842011,"g":{"r":0,"d":0,"h":25770323174,"f":1},"s":{"r":0,"d":0,"h":30065290470,"f":1},"n":"Credential","d":519398,"h":21475355878,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":38655225062,"f":1},"s":{"r":0,"d":0,"h":42950192358,"f":1},"n":"Package","d":519398,"h":34360257766,"f":1},{"p":1567974,"g":{"r":0,"d":0,"h":51540126950,"f":1},"s":{"r":0,"d":0,"h":55835094246,"f":1},"n":"Policy","d":519398,"h":47245159654,"f":1},{"p":117243905,"g":{"r":0,"d":0,"h":64425028838,"f":1},"s":{"r":0,"d":0,"h":68719996134,"f":1},"n":"RequiredImpersonationLevel","d":519398,"h":60130061542,"f":1},{"p":716006,"g":{"r":0,"d":0,"h":77309930726,"f":1},"s":{"r":0,"d":0,"h":81604898022,"f":1},"n":"RequiredProtectionLevel","d":519398,"h":73014963430,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":519398,"h":4295486694,"f":1}],"h":519398}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationServerOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslCertificateTrust", ($self) => class SslCertificateTrust extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            static /*System.Net.Security.SslCertificateTrust */ CreateForX509Collection(/*System.Security.Cryptography.X509Certificates.X509Certificate2Collection*/ trustList, /*bool*/ sendTrustInHandshake)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslCertificateTrust */ CreateForX509Store(/*System.Security.Cryptography.X509Certificates.X509Store*/ store, /*bool*/ sendTrustInHandshake)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1043686;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":1043686,"p":[{"n":"trustList","p":28303975},{"n":"sendTrustInHandshake","p":262145,"f":65,"v":false}],"n":"CreateForX509Collection","d":1043686,"h":8590978278,"f":33},{"r":1043686,"p":[{"n":"store","p":30466663},{"n":"sendTrustInHandshake","p":262145,"f":65,"v":false}],"n":"CreateForX509Store","d":1043686,"h":12885945574,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1043686,"h":4296010982,"f":8}],"h":1043686}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslCertificateTrust`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslClientAuthenticationOptions", ($self) => class SslClientAuthenticationOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AllowRenegotiation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRenegotiation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPkcs1Padding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPkcs1Padding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPssPadding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPssPadding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowTlsResume()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowTlsResume(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ get ApplicationProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ set ApplicationProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ get CertificateChainPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ set CertificateChainPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ get CertificateRevocationCheckMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ set CertificateRevocationCheckMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ get CipherSuitesPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ set CipherSuitesPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ get ClientCertificateContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ set ClientCertificateContext(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection? */ get ClientCertificates()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509CertificateCollection? */ set ClientCertificates(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get EnabledSslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ set EnabledSslProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ set EncryptionPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.LocalCertificateSelectionCallback? */ get LocalCertificateSelectionCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.LocalCertificateSelectionCallback? */ set LocalCertificateSelectionCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get RemoteCertificateValidationCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set RemoteCertificateValidationCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetHost()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ set TargetHost(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1109222;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886011110,"f":1},"s":{"r":0,"d":0,"h":17180978406,"f":1},"n":"AllowRenegotiation","d":1109222,"h":8591043814,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770912998,"f":1},"s":{"r":0,"d":0,"h":30065880294,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPkcs1Padding","d":1109222,"h":21475945702,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655814886,"f":1},"s":{"r":0,"d":0,"h":42950782182,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPssPadding","d":1109222,"h":34360847590,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540716774,"f":1},"s":{"r":0,"d":0,"h":55835684070,"f":1},"n":"AllowTlsResume","d":1109222,"h":47245749478,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":64425618662,"f":1},"s":{"r":0,"d":0,"h":68720585958,"f":1},"n":"ApplicationProtocols","d":1109222,"h":60130651366,"f":1},{"p":29155943,"g":{"r":0,"d":0,"h":77310520550,"f":1},"s":{"r":0,"d":0,"h":81605487846,"f":1},"n":"CertificateChainPolicy","d":1109222,"h":73015553254,"f":1},{"p":30270055,"g":{"r":0,"d":0,"h":90195422438,"f":1},"s":{"r":0,"d":0,"h":94490389734,"f":1},"n":"CertificateRevocationCheckMode","d":1109222,"h":85900455142,"f":1},{"p":191718,"g":{"r":0,"d":0,"h":103080324326,"f":1},"s":{"r":0,"d":0,"h":107375291622,"f":1},"n":"CipherSuitesPolicy","d":1109222,"h":98785357030,"f":1},{"p":1371366,"g":{"r":0,"d":0,"h":115965226214,"f":1},"s":{"r":0,"d":0,"h":120260193510,"f":1},"n":"ClientCertificateContext","d":1109222,"h":111670258918,"f":1},{"p":28435047,"g":{"r":0,"d":0,"h":128850128102,"f":1},"s":{"r":0,"d":0,"h":133145095398,"f":1},"n":"ClientCertificates","d":1109222,"h":124555160806,"f":1},{"p":5611483,"g":{"r":0,"d":0,"h":141735029990,"f":1},"s":{"r":0,"d":0,"h":146029997286,"f":1},"n":"EnabledSslProtocols","d":1109222,"h":137440062694,"f":1},{"p":257254,"g":{"r":0,"d":0,"h":154619931878,"f":1},"s":{"r":0,"d":0,"h":158914899174,"f":1},"n":"EncryptionPolicy","d":1109222,"h":150324964582,"f":1},{"p":322790,"g":{"r":0,"d":0,"h":167504833766,"f":1},"s":{"r":0,"d":0,"h":171799801062,"f":1},"n":"LocalCertificateSelectionCallback","d":1109222,"h":163209866470,"f":1},{"p":781542,"g":{"r":0,"d":0,"h":180389735654,"f":1},"s":{"r":0,"d":0,"h":184684702950,"f":1},"n":"RemoteCertificateValidationCallback","d":1109222,"h":176094768358,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":193274637542,"f":1},"s":{"r":0,"d":0,"h":197569604838,"f":1},"n":"TargetHost","d":1109222,"h":188979670246,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1109222,"h":4296076518,"f":1}],"h":1109222}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslClientAuthenticationOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslServerAuthenticationOptions", ($self) => class SslServerAuthenticationOptions extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get AllowRenegotiation()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRenegotiation(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPkcs1Padding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPkcs1Padding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowRsaPssPadding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowRsaPssPadding(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get AllowTlsResume()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set AllowTlsResume(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ get ApplicationProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.List<System.Net.Security.SslApplicationProtocol>? */ set ApplicationProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ get CertificateChainPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509ChainPolicy? */ set CertificateChainPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ get CertificateRevocationCheckMode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509RevocationMode */ set CertificateRevocationCheckMode(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ get CipherSuitesPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.CipherSuitesPolicy? */ set CipherSuitesPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ClientCertificateRequired()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ClientCertificateRequired(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get EnabledSslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ set EnabledSslProtocols(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ get EncryptionPolicy()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.EncryptionPolicy */ set EncryptionPolicy(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ get RemoteCertificateValidationCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.RemoteCertificateValidationCallback? */ set RemoteCertificateValidationCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get ServerCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ set ServerCertificate(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ get ServerCertificateContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslStreamCertificateContext? */ set ServerCertificateContext(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ServerCertificateSelectionCallback? */ get ServerCertificateSelectionCallback()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ServerCertificateSelectionCallback? */ set ServerCertificateSelectionCallback(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1240294;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12886142182,"f":1},"s":{"r":0,"d":0,"h":17181109478,"f":1},"n":"AllowRenegotiation","d":1240294,"h":8591174886,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25771044070,"f":1},"s":{"r":0,"d":0,"h":30066011366,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPkcs1Padding","d":1240294,"h":21476076774,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":38655945958,"f":1},"s":{"r":0,"d":0,"h":42950913254,"f":1,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},"n":"AllowRsaPssPadding","d":1240294,"h":34360978662,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51540847846,"f":1},"s":{"r":0,"d":0,"h":55835815142,"f":1},"n":"AllowTlsResume","d":1240294,"h":47245880550,"f":1},{"p":$.$spc.System.Collections.Generic.List$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h,"g":{"r":0,"d":0,"h":64425749734,"f":1},"s":{"r":0,"d":0,"h":68720717030,"f":1},"n":"ApplicationProtocols","d":1240294,"h":60130782438,"f":1},{"p":29155943,"g":{"r":0,"d":0,"h":77310651622,"f":1},"s":{"r":0,"d":0,"h":81605618918,"f":1},"n":"CertificateChainPolicy","d":1240294,"h":73015684326,"f":1},{"p":30270055,"g":{"r":0,"d":0,"h":90195553510,"f":1},"s":{"r":0,"d":0,"h":94490520806,"f":1},"n":"CertificateRevocationCheckMode","d":1240294,"h":85900586214,"f":1},{"p":191718,"g":{"r":0,"d":0,"h":103080455398,"f":1},"s":{"r":0,"d":0,"h":107375422694,"f":1},"n":"CipherSuitesPolicy","d":1240294,"h":98785488102,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":115965357286,"f":1},"s":{"r":0,"d":0,"h":120260324582,"f":1},"n":"ClientCertificateRequired","d":1240294,"h":111670389990,"f":1},{"p":5611483,"g":{"r":0,"d":0,"h":128850259174,"f":1},"s":{"r":0,"d":0,"h":133145226470,"f":1},"n":"EnabledSslProtocols","d":1240294,"h":124555291878,"f":1},{"p":257254,"g":{"r":0,"d":0,"h":141735161062,"f":1},"s":{"r":0,"d":0,"h":146030128358,"f":1},"n":"EncryptionPolicy","d":1240294,"h":137440193766,"f":1},{"p":781542,"g":{"r":0,"d":0,"h":154620062950,"f":1},"s":{"r":0,"d":0,"h":158915030246,"f":1},"n":"RemoteCertificateValidationCallback","d":1240294,"h":150325095654,"f":1},{"p":28172903,"g":{"r":0,"d":0,"h":167504964838,"f":1},"s":{"r":0,"d":0,"h":171799932134,"f":1},"n":"ServerCertificate","d":1240294,"h":163209997542,"f":1},{"p":1371366,"g":{"r":0,"d":0,"h":180389866726,"f":1},"s":{"r":0,"d":0,"h":184684834022,"f":1},"n":"ServerCertificateContext","d":1240294,"h":176094899430,"f":1},{"p":847078,"g":{"r":0,"d":0,"h":193274768614,"f":1},"s":{"r":0,"d":0,"h":197569735910,"f":1},"n":"ServerCertificateSelectionCallback","d":1240294,"h":188979801318,"f":1}],"c":[{"n":".ctor","o":"$ctor$1","d":1240294,"h":4296207590,"f":1}],"h":1240294}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslServerAuthenticationOptions`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslStreamCertificateContext", ($self) => class SslStreamCertificateContext extends $.$spc.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Collections.ObjectModel.ReadOnlyCollection<System.Security.Cryptography.X509Certificates.X509Certificate2> */ get IntermediateCertificates()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate2 */ get TargetCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslStreamCertificateContext */ Create(/*System.Security.Cryptography.X509Certificates.X509Certificate2*/ target, /*System.Security.Cryptography.X509Certificates.X509Certificate2Collection?*/ additionalCertificates, /*bool*/ offline)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Security.SslStreamCertificateContext */ Create$1(/*System.Security.Cryptography.X509Certificates.X509Certificate2*/ target, /*System.Security.Cryptography.X509Certificates.X509Certificate2Collection?*/ additionalCertificates, /*bool*/ offline, /*System.Net.Security.SslCertificateTrust?*/ trust)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1371366;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$spc.System.Collections.ObjectModel.ReadOnlyCollection$$($.$sscr.System.Security.Cryptography.X509Certificates.X509Certificate2).$h,"g":{"r":0,"d":0,"h":12886273254,"f":1},"n":"IntermediateCertificates","d":1371366,"h":8591305958,"f":1},{"p":28238439,"g":{"r":0,"d":0,"h":21476207846,"f":1},"n":"TargetCertificate","d":1371366,"h":17181240550,"f":1}],"m":[{"r":1371366,"p":[{"n":"target","p":28238439},{"n":"additionalCertificates","p":28303975},{"n":"offline","p":262145}],"n":"Create","d":1371366,"h":25771175142,"f":33,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]}]},{"r":1371366,"p":[{"n":"target","p":28238439},{"n":"additionalCertificates","p":28303975},{"n":"offline","p":262145,"f":65,"v":false},{"n":"trust","p":1043686,"f":65}],"n":"Create","o":"@$1","d":1371366,"h":30066142438,"f":33}],"c":[{"n":".ctor","o":"$ctor$1","d":1371366,"h":4296338662,"f":8}],"h":1371366}; }
            static get $b() { return $.$spc.System.Object; }
            static get $fullName() { return `System.Net.Security.SslStreamCertificateContext`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateAuthentication", ($self) => class NegotiateAuthentication extends $.$spc.System.Object
        {
            $ctor$1(/*System.Net.Security.NegotiateAuthenticationClientOptions*/ clientOptions)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.Security.NegotiateAuthenticationServerOptions*/ serverOptions)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get Package()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.ProtectionLevel */ get ProtectionLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get RemoteIdentity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get TargetName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ ComputeIntegrityCheck(/*System.ReadOnlySpan<byte>*/ message, /*System.Buffers.IBufferWriter<byte>*/ signatureWriter)
            {
            }
            /*void */ Dispose()
            {
            }
            /*byte[]? */ GetOutgoingBlob(/*System.ReadOnlySpan<byte>*/ incomingBlob, /*out System.Net.Security.NegotiateAuthenticationStatusCode*/ statusCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ GetOutgoingBlob$1(/*string?*/ incomingBlob, /*out System.Net.Security.NegotiateAuthenticationStatusCode*/ statusCode)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ Unwrap(/*System.ReadOnlySpan<byte>*/ input, /*System.Buffers.IBufferWriter<byte>*/ outputWriter, /*out bool*/ wasEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ UnwrapInPlace(/*System.Span<byte>*/ input, /*out int*/ unwrappedOffset, /*out int*/ unwrappedLength, /*out bool*/ wasEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ VerifyIntegrityCheck(/*System.ReadOnlySpan<byte>*/ message, /*System.ReadOnlySpan<byte>*/ signature)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.NegotiateAuthenticationStatusCode */ Wrap(/*System.ReadOnlySpan<byte>*/ input, /*System.Buffers.IBufferWriter<byte>*/ outputWriter, /*bool*/ requestEncryption, /*out bool*/ isEncrypted)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 388326;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":117243905,"g":{"r":0,"d":0,"h":17180257510,"f":1},"n":"ImpersonationLevel","d":388326,"h":12885290214,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":25770192102,"f":1},"n":"IsAuthenticated","d":388326,"h":21475224806,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":34360126694,"f":1},"n":"IsEncrypted","d":388326,"h":30065159398,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":42950061286,"f":1},"n":"IsMutuallyAuthenticated","d":388326,"h":38655093990,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":51539995878,"f":1},"n":"IsServer","d":388326,"h":47245028582,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":60129930470,"f":1},"n":"IsSigned","d":388326,"h":55834963174,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":68719865062,"f":1},"n":"Package","d":388326,"h":64424897766,"f":1},{"p":716006,"g":{"r":0,"d":0,"h":77309799654,"f":1},"n":"ProtectionLevel","d":388326,"h":73014832358,"f":1},{"p":117047297,"g":{"r":0,"d":0,"h":85899734246,"f":1},"n":"RemoteIdentity","d":388326,"h":81604766950,"f":1},{"p":1310721,"g":{"r":0,"d":0,"h":94489668838,"f":1},"n":"TargetName","d":388326,"h":90194701542,"f":1}],"m":[{"r":65537,"p":[{"n":"message","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"signatureWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h}],"n":"ComputeIntegrityCheck","d":388326,"h":98784636134,"f":1},{"r":65537,"n":"Dispose","d":388326,"h":103079603430,"f":1},{"r":0,"p":[{"n":"incomingBlob","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"statusCode","p":584934,"f":2}],"n":"GetOutgoingBlob","d":388326,"h":107374570726,"f":1},{"r":1310721,"p":[{"n":"incomingBlob","p":1310721},{"n":"statusCode","p":584934,"f":2}],"n":"GetOutgoingBlob","o":"@$1","d":388326,"h":111669538022,"f":1},{"r":584934,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"outputWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h},{"n":"wasEncrypted","p":262145,"f":2}],"n":"Unwrap","d":388326,"h":115964505318,"f":1},{"r":584934,"p":[{"n":"input","p":$.$spc.System.Span$$($.$spc.System.Byte).$h},{"n":"unwrappedOffset","p":655361,"f":2},{"n":"unwrappedLength","p":655361,"f":2},{"n":"wasEncrypted","p":262145,"f":2}],"n":"UnwrapInPlace","d":388326,"h":120259472614,"f":1},{"r":262145,"p":[{"n":"message","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"signature","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"VerifyIntegrityCheck","d":388326,"h":124554439910,"f":1},{"r":584934,"p":[{"n":"input","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h},{"n":"outputWriter","p":$.$sm.System.Buffers.IBufferWriter$$($.$spc.System.Byte).$h},{"n":"requestEncryption","p":262145},{"n":"isEncrypted","p":262145,"f":2}],"n":"Wrap","d":388326,"h":128849407206,"f":1}],"c":[{"p":[{"n":"clientOptions","p":453862}],"n":".ctor","o":"$ctor$1","d":388326,"h":4295355622,"f":1},{"p":[{"n":"serverOptions","p":519398}],"n":".ctor","o":"$ctor$2","d":388326,"h":8590322918,"f":1}],"i":[57475073],"h":388326}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthentication`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy", ($self) => class ExtendedProtectionPolicy extends $.$spc.System.Object
        {
            $ctor$1(/*System.Runtime.Serialization.SerializationInfo*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ChannelBinding*/ customChannelBinding)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ProtectionScenario*/ protectionScenario, /*System.Collections.ICollection?*/ customServiceNames)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.Security.Authentication.ExtendedProtection.PolicyEnforcement*/ policyEnforcement, /*System.Security.Authentication.ExtendedProtection.ProtectionScenario*/ protectionScenario, /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection?*/ customServiceNames)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Security.Authentication.ExtendedProtection.ChannelBinding? */ get CustomChannelBinding()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection? */ get CustomServiceNames()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsExtendedProtection()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.PolicyEnforcement */ get PolicyEnforcement()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ProtectionScenario */ get ProtectionScenario()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ System$Runtime$Serialization$ISerializable$GetObjectData(/*System.Runtime.Serialization.SerializationInfo?*/ info, /*System.Runtime.Serialization.StreamingContext*/ context)
            {
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snsc.System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy.ToString.apply(this, arguments); }
            static $h = 1567974;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":5414875,"g":{"r":0,"d":0,"h":30066339046,"f":1},"n":"CustomChannelBinding","d":1567974,"h":25771371750,"f":1},{"p":1764582,"g":{"r":0,"d":0,"h":38656273638,"f":1},"n":"CustomServiceNames","d":1567974,"h":34361306342,"f":1},{"p":262145,"g":{"r":0,"d":0,"h":47246208230,"f":33},"n":"OSSupportsExtendedProtection","d":1567974,"h":42951240934,"f":33},{"p":1633510,"g":{"r":0,"d":0,"h":55836142822,"f":1},"n":"PolicyEnforcement","d":1567974,"h":51541175526,"f":1},{"p":1699046,"g":{"r":0,"d":0,"h":64426077414,"f":1},"n":"ProtectionScenario","d":1567974,"h":60131110118,"f":1}],"m":[{"r":1310721,"n":"ToString","d":1567974,"h":73016012006,"f":32769}],"c":[{"p":[{"n":"info","p":113967105},{"n":"context","p":114098177}],"n":".ctor","o":"$ctor$1","d":1567974,"h":4296535270,"f":4,"a":[{"t":33161217,"c":4328128513,"a":[{"v":1,"t":33226753}]},{"t":70909953,"c":8660844545,"a":[{"v":"This API supports obsolete formatter-based serialization. It should not be called or extended by application code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0051","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":[{"n":"policyEnforcement","p":1633510}],"n":".ctor","o":"$ctor$2","d":1567974,"h":8591502566,"f":1},{"p":[{"n":"policyEnforcement","p":1633510},{"n":"customChannelBinding","p":5414875}],"n":".ctor","o":"$ctor$3","d":1567974,"h":12886469862,"f":1},{"p":[{"n":"policyEnforcement","p":1633510},{"n":"protectionScenario","p":1699046},{"n":"customServiceNames","p":31326209}],"n":".ctor","o":"$ctor$4","d":1567974,"h":17181437158,"f":1},{"p":[{"n":"policyEnforcement","p":1633510},{"n":"protectionScenario","p":1699046},{"n":"customServiceNames","p":1764582}],"n":".ctor","o":"$ctor$5","d":1567974,"h":21476404454,"f":1}],"i":[113377281],"h":1567974}; }
            static get $b() { return $.$spc.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.SslClientHelloInfo", ($self) => class SslClientHelloInfo extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            $ctor$2(/*string*/ serverName, /*System.Security.Authentication.SslProtocols*/ sslProtocols)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*string */ get ServerName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocols()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$3()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 1174758;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1310721,"g":{"r":0,"d":0,"h":21476011238,"f":1},"n":"ServerName","d":1174758,"h":17181043942,"f":1},{"p":5611483,"g":{"r":0,"d":0,"h":30065945830,"f":1},"n":"SslProtocols","d":1174758,"h":25770978534,"f":1}],"l":[{"t":131073,"n":"_dummy","d":1174758,"h":4296142054,"f":2},{"t":655361,"n":"_dummyPrimitive","d":1174758,"h":8591109350,"f":2}],"c":[{"p":[{"n":"serverName","p":1310721},{"n":"sslProtocols","p":5611483}],"n":".ctor","o":"$ctor$2","d":1174758,"h":12886076646,"f":1},{"n":".ctor","o":"$ctor$3","d":1174758,"h":34360913126,"f":1}],"h":1174758}; }
            static get $b() { return $.$spc.System.ValueType; }
            static get $fullName() { return `System.Net.Security.SslClientHelloInfo`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.SslApplicationProtocol", ($self) => class SslApplicationProtocol extends $.$spc.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.Security.SslApplicationProtocol*/ static Http11;
            /*System.Net.Security.SslApplicationProtocol*/ static Http2;
            /*System.Net.Security.SslApplicationProtocol*/ static Http3;
            $ctor$2(/*byte[]*/ protocol)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            $ctor$3(/*string*/ protocol)
            {
                super.$ctor$1();
                {
                    throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*System.ReadOnlyMemory<byte> */ get Protocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Security.SslApplicationProtocol*/ other)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals(/*object?*/ obj)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals() { return $.$snsc.System.Net.Security.SslApplicationProtocol.Equals.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$snsc.System.Net.Security.SslApplicationProtocol.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Security.SslApplicationProtocol*/ left, /*System.Net.Security.SslApplicationProtocol*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Security.SslApplicationProtocol*/ left, /*System.Net.Security.SslApplicationProtocol*/ right)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$snsc.System.Net.Security.SslApplicationProtocol.ToString.apply(this, arguments); }
            //Generated interface implemetation for System.IEquatable<System.Net.Security.SslApplicationProtocol>.Equals(System.Net.Security.SslApplicationProtocol)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$4()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            //Static Initializer
            static $sinit()
            {
                {
                    this.Http11 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
                {
                    this.Http2 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
                {
                    this.Http3 = $.$default($.$snsc.System.Net.Security.SslApplicationProtocol);
                }
            }
            static $h = 978150;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h,"g":{"r":0,"d":0,"h":38655683814,"f":1},"n":"Protocol","d":978150,"h":34360716518,"f":1}],"m":[{"r":262145,"p":[{"n":"other","p":978150}],"n":"Equals","o":"@$2","d":978150,"h":42950651110,"f":1},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","d":978150,"h":47245618406,"f":32769},{"r":655361,"n":"GetHashCode","d":978150,"h":51540585702,"f":32769},{"r":1310721,"n":"ToString","d":978150,"h":64425487590,"f":32769}],"l":[{"t":131073,"n":"_dummy","d":978150,"h":4295945446,"f":2},{"t":655361,"n":"_dummyPrimitive","d":978150,"h":8590912742,"f":2},{"t":978150,"n":"Http11","d":978150,"h":12885880038,"f":33},{"t":978150,"n":"Http2","d":978150,"h":17180847334,"f":33},{"t":978150,"n":"Http3","d":978150,"h":21475814630,"f":33}],"c":[{"p":[{"n":"protocol","p":0}],"n":".ctor","o":"$ctor$2","d":978150,"h":25770781926,"f":1},{"p":[{"n":"protocol","p":1310721}],"n":".ctor","o":"$ctor$3","d":978150,"h":30065749222,"f":1},{"n":".ctor","o":"$ctor$4","d":978150,"h":68720454886,"f":1}],"i":[$.$spc.System.IEquatable$$($.$snsc.System.Net.Security.SslApplicationProtocol).$h],"h":978150}; }
            static get $b() { return $.$spc.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IEquatable$$($.$snsc.System.Net.Security.SslApplicationProtocol) ]; }
            static get $fullName() { return `System.Net.Security.SslApplicationProtocol`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.ExtendedProtection.ServiceNameCollection", ($self) => class ServiceNameCollection extends $.$scn.System.Collections.ReadOnlyCollectionBase
        {
            $ctor$2(/*System.Collections.ICollection*/ items)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*bool */ Contains(/*string?*/ searchServiceName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection */ Merge(/*System.Collections.IEnumerable*/ serviceNames)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExtendedProtection.ServiceNameCollection */ Merge$1(/*string*/ serviceName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1764582;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":589859,"m":[{"r":262145,"p":[{"n":"searchServiceName","p":1310721}],"n":"Contains","d":1764582,"h":8591699174,"f":1},{"r":1764582,"p":[{"n":"serviceNames","p":31588353}],"n":"Merge","d":1764582,"h":12886666470,"f":1},{"r":1764582,"p":[{"n":"serviceName","p":1310721}],"n":"Merge","o":"@$1","d":1764582,"h":17181633766,"f":1}],"c":[{"p":[{"n":"items","p":31326209}],"n":".ctor","o":"$ctor$2","d":1764582,"h":4296731878,"f":1}],"i":[31326209,31588353],"h":1764582}; }
            static get $b() { return $.$scn.System.Collections.ReadOnlyCollectionBase; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Collections.ICollection, $.$spc.System.Collections.IEnumerable ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ServiceNameCollection`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.EncryptionPolicy", ($self) => class EncryptionPolicy extends $.$spc.System.Enum
        {
            static RequireEncryption = 0;
            static AllowNoEncryption = 1;
            static NoEncryption = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "RequireEncryption": 0n,
                    "AllowNoEncryption": 1n,
                    "NoEncryption": 2n
                };
            }
            static $h = 257254;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":257254,"n":"RequireEncryption","d":257254,"h":4295224550,"f":33},{"t":257254,"n":"AllowNoEncryption","d":257254,"h":8590191846,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0040","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"t":257254,"n":"NoEncryption","d":257254,"h":12885159142,"f":33,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"EncryptionPolicy.NoEncryption and AllowEncryption significantly reduce security and should not be used in production code.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0040","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":257254,"h":17180126438,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":257254}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.EncryptionPolicy`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.NegotiateAuthenticationStatusCode", ($self) => class NegotiateAuthenticationStatusCode extends $.$spc.System.Enum
        {
            static Completed = 0;
            static ContinueNeeded = 1;
            static GenericFailure = 2;
            static BadBinding = 3;
            static Unsupported = 4;
            static MessageAltered = 5;
            static ContextExpired = 6;
            static CredentialsExpired = 7;
            static InvalidCredentials = 8;
            static InvalidToken = 9;
            static UnknownCredentials = 10;
            static QopNotSupported = 11;
            static OutOfSequence = 12;
            static SecurityQosFailed = 13;
            static TargetUnknown = 14;
            static ImpersonationValidationFailed = 15;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Completed": 0n,
                    "ContinueNeeded": 1n,
                    "GenericFailure": 2n,
                    "BadBinding": 3n,
                    "Unsupported": 4n,
                    "MessageAltered": 5n,
                    "ContextExpired": 6n,
                    "CredentialsExpired": 7n,
                    "InvalidCredentials": 8n,
                    "InvalidToken": 9n,
                    "UnknownCredentials": 10n,
                    "QopNotSupported": 11n,
                    "OutOfSequence": 12n,
                    "SecurityQosFailed": 13n,
                    "TargetUnknown": 14n,
                    "ImpersonationValidationFailed": 15n
                };
            }
            static $h = 584934;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":584934,"n":"Completed","d":584934,"h":4295552230,"f":33},{"t":584934,"n":"ContinueNeeded","d":584934,"h":8590519526,"f":33},{"t":584934,"n":"GenericFailure","d":584934,"h":12885486822,"f":33},{"t":584934,"n":"BadBinding","d":584934,"h":17180454118,"f":33},{"t":584934,"n":"Unsupported","d":584934,"h":21475421414,"f":33},{"t":584934,"n":"MessageAltered","d":584934,"h":25770388710,"f":33},{"t":584934,"n":"ContextExpired","d":584934,"h":30065356006,"f":33},{"t":584934,"n":"CredentialsExpired","d":584934,"h":34360323302,"f":33},{"t":584934,"n":"InvalidCredentials","d":584934,"h":38655290598,"f":33},{"t":584934,"n":"InvalidToken","d":584934,"h":42950257894,"f":33},{"t":584934,"n":"UnknownCredentials","d":584934,"h":47245225190,"f":33},{"t":584934,"n":"QopNotSupported","d":584934,"h":51540192486,"f":33},{"t":584934,"n":"OutOfSequence","d":584934,"h":55835159782,"f":33},{"t":584934,"n":"SecurityQosFailed","d":584934,"h":60130127078,"f":33},{"t":584934,"n":"TargetUnknown","d":584934,"h":64425094374,"f":33},{"t":584934,"n":"ImpersonationValidationFailed","d":584934,"h":68720061670,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":584934,"h":73015028966,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":584934}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.NegotiateAuthenticationStatusCode`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.ProtectionLevel", ($self) => class ProtectionLevel extends $.$spc.System.Enum
        {
            static None = 0;
            static Sign = 1;
            static EncryptAndSign = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Sign": 1n,
                    "EncryptAndSign": 2n
                };
            }
            static $h = 716006;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":716006,"n":"None","d":716006,"h":4295683302,"f":33},{"t":716006,"n":"Sign","d":716006,"h":8590650598,"f":33},{"t":716006,"n":"EncryptAndSign","d":716006,"h":12885617894,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":716006,"h":17180585190,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":716006}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.ProtectionLevel`; }
        });
        
        $asm.$str("$snsc.System.Net.Security.TlsCipherSuite", ($self) => class TlsCipherSuite extends $.$spc.System.Enum
        {
            static TLS_NULL_WITH_NULL_NULL = 0;
            static TLS_RSA_WITH_NULL_MD5 = 1;
            static TLS_RSA_WITH_NULL_SHA = 2;
            static TLS_RSA_EXPORT_WITH_RC4_40_MD5 = 3;
            static TLS_RSA_WITH_RC4_128_MD5 = 4;
            static TLS_RSA_WITH_RC4_128_SHA = 5;
            static TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5 = 6;
            static TLS_RSA_WITH_IDEA_CBC_SHA = 7;
            static TLS_RSA_EXPORT_WITH_DES40_CBC_SHA = 8;
            static TLS_RSA_WITH_DES_CBC_SHA = 9;
            static TLS_RSA_WITH_3DES_EDE_CBC_SHA = 10;
            static TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA = 11;
            static TLS_DH_DSS_WITH_DES_CBC_SHA = 12;
            static TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA = 13;
            static TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA = 14;
            static TLS_DH_RSA_WITH_DES_CBC_SHA = 15;
            static TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA = 16;
            static TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA = 17;
            static TLS_DHE_DSS_WITH_DES_CBC_SHA = 18;
            static TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA = 19;
            static TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA = 20;
            static TLS_DHE_RSA_WITH_DES_CBC_SHA = 21;
            static TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA = 22;
            static TLS_DH_anon_EXPORT_WITH_RC4_40_MD5 = 23;
            static TLS_DH_anon_WITH_RC4_128_MD5 = 24;
            static TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA = 25;
            static TLS_DH_anon_WITH_DES_CBC_SHA = 26;
            static TLS_DH_anon_WITH_3DES_EDE_CBC_SHA = 27;
            static TLS_KRB5_WITH_DES_CBC_SHA = 30;
            static TLS_KRB5_WITH_3DES_EDE_CBC_SHA = 31;
            static TLS_KRB5_WITH_RC4_128_SHA = 32;
            static TLS_KRB5_WITH_IDEA_CBC_SHA = 33;
            static TLS_KRB5_WITH_DES_CBC_MD5 = 34;
            static TLS_KRB5_WITH_3DES_EDE_CBC_MD5 = 35;
            static TLS_KRB5_WITH_RC4_128_MD5 = 36;
            static TLS_KRB5_WITH_IDEA_CBC_MD5 = 37;
            static TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA = 38;
            static TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA = 39;
            static TLS_KRB5_EXPORT_WITH_RC4_40_SHA = 40;
            static TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5 = 41;
            static TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5 = 42;
            static TLS_KRB5_EXPORT_WITH_RC4_40_MD5 = 43;
            static TLS_PSK_WITH_NULL_SHA = 44;
            static TLS_DHE_PSK_WITH_NULL_SHA = 45;
            static TLS_RSA_PSK_WITH_NULL_SHA = 46;
            static TLS_RSA_WITH_AES_128_CBC_SHA = 47;
            static TLS_DH_DSS_WITH_AES_128_CBC_SHA = 48;
            static TLS_DH_RSA_WITH_AES_128_CBC_SHA = 49;
            static TLS_DHE_DSS_WITH_AES_128_CBC_SHA = 50;
            static TLS_DHE_RSA_WITH_AES_128_CBC_SHA = 51;
            static TLS_DH_anon_WITH_AES_128_CBC_SHA = 52;
            static TLS_RSA_WITH_AES_256_CBC_SHA = 53;
            static TLS_DH_DSS_WITH_AES_256_CBC_SHA = 54;
            static TLS_DH_RSA_WITH_AES_256_CBC_SHA = 55;
            static TLS_DHE_DSS_WITH_AES_256_CBC_SHA = 56;
            static TLS_DHE_RSA_WITH_AES_256_CBC_SHA = 57;
            static TLS_DH_anon_WITH_AES_256_CBC_SHA = 58;
            static TLS_RSA_WITH_NULL_SHA256 = 59;
            static TLS_RSA_WITH_AES_128_CBC_SHA256 = 60;
            static TLS_RSA_WITH_AES_256_CBC_SHA256 = 61;
            static TLS_DH_DSS_WITH_AES_128_CBC_SHA256 = 62;
            static TLS_DH_RSA_WITH_AES_128_CBC_SHA256 = 63;
            static TLS_DHE_DSS_WITH_AES_128_CBC_SHA256 = 64;
            static TLS_RSA_WITH_CAMELLIA_128_CBC_SHA = 65;
            static TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA = 66;
            static TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA = 67;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA = 68;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA = 69;
            static TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA = 70;
            static TLS_DHE_RSA_WITH_AES_128_CBC_SHA256 = 103;
            static TLS_DH_DSS_WITH_AES_256_CBC_SHA256 = 104;
            static TLS_DH_RSA_WITH_AES_256_CBC_SHA256 = 105;
            static TLS_DHE_DSS_WITH_AES_256_CBC_SHA256 = 106;
            static TLS_DHE_RSA_WITH_AES_256_CBC_SHA256 = 107;
            static TLS_DH_anon_WITH_AES_128_CBC_SHA256 = 108;
            static TLS_DH_anon_WITH_AES_256_CBC_SHA256 = 109;
            static TLS_RSA_WITH_CAMELLIA_256_CBC_SHA = 132;
            static TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA = 133;
            static TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA = 134;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA = 135;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA = 136;
            static TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA = 137;
            static TLS_PSK_WITH_RC4_128_SHA = 138;
            static TLS_PSK_WITH_3DES_EDE_CBC_SHA = 139;
            static TLS_PSK_WITH_AES_128_CBC_SHA = 140;
            static TLS_PSK_WITH_AES_256_CBC_SHA = 141;
            static TLS_DHE_PSK_WITH_RC4_128_SHA = 142;
            static TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA = 143;
            static TLS_DHE_PSK_WITH_AES_128_CBC_SHA = 144;
            static TLS_DHE_PSK_WITH_AES_256_CBC_SHA = 145;
            static TLS_RSA_PSK_WITH_RC4_128_SHA = 146;
            static TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA = 147;
            static TLS_RSA_PSK_WITH_AES_128_CBC_SHA = 148;
            static TLS_RSA_PSK_WITH_AES_256_CBC_SHA = 149;
            static TLS_RSA_WITH_SEED_CBC_SHA = 150;
            static TLS_DH_DSS_WITH_SEED_CBC_SHA = 151;
            static TLS_DH_RSA_WITH_SEED_CBC_SHA = 152;
            static TLS_DHE_DSS_WITH_SEED_CBC_SHA = 153;
            static TLS_DHE_RSA_WITH_SEED_CBC_SHA = 154;
            static TLS_DH_anon_WITH_SEED_CBC_SHA = 155;
            static TLS_RSA_WITH_AES_128_GCM_SHA256 = 156;
            static TLS_RSA_WITH_AES_256_GCM_SHA384 = 157;
            static TLS_DHE_RSA_WITH_AES_128_GCM_SHA256 = 158;
            static TLS_DHE_RSA_WITH_AES_256_GCM_SHA384 = 159;
            static TLS_DH_RSA_WITH_AES_128_GCM_SHA256 = 160;
            static TLS_DH_RSA_WITH_AES_256_GCM_SHA384 = 161;
            static TLS_DHE_DSS_WITH_AES_128_GCM_SHA256 = 162;
            static TLS_DHE_DSS_WITH_AES_256_GCM_SHA384 = 163;
            static TLS_DH_DSS_WITH_AES_128_GCM_SHA256 = 164;
            static TLS_DH_DSS_WITH_AES_256_GCM_SHA384 = 165;
            static TLS_DH_anon_WITH_AES_128_GCM_SHA256 = 166;
            static TLS_DH_anon_WITH_AES_256_GCM_SHA384 = 167;
            static TLS_PSK_WITH_AES_128_GCM_SHA256 = 168;
            static TLS_PSK_WITH_AES_256_GCM_SHA384 = 169;
            static TLS_DHE_PSK_WITH_AES_128_GCM_SHA256 = 170;
            static TLS_DHE_PSK_WITH_AES_256_GCM_SHA384 = 171;
            static TLS_RSA_PSK_WITH_AES_128_GCM_SHA256 = 172;
            static TLS_RSA_PSK_WITH_AES_256_GCM_SHA384 = 173;
            static TLS_PSK_WITH_AES_128_CBC_SHA256 = 174;
            static TLS_PSK_WITH_AES_256_CBC_SHA384 = 175;
            static TLS_PSK_WITH_NULL_SHA256 = 176;
            static TLS_PSK_WITH_NULL_SHA384 = 177;
            static TLS_DHE_PSK_WITH_AES_128_CBC_SHA256 = 178;
            static TLS_DHE_PSK_WITH_AES_256_CBC_SHA384 = 179;
            static TLS_DHE_PSK_WITH_NULL_SHA256 = 180;
            static TLS_DHE_PSK_WITH_NULL_SHA384 = 181;
            static TLS_RSA_PSK_WITH_AES_128_CBC_SHA256 = 182;
            static TLS_RSA_PSK_WITH_AES_256_CBC_SHA384 = 183;
            static TLS_RSA_PSK_WITH_NULL_SHA256 = 184;
            static TLS_RSA_PSK_WITH_NULL_SHA384 = 185;
            static TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 186;
            static TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256 = 187;
            static TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 188;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256 = 189;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 190;
            static TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256 = 191;
            static TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 192;
            static TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256 = 193;
            static TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 194;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256 = 195;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256 = 196;
            static TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256 = 197;
            static TLS_AES_128_GCM_SHA256 = 4865;
            static TLS_AES_256_GCM_SHA384 = 4866;
            static TLS_CHACHA20_POLY1305_SHA256 = 4867;
            static TLS_AES_128_CCM_SHA256 = 4868;
            static TLS_AES_128_CCM_8_SHA256 = 4869;
            static TLS_ECDH_ECDSA_WITH_NULL_SHA = 49153;
            static TLS_ECDH_ECDSA_WITH_RC4_128_SHA = 49154;
            static TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA = 49155;
            static TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA = 49156;
            static TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA = 49157;
            static TLS_ECDHE_ECDSA_WITH_NULL_SHA = 49158;
            static TLS_ECDHE_ECDSA_WITH_RC4_128_SHA = 49159;
            static TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA = 49160;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA = 49161;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA = 49162;
            static TLS_ECDH_RSA_WITH_NULL_SHA = 49163;
            static TLS_ECDH_RSA_WITH_RC4_128_SHA = 49164;
            static TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA = 49165;
            static TLS_ECDH_RSA_WITH_AES_128_CBC_SHA = 49166;
            static TLS_ECDH_RSA_WITH_AES_256_CBC_SHA = 49167;
            static TLS_ECDHE_RSA_WITH_NULL_SHA = 49168;
            static TLS_ECDHE_RSA_WITH_RC4_128_SHA = 49169;
            static TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA = 49170;
            static TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA = 49171;
            static TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA = 49172;
            static TLS_ECDH_anon_WITH_NULL_SHA = 49173;
            static TLS_ECDH_anon_WITH_RC4_128_SHA = 49174;
            static TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA = 49175;
            static TLS_ECDH_anon_WITH_AES_128_CBC_SHA = 49176;
            static TLS_ECDH_anon_WITH_AES_256_CBC_SHA = 49177;
            static TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA = 49178;
            static TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA = 49179;
            static TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA = 49180;
            static TLS_SRP_SHA_WITH_AES_128_CBC_SHA = 49181;
            static TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA = 49182;
            static TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA = 49183;
            static TLS_SRP_SHA_WITH_AES_256_CBC_SHA = 49184;
            static TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA = 49185;
            static TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA = 49186;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256 = 49187;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384 = 49188;
            static TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256 = 49189;
            static TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384 = 49190;
            static TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256 = 49191;
            static TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384 = 49192;
            static TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256 = 49193;
            static TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384 = 49194;
            static TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256 = 49195;
            static TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384 = 49196;
            static TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256 = 49197;
            static TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384 = 49198;
            static TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 = 49199;
            static TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384 = 49200;
            static TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256 = 49201;
            static TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384 = 49202;
            static TLS_ECDHE_PSK_WITH_RC4_128_SHA = 49203;
            static TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA = 49204;
            static TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA = 49205;
            static TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA = 49206;
            static TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256 = 49207;
            static TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384 = 49208;
            static TLS_ECDHE_PSK_WITH_NULL_SHA = 49209;
            static TLS_ECDHE_PSK_WITH_NULL_SHA256 = 49210;
            static TLS_ECDHE_PSK_WITH_NULL_SHA384 = 49211;
            static TLS_RSA_WITH_ARIA_128_CBC_SHA256 = 49212;
            static TLS_RSA_WITH_ARIA_256_CBC_SHA384 = 49213;
            static TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256 = 49214;
            static TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384 = 49215;
            static TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256 = 49216;
            static TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384 = 49217;
            static TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256 = 49218;
            static TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384 = 49219;
            static TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256 = 49220;
            static TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384 = 49221;
            static TLS_DH_anon_WITH_ARIA_128_CBC_SHA256 = 49222;
            static TLS_DH_anon_WITH_ARIA_256_CBC_SHA384 = 49223;
            static TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256 = 49224;
            static TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384 = 49225;
            static TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256 = 49226;
            static TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384 = 49227;
            static TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256 = 49228;
            static TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384 = 49229;
            static TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256 = 49230;
            static TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384 = 49231;
            static TLS_RSA_WITH_ARIA_128_GCM_SHA256 = 49232;
            static TLS_RSA_WITH_ARIA_256_GCM_SHA384 = 49233;
            static TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256 = 49234;
            static TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384 = 49235;
            static TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256 = 49236;
            static TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384 = 49237;
            static TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256 = 49238;
            static TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384 = 49239;
            static TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256 = 49240;
            static TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384 = 49241;
            static TLS_DH_anon_WITH_ARIA_128_GCM_SHA256 = 49242;
            static TLS_DH_anon_WITH_ARIA_256_GCM_SHA384 = 49243;
            static TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256 = 49244;
            static TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384 = 49245;
            static TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256 = 49246;
            static TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384 = 49247;
            static TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256 = 49248;
            static TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384 = 49249;
            static TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256 = 49250;
            static TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384 = 49251;
            static TLS_PSK_WITH_ARIA_128_CBC_SHA256 = 49252;
            static TLS_PSK_WITH_ARIA_256_CBC_SHA384 = 49253;
            static TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256 = 49254;
            static TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384 = 49255;
            static TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256 = 49256;
            static TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384 = 49257;
            static TLS_PSK_WITH_ARIA_128_GCM_SHA256 = 49258;
            static TLS_PSK_WITH_ARIA_256_GCM_SHA384 = 49259;
            static TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256 = 49260;
            static TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384 = 49261;
            static TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256 = 49262;
            static TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384 = 49263;
            static TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256 = 49264;
            static TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384 = 49265;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 = 49266;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 = 49267;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256 = 49268;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384 = 49269;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 49270;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384 = 49271;
            static TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256 = 49272;
            static TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384 = 49273;
            static TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49274;
            static TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49275;
            static TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49276;
            static TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49277;
            static TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49278;
            static TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49279;
            static TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256 = 49280;
            static TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384 = 49281;
            static TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256 = 49282;
            static TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384 = 49283;
            static TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256 = 49284;
            static TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384 = 49285;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 = 49286;
            static TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 = 49287;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256 = 49288;
            static TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384 = 49289;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49290;
            static TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49291;
            static TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256 = 49292;
            static TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384 = 49293;
            static TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49294;
            static TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49295;
            static TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49296;
            static TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49297;
            static TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256 = 49298;
            static TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384 = 49299;
            static TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49300;
            static TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49301;
            static TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49302;
            static TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49303;
            static TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49304;
            static TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49305;
            static TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256 = 49306;
            static TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384 = 49307;
            static TLS_RSA_WITH_AES_128_CCM = 49308;
            static TLS_RSA_WITH_AES_256_CCM = 49309;
            static TLS_DHE_RSA_WITH_AES_128_CCM = 49310;
            static TLS_DHE_RSA_WITH_AES_256_CCM = 49311;
            static TLS_RSA_WITH_AES_128_CCM_8 = 49312;
            static TLS_RSA_WITH_AES_256_CCM_8 = 49313;
            static TLS_DHE_RSA_WITH_AES_128_CCM_8 = 49314;
            static TLS_DHE_RSA_WITH_AES_256_CCM_8 = 49315;
            static TLS_PSK_WITH_AES_128_CCM = 49316;
            static TLS_PSK_WITH_AES_256_CCM = 49317;
            static TLS_DHE_PSK_WITH_AES_128_CCM = 49318;
            static TLS_DHE_PSK_WITH_AES_256_CCM = 49319;
            static TLS_PSK_WITH_AES_128_CCM_8 = 49320;
            static TLS_PSK_WITH_AES_256_CCM_8 = 49321;
            static TLS_PSK_DHE_WITH_AES_128_CCM_8 = 49322;
            static TLS_PSK_DHE_WITH_AES_256_CCM_8 = 49323;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CCM = 49324;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CCM = 49325;
            static TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8 = 49326;
            static TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8 = 49327;
            static TLS_ECCPWD_WITH_AES_128_GCM_SHA256 = 49328;
            static TLS_ECCPWD_WITH_AES_256_GCM_SHA384 = 49329;
            static TLS_ECCPWD_WITH_AES_128_CCM_SHA256 = 49330;
            static TLS_ECCPWD_WITH_AES_256_CCM_SHA384 = 49331;
            static TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256 = 52392;
            static TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256 = 52393;
            static TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256 = 52394;
            static TLS_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52395;
            static TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52396;
            static TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52397;
            static TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256 = 52398;
            static TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256 = 53249;
            static TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384 = 53250;
            static TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256 = 53251;
            static TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256 = 53253;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TLS_NULL_WITH_NULL_NULL": 0n,
                    "TLS_RSA_WITH_NULL_MD5": 1n,
                    "TLS_RSA_WITH_NULL_SHA": 2n,
                    "TLS_RSA_EXPORT_WITH_RC4_40_MD5": 3n,
                    "TLS_RSA_WITH_RC4_128_MD5": 4n,
                    "TLS_RSA_WITH_RC4_128_SHA": 5n,
                    "TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5": 6n,
                    "TLS_RSA_WITH_IDEA_CBC_SHA": 7n,
                    "TLS_RSA_EXPORT_WITH_DES40_CBC_SHA": 8n,
                    "TLS_RSA_WITH_DES_CBC_SHA": 9n,
                    "TLS_RSA_WITH_3DES_EDE_CBC_SHA": 10n,
                    "TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA": 11n,
                    "TLS_DH_DSS_WITH_DES_CBC_SHA": 12n,
                    "TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA": 13n,
                    "TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA": 14n,
                    "TLS_DH_RSA_WITH_DES_CBC_SHA": 15n,
                    "TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA": 16n,
                    "TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA": 17n,
                    "TLS_DHE_DSS_WITH_DES_CBC_SHA": 18n,
                    "TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA": 19n,
                    "TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA": 20n,
                    "TLS_DHE_RSA_WITH_DES_CBC_SHA": 21n,
                    "TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA": 22n,
                    "TLS_DH_anon_EXPORT_WITH_RC4_40_MD5": 23n,
                    "TLS_DH_anon_WITH_RC4_128_MD5": 24n,
                    "TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA": 25n,
                    "TLS_DH_anon_WITH_DES_CBC_SHA": 26n,
                    "TLS_DH_anon_WITH_3DES_EDE_CBC_SHA": 27n,
                    "TLS_KRB5_WITH_DES_CBC_SHA": 30n,
                    "TLS_KRB5_WITH_3DES_EDE_CBC_SHA": 31n,
                    "TLS_KRB5_WITH_RC4_128_SHA": 32n,
                    "TLS_KRB5_WITH_IDEA_CBC_SHA": 33n,
                    "TLS_KRB5_WITH_DES_CBC_MD5": 34n,
                    "TLS_KRB5_WITH_3DES_EDE_CBC_MD5": 35n,
                    "TLS_KRB5_WITH_RC4_128_MD5": 36n,
                    "TLS_KRB5_WITH_IDEA_CBC_MD5": 37n,
                    "TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA": 38n,
                    "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA": 39n,
                    "TLS_KRB5_EXPORT_WITH_RC4_40_SHA": 40n,
                    "TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5": 41n,
                    "TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5": 42n,
                    "TLS_KRB5_EXPORT_WITH_RC4_40_MD5": 43n,
                    "TLS_PSK_WITH_NULL_SHA": 44n,
                    "TLS_DHE_PSK_WITH_NULL_SHA": 45n,
                    "TLS_RSA_PSK_WITH_NULL_SHA": 46n,
                    "TLS_RSA_WITH_AES_128_CBC_SHA": 47n,
                    "TLS_DH_DSS_WITH_AES_128_CBC_SHA": 48n,
                    "TLS_DH_RSA_WITH_AES_128_CBC_SHA": 49n,
                    "TLS_DHE_DSS_WITH_AES_128_CBC_SHA": 50n,
                    "TLS_DHE_RSA_WITH_AES_128_CBC_SHA": 51n,
                    "TLS_DH_anon_WITH_AES_128_CBC_SHA": 52n,
                    "TLS_RSA_WITH_AES_256_CBC_SHA": 53n,
                    "TLS_DH_DSS_WITH_AES_256_CBC_SHA": 54n,
                    "TLS_DH_RSA_WITH_AES_256_CBC_SHA": 55n,
                    "TLS_DHE_DSS_WITH_AES_256_CBC_SHA": 56n,
                    "TLS_DHE_RSA_WITH_AES_256_CBC_SHA": 57n,
                    "TLS_DH_anon_WITH_AES_256_CBC_SHA": 58n,
                    "TLS_RSA_WITH_NULL_SHA256": 59n,
                    "TLS_RSA_WITH_AES_128_CBC_SHA256": 60n,
                    "TLS_RSA_WITH_AES_256_CBC_SHA256": 61n,
                    "TLS_DH_DSS_WITH_AES_128_CBC_SHA256": 62n,
                    "TLS_DH_RSA_WITH_AES_128_CBC_SHA256": 63n,
                    "TLS_DHE_DSS_WITH_AES_128_CBC_SHA256": 64n,
                    "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA": 65n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA": 66n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA": 67n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA": 68n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA": 69n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA": 70n,
                    "TLS_DHE_RSA_WITH_AES_128_CBC_SHA256": 103n,
                    "TLS_DH_DSS_WITH_AES_256_CBC_SHA256": 104n,
                    "TLS_DH_RSA_WITH_AES_256_CBC_SHA256": 105n,
                    "TLS_DHE_DSS_WITH_AES_256_CBC_SHA256": 106n,
                    "TLS_DHE_RSA_WITH_AES_256_CBC_SHA256": 107n,
                    "TLS_DH_anon_WITH_AES_128_CBC_SHA256": 108n,
                    "TLS_DH_anon_WITH_AES_256_CBC_SHA256": 109n,
                    "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA": 132n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA": 133n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA": 134n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA": 135n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA": 136n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA": 137n,
                    "TLS_PSK_WITH_RC4_128_SHA": 138n,
                    "TLS_PSK_WITH_3DES_EDE_CBC_SHA": 139n,
                    "TLS_PSK_WITH_AES_128_CBC_SHA": 140n,
                    "TLS_PSK_WITH_AES_256_CBC_SHA": 141n,
                    "TLS_DHE_PSK_WITH_RC4_128_SHA": 142n,
                    "TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA": 143n,
                    "TLS_DHE_PSK_WITH_AES_128_CBC_SHA": 144n,
                    "TLS_DHE_PSK_WITH_AES_256_CBC_SHA": 145n,
                    "TLS_RSA_PSK_WITH_RC4_128_SHA": 146n,
                    "TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA": 147n,
                    "TLS_RSA_PSK_WITH_AES_128_CBC_SHA": 148n,
                    "TLS_RSA_PSK_WITH_AES_256_CBC_SHA": 149n,
                    "TLS_RSA_WITH_SEED_CBC_SHA": 150n,
                    "TLS_DH_DSS_WITH_SEED_CBC_SHA": 151n,
                    "TLS_DH_RSA_WITH_SEED_CBC_SHA": 152n,
                    "TLS_DHE_DSS_WITH_SEED_CBC_SHA": 153n,
                    "TLS_DHE_RSA_WITH_SEED_CBC_SHA": 154n,
                    "TLS_DH_anon_WITH_SEED_CBC_SHA": 155n,
                    "TLS_RSA_WITH_AES_128_GCM_SHA256": 156n,
                    "TLS_RSA_WITH_AES_256_GCM_SHA384": 157n,
                    "TLS_DHE_RSA_WITH_AES_128_GCM_SHA256": 158n,
                    "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384": 159n,
                    "TLS_DH_RSA_WITH_AES_128_GCM_SHA256": 160n,
                    "TLS_DH_RSA_WITH_AES_256_GCM_SHA384": 161n,
                    "TLS_DHE_DSS_WITH_AES_128_GCM_SHA256": 162n,
                    "TLS_DHE_DSS_WITH_AES_256_GCM_SHA384": 163n,
                    "TLS_DH_DSS_WITH_AES_128_GCM_SHA256": 164n,
                    "TLS_DH_DSS_WITH_AES_256_GCM_SHA384": 165n,
                    "TLS_DH_anon_WITH_AES_128_GCM_SHA256": 166n,
                    "TLS_DH_anon_WITH_AES_256_GCM_SHA384": 167n,
                    "TLS_PSK_WITH_AES_128_GCM_SHA256": 168n,
                    "TLS_PSK_WITH_AES_256_GCM_SHA384": 169n,
                    "TLS_DHE_PSK_WITH_AES_128_GCM_SHA256": 170n,
                    "TLS_DHE_PSK_WITH_AES_256_GCM_SHA384": 171n,
                    "TLS_RSA_PSK_WITH_AES_128_GCM_SHA256": 172n,
                    "TLS_RSA_PSK_WITH_AES_256_GCM_SHA384": 173n,
                    "TLS_PSK_WITH_AES_128_CBC_SHA256": 174n,
                    "TLS_PSK_WITH_AES_256_CBC_SHA384": 175n,
                    "TLS_PSK_WITH_NULL_SHA256": 176n,
                    "TLS_PSK_WITH_NULL_SHA384": 177n,
                    "TLS_DHE_PSK_WITH_AES_128_CBC_SHA256": 178n,
                    "TLS_DHE_PSK_WITH_AES_256_CBC_SHA384": 179n,
                    "TLS_DHE_PSK_WITH_NULL_SHA256": 180n,
                    "TLS_DHE_PSK_WITH_NULL_SHA384": 181n,
                    "TLS_RSA_PSK_WITH_AES_128_CBC_SHA256": 182n,
                    "TLS_RSA_PSK_WITH_AES_256_CBC_SHA384": 183n,
                    "TLS_RSA_PSK_WITH_NULL_SHA256": 184n,
                    "TLS_RSA_PSK_WITH_NULL_SHA384": 185n,
                    "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256": 186n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256": 187n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256": 188n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256": 189n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256": 190n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256": 191n,
                    "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256": 192n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256": 193n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256": 194n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256": 195n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256": 196n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256": 197n,
                    "TLS_AES_128_GCM_SHA256": 4865n,
                    "TLS_AES_256_GCM_SHA384": 4866n,
                    "TLS_CHACHA20_POLY1305_SHA256": 4867n,
                    "TLS_AES_128_CCM_SHA256": 4868n,
                    "TLS_AES_128_CCM_8_SHA256": 4869n,
                    "TLS_ECDH_ECDSA_WITH_NULL_SHA": 49153n,
                    "TLS_ECDH_ECDSA_WITH_RC4_128_SHA": 49154n,
                    "TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA": 49155n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA": 49156n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA": 49157n,
                    "TLS_ECDHE_ECDSA_WITH_NULL_SHA": 49158n,
                    "TLS_ECDHE_ECDSA_WITH_RC4_128_SHA": 49159n,
                    "TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA": 49160n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA": 49161n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA": 49162n,
                    "TLS_ECDH_RSA_WITH_NULL_SHA": 49163n,
                    "TLS_ECDH_RSA_WITH_RC4_128_SHA": 49164n,
                    "TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA": 49165n,
                    "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA": 49166n,
                    "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA": 49167n,
                    "TLS_ECDHE_RSA_WITH_NULL_SHA": 49168n,
                    "TLS_ECDHE_RSA_WITH_RC4_128_SHA": 49169n,
                    "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA": 49170n,
                    "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA": 49171n,
                    "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA": 49172n,
                    "TLS_ECDH_anon_WITH_NULL_SHA": 49173n,
                    "TLS_ECDH_anon_WITH_RC4_128_SHA": 49174n,
                    "TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA": 49175n,
                    "TLS_ECDH_anon_WITH_AES_128_CBC_SHA": 49176n,
                    "TLS_ECDH_anon_WITH_AES_256_CBC_SHA": 49177n,
                    "TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA": 49178n,
                    "TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA": 49179n,
                    "TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA": 49180n,
                    "TLS_SRP_SHA_WITH_AES_128_CBC_SHA": 49181n,
                    "TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA": 49182n,
                    "TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA": 49183n,
                    "TLS_SRP_SHA_WITH_AES_256_CBC_SHA": 49184n,
                    "TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA": 49185n,
                    "TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA": 49186n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256": 49187n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384": 49188n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256": 49189n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384": 49190n,
                    "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256": 49191n,
                    "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384": 49192n,
                    "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256": 49193n,
                    "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384": 49194n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256": 49195n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384": 49196n,
                    "TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256": 49197n,
                    "TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384": 49198n,
                    "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256": 49199n,
                    "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384": 49200n,
                    "TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256": 49201n,
                    "TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384": 49202n,
                    "TLS_ECDHE_PSK_WITH_RC4_128_SHA": 49203n,
                    "TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA": 49204n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA": 49205n,
                    "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA": 49206n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256": 49207n,
                    "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384": 49208n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA": 49209n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA256": 49210n,
                    "TLS_ECDHE_PSK_WITH_NULL_SHA384": 49211n,
                    "TLS_RSA_WITH_ARIA_128_CBC_SHA256": 49212n,
                    "TLS_RSA_WITH_ARIA_256_CBC_SHA384": 49213n,
                    "TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256": 49214n,
                    "TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384": 49215n,
                    "TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256": 49216n,
                    "TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384": 49217n,
                    "TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256": 49218n,
                    "TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384": 49219n,
                    "TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256": 49220n,
                    "TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384": 49221n,
                    "TLS_DH_anon_WITH_ARIA_128_CBC_SHA256": 49222n,
                    "TLS_DH_anon_WITH_ARIA_256_CBC_SHA384": 49223n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256": 49224n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384": 49225n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256": 49226n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384": 49227n,
                    "TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256": 49228n,
                    "TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384": 49229n,
                    "TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256": 49230n,
                    "TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384": 49231n,
                    "TLS_RSA_WITH_ARIA_128_GCM_SHA256": 49232n,
                    "TLS_RSA_WITH_ARIA_256_GCM_SHA384": 49233n,
                    "TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256": 49234n,
                    "TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384": 49235n,
                    "TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256": 49236n,
                    "TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384": 49237n,
                    "TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256": 49238n,
                    "TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384": 49239n,
                    "TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256": 49240n,
                    "TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384": 49241n,
                    "TLS_DH_anon_WITH_ARIA_128_GCM_SHA256": 49242n,
                    "TLS_DH_anon_WITH_ARIA_256_GCM_SHA384": 49243n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256": 49244n,
                    "TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384": 49245n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256": 49246n,
                    "TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384": 49247n,
                    "TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256": 49248n,
                    "TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384": 49249n,
                    "TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256": 49250n,
                    "TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384": 49251n,
                    "TLS_PSK_WITH_ARIA_128_CBC_SHA256": 49252n,
                    "TLS_PSK_WITH_ARIA_256_CBC_SHA384": 49253n,
                    "TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256": 49254n,
                    "TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384": 49255n,
                    "TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256": 49256n,
                    "TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384": 49257n,
                    "TLS_PSK_WITH_ARIA_128_GCM_SHA256": 49258n,
                    "TLS_PSK_WITH_ARIA_256_GCM_SHA384": 49259n,
                    "TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256": 49260n,
                    "TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384": 49261n,
                    "TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256": 49262n,
                    "TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384": 49263n,
                    "TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256": 49264n,
                    "TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384": 49265n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256": 49266n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384": 49267n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256": 49268n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384": 49269n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256": 49270n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384": 49271n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256": 49272n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384": 49273n,
                    "TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49274n,
                    "TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49275n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49276n,
                    "TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49277n,
                    "TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49278n,
                    "TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49279n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256": 49280n,
                    "TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384": 49281n,
                    "TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256": 49282n,
                    "TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384": 49283n,
                    "TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256": 49284n,
                    "TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384": 49285n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256": 49286n,
                    "TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384": 49287n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256": 49288n,
                    "TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384": 49289n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49290n,
                    "TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49291n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256": 49292n,
                    "TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384": 49293n,
                    "TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49294n,
                    "TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49295n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49296n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49297n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256": 49298n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384": 49299n,
                    "TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49300n,
                    "TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49301n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49302n,
                    "TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49303n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49304n,
                    "TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49305n,
                    "TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256": 49306n,
                    "TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384": 49307n,
                    "TLS_RSA_WITH_AES_128_CCM": 49308n,
                    "TLS_RSA_WITH_AES_256_CCM": 49309n,
                    "TLS_DHE_RSA_WITH_AES_128_CCM": 49310n,
                    "TLS_DHE_RSA_WITH_AES_256_CCM": 49311n,
                    "TLS_RSA_WITH_AES_128_CCM_8": 49312n,
                    "TLS_RSA_WITH_AES_256_CCM_8": 49313n,
                    "TLS_DHE_RSA_WITH_AES_128_CCM_8": 49314n,
                    "TLS_DHE_RSA_WITH_AES_256_CCM_8": 49315n,
                    "TLS_PSK_WITH_AES_128_CCM": 49316n,
                    "TLS_PSK_WITH_AES_256_CCM": 49317n,
                    "TLS_DHE_PSK_WITH_AES_128_CCM": 49318n,
                    "TLS_DHE_PSK_WITH_AES_256_CCM": 49319n,
                    "TLS_PSK_WITH_AES_128_CCM_8": 49320n,
                    "TLS_PSK_WITH_AES_256_CCM_8": 49321n,
                    "TLS_PSK_DHE_WITH_AES_128_CCM_8": 49322n,
                    "TLS_PSK_DHE_WITH_AES_256_CCM_8": 49323n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CCM": 49324n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CCM": 49325n,
                    "TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8": 49326n,
                    "TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8": 49327n,
                    "TLS_ECCPWD_WITH_AES_128_GCM_SHA256": 49328n,
                    "TLS_ECCPWD_WITH_AES_256_GCM_SHA384": 49329n,
                    "TLS_ECCPWD_WITH_AES_128_CCM_SHA256": 49330n,
                    "TLS_ECCPWD_WITH_AES_256_CCM_SHA384": 49331n,
                    "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256": 52392n,
                    "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256": 52393n,
                    "TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256": 52394n,
                    "TLS_PSK_WITH_CHACHA20_POLY1305_SHA256": 52395n,
                    "TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256": 52396n,
                    "TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256": 52397n,
                    "TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256": 52398n,
                    "TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256": 53249n,
                    "TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384": 53250n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256": 53251n,
                    "TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256": 53253n
                };
            }
            static $h = 1436902;
            static $z = 2;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.UInt16; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":589825,"l":[{"t":1436902,"n":"TLS_NULL_WITH_NULL_NULL","d":1436902,"h":4296404198,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_NULL_MD5","d":1436902,"h":8591371494,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_NULL_SHA","d":1436902,"h":12886338790,"f":33},{"t":1436902,"n":"TLS_RSA_EXPORT_WITH_RC4_40_MD5","d":1436902,"h":17181306086,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_RC4_128_MD5","d":1436902,"h":21476273382,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_RC4_128_SHA","d":1436902,"h":25771240678,"f":33},{"t":1436902,"n":"TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5","d":1436902,"h":30066207974,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_IDEA_CBC_SHA","d":1436902,"h":34361175270,"f":33},{"t":1436902,"n":"TLS_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1436902,"h":38656142566,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_DES_CBC_SHA","d":1436902,"h":42951109862,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":47246077158,"f":33},{"t":1436902,"n":"TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA","d":1436902,"h":51541044454,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_DES_CBC_SHA","d":1436902,"h":55836011750,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":60130979046,"f":33},{"t":1436902,"n":"TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1436902,"h":64425946342,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_DES_CBC_SHA","d":1436902,"h":68720913638,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":73015880934,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA","d":1436902,"h":77310848230,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_DES_CBC_SHA","d":1436902,"h":81605815526,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":85900782822,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA","d":1436902,"h":90195750118,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_DES_CBC_SHA","d":1436902,"h":94490717414,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":98785684710,"f":33},{"t":1436902,"n":"TLS_DH_anon_EXPORT_WITH_RC4_40_MD5","d":1436902,"h":103080652006,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_RC4_128_MD5","d":1436902,"h":107375619302,"f":33},{"t":1436902,"n":"TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA","d":1436902,"h":111670586598,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_DES_CBC_SHA","d":1436902,"h":115965553894,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":120260521190,"f":33},{"t":1436902,"n":"TLS_KRB5_WITH_DES_CBC_SHA","d":1436902,"h":124555488486,"f":33},{"t":1436902,"n":"TLS_KRB5_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":128850455782,"f":33},{"t":1436902,"n":"TLS_KRB5_WITH_RC4_128_SHA","d":1436902,"h":133145423078,"f":33},{"t":1436902,"n":"TLS_KRB5_WITH_IDEA_CBC_SHA","d":1436902,"h":137440390374,"f":33},{"t":1436902,"n":"TLS_KRB5_WITH_DES_CBC_MD5","d":1436902,"h":141735357670,"f":33},{"t":1436902,"n":"TLS_KRB5_WITH_3DES_EDE_CBC_MD5","d":1436902,"h":146030324966,"f":33},{"t":1436902,"n":"TLS_KRB5_WITH_RC4_128_MD5","d":1436902,"h":150325292262,"f":33},{"t":1436902,"n":"TLS_KRB5_WITH_IDEA_CBC_MD5","d":1436902,"h":154620259558,"f":33},{"t":1436902,"n":"TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA","d":1436902,"h":158915226854,"f":33},{"t":1436902,"n":"TLS_KRB5_EXPORT_WITH_RC2_CBC_40_SHA","d":1436902,"h":163210194150,"f":33},{"t":1436902,"n":"TLS_KRB5_EXPORT_WITH_RC4_40_SHA","d":1436902,"h":167505161446,"f":33},{"t":1436902,"n":"TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5","d":1436902,"h":171800128742,"f":33},{"t":1436902,"n":"TLS_KRB5_EXPORT_WITH_RC2_CBC_40_MD5","d":1436902,"h":176095096038,"f":33},{"t":1436902,"n":"TLS_KRB5_EXPORT_WITH_RC4_40_MD5","d":1436902,"h":180390063334,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_NULL_SHA","d":1436902,"h":184685030630,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_NULL_SHA","d":1436902,"h":188979997926,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_NULL_SHA","d":1436902,"h":193274965222,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_AES_128_CBC_SHA","d":1436902,"h":197569932518,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_AES_128_CBC_SHA","d":1436902,"h":201864899814,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_AES_128_CBC_SHA","d":1436902,"h":206159867110,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_AES_128_CBC_SHA","d":1436902,"h":210454834406,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_AES_128_CBC_SHA","d":1436902,"h":214749801702,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_AES_128_CBC_SHA","d":1436902,"h":219044768998,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_AES_256_CBC_SHA","d":1436902,"h":223339736294,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_AES_256_CBC_SHA","d":1436902,"h":227634703590,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_AES_256_CBC_SHA","d":1436902,"h":231929670886,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_AES_256_CBC_SHA","d":1436902,"h":236224638182,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_AES_256_CBC_SHA","d":1436902,"h":240519605478,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_AES_256_CBC_SHA","d":1436902,"h":244814572774,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_NULL_SHA256","d":1436902,"h":249109540070,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_AES_128_CBC_SHA256","d":1436902,"h":253404507366,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_AES_256_CBC_SHA256","d":1436902,"h":257699474662,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_AES_128_CBC_SHA256","d":1436902,"h":261994441958,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_AES_128_CBC_SHA256","d":1436902,"h":266289409254,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_AES_128_CBC_SHA256","d":1436902,"h":270584376550,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1436902,"h":274879343846,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA","d":1436902,"h":279174311142,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1436902,"h":283469278438,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA","d":1436902,"h":287764245734,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA","d":1436902,"h":292059213030,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA","d":1436902,"h":296354180326,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_AES_128_CBC_SHA256","d":1436902,"h":300649147622,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_AES_256_CBC_SHA256","d":1436902,"h":304944114918,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_AES_256_CBC_SHA256","d":1436902,"h":309239082214,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_AES_256_CBC_SHA256","d":1436902,"h":313534049510,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_AES_256_CBC_SHA256","d":1436902,"h":317829016806,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_AES_128_CBC_SHA256","d":1436902,"h":322123984102,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_AES_256_CBC_SHA256","d":1436902,"h":326418951398,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1436902,"h":330713918694,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA","d":1436902,"h":335008885990,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1436902,"h":339303853286,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA","d":1436902,"h":343598820582,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA","d":1436902,"h":347893787878,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA","d":1436902,"h":352188755174,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_RC4_128_SHA","d":1436902,"h":356483722470,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":360778689766,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_AES_128_CBC_SHA","d":1436902,"h":365073657062,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_AES_256_CBC_SHA","d":1436902,"h":369368624358,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_RC4_128_SHA","d":1436902,"h":373663591654,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":377958558950,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_AES_128_CBC_SHA","d":1436902,"h":382253526246,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_AES_256_CBC_SHA","d":1436902,"h":386548493542,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_RC4_128_SHA","d":1436902,"h":390843460838,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":395138428134,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_AES_128_CBC_SHA","d":1436902,"h":399433395430,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_AES_256_CBC_SHA","d":1436902,"h":403728362726,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_SEED_CBC_SHA","d":1436902,"h":408023330022,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_SEED_CBC_SHA","d":1436902,"h":412318297318,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_SEED_CBC_SHA","d":1436902,"h":416613264614,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_SEED_CBC_SHA","d":1436902,"h":420908231910,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_SEED_CBC_SHA","d":1436902,"h":425203199206,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_SEED_CBC_SHA","d":1436902,"h":429498166502,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_AES_128_GCM_SHA256","d":1436902,"h":433793133798,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_AES_256_GCM_SHA384","d":1436902,"h":438088101094,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_AES_128_GCM_SHA256","d":1436902,"h":442383068390,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_AES_256_GCM_SHA384","d":1436902,"h":446678035686,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_AES_128_GCM_SHA256","d":1436902,"h":450973002982,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_AES_256_GCM_SHA384","d":1436902,"h":455267970278,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_AES_128_GCM_SHA256","d":1436902,"h":459562937574,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_AES_256_GCM_SHA384","d":1436902,"h":463857904870,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_AES_128_GCM_SHA256","d":1436902,"h":468152872166,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_AES_256_GCM_SHA384","d":1436902,"h":472447839462,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_AES_128_GCM_SHA256","d":1436902,"h":476742806758,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_AES_256_GCM_SHA384","d":1436902,"h":481037774054,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_AES_128_GCM_SHA256","d":1436902,"h":485332741350,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_AES_256_GCM_SHA384","d":1436902,"h":489627708646,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_AES_128_GCM_SHA256","d":1436902,"h":493922675942,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_AES_256_GCM_SHA384","d":1436902,"h":498217643238,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_AES_128_GCM_SHA256","d":1436902,"h":502512610534,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_AES_256_GCM_SHA384","d":1436902,"h":506807577830,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_AES_128_CBC_SHA256","d":1436902,"h":511102545126,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_AES_256_CBC_SHA384","d":1436902,"h":515397512422,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_NULL_SHA256","d":1436902,"h":519692479718,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_NULL_SHA384","d":1436902,"h":523987447014,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_AES_128_CBC_SHA256","d":1436902,"h":528282414310,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_AES_256_CBC_SHA384","d":1436902,"h":532577381606,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_NULL_SHA256","d":1436902,"h":536872348902,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_NULL_SHA384","d":1436902,"h":541167316198,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_AES_128_CBC_SHA256","d":1436902,"h":545462283494,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_AES_256_CBC_SHA384","d":1436902,"h":549757250790,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_NULL_SHA256","d":1436902,"h":554052218086,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_NULL_SHA384","d":1436902,"h":558347185382,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1436902,"h":562642152678,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256","d":1436902,"h":566937119974,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1436902,"h":571232087270,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256","d":1436902,"h":575527054566,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1436902,"h":579822021862,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256","d":1436902,"h":584116989158,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1436902,"h":588411956454,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256","d":1436902,"h":592706923750,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1436902,"h":597001891046,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256","d":1436902,"h":601296858342,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256","d":1436902,"h":605591825638,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256","d":1436902,"h":609886792934,"f":33},{"t":1436902,"n":"TLS_AES_128_GCM_SHA256","d":1436902,"h":614181760230,"f":33},{"t":1436902,"n":"TLS_AES_256_GCM_SHA384","d":1436902,"h":618476727526,"f":33},{"t":1436902,"n":"TLS_CHACHA20_POLY1305_SHA256","d":1436902,"h":622771694822,"f":33},{"t":1436902,"n":"TLS_AES_128_CCM_SHA256","d":1436902,"h":627066662118,"f":33},{"t":1436902,"n":"TLS_AES_128_CCM_8_SHA256","d":1436902,"h":631361629414,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_NULL_SHA","d":1436902,"h":635656596710,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_RC4_128_SHA","d":1436902,"h":639951564006,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":644246531302,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA","d":1436902,"h":648541498598,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA","d":1436902,"h":652836465894,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_NULL_SHA","d":1436902,"h":657131433190,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_RC4_128_SHA","d":1436902,"h":661426400486,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":665721367782,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA","d":1436902,"h":670016335078,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA","d":1436902,"h":674311302374,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_NULL_SHA","d":1436902,"h":678606269670,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_RC4_128_SHA","d":1436902,"h":682901236966,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":687196204262,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_AES_128_CBC_SHA","d":1436902,"h":691491171558,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_AES_256_CBC_SHA","d":1436902,"h":695786138854,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_NULL_SHA","d":1436902,"h":700081106150,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_RC4_128_SHA","d":1436902,"h":704376073446,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":708671040742,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA","d":1436902,"h":712966008038,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA","d":1436902,"h":717260975334,"f":33},{"t":1436902,"n":"TLS_ECDH_anon_WITH_NULL_SHA","d":1436902,"h":721555942630,"f":33},{"t":1436902,"n":"TLS_ECDH_anon_WITH_RC4_128_SHA","d":1436902,"h":725850909926,"f":33},{"t":1436902,"n":"TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":730145877222,"f":33},{"t":1436902,"n":"TLS_ECDH_anon_WITH_AES_128_CBC_SHA","d":1436902,"h":734440844518,"f":33},{"t":1436902,"n":"TLS_ECDH_anon_WITH_AES_256_CBC_SHA","d":1436902,"h":738735811814,"f":33},{"t":1436902,"n":"TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":743030779110,"f":33},{"t":1436902,"n":"TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":747325746406,"f":33},{"t":1436902,"n":"TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":751620713702,"f":33},{"t":1436902,"n":"TLS_SRP_SHA_WITH_AES_128_CBC_SHA","d":1436902,"h":755915680998,"f":33},{"t":1436902,"n":"TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA","d":1436902,"h":760210648294,"f":33},{"t":1436902,"n":"TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA","d":1436902,"h":764505615590,"f":33},{"t":1436902,"n":"TLS_SRP_SHA_WITH_AES_256_CBC_SHA","d":1436902,"h":768800582886,"f":33},{"t":1436902,"n":"TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA","d":1436902,"h":773095550182,"f":33},{"t":1436902,"n":"TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA","d":1436902,"h":777390517478,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256","d":1436902,"h":781685484774,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384","d":1436902,"h":785980452070,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256","d":1436902,"h":790275419366,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384","d":1436902,"h":794570386662,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256","d":1436902,"h":798865353958,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384","d":1436902,"h":803160321254,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256","d":1436902,"h":807455288550,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384","d":1436902,"h":811750255846,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256","d":1436902,"h":816045223142,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384","d":1436902,"h":820340190438,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256","d":1436902,"h":824635157734,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384","d":1436902,"h":828930125030,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256","d":1436902,"h":833225092326,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384","d":1436902,"h":837520059622,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256","d":1436902,"h":841815026918,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384","d":1436902,"h":846109994214,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_RC4_128_SHA","d":1436902,"h":850404961510,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA","d":1436902,"h":854699928806,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA","d":1436902,"h":858994896102,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA","d":1436902,"h":863289863398,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256","d":1436902,"h":867584830694,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384","d":1436902,"h":871879797990,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA","d":1436902,"h":876174765286,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA256","d":1436902,"h":880469732582,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_NULL_SHA384","d":1436902,"h":884764699878,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_ARIA_128_CBC_SHA256","d":1436902,"h":889059667174,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_ARIA_256_CBC_SHA384","d":1436902,"h":893354634470,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_ARIA_128_CBC_SHA256","d":1436902,"h":897649601766,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_ARIA_256_CBC_SHA384","d":1436902,"h":901944569062,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_ARIA_128_CBC_SHA256","d":1436902,"h":906239536358,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_ARIA_256_CBC_SHA384","d":1436902,"h":910534503654,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_ARIA_128_CBC_SHA256","d":1436902,"h":914829470950,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_ARIA_256_CBC_SHA384","d":1436902,"h":919124438246,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_ARIA_128_CBC_SHA256","d":1436902,"h":923419405542,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_ARIA_256_CBC_SHA384","d":1436902,"h":927714372838,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_ARIA_128_CBC_SHA256","d":1436902,"h":932009340134,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_ARIA_256_CBC_SHA384","d":1436902,"h":936304307430,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_128_CBC_SHA256","d":1436902,"h":940599274726,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_256_CBC_SHA384","d":1436902,"h":944894242022,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_ARIA_128_CBC_SHA256","d":1436902,"h":949189209318,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_ARIA_256_CBC_SHA384","d":1436902,"h":953484176614,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_ARIA_128_CBC_SHA256","d":1436902,"h":957779143910,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_ARIA_256_CBC_SHA384","d":1436902,"h":962074111206,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_ARIA_128_CBC_SHA256","d":1436902,"h":966369078502,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_ARIA_256_CBC_SHA384","d":1436902,"h":970664045798,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_ARIA_128_GCM_SHA256","d":1436902,"h":974959013094,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_ARIA_256_GCM_SHA384","d":1436902,"h":979253980390,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_ARIA_128_GCM_SHA256","d":1436902,"h":983548947686,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_ARIA_256_GCM_SHA384","d":1436902,"h":987843914982,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_ARIA_128_GCM_SHA256","d":1436902,"h":992138882278,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_ARIA_256_GCM_SHA384","d":1436902,"h":996433849574,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_ARIA_128_GCM_SHA256","d":1436902,"h":1000728816870,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_ARIA_256_GCM_SHA384","d":1436902,"h":1005023784166,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_ARIA_128_GCM_SHA256","d":1436902,"h":1009318751462,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_ARIA_256_GCM_SHA384","d":1436902,"h":1013613718758,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_ARIA_128_GCM_SHA256","d":1436902,"h":1017908686054,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_ARIA_256_GCM_SHA384","d":1436902,"h":1022203653350,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_128_GCM_SHA256","d":1436902,"h":1026498620646,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_ARIA_256_GCM_SHA384","d":1436902,"h":1030793587942,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_ARIA_128_GCM_SHA256","d":1436902,"h":1035088555238,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_ARIA_256_GCM_SHA384","d":1436902,"h":1039383522534,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_ARIA_128_GCM_SHA256","d":1436902,"h":1043678489830,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_ARIA_256_GCM_SHA384","d":1436902,"h":1047973457126,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_ARIA_128_GCM_SHA256","d":1436902,"h":1052268424422,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_ARIA_256_GCM_SHA384","d":1436902,"h":1056563391718,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_ARIA_128_CBC_SHA256","d":1436902,"h":1060858359014,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_ARIA_256_CBC_SHA384","d":1436902,"h":1065153326310,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_ARIA_128_CBC_SHA256","d":1436902,"h":1069448293606,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_ARIA_256_CBC_SHA384","d":1436902,"h":1073743260902,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_ARIA_128_CBC_SHA256","d":1436902,"h":1078038228198,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_ARIA_256_CBC_SHA384","d":1436902,"h":1082333195494,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_ARIA_128_GCM_SHA256","d":1436902,"h":1086628162790,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_ARIA_256_GCM_SHA384","d":1436902,"h":1090923130086,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_ARIA_128_GCM_SHA256","d":1436902,"h":1095218097382,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_ARIA_256_GCM_SHA384","d":1436902,"h":1099513064678,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_ARIA_128_GCM_SHA256","d":1436902,"h":1103808031974,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_ARIA_256_GCM_SHA384","d":1436902,"h":1108102999270,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_ARIA_128_CBC_SHA256","d":1436902,"h":1112397966566,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_ARIA_256_CBC_SHA384","d":1436902,"h":1116692933862,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256","d":1436902,"h":1120987901158,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384","d":1436902,"h":1125282868454,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256","d":1436902,"h":1129577835750,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384","d":1436902,"h":1133872803046,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1436902,"h":1138167770342,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384","d":1436902,"h":1142462737638,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256","d":1436902,"h":1146757704934,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384","d":1436902,"h":1151052672230,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1436902,"h":1155347639526,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1436902,"h":1159642606822,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1436902,"h":1163937574118,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1436902,"h":1168232541414,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1436902,"h":1172527508710,"f":33},{"t":1436902,"n":"TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1436902,"h":1176822476006,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256","d":1436902,"h":1181117443302,"f":33},{"t":1436902,"n":"TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384","d":1436902,"h":1185412410598,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256","d":1436902,"h":1189707377894,"f":33},{"t":1436902,"n":"TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384","d":1436902,"h":1194002345190,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256","d":1436902,"h":1198297312486,"f":33},{"t":1436902,"n":"TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384","d":1436902,"h":1202592279782,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256","d":1436902,"h":1206887247078,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384","d":1436902,"h":1211182214374,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256","d":1436902,"h":1215477181670,"f":33},{"t":1436902,"n":"TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384","d":1436902,"h":1219772148966,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1436902,"h":1224067116262,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1436902,"h":1228362083558,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256","d":1436902,"h":1232657050854,"f":33},{"t":1436902,"n":"TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384","d":1436902,"h":1236952018150,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1436902,"h":1241246985446,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1436902,"h":1245541952742,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1436902,"h":1249836920038,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1436902,"h":1254131887334,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256","d":1436902,"h":1258426854630,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384","d":1436902,"h":1262721821926,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1436902,"h":1267016789222,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1436902,"h":1271311756518,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1436902,"h":1275606723814,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1436902,"h":1279901691110,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1436902,"h":1284196658406,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1436902,"h":1288491625702,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256","d":1436902,"h":1292786592998,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384","d":1436902,"h":1297081560294,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_AES_128_CCM","d":1436902,"h":1301376527590,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_AES_256_CCM","d":1436902,"h":1305671494886,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_AES_128_CCM","d":1436902,"h":1309966462182,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_AES_256_CCM","d":1436902,"h":1314261429478,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_AES_128_CCM_8","d":1436902,"h":1318556396774,"f":33},{"t":1436902,"n":"TLS_RSA_WITH_AES_256_CCM_8","d":1436902,"h":1322851364070,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_AES_128_CCM_8","d":1436902,"h":1327146331366,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_AES_256_CCM_8","d":1436902,"h":1331441298662,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_AES_128_CCM","d":1436902,"h":1335736265958,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_AES_256_CCM","d":1436902,"h":1340031233254,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_AES_128_CCM","d":1436902,"h":1344326200550,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_AES_256_CCM","d":1436902,"h":1348621167846,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_AES_128_CCM_8","d":1436902,"h":1352916135142,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_AES_256_CCM_8","d":1436902,"h":1357211102438,"f":33},{"t":1436902,"n":"TLS_PSK_DHE_WITH_AES_128_CCM_8","d":1436902,"h":1361506069734,"f":33},{"t":1436902,"n":"TLS_PSK_DHE_WITH_AES_256_CCM_8","d":1436902,"h":1365801037030,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CCM","d":1436902,"h":1370096004326,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CCM","d":1436902,"h":1374390971622,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_AES_128_CCM_8","d":1436902,"h":1378685938918,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_AES_256_CCM_8","d":1436902,"h":1382980906214,"f":33},{"t":1436902,"n":"TLS_ECCPWD_WITH_AES_128_GCM_SHA256","d":1436902,"h":1387275873510,"f":33},{"t":1436902,"n":"TLS_ECCPWD_WITH_AES_256_GCM_SHA384","d":1436902,"h":1391570840806,"f":33},{"t":1436902,"n":"TLS_ECCPWD_WITH_AES_128_CCM_SHA256","d":1436902,"h":1395865808102,"f":33},{"t":1436902,"n":"TLS_ECCPWD_WITH_AES_256_CCM_SHA384","d":1436902,"h":1400160775398,"f":33},{"t":1436902,"n":"TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256","d":1436902,"h":1404455742694,"f":33},{"t":1436902,"n":"TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256","d":1436902,"h":1408750709990,"f":33},{"t":1436902,"n":"TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256","d":1436902,"h":1413045677286,"f":33},{"t":1436902,"n":"TLS_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1436902,"h":1417340644582,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1436902,"h":1421635611878,"f":33},{"t":1436902,"n":"TLS_DHE_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1436902,"h":1425930579174,"f":33},{"t":1436902,"n":"TLS_RSA_PSK_WITH_CHACHA20_POLY1305_SHA256","d":1436902,"h":1430225546470,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_AES_128_GCM_SHA256","d":1436902,"h":1434520513766,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_AES_256_GCM_SHA384","d":1436902,"h":1438815481062,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_AES_128_CCM_8_SHA256","d":1436902,"h":1443110448358,"f":33},{"t":1436902,"n":"TLS_ECDHE_PSK_WITH_AES_128_CCM_SHA256","d":1436902,"h":1447405415654,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1436902,"h":1451700382950,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1436902,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Security.TlsCipherSuite`; }
        });
        
        $asm.$str("$snsc.System.Security.Authentication.ExtendedProtection.PolicyEnforcement", ($self) => class PolicyEnforcement extends $.$spc.System.Enum
        {
            static Never = 0;
            static WhenSupported = 1;
            static Always = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Never": 0n,
                    "WhenSupported": 1n,
                    "Always": 2n
                };
            }
            static $h = 1633510;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1633510,"n":"Never","d":1633510,"h":4296600806,"f":33},{"t":1633510,"n":"WhenSupported","d":1633510,"h":8591568102,"f":33},{"t":1633510,"n":"Always","d":1633510,"h":12886535398,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1633510,"h":17181502694,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1633510}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.PolicyEnforcement`; }
        });
        
        $asm.$str("$snsc.System.Security.Authentication.ExtendedProtection.ProtectionScenario", ($self) => class ProtectionScenario extends $.$spc.System.Enum
        {
            static TransportSelected = 0;
            static TrustedProxy = 1;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "TransportSelected": 0n,
                    "TrustedProxy": 1n
                };
            }
            static $h = 1699046;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$spc.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1699046,"n":"TransportSelected","d":1699046,"h":4296666342,"f":33},{"t":1699046,"n":"TrustedProxy","d":1699046,"h":8591633638,"f":33}],"c":[{"n":".ctor","o":"$ctor$3","d":1699046,"h":12886600934,"f":1}],"i":[57212929,63766529,57671681,57344001],"h":1699046}; }
            static get $b() { return $.$spc.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IComparable, $.$spc.System.ISpanFormattable, $.$spc.System.IFormattable, $.$spc.System.IConvertible ]; }
            static get $fullName() { return `System.Security.Authentication.ExtendedProtection.ProtectionScenario`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.NegotiateStream", ($self) => class NegotiateStream extends $.$snsc.System.Net.Security.AuthenticatedStream
        {
            $ctor$4(/*System.IO.Stream*/ innerStream)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.TokenImpersonationLevel */ get ImpersonationLevel()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Principal.IIdentity */ get RemoteIdentity()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsClient()
            {
            }
            /*void */ AuthenticateAsClient$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName)
            {
            }
            /*void */ AuthenticateAsClient$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsClient$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName)
            {
            }
            /*void */ AuthenticateAsClient$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsServer()
            {
            }
            /*void */ AuthenticateAsServer$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsServer$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
            }
            /*void */ AuthenticateAsServer$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient(/*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$1(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ChannelBinding?*/ binding, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$3(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$4(/*System.Net.NetworkCredential*/ credential, /*string*/ targetName, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ allowedImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer(/*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$1(/*System.Net.NetworkCredential*/ credential, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$2(/*System.Net.NetworkCredential*/ credential, /*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.Net.Security.ProtectionLevel*/ requiredProtectionLevel, /*System.Security.Principal.TokenImpersonationLevel*/ requiredImpersonationLevel, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$3(/*System.Security.Authentication.ExtendedProtection.ExtendedProtectionPolicy?*/ policy, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndAuthenticateAsClient(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndAuthenticateAsServer(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 650470;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":126182,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180519654,"f":32769},"n":"CanRead","d":650470,"h":12885552358,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":25770454246,"f":32769},"n":"CanSeek","d":650470,"h":21475486950,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":34360388838,"f":32769},"n":"CanTimeout","d":650470,"h":30065421542,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":42950323430,"f":32769},"n":"CanWrite","d":650470,"h":38655356134,"f":32769},{"p":117243905,"g":{"r":0,"d":0,"h":51540258022,"f":129},"n":"ImpersonationLevel","d":650470,"h":47245290726,"f":129},{"p":262145,"g":{"r":0,"d":0,"h":60130192614,"f":32769},"n":"IsAuthenticated","d":650470,"h":55835225318,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":68720127206,"f":32769},"n":"IsEncrypted","d":650470,"h":64425159910,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":77310061798,"f":32769},"n":"IsMutuallyAuthenticated","d":650470,"h":73015094502,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":85899996390,"f":32769},"n":"IsServer","d":650470,"h":81605029094,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":94489930982,"f":32769},"n":"IsSigned","d":650470,"h":90194963686,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":103079865574,"f":32769},"n":"Length","d":650470,"h":98784898278,"f":32769},{"p":917505,"g":{"r":0,"d":0,"h":111669800166,"f":32769},"s":{"r":0,"d":0,"h":115964767462,"f":32769},"n":"Position","d":650470,"h":107374832870,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":124554702054,"f":32769},"s":{"r":0,"d":0,"h":128849669350,"f":32769},"n":"ReadTimeout","d":650470,"h":120259734758,"f":32769},{"p":117047297,"g":{"r":0,"d":0,"h":137439603942,"f":129},"n":"RemoteIdentity","d":650470,"h":133144636646,"f":129},{"p":655361,"g":{"r":0,"d":0,"h":146029538534,"f":32769},"s":{"r":0,"d":0,"h":150324505830,"f":32769},"n":"WriteTimeout","d":650470,"h":141734571238,"f":32769}],"m":[{"r":65537,"n":"AuthenticateAsClient","d":650470,"h":154619473126,"f":129},{"r":65537,"p":[{"n":"credential","p":3842011},{"n":"binding","p":5414875},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClient","o":"@$1","d":650470,"h":158914440422,"f":129},{"r":65537,"p":[{"n":"credential","p":3842011},{"n":"binding","p":5414875},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":716006},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClient","o":"@$2","d":650470,"h":163209407718,"f":129},{"r":65537,"p":[{"n":"credential","p":3842011},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClient","o":"@$3","d":650470,"h":167504375014,"f":129},{"r":65537,"p":[{"n":"credential","p":3842011},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":716006},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClient","o":"@$4","d":650470,"h":171799342310,"f":129},{"r":133300225,"n":"AuthenticateAsClientAsync","d":650470,"h":176094309606,"f":129},{"r":133300225,"p":[{"n":"credential","p":3842011},{"n":"binding","p":5414875},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$1","d":650470,"h":180389276902,"f":129},{"r":133300225,"p":[{"n":"credential","p":3842011},{"n":"binding","p":5414875},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":716006},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClientAsync","o":"@$2","d":650470,"h":184684244198,"f":129},{"r":133300225,"p":[{"n":"credential","p":3842011},{"n":"targetName","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$3","d":650470,"h":188979211494,"f":129},{"r":133300225,"p":[{"n":"credential","p":3842011},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":716006},{"n":"allowedImpersonationLevel","p":117243905}],"n":"AuthenticateAsClientAsync","o":"@$4","d":650470,"h":193274178790,"f":129},{"r":65537,"n":"AuthenticateAsServer","d":650470,"h":197569146086,"f":129},{"r":65537,"p":[{"n":"credential","p":3842011},{"n":"requiredProtectionLevel","p":716006},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServer","o":"@$1","d":650470,"h":201864113382,"f":129},{"r":65537,"p":[{"n":"credential","p":3842011},{"n":"policy","p":1567974},{"n":"requiredProtectionLevel","p":716006},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServer","o":"@$2","d":650470,"h":206159080678,"f":129},{"r":65537,"p":[{"n":"policy","p":1567974}],"n":"AuthenticateAsServer","o":"@$3","d":650470,"h":210454047974,"f":129},{"r":133300225,"n":"AuthenticateAsServerAsync","d":650470,"h":214749015270,"f":129},{"r":133300225,"p":[{"n":"credential","p":3842011},{"n":"requiredProtectionLevel","p":716006},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServerAsync","o":"@$1","d":650470,"h":219043982566,"f":129},{"r":133300225,"p":[{"n":"credential","p":3842011},{"n":"policy","p":1567974},{"n":"requiredProtectionLevel","p":716006},{"n":"requiredImpersonationLevel","p":117243905}],"n":"AuthenticateAsServerAsync","o":"@$2","d":650470,"h":223338949862,"f":129},{"r":133300225,"p":[{"n":"policy","p":1567974}],"n":"AuthenticateAsServerAsync","o":"@$3","d":650470,"h":227633917158,"f":129},{"r":56950785,"p":[{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","d":650470,"h":231928884454,"f":129},{"r":56950785,"p":[{"n":"credential","p":3842011},{"n":"binding","p":5414875},{"n":"targetName","p":1310721},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$1","d":650470,"h":236223851750,"f":129},{"r":56950785,"p":[{"n":"credential","p":3842011},{"n":"binding","p":5414875},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":716006},{"n":"allowedImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$2","d":650470,"h":240518819046,"f":129},{"r":56950785,"p":[{"n":"credential","p":3842011},{"n":"targetName","p":1310721},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$3","d":650470,"h":244813786342,"f":129},{"r":56950785,"p":[{"n":"credential","p":3842011},{"n":"targetName","p":1310721},{"n":"requiredProtectionLevel","p":716006},{"n":"allowedImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$4","d":650470,"h":249108753638,"f":129},{"r":56950785,"p":[{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","d":650470,"h":253403720934,"f":129},{"r":56950785,"p":[{"n":"credential","p":3842011},{"n":"requiredProtectionLevel","p":716006},{"n":"requiredImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$1","d":650470,"h":257698688230,"f":129},{"r":56950785,"p":[{"n":"credential","p":3842011},{"n":"policy","p":1567974},{"n":"requiredProtectionLevel","p":716006},{"n":"requiredImpersonationLevel","p":117243905},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$2","d":650470,"h":261993655526,"f":129},{"r":56950785,"p":[{"n":"policy","p":1567974},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$3","d":650470,"h":266288622822,"f":129},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginRead","d":650470,"h":270583590118,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":650470,"h":274878557414,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":650470,"h":279173524710,"f":32772},{"r":136118273,"n":"DisposeAsync","d":650470,"h":283468492006,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAuthenticateAsClient","d":650470,"h":287763459302,"f":129},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAuthenticateAsServer","d":650470,"h":292058426598,"f":129},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":650470,"h":296353393894,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":650470,"h":300648361190,"f":32769},{"r":65537,"n":"Flush","d":650470,"h":304943328486,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":650470,"h":309238295782,"f":32769},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":650470,"h":313533263078,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":650470,"h":317828230374,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":650470,"h":322123197670,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":650470,"h":326418164966,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":650470,"h":330713132262,"f":32769},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":650470,"h":335008099558,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":650470,"h":339303066854,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":650470,"h":343598034150,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62128129}],"n":".ctor","o":"$ctor$4","d":650470,"h":4295617766,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":650470,"h":8590585062,"f":1}],"i":[57475073,56885249],"h":650470}; }
            static get $b() { return $.$snsc.System.Net.Security.AuthenticatedStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.NegotiateStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.SslStream", ($self) => class SslStream extends $.$snsc.System.Net.Security.AuthenticatedStream
        {
            $ctor$4(/*System.IO.Stream*/ innerStream)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$7(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback, /*System.Net.Security.LocalCertificateSelectionCallback?*/ userCertificateSelectionCallback)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            $ctor$8(/*System.IO.Stream*/ innerStream, /*bool*/ leaveInnerStreamOpen, /*System.Net.Security.RemoteCertificateValidationCallback?*/ userCertificateValidationCallback, /*System.Net.Security.LocalCertificateSelectionCallback?*/ userCertificateSelectionCallback, /*System.Net.Security.EncryptionPolicy*/ encryptionPolicy)
            {
                super.$ctor$3(null, false);
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CheckCertRevocationStatus()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.CipherAlgorithmType */ get CipherAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get CipherStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.HashAlgorithmType */ get HashAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get HashStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsEncrypted()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsMutuallyAuthenticated()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsServer()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsSigned()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.ExchangeAlgorithmType */ get KeyExchangeAlgorithm()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get KeyExchangeStrength()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get LocalCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.SslApplicationProtocol */ get NegotiatedApplicationProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Security.TlsCipherSuite */ get NegotiatedCipherSuite()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate? */ get RemoteCertificate()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Security.Authentication.SslProtocols */ get SslProtocol()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string */ get TargetHostName()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.TransportContext */ get TransportContext()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsClient(/*System.Net.Security.SslClientAuthenticationOptions*/ sslClientAuthenticationOptions)
            {
            }
            /*void */ AuthenticateAsClient$1(/*string*/ targetHost)
            {
            }
            /*void */ AuthenticateAsClient$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation)
            {
            }
            /*void */ AuthenticateAsClient$3(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync(/*System.Net.Security.SslClientAuthenticationOptions*/ sslClientAuthenticationOptions, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$1(/*string*/ targetHost)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsClientAsync$3(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AuthenticateAsServer(/*System.Net.Security.SslServerAuthenticationOptions*/ sslServerAuthenticationOptions)
            {
            }
            /*void */ AuthenticateAsServer$1(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate)
            {
            }
            /*void */ AuthenticateAsServer$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation)
            {
            }
            /*void */ AuthenticateAsServer$3(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync(/*System.Net.Security.ServerOptionsSelectionCallback*/ optionsCallback, /*object?*/ state, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$1(/*System.Net.Security.SslServerAuthenticationOptions*/ sslServerAuthenticationOptions, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$3(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ AuthenticateAsServerAsync$4(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient(/*string*/ targetHost, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$1(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsClient$2(/*string*/ targetHost, /*System.Security.Cryptography.X509Certificates.X509CertificateCollection?*/ clientCertificates, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$1(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAuthenticateAsServer$2(/*System.Security.Cryptography.X509Certificates.X509Certificate*/ serverCertificate, /*bool*/ clientCertificateRequired, /*System.Security.Authentication.SslProtocols*/ enabledSslProtocols, /*bool*/ checkCertificateRevocation, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ asyncCallback, /*object?*/ asyncState)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisposeAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndAuthenticateAsClient(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndAuthenticateAsServer(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ NegotiateClientCertificateAsync(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*System.Threading.Tasks.Task */ ShutdownAsync()
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Write$2(/*byte[]*/ buffer)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$spc.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 1305830;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":126182,"p":[{"p":262145,"g":{"r":0,"d":0,"h":30066076902,"f":32769},"n":"CanRead","d":1305830,"h":25771109606,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":38656011494,"f":32769},"n":"CanSeek","d":1305830,"h":34361044198,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":47245946086,"f":32769},"n":"CanTimeout","d":1305830,"h":42950978790,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":55835880678,"f":32769},"n":"CanWrite","d":1305830,"h":51540913382,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":64425815270,"f":129},"n":"CheckCertRevocationStatus","d":1305830,"h":60130847974,"f":129},{"p":5283803,"g":{"r":0,"d":0,"h":73015749862,"f":129},"n":"CipherAlgorithm","d":1305830,"h":68720782566,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":81605684454,"f":129},"n":"CipherStrength","d":1305830,"h":77310717158,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":5545947,"g":{"r":0,"d":0,"h":90195619046,"f":129},"n":"HashAlgorithm","d":1305830,"h":85900651750,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":98785553638,"f":129},"n":"HashStrength","d":1305830,"h":94490586342,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":107375488230,"f":32769},"n":"IsAuthenticated","d":1305830,"h":103080520934,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":115965422822,"f":32769},"n":"IsEncrypted","d":1305830,"h":111670455526,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":124555357414,"f":32769},"n":"IsMutuallyAuthenticated","d":1305830,"h":120260390118,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":133145292006,"f":32769},"n":"IsServer","d":1305830,"h":128850324710,"f":32769},{"p":262145,"g":{"r":0,"d":0,"h":141735226598,"f":32769},"n":"IsSigned","d":1305830,"h":137440259302,"f":32769},{"p":5349339,"g":{"r":0,"d":0,"h":150325161190,"f":129},"n":"KeyExchangeAlgorithm","d":1305830,"h":146030193894,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":655361,"g":{"r":0,"d":0,"h":158915095782,"f":129},"n":"KeyExchangeStrength","d":1305830,"h":154620128486,"f":129,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"KeyExchangeAlgorithm, KeyExchangeStrength, CipherAlgorithm, CipherStrength, HashAlgorithm and HashStrength properties of SslStream are obsolete. Use NegotiatedCipherSuite instead.","t":1310721}],"n":[{"n":"DiagnosticId","v":"SYSLIB0058","t":1310721},{"n":"UrlFormat","v":"https://aka.ms/dotnet-warnings/{0}","t":1310721}]}]},{"p":917505,"g":{"r":0,"d":0,"h":167505030374,"f":32769},"n":"Length","d":1305830,"h":163210063078,"f":32769},{"p":28172903,"g":{"r":0,"d":0,"h":176094964966,"f":129},"n":"LocalCertificate","d":1305830,"h":171799997670,"f":129},{"p":978150,"g":{"r":0,"d":0,"h":184684899558,"f":1},"n":"NegotiatedApplicationProtocol","d":1305830,"h":180389932262,"f":1},{"p":1436902,"g":{"r":0,"d":0,"h":193274834150,"f":129},"n":"NegotiatedCipherSuite","d":1305830,"h":188979866854,"f":129,"a":[{"t":23396353,"c":8613330945,"a":[{"v":false,"t":262145}]}]},{"p":917505,"g":{"r":0,"d":0,"h":201864768742,"f":32769},"s":{"r":0,"d":0,"h":206159736038,"f":32769},"n":"Position","d":1305830,"h":197569801446,"f":32769},{"p":655361,"g":{"r":0,"d":0,"h":214749670630,"f":32769},"s":{"r":0,"d":0,"h":219044637926,"f":32769},"n":"ReadTimeout","d":1305830,"h":210454703334,"f":32769},{"p":28172903,"g":{"r":0,"d":0,"h":227634572518,"f":129},"n":"RemoteCertificate","d":1305830,"h":223339605222,"f":129},{"p":5611483,"g":{"r":0,"d":0,"h":236224507110,"f":129},"n":"SslProtocol","d":1305830,"h":231929539814,"f":129},{"p":1310721,"g":{"r":0,"d":0,"h":244814441702,"f":1},"n":"TargetHostName","d":1305830,"h":240519474406,"f":1},{"p":5021659,"g":{"r":0,"d":0,"h":253404376294,"f":1},"n":"TransportContext","d":1305830,"h":249109408998,"f":1},{"p":655361,"g":{"r":0,"d":0,"h":261994310886,"f":32769},"s":{"r":0,"d":0,"h":266289278182,"f":32769},"n":"WriteTimeout","d":1305830,"h":257699343590,"f":32769}],"m":[{"r":65537,"p":[{"n":"sslClientAuthenticationOptions","p":1109222}],"n":"AuthenticateAsClient","d":1305830,"h":270584245478,"f":1},{"r":65537,"p":[{"n":"targetHost","p":1310721}],"n":"AuthenticateAsClient","o":"@$1","d":1305830,"h":274879212774,"f":129},{"r":65537,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28435047},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClient","o":"@$2","d":1305830,"h":279174180070,"f":129},{"r":65537,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28435047},{"n":"enabledSslProtocols","p":5611483},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClient","o":"@$3","d":1305830,"h":283469147366,"f":129},{"r":133300225,"p":[{"n":"sslClientAuthenticationOptions","p":1109222},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsClientAsync","d":1305830,"h":287764114662,"f":1},{"r":133300225,"p":[{"n":"targetHost","p":1310721}],"n":"AuthenticateAsClientAsync","o":"@$1","d":1305830,"h":292059081958,"f":129},{"r":133300225,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28435047},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClientAsync","o":"@$2","d":1305830,"h":296354049254,"f":129},{"r":133300225,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28435047},{"n":"enabledSslProtocols","p":5611483},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsClientAsync","o":"@$3","d":1305830,"h":300649016550,"f":129},{"r":65537,"p":[{"n":"sslServerAuthenticationOptions","p":1240294}],"n":"AuthenticateAsServer","d":1305830,"h":304943983846,"f":1},{"r":65537,"p":[{"n":"serverCertificate","p":28172903}],"n":"AuthenticateAsServer","o":"@$1","d":1305830,"h":309238951142,"f":129},{"r":65537,"p":[{"n":"serverCertificate","p":28172903},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServer","o":"@$2","d":1305830,"h":313533918438,"f":129},{"r":65537,"p":[{"n":"serverCertificate","p":28172903},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5611483},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServer","o":"@$3","d":1305830,"h":317828885734,"f":129},{"r":133300225,"p":[{"n":"optionsCallback","p":912614},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsServerAsync","d":1305830,"h":322123853030,"f":1},{"r":133300225,"p":[{"n":"sslServerAuthenticationOptions","p":1240294},{"n":"cancellationToken","p":125960193,"f":65}],"n":"AuthenticateAsServerAsync","o":"@$1","d":1305830,"h":326418820326,"f":1},{"r":133300225,"p":[{"n":"serverCertificate","p":28172903}],"n":"AuthenticateAsServerAsync","o":"@$2","d":1305830,"h":330713787622,"f":129},{"r":133300225,"p":[{"n":"serverCertificate","p":28172903},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServerAsync","o":"@$3","d":1305830,"h":335008754918,"f":129},{"r":133300225,"p":[{"n":"serverCertificate","p":28172903},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5611483},{"n":"checkCertificateRevocation","p":262145}],"n":"AuthenticateAsServerAsync","o":"@$4","d":1305830,"h":339303722214,"f":129},{"r":56950785,"p":[{"n":"targetHost","p":1310721},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","d":1305830,"h":343598689510,"f":129},{"r":56950785,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28435047},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$1","d":1305830,"h":347893656806,"f":129},{"r":56950785,"p":[{"n":"targetHost","p":1310721},{"n":"clientCertificates","p":28435047},{"n":"enabledSslProtocols","p":5611483},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsClient","o":"@$2","d":1305830,"h":352188624102,"f":129},{"r":56950785,"p":[{"n":"serverCertificate","p":28172903},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","d":1305830,"h":356483591398,"f":129},{"r":56950785,"p":[{"n":"serverCertificate","p":28172903},{"n":"clientCertificateRequired","p":262145},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$1","d":1305830,"h":360778558694,"f":129},{"r":56950785,"p":[{"n":"serverCertificate","p":28172903},{"n":"clientCertificateRequired","p":262145},{"n":"enabledSslProtocols","p":5611483},{"n":"checkCertificateRevocation","p":262145},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginAuthenticateAsServer","o":"@$2","d":1305830,"h":365073525990,"f":129},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginRead","d":1305830,"h":369368493286,"f":32769},{"r":56950785,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"asyncCallback","p":14417921},{"n":"asyncState","p":131073}],"n":"BeginWrite","d":1305830,"h":373663460582,"f":32769},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1305830,"h":377958427878,"f":32772},{"r":136118273,"n":"DisposeAsync","d":1305830,"h":382253395174,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAuthenticateAsClient","d":1305830,"h":386548362470,"f":129},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndAuthenticateAsServer","d":1305830,"h":390843329766,"f":129},{"r":655361,"p":[{"n":"asyncResult","p":56950785}],"n":"EndRead","d":1305830,"h":395138297062,"f":32769},{"r":65537,"p":[{"n":"asyncResult","p":56950785}],"n":"EndWrite","d":1305830,"h":399433264358,"f":32769},{"r":65537,"n":"Flush","d":1305830,"h":408023198950,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193}],"n":"FlushAsync","o":"@$1","d":1305830,"h":412318166246,"f":32769},{"r":133300225,"p":[{"n":"cancellationToken","p":125960193,"f":65}],"n":"NegotiateClientCertificateAsync","d":1305830,"h":416613133542,"f":129,"a":[{"t":114950145,"c":4409917441,"a":[{"v":"freebsd","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"linux","t":1310721}]},{"t":114950145,"c":4409917441,"a":[{"v":"windows","t":1310721}]}]},{"r":655361,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":1305830,"h":420908100838,"f":32769},{"r":655361,"p":[{"n":"buffer","p":$.$spc.System.Span$$($.$spc.System.Byte).$h}],"n":"Read","o":"@$1","d":1305830,"h":425203068134,"f":32769},{"r":$.$spc.System.Threading.Tasks.Task$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"ReadAsync","o":"@$1","d":1305830,"h":429498035430,"f":32769},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$spc.System.Int32).$h,"p":[{"n":"buffer","p":$.$spc.System.Memory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"ReadAsync","o":"@$2","d":1305830,"h":433793002726,"f":32769},{"r":655361,"n":"ReadByte","d":1305830,"h":438087970022,"f":32769},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61669377}],"n":"Seek","d":1305830,"h":442382937318,"f":32769},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":1305830,"h":446677904614,"f":32769},{"r":133300225,"n":"ShutdownAsync","d":1305830,"h":450972871910,"f":129},{"r":65537,"p":[{"n":"buffer","p":0}],"n":"Write","o":"@$2","d":1305830,"h":455267839206,"f":1},{"r":65537,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":1305830,"h":459562806502,"f":32769},{"r":65537,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlySpan$$($.$spc.System.Byte).$h}],"n":"Write","o":"@$1","d":1305830,"h":463857773798,"f":32769},{"r":133300225,"p":[{"n":"buffer","p":0},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125960193}],"n":"WriteAsync","o":"@$1","d":1305830,"h":468152741094,"f":32769},{"r":136118273,"p":[{"n":"buffer","p":$.$spc.System.ReadOnlyMemory$$($.$spc.System.Byte).$h},{"n":"cancellationToken","p":125960193,"f":65}],"n":"WriteAsync","o":"@$2","d":1305830,"h":472447708390,"f":32769},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":1305830,"h":476742675686,"f":32769}],"c":[{"p":[{"n":"innerStream","p":62128129}],"n":".ctor","o":"$ctor$4","d":1305830,"h":4296273126,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145}],"n":".ctor","o":"$ctor$5","d":1305830,"h":8591240422,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":781542}],"n":".ctor","o":"$ctor$6","d":1305830,"h":12886207718,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":781542},{"n":"userCertificateSelectionCallback","p":322790}],"n":".ctor","o":"$ctor$7","d":1305830,"h":17181175014,"f":1},{"p":[{"n":"innerStream","p":62128129},{"n":"leaveInnerStreamOpen","p":262145},{"n":"userCertificateValidationCallback","p":781542},{"n":"userCertificateSelectionCallback","p":322790},{"n":"encryptionPolicy","p":257254}],"n":".ctor","o":"$ctor$8","d":1305830,"h":21476142310,"f":1}],"i":[57475073,56885249],"h":1305830}; }
            static get $b() { return $.$snsc.System.Net.Security.AuthenticatedStream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.IDisposable, $.$spc.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Security.SslStream`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.LocalCertificateSelectionCallback", ($self) => class LocalCertificateSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate?*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$spc.System.String*/ $targetHost, /*$.$sscr.System.Security.Cryptography.X509Certificates.X509CertificateCollection*/ $localCertificates, /*$.$spc.System.Nullable$$*/ $remoteCertificate, /**/ $acceptableIssuers)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 322790;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":28172903,"p":[{"n":"sender","p":131073},{"n":"targetHost","p":1310721},{"n":"localCertificates","p":28435047},{"n":"remoteCertificate","p":28172903},{"n":"acceptableIssuers","p":0}],"n":"Invoke","d":322790,"h":8590257382,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"targetHost","p":1310721},{"n":"localCertificates","p":28435047},{"n":"remoteCertificate","p":28172903},{"n":"acceptableIssuers","p":0},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":322790,"h":12885224678,"f":129},{"r":28172903,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":322790,"h":17180191974,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":322790,"h":4295290086,"f":1}],"i":[57147393,113377281],"h":322790}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.LocalCertificateSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.RemoteCertificateValidationCallback", ($self) => class RemoteCertificateValidationCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*bool*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$spc.System.Nullable$$*/ $certificate, /*$.$spc.System.Nullable$$*/ $chain, /*$.$snp.System.Net.Security.SslPolicyErrors*/ $sslPolicyErrors)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 781542;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":262145,"p":[{"n":"sender","p":131073},{"n":"certificate","p":28172903},{"n":"chain","p":28893799},{"n":"sslPolicyErrors","p":4300763}],"n":"Invoke","d":781542,"h":8590716134,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"certificate","p":28172903},{"n":"chain","p":28893799},{"n":"sslPolicyErrors","p":4300763},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":781542,"h":12885683430,"f":129},{"r":262145,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":781542,"h":17180650726,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":781542,"h":4295748838,"f":1}],"i":[57147393,113377281],"h":781542}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.RemoteCertificateValidationCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.ServerCertificateSelectionCallback", ($self) => class ServerCertificateSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*System.Security.Cryptography.X509Certificates.X509Certificate*/ Invoke(/*$.$spc.System.Object*/ $sender, /*$.$spc.System.Nullable$$*/ $hostName)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 847078;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":28172903,"p":[{"n":"sender","p":131073},{"n":"hostName","p":1310721}],"n":"Invoke","d":847078,"h":8590781670,"f":129},{"r":56950785,"p":[{"n":"sender","p":131073},{"n":"hostName","p":1310721},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":847078,"h":12885748966,"f":129},{"r":28172903,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":847078,"h":17180716262,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":847078,"h":4295814374,"f":1}],"i":[57147393,113377281],"h":847078}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.ServerCertificateSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Net.Security.ServerOptionsSelectionCallback", ($self) => class ServerOptionsSelectionCallback extends $.$spc.System.MulticastDelegate
        {
            $ctor(/*object*/ target, fn)
            {
                this._target = target;
                this.$nativeFunction = fn;
                return this;
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Security.SslServerAuthenticationOptions>*/ Invoke(/*$.$snsc.System.Net.Security.SslStream*/ $stream, /*$.$snsc.System.Net.Security.SslClientHelloInfo*/ $clientHelloInfo, /*$.$spc.System.Nullable$$*/ $state, /*$.$spc.System.Threading.CancellationToken*/ $cancellationToken)
            {
                return this.$nativeFunction.apply(this._target, arguments);
            }
            static $h = 912614;
            static $f = 0b10000001;
            static $k = 5;
            static $$md;
            static get $md() { return this.$$md ??= {"b":66191361,"m":[{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snsc.System.Net.Security.SslServerAuthenticationOptions).$h,"p":[{"n":"stream","p":1305830},{"n":"clientHelloInfo","p":1174758},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193}],"n":"Invoke","d":912614,"h":8590847206,"f":129},{"r":56950785,"p":[{"n":"stream","p":1305830},{"n":"clientHelloInfo","p":1174758},{"n":"state","p":131073},{"n":"cancellationToken","p":125960193},{"n":"callback","p":14417921},{"n":"object","p":131073}],"n":"BeginInvoke","d":912614,"h":12885814502,"f":129},{"r":$.$spc.System.Threading.Tasks.ValueTask$$($.$snsc.System.Net.Security.SslServerAuthenticationOptions).$h,"p":[{"n":"result","p":56950785}],"n":"EndInvoke","d":912614,"h":17180781798,"f":129}],"c":[{"p":[{"n":"object","p":131073},{"n":"method","p":786433}],"n":".ctor","o":"$ctor$5","d":912614,"h":4295879910,"f":1}],"i":[57147393,113377281],"h":912614}; }
            static get $b() { return $.$spc.System.MulticastDelegate; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.ICloneable, $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Net.Security.ServerOptionsSelectionCallback`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.AuthenticationException", ($self) => class AuthenticationException extends $.$spc.System.SystemException
        {
            $ctor$9()
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$10(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$11(/*string?*/ message)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            $ctor$12(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$5();
                {
                }
                return this;
            }
            static $h = 1502438;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":119668737,"h":1502438}; }
            static get $b() { return $.$spc.System.SystemException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.AuthenticationException`; }
        });
        
        $asm.$cls("$snsc.System.Security.Authentication.InvalidCredentialException", ($self) => class InvalidCredentialException extends $.$snsc.System.Security.Authentication.AuthenticationException
        {
            $ctor$13()
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$14(/*System.Runtime.Serialization.SerializationInfo*/ serializationInfo, /*System.Runtime.Serialization.StreamingContext*/ streamingContext)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$15(/*string?*/ message)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            $ctor$16(/*string?*/ message, /*System.Exception?*/ innerException)
            {
                super.$ctor$9();
                {
                }
                return this;
            }
            static $h = 1830118;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":1502438,"h":1830118}; }
            static get $b() { return $.$snsc.System.Security.Authentication.AuthenticationException; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$spc.System.Runtime.Serialization.ISerializable ]; }
            static get $fullName() { return `System.Security.Authentication.InvalidCredentialException`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Memory", "NetJs.System.Numerics.Vectors", "NetJs.System.Private.Uri", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Threading", "NetJs.System.Threading.Overlapped", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Runtime", "NetJs.System.Collections.Concurrent", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.Numerics", "NetJs.System.Security.Claims", "NetJs.System.Runtime.InteropServices", "NetJs.System.Console", "NetJs.System.Formats.Asn1", "NetJs.System.IO.Compression", "NetJs.System.IO.MemoryMappedFiles", "NetJs.System.Linq", "NetJs.System.Net.Primitives", "NetJs.System.Security.Principal.Windows", "NetJs.System.Collections.Immutable", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Reflection.Metadata", "NetJs.System.Net.NameResolution", "NetJs.System.Diagnostics.StackTrace", "NetJs.System.Net.Sockets", "NetJs.System.Security.Cryptography"))