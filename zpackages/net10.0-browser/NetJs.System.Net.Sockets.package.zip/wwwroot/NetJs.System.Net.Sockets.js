
(function ($global, $, $$, $mwp, $sc, $sdt, $st, $scc, $sm, $spu, $sr, $scn, $sris, $stee, $scsl, $snv, $sri, $sl, $stt, $sttp, $sdd, $snp, $ssc, $sspw, $sto, $snnr) {
    "use strict";
    let _;
    
    
    
	$.$asm(
    "NetJs.System.Net.Sockets", 
    {"h":58738,"f":"System.Net.Sockets","v":"1.0.35.0","a":[{"t":115015681,"c":12999917569,"a":[{"v":".NETCoreApp,Version=v10.0","t":1310721}],"n":[{"n":"FrameworkDisplayName","v":".NET 10.0","t":1310721}]},{"t":73596929,"c":4368564225,"a":[{"v":"SIT","t":1310721}]},{"t":73662465,"c":4368629761,"a":[{"v":"Debug","t":1310721}]},{"t":74121217,"c":4369088513,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":74252289,"c":4369219585,"a":[{"v":"1.0.35\u002Beff628fa5ab8bd29ec37e9c13a50148694bea088","t":1310721}]},{"t":75104257,"c":4370071553,"a":[{"v":"NetJs.System.Net.Sockets","t":1310721}]},{"t":75235329,"c":4370202625,"a":[{"v":"NetJs.System.Net.Sockets","t":1310721}]},{"t":75366401,"c":4370333697,"a":[{"v":"1.0.35.0","t":1310721}]},{"t":115081217,"c":4410048513,"a":[{"v":"browser1.0","t":1310721}]},{"t":114819073,"c":4409786369,"a":[{"v":"browser1.0","t":1310721}]}],"m":[]},
    function($asm)
	{
        
        
        $asm.$cls("$sns.System.Net.Sockets.IPv6MulticastOption", ($self) => class IPv6MulticastOption extends $.$$.System.Object
        {
            $ctor$2(/*System.Net.IPAddress*/ group)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$1(/*System.Net.IPAddress*/ group, /*long*/ ifindex)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.IPAddress */ get Group()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress */ set Group(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get InterfaceIndex()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set InterfaceIndex(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 320882;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3064565,"g":{"r":0,"d":0,"h":17180190066,"f":50331649},"s":{"r":0,"d":0,"h":21475157362,"f":83886081},"n":"Group","d":320882,"h":12885222770,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":30065091954,"f":50331649},"s":{"r":0,"d":0,"h":34360059250,"f":83886081},"n":"InterfaceIndex","d":320882,"h":25770124658,"f":2097153}],"c":[{"p":[{"n":"group","p":3064565}],"n":".ctor","o":"$ctor$2","d":320882,"h":4295288178,"f":16777217},{"p":[{"n":"group","p":3064565},{"n":"ifindex","p":917505}],"n":".ctor","o":"$ctor$1","d":320882,"h":8590255474,"f":16777217}],"h":320882}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Sockets.IPv6MulticastOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.LingerOption", ($self) => class LingerOption extends $.$$.System.Object
        {
            $ctor$1(/*bool*/ enable, /*int*/ seconds)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Enabled()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Enabled(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get LingerTime()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set LingerTime(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ comparand)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sns.System.Net.Sockets.LingerOption.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.LingerOption.GetHashCode.apply(this, arguments); }
            static $h = 386418;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":12885288306,"f":50331649},"s":{"r":0,"d":0,"h":17180255602,"f":83886081},"n":"Enabled","d":386418,"h":8590321010,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":25770190194,"f":50331649},"s":{"r":0,"d":0,"h":30065157490,"f":83886081},"n":"LingerTime","d":386418,"h":21475222898,"f":2097153}],"m":[{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","o":"@$1","d":386418,"h":34360124786,"f":16809985},{"r":655361,"n":"GetHashCode","d":386418,"h":38655092082,"f":16809985}],"c":[{"p":[{"n":"enable","p":262145},{"n":"seconds","p":655361}],"n":".ctor","o":"$ctor$1","d":386418,"h":4295353714,"f":16777217}],"h":386418}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Sockets.LingerOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.MulticastOption", ($self) => class MulticastOption extends $.$$.System.Object
        {
            $ctor$3(/*System.Net.IPAddress*/ group)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$1(/*System.Net.IPAddress*/ group, /*int*/ interfaceIndex)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ group, /*System.Net.IPAddress*/ mcint)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.IPAddress */ get Group()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress */ set Group(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get InterfaceIndex()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set InterfaceIndex(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress? */ get LocalAddress()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPAddress? */ set LocalAddress(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 451954;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":3064565,"g":{"r":0,"d":0,"h":21475288434,"f":50331649},"s":{"r":0,"d":0,"h":25770255730,"f":83886081},"n":"Group","d":451954,"h":17180321138,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":34360190322,"f":50331649},"s":{"r":0,"d":0,"h":38655157618,"f":83886081},"n":"InterfaceIndex","d":451954,"h":30065223026,"f":2097153},{"p":3064565,"g":{"r":0,"d":0,"h":47245092210,"f":50331649},"s":{"r":0,"d":0,"h":51540059506,"f":83886081},"n":"LocalAddress","d":451954,"h":42950124914,"f":2097153}],"c":[{"p":[{"n":"group","p":3064565}],"n":".ctor","o":"$ctor$3","d":451954,"h":4295419250,"f":16777217},{"p":[{"n":"group","p":3064565},{"n":"interfaceIndex","p":655361}],"n":".ctor","o":"$ctor$1","d":451954,"h":8590386546,"f":16777217},{"p":[{"n":"group","p":3064565},{"n":"mcint","p":3064565}],"n":".ctor","o":"$ctor$2","d":451954,"h":12885353842,"f":16777217}],"h":451954}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Sockets.MulticastOption`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SendPacketsElement", ($self) => class SendPacketsElement extends $.$$.System.Object
        {
            $ctor$3(/*byte[]*/ buffer)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$6(/*System.IO.FileStream*/ fileStream)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.IO.FileStream*/ fileStream, /*long*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.IO.FileStream*/ fileStream, /*long*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$8(/*System.ReadOnlyMemory<byte>*/ buffer)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$7(/*System.ReadOnlyMemory<byte>*/ buffer, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$13(/*string*/ filepath)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$10(/*string*/ filepath, /*int*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$9(/*string*/ filepath, /*int*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$12(/*string*/ filepath, /*long*/ offset, /*int*/ count)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$11(/*string*/ filepath, /*long*/ offset, /*int*/ count, /*bool*/ endOfPacket)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*byte[]? */ get Buffer()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EndOfPacket()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*string? */ get FilePath()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IO.FileStream? */ get FileStream()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.ReadOnlyMemory<byte>? */ get MemoryBuffer()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Offset()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get OffsetLong()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 845170;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":64425354610,"f":50331649},"n":"Buffer","d":845170,"h":60130387314,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":73015289202,"f":50331649},"n":"Count","d":845170,"h":68720321906,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":81605223794,"f":50331649},"n":"EndOfPacket","d":845170,"h":77310256498,"f":2097153},{"p":1310721,"g":{"r":0,"d":0,"h":90195158386,"f":50331649},"n":"FilePath","d":845170,"h":85900191090,"f":2097153},{"p":60358657,"g":{"r":0,"d":0,"h":98785092978,"f":50331649},"n":"FileStream","d":845170,"h":94490125682,"f":2097153},{"p":$.$typeNullable($.$$.System.ReadOnlyMemory$$($.$$.System.Byte)).$h,"g":{"r":0,"d":0,"h":107375027570,"f":50331649},"n":"MemoryBuffer","d":845170,"h":103080060274,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":115964962162,"f":50331649},"n":"Offset","d":845170,"h":111669994866,"f":2097153},{"p":917505,"g":{"r":0,"d":0,"h":124554896754,"f":50331649},"n":"OffsetLong","d":845170,"h":120259929458,"f":2097153}],"c":[{"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$3","d":845170,"h":4295812466,"f":16777217},{"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$2","d":845170,"h":8590779762,"f":16777217},{"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$1","d":845170,"h":12885747058,"f":16777217},{"p":[{"n":"fileStream","p":60358657}],"n":".ctor","o":"$ctor$6","d":845170,"h":17180714354,"f":16777217},{"p":[{"n":"fileStream","p":60358657},{"n":"offset","p":917505},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$5","d":845170,"h":21475681650,"f":16777217},{"p":[{"n":"fileStream","p":60358657},{"n":"offset","p":917505},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$4","d":845170,"h":25770648946,"f":16777217},{"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h}],"n":".ctor","o":"$ctor$8","d":845170,"h":30065616242,"f":16777217},{"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$7","d":845170,"h":34360583538,"f":16777217},{"p":[{"n":"filepath","p":1310721}],"n":".ctor","o":"$ctor$13","d":845170,"h":38655550834,"f":16777217},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$10","d":845170,"h":42950518130,"f":16777217},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$9","d":845170,"h":47245485426,"f":16777217},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":917505},{"n":"count","p":655361}],"n":".ctor","o":"$ctor$12","d":845170,"h":51540452722,"f":16777217},{"p":[{"n":"filepath","p":1310721},{"n":"offset","p":917505},{"n":"count","p":655361},{"n":"endOfPacket","p":262145}],"n":".ctor","o":"$ctor$11","d":845170,"h":55835420018,"f":16777217}],"h":845170}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SendPacketsElement`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SocketTaskExtensions", ($self) => class SocketTaskExtensions
        {
            static /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync$1(/*this System.Net.Sockets.Socket*/ socket)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.Sockets.Socket?*/ acceptSocket)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$3(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$5(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$4(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$7(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync$6(/*this System.Net.Sockets.Socket*/ socket, /*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task */ ConnectAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*string*/ host, /*int*/ port)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask */ ConnectAsync(/*this System.Net.Sockets.Socket*/ socket, /*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ ReceiveAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ ReceiveAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*this System.Net.Sockets.Socket*/ socket, /*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.ValueTask<int> */ SendAsync$2(/*this System.Net.Sockets.Socket*/ socket, /*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Threading.Tasks.Task<int> */ SendToAsync(/*this System.Net.Sockets.Socket*/ socket, /*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 1631602;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"m":[{"r":$.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"socket","p":910706}],"n":"AcceptAsync","o":"@$1","d":1631602,"h":4296598898,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":$.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"socket","p":910706},{"n":"acceptSocket","p":910706}],"n":"AcceptAsync","d":1631602,"h":8591566194,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":133169153,"p":[{"n":"socket","p":910706},{"n":"remoteEP","p":2605813}],"n":"ConnectAsync","o":"@$3","d":1631602,"h":12886533490,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":135987201,"p":[{"n":"socket","p":910706},{"n":"remoteEP","p":2605813},{"n":"cancellationToken","p":125829121}],"n":"ConnectAsync","o":"@$2","d":1631602,"h":17181500786,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":133169153,"p":[{"n":"socket","p":910706},{"n":"address","p":3064565},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$5","d":1631602,"h":21476468082,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":135987201,"p":[{"n":"socket","p":910706},{"n":"address","p":3064565},{"n":"port","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ConnectAsync","o":"@$4","d":1631602,"h":25771435378,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":133169153,"p":[{"n":"socket","p":910706},{"n":"addresses","p":$.$typeArray($.$snp.System.Net.IPAddress).$h},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$7","d":1631602,"h":30066402674,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":135987201,"p":[{"n":"socket","p":910706},{"n":"addresses","p":$.$typeArray($.$snp.System.Net.IPAddress).$h},{"n":"port","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ConnectAsync","o":"@$6","d":1631602,"h":34361369970,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":133169153,"p":[{"n":"socket","p":910706},{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$1","d":1631602,"h":38656337266,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":135987201,"p":[{"n":"socket","p":910706},{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ConnectAsync","d":1631602,"h":42951304562,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"socket","p":910706},{"n":"buffer","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314}],"n":"ReceiveAsync","d":1631602,"h":47246271858,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"socket","p":910706},{"n":"buffers","p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h},{"n":"socketFlags","p":1107314}],"n":"ReceiveAsync","o":"@$1","d":1631602,"h":51541239154,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"socket","p":910706},{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReceiveAsync","o":"@$2","d":1631602,"h":55836206450,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":$.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"socket","p":910706},{"n":"buffer","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"remoteEndPoint","p":2605813}],"n":"ReceiveFromAsync","d":1631602,"h":60131173746,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":$.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"socket","p":910706},{"n":"buffer","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"remoteEndPoint","p":2605813}],"n":"ReceiveMessageFromAsync","d":1631602,"h":64426141042,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"socket","p":910706},{"n":"buffer","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314}],"n":"SendAsync","d":1631602,"h":68721108338,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"socket","p":910706},{"n":"buffers","p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h},{"n":"socketFlags","p":1107314}],"n":"SendAsync","o":"@$1","d":1631602,"h":73016075634,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"socket","p":910706},{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"cancellationToken","p":125829121,"f":65}],"n":"SendAsync","o":"@$2","d":1631602,"h":77311042930,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"socket","p":910706},{"n":"buffer","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"remoteEP","p":2605813}],"n":"SendToAsync","d":1631602,"h":81606010226,"f":16777249,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}],"h":1631602,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]}]}; }
            static get $b() { return $.$$.System.Object; }
            static get $fullName() { return `System.Net.Sockets.SocketTaskExtensions`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.Socket", ($self) => class Socket extends $.$$.System.Object
        {
            $ctor$1(/*System.Net.Sockets.AddressFamily*/ addressFamily, /*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.Sockets.SafeSocketHandle*/ handle)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.Sockets.SocketInformation*/ socketInformation)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*System.Net.Sockets.AddressFamily */ get AddressFamily()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Blocking()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Blocking(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Connected()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DontFragment()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DontFragment(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DualMode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DualMode(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableBroadcast()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableBroadcast(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*nint */ get Handle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get IsBound()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ get LingerState()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ set LingerState(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get LocalEndPoint()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get MulticastLoopback()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set MulticastLoopback(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get NoDelay()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set NoDelay(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsIPv4()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsIPv6()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get OSSupportsUnixDomainSockets()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.ProtocolType */ get ProtocolType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveBufferSize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveBufferSize(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveTimeout(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get RemoteEndPoint()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SafeSocketHandle */ get SafeHandle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendBufferSize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendBufferSize(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendTimeout(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketType */ get SocketType()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get SupportsIPv4()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ get SupportsIPv6()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ get Ttl()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ set Ttl(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get UseOnlyOverlappedIO()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set UseOnlyOverlappedIO(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ Accept()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptAsync$3(/*System.Net.Sockets.Socket?*/ acceptSocket)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptAsync$2(/*System.Net.Sockets.Socket?*/ acceptSocket, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ AcceptAsync$4(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept$1(/*int*/ receiveSize, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAccept$2(/*System.Net.Sockets.Socket?*/ acceptSocket, /*int*/ receiveSize, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$1(/*System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$2(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$3(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect(/*string*/ host, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginDisconnect(/*bool*/ reuseSocket, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceive(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginReceive$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceive$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginReceive$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceiveFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginReceiveMessageFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginSend$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult? */ BeginSend$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendFile(/*string?*/ fileName, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendFile$1(/*string?*/ fileName, /*byte[]?*/ preBuffer, /*byte[]?*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSendTo(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Bind(/*System.Net.EndPoint*/ localEP)
            {
            }
            static /*void */ CancelConnectAsync(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
            }
            /*void */ Close()
            {
            }
            /*void */ Close$1(/*int*/ timeout)
            {
            }
            /*void */ Connect$1(/*System.Net.EndPoint*/ remoteEP)
            {
            }
            /*void */ Connect$2(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
            }
            /*void */ Connect$3(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
            }
            /*void */ Connect(/*string*/ host, /*int*/ port)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$3(/*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$2(/*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$5(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$4(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$7(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$6(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ConnectAsync$8(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ ConnectAsync$9(/*System.Net.Sockets.SocketType*/ socketType, /*System.Net.Sockets.ProtocolType*/ protocolType, /*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$1(/*string*/ host, /*int*/ port)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync(/*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Disconnect(/*bool*/ reuseSocket)
            {
            }
            /*System.Threading.Tasks.ValueTask */ DisconnectAsync(/*bool*/ reuseSocket, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ DisconnectAsync$1(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*System.Net.Sockets.SocketInformation */ DuplicateAndClose(/*int*/ targetProcessId)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept$1(/*out byte[]*/ buffer, /*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept$2(/*out byte[]*/ buffer, /*out int*/ bytesTransferred, /*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ EndAccept(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndConnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*void */ EndDisconnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndReceive$1(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceive(/*System.IAsyncResult*/ asyncResult, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceiveFrom(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.EndPoint*/ endPoint)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndReceiveMessageFrom(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ endPoint, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend$1(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend(/*System.IAsyncResult*/ asyncResult, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndSendFile(/*System.IAsyncResult*/ asyncResult)
            {
            }
            /*int */ EndSendTo(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            $dtor()
            {
            }
            /*int */ GetRawSocketOption(/*int*/ optionLevel, /*int*/ optionName, /*System.Span<byte>*/ optionValue)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ GetSocketOption$2(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ GetSocketOption(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*byte[]*/ optionValue)
            {
            }
            /*byte[] */ GetSocketOption$1(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*int*/ optionLength)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ IOControl(/*int*/ ioControlCode, /*byte[]?*/ optionInValue, /*byte[]?*/ optionOutValue)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ IOControl$1(/*System.Net.Sockets.IOControlCode*/ ioControlCode, /*byte[]?*/ optionInValue, /*byte[]?*/ optionOutValue)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Listen()
            {
            }
            /*void */ Listen$1(/*int*/ backlog)
            {
            }
            /*bool */ Poll(/*int*/ microSeconds, /*System.Net.Sockets.SelectMode*/ mode)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Poll$1(/*System.TimeSpan*/ timeout, /*System.Net.Sockets.SelectMode*/ mode)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$4(/*byte[]*/ buffer)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$2(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$3(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$7(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$6(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$5(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$10(/*System.Span<byte>*/ buffer)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$9(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Receive$8(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$1(/*System.ArraySegment<byte>*/ buffer)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReceiveAsync$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$5(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveAsync$4(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveAsync$6(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$1(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$3(/*byte[]*/ buffer, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$2(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$6(/*System.Span<byte>*/ buffer, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$5(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveFrom$4(/*System.Span<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ receivedAddress)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$2(/*System.Memory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveFromResult> */ ReceiveFromAsync$3(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReceiveFromAsync$4(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ receivedAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveFromAsync$5(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveMessageFrom(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReceiveMessageFrom$1(/*System.Span<byte>*/ buffer, /*ref System.Net.Sockets.SocketFlags*/ socketFlags, /*ref System.Net.EndPoint*/ remoteEP, /*out System.Net.Sockets.IPPacketInformation*/ ipPacketInformation)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$2(/*System.Memory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.SocketReceiveMessageFromResult> */ ReceiveMessageFromAsync$3(/*System.Memory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEndPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReceiveMessageFromAsync$4(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*void */ Select(/*System.Collections.IList?*/ checkRead, /*System.Collections.IList?*/ checkWrite, /*System.Collections.IList?*/ checkError, /*int*/ microSeconds)
            {
            }
            static /*void */ Select$1(/*System.Collections.IList?*/ checkRead, /*System.Collections.IList?*/ checkWrite, /*System.Collections.IList?*/ checkError, /*System.TimeSpan*/ timeout)
            {
            }
            /*int */ Send$4(/*byte[]*/ buffer)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$1(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$2(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$3(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$7(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$6(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$5(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$10(/*System.ReadOnlySpan<byte>*/ buffer)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$9(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$8(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*out System.Net.Sockets.SocketError*/ errorCode)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*System.ArraySegment<byte>*/ buffer)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$3(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$2(/*System.Collections.Generic.IList<System.ArraySegment<byte>>*/ buffers, /*System.Net.Sockets.SocketFlags*/ socketFlags)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendAsync$6(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$5(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$4(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SendFile$2(/*string?*/ fileName)
            {
            }
            /*void */ SendFile(/*string?*/ fileName, /*byte[]?*/ preBuffer, /*byte[]?*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags)
            {
            }
            /*void */ SendFile$1(/*string?*/ fileName, /*System.ReadOnlySpan<byte>*/ preBuffer, /*System.ReadOnlySpan<byte>*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags)
            {
            }
            /*System.Threading.Tasks.ValueTask */ SendFileAsync(/*string?*/ fileName, /*System.ReadOnlyMemory<byte>*/ preBuffer, /*System.ReadOnlyMemory<byte>*/ postBuffer, /*System.Net.Sockets.TransmitFileOptions*/ flags, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ SendFileAsync$1(/*string?*/ fileName, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendPacketsAsync(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo(/*byte[]*/ buffer, /*int*/ offset, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$1(/*byte[]*/ buffer, /*int*/ size, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$2(/*byte[]*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$3(/*byte[]*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$4(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$5(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ SendTo$6(/*System.ReadOnlySpan<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ socketAddress)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendToAsync(/*System.ArraySegment<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendToAsync$1(/*System.ArraySegment<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ SendToAsync$5(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$3(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.EndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendToAsync$4(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Net.Sockets.SocketFlags*/ socketFlags, /*System.Net.SocketAddress*/ socketAddress, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetIPProtectionLevel(/*System.Net.Sockets.IPProtectionLevel*/ level)
            {
            }
            /*void */ SetRawSocketOption(/*int*/ optionLevel, /*int*/ optionName, /*System.ReadOnlySpan<byte>*/ optionValue)
            {
            }
            /*void */ SetSocketOption(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*bool*/ optionValue)
            {
            }
            /*void */ SetSocketOption$1(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*byte[]*/ optionValue)
            {
            }
            /*void */ SetSocketOption$2(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*int*/ optionValue)
            {
            }
            /*void */ SetSocketOption$3(/*System.Net.Sockets.SocketOptionLevel*/ optionLevel, /*System.Net.Sockets.SocketOptionName*/ optionName, /*object*/ optionValue)
            {
            }
            /*void */ Shutdown(/*System.Net.Sockets.SocketShutdown*/ how)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 910706;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":4506357,"g":{"r":0,"d":0,"h":25770714482,"f":50331649},"n":"AddressFamily","d":910706,"h":21475747186,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":34360649074,"f":50331649},"n":"Available","d":910706,"h":30065681778,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":42950583666,"f":50331649},"s":{"r":0,"d":0,"h":47245550962,"f":83886081},"n":"Blocking","d":910706,"h":38655616370,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":55835485554,"f":50331649},"n":"Connected","d":910706,"h":51540518258,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":64425420146,"f":50331649},"s":{"r":0,"d":0,"h":68720387442,"f":83886081},"n":"DontFragment","d":910706,"h":60130452850,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":77310322034,"f":50331649},"s":{"r":0,"d":0,"h":81605289330,"f":83886081},"n":"DualMode","d":910706,"h":73015354738,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":90195223922,"f":50331649},"s":{"r":0,"d":0,"h":94490191218,"f":83886081},"n":"EnableBroadcast","d":910706,"h":85900256626,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":103080125810,"f":50331649},"s":{"r":0,"d":0,"h":107375093106,"f":83886081},"n":"ExclusiveAddressUse","d":910706,"h":98785158514,"f":2097153},{"p":786433,"g":{"r":0,"d":0,"h":115965027698,"f":50331649},"n":"Handle","d":910706,"h":111670060402,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":124554962290,"f":50331649},"n":"IsBound","d":910706,"h":120259994994,"f":2097153},{"p":386418,"g":{"r":0,"d":0,"h":133144896882,"f":50331649},"s":{"r":0,"d":0,"h":137439864178,"f":83886081},"n":"LingerState","d":910706,"h":128849929586,"f":2097153},{"p":2605813,"g":{"r":0,"d":0,"h":146029798770,"f":50331649},"n":"LocalEndPoint","d":910706,"h":141734831474,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":154619733362,"f":50331649},"s":{"r":0,"d":0,"h":158914700658,"f":83886081},"n":"MulticastLoopback","d":910706,"h":150324766066,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":167504635250,"f":50331649},"s":{"r":0,"d":0,"h":171799602546,"f":83886081},"n":"NoDelay","d":910706,"h":163209667954,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":180389537138,"f":50331681},"n":"OSSupportsIPv4","d":910706,"h":176094569842,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":188979471730,"f":50331681},"n":"OSSupportsIPv6","d":910706,"h":184684504434,"f":2097185},{"p":262145,"g":{"r":0,"d":0,"h":197569406322,"f":50331681},"n":"OSSupportsUnixDomainSockets","d":910706,"h":193274439026,"f":2097185},{"p":648562,"g":{"r":0,"d":0,"h":206159340914,"f":50331649},"n":"ProtocolType","d":910706,"h":201864373618,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":214749275506,"f":50331649},"s":{"r":0,"d":0,"h":219044242802,"f":83886081},"n":"ReceiveBufferSize","d":910706,"h":210454308210,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":227634177394,"f":50331649},"s":{"r":0,"d":0,"h":231929144690,"f":83886081},"n":"ReceiveTimeout","d":910706,"h":223339210098,"f":2097153},{"p":2605813,"g":{"r":0,"d":0,"h":240519079282,"f":50331649},"n":"RemoteEndPoint","d":910706,"h":236224111986,"f":2097153},{"p":714098,"g":{"r":0,"d":0,"h":249109013874,"f":50331649},"n":"SafeHandle","d":910706,"h":244814046578,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":257698948466,"f":50331649},"s":{"r":0,"d":0,"h":261993915762,"f":83886081},"n":"SendBufferSize","d":910706,"h":253403981170,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":270583850354,"f":50331649},"s":{"r":0,"d":0,"h":274878817650,"f":83886081},"n":"SendTimeout","d":910706,"h":266288883058,"f":2097153},{"p":1697138,"g":{"r":0,"d":0,"h":283468752242,"f":50331649},"n":"SocketType","d":910706,"h":279173784946,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":292058686834,"f":50331681},"n":"SupportsIPv4","d":910706,"h":287763719538,"f":2097185,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SupportsIPv4 has been deprecated. Use OSSupportsIPv4 instead.","t":1310721}]}]},{"p":262145,"g":{"r":0,"d":0,"h":300648621426,"f":50331681},"n":"SupportsIPv6","d":910706,"h":296353654130,"f":2097185,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"SupportsIPv6 has been deprecated. Use OSSupportsIPv6 instead.","t":1310721}]}]},{"p":524289,"g":{"r":0,"d":0,"h":309238556018,"f":50331649},"s":{"r":0,"d":0,"h":313533523314,"f":83886081},"n":"Ttl","d":910706,"h":304943588722,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":322123457906,"f":50331649},"s":{"r":0,"d":0,"h":326418425202,"f":83886081},"n":"UseOnlyOverlappedIO","d":910706,"h":317828490610,"f":2097153,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]},{"t":70909953,"c":8660844545,"a":[{"v":"UseOnlyOverlappedIO has been deprecated and is not supported.","t":1310721}]}]}],"m":[{"r":910706,"n":"Accept","d":910706,"h":330713392498,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"n":"AcceptAsync","d":910706,"h":335008359794,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"acceptSocket","p":910706}],"n":"AcceptAsync","o":"@$3","d":910706,"h":339303327090,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"acceptSocket","p":910706},{"n":"cancellationToken","p":125829121}],"n":"AcceptAsync","o":"@$2","d":910706,"h":343598294386,"f":16777217},{"r":262145,"p":[{"n":"e","p":976242}],"n":"AcceptAsync","o":"@$4","d":910706,"h":347893261682,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"cancellationToken","p":125829121}],"n":"AcceptAsync","o":"@$1","d":910706,"h":352188228978,"f":16777217},{"r":57016321,"p":[{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginAccept","d":910706,"h":356483196274,"f":16777217},{"r":57016321,"p":[{"n":"receiveSize","p":655361},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginAccept","o":"@$1","d":910706,"h":360778163570,"f":16777217},{"r":57016321,"p":[{"n":"acceptSocket","p":910706},{"n":"receiveSize","p":655361},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginAccept","o":"@$2","d":910706,"h":365073130866,"f":16777217},{"r":57016321,"p":[{"n":"remoteEP","p":2605813},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$1","d":910706,"h":369368098162,"f":16777217},{"r":57016321,"p":[{"n":"address","p":3064565},{"n":"port","p":655361},{"n":"requestCallback","p":14548993},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$2","d":910706,"h":373663065458,"f":16777217},{"r":57016321,"p":[{"n":"addresses","p":$.$typeArray($.$snp.System.Net.IPAddress).$h},{"n":"port","p":655361},{"n":"requestCallback","p":14548993},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$3","d":910706,"h":377958032754,"f":16777217},{"r":57016321,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14548993},{"n":"state","p":131073}],"n":"BeginConnect","d":910706,"h":382253000050,"f":16777217},{"r":57016321,"p":[{"n":"reuseSocket","p":262145},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginDisconnect","d":910706,"h":386547967346,"f":16777217},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1107314},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginReceive","d":910706,"h":390842934642,"f":16777217},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1107314},{"n":"errorCode","p":4702965,"f":2},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$1","d":910706,"h":395137901938,"f":16777217},{"r":57016321,"p":[{"n":"buffers","p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h},{"n":"socketFlags","p":1107314},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$2","d":910706,"h":399432869234,"f":16777217},{"r":57016321,"p":[{"n":"buffers","p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h},{"n":"socketFlags","p":1107314},{"n":"errorCode","p":4702965,"f":2},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginReceive","o":"@$3","d":910706,"h":403727836530,"f":16777217},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1107314},{"n":"remoteEP","p":2605813,"f":4},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginReceiveFrom","d":910706,"h":408022803826,"f":16777217},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1107314},{"n":"remoteEP","p":2605813,"f":4},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginReceiveMessageFrom","d":910706,"h":412317771122,"f":16777217},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1107314},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginSend","d":910706,"h":416612738418,"f":16777217},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1107314},{"n":"errorCode","p":4702965,"f":2},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginSend","o":"@$1","d":910706,"h":420907705714,"f":16777217},{"r":57016321,"p":[{"n":"buffers","p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h},{"n":"socketFlags","p":1107314},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginSend","o":"@$2","d":910706,"h":425202673010,"f":16777217},{"r":57016321,"p":[{"n":"buffers","p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h},{"n":"socketFlags","p":1107314},{"n":"errorCode","p":4702965,"f":2},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginSend","o":"@$3","d":910706,"h":429497640306,"f":16777217},{"r":57016321,"p":[{"n":"fileName","p":1310721},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginSendFile","d":910706,"h":433792607602,"f":16777217},{"r":57016321,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"postBuffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"flags","p":1893746},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginSendFile","o":"@$1","d":910706,"h":438087574898,"f":16777217},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1107314},{"n":"remoteEP","p":2605813},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginSendTo","d":910706,"h":442382542194,"f":16777217},{"r":65537,"p":[{"n":"localEP","p":2605813}],"n":"Bind","d":910706,"h":446677509490,"f":16777217},{"r":65537,"p":[{"n":"e","p":976242}],"n":"CancelConnectAsync","d":910706,"h":450972476786,"f":16777249},{"r":65537,"n":"Close","d":910706,"h":455267444082,"f":16777217},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Close","o":"@$1","d":910706,"h":459562411378,"f":16777217},{"r":65537,"p":[{"n":"remoteEP","p":2605813}],"n":"Connect","o":"@$1","d":910706,"h":463857378674,"f":16777217},{"r":65537,"p":[{"n":"address","p":3064565},{"n":"port","p":655361}],"n":"Connect","o":"@$2","d":910706,"h":468152345970,"f":16777217},{"r":65537,"p":[{"n":"addresses","p":$.$typeArray($.$snp.System.Net.IPAddress).$h},{"n":"port","p":655361}],"n":"Connect","o":"@$3","d":910706,"h":472447313266,"f":16777217},{"r":65537,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"Connect","d":910706,"h":476742280562,"f":16777217},{"r":133169153,"p":[{"n":"remoteEP","p":2605813}],"n":"ConnectAsync","o":"@$3","d":910706,"h":481037247858,"f":16777217},{"r":135987201,"p":[{"n":"remoteEP","p":2605813},{"n":"cancellationToken","p":125829121}],"n":"ConnectAsync","o":"@$2","d":910706,"h":485332215154,"f":16777217},{"r":133169153,"p":[{"n":"address","p":3064565},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$5","d":910706,"h":489627182450,"f":16777217},{"r":135987201,"p":[{"n":"address","p":3064565},{"n":"port","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ConnectAsync","o":"@$4","d":910706,"h":493922149746,"f":16777217},{"r":133169153,"p":[{"n":"addresses","p":$.$typeArray($.$snp.System.Net.IPAddress).$h},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$7","d":910706,"h":498217117042,"f":16777217},{"r":135987201,"p":[{"n":"addresses","p":$.$typeArray($.$snp.System.Net.IPAddress).$h},{"n":"port","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ConnectAsync","o":"@$6","d":910706,"h":502512084338,"f":16777217},{"r":262145,"p":[{"n":"e","p":976242}],"n":"ConnectAsync","o":"@$8","d":910706,"h":506807051634,"f":16777217},{"r":262145,"p":[{"n":"socketType","p":1697138},{"n":"protocolType","p":648562},{"n":"e","p":976242}],"n":"ConnectAsync","o":"@$9","d":910706,"h":511102018930,"f":16777249},{"r":133169153,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$1","d":910706,"h":515396986226,"f":16777217},{"r":135987201,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ConnectAsync","d":910706,"h":519691953522,"f":16777217},{"r":65537,"p":[{"n":"reuseSocket","p":262145}],"n":"Disconnect","d":910706,"h":523986920818,"f":16777217},{"r":135987201,"p":[{"n":"reuseSocket","p":262145},{"n":"cancellationToken","p":125829121,"f":65}],"n":"DisconnectAsync","d":910706,"h":528281888114,"f":16777217},{"r":262145,"p":[{"n":"e","p":976242}],"n":"DisconnectAsync","o":"@$1","d":910706,"h":532576855410,"f":16777217},{"r":65537,"n":"Dispose","d":910706,"h":536871822706,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":910706,"h":541166790002,"f":16777348},{"r":1172850,"p":[{"n":"targetProcessId","p":655361}],"n":"DuplicateAndClose","d":910706,"h":545461757298,"f":16777217,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"r":910706,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h,"f":2},{"n":"asyncResult","p":57016321}],"n":"EndAccept","o":"@$1","d":910706,"h":549756724594,"f":16777217},{"r":910706,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h,"f":2},{"n":"bytesTransferred","p":655361,"f":2},{"n":"asyncResult","p":57016321}],"n":"EndAccept","o":"@$2","d":910706,"h":554051691890,"f":16777217},{"r":910706,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAccept","d":910706,"h":558346659186,"f":16777217},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndConnect","d":910706,"h":562641626482,"f":16777217},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndDisconnect","d":910706,"h":566936593778,"f":16777217},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndReceive","o":"@$1","d":910706,"h":571231561074,"f":16777217},{"r":655361,"p":[{"n":"asyncResult","p":57016321},{"n":"errorCode","p":4702965,"f":2}],"n":"EndReceive","d":910706,"h":575526528370,"f":16777217},{"r":655361,"p":[{"n":"asyncResult","p":57016321},{"n":"endPoint","p":2605813,"f":4}],"n":"EndReceiveFrom","d":910706,"h":579821495666,"f":16777217},{"r":655361,"p":[{"n":"asyncResult","p":57016321},{"n":"socketFlags","p":1107314,"f":4},{"n":"endPoint","p":2605813,"f":4},{"n":"ipPacketInformation","p":189810,"f":2}],"n":"EndReceiveMessageFrom","d":910706,"h":584116462962,"f":16777217},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndSend","o":"@$1","d":910706,"h":588411430258,"f":16777217},{"r":655361,"p":[{"n":"asyncResult","p":57016321},{"n":"errorCode","p":4702965,"f":2}],"n":"EndSend","d":910706,"h":592706397554,"f":16777217},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndSendFile","d":910706,"h":597001364850,"f":16777217},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndSendTo","d":910706,"h":601296332146,"f":16777217},{"r":655361,"p":[{"n":"optionLevel","p":655361},{"n":"optionName","p":655361},{"n":"optionValue","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"GetRawSocketOption","d":910706,"h":609886266738,"f":16777217},{"r":131073,"p":[{"n":"optionLevel","p":1303922},{"n":"optionName","p":1369458}],"n":"GetSocketOption","o":"@$2","d":910706,"h":614181234034,"f":16777217},{"r":65537,"p":[{"n":"optionLevel","p":1303922},{"n":"optionName","p":1369458},{"n":"optionValue","p":$.$typeArray($.$$.System.Byte).$h}],"n":"GetSocketOption","d":910706,"h":618476201330,"f":16777217},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"optionLevel","p":1303922},{"n":"optionName","p":1369458},{"n":"optionLength","p":655361}],"n":"GetSocketOption","o":"@$1","d":910706,"h":622771168626,"f":16777217},{"r":655361,"p":[{"n":"ioControlCode","p":655361},{"n":"optionInValue","p":$.$typeArray($.$$.System.Byte).$h},{"n":"optionOutValue","p":$.$typeArray($.$$.System.Byte).$h}],"n":"IOControl","d":910706,"h":627066135922,"f":16777217},{"r":655361,"p":[{"n":"ioControlCode","p":124274},{"n":"optionInValue","p":$.$typeArray($.$$.System.Byte).$h},{"n":"optionOutValue","p":$.$typeArray($.$$.System.Byte).$h}],"n":"IOControl","o":"@$1","d":910706,"h":631361103218,"f":16777217},{"r":65537,"n":"Listen","d":910706,"h":635656070514,"f":16777217},{"r":65537,"p":[{"n":"backlog","p":655361}],"n":"Listen","o":"@$1","d":910706,"h":639951037810,"f":16777217},{"r":262145,"p":[{"n":"microSeconds","p":655361},{"n":"mode","p":779634}],"n":"Poll","d":910706,"h":644246005106,"f":16777217},{"r":262145,"p":[{"n":"timeout","p":140574721},{"n":"mode","p":779634}],"n":"Poll","o":"@$1","d":910706,"h":648540972402,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h}],"n":"Receive","o":"@$4","d":910706,"h":652835939698,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1107314}],"n":"Receive","o":"@$1","d":910706,"h":657130906994,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1107314},{"n":"errorCode","p":4702965,"f":2}],"n":"Receive","d":910706,"h":661425874290,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"size","p":655361},{"n":"socketFlags","p":1107314}],"n":"Receive","o":"@$2","d":910706,"h":665720841586,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314}],"n":"Receive","o":"@$3","d":910706,"h":670015808882,"f":16777217},{"r":655361,"p":[{"n":"buffers","p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h}],"n":"Receive","o":"@$7","d":910706,"h":674310776178,"f":16777217},{"r":655361,"p":[{"n":"buffers","p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h},{"n":"socketFlags","p":1107314}],"n":"Receive","o":"@$6","d":910706,"h":678605743474,"f":16777217},{"r":655361,"p":[{"n":"buffers","p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h},{"n":"socketFlags","p":1107314},{"n":"errorCode","p":4702965,"f":2}],"n":"Receive","o":"@$5","d":910706,"h":682900710770,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"Receive","o":"@$10","d":910706,"h":687195678066,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314}],"n":"Receive","o":"@$9","d":910706,"h":691490645362,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"errorCode","p":4702965,"f":2}],"n":"Receive","o":"@$8","d":910706,"h":695785612658,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h}],"n":"ReceiveAsync","o":"@$1","d":910706,"h":700080579954,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314}],"n":"ReceiveAsync","d":910706,"h":704375547250,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffers","p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h}],"n":"ReceiveAsync","o":"@$3","d":910706,"h":708670514546,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffers","p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h},{"n":"socketFlags","p":1107314}],"n":"ReceiveAsync","o":"@$2","d":910706,"h":712965481842,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReceiveAsync","o":"@$5","d":910706,"h":717260449138,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReceiveAsync","o":"@$4","d":910706,"h":721555416434,"f":16777217},{"r":262145,"p":[{"n":"e","p":976242}],"n":"ReceiveAsync","o":"@$6","d":910706,"h":725850383730,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1107314},{"n":"remoteEP","p":2605813,"f":4}],"n":"ReceiveFrom","d":910706,"h":730145351026,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"size","p":655361},{"n":"socketFlags","p":1107314},{"n":"remoteEP","p":2605813,"f":4}],"n":"ReceiveFrom","o":"@$1","d":910706,"h":734440318322,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"remoteEP","p":2605813,"f":4}],"n":"ReceiveFrom","o":"@$3","d":910706,"h":738735285618,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"remoteEP","p":2605813,"f":4}],"n":"ReceiveFrom","o":"@$2","d":910706,"h":743030252914,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"remoteEP","p":2605813,"f":4}],"n":"ReceiveFrom","o":"@$6","d":910706,"h":747325220210,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"remoteEP","p":2605813,"f":4}],"n":"ReceiveFrom","o":"@$5","d":910706,"h":751620187506,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"receivedAddress","p":4375285}],"n":"ReceiveFrom","o":"@$4","d":910706,"h":755915154802,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h},{"n":"remoteEndPoint","p":2605813}],"n":"ReceiveFromAsync","d":910706,"h":760210122098,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"remoteEndPoint","p":2605813}],"n":"ReceiveFromAsync","o":"@$1","d":910706,"h":764505089394,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"remoteEndPoint","p":2605813},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReceiveFromAsync","o":"@$2","d":910706,"h":768800056690,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveFromResult).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"remoteEndPoint","p":2605813},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReceiveFromAsync","o":"@$3","d":910706,"h":773095023986,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"receivedAddress","p":4375285},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReceiveFromAsync","o":"@$4","d":910706,"h":777389991282,"f":16777217},{"r":262145,"p":[{"n":"e","p":976242}],"n":"ReceiveFromAsync","o":"@$5","d":910706,"h":781684958578,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1107314,"f":4},{"n":"remoteEP","p":2605813,"f":4},{"n":"ipPacketInformation","p":189810,"f":2}],"n":"ReceiveMessageFrom","d":910706,"h":785979925874,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314,"f":4},{"n":"remoteEP","p":2605813,"f":4},{"n":"ipPacketInformation","p":189810,"f":2}],"n":"ReceiveMessageFrom","o":"@$1","d":910706,"h":790274893170,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h},{"n":"remoteEndPoint","p":2605813}],"n":"ReceiveMessageFromAsync","d":910706,"h":794569860466,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"remoteEndPoint","p":2605813}],"n":"ReceiveMessageFromAsync","o":"@$1","d":910706,"h":798864827762,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"remoteEndPoint","p":2605813},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReceiveMessageFromAsync","o":"@$2","d":910706,"h":803159795058,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.SocketReceiveMessageFromResult).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"remoteEndPoint","p":2605813},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReceiveMessageFromAsync","o":"@$3","d":910706,"h":807454762354,"f":16777217},{"r":262145,"p":[{"n":"e","p":976242}],"n":"ReceiveMessageFromAsync","o":"@$4","d":910706,"h":811749729650,"f":16777217},{"r":65537,"p":[{"n":"checkRead","p":32047105},{"n":"checkWrite","p":32047105},{"n":"checkError","p":32047105},{"n":"microSeconds","p":655361}],"n":"Select","d":910706,"h":816044696946,"f":16777249},{"r":65537,"p":[{"n":"checkRead","p":32047105},{"n":"checkWrite","p":32047105},{"n":"checkError","p":32047105},{"n":"timeout","p":140574721}],"n":"Select","o":"@$1","d":910706,"h":820339664242,"f":16777249},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h}],"n":"Send","o":"@$4","d":910706,"h":824634631538,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1107314}],"n":"Send","o":"@$1","d":910706,"h":828929598834,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1107314},{"n":"errorCode","p":4702965,"f":2}],"n":"Send","d":910706,"h":833224566130,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"size","p":655361},{"n":"socketFlags","p":1107314}],"n":"Send","o":"@$2","d":910706,"h":837519533426,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314}],"n":"Send","o":"@$3","d":910706,"h":841814500722,"f":16777217},{"r":655361,"p":[{"n":"buffers","p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h}],"n":"Send","o":"@$7","d":910706,"h":846109468018,"f":16777217},{"r":655361,"p":[{"n":"buffers","p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h},{"n":"socketFlags","p":1107314}],"n":"Send","o":"@$6","d":910706,"h":850404435314,"f":16777217},{"r":655361,"p":[{"n":"buffers","p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h},{"n":"socketFlags","p":1107314},{"n":"errorCode","p":4702965,"f":2}],"n":"Send","o":"@$5","d":910706,"h":854699402610,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"Send","o":"@$10","d":910706,"h":858994369906,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314}],"n":"Send","o":"@$9","d":910706,"h":863289337202,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"errorCode","p":4702965,"f":2}],"n":"Send","o":"@$8","d":910706,"h":867584304498,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h}],"n":"SendAsync","o":"@$1","d":910706,"h":871879271794,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314}],"n":"SendAsync","d":910706,"h":876174239090,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffers","p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h}],"n":"SendAsync","o":"@$3","d":910706,"h":880469206386,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffers","p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h},{"n":"socketFlags","p":1107314}],"n":"SendAsync","o":"@$2","d":910706,"h":884764173682,"f":16777217},{"r":262145,"p":[{"n":"e","p":976242}],"n":"SendAsync","o":"@$6","d":910706,"h":889059140978,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"cancellationToken","p":125829121,"f":65}],"n":"SendAsync","o":"@$5","d":910706,"h":893354108274,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"SendAsync","o":"@$4","d":910706,"h":897649075570,"f":16777217},{"r":65537,"p":[{"n":"fileName","p":1310721}],"n":"SendFile","o":"@$2","d":910706,"h":901944042866,"f":16777217},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"postBuffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"flags","p":1893746}],"n":"SendFile","d":910706,"h":906239010162,"f":16777217},{"r":65537,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"postBuffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"flags","p":1893746}],"n":"SendFile","o":"@$1","d":910706,"h":910533977458,"f":16777217},{"r":135987201,"p":[{"n":"fileName","p":1310721},{"n":"preBuffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"postBuffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"flags","p":1893746},{"n":"cancellationToken","p":125829121,"f":65}],"n":"SendFileAsync","d":910706,"h":914828944754,"f":16777217},{"r":135987201,"p":[{"n":"fileName","p":1310721},{"n":"cancellationToken","p":125829121,"f":65}],"n":"SendFileAsync","o":"@$1","d":910706,"h":919123912050,"f":16777217},{"r":262145,"p":[{"n":"e","p":976242}],"n":"SendPacketsAsync","d":910706,"h":923418879346,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"size","p":655361},{"n":"socketFlags","p":1107314},{"n":"remoteEP","p":2605813}],"n":"SendTo","d":910706,"h":927713846642,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"size","p":655361},{"n":"socketFlags","p":1107314},{"n":"remoteEP","p":2605813}],"n":"SendTo","o":"@$1","d":910706,"h":932008813938,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"remoteEP","p":2605813}],"n":"SendTo","o":"@$2","d":910706,"h":936303781234,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"remoteEP","p":2605813}],"n":"SendTo","o":"@$3","d":910706,"h":940598748530,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"remoteEP","p":2605813}],"n":"SendTo","o":"@$4","d":910706,"h":944893715826,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"remoteEP","p":2605813}],"n":"SendTo","o":"@$5","d":910706,"h":949188683122,"f":16777217},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"socketAddress","p":4375285}],"n":"SendTo","o":"@$6","d":910706,"h":953483650418,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h},{"n":"remoteEP","p":2605813}],"n":"SendToAsync","d":910706,"h":957778617714,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.ArraySegment$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"remoteEP","p":2605813}],"n":"SendToAsync","o":"@$1","d":910706,"h":962073585010,"f":16777217},{"r":262145,"p":[{"n":"e","p":976242}],"n":"SendToAsync","o":"@$5","d":910706,"h":966368552306,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"remoteEP","p":2605813},{"n":"cancellationToken","p":125829121,"f":65}],"n":"SendToAsync","o":"@$2","d":910706,"h":970663519602,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"remoteEP","p":2605813},{"n":"cancellationToken","p":125829121,"f":65}],"n":"SendToAsync","o":"@$3","d":910706,"h":974958486898,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"socketFlags","p":1107314},{"n":"socketAddress","p":4375285},{"n":"cancellationToken","p":125829121,"f":65}],"n":"SendToAsync","o":"@$4","d":910706,"h":979253454194,"f":16777217},{"r":65537,"p":[{"n":"level","p":255346}],"n":"SetIPProtectionLevel","d":910706,"h":983548421490,"f":16777217,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"r":65537,"p":[{"n":"optionLevel","p":655361},{"n":"optionName","p":655361},{"n":"optionValue","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"SetRawSocketOption","d":910706,"h":987843388786,"f":16777217},{"r":65537,"p":[{"n":"optionLevel","p":1303922},{"n":"optionName","p":1369458},{"n":"optionValue","p":262145}],"n":"SetSocketOption","d":910706,"h":992138356082,"f":16777217},{"r":65537,"p":[{"n":"optionLevel","p":1303922},{"n":"optionName","p":1369458},{"n":"optionValue","p":$.$typeArray($.$$.System.Byte).$h}],"n":"SetSocketOption","o":"@$1","d":910706,"h":996433323378,"f":16777217},{"r":65537,"p":[{"n":"optionLevel","p":1303922},{"n":"optionName","p":1369458},{"n":"optionValue","p":655361}],"n":"SetSocketOption","o":"@$2","d":910706,"h":1000728290674,"f":16777217},{"r":65537,"p":[{"n":"optionLevel","p":1303922},{"n":"optionName","p":1369458},{"n":"optionValue","p":131073}],"n":"SetSocketOption","o":"@$3","d":910706,"h":1005023257970,"f":16777217},{"r":65537,"p":[{"n":"how","p":1566066}],"n":"Shutdown","d":910706,"h":1009318225266,"f":16777217}],"c":[{"p":[{"n":"addressFamily","p":4506357},{"n":"socketType","p":1697138},{"n":"protocolType","p":648562}],"n":".ctor","o":"$ctor$1","d":910706,"h":4295878002,"f":16777217},{"p":[{"n":"handle","p":714098}],"n":".ctor","o":"$ctor$2","d":910706,"h":8590845298,"f":16777217},{"p":[{"n":"socketInformation","p":1172850}],"n":".ctor","o":"$ctor$3","d":910706,"h":12885812594,"f":16777217,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"p":[{"n":"socketType","p":1697138},{"n":"protocolType","p":648562}],"n":".ctor","o":"$ctor$4","d":910706,"h":17180779890,"f":16777217}],"i":[57540609],"h":910706}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.Socket`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.TcpClient", ($self) => class TcpClient extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*string*/ hostname, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Active(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Client()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ set Client(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Connected()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ get LingerState()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.LingerOption? */ set LingerState(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get NoDelay()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set NoDelay(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveBufferSize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveBufferSize(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReceiveTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReceiveTimeout(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendBufferSize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendBufferSize(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendTimeout(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$1(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect$2(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginConnect(/*string*/ host, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close()
            {
            }
            /*void */ Connect$1(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
            }
            /*void */ Connect$2(/*System.Net.IPAddress[]*/ ipAddresses, /*int*/ port)
            {
            }
            /*void */ Connect$3(/*System.Net.IPEndPoint*/ remoteEP)
            {
            }
            /*void */ Connect(/*string*/ hostname, /*int*/ port)
            {
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$3(/*System.Net.IPAddress*/ address, /*int*/ port)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$2(/*System.Net.IPAddress*/ address, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$5(/*System.Net.IPAddress[]*/ addresses, /*int*/ port)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$4(/*System.Net.IPAddress[]*/ addresses, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$7(/*System.Net.IPEndPoint*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync$6(/*System.Net.IPEndPoint*/ remoteEP, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task */ ConnectAsync$1(/*string*/ host, /*int*/ port)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ ConnectAsync(/*string*/ host, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ EndConnect(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*System.Net.Sockets.NetworkStream */ GetStream()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 1762674;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25771566450,"f":50331652},"s":{"r":0,"d":0,"h":30066533746,"f":83886084},"n":"Active","d":1762674,"h":21476599154,"f":2097156},{"p":655361,"g":{"r":0,"d":0,"h":38656468338,"f":50331649},"n":"Available","d":1762674,"h":34361501042,"f":2097153},{"p":910706,"g":{"r":0,"d":0,"h":47246402930,"f":50331649},"s":{"r":0,"d":0,"h":51541370226,"f":83886081},"n":"Client","d":1762674,"h":42951435634,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":60131304818,"f":50331649},"n":"Connected","d":1762674,"h":55836337522,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":68721239410,"f":50331649},"s":{"r":0,"d":0,"h":73016206706,"f":83886081},"n":"ExclusiveAddressUse","d":1762674,"h":64426272114,"f":2097153},{"p":386418,"g":{"r":0,"d":0,"h":81606141298,"f":50331649},"s":{"r":0,"d":0,"h":85901108594,"f":83886081},"n":"LingerState","d":1762674,"h":77311174002,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":94491043186,"f":50331649},"s":{"r":0,"d":0,"h":98786010482,"f":83886081},"n":"NoDelay","d":1762674,"h":90196075890,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":107375945074,"f":50331649},"s":{"r":0,"d":0,"h":111670912370,"f":83886081},"n":"ReceiveBufferSize","d":1762674,"h":103080977778,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":120260846962,"f":50331649},"s":{"r":0,"d":0,"h":124555814258,"f":83886081},"n":"ReceiveTimeout","d":1762674,"h":115965879666,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":133145748850,"f":50331649},"s":{"r":0,"d":0,"h":137440716146,"f":83886081},"n":"SendBufferSize","d":1762674,"h":128850781554,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":146030650738,"f":50331649},"s":{"r":0,"d":0,"h":150325618034,"f":83886081},"n":"SendTimeout","d":1762674,"h":141735683442,"f":2097153}],"m":[{"r":57016321,"p":[{"n":"address","p":3064565},{"n":"port","p":655361},{"n":"requestCallback","p":14548993},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$1","d":1762674,"h":154620585330,"f":16777217},{"r":57016321,"p":[{"n":"addresses","p":$.$typeArray($.$snp.System.Net.IPAddress).$h},{"n":"port","p":655361},{"n":"requestCallback","p":14548993},{"n":"state","p":131073}],"n":"BeginConnect","o":"@$2","d":1762674,"h":158915552626,"f":16777217},{"r":57016321,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14548993},{"n":"state","p":131073}],"n":"BeginConnect","d":1762674,"h":163210519922,"f":16777217},{"r":65537,"n":"Close","d":1762674,"h":167505487218,"f":16777217},{"r":65537,"p":[{"n":"address","p":3064565},{"n":"port","p":655361}],"n":"Connect","o":"@$1","d":1762674,"h":171800454514,"f":16777217},{"r":65537,"p":[{"n":"ipAddresses","p":$.$typeArray($.$snp.System.Net.IPAddress).$h},{"n":"port","p":655361}],"n":"Connect","o":"@$2","d":1762674,"h":176095421810,"f":16777217},{"r":65537,"p":[{"n":"remoteEP","p":3326709}],"n":"Connect","o":"@$3","d":1762674,"h":180390389106,"f":16777217},{"r":65537,"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Connect","d":1762674,"h":184685356402,"f":16777217},{"r":133169153,"p":[{"n":"address","p":3064565},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$3","d":1762674,"h":188980323698,"f":16777217},{"r":135987201,"p":[{"n":"address","p":3064565},{"n":"port","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ConnectAsync","o":"@$2","d":1762674,"h":193275290994,"f":16777217},{"r":133169153,"p":[{"n":"addresses","p":$.$typeArray($.$snp.System.Net.IPAddress).$h},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$5","d":1762674,"h":197570258290,"f":16777217},{"r":135987201,"p":[{"n":"addresses","p":$.$typeArray($.$snp.System.Net.IPAddress).$h},{"n":"port","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ConnectAsync","o":"@$4","d":1762674,"h":201865225586,"f":16777217},{"r":133169153,"p":[{"n":"remoteEP","p":3326709}],"n":"ConnectAsync","o":"@$7","d":1762674,"h":206160192882,"f":16777217},{"r":135987201,"p":[{"n":"remoteEP","p":3326709},{"n":"cancellationToken","p":125829121}],"n":"ConnectAsync","o":"@$6","d":1762674,"h":210455160178,"f":16777217},{"r":133169153,"p":[{"n":"host","p":1310721},{"n":"port","p":655361}],"n":"ConnectAsync","o":"@$1","d":1762674,"h":214750127474,"f":16777217},{"r":135987201,"p":[{"n":"host","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ConnectAsync","d":1762674,"h":219045094770,"f":16777217},{"r":65537,"n":"Dispose","d":1762674,"h":223340062066,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1762674,"h":227635029362,"f":16777348},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndConnect","d":1762674,"h":231929996658,"f":16777217},{"r":517490,"n":"GetStream","d":1762674,"h":240519931250,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":1762674,"h":4296729970,"f":16777217},{"p":[{"n":"localEP","p":3326709}],"n":".ctor","o":"$ctor$3","d":1762674,"h":8591697266,"f":16777217},{"p":[{"n":"family","p":4506357}],"n":".ctor","o":"$ctor$4","d":1762674,"h":12886664562,"f":16777217},{"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$2","d":1762674,"h":17181631858,"f":16777217}],"i":[57540609],"h":1762674}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.TcpClient`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.TcpListener", ($self) => class TcpListener extends $.$$.System.Object
        {
            $ctor$1(/*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*System.Net.IPAddress*/ localaddr, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ get LocalEndpoint()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Server()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ AcceptSocket()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.Socket> */ AcceptSocketAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.Socket> */ AcceptSocketAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TcpClient */ AcceptTcpClient()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.TcpClient> */ AcceptTcpClientAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.TcpClient> */ AcceptTcpClientAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AllowNatTraversal(/*bool*/ allowed)
            {
            }
            /*System.IAsyncResult */ BeginAcceptSocket(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginAcceptTcpClient(/*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*System.Net.Sockets.TcpListener */ Create(/*int*/ port)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Dispose()
            {
            }
            /*System.Net.Sockets.Socket */ EndAcceptSocket(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TcpClient */ EndAcceptTcpClient(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Pending()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Start()
            {
            }
            /*void */ Start$1(/*int*/ backlog)
            {
            }
            /*void */ Stop()
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1828210;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":21476664690,"f":50331652},"n":"Active","d":1828210,"h":17181697394,"f":2097156},{"p":262145,"g":{"r":0,"d":0,"h":30066599282,"f":50331649},"s":{"r":0,"d":0,"h":34361566578,"f":83886081},"n":"ExclusiveAddressUse","d":1828210,"h":25771631986,"f":2097153},{"p":2605813,"g":{"r":0,"d":0,"h":42951501170,"f":50331649},"n":"LocalEndpoint","d":1828210,"h":38656533874,"f":2097153},{"p":910706,"g":{"r":0,"d":0,"h":51541435762,"f":50331649},"n":"Server","d":1828210,"h":47246468466,"f":2097153}],"m":[{"r":910706,"n":"AcceptSocket","d":1828210,"h":55836403058,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.Socket).$h,"n":"AcceptSocketAsync","d":1828210,"h":60131370354,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.Socket).$h,"p":[{"n":"cancellationToken","p":125829121}],"n":"AcceptSocketAsync","o":"@$1","d":1828210,"h":64426337650,"f":16777217},{"r":1762674,"n":"AcceptTcpClient","d":1828210,"h":68721304946,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.TcpClient).$h,"n":"AcceptTcpClientAsync","d":1828210,"h":73016272242,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.TcpClient).$h,"p":[{"n":"cancellationToken","p":125829121}],"n":"AcceptTcpClientAsync","o":"@$1","d":1828210,"h":77311239538,"f":16777217},{"r":65537,"p":[{"n":"allowed","p":262145}],"n":"AllowNatTraversal","d":1828210,"h":81606206834,"f":16777217,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"r":57016321,"p":[{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginAcceptSocket","d":1828210,"h":85901174130,"f":16777217},{"r":57016321,"p":[{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginAcceptTcpClient","d":1828210,"h":90196141426,"f":16777217},{"r":1828210,"p":[{"n":"port","p":655361}],"n":"Create","d":1828210,"h":94491108722,"f":16777249},{"r":65537,"n":"Dispose","d":1828210,"h":98786076018,"f":16777217},{"r":910706,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAcceptSocket","d":1828210,"h":103081043314,"f":16777217},{"r":1762674,"p":[{"n":"asyncResult","p":57016321}],"n":"EndAcceptTcpClient","d":1828210,"h":107376010610,"f":16777217},{"r":262145,"n":"Pending","d":1828210,"h":111670977906,"f":16777217},{"r":65537,"n":"Start","d":1828210,"h":115965945202,"f":16777217},{"r":65537,"p":[{"n":"backlog","p":655361}],"n":"Start","o":"@$1","d":1828210,"h":120260912498,"f":16777217},{"r":65537,"n":"Stop","d":1828210,"h":124555879794,"f":16777217}],"c":[{"p":[{"n":"port","p":655361}],"n":".ctor","o":"$ctor$1","d":1828210,"h":4296795506,"f":16777217,"a":[{"t":70909953,"c":8660844545,"a":[{"v":"This constructor has been deprecated. Use TcpListener(IPAddress localaddr, int port) instead.","t":1310721}]}]},{"p":[{"n":"localaddr","p":3064565},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$2","d":1828210,"h":8591762802,"f":16777217},{"p":[{"n":"localEP","p":3326709}],"n":".ctor","o":"$ctor$3","d":1828210,"h":12886730098,"f":16777217}],"i":[57540609],"h":1828210}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.TcpListener`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.UdpClient", ($self) => class UdpClient extends $.$$.System.Object
        {
            $ctor$1()
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$3(/*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$2(/*int*/ port, /*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$5(/*System.Net.IPEndPoint*/ localEP)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$6(/*System.Net.Sockets.AddressFamily*/ family)
            {
                super.$ctor();
                {
                }
                return this;
            }
            $ctor$4(/*string*/ hostname, /*int*/ port)
            {
                super.$ctor();
                {
                }
                return this;
            }
            /*bool */ get Active()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Active(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Available()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Client()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ set Client(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DontFragment()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DontFragment(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get EnableBroadcast()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set EnableBroadcast(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get ExclusiveAddressUse()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set ExclusiveAddressUse(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get MulticastLoopback()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set MulticastLoopback(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ get Ttl()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*short */ set Ttl(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ AllowNatTraversal(/*bool*/ allowed)
            {
            }
            /*System.IAsyncResult */ BeginReceive(/*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend(/*byte[]*/ datagram, /*int*/ bytes, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$2(/*byte[]*/ datagram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginSend$1(/*byte[]*/ datagram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port, /*System.AsyncCallback?*/ requestCallback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close()
            {
            }
            /*void */ Connect$1(/*System.Net.IPAddress*/ addr, /*int*/ port)
            {
            }
            /*void */ Connect$2(/*System.Net.IPEndPoint*/ endPoint)
            {
            }
            /*void */ Connect(/*string*/ hostname, /*int*/ port)
            {
            }
            /*void */ Dispose()
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*void */ DropMulticastGroup$1(/*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ DropMulticastGroup(/*System.Net.IPAddress*/ multicastAddr, /*int*/ ifindex)
            {
            }
            /*byte[] */ EndReceive(/*System.IAsyncResult*/ asyncResult, /*ref System.Net.IPEndPoint?*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ EndSend(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ JoinMulticastGroup(/*int*/ ifindex, /*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ JoinMulticastGroup$3(/*System.Net.IPAddress*/ multicastAddr)
            {
            }
            /*void */ JoinMulticastGroup$1(/*System.Net.IPAddress*/ multicastAddr, /*int*/ timeToLive)
            {
            }
            /*void */ JoinMulticastGroup$2(/*System.Net.IPAddress*/ multicastAddr, /*System.Net.IPAddress*/ localAddress)
            {
            }
            /*byte[] */ Receive(/*ref System.Net.IPEndPoint?*/ remoteEP)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<System.Net.Sockets.UdpReceiveResult> */ ReceiveAsync()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<System.Net.Sockets.UdpReceiveResult> */ ReceiveAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$2(/*byte[]*/ dgram, /*int*/ bytes)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$1(/*byte[]*/ dgram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send(/*byte[]*/ dgram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$5(/*System.ReadOnlySpan<byte>*/ datagram)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$4(/*System.ReadOnlySpan<byte>*/ datagram, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Send$3(/*System.ReadOnlySpan<byte>*/ datagram, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$2(/*byte[]*/ datagram, /*int*/ bytes)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync$1(/*byte[]*/ datagram, /*int*/ bytes, /*System.Net.IPEndPoint?*/ endPoint)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ SendAsync(/*byte[]*/ datagram, /*int*/ bytes, /*string?*/ hostname, /*int*/ port)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$5(/*System.ReadOnlyMemory<byte>*/ datagram, /*System.Net.IPEndPoint?*/ endPoint, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$3(/*System.ReadOnlyMemory<byte>*/ datagram, /*string?*/ hostname, /*int*/ port, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ SendAsync$4(/*System.ReadOnlyMemory<byte>*/ datagram, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            static $h = 1959282;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":131073,"p":[{"p":262145,"g":{"r":0,"d":0,"h":34361697650,"f":50331652},"s":{"r":0,"d":0,"h":38656664946,"f":83886084},"n":"Active","d":1959282,"h":30066730354,"f":2097156},{"p":655361,"g":{"r":0,"d":0,"h":47246599538,"f":50331649},"n":"Available","d":1959282,"h":42951632242,"f":2097153},{"p":910706,"g":{"r":0,"d":0,"h":55836534130,"f":50331649},"s":{"r":0,"d":0,"h":60131501426,"f":83886081},"n":"Client","d":1959282,"h":51541566834,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":68721436018,"f":50331649},"s":{"r":0,"d":0,"h":73016403314,"f":83886081},"n":"DontFragment","d":1959282,"h":64426468722,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":81606337906,"f":50331649},"s":{"r":0,"d":0,"h":85901305202,"f":83886081},"n":"EnableBroadcast","d":1959282,"h":77311370610,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":94491239794,"f":50331649},"s":{"r":0,"d":0,"h":98786207090,"f":83886081},"n":"ExclusiveAddressUse","d":1959282,"h":90196272498,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":107376141682,"f":50331649},"s":{"r":0,"d":0,"h":111671108978,"f":83886081},"n":"MulticastLoopback","d":1959282,"h":103081174386,"f":2097153},{"p":524289,"g":{"r":0,"d":0,"h":120261043570,"f":50331649},"s":{"r":0,"d":0,"h":124556010866,"f":83886081},"n":"Ttl","d":1959282,"h":115966076274,"f":2097153}],"m":[{"r":65537,"p":[{"n":"allowed","p":262145}],"n":"AllowNatTraversal","d":1959282,"h":128850978162,"f":16777217,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"r":57016321,"p":[{"n":"requestCallback","p":14548993},{"n":"state","p":131073}],"n":"BeginReceive","d":1959282,"h":133145945458,"f":16777217},{"r":57016321,"p":[{"n":"datagram","p":$.$typeArray($.$$.System.Byte).$h},{"n":"bytes","p":655361},{"n":"requestCallback","p":14548993},{"n":"state","p":131073}],"n":"BeginSend","d":1959282,"h":137440912754,"f":16777217},{"r":57016321,"p":[{"n":"datagram","p":$.$typeArray($.$$.System.Byte).$h},{"n":"bytes","p":655361},{"n":"endPoint","p":3326709},{"n":"requestCallback","p":14548993},{"n":"state","p":131073}],"n":"BeginSend","o":"@$2","d":1959282,"h":141735880050,"f":16777217},{"r":57016321,"p":[{"n":"datagram","p":$.$typeArray($.$$.System.Byte).$h},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361},{"n":"requestCallback","p":14548993},{"n":"state","p":131073}],"n":"BeginSend","o":"@$1","d":1959282,"h":146030847346,"f":16777217},{"r":65537,"n":"Close","d":1959282,"h":150325814642,"f":16777217},{"r":65537,"p":[{"n":"addr","p":3064565},{"n":"port","p":655361}],"n":"Connect","o":"@$1","d":1959282,"h":154620781938,"f":16777217},{"r":65537,"p":[{"n":"endPoint","p":3326709}],"n":"Connect","o":"@$2","d":1959282,"h":158915749234,"f":16777217},{"r":65537,"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Connect","d":1959282,"h":163210716530,"f":16777217},{"r":65537,"n":"Dispose","d":1959282,"h":167505683826,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":1959282,"h":171800651122,"f":16777348},{"r":65537,"p":[{"n":"multicastAddr","p":3064565}],"n":"DropMulticastGroup","o":"@$1","d":1959282,"h":176095618418,"f":16777217},{"r":65537,"p":[{"n":"multicastAddr","p":3064565},{"n":"ifindex","p":655361}],"n":"DropMulticastGroup","d":1959282,"h":180390585714,"f":16777217},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"asyncResult","p":57016321},{"n":"remoteEP","p":3326709,"f":4}],"n":"EndReceive","d":1959282,"h":184685553010,"f":16777217},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndSend","d":1959282,"h":188980520306,"f":16777217},{"r":65537,"p":[{"n":"ifindex","p":655361},{"n":"multicastAddr","p":3064565}],"n":"JoinMulticastGroup","d":1959282,"h":193275487602,"f":16777217},{"r":65537,"p":[{"n":"multicastAddr","p":3064565}],"n":"JoinMulticastGroup","o":"@$3","d":1959282,"h":197570454898,"f":16777217},{"r":65537,"p":[{"n":"multicastAddr","p":3064565},{"n":"timeToLive","p":655361}],"n":"JoinMulticastGroup","o":"@$1","d":1959282,"h":201865422194,"f":16777217},{"r":65537,"p":[{"n":"multicastAddr","p":3064565},{"n":"localAddress","p":3064565}],"n":"JoinMulticastGroup","o":"@$2","d":1959282,"h":206160389490,"f":16777217},{"r":$.$typeArray($.$$.System.Byte).$h,"p":[{"n":"remoteEP","p":3326709,"f":4}],"n":"Receive","d":1959282,"h":210455356786,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h,"n":"ReceiveAsync","d":1959282,"h":214750324082,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h,"p":[{"n":"cancellationToken","p":125829121}],"n":"ReceiveAsync","o":"@$1","d":1959282,"h":219045291378,"f":16777217},{"r":655361,"p":[{"n":"dgram","p":$.$typeArray($.$$.System.Byte).$h},{"n":"bytes","p":655361}],"n":"Send","o":"@$2","d":1959282,"h":223340258674,"f":16777217},{"r":655361,"p":[{"n":"dgram","p":$.$typeArray($.$$.System.Byte).$h},{"n":"bytes","p":655361},{"n":"endPoint","p":3326709}],"n":"Send","o":"@$1","d":1959282,"h":227635225970,"f":16777217},{"r":655361,"p":[{"n":"dgram","p":$.$typeArray($.$$.System.Byte).$h},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Send","d":1959282,"h":231930193266,"f":16777217},{"r":655361,"p":[{"n":"datagram","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"Send","o":"@$5","d":1959282,"h":236225160562,"f":16777217},{"r":655361,"p":[{"n":"datagram","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"endPoint","p":3326709}],"n":"Send","o":"@$4","d":1959282,"h":240520127858,"f":16777217},{"r":655361,"p":[{"n":"datagram","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"Send","o":"@$3","d":1959282,"h":244815095154,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"datagram","p":$.$typeArray($.$$.System.Byte).$h},{"n":"bytes","p":655361}],"n":"SendAsync","o":"@$2","d":1959282,"h":249110062450,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"datagram","p":$.$typeArray($.$$.System.Byte).$h},{"n":"bytes","p":655361},{"n":"endPoint","p":3326709}],"n":"SendAsync","o":"@$1","d":1959282,"h":253405029746,"f":16777217},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"datagram","p":$.$typeArray($.$$.System.Byte).$h},{"n":"bytes","p":655361},{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":"SendAsync","d":1959282,"h":257699997042,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"datagram","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"endPoint","p":3326709},{"n":"cancellationToken","p":125829121,"f":65}],"n":"SendAsync","o":"@$5","d":1959282,"h":261994964338,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"datagram","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"hostname","p":1310721},{"n":"port","p":655361},{"n":"cancellationToken","p":125829121,"f":65}],"n":"SendAsync","o":"@$3","d":1959282,"h":266289931634,"f":16777217},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"datagram","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"SendAsync","o":"@$4","d":1959282,"h":270584898930,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$1","d":1959282,"h":4296926578,"f":16777217},{"p":[{"n":"port","p":655361}],"n":".ctor","o":"$ctor$3","d":1959282,"h":8591893874,"f":16777217},{"p":[{"n":"port","p":655361},{"n":"family","p":4506357}],"n":".ctor","o":"$ctor$2","d":1959282,"h":12886861170,"f":16777217},{"p":[{"n":"localEP","p":3326709}],"n":".ctor","o":"$ctor$5","d":1959282,"h":17181828466,"f":16777217},{"p":[{"n":"family","p":4506357}],"n":".ctor","o":"$ctor$6","d":1959282,"h":21476795762,"f":16777217},{"p":[{"n":"hostname","p":1310721},{"n":"port","p":655361}],"n":".ctor","o":"$ctor$4","d":1959282,"h":25771763058,"f":16777217}],"i":[57540609],"h":1959282}; }
            static get $b() { return $.$$.System.Object; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.UdpClient`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketInformation", ($self) => class SocketInformation extends $.$$.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.Sockets.SocketInformationOptions */ get Options()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketInformationOptions */ set Options(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ get ProtocolInformation()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[] */ set ProtocolInformation(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 1172850;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":1238386,"g":{"r":0,"d":0,"h":17181042034,"f":50331649},"s":{"r":0,"d":0,"h":21476009330,"f":83886081},"n":"Options","d":1172850,"h":12886074738,"f":2097153},{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":30065943922,"f":50331649},"s":{"r":0,"d":0,"h":34360911218,"f":83886081},"n":"ProtocolInformation","d":1172850,"h":25770976626,"f":2097153}],"l":[{"t":131073,"n":"_dummy","d":1172850,"h":4296140146,"f":4194306},{"t":655361,"n":"_dummyPrimitive","d":1172850,"h":8591107442,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":1172850,"h":38655878514,"f":16777217}],"h":1172850}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketInformation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketReceiveFromResult", ($self) => class SocketReceiveFromResult extends $.$$.System.ValueType
        {
            /*int*/  get ReceivedBytes() { return this.$getField(0, 4); }
            /*int*/  set ReceivedBytes(value) { this.$setField(0, 4, value); }
            /*System.Net.EndPoint*/  get RemoteEndPoint() { return this.$getField(4, 4); }
            /*System.Net.EndPoint*/  set RemoteEndPoint(value) { this.$setField(4, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.ReceivedBytes = this.ReceivedBytes;
                copy.RemoteEndPoint = this.RemoteEndPoint;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.ReceivedBytes = 0;
                this.RemoteEndPoint = null;
            }
            static $h = 1434994;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":655361,"n":"ReceivedBytes","d":1434994,"h":4296402290,"f":4194305},{"t":2605813,"n":"RemoteEndPoint","d":1434994,"h":8591369586,"f":4194305}],"c":[{"n":".ctor","o":"$ctor$2","d":1434994,"h":12886336882,"f":16777217}],"h":1434994}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketReceiveFromResult`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketReceiveMessageFromResult", ($self) => class SocketReceiveMessageFromResult extends $.$$.System.ValueType
        {
            /*System.Net.Sockets.IPPacketInformation*/  get PacketInformation() { return this.$getField(0, 8); }
            /*System.Net.Sockets.IPPacketInformation*/  set PacketInformation(value) { this.$setField(0, 8, value); }
            /*int*/  get ReceivedBytes() { return this.$getField(8, 4); }
            /*int*/  set ReceivedBytes(value) { this.$setField(8, 4, value); }
            /*System.Net.EndPoint*/  get RemoteEndPoint() { return this.$getField(12, 4); }
            /*System.Net.EndPoint*/  set RemoteEndPoint(value) { this.$setField(12, 4, value); }
            /*System.Net.Sockets.SocketFlags*/  get SocketFlags() { return this.$getField(16, 4); }
            /*System.Net.Sockets.SocketFlags*/  set SocketFlags(value) { this.$setField(16, 4, value); }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy.PacketInformation = this.PacketInformation.Clone();
                copy.ReceivedBytes = this.ReceivedBytes;
                copy.RemoteEndPoint = this.RemoteEndPoint;
                copy.SocketFlags = this.SocketFlags;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this.PacketInformation = $.$default($.$sns.System.Net.Sockets.IPPacketInformation);
                this.ReceivedBytes = 0;
                this.RemoteEndPoint = null;
                this.SocketFlags = 0;
            }
            static $h = 1500530;
            static $z = 20;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"l":[{"t":189810,"n":"PacketInformation","d":1500530,"h":4296467826,"f":4194305},{"t":655361,"n":"ReceivedBytes","d":1500530,"h":8591435122,"f":4194305},{"t":2605813,"n":"RemoteEndPoint","d":1500530,"h":12886402418,"f":4194305},{"t":1107314,"n":"SocketFlags","d":1500530,"h":17181369714,"f":4194305}],"c":[{"n":".ctor","o":"$ctor$2","d":1500530,"h":21476337010,"f":16777217}],"h":1500530}; }
            static get $b() { return $.$$.System.ValueType; }
            static get $fullName() { return `System.Net.Sockets.SocketReceiveMessageFromResult`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.UnixDomainSocketEndPoint", ($self) => class UnixDomainSocketEndPoint extends $.$snp.System.Net.EndPoint
        {
            $ctor$2(/*string*/ path)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Sockets.AddressFamily */ get AddressFamily()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint */ Create(/*System.Net.SocketAddress*/ socketAddress)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.GetHashCode.apply(this, arguments); }
            /*System.Net.SocketAddress */ Serialize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*string */ ToString()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*string */ ToString() { return $.$sns.System.Net.Sockets.UnixDomainSocketEndPoint.ToString.apply(this, arguments); }
            static $h = 2090354;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":2605813,"p":[{"p":4506357,"g":{"r":0,"d":0,"h":12886992242,"f":50364417},"n":"AddressFamily","d":2090354,"h":8592024946,"f":2129921}],"m":[{"r":2605813,"p":[{"n":"socketAddress","p":4375285}],"n":"Create","d":2090354,"h":17181959538,"f":16809985},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":2090354,"h":21476926834,"f":16809985},{"r":655361,"n":"GetHashCode","d":2090354,"h":25771894130,"f":16809985},{"r":4375285,"n":"Serialize","d":2090354,"h":30066861426,"f":16809985},{"r":1310721,"n":"ToString","d":2090354,"h":34361828722,"f":16809985}],"c":[{"p":[{"n":"path","p":1310721}],"n":".ctor","o":"$ctor$2","d":2090354,"h":4297057650,"f":16777217}],"h":2090354}; }
            static get $b() { return $.$snp.System.Net.EndPoint; }
            static get $fullName() { return `System.Net.Sockets.UnixDomainSocketEndPoint`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IPPacketInformation", ($self) => class IPPacketInformation extends $.$$.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            /*System.Net.IPAddress */ get Address()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Interface()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Sockets.IPPacketInformation*/ other)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ comparand)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sns.System.Net.Sockets.IPPacketInformation.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.IPPacketInformation.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Sockets.IPPacketInformation*/ packetInformation1, /*System.Net.Sockets.IPPacketInformation*/ packetInformation2)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Sockets.IPPacketInformation*/ packetInformation1, /*System.Net.Sockets.IPPacketInformation*/ packetInformation2)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IEquatable<System.Net.Sockets.IPPacketInformation>.Equals(System.Net.Sockets.IPPacketInformation)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 189810;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":3064565,"g":{"r":0,"d":0,"h":17180058994,"f":50331649},"n":"Address","d":189810,"h":12885091698,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":25769993586,"f":50331649},"n":"Interface","d":189810,"h":21475026290,"f":2097153}],"m":[{"r":262145,"p":[{"n":"other","p":189810}],"n":"Equals","o":"@$2","d":189810,"h":30064960882,"f":16777217},{"r":262145,"p":[{"n":"comparand","p":131073}],"n":"Equals","o":"@$1","d":189810,"h":34359928178,"f":16809985},{"r":655361,"n":"GetHashCode","d":189810,"h":38654895474,"f":16809985}],"l":[{"t":131073,"n":"_dummy","d":189810,"h":4295157106,"f":4194306},{"t":655361,"n":"_dummyPrimitive","d":189810,"h":8590124402,"f":4194306}],"c":[{"n":".ctor","o":"$ctor$2","d":189810,"h":51539797362,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$sns.System.Net.Sockets.IPPacketInformation).$h],"h":189810}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sns.System.Net.Sockets.IPPacketInformation) ]; }
            static get $fullName() { return `System.Net.Sockets.IPPacketInformation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.UdpReceiveResult", ($self) => class UdpReceiveResult extends $.$$.System.ValueType
        {
            /*object*/  get _dummy() { return this.$getField(0, 4); }
            /*object*/  set _dummy(value) { this.$setField(0, 4, value); }
            /*int*/  get _dummyPrimitive() { return this.$getField(4, 4); }
            /*int*/  set _dummyPrimitive(value) { this.$setField(4, 4, value); }
            $ctor$3(/*byte[]*/ buffer, /*System.Net.IPEndPoint*/ remoteEndPoint)
            {
                super.$ctor$1();
                {
                    throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
                }
                return this;
            }
            /*byte[] */ get Buffer()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.IPEndPoint */ get RemoteEndPoint()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ Equals$2(/*System.Net.Sockets.UdpReceiveResult*/ other)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static/*conventional*/ /*bool */ Equals$1(/*object?*/ obj)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*bool */ Equals$1() { return $.$sns.System.Net.Sockets.UdpReceiveResult.Equals$1.apply(this, arguments); }
            static/*conventional*/ /*int */ GetHashCode()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Static convention instance redirect
            /*int */ GetHashCode() { return $.$sns.System.Net.Sockets.UdpReceiveResult.GetHashCode.apply(this, arguments); }
            static /*bool */ op_Equality(/*System.Net.Sockets.UdpReceiveResult*/ left, /*System.Net.Sockets.UdpReceiveResult*/ right)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static /*bool */ op_Inequality(/*System.Net.Sockets.UdpReceiveResult*/ left, /*System.Net.Sockets.UdpReceiveResult*/ right)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            //Generated interface implemetation for System.IEquatable<System.Net.Sockets.UdpReceiveResult>.Equals(System.Net.Sockets.UdpReceiveResult)
            System$IEquatable$$$Equals()
            {
                return this.Equals$2(...arguments);
            }
            //default value type constructor
            $ctor$2()
            {
                return this;
            }
            Clone($copy)
            {
                let copy = $copy ?? new this.constructor();
                copy._dummy = this._dummy;
                copy._dummyPrimitive = this._dummyPrimitive;
                return copy;
            }
            //default member initializer
            constructor()
            {
                super();
                this._dummy = null;
                this._dummyPrimitive = 0;
            }
            static $h = 2024818;
            static $z = 8;
            static $f = 0b1010000001;
            static $k = 2;
            static $$md;
            static get $md() { return this.$$md ??= {"b":196609,"p":[{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":21476861298,"f":50331649},"n":"Buffer","d":2024818,"h":17181894002,"f":2097153},{"p":3326709,"g":{"r":0,"d":0,"h":30066795890,"f":50331649},"n":"RemoteEndPoint","d":2024818,"h":25771828594,"f":2097153}],"m":[{"r":262145,"p":[{"n":"other","p":2024818}],"n":"Equals","o":"@$2","d":2024818,"h":34361763186,"f":16777217},{"r":262145,"p":[{"n":"obj","p":131073}],"n":"Equals","o":"@$1","d":2024818,"h":38656730482,"f":16809985},{"r":655361,"n":"GetHashCode","d":2024818,"h":42951697778,"f":16809985}],"l":[{"t":131073,"n":"_dummy","d":2024818,"h":4296992114,"f":4194306},{"t":655361,"n":"_dummyPrimitive","d":2024818,"h":8591959410,"f":4194306}],"c":[{"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"remoteEndPoint","p":3326709}],"n":".ctor","o":"$ctor$3","d":2024818,"h":12886926706,"f":16777217},{"n":".ctor","o":"$ctor$2","d":2024818,"h":55836599666,"f":16777217}],"i":[$.$$.System.IEquatable$$($.$sns.System.Net.Sockets.UdpReceiveResult).$h],"h":2024818}; }
            static get $b() { return $.$$.System.ValueType; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IEquatable$$($.$sns.System.Net.Sockets.UdpReceiveResult) ]; }
            static get $fullName() { return `System.Net.Sockets.UdpReceiveResult`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.NetworkStream", ($self) => class NetworkStream extends $.$$.System.IO.Stream
        {
            $ctor$6(/*System.Net.Sockets.Socket*/ socket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$3(/*System.Net.Sockets.Socket*/ socket, /*bool*/ ownsSocket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$5(/*System.Net.Sockets.Socket*/ socket, /*System.IO.FileAccess*/ access)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            $ctor$4(/*System.Net.Sockets.Socket*/ socket, /*System.IO.FileAccess*/ access, /*bool*/ ownsSocket)
            {
                super.$ctor$2();
                {
                }
                return this;
            }
            /*bool */ get CanRead()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanSeek()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get CanWrite()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DataAvailable()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Length()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ get Position()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ set Position(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Readable()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Readable(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get ReadTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set ReadTimeout(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket */ get Socket()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get Writeable()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set Writeable(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get WriteTimeout()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set WriteTimeout(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginRead(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.IAsyncResult */ BeginWrite(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.AsyncCallback?*/ callback, /*object?*/ state)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ Close$1(/*int*/ timeout)
            {
            }
            /*void */ Close$2(/*System.TimeSpan*/ timeout)
            {
            }
            /*void */ Dispose$1(/*bool*/ disposing)
            {
            }
            /*int */ EndRead(/*System.IAsyncResult*/ asyncResult)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ EndWrite(/*System.IAsyncResult*/ asyncResult)
            {
            }
            $dtor()
            {
            }
            /*void */ Flush()
            {
            }
            /*System.Threading.Tasks.Task */ FlushAsync$1(/*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ Read$1(/*System.Span<byte>*/ buffer)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.Task<int> */ ReadAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask<int> */ ReadAsync$2(/*System.Memory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ ReadByte()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*long */ Seek(/*long*/ offset, /*System.IO.SeekOrigin*/ origin)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ SetLength(/*long*/ value)
            {
            }
            /*void */ Write(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ Write$1(/*System.ReadOnlySpan<byte>*/ buffer)
            {
            }
            /*System.Threading.Tasks.Task */ WriteAsync(/*byte[]*/ buffer, /*int*/ offset, /*int*/ count, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Threading.Tasks.ValueTask */ WriteAsync$2(/*System.ReadOnlyMemory<byte>*/ buffer, /*System.Threading.CancellationToken*/ cancellationToken)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*void */ WriteByte(/*byte*/ value)
            {
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 517490;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":62193665,"p":[{"p":262145,"g":{"r":0,"d":0,"h":25770321266,"f":50364417},"n":"CanRead","d":517490,"h":21475353970,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":34360255858,"f":50364417},"n":"CanSeek","d":517490,"h":30065288562,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":42950190450,"f":50364417},"n":"CanTimeout","d":517490,"h":38655223154,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":51540125042,"f":50364417},"n":"CanWrite","d":517490,"h":47245157746,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":60130059634,"f":50331777},"n":"DataAvailable","d":517490,"h":55835092338,"f":2097281},{"p":917505,"g":{"r":0,"d":0,"h":68719994226,"f":50364417},"n":"Length","d":517490,"h":64425026930,"f":2129921},{"p":917505,"g":{"r":0,"d":0,"h":77309928818,"f":50364417},"s":{"r":0,"d":0,"h":81604896114,"f":83918849},"n":"Position","d":517490,"h":73014961522,"f":2129921},{"p":262145,"g":{"r":0,"d":0,"h":90194830706,"f":50331652},"s":{"r":0,"d":0,"h":94489798002,"f":83886084},"n":"Readable","d":517490,"h":85899863410,"f":2097156},{"p":655361,"g":{"r":0,"d":0,"h":103079732594,"f":50364417},"s":{"r":0,"d":0,"h":107374699890,"f":83918849},"n":"ReadTimeout","d":517490,"h":98784765298,"f":2129921},{"p":910706,"g":{"r":0,"d":0,"h":115964634482,"f":50331649},"n":"Socket","d":517490,"h":111669667186,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":124554569074,"f":50331652},"s":{"r":0,"d":0,"h":128849536370,"f":83886084},"n":"Writeable","d":517490,"h":120259601778,"f":2097156},{"p":655361,"g":{"r":0,"d":0,"h":137439470962,"f":50364417},"s":{"r":0,"d":0,"h":141734438258,"f":83918849},"n":"WriteTimeout","d":517490,"h":133144503666,"f":2129921}],"m":[{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginRead","d":517490,"h":146029405554,"f":16809985},{"r":57016321,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"callback","p":14548993},{"n":"state","p":131073}],"n":"BeginWrite","d":517490,"h":150324372850,"f":16809985},{"r":65537,"p":[{"n":"timeout","p":655361}],"n":"Close","o":"@$1","d":517490,"h":154619340146,"f":16777217},{"r":65537,"p":[{"n":"timeout","p":140574721}],"n":"Close","o":"@$2","d":517490,"h":158914307442,"f":16777217},{"r":65537,"p":[{"n":"disposing","p":262145}],"n":"Dispose","o":"@$1","d":517490,"h":163209274738,"f":16809988},{"r":655361,"p":[{"n":"asyncResult","p":57016321}],"n":"EndRead","d":517490,"h":167504242034,"f":16809985},{"r":65537,"p":[{"n":"asyncResult","p":57016321}],"n":"EndWrite","d":517490,"h":171799209330,"f":16809985},{"r":65537,"n":"Flush","d":517490,"h":180389143922,"f":16809985},{"r":133169153,"p":[{"n":"cancellationToken","p":125829121}],"n":"FlushAsync","o":"@$1","d":517490,"h":184684111218,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Read","d":517490,"h":188979078514,"f":16809985},{"r":655361,"p":[{"n":"buffer","p":$.$$.System.Span$$($.$$.System.Byte).$h}],"n":"Read","o":"@$1","d":517490,"h":193274045810,"f":16809985},{"r":$.$$.System.Threading.Tasks.Task$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"ReadAsync","d":517490,"h":197569013106,"f":16809985},{"r":$.$$.System.Threading.Tasks.ValueTask$$($.$$.System.Int32).$h,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"ReadAsync","o":"@$2","d":517490,"h":201863980402,"f":16809985},{"r":655361,"n":"ReadByte","d":517490,"h":206158947698,"f":16809985},{"r":917505,"p":[{"n":"offset","p":917505},{"n":"origin","p":61734913}],"n":"Seek","d":517490,"h":210453914994,"f":16809985},{"r":65537,"p":[{"n":"value","p":917505}],"n":"SetLength","d":517490,"h":214748882290,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"Write","d":517490,"h":219043849586,"f":16809985},{"r":65537,"p":[{"n":"buffer","p":$.$$.System.ReadOnlySpan$$($.$$.System.Byte).$h}],"n":"Write","o":"@$1","d":517490,"h":223338816882,"f":16809985},{"r":133169153,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361},{"n":"cancellationToken","p":125829121}],"n":"WriteAsync","d":517490,"h":227633784178,"f":16809985},{"r":135987201,"p":[{"n":"buffer","p":$.$$.System.ReadOnlyMemory$$($.$$.System.Byte).$h},{"n":"cancellationToken","p":125829121,"f":65}],"n":"WriteAsync","o":"@$2","d":517490,"h":231928751474,"f":16809985},{"r":65537,"p":[{"n":"value","p":393217}],"n":"WriteByte","d":517490,"h":236223718770,"f":16809985}],"c":[{"p":[{"n":"socket","p":910706}],"n":".ctor","o":"$ctor$6","d":517490,"h":4295484786,"f":16777217},{"p":[{"n":"socket","p":910706},{"n":"ownsSocket","p":262145}],"n":".ctor","o":"$ctor$3","d":517490,"h":8590452082,"f":16777217},{"p":[{"n":"socket","p":910706},{"n":"access","p":59768833}],"n":".ctor","o":"$ctor$5","d":517490,"h":12885419378,"f":16777217},{"p":[{"n":"socket","p":910706},{"n":"access","p":59768833},{"n":"ownsSocket","p":262145}],"n":".ctor","o":"$ctor$4","d":517490,"h":17180386674,"f":16777217}],"i":[57540609,56950785],"h":517490}; }
            static get $b() { return $.$$.System.IO.Stream; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable, $.$$.System.IAsyncDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.NetworkStream`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IOControlCode", ($self) => class IOControlCode extends $.$$.System.Enum
        {
            static EnableCircularQueuing = 671088642n;
            static Flush = 671088644n;
            static AddressListChange = 671088663n;
            static DataToRead = 1074030207n;
            static OobDataRead = 1074033415n;
            static GetBroadcastAddress = 1207959557n;
            static AddressListQuery = 1207959574n;
            static QueryTargetPnpHandle = 1207959576n;
            static AsyncIO = 2147772029n;
            static NonBlockingIO = 2147772030n;
            static AssociateHandle = 2281701377n;
            static MultipointLoopback = 2281701385n;
            static MulticastScope = 2281701386n;
            static SetQos = 2281701387n;
            static SetGroupQos = 2281701388n;
            static RoutingInterfaceChange = 2281701397n;
            static NamespaceChange = 2281701401n;
            static ReceiveAll = 2550136833n;
            static ReceiveAllMulticast = 2550136834n;
            static ReceiveAllIgmpMulticast = 2550136835n;
            static KeepAliveValues = 2550136836n;
            static AbsorbRouterAlert = 2550136837n;
            static UnicastInterface = 2550136838n;
            static LimitBroadcasts = 2550136839n;
            static BindToInterface = 2550136840n;
            static MulticastInterface = 2550136841n;
            static AddMulticastGroupOnInterface = 2550136842n;
            static DeleteMulticastGroupFromInterface = 2550136843n;
            static GetExtensionFunctionPointer = 3355443206n;
            static GetQos = 3355443207n;
            static GetGroupQos = 3355443208n;
            static TranslateHandle = 3355443213n;
            static RoutingInterfaceQuery = 3355443220n;
            static AddressListSort = 3355443225n;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "EnableCircularQueuing": 671088642n,
                    "Flush": 671088644n,
                    "AddressListChange": 671088663n,
                    "DataToRead": 1074030207n,
                    "OobDataRead": 1074033415n,
                    "GetBroadcastAddress": 1207959557n,
                    "AddressListQuery": 1207959574n,
                    "QueryTargetPnpHandle": 1207959576n,
                    "AsyncIO": 2147772029n,
                    "NonBlockingIO": 2147772030n,
                    "AssociateHandle": 2281701377n,
                    "MultipointLoopback": 2281701385n,
                    "MulticastScope": 2281701386n,
                    "SetQos": 2281701387n,
                    "SetGroupQos": 2281701388n,
                    "RoutingInterfaceChange": 2281701397n,
                    "NamespaceChange": 2281701401n,
                    "ReceiveAll": 2550136833n,
                    "ReceiveAllMulticast": 2550136834n,
                    "ReceiveAllIgmpMulticast": 2550136835n,
                    "KeepAliveValues": 2550136836n,
                    "AbsorbRouterAlert": 2550136837n,
                    "UnicastInterface": 2550136838n,
                    "LimitBroadcasts": 2550136839n,
                    "BindToInterface": 2550136840n,
                    "MulticastInterface": 2550136841n,
                    "AddMulticastGroupOnInterface": 2550136842n,
                    "DeleteMulticastGroupFromInterface": 2550136843n,
                    "GetExtensionFunctionPointer": 3355443206n,
                    "GetQos": 3355443207n,
                    "GetGroupQos": 3355443208n,
                    "TranslateHandle": 3355443213n,
                    "RoutingInterfaceQuery": 3355443220n,
                    "AddressListSort": 3355443225n
                };
            }
            static $h = 124274;
            static $z = 8;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int64; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":917505,"l":[{"t":124274,"n":"EnableCircularQueuing","d":124274,"h":4295091570,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"Flush","d":124274,"h":8590058866,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"AddressListChange","d":124274,"h":12885026162,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"DataToRead","d":124274,"h":17179993458,"f":4194337},{"t":124274,"n":"OobDataRead","d":124274,"h":21474960754,"f":4194337},{"t":124274,"n":"GetBroadcastAddress","d":124274,"h":25769928050,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"AddressListQuery","d":124274,"h":30064895346,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"QueryTargetPnpHandle","d":124274,"h":34359862642,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"AsyncIO","d":124274,"h":38654829938,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"NonBlockingIO","d":124274,"h":42949797234,"f":4194337},{"t":124274,"n":"AssociateHandle","d":124274,"h":47244764530,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"MultipointLoopback","d":124274,"h":51539731826,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"MulticastScope","d":124274,"h":55834699122,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"SetQos","d":124274,"h":60129666418,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"SetGroupQos","d":124274,"h":64424633714,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"RoutingInterfaceChange","d":124274,"h":68719601010,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"NamespaceChange","d":124274,"h":73014568306,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"ReceiveAll","d":124274,"h":77309535602,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"ReceiveAllMulticast","d":124274,"h":81604502898,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"ReceiveAllIgmpMulticast","d":124274,"h":85899470194,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"KeepAliveValues","d":124274,"h":90194437490,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"AbsorbRouterAlert","d":124274,"h":94489404786,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"UnicastInterface","d":124274,"h":98784372082,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"LimitBroadcasts","d":124274,"h":103079339378,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"BindToInterface","d":124274,"h":107374306674,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"MulticastInterface","d":124274,"h":111669273970,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"AddMulticastGroupOnInterface","d":124274,"h":115964241266,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"DeleteMulticastGroupFromInterface","d":124274,"h":120259208562,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"GetExtensionFunctionPointer","d":124274,"h":124554175858,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"GetQos","d":124274,"h":128849143154,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"GetGroupQos","d":124274,"h":133144110450,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"TranslateHandle","d":124274,"h":137439077746,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"RoutingInterfaceQuery","d":124274,"h":141734045042,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":124274,"n":"AddressListSort","d":124274,"h":146029012338,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":124274,"h":150323979634,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":124274}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.IOControlCode`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.IPProtectionLevel", ($self) => class IPProtectionLevel extends $.$$.System.Enum
        {
            static Unspecified = -1;
            static Unrestricted = 10;
            static EdgeRestricted = 20;
            static Restricted = 30;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unspecified": -1n,
                    "Unrestricted": 10n,
                    "EdgeRestricted": 20n,
                    "Restricted": 30n
                };
            }
            static $h = 255346;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":255346,"n":"Unspecified","d":255346,"h":4295222642,"f":4194337},{"t":255346,"n":"Unrestricted","d":255346,"h":8590189938,"f":4194337},{"t":255346,"n":"EdgeRestricted","d":255346,"h":12885157234,"f":4194337},{"t":255346,"n":"Restricted","d":255346,"h":17180124530,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":255346,"h":21475091826,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":255346}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.IPProtectionLevel`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.ProtocolFamily", ($self) => class ProtocolFamily extends $.$$.System.Enum
        {
            static Unknown = -1;
            static Unspecified = 0;
            static Unix = 1;
            static InterNetwork = 2;
            static ImpLink = 3;
            static Pup = 4;
            static Chaos = 5;
            static Ipx = 6;
            static NS = 6;
            static Iso = 7;
            static Osi = 7;
            static Ecma = 8;
            static DataKit = 9;
            static Ccitt = 10;
            static Sna = 11;
            static DecNet = 12;
            static DataLink = 13;
            static Lat = 14;
            static HyperChannel = 15;
            static AppleTalk = 16;
            static NetBios = 17;
            static VoiceView = 18;
            static FireFox = 19;
            static Banyan = 21;
            static Atm = 22;
            static InterNetworkV6 = 23;
            static Cluster = 24;
            static Ieee12844 = 25;
            static Irda = 26;
            static NetworkDesigners = 28;
            static Max = 29;
            static Packet = 65536;
            static ControllerAreaNetwork = 65537;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "Unspecified": 0n,
                    "Unix": 1n,
                    "InterNetwork": 2n,
                    "ImpLink": 3n,
                    "Pup": 4n,
                    "Chaos": 5n,
                    "Ipx": 6n,
                    "NS": 6n,
                    "Iso": 7n,
                    "Osi": 7n,
                    "Ecma": 8n,
                    "DataKit": 9n,
                    "Ccitt": 10n,
                    "Sna": 11n,
                    "DecNet": 12n,
                    "DataLink": 13n,
                    "Lat": 14n,
                    "HyperChannel": 15n,
                    "AppleTalk": 16n,
                    "NetBios": 17n,
                    "VoiceView": 18n,
                    "FireFox": 19n,
                    "Banyan": 21n,
                    "Atm": 22n,
                    "InterNetworkV6": 23n,
                    "Cluster": 24n,
                    "Ieee12844": 25n,
                    "Irda": 26n,
                    "NetworkDesigners": 28n,
                    "Max": 29n,
                    "Packet": 65536n,
                    "ControllerAreaNetwork": 65537n
                };
            }
            static $h = 583026;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":583026,"n":"Unknown","d":583026,"h":4295550322,"f":4194337},{"t":583026,"n":"Unspecified","d":583026,"h":8590517618,"f":4194337},{"t":583026,"n":"Unix","d":583026,"h":12885484914,"f":4194337},{"t":583026,"n":"InterNetwork","d":583026,"h":17180452210,"f":4194337},{"t":583026,"n":"ImpLink","d":583026,"h":21475419506,"f":4194337},{"t":583026,"n":"Pup","d":583026,"h":25770386802,"f":4194337},{"t":583026,"n":"Chaos","d":583026,"h":30065354098,"f":4194337},{"t":583026,"n":"Ipx","d":583026,"h":34360321394,"f":4194337},{"t":583026,"n":"NS","d":583026,"h":38655288690,"f":4194337},{"t":583026,"n":"Iso","d":583026,"h":42950255986,"f":4194337},{"t":583026,"n":"Osi","d":583026,"h":47245223282,"f":4194337},{"t":583026,"n":"Ecma","d":583026,"h":51540190578,"f":4194337},{"t":583026,"n":"DataKit","d":583026,"h":55835157874,"f":4194337},{"t":583026,"n":"Ccitt","d":583026,"h":60130125170,"f":4194337},{"t":583026,"n":"Sna","d":583026,"h":64425092466,"f":4194337},{"t":583026,"n":"DecNet","d":583026,"h":68720059762,"f":4194337},{"t":583026,"n":"DataLink","d":583026,"h":73015027058,"f":4194337},{"t":583026,"n":"Lat","d":583026,"h":77309994354,"f":4194337},{"t":583026,"n":"HyperChannel","d":583026,"h":81604961650,"f":4194337},{"t":583026,"n":"AppleTalk","d":583026,"h":85899928946,"f":4194337},{"t":583026,"n":"NetBios","d":583026,"h":90194896242,"f":4194337},{"t":583026,"n":"VoiceView","d":583026,"h":94489863538,"f":4194337},{"t":583026,"n":"FireFox","d":583026,"h":98784830834,"f":4194337},{"t":583026,"n":"Banyan","d":583026,"h":103079798130,"f":4194337},{"t":583026,"n":"Atm","d":583026,"h":107374765426,"f":4194337},{"t":583026,"n":"InterNetworkV6","d":583026,"h":111669732722,"f":4194337},{"t":583026,"n":"Cluster","d":583026,"h":115964700018,"f":4194337},{"t":583026,"n":"Ieee12844","d":583026,"h":120259667314,"f":4194337},{"t":583026,"n":"Irda","d":583026,"h":124554634610,"f":4194337},{"t":583026,"n":"NetworkDesigners","d":583026,"h":128849601906,"f":4194337},{"t":583026,"n":"Max","d":583026,"h":133144569202,"f":4194337},{"t":583026,"n":"Packet","d":583026,"h":137439536498,"f":4194337},{"t":583026,"n":"ControllerAreaNetwork","d":583026,"h":141734503794,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":583026,"h":146029471090,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":583026}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.ProtocolFamily`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.ProtocolType", ($self) => class ProtocolType extends $.$$.System.Enum
        {
            static Unknown = -1;
            static IP = 0;
            static IPv6HopByHopOptions = 0;
            static Unspecified = 0;
            static Icmp = 1;
            static Igmp = 2;
            static Ggp = 3;
            static IPv4 = 4;
            static Tcp = 6;
            static Pup = 12;
            static Udp = 17;
            static Idp = 22;
            static IPv6 = 41;
            static IPv6RoutingHeader = 43;
            static IPv6FragmentHeader = 44;
            static IPSecEncapsulatingSecurityPayload = 50;
            static IPSecAuthenticationHeader = 51;
            static IcmpV6 = 58;
            static IPv6NoNextHeader = 59;
            static IPv6DestinationOptions = 60;
            static ND = 77;
            static Raw = 255;
            static Ipx = 1000;
            static Spx = 1256;
            static SpxII = 1257;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "IP": 0n,
                    "IPv6HopByHopOptions": 0n,
                    "Unspecified": 0n,
                    "Icmp": 1n,
                    "Igmp": 2n,
                    "Ggp": 3n,
                    "IPv4": 4n,
                    "Tcp": 6n,
                    "Pup": 12n,
                    "Udp": 17n,
                    "Idp": 22n,
                    "IPv6": 41n,
                    "IPv6RoutingHeader": 43n,
                    "IPv6FragmentHeader": 44n,
                    "IPSecEncapsulatingSecurityPayload": 50n,
                    "IPSecAuthenticationHeader": 51n,
                    "IcmpV6": 58n,
                    "IPv6NoNextHeader": 59n,
                    "IPv6DestinationOptions": 60n,
                    "ND": 77n,
                    "Raw": 255n,
                    "Ipx": 1000n,
                    "Spx": 1256n,
                    "SpxII": 1257n
                };
            }
            static $h = 648562;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":648562,"n":"Unknown","d":648562,"h":4295615858,"f":4194337},{"t":648562,"n":"IP","d":648562,"h":8590583154,"f":4194337},{"t":648562,"n":"IPv6HopByHopOptions","d":648562,"h":12885550450,"f":4194337},{"t":648562,"n":"Unspecified","d":648562,"h":17180517746,"f":4194337},{"t":648562,"n":"Icmp","d":648562,"h":21475485042,"f":4194337},{"t":648562,"n":"Igmp","d":648562,"h":25770452338,"f":4194337},{"t":648562,"n":"Ggp","d":648562,"h":30065419634,"f":4194337},{"t":648562,"n":"IPv4","d":648562,"h":34360386930,"f":4194337},{"t":648562,"n":"Tcp","d":648562,"h":38655354226,"f":4194337},{"t":648562,"n":"Pup","d":648562,"h":42950321522,"f":4194337},{"t":648562,"n":"Udp","d":648562,"h":47245288818,"f":4194337},{"t":648562,"n":"Idp","d":648562,"h":51540256114,"f":4194337},{"t":648562,"n":"IPv6","d":648562,"h":55835223410,"f":4194337},{"t":648562,"n":"IPv6RoutingHeader","d":648562,"h":60130190706,"f":4194337},{"t":648562,"n":"IPv6FragmentHeader","d":648562,"h":64425158002,"f":4194337},{"t":648562,"n":"IPSecEncapsulatingSecurityPayload","d":648562,"h":68720125298,"f":4194337},{"t":648562,"n":"IPSecAuthenticationHeader","d":648562,"h":73015092594,"f":4194337},{"t":648562,"n":"IcmpV6","d":648562,"h":77310059890,"f":4194337},{"t":648562,"n":"IPv6NoNextHeader","d":648562,"h":81605027186,"f":4194337},{"t":648562,"n":"IPv6DestinationOptions","d":648562,"h":85899994482,"f":4194337},{"t":648562,"n":"ND","d":648562,"h":90194961778,"f":4194337},{"t":648562,"n":"Raw","d":648562,"h":94489929074,"f":4194337},{"t":648562,"n":"Ipx","d":648562,"h":98784896370,"f":4194337},{"t":648562,"n":"Spx","d":648562,"h":103079863666,"f":4194337},{"t":648562,"n":"SpxII","d":648562,"h":107374830962,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":648562,"h":111669798258,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":648562}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.ProtocolType`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SelectMode", ($self) => class SelectMode extends $.$$.System.Enum
        {
            static SelectRead = 0;
            static SelectWrite = 1;
            static SelectError = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "SelectRead": 0n,
                    "SelectWrite": 1n,
                    "SelectError": 2n
                };
            }
            static $h = 779634;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":779634,"n":"SelectRead","d":779634,"h":4295746930,"f":4194337},{"t":779634,"n":"SelectWrite","d":779634,"h":8590714226,"f":4194337},{"t":779634,"n":"SelectError","d":779634,"h":12885681522,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":779634,"h":17180648818,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":779634}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SelectMode`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketAsyncOperation", ($self) => class SocketAsyncOperation extends $.$$.System.Enum
        {
            static None = 0;
            static Accept = 1;
            static Connect = 2;
            static Disconnect = 3;
            static Receive = 4;
            static ReceiveFrom = 5;
            static ReceiveMessageFrom = 6;
            static Send = 7;
            static SendPackets = 8;
            static SendTo = 9;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "Accept": 1n,
                    "Connect": 2n,
                    "Disconnect": 3n,
                    "Receive": 4n,
                    "ReceiveFrom": 5n,
                    "ReceiveMessageFrom": 6n,
                    "Send": 7n,
                    "SendPackets": 8n,
                    "SendTo": 9n
                };
            }
            static $h = 1041778;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1041778,"n":"None","d":1041778,"h":4296009074,"f":4194337},{"t":1041778,"n":"Accept","d":1041778,"h":8590976370,"f":4194337},{"t":1041778,"n":"Connect","d":1041778,"h":12885943666,"f":4194337},{"t":1041778,"n":"Disconnect","d":1041778,"h":17180910962,"f":4194337},{"t":1041778,"n":"Receive","d":1041778,"h":21475878258,"f":4194337},{"t":1041778,"n":"ReceiveFrom","d":1041778,"h":25770845554,"f":4194337},{"t":1041778,"n":"ReceiveMessageFrom","d":1041778,"h":30065812850,"f":4194337},{"t":1041778,"n":"Send","d":1041778,"h":34360780146,"f":4194337},{"t":1041778,"n":"SendPackets","d":1041778,"h":38655747442,"f":4194337},{"t":1041778,"n":"SendTo","d":1041778,"h":42950714738,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1041778,"h":47245682034,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1041778}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketAsyncOperation`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketFlags", ($self) => class SocketFlags extends $.$$.System.Enum
        {
            static None = 0;
            static OutOfBand = 1;
            static Peek = 2;
            static DontRoute = 4;
            static Truncated = 256;
            static ControlDataTruncated = 512;
            static Broadcast = 1024;
            static Multicast = 2048;
            static Partial = 32768;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "None": 0n,
                    "OutOfBand": 1n,
                    "Peek": 2n,
                    "DontRoute": 4n,
                    "Truncated": 256n,
                    "ControlDataTruncated": 512n,
                    "Broadcast": 1024n,
                    "Multicast": 2048n,
                    "Partial": 32768n
                };
            }
            static $h = 1107314;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1107314,"n":"None","d":1107314,"h":4296074610,"f":4194337},{"t":1107314,"n":"OutOfBand","d":1107314,"h":8591041906,"f":4194337},{"t":1107314,"n":"Peek","d":1107314,"h":12886009202,"f":4194337},{"t":1107314,"n":"DontRoute","d":1107314,"h":17180976498,"f":4194337},{"t":1107314,"n":"Truncated","d":1107314,"h":21475943794,"f":4194337},{"t":1107314,"n":"ControlDataTruncated","d":1107314,"h":25770911090,"f":4194337},{"t":1107314,"n":"Broadcast","d":1107314,"h":30065878386,"f":4194337},{"t":1107314,"n":"Multicast","d":1107314,"h":34360845682,"f":4194337},{"t":1107314,"n":"Partial","d":1107314,"h":38655812978,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1107314,"h":42950780274,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1107314,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketFlags`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketInformationOptions", ($self) => class SocketInformationOptions extends $.$$.System.Enum
        {
            static NonBlocking = 1;
            static Connected = 2;
            static Listening = 4;
            static UseOnlyOverlappedIO = 8;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "NonBlocking": 1n,
                    "Connected": 2n,
                    "Listening": 4n,
                    "UseOnlyOverlappedIO": 8n
                };
            }
            static $h = 1238386;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1238386,"n":"NonBlocking","d":1238386,"h":4296205682,"f":4194337},{"t":1238386,"n":"Connected","d":1238386,"h":8591172978,"f":4194337},{"t":1238386,"n":"Listening","d":1238386,"h":12886140274,"f":4194337},{"t":1238386,"n":"UseOnlyOverlappedIO","d":1238386,"h":17181107570,"f":4194337,"a":[{"t":33292289,"c":4328259585,"a":[{"v":1,"t":33357825}]},{"t":70909953,"c":8660844545,"a":[{"v":"SocketInformationOptions.UseOnlyOverlappedIO has been deprecated and is not supported.","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":1238386,"h":21476074866,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1238386,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketInformationOptions`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketOptionLevel", ($self) => class SocketOptionLevel extends $.$$.System.Enum
        {
            static IP = 0;
            static Tcp = 6;
            static Udp = 17;
            static IPv6 = 41;
            static Socket = 65535;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "IP": 0n,
                    "Tcp": 6n,
                    "Udp": 17n,
                    "IPv6": 41n,
                    "Socket": 65535n
                };
            }
            static $h = 1303922;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1303922,"n":"IP","d":1303922,"h":4296271218,"f":4194337},{"t":1303922,"n":"Tcp","d":1303922,"h":8591238514,"f":4194337},{"t":1303922,"n":"Udp","d":1303922,"h":12886205810,"f":4194337},{"t":1303922,"n":"IPv6","d":1303922,"h":17181173106,"f":4194337},{"t":1303922,"n":"Socket","d":1303922,"h":21476140402,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1303922,"h":25771107698,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1303922}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketOptionLevel`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketOptionName", ($self) => class SocketOptionName extends $.$$.System.Enum
        {
            static DontLinger = -129;
            static ExclusiveAddressUse = -5;
            static Debug = 1;
            static IPOptions = 1;
            static NoChecksum = 1;
            static NoDelay = 1;
            static AcceptConnection = 2;
            static BsdUrgent = 2;
            static Expedited = 2;
            static HeaderIncluded = 2;
            static TcpKeepAliveTime = 3;
            static TypeOfService = 3;
            static IpTimeToLive = 4;
            static ReuseAddress = 4;
            static KeepAlive = 8;
            static MulticastInterface = 9;
            static MulticastTimeToLive = 10;
            static MulticastLoopback = 11;
            static AddMembership = 12;
            static DropMembership = 13;
            static DontFragment = 14;
            static AddSourceMembership = 15;
            static FastOpen = 15;
            static DontRoute = 16;
            static DropSourceMembership = 16;
            static TcpKeepAliveRetryCount = 16;
            static BlockSource = 17;
            static TcpKeepAliveInterval = 17;
            static UnblockSource = 18;
            static PacketInformation = 19;
            static ChecksumCoverage = 20;
            static HopLimit = 21;
            static IPProtectionLevel = 23;
            static IPv6Only = 27;
            static Broadcast = 32;
            static UseLoopback = 64;
            static Linger = 128;
            static OutOfBandInline = 256;
            static SendBuffer = 4097;
            static ReceiveBuffer = 4098;
            static SendLowWater = 4099;
            static ReceiveLowWater = 4100;
            static SendTimeout = 4101;
            static ReceiveTimeout = 4102;
            static Error = 4103;
            static Type = 4104;
            static ReuseUnicastPort = 12295;
            static UpdateAcceptContext = 28683;
            static UpdateConnectContext = 28688;
            static MaxConnections = 2147483647;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "DontLinger": -129n,
                    "ExclusiveAddressUse": -5n,
                    "Debug": 1n,
                    "IPOptions": 1n,
                    "NoChecksum": 1n,
                    "NoDelay": 1n,
                    "AcceptConnection": 2n,
                    "BsdUrgent": 2n,
                    "Expedited": 2n,
                    "HeaderIncluded": 2n,
                    "TcpKeepAliveTime": 3n,
                    "TypeOfService": 3n,
                    "IpTimeToLive": 4n,
                    "ReuseAddress": 4n,
                    "KeepAlive": 8n,
                    "MulticastInterface": 9n,
                    "MulticastTimeToLive": 10n,
                    "MulticastLoopback": 11n,
                    "AddMembership": 12n,
                    "DropMembership": 13n,
                    "DontFragment": 14n,
                    "AddSourceMembership": 15n,
                    "FastOpen": 15n,
                    "DontRoute": 16n,
                    "DropSourceMembership": 16n,
                    "TcpKeepAliveRetryCount": 16n,
                    "BlockSource": 17n,
                    "TcpKeepAliveInterval": 17n,
                    "UnblockSource": 18n,
                    "PacketInformation": 19n,
                    "ChecksumCoverage": 20n,
                    "HopLimit": 21n,
                    "IPProtectionLevel": 23n,
                    "IPv6Only": 27n,
                    "Broadcast": 32n,
                    "UseLoopback": 64n,
                    "Linger": 128n,
                    "OutOfBandInline": 256n,
                    "SendBuffer": 4097n,
                    "ReceiveBuffer": 4098n,
                    "SendLowWater": 4099n,
                    "ReceiveLowWater": 4100n,
                    "SendTimeout": 4101n,
                    "ReceiveTimeout": 4102n,
                    "Error": 4103n,
                    "Type": 4104n,
                    "ReuseUnicastPort": 12295n,
                    "UpdateAcceptContext": 28683n,
                    "UpdateConnectContext": 28688n,
                    "MaxConnections": 2147483647n
                };
            }
            static $h = 1369458;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1369458,"n":"DontLinger","d":1369458,"h":4296336754,"f":4194337},{"t":1369458,"n":"ExclusiveAddressUse","d":1369458,"h":8591304050,"f":4194337},{"t":1369458,"n":"Debug","d":1369458,"h":12886271346,"f":4194337},{"t":1369458,"n":"IPOptions","d":1369458,"h":17181238642,"f":4194337},{"t":1369458,"n":"NoChecksum","d":1369458,"h":21476205938,"f":4194337},{"t":1369458,"n":"NoDelay","d":1369458,"h":25771173234,"f":4194337},{"t":1369458,"n":"AcceptConnection","d":1369458,"h":30066140530,"f":4194337},{"t":1369458,"n":"BsdUrgent","d":1369458,"h":34361107826,"f":4194337},{"t":1369458,"n":"Expedited","d":1369458,"h":38656075122,"f":4194337},{"t":1369458,"n":"HeaderIncluded","d":1369458,"h":42951042418,"f":4194337},{"t":1369458,"n":"TcpKeepAliveTime","d":1369458,"h":47246009714,"f":4194337},{"t":1369458,"n":"TypeOfService","d":1369458,"h":51540977010,"f":4194337},{"t":1369458,"n":"IpTimeToLive","d":1369458,"h":55835944306,"f":4194337},{"t":1369458,"n":"ReuseAddress","d":1369458,"h":60130911602,"f":4194337},{"t":1369458,"n":"KeepAlive","d":1369458,"h":64425878898,"f":4194337},{"t":1369458,"n":"MulticastInterface","d":1369458,"h":68720846194,"f":4194337},{"t":1369458,"n":"MulticastTimeToLive","d":1369458,"h":73015813490,"f":4194337},{"t":1369458,"n":"MulticastLoopback","d":1369458,"h":77310780786,"f":4194337},{"t":1369458,"n":"AddMembership","d":1369458,"h":81605748082,"f":4194337},{"t":1369458,"n":"DropMembership","d":1369458,"h":85900715378,"f":4194337},{"t":1369458,"n":"DontFragment","d":1369458,"h":90195682674,"f":4194337},{"t":1369458,"n":"AddSourceMembership","d":1369458,"h":94490649970,"f":4194337},{"t":1369458,"n":"FastOpen","d":1369458,"h":98785617266,"f":4194337},{"t":1369458,"n":"DontRoute","d":1369458,"h":103080584562,"f":4194337},{"t":1369458,"n":"DropSourceMembership","d":1369458,"h":107375551858,"f":4194337},{"t":1369458,"n":"TcpKeepAliveRetryCount","d":1369458,"h":111670519154,"f":4194337},{"t":1369458,"n":"BlockSource","d":1369458,"h":115965486450,"f":4194337},{"t":1369458,"n":"TcpKeepAliveInterval","d":1369458,"h":120260453746,"f":4194337},{"t":1369458,"n":"UnblockSource","d":1369458,"h":124555421042,"f":4194337},{"t":1369458,"n":"PacketInformation","d":1369458,"h":128850388338,"f":4194337},{"t":1369458,"n":"ChecksumCoverage","d":1369458,"h":133145355634,"f":4194337},{"t":1369458,"n":"HopLimit","d":1369458,"h":137440322930,"f":4194337},{"t":1369458,"n":"IPProtectionLevel","d":1369458,"h":141735290226,"f":4194337},{"t":1369458,"n":"IPv6Only","d":1369458,"h":146030257522,"f":4194337},{"t":1369458,"n":"Broadcast","d":1369458,"h":150325224818,"f":4194337},{"t":1369458,"n":"UseLoopback","d":1369458,"h":154620192114,"f":4194337},{"t":1369458,"n":"Linger","d":1369458,"h":158915159410,"f":4194337},{"t":1369458,"n":"OutOfBandInline","d":1369458,"h":163210126706,"f":4194337},{"t":1369458,"n":"SendBuffer","d":1369458,"h":167505094002,"f":4194337},{"t":1369458,"n":"ReceiveBuffer","d":1369458,"h":171800061298,"f":4194337},{"t":1369458,"n":"SendLowWater","d":1369458,"h":176095028594,"f":4194337},{"t":1369458,"n":"ReceiveLowWater","d":1369458,"h":180389995890,"f":4194337},{"t":1369458,"n":"SendTimeout","d":1369458,"h":184684963186,"f":4194337},{"t":1369458,"n":"ReceiveTimeout","d":1369458,"h":188979930482,"f":4194337},{"t":1369458,"n":"Error","d":1369458,"h":193274897778,"f":4194337},{"t":1369458,"n":"Type","d":1369458,"h":197569865074,"f":4194337},{"t":1369458,"n":"ReuseUnicastPort","d":1369458,"h":201864832370,"f":4194337},{"t":1369458,"n":"UpdateAcceptContext","d":1369458,"h":206159799666,"f":4194337},{"t":1369458,"n":"UpdateConnectContext","d":1369458,"h":210454766962,"f":4194337},{"t":1369458,"n":"MaxConnections","d":1369458,"h":214749734258,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1369458,"h":219044701554,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1369458}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketOptionName`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketShutdown", ($self) => class SocketShutdown extends $.$$.System.Enum
        {
            static Receive = 0;
            static Send = 1;
            static Both = 2;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Receive": 0n,
                    "Send": 1n,
                    "Both": 2n
                };
            }
            static $h = 1566066;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1566066,"n":"Receive","d":1566066,"h":4296533362,"f":4194337},{"t":1566066,"n":"Send","d":1566066,"h":8591500658,"f":4194337},{"t":1566066,"n":"Both","d":1566066,"h":12886467954,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1566066,"h":17181435250,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1566066}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketShutdown`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.SocketType", ($self) => class SocketType extends $.$$.System.Enum
        {
            static Unknown = -1;
            static Stream = 1;
            static Dgram = 2;
            static Raw = 3;
            static Rdm = 4;
            static Seqpacket = 5;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "Unknown": -1n,
                    "Stream": 1n,
                    "Dgram": 2n,
                    "Raw": 3n,
                    "Rdm": 4n,
                    "Seqpacket": 5n
                };
            }
            static $h = 1697138;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1697138,"n":"Unknown","d":1697138,"h":4296664434,"f":4194337},{"t":1697138,"n":"Stream","d":1697138,"h":8591631730,"f":4194337},{"t":1697138,"n":"Dgram","d":1697138,"h":12886599026,"f":4194337},{"t":1697138,"n":"Raw","d":1697138,"h":17181566322,"f":4194337},{"t":1697138,"n":"Rdm","d":1697138,"h":21476533618,"f":4194337},{"t":1697138,"n":"Seqpacket","d":1697138,"h":25771500914,"f":4194337}],"c":[{"n":".ctor","o":"$ctor$3","d":1697138,"h":30066468210,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1697138}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.SocketType`; }
        });
        
        $asm.$str("$sns.System.Net.Sockets.TransmitFileOptions", ($self) => class TransmitFileOptions extends $.$$.System.Enum
        {
            static UseDefaultWorkerThread = 0;
            static Disconnect = 1;
            static ReuseSocket = 2;
            static WriteBehind = 4;
            static UseSystemThread = 16;
            static UseKernelApc = 32;
            static $map;
            static get Map()
            {
                return this.$map ??= 
                {
                    "UseDefaultWorkerThread": 0n,
                    "Disconnect": 1n,
                    "ReuseSocket": 2n,
                    "WriteBehind": 4n,
                    "UseSystemThread": 16n,
                    "UseKernelApc": 32n
                };
            }
            static $h = 1893746;
            static $z = 4;
            static $f = 0b100000011010001001;
            static $k = 4;
            static get $eut() { return $.$$.System.Int32; }
            static $$md;
            static get $md() { return this.$$md ??= {"b":1048577,"u":655361,"l":[{"t":1893746,"n":"UseDefaultWorkerThread","d":1893746,"h":4296861042,"f":4194337},{"t":1893746,"n":"Disconnect","d":1893746,"h":8591828338,"f":4194337},{"t":1893746,"n":"ReuseSocket","d":1893746,"h":12886795634,"f":4194337},{"t":1893746,"n":"WriteBehind","d":1893746,"h":17181762930,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":1893746,"n":"UseSystemThread","d":1893746,"h":21476730226,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]},{"t":1893746,"n":"UseKernelApc","d":1893746,"h":25771697522,"f":4194337,"a":[{"t":114819073,"c":4409786369,"a":[{"v":"windows","t":1310721}]}]}],"c":[{"n":".ctor","o":"$ctor$3","d":1893746,"h":30066664818,"f":16777217}],"i":[57278465,63832065,57737217,57409537],"h":1893746,"a":[{"t":47710209,"c":4342677505}]}; }
            static get $b() { return $.$$.System.Enum; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IComparable, $.$$.System.ISpanFormattable, $.$$.System.IFormattable, $.$$.System.IConvertible ]; }
            static get $fullName() { return `System.Net.Sockets.TransmitFileOptions`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SafeSocketHandle", ($self) => class SafeSocketHandle extends $.$$.Microsoft.Win32.SafeHandles.SafeHandleMinusOneIsInvalid
        {
            $ctor$4()
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            $ctor$5(/*nint*/ preexistingHandle, /*bool*/ ownsHandle)
            {
                super.$ctor$3(false);
                {
                }
                return this;
            }
            /*bool */ get IsInvalid()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ ReleaseHandle()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            static $h = 714098;
            static $f = 0b10010001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":7405569,"p":[{"p":262145,"g":{"r":0,"d":0,"h":17180583282,"f":50364417},"n":"IsInvalid","d":714098,"h":12885615986,"f":2129921}],"m":[{"r":262145,"n":"ReleaseHandle","d":714098,"h":21475550578,"f":16809988}],"c":[{"n":".ctor","o":"$ctor$4","d":714098,"h":4295681394,"f":16777217},{"p":[{"n":"preexistingHandle","p":786433},{"n":"ownsHandle","p":262145}],"n":".ctor","o":"$ctor$5","d":714098,"h":8590648690,"f":16777217}],"i":[57540609],"h":714098}; }
            static get $b() { return $.$$.Microsoft.Win32.SafeHandles.SafeHandleMinusOneIsInvalid; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.SafeSocketHandle`; }
        });
        
        $asm.$cls("$sns.System.Net.Sockets.SocketAsyncEventArgs", ($self) => class SocketAsyncEventArgs extends $.$$.System.EventArgs
        {
            $ctor$2()
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            $ctor$3(/*bool*/ unsafeSuppressExecutionContextFlow)
            {
                super.$ctor$1();
                {
                }
                return this;
            }
            /*System.Net.Sockets.Socket? */ get AcceptSocket()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket? */ set AcceptSocket(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*byte[]? */ get Buffer()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IList<System.ArraySegment<byte>>? */ get BufferList()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Collections.Generic.IList<System.ArraySegment<byte>>? */ set BufferList(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get BytesTransferred()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Exception? */ get ConnectByNameError()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.Socket? */ get ConnectSocket()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Count()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ get DisconnectReuseSocket()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*bool */ set DisconnectReuseSocket(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketAsyncOperation */ get LastOperation()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Memory<byte> */ get MemoryBuffer()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get Offset()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.IPPacketInformation */ get ReceiveMessageFromPacketInfo()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ get RemoteEndPoint()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.EndPoint? */ set RemoteEndPoint(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SendPacketsElement[]? */ get SendPacketsElements()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SendPacketsElement[]? */ set SendPacketsElements(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TransmitFileOptions */ get SendPacketsFlags()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.TransmitFileOptions */ set SendPacketsFlags(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ get SendPacketsSendSize()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*int */ set SendPacketsSendSize(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketError */ get SocketError()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketError */ set SocketError(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketFlags */ get SocketFlags()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.Net.Sockets.SocketFlags */ set SocketFlags(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ get UserToken()
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*object? */ set UserToken(value)
            {
                throw new $.$$.System.PlatformNotSupportedException().$ctor$13();
            }
            /*System.EventHandler<System.Net.Sockets.SocketAsyncEventArgs>?*/ add_Completed(value)
            {
            }
            /*System.EventHandler<System.Net.Sockets.SocketAsyncEventArgs>?*/ remove_Completed(value)
            {
            }
            /*void */ Dispose()
            {
            }
            $dtor()
            {
            }
            /*void */ OnCompleted(/*System.Net.Sockets.SocketAsyncEventArgs*/ e)
            {
            }
            /*void */ SetBuffer(/*byte[]?*/ buffer, /*int*/ offset, /*int*/ count)
            {
            }
            /*void */ SetBuffer$1(/*int*/ offset, /*int*/ count)
            {
            }
            /*void */ SetBuffer$2(/*System.Memory<byte>*/ buffer)
            {
            }
            //Generated interface implemetation for System.IDisposable.Dispose()
            System$IDisposable$Dispose()
            {
                return this.Dispose(...arguments);
            }
            //default member initializer
            constructor()
            {
                super();
                $.$finalizer(this);
            }
            static $h = 976242;
            static $f = 0b10001;
            static $k = 1;
            static $$md;
            static get $md() { return this.$$md ??= {"b":46989313,"p":[{"p":910706,"g":{"r":0,"d":0,"h":17180845426,"f":50331649},"s":{"r":0,"d":0,"h":21475812722,"f":83886081},"n":"AcceptSocket","d":976242,"h":12885878130,"f":2097153},{"p":$.$typeArray($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":30065747314,"f":50331649},"n":"Buffer","d":976242,"h":25770780018,"f":2097153},{"p":$.$$.System.Collections.Generic.IList$$($.$$.System.ArraySegment$$($.$$.System.Byte)).$h,"g":{"r":0,"d":0,"h":38655681906,"f":50331649},"s":{"r":0,"d":0,"h":42950649202,"f":83886081},"n":"BufferList","d":976242,"h":34360714610,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":51540583794,"f":50331649},"n":"BytesTransferred","d":976242,"h":47245616498,"f":2097153},{"p":47251457,"g":{"r":0,"d":0,"h":60130518386,"f":50331649},"n":"ConnectByNameError","d":976242,"h":55835551090,"f":2097153},{"p":910706,"g":{"r":0,"d":0,"h":68720452978,"f":50331649},"n":"ConnectSocket","d":976242,"h":64425485682,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":77310387570,"f":50331649},"n":"Count","d":976242,"h":73015420274,"f":2097153},{"p":262145,"g":{"r":0,"d":0,"h":85900322162,"f":50331649},"s":{"r":0,"d":0,"h":90195289458,"f":83886081},"n":"DisconnectReuseSocket","d":976242,"h":81605354866,"f":2097153},{"p":1041778,"g":{"r":0,"d":0,"h":98785224050,"f":50331649},"n":"LastOperation","d":976242,"h":94490256754,"f":2097153},{"p":$.$$.System.Memory$$($.$$.System.Byte).$h,"g":{"r":0,"d":0,"h":107375158642,"f":50331649},"n":"MemoryBuffer","d":976242,"h":103080191346,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":115965093234,"f":50331649},"n":"Offset","d":976242,"h":111670125938,"f":2097153},{"p":189810,"g":{"r":0,"d":0,"h":124555027826,"f":50331649},"n":"ReceiveMessageFromPacketInfo","d":976242,"h":120260060530,"f":2097153},{"p":2605813,"g":{"r":0,"d":0,"h":133144962418,"f":50331649},"s":{"r":0,"d":0,"h":137439929714,"f":83886081},"n":"RemoteEndPoint","d":976242,"h":128849995122,"f":2097153},{"p":$.$typeArray($.$sns.System.Net.Sockets.SendPacketsElement).$h,"g":{"r":0,"d":0,"h":146029864306,"f":50331649},"s":{"r":0,"d":0,"h":150324831602,"f":83886081},"n":"SendPacketsElements","d":976242,"h":141734897010,"f":2097153},{"p":1893746,"g":{"r":0,"d":0,"h":158914766194,"f":50331649},"s":{"r":0,"d":0,"h":163209733490,"f":83886081},"n":"SendPacketsFlags","d":976242,"h":154619798898,"f":2097153},{"p":655361,"g":{"r":0,"d":0,"h":171799668082,"f":50331649},"s":{"r":0,"d":0,"h":176094635378,"f":83886081},"n":"SendPacketsSendSize","d":976242,"h":167504700786,"f":2097153},{"p":4702965,"g":{"r":0,"d":0,"h":184684569970,"f":50331649},"s":{"r":0,"d":0,"h":188979537266,"f":83886081},"n":"SocketError","d":976242,"h":180389602674,"f":2097153},{"p":1107314,"g":{"r":0,"d":0,"h":197569471858,"f":50331649},"s":{"r":0,"d":0,"h":201864439154,"f":83886081},"n":"SocketFlags","d":976242,"h":193274504562,"f":2097153},{"p":131073,"g":{"r":0,"d":0,"h":210454373746,"f":50331649},"s":{"r":0,"d":0,"h":214749341042,"f":83886081},"n":"UserToken","d":976242,"h":206159406450,"f":2097153}],"m":[{"r":65537,"n":"Dispose","d":976242,"h":231929210226,"f":16777217},{"r":65537,"p":[{"n":"e","p":976242}],"n":"OnCompleted","d":976242,"h":240519144818,"f":16777348},{"r":65537,"p":[{"n":"buffer","p":$.$typeArray($.$$.System.Byte).$h},{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"SetBuffer","d":976242,"h":244814112114,"f":16777217},{"r":65537,"p":[{"n":"offset","p":655361},{"n":"count","p":655361}],"n":"SetBuffer","o":"@$1","d":976242,"h":249109079410,"f":16777217},{"r":65537,"p":[{"n":"buffer","p":$.$$.System.Memory$$($.$$.System.Byte).$h}],"n":"SetBuffer","o":"@$2","d":976242,"h":253404046706,"f":16777217}],"c":[{"n":".ctor","o":"$ctor$2","d":976242,"h":4295943538,"f":16777217},{"p":[{"n":"unsafeSuppressExecutionContextFlow","p":262145}],"n":".ctor","o":"$ctor$3","d":976242,"h":8590910834,"f":16777217}],"e":[{"e":$.$$.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h,"m":{"r":65537,"p":[{"n":"value","p":$.$$.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h}],"n":"add_Completed","d":976242,"h":223339275634,"f":150994945},"r":{"r":65537,"p":[{"n":"value","p":$.$$.System.EventHandler$$($.$sns.System.Net.Sockets.SocketAsyncEventArgs).$h}],"n":"remove_Completed","d":976242,"h":227634242930,"f":285212673},"n":"Completed","d":976242,"h":219044308338,"f":8388609}],"i":[57540609],"h":976242}; }
            static get $b() { return $.$$.System.EventArgs; }
            static $$i;
            static get $i() { return this.$$i ??= [ $.$$.System.IDisposable ]; }
            static get $fullName() { return `System.Net.Sockets.SocketAsyncEventArgs`; }
        });
	});
})(window, window.NetJs.$boot(), ...window.NetJs.$require("NetJs.System.Private.CoreLib", "NetJs.Microsoft.Win32.Primitives", "NetJs.System.Collections", "NetJs.System.Diagnostics.Tracing", "NetJs.System.Threading", "NetJs.System.Collections.Concurrent", "NetJs.System.Memory", "NetJs.System.Private.Uri", "NetJs.System.Runtime", "NetJs.System.Collections.NonGeneric", "NetJs.System.Runtime.InteropServices", "NetJs.System.Text.Encoding.Extensions", "NetJs.System.Console", "NetJs.System.Numerics.Vectors", "NetJs.System.Runtime.Intrinsics", "NetJs.System.Linq", "NetJs.System.Threading.Thread", "NetJs.System.Threading.ThreadPool", "NetJs.System.Diagnostics.DiagnosticSource", "NetJs.System.Net.Primitives", "NetJs.System.Security.Claims", "NetJs.System.Security.Principal.Windows", "NetJs.System.Threading.Overlapped", "NetJs.System.Net.NameResolution"))